// 
// Decompiled by Procyon v0.5.36
// 

package org.objectweb.asm.tree;

public class UnsupportedClassVersionException extends RuntimeException
{
    private static final long serialVersionUID = -3502347765891805831L;
}
