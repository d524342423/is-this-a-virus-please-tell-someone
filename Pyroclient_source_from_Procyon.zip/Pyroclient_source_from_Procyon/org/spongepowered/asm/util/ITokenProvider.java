// 
// Decompiled by Procyon v0.5.36
// 

package org.spongepowered.asm.util;

public interface ITokenProvider
{
    Integer getToken(final String p0);
}
