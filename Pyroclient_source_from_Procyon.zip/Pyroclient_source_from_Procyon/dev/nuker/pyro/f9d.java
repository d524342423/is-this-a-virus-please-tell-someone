// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

public class f9d
{
    public static int[] c;
}
