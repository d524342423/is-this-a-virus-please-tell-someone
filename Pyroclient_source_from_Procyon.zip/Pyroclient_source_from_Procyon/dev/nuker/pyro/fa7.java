// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

public enum fa7
{
    public static fa7 c;
    public static fa7 0;
    public static fa7 1;
    public static fa7 2;
    public static fa7[] c;
    
    public fa7(final String name, final int ordinal) {
        while (true) {
            Label_0014: {
                if (fc.1 == 0) {
                    n = -2005253248;
                    break Label_0014;
                }
                n = 1778149141;
            }
            switch (n ^ 0xD8C9EA25) {
                case 1424268186: {
                    continue;
                }
                default: {
                    super(name, ordinal);
                }
                case 1353951653: {
                    throw null;
                }
            }
            break;
        }
    }
    
    static {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: anewarray       Ldev/nuker/pyro/fa7;
        //     4: dup            
        //     5: dup            
        //     6: iconst_0       
        //     7: new             Ldev/nuker/pyro/fa7;
        //    10: dup            
        //    11: ldc             "\u3796\ub24b\u84e6\ua16b\u54a2\u5354\u7e54"
        //    13: invokestatic    invokestatic   !!! ERROR
        //    16: iconst_0       
        //    17: getstatic       dev/nuker/pyro/fc.c:I
        //    20: ifne            28
        //    23: ldc             -1933826209
        //    25: goto            30
        //    28: ldc             444205639
        //    30: ldc             529852720
        //    32: ixor           
        //    33: lookupswitch {
        //          -1826042257: 28
        //          99541879: 60
        //          default: 224
        //        }
        //    60: invokespecial   dev/nuker/pyro/fa7.<init>:(Ljava/lang/String;I)V
        //    63: dup            
        //    64: putstatic       dev/nuker/pyro/fa7.c:Ldev/nuker/pyro/fa7;
        //    67: aastore        
        //    68: dup            
        //    69: iconst_1       
        //    70: new             Ldev/nuker/pyro/fa7;
        //    73: dup            
        //    74: ldc             "\u379e\ub241\u84f1"
        //    76: invokestatic    invokestatic   !!! ERROR
        //    79: iconst_1       
        //    80: invokespecial   dev/nuker/pyro/fa7.<init>:(Ljava/lang/String;I)V
        //    83: dup            
        //    84: putstatic       dev/nuker/pyro/fa7.0:Ldev/nuker/pyro/fa7;
        //    87: aastore        
        //    88: dup            
        //    89: iconst_2       
        //    90: new             Ldev/nuker/pyro/fa7;
        //    93: dup            
        //    94: ldc             "\u3792\ub250\u84f9\ua16b\u54aa\u534a\u7e4c\u63fb"
        //    96: invokestatic    invokestatic   !!! ERROR
        //    99: iconst_2       
        //   100: invokespecial   dev/nuker/pyro/fa7.<init>:(Ljava/lang/String;I)V
        //   103: dup            
        //   104: getstatic       dev/nuker/pyro/fc.0:I
        //   107: ifgt            115
        //   110: ldc             248309543
        //   112: goto            117
        //   115: ldc             1644820895
        //   117: ldc             2067394702
        //   119: ixor           
        //   120: lookupswitch {
        //          987140232: 115
        //          1978996649: 220
        //          default: 148
        //        }
        //   148: putstatic       dev/nuker/pyro/fa7.1:Ldev/nuker/pyro/fa7;
        //   151: aastore        
        //   152: dup            
        //   153: iconst_3       
        //   154: new             Ldev/nuker/pyro/fa7;
        //   157: dup            
        //   158: ldc             "\u379e\ub246\u84f0"
        //   160: invokestatic    invokestatic   !!! ERROR
        //   163: iconst_3       
        //   164: invokespecial   dev/nuker/pyro/fa7.<init>:(Ljava/lang/String;I)V
        //   167: dup            
        //   168: putstatic       dev/nuker/pyro/fa7.2:Ldev/nuker/pyro/fa7;
        //   171: aastore        
        //   172: getstatic       dev/nuker/pyro/fc.1:I
        //   175: ifne            183
        //   178: ldc             684598785
        //   180: goto            185
        //   183: ldc             1872745267
        //   185: ldc             -347090976
        //   187: ixor           
        //   188: lookupswitch {
        //          -1014896159: 222
        //          256871627: 183
        //          default: 216
        //        }
        //   216: putstatic       dev/nuker/pyro/fa7.c:[Ldev/nuker/pyro/fa7;
        //   219: return         
        //   220: aconst_null    
        //   221: athrow         
        //   222: aconst_null    
        //   223: athrow         
        //   224: aconst_null    
        //   225: athrow         
        //    StackMapTable: 00 0C FF 00 1C 00 00 00 08 07 00 41 07 00 41 07 00 41 01 08 00 07 08 00 07 07 00 19 01 FF 00 01 00 00 00 09 07 00 41 07 00 41 07 00 41 01 08 00 07 08 00 07 07 00 19 01 01 FF 00 1D 00 00 00 08 07 00 41 07 00 41 07 00 41 01 08 00 07 08 00 07 07 00 19 01 FF 00 36 00 00 00 06 07 00 41 07 00 41 07 00 41 01 07 00 03 07 00 03 FF 00 01 00 00 00 07 07 00 41 07 00 41 07 00 41 01 07 00 03 07 00 03 01 FF 00 1E 00 00 00 06 07 00 41 07 00 41 07 00 41 01 07 00 03 07 00 03 FF 00 22 00 00 00 02 07 00 41 07 00 41 FF 00 01 00 00 00 03 07 00 41 07 00 41 01 FF 00 1E 00 00 00 02 07 00 41 07 00 41 FF 00 03 00 00 00 06 07 00 41 07 00 41 07 00 41 01 07 00 03 07 00 03 FF 00 01 00 00 00 02 07 00 41 07 00 41 FF 00 01 00 00 00 08 07 00 41 07 00 41 07 00 41 01 08 00 07 08 00 07 07 00 19 01
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static fa7 c(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          67
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            59
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            51
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: ldc             Ldev/nuker/pyro/fa7;.class
        //    26: aload_0        
        //    27: goto            31
        //    30: athrow         
        //    31: invokestatic    java/lang/Enum.valueOf:(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
        //    34: goto            38
        //    37: athrow         
        //    38: checkcast       Ldev/nuker/pyro/fa7;
        //    41: areturn        
        //    42: pop            
        //    43: goto            24
        //    46: pop            
        //    47: aconst_null    
        //    48: goto            42
        //    51: dup            
        //    52: ifnull          42
        //    55: checkcast       Ljava/lang/Throwable;
        //    58: athrow         
        //    59: dup            
        //    60: ifnull          46
        //    63: checkcast       Ljava/lang/Throwable;
        //    66: athrow         
        //    67: aconst_null    
        //    68: athrow         
        //    StackMapTable: 00 0D 43 07 00 48 04 FF 00 0B 00 00 00 01 07 00 48 FC 00 03 07 00 19 45 07 00 46 FF 00 00 00 01 07 00 19 00 02 07 00 4E 07 00 19 45 07 00 48 40 07 00 05 43 07 00 48 43 05 44 07 00 48 47 05 47 07 00 48
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     51     59     Ljava/lang/ArrayIndexOutOfBoundsException;
        //  51     59     51     59     Any
        //  67     69     3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  30     37     37     38     Any
        //  31     37     37     38     Ljava/lang/EnumConstantNotPresentException;
        //  31     37     37     38     Ljava/lang/ArrayIndexOutOfBoundsException;
        //  31     37     30     31     Ljava/lang/EnumConstantNotPresentException;
        //  30     37     3      8      Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 34 out of bounds for length 34
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
