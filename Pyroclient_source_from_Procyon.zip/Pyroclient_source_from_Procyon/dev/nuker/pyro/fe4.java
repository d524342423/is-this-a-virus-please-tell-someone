// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import org.jetbrains.annotations.NotNull;
import java.util.ArrayList;
import org.jetbrains.annotations.Nullable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import java.util.List;

public class fe4
{
    public static List<EntityOtherPlayerMP> c;
    public static List<EntityOtherPlayerMP> 0;
    public static fe4 c;
    
    public fe4() {
        while (true) {
            int n = 0;
            Label_0014: {
                if (fc.1 == 0) {
                    n = 264797636;
                    break Label_0014;
                }
                n = 2083976379;
            }
            switch (n ^ 0x625A83DA) {
                case -665768996: {
                    continue;
                }
                default: {}
                case 1838349854: {
                    throw null;
                }
            }
            break;
        }
    }
    
    public boolean c(@Nullable final EntityPlayer entityPlayer) {
        return fez.0h(this, 1886396015, entityPlayer);
    }
    
    static {
        fe4.c = new fe4();
        final ArrayList<EntityOtherPlayerMP> c = new ArrayList<EntityOtherPlayerMP>();
        while (true) {
            int n = 0;
            Label_0037: {
                if (fc.c == 0) {
                    n = -941073065;
                    break Label_0037;
                }
                n = 2098793053;
            }
            switch (n ^ 0x8EE9D0F6) {
                case 1224838561: {
                    continue;
                }
                case -202319189: {
                    fe4.c = c;
                    fe4.0 = new ArrayList<EntityOtherPlayerMP>();
                }
                default: {
                    throw null;
                }
            }
            break;
        }
    }
    
    public void c() {
        fez.ga(this, 161016495);
    }
    
    public void c(@NotNull final EntityOtherPlayerMP p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          532
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            524
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            516
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: getstatic       dev/nuker/pyro/fc.c:I
        //    27: ifne            35
        //    30: ldc             -863904202
        //    32: goto            37
        //    35: ldc             -1527947037
        //    37: ldc             -731544247
        //    39: ixor           
        //    40: lookupswitch {
        //          417618815: 35
        //          1888019882: 68
        //          default: 497
        //        }
        //    68: aload_1        
        //    69: pop            
        //    70: goto            74
        //    73: athrow         
        //    74: invokestatic    net/minecraft/client/Minecraft.func_71410_x:()Lnet/minecraft/client/Minecraft;
        //    77: goto            81
        //    80: athrow         
        //    81: getstatic       dev/nuker/pyro/fc.0:I
        //    84: ifgt            92
        //    87: ldc             1519830832
        //    89: goto            94
        //    92: ldc             -1984225210
        //    94: ldc             -1746611717
        //    96: ixor           
        //    97: lookupswitch {
        //          -848161077: 92
        //          509604285: 124
        //          default: 499
        //        }
        //   124: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //   127: ifnull          135
        //   130: ldc             1103914574
        //   132: goto            137
        //   135: ldc             1103914573
        //   137: ldc             -1286110049
        //   139: ixor           
        //   140: tableswitch {
        //          -449329758: 164
        //          -449329757: 328
        //          default: 130
        //        }
        //   164: getstatic       dev/nuker/pyro/fc.1:I
        //   167: ifne            175
        //   170: ldc             1036850308
        //   172: goto            177
        //   175: ldc             -1074950462
        //   177: ldc             446610428
        //   179: ixor           
        //   180: lookupswitch {
        //          -1519176386: 208
        //          659795832: 175
        //          default: 505
        //        }
        //   208: goto            212
        //   211: athrow         
        //   212: invokestatic    net/minecraft/client/Minecraft.func_71410_x:()Lnet/minecraft/client/Minecraft;
        //   215: goto            219
        //   218: athrow         
        //   219: getstatic       dev/nuker/pyro/fc.c:I
        //   222: ifne            230
        //   225: ldc             -1235640544
        //   227: goto            232
        //   230: ldc             1528803263
        //   232: ldc             -1270870660
        //   234: ixor           
        //   235: lookupswitch {
        //          -278945085: 260
        //          35230300: 230
        //          default: 491
        //        }
        //   260: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //   263: aload_1        
        //   264: goto            268
        //   267: athrow         
        //   268: invokevirtual   net/minecraft/client/entity/EntityOtherPlayerMP.func_145782_y:()I
        //   271: goto            275
        //   274: athrow         
        //   275: getstatic       dev/nuker/pyro/fc.c:I
        //   278: ifne            286
        //   281: ldc             -662346795
        //   283: goto            288
        //   286: ldc             114738357
        //   288: ldc             970858466
        //   290: ixor           
        //   291: lookupswitch {
        //          -1324842623: 286
        //          -514098121: 495
        //          default: 316
        //        }
        //   316: goto            320
        //   319: athrow         
        //   320: invokevirtual   net/minecraft/client/multiplayer/WorldClient.func_73028_b:(I)Lnet/minecraft/entity/Entity;
        //   323: goto            327
        //   326: athrow         
        //   327: pop            
        //   328: getstatic       dev/nuker/pyro/fe4.c:Ljava/util/List;
        //   331: getstatic       dev/nuker/pyro/fc.0:I
        //   334: ifgt            342
        //   337: ldc             1125034151
        //   339: goto            344
        //   342: ldc             1704917193
        //   344: ldc             -1045324281
        //   346: ixor           
        //   347: lookupswitch {
        //          -2101397856: 503
        //          -1354679395: 342
        //          default: 372
        //        }
        //   372: aload_1        
        //   373: getstatic       dev/nuker/pyro/fc.1:I
        //   376: ifne            384
        //   379: ldc             235626015
        //   381: goto            386
        //   384: ldc             1115039304
        //   386: ldc             1954886236
        //   388: ixor           
        //   389: lookupswitch {
        //          921900052: 416
        //          2056154179: 384
        //          default: 493
        //        }
        //   416: goto            420
        //   419: athrow         
        //   420: invokeinterface java/util/List.remove:(Ljava/lang/Object;)Z
        //   425: goto            429
        //   428: athrow         
        //   429: pop            
        //   430: getstatic       dev/nuker/pyro/fc.0:I
        //   433: ifgt            441
        //   436: ldc             -1736246290
        //   438: goto            443
        //   441: ldc             -1576668623
        //   443: ldc             -662821451
        //   445: ixor           
        //   446: lookupswitch {
        //          -331163781: 441
        //          1090313819: 501
        //          default: 472
        //        }
        //   472: getstatic       dev/nuker/pyro/fe4.0:Ljava/util/List;
        //   475: aload_1        
        //   476: goto            480
        //   479: athrow         
        //   480: invokeinterface java/util/List.remove:(Ljava/lang/Object;)Z
        //   485: goto            489
        //   488: athrow         
        //   489: pop            
        //   490: return         
        //   491: aconst_null    
        //   492: athrow         
        //   493: aconst_null    
        //   494: athrow         
        //   495: aconst_null    
        //   496: athrow         
        //   497: aconst_null    
        //   498: athrow         
        //   499: aconst_null    
        //   500: athrow         
        //   501: aconst_null    
        //   502: athrow         
        //   503: aconst_null    
        //   504: athrow         
        //   505: aconst_null    
        //   506: athrow         
        //   507: pop            
        //   508: goto            24
        //   511: pop            
        //   512: aconst_null    
        //   513: goto            507
        //   516: dup            
        //   517: ifnull          507
        //   520: checkcast       Ljava/lang/Throwable;
        //   523: athrow         
        //   524: dup            
        //   525: ifnull          511
        //   528: checkcast       Ljava/lang/Throwable;
        //   531: athrow         
        //   532: aconst_null    
        //   533: athrow         
        //    StackMapTable: 00 46 43 07 00 4D 04 FF 00 0B 00 00 00 01 07 00 4D FD 00 03 07 00 03 07 00 6A 0A 41 01 1E 44 07 00 4D 00 45 07 00 4D 40 07 00 52 4A 07 00 52 FF 00 01 00 02 07 00 03 07 00 6A 00 02 07 00 52 01 5D 07 00 52 05 04 41 01 1A 0A 41 01 1E 42 07 00 49 00 45 07 00 4D 40 07 00 52 4A 07 00 52 FF 00 01 00 02 07 00 03 07 00 6A 00 02 07 00 52 01 5B 07 00 52 46 07 00 4D FF 00 00 00 02 07 00 03 07 00 6A 00 02 07 00 73 07 00 6A 45 07 00 4D FF 00 00 00 02 07 00 03 07 00 6A 00 02 07 00 73 01 FF 00 0A 00 02 07 00 03 07 00 6A 00 02 07 00 73 01 FF 00 01 00 02 07 00 03 07 00 6A 00 03 07 00 73 01 01 FF 00 1B 00 02 07 00 03 07 00 6A 00 02 07 00 73 01 FF 00 02 00 00 00 01 07 00 4D FF 00 00 00 02 07 00 03 07 00 6A 00 02 07 00 73 01 45 07 00 4D 40 07 00 86 00 4D 07 00 29 FF 00 01 00 02 07 00 03 07 00 6A 00 02 07 00 29 01 5B 07 00 29 FF 00 0B 00 02 07 00 03 07 00 6A 00 02 07 00 29 07 00 6A FF 00 01 00 02 07 00 03 07 00 6A 00 03 07 00 29 07 00 6A 01 FF 00 1D 00 02 07 00 03 07 00 6A 00 02 07 00 29 07 00 6A FF 00 02 00 00 00 01 07 00 4D FF 00 00 00 02 07 00 03 07 00 6A 00 02 07 00 29 07 00 6A 47 07 00 4D 40 01 0B 41 01 1C 46 07 00 4D FF 00 00 00 02 07 00 03 07 00 6A 00 02 07 00 29 07 00 6A 47 07 00 4D 40 01 41 07 00 52 FF 00 01 00 02 07 00 03 07 00 6A 00 02 07 00 29 07 00 6A FF 00 01 00 02 07 00 03 07 00 6A 00 02 07 00 73 01 01 41 07 00 52 01 41 07 00 29 01 41 07 00 4D 43 05 44 07 00 4D 47 05 47 07 00 4D
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     516    524    Any
        //  516    524    516    524    Any
        //  532    534    3      8      Any
        //  73     80     80     81     Any
        //  73     80     73     74     Ljava/lang/StringIndexOutOfBoundsException;
        //  74     80     80     81     Ljava/lang/ArithmeticException;
        //  74     80     73     74     Any
        //  73     80     80     81     Ljava/lang/ArithmeticException;
        //  211    218    218    219    Any
        //  212    218    211    212    Ljava/lang/IllegalStateException;
        //  211    218    211    212    Ljava/lang/UnsupportedOperationException;
        //  211    218    3      8      Any
        //  211    218    211    212    Ljava/lang/StringIndexOutOfBoundsException;
        //  267    274    274    275    Any
        //  268    274    3      8      Ljava/lang/UnsupportedOperationException;
        //  268    274    267    268    Any
        //  268    274    267    268    Any
        //  268    274    274    275    Ljava/util/NoSuchElementException;
        //  320    326    326    327    Any
        //  320    326    326    327    Ljava/lang/ArithmeticException;
        //  320    326    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  320    326    326    327    Ljava/util/NoSuchElementException;
        //  320    326    3      8      Ljava/lang/NullPointerException;
        //  420    428    428    429    Any
        //  420    428    3      8      Any
        //  420    428    428    429    Any
        //  420    428    428    429    Any
        //  420    428    428    429    Ljava/lang/RuntimeException;
        //  479    488    488    489    Any
        //  479    488    3      8      Ljava/lang/RuntimeException;
        //  480    488    488    489    Ljava/lang/IllegalArgumentException;
        //  479    488    479    480    Any
        //  480    488    488    489    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:738)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @NotNull
    public EntityOtherPlayerMP c(@NotNull final EntityPlayer p0, final int p1, final boolean p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          737
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            729
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            721
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: getstatic       dev/nuker/pyro/fc.0:I
        //    27: ifgt            35
        //    30: ldc             1947635624
        //    32: goto            37
        //    35: ldc             1198512312
        //    37: ldc             -650189348
        //    39: ixor           
        //    40: lookupswitch {
        //          -1638843036: 68
        //          -1389860236: 35
        //          default: 694
        //        }
        //    68: aload_1        
        //    69: pop            
        //    70: new             Lnet/minecraft/client/entity/EntityOtherPlayerMP;
        //    73: dup            
        //    74: aload_1        
        //    75: getfield        net/minecraft/entity/player/EntityPlayer.field_70170_p:Lnet/minecraft/world/World;
        //    78: aload_1        
        //    79: goto            83
        //    82: athrow         
        //    83: invokevirtual   net/minecraft/entity/player/EntityPlayer.func_146103_bH:()Lcom/mojang/authlib/GameProfile;
        //    86: goto            90
        //    89: athrow         
        //    90: goto            94
        //    93: athrow         
        //    94: invokespecial   net/minecraft/client/entity/EntityOtherPlayerMP.<init>:(Lnet/minecraft/world/World;Lcom/mojang/authlib/GameProfile;)V
        //    97: goto            101
        //   100: athrow         
        //   101: getstatic       dev/nuker/pyro/fc.1:I
        //   104: ifne            112
        //   107: ldc             -1376710227
        //   109: goto            114
        //   112: ldc             837913478
        //   114: ldc             -1964612371
        //   116: ixor           
        //   117: lookupswitch {
        //          -1156059285: 144
        //          655848768: 112
        //          default: 706
        //        }
        //   144: astore          4
        //   146: aload           4
        //   148: getstatic       dev/nuker/pyro/fc.0:I
        //   151: ifgt            159
        //   154: ldc             -1458290787
        //   156: goto            161
        //   159: ldc             -1860495718
        //   161: ldc             770949324
        //   163: ixor           
        //   164: lookupswitch {
        //          -2065170607: 702
        //          385044527: 159
        //          default: 192
        //        }
        //   192: aload_1        
        //   193: checkcast       Lnet/minecraft/entity/Entity;
        //   196: goto            200
        //   199: athrow         
        //   200: invokevirtual   net/minecraft/client/entity/EntityOtherPlayerMP.func_82149_j:(Lnet/minecraft/entity/Entity;)V
        //   203: goto            207
        //   206: athrow         
        //   207: aload           4
        //   209: aload_1        
        //   210: getfield        net/minecraft/entity/player/EntityPlayer.field_70177_z:F
        //   213: getstatic       dev/nuker/pyro/fc.0:I
        //   216: ifgt            224
        //   219: ldc             -1797711562
        //   221: goto            226
        //   224: ldc             -1908844028
        //   226: ldc             1204899831
        //   228: ixor           
        //   229: lookupswitch {
        //          -907536909: 256
        //          -754428223: 224
        //          default: 692
        //        }
        //   256: putfield        net/minecraft/client/entity/EntityOtherPlayerMP.field_70177_z:F
        //   259: getstatic       dev/nuker/pyro/fc.1:I
        //   262: ifne            270
        //   265: ldc             -1648017120
        //   267: goto            272
        //   270: ldc             -862128511
        //   272: ldc             404507202
        //   274: ixor           
        //   275: lookupswitch {
        //          -2049373342: 700
        //          -1749584855: 270
        //          default: 300
        //        }
        //   300: aload           4
        //   302: getstatic       dev/nuker/pyro/fc.c:I
        //   305: ifne            313
        //   308: ldc             -829661287
        //   310: goto            315
        //   313: ldc             1869214858
        //   315: ldc             -224675237
        //   317: ixor           
        //   318: lookupswitch {
        //          -1645064495: 344
        //          1008199106: 313
        //          default: 710
        //        }
        //   344: aload_1        
        //   345: getfield        net/minecraft/entity/player/EntityPlayer.field_70759_as:F
        //   348: putfield        net/minecraft/client/entity/EntityOtherPlayerMP.field_70759_as:F
        //   351: aload           4
        //   353: getfield        net/minecraft/client/entity/EntityOtherPlayerMP.field_71071_by:Lnet/minecraft/entity/player/InventoryPlayer;
        //   356: aload_1        
        //   357: getfield        net/minecraft/entity/player/EntityPlayer.field_71071_by:Lnet/minecraft/entity/player/InventoryPlayer;
        //   360: goto            364
        //   363: athrow         
        //   364: invokevirtual   net/minecraft/entity/player/InventoryPlayer.func_70455_b:(Lnet/minecraft/entity/player/InventoryPlayer;)V
        //   367: goto            371
        //   370: athrow         
        //   371: aload           4
        //   373: checkcast       Ldev/nuker/pyro/mixin/EntityFlagAccessor;
        //   376: bipush          7
        //   378: aload_1        
        //   379: goto            383
        //   382: athrow         
        //   383: invokevirtual   net/minecraft/entity/player/EntityPlayer.func_184613_cA:()Z
        //   386: goto            390
        //   389: athrow         
        //   390: goto            394
        //   393: athrow         
        //   394: invokeinterface dev/nuker/pyro/mixin/EntityFlagAccessor.set:(IZ)V
        //   399: goto            403
        //   402: athrow         
        //   403: goto            407
        //   406: athrow         
        //   407: invokestatic    net/minecraft/client/Minecraft.func_71410_x:()Lnet/minecraft/client/Minecraft;
        //   410: goto            414
        //   413: athrow         
        //   414: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //   417: iload_2        
        //   418: aload           4
        //   420: checkcast       Lnet/minecraft/entity/Entity;
        //   423: goto            427
        //   426: athrow         
        //   427: invokevirtual   net/minecraft/client/multiplayer/WorldClient.func_73027_a:(ILnet/minecraft/entity/Entity;)V
        //   430: goto            434
        //   433: athrow         
        //   434: getstatic       dev/nuker/pyro/fc.0:I
        //   437: ifgt            445
        //   440: ldc             -1388927234
        //   442: goto            447
        //   445: ldc             1570308518
        //   447: ldc             237644619
        //   449: ixor           
        //   450: lookupswitch {
        //          -1558409803: 708
        //          -274432746: 445
        //          default: 476
        //        }
        //   476: getstatic       dev/nuker/pyro/fe4.c:Ljava/util/List;
        //   479: aload           4
        //   481: goto            485
        //   484: athrow         
        //   485: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //   490: goto            494
        //   493: athrow         
        //   494: pop            
        //   495: iload_3        
        //   496: ifeq            560
        //   499: getstatic       dev/nuker/pyro/fe4.0:Ljava/util/List;
        //   502: getstatic       dev/nuker/pyro/fc.0:I
        //   505: ifgt            513
        //   508: ldc             -1304375044
        //   510: goto            515
        //   513: ldc             -190294050
        //   515: ldc             106698332
        //   517: ixor           
        //   518: lookupswitch {
        //          -1273182560: 698
        //          1092909676: 513
        //          default: 544
        //        }
        //   544: aload           4
        //   546: goto            550
        //   549: athrow         
        //   550: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //   555: goto            559
        //   558: athrow         
        //   559: pop            
        //   560: getstatic       dev/nuker/pyro/fc.0:I
        //   563: ifgt            571
        //   566: ldc             932015890
        //   568: goto            573
        //   571: ldc             372400971
        //   573: ldc             -224787253
        //   575: ixor           
        //   576: lookupswitch {
        //          -988320807: 571
        //          -458725504: 604
        //          default: 704
        //        }
        //   604: aload_1        
        //   605: goto            609
        //   608: athrow         
        //   609: invokevirtual   net/minecraft/entity/player/EntityPlayer.func_184187_bx:()Lnet/minecraft/entity/Entity;
        //   612: goto            616
        //   615: athrow         
        //   616: ifnull          689
        //   619: aload           4
        //   621: getstatic       dev/nuker/pyro/fc.1:I
        //   624: ifne            632
        //   627: ldc             1980773938
        //   629: goto            634
        //   632: ldc             1471044672
        //   634: ldc             1469066930
        //   636: ixor           
        //   637: lookupswitch {
        //          4092658: 664
        //          562043008: 632
        //          default: 696
        //        }
        //   664: aload_1        
        //   665: goto            669
        //   668: athrow         
        //   669: invokevirtual   net/minecraft/entity/player/EntityPlayer.func_184187_bx:()Lnet/minecraft/entity/Entity;
        //   672: goto            676
        //   675: athrow         
        //   676: iconst_1       
        //   677: goto            681
        //   680: athrow         
        //   681: invokevirtual   net/minecraft/client/entity/EntityOtherPlayerMP.func_184205_a:(Lnet/minecraft/entity/Entity;Z)Z
        //   684: goto            688
        //   687: athrow         
        //   688: pop            
        //   689: aload           4
        //   691: areturn        
        //   692: aconst_null    
        //   693: athrow         
        //   694: aconst_null    
        //   695: athrow         
        //   696: aconst_null    
        //   697: athrow         
        //   698: aconst_null    
        //   699: athrow         
        //   700: aconst_null    
        //   701: athrow         
        //   702: aconst_null    
        //   703: athrow         
        //   704: aconst_null    
        //   705: athrow         
        //   706: aconst_null    
        //   707: athrow         
        //   708: aconst_null    
        //   709: athrow         
        //   710: aconst_null    
        //   711: athrow         
        //   712: pop            
        //   713: goto            24
        //   716: pop            
        //   717: aconst_null    
        //   718: goto            712
        //   721: dup            
        //   722: ifnull          712
        //   725: checkcast       Ljava/lang/Throwable;
        //   728: athrow         
        //   729: dup            
        //   730: ifnull          716
        //   733: checkcast       Ljava/lang/Throwable;
        //   736: athrow         
        //   737: aconst_null    
        //   738: athrow         
        //    StackMapTable: 00 67 43 07 00 4D 04 FF 00 0B 00 00 00 01 07 00 4D FF 00 03 00 04 07 00 03 07 00 98 01 01 00 00 0A 41 01 1E FF 00 0D 00 00 00 01 07 00 4D FF 00 00 00 04 07 00 03 07 00 98 01 01 00 04 08 00 46 08 00 46 07 00 F1 07 00 98 45 07 00 4D FF 00 00 00 04 07 00 03 07 00 98 01 01 00 04 08 00 46 08 00 46 07 00 F1 07 00 F3 42 07 00 4D FF 00 00 00 04 07 00 03 07 00 98 01 01 00 04 08 00 46 08 00 46 07 00 F1 07 00 F3 45 07 00 4D 40 07 00 6A 4A 07 00 6A FF 00 01 00 04 07 00 03 07 00 98 01 01 00 02 07 00 6A 01 5D 07 00 6A FF 00 0E 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 01 07 00 6A FF 00 01 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 02 07 00 6A 01 5E 07 00 6A 46 07 00 49 FF 00 00 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 02 07 00 6A 07 00 86 45 07 00 4D 00 FF 00 10 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 02 07 00 6A 02 FF 00 01 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 03 07 00 6A 02 01 FF 00 1D 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 02 07 00 6A 02 0D 41 01 1B 4C 07 00 6A FF 00 01 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 02 07 00 6A 01 5C 07 00 6A 52 07 00 41 FF 00 00 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 02 07 00 C6 07 00 C6 45 07 00 4D 00 4A 07 00 4D FF 00 00 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 03 07 00 CC 01 07 00 98 45 07 00 4D FF 00 00 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 03 07 00 CC 01 01 42 07 00 4D FF 00 00 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 03 07 00 CC 01 01 47 07 00 4D 00 42 07 00 4D 00 45 07 00 4D 40 07 00 52 4B 07 00 49 FF 00 00 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 03 07 00 73 01 07 00 86 45 07 00 4D 00 0A 41 01 1C FF 00 07 00 00 00 01 07 00 4D FF 00 00 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 02 07 00 29 07 00 6A 47 07 00 4D 40 01 52 07 00 29 FF 00 01 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 02 07 00 29 01 5C 07 00 29 44 07 00 4D FF 00 00 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 02 07 00 29 07 00 6A 47 07 00 4D 40 01 00 0A 41 01 1E 43 07 00 4D 40 07 00 98 45 07 00 4D 40 07 00 86 4F 07 00 6A FF 00 01 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 02 07 00 6A 01 5D 07 00 6A 43 07 00 4D FF 00 00 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 02 07 00 6A 07 00 98 45 07 00 4D FF 00 00 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 02 07 00 6A 07 00 86 43 07 00 91 FF 00 00 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 03 07 00 6A 07 00 86 01 45 07 00 4D 40 01 00 FF 00 02 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 02 07 00 6A 02 FA 00 01 FF 00 01 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 01 07 00 6A 41 07 00 29 01 41 07 00 6A 01 FF 00 01 00 04 07 00 03 07 00 98 01 01 00 01 07 00 6A FC 00 01 07 00 6A 41 07 00 6A FF 00 01 00 04 07 00 03 07 00 98 01 01 00 01 07 00 4D 43 05 44 07 00 4D 47 05 47 07 00 4D
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     721    729    Any
        //  721    729    721    729    Ljava/util/NoSuchElementException;
        //  737    739    3      8      Any
        //  83     89     89     90     Any
        //  83     89     89     90     Ljava/lang/ArrayIndexOutOfBoundsException;
        //  83     89     3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  83     89     89     90     Ljava/lang/NumberFormatException;
        //  83     89     89     90     Any
        //  93     100    100    101    Any
        //  93     100    93     94     Ljava/lang/AssertionError;
        //  94     100    93     94     Any
        //  94     100    3      8      Any
        //  94     100    100    101    Any
        //  199    206    206    207    Any
        //  200    206    206    207    Any
        //  200    206    199    200    Ljava/lang/IndexOutOfBoundsException;
        //  199    206    199    200    Ljava/util/ConcurrentModificationException;
        //  199    206    3      8      Ljava/lang/NullPointerException;
        //  363    370    370    371    Any
        //  363    370    3      8      Any
        //  363    370    3      8      Ljava/util/ConcurrentModificationException;
        //  364    370    370    371    Any
        //  363    370    363    364    Ljava/lang/UnsupportedOperationException;
        //  382    389    389    390    Any
        //  382    389    382    383    Any
        //  383    389    3      8      Any
        //  382    389    3      8      Any
        //  383    389    382    383    Any
        //  393    402    402    403    Any
        //  394    402    3      8      Any
        //  393    402    393    394    Ljava/lang/NullPointerException;
        //  394    402    393    394    Any
        //  394    402    393    394    Any
        //  406    413    413    414    Any
        //  407    413    413    414    Any
        //  407    413    413    414    Ljava/lang/EnumConstantNotPresentException;
        //  406    413    3      8      Any
        //  407    413    406    407    Any
        //  426    433    433    434    Any
        //  427    433    426    427    Ljava/util/ConcurrentModificationException;
        //  426    433    426    427    Ljava/lang/NullPointerException;
        //  426    433    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  426    433    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  485    493    493    494    Any
        //  485    493    3      8      Ljava/util/NoSuchElementException;
        //  485    493    3      8      Any
        //  485    493    493    494    Any
        //  485    493    3      8      Ljava/lang/ArithmeticException;
        //  549    558    558    559    Any
        //  549    558    558    559    Ljava/lang/NumberFormatException;
        //  550    558    549    550    Ljava/lang/NegativeArraySizeException;
        //  549    558    549    550    Any
        //  550    558    549    550    Ljava/lang/IllegalStateException;
        //  608    615    615    616    Any
        //  608    615    615    616    Any
        //  609    615    608    609    Any
        //  609    615    615    616    Any
        //  609    615    608    609    Ljava/lang/ArithmeticException;
        //  668    675    675    676    Any
        //  668    675    668    669    Any
        //  668    675    668    669    Any
        //  669    675    668    669    Any
        //  668    675    668    669    Ljava/lang/IllegalArgumentException;
        //  680    687    687    688    Any
        //  681    687    3      8      Any
        //  680    687    680    681    Ljava/lang/EnumConstantNotPresentException;
        //  681    687    680    681    Ljava/lang/EnumConstantNotPresentException;
        //  681    687    3      8      Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalArgumentException: Argument 'offset' must be in the range [0, 0], but value was: 2.
        //     at com.strobel.core.VerifyArgument.inRange(VerifyArgument.java:347)
        //     at com.strobel.assembler.ir.StackMappingVisitor.getStackValue(StackMappingVisitor.java:67)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:691)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @NotNull
    public EntityOtherPlayerMP c(@NotNull final String p0, final int p1, final boolean p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          406
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            398
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            390
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: new             Lnet/minecraft/client/entity/EntityOtherPlayerMP;
        //    29: dup            
        //    30: getstatic       dev/nuker/pyro/fc.c:I
        //    33: ifne            41
        //    36: ldc             1907727881
        //    38: goto            43
        //    41: ldc             1630162143
        //    43: ldc             -352911097
        //    45: ixor           
        //    46: lookupswitch {
        //          -1690132722: 375
        //          -500065182: 41
        //          default: 72
        //        }
        //    72: goto            76
        //    75: athrow         
        //    76: invokestatic    net/minecraft/client/Minecraft.func_71410_x:()Lnet/minecraft/client/Minecraft;
        //    79: goto            83
        //    82: athrow         
        //    83: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //    86: checkcast       Lnet/minecraft/world/World;
        //    89: new             Lcom/mojang/authlib/GameProfile;
        //    92: dup            
        //    93: aconst_null    
        //    94: getstatic       dev/nuker/pyro/fc.c:I
        //    97: ifne            105
        //   100: ldc             983912655
        //   102: goto            107
        //   105: ldc             -931367226
        //   107: ldc             1816349800
        //   109: ixor           
        //   110: lookupswitch {
        //          -1539360082: 136
        //          1457921191: 105
        //          default: 373
        //        }
        //   136: aload_1        
        //   137: goto            141
        //   140: athrow         
        //   141: invokespecial   com/mojang/authlib/GameProfile.<init>:(Ljava/util/UUID;Ljava/lang/String;)V
        //   144: goto            148
        //   147: athrow         
        //   148: goto            152
        //   151: athrow         
        //   152: invokespecial   net/minecraft/client/entity/EntityOtherPlayerMP.<init>:(Lnet/minecraft/world/World;Lcom/mojang/authlib/GameProfile;)V
        //   155: goto            159
        //   158: athrow         
        //   159: astore          4
        //   161: goto            165
        //   164: athrow         
        //   165: invokestatic    net/minecraft/client/Minecraft.func_71410_x:()Lnet/minecraft/client/Minecraft;
        //   168: goto            172
        //   171: athrow         
        //   172: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //   175: iload_2        
        //   176: aload           4
        //   178: checkcast       Lnet/minecraft/entity/Entity;
        //   181: goto            185
        //   184: athrow         
        //   185: invokevirtual   net/minecraft/client/multiplayer/WorldClient.func_73027_a:(ILnet/minecraft/entity/Entity;)V
        //   188: goto            192
        //   191: athrow         
        //   192: getstatic       dev/nuker/pyro/fe4.c:Ljava/util/List;
        //   195: aload           4
        //   197: getstatic       dev/nuker/pyro/fc.c:I
        //   200: ifne            208
        //   203: ldc             558690990
        //   205: goto            210
        //   208: ldc             -1037785285
        //   210: ldc_w           497227224
        //   213: ixor           
        //   214: lookupswitch {
        //          -544754973: 240
        //          1022355318: 208
        //          default: 379
        //        }
        //   240: goto            244
        //   243: athrow         
        //   244: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //   249: goto            253
        //   252: athrow         
        //   253: pop            
        //   254: iload_3        
        //   255: ifeq            368
        //   258: getstatic       dev/nuker/pyro/fc.0:I
        //   261: ifgt            270
        //   264: ldc_w           1234840000
        //   267: goto            273
        //   270: ldc_w           -1586118928
        //   273: ldc_w           1540567825
        //   276: ixor           
        //   277: lookupswitch {
        //          -89747999: 304
        //          306780881: 270
        //          default: 377
        //        }
        //   304: getstatic       dev/nuker/pyro/fe4.0:Ljava/util/List;
        //   307: getstatic       dev/nuker/pyro/fc.1:I
        //   310: ifne            319
        //   313: ldc_w           -472147271
        //   316: goto            322
        //   319: ldc_w           -1210983268
        //   322: ldc_w           1334448313
        //   325: ixor           
        //   326: lookupswitch {
        //          -1403942400: 319
        //          -128201691: 352
        //          default: 371
        //        }
        //   352: aload           4
        //   354: goto            358
        //   357: athrow         
        //   358: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //   363: goto            367
        //   366: athrow         
        //   367: pop            
        //   368: aload           4
        //   370: areturn        
        //   371: aconst_null    
        //   372: athrow         
        //   373: aconst_null    
        //   374: athrow         
        //   375: aconst_null    
        //   376: athrow         
        //   377: aconst_null    
        //   378: athrow         
        //   379: aconst_null    
        //   380: athrow         
        //   381: pop            
        //   382: goto            24
        //   385: pop            
        //   386: aconst_null    
        //   387: goto            381
        //   390: dup            
        //   391: ifnull          381
        //   394: checkcast       Ljava/lang/Throwable;
        //   397: athrow         
        //   398: dup            
        //   399: ifnull          385
        //   402: checkcast       Ljava/lang/Throwable;
        //   405: athrow         
        //   406: aconst_null    
        //   407: athrow         
        //    StackMapTable: 00 3A 43 07 00 4D 04 FF 00 0B 00 00 00 01 07 00 4D FF 00 03 00 04 07 00 03 07 01 08 01 01 00 00 FF 00 10 00 04 07 00 03 07 01 08 01 01 00 02 08 00 1A 08 00 1A FF 00 01 00 04 07 00 03 07 01 08 01 01 00 03 08 00 1A 08 00 1A 01 FF 00 1C 00 04 07 00 03 07 01 08 01 01 00 02 08 00 1A 08 00 1A FF 00 02 00 00 00 01 07 00 4D FF 00 00 00 04 07 00 03 07 01 08 01 01 00 02 08 00 1A 08 00 1A 45 07 00 4D FF 00 00 00 04 07 00 03 07 01 08 01 01 00 03 08 00 1A 08 00 1A 07 00 52 FF 00 15 00 04 07 00 03 07 01 08 01 01 00 06 08 00 1A 08 00 1A 07 00 F1 08 00 59 08 00 59 05 FF 00 01 00 04 07 00 03 07 01 08 01 01 00 07 08 00 1A 08 00 1A 07 00 F1 08 00 59 08 00 59 05 01 FF 00 1C 00 04 07 00 03 07 01 08 01 01 00 06 08 00 1A 08 00 1A 07 00 F1 08 00 59 08 00 59 05 43 07 00 4D FF 00 00 00 04 07 00 03 07 01 08 01 01 00 07 08 00 1A 08 00 1A 07 00 F1 08 00 59 08 00 59 05 07 01 08 45 07 00 4D FF 00 00 00 04 07 00 03 07 01 08 01 01 00 04 08 00 1A 08 00 1A 07 00 F1 07 00 F3 FF 00 02 00 00 00 01 07 00 4D FF 00 00 00 04 07 00 03 07 01 08 01 01 00 04 08 00 1A 08 00 1A 07 00 F1 07 00 F3 45 07 00 4D 40 07 00 6A FF 00 04 00 05 07 00 03 07 01 08 01 01 07 00 6A 00 01 07 00 89 00 45 07 00 4D 40 07 00 52 4B 07 00 43 FF 00 00 00 05 07 00 03 07 01 08 01 01 07 00 6A 00 03 07 00 73 01 07 00 86 45 07 00 4D 00 FF 00 0F 00 05 07 00 03 07 01 08 01 01 07 00 6A 00 02 07 00 29 07 00 6A FF 00 01 00 05 07 00 03 07 01 08 01 01 07 00 6A 00 03 07 00 29 07 00 6A 01 FF 00 1D 00 05 07 00 03 07 01 08 01 01 07 00 6A 00 02 07 00 29 07 00 6A FF 00 02 00 00 00 01 07 00 4D FF 00 00 00 05 07 00 03 07 01 08 01 01 07 00 6A 00 02 07 00 29 07 00 6A 47 07 00 4D 40 01 10 42 01 1E 4E 07 00 29 FF 00 02 00 05 07 00 03 07 01 08 01 01 07 00 6A 00 02 07 00 29 01 5D 07 00 29 44 07 00 4D FF 00 00 00 05 07 00 03 07 01 08 01 01 07 00 6A 00 02 07 00 29 07 00 6A 47 07 00 4D 40 01 00 42 07 00 29 FF 00 01 00 04 07 00 03 07 01 08 01 01 00 06 08 00 1A 08 00 1A 07 00 F1 08 00 59 08 00 59 05 FF 00 01 00 04 07 00 03 07 01 08 01 01 00 02 08 00 1A 08 00 1A FC 00 01 07 00 6A FF 00 01 00 05 07 00 03 07 01 08 01 01 07 00 6A 00 02 07 00 29 07 00 6A FF 00 01 00 04 07 00 03 07 01 08 01 01 00 01 07 00 4D 43 05 44 07 00 4D 47 05 47 07 00 4D
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     390    398    Any
        //  390    398    390    398    Any
        //  406    408    3      8      Ljava/util/ConcurrentModificationException;
        //  76     82     82     83     Any
        //  76     82     3      8      Ljava/lang/NumberFormatException;
        //  76     82     3      8      Any
        //  76     82     3      8      Any
        //  76     82     82     83     Ljava/util/ConcurrentModificationException;
        //  140    147    147    148    Any
        //  141    147    140    141    Any
        //  140    147    147    148    Any
        //  140    147    3      8      Any
        //  140    147    147    148    Ljava/lang/NegativeArraySizeException;
        //  152    158    158    159    Any
        //  152    158    158    159    Ljava/lang/ArithmeticException;
        //  152    158    3      8      Any
        //  152    158    3      8      Any
        //  152    158    3      8      Any
        //  164    171    171    172    Any
        //  165    171    3      8      Any
        //  164    171    3      8      Ljava/util/NoSuchElementException;
        //  165    171    164    165    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  165    171    3      8      Ljava/util/NoSuchElementException;
        //  184    191    191    192    Any
        //  184    191    3      8      Any
        //  184    191    184    185    Ljava/util/NoSuchElementException;
        //  184    191    191    192    Ljava/lang/IllegalStateException;
        //  185    191    191    192    Any
        //  244    252    252    253    Any
        //  244    252    3      8      Any
        //  244    252    3      8      Ljava/util/NoSuchElementException;
        //  244    252    3      8      Ljava/lang/AssertionError;
        //  244    252    252    253    Ljava/lang/IllegalArgumentException;
        //  357    366    366    367    Any
        //  357    366    3      8      Ljava/lang/IllegalStateException;
        //  358    366    366    367    Any
        //  358    366    357    358    Any
        //  357    366    357    358    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalArgumentException: Argument 'offset' must be in the range [0, 0], but value was: 2.
        //     at com.strobel.core.VerifyArgument.inRange(VerifyArgument.java:347)
        //     at com.strobel.assembler.ir.StackMappingVisitor.getStackValue(StackMappingVisitor.java:67)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:691)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @NotNull
    public EntityOtherPlayerMP 0(@NotNull final EntityPlayer p0, final int p1, final boolean p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          525
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            517
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            509
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: new             Lnet/minecraft/client/entity/EntityOtherPlayerMP;
        //    29: dup            
        //    30: aload_1        
        //    31: getfield        net/minecraft/entity/player/EntityPlayer.field_70170_p:Lnet/minecraft/world/World;
        //    34: getstatic       dev/nuker/pyro/fc.1:I
        //    37: ifne            46
        //    40: ldc_w           -1331816720
        //    43: goto            49
        //    46: ldc_w           -1953602373
        //    49: ldc_w           24718902
        //    52: ixor           
        //    53: lookupswitch {
        //          -1963505011: 80
        //          -1310246714: 46
        //          default: 494
        //        }
        //    80: aload_1        
        //    81: goto            85
        //    84: athrow         
        //    85: invokevirtual   net/minecraft/entity/player/EntityPlayer.func_146103_bH:()Lcom/mojang/authlib/GameProfile;
        //    88: goto            92
        //    91: athrow         
        //    92: goto            96
        //    95: athrow         
        //    96: invokespecial   net/minecraft/client/entity/EntityOtherPlayerMP.<init>:(Lnet/minecraft/world/World;Lcom/mojang/authlib/GameProfile;)V
        //    99: goto            103
        //   102: athrow         
        //   103: astore          4
        //   105: aload           4
        //   107: aload_1        
        //   108: checkcast       Lnet/minecraft/entity/Entity;
        //   111: goto            115
        //   114: athrow         
        //   115: invokevirtual   net/minecraft/client/entity/EntityOtherPlayerMP.func_82149_j:(Lnet/minecraft/entity/Entity;)V
        //   118: goto            122
        //   121: athrow         
        //   122: aload           4
        //   124: aload_1        
        //   125: getfield        net/minecraft/entity/player/EntityPlayer.field_70177_z:F
        //   128: putfield        net/minecraft/client/entity/EntityOtherPlayerMP.field_70177_z:F
        //   131: getstatic       dev/nuker/pyro/fc.0:I
        //   134: ifgt            143
        //   137: ldc_w           1027120731
        //   140: goto            146
        //   143: ldc_w           829883015
        //   146: ldc_w           -422125177
        //   149: ixor           
        //   150: lookupswitch {
        //          -605126692: 490
        //          1959296492: 143
        //          default: 176
        //        }
        //   176: aload           4
        //   178: getstatic       dev/nuker/pyro/fc.0:I
        //   181: ifgt            190
        //   184: ldc_w           722991960
        //   187: goto            193
        //   190: ldc_w           -144168959
        //   193: ldc_w           -1433068838
        //   196: ixor           
        //   197: lookupswitch {
        //          -2122129022: 190
        //          1576874715: 224
        //          default: 496
        //        }
        //   224: aload_1        
        //   225: getfield        net/minecraft/entity/player/EntityPlayer.field_70759_as:F
        //   228: getstatic       dev/nuker/pyro/fc.0:I
        //   231: ifgt            240
        //   234: ldc_w           -1192541243
        //   237: goto            243
        //   240: ldc_w           -1138368991
        //   243: ldc_w           1257185976
        //   246: ixor           
        //   247: lookupswitch {
        //          -234593923: 240
        //          -154469223: 272
        //          default: 492
        //        }
        //   272: putfield        net/minecraft/client/entity/EntityOtherPlayerMP.field_70759_as:F
        //   275: goto            279
        //   278: athrow         
        //   279: invokestatic    net/minecraft/client/Minecraft.func_71410_x:()Lnet/minecraft/client/Minecraft;
        //   282: goto            286
        //   285: athrow         
        //   286: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //   289: iload_2        
        //   290: aload           4
        //   292: checkcast       Lnet/minecraft/entity/Entity;
        //   295: goto            299
        //   298: athrow         
        //   299: invokevirtual   net/minecraft/client/multiplayer/WorldClient.func_73027_a:(ILnet/minecraft/entity/Entity;)V
        //   302: goto            306
        //   305: athrow         
        //   306: getstatic       dev/nuker/pyro/fc.0:I
        //   309: ifgt            318
        //   312: ldc_w           1849831332
        //   315: goto            321
        //   318: ldc_w           388903754
        //   321: ldc_w           -1784542451
        //   324: ixor           
        //   325: lookupswitch {
        //          -2104739769: 352
        //          -69196631: 318
        //          default: 498
        //        }
        //   352: getstatic       dev/nuker/pyro/fe4.c:Ljava/util/List;
        //   355: getstatic       dev/nuker/pyro/fc.0:I
        //   358: ifgt            367
        //   361: ldc_w           -210934811
        //   364: goto            370
        //   367: ldc_w           1751190966
        //   370: ldc_w           -1223747114
        //   373: ixor           
        //   374: lookupswitch {
        //          1147304499: 488
        //          2120046056: 367
        //          default: 400
        //        }
        //   400: aload           4
        //   402: goto            406
        //   405: athrow         
        //   406: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //   411: goto            415
        //   414: athrow         
        //   415: pop            
        //   416: getstatic       dev/nuker/pyro/fc.1:I
        //   419: ifne            428
        //   422: ldc_w           2057496071
        //   425: goto            431
        //   428: ldc_w           -609977298
        //   431: ldc_w           -1033257045
        //   434: ixor           
        //   435: lookupswitch {
        //          -1194632788: 428
        //          432915333: 460
        //          default: 486
        //        }
        //   460: iload_3        
        //   461: ifeq            483
        //   464: getstatic       dev/nuker/pyro/fe4.0:Ljava/util/List;
        //   467: aload           4
        //   469: goto            473
        //   472: athrow         
        //   473: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //   478: goto            482
        //   481: athrow         
        //   482: pop            
        //   483: aload           4
        //   485: areturn        
        //   486: aconst_null    
        //   487: athrow         
        //   488: aconst_null    
        //   489: athrow         
        //   490: aconst_null    
        //   491: athrow         
        //   492: aconst_null    
        //   493: athrow         
        //   494: aconst_null    
        //   495: athrow         
        //   496: aconst_null    
        //   497: athrow         
        //   498: aconst_null    
        //   499: athrow         
        //   500: pop            
        //   501: goto            24
        //   504: pop            
        //   505: aconst_null    
        //   506: goto            500
        //   509: dup            
        //   510: ifnull          500
        //   513: checkcast       Ljava/lang/Throwable;
        //   516: athrow         
        //   517: dup            
        //   518: ifnull          504
        //   521: checkcast       Ljava/lang/Throwable;
        //   524: athrow         
        //   525: aconst_null    
        //   526: athrow         
        //    StackMapTable: 00 42 43 07 00 4D 04 FF 00 0B 00 00 00 01 07 00 4D FF 00 03 00 04 07 00 03 07 00 98 01 01 00 00 FF 00 15 00 04 07 00 03 07 00 98 01 01 00 03 08 00 1A 08 00 1A 07 00 F1 FF 00 02 00 04 07 00 03 07 00 98 01 01 00 04 08 00 1A 08 00 1A 07 00 F1 01 FF 00 1E 00 04 07 00 03 07 00 98 01 01 00 03 08 00 1A 08 00 1A 07 00 F1 43 07 00 4D FF 00 00 00 04 07 00 03 07 00 98 01 01 00 04 08 00 1A 08 00 1A 07 00 F1 07 00 98 45 07 00 4D FF 00 00 00 04 07 00 03 07 00 98 01 01 00 04 08 00 1A 08 00 1A 07 00 F1 07 00 F3 42 07 00 45 FF 00 00 00 04 07 00 03 07 00 98 01 01 00 04 08 00 1A 08 00 1A 07 00 F1 07 00 F3 45 07 00 4D 40 07 00 6A FF 00 0A 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 01 07 00 4B FF 00 00 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 02 07 00 6A 07 00 86 45 07 00 4D 00 14 42 01 1D 4D 07 00 6A FF 00 02 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 02 07 00 6A 01 5E 07 00 6A FF 00 0F 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 02 07 00 6A 02 FF 00 02 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 03 07 00 6A 02 01 FF 00 1C 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 02 07 00 6A 02 45 07 00 4D 00 45 07 00 4D 40 07 00 52 4B 07 00 47 FF 00 00 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 03 07 00 73 01 07 00 86 45 07 00 4D 00 0B 42 01 1E 4E 07 00 29 FF 00 02 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 02 07 00 29 01 5D 07 00 29 FF 00 04 00 00 00 01 07 00 4D FF 00 00 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 02 07 00 29 07 00 6A 47 07 00 4D 40 01 0C 42 01 1C 4B 07 00 4D FF 00 00 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 02 07 00 29 07 00 6A 47 07 00 4D 40 01 00 02 41 07 00 29 01 FF 00 01 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 02 07 00 6A 02 FF 00 01 00 04 07 00 03 07 00 98 01 01 00 03 08 00 1A 08 00 1A 07 00 F1 FF 00 01 00 05 07 00 03 07 00 98 01 01 07 00 6A 00 01 07 00 6A 01 FF 00 01 00 04 07 00 03 07 00 98 01 01 00 01 07 00 4D 43 05 44 07 00 4D 47 05 47 07 00 4D
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                     
        //  -----  -----  -----  -----  -----------------------------------------
        //  8      20     509    517    Ljava/lang/AssertionError;
        //  509    517    509    517    Any
        //  525    527    3      8      Any
        //  84     91     91     92     Any
        //  84     91     91     92     Ljava/lang/ArithmeticException;
        //  85     91     91     92     Any
        //  84     91     84     85     Any
        //  85     91     84     85     Ljava/lang/NumberFormatException;
        //  95     102    102    103    Any
        //  96     102    95     96     Ljava/lang/IndexOutOfBoundsException;
        //  95     102    102    103    Any
        //  95     102    3      8      Any
        //  95     102    102    103    Any
        //  114    121    121    122    Any
        //  114    121    3      8      Any
        //  114    121    121    122    Ljava/lang/AssertionError;
        //  115    121    114    115    Ljava/lang/IllegalArgumentException;
        //  115    121    3      8      Any
        //  278    285    285    286    Any
        //  278    285    278    279    Ljava/lang/AssertionError;
        //  278    285    278    279    Ljava/lang/RuntimeException;
        //  279    285    278    279    Any
        //  279    285    3      8      Ljava/util/NoSuchElementException;
        //  298    305    305    306    Any
        //  299    305    305    306    Any
        //  298    305    298    299    Ljava/lang/NullPointerException;
        //  299    305    3      8      Any
        //  299    305    305    306    Ljava/lang/UnsupportedOperationException;
        //  406    414    414    415    Any
        //  406    414    414    415    Ljava/lang/IndexOutOfBoundsException;
        //  406    414    3      8      Any
        //  406    414    414    415    Any
        //  406    414    414    415    Ljava/lang/RuntimeException;
        //  472    481    481    482    Any
        //  473    481    472    473    Any
        //  473    481    481    482    Ljava/lang/NumberFormatException;
        //  473    481    472    473    Ljava/lang/NumberFormatException;
        //  473    481    481    482    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visitVariable(StackMappingVisitor.java:470)
        //     at com.strobel.assembler.ir.Instruction.accept(Instruction.java:556)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:403)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
