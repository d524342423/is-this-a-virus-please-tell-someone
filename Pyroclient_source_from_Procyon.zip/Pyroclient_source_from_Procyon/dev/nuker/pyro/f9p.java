// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import net.minecraft.client.entity.EntityPlayerSP;
import dev.nuker.pyro.security.inject.LauncherEventHide;

public class f9p extends fQ
{
    public f0k c;
    public f0o<f9o> c;
    public f0m c;
    public f0k 0;
    public f0k 1;
    public f0m 0;
    public f0m 1;
    public f0k 2;
    public f0k 3;
    public int 1;
    
    @f0g
    @LauncherEventHide
    public void c(final f49 f49) {
        fez.3I(this, 175722142, f49);
    }
    
    @f0g
    @LauncherEventHide
    public void c(final f4t f4t) {
        fez.jK(this, 263981914, f4t);
    }
    
    @Override
    public void c(final boolean p0, @Nullable final EntityPlayerSP p1, @Nullable final World p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          287
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            279
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            271
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_0        
        //    25: iload_1        
        //    26: aload_2        
        //    27: aload_3        
        //    28: goto            32
        //    31: athrow         
        //    32: invokespecial   dev/nuker/pyro/fQ.c:(ZLnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/world/World;)V
        //    35: goto            39
        //    38: athrow         
        //    39: aload_0        
        //    40: getstatic       dev/nuker/pyro/fc.1:I
        //    43: ifne            51
        //    46: ldc             -350869034
        //    48: goto            53
        //    51: ldc             2011729755
        //    53: ldc             -602733176
        //    55: ixor           
        //    56: lookupswitch {
        //          -1409578285: 84
        //          923085918: 51
        //          default: 258
        //        }
        //    84: aload_0        
        //    85: getfield        dev/nuker/pyro/f9p.c:Ldev/nuker/pyro/f0o;
        //    88: goto            92
        //    91: athrow         
        //    92: invokevirtual   dev/nuker/pyro/f0o.c:()Ljava/lang/Object;
        //    95: goto            99
        //    98: athrow         
        //    99: goto            103
        //   102: athrow         
        //   103: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   106: goto            110
        //   109: athrow         
        //   110: goto            114
        //   113: athrow         
        //   114: invokevirtual   dev/nuker/pyro/f9p.5:(Ljava/lang/String;)V
        //   117: goto            121
        //   120: athrow         
        //   121: getstatic       dev/nuker/pyro/fc.0:I
        //   124: ifgt            132
        //   127: ldc             714544460
        //   129: goto            134
        //   132: ldc             2087315286
        //   134: ldc             -161512025
        //   136: ixor           
        //   137: lookupswitch {
        //          -1976147215: 164
        //          -590835477: 132
        //          default: 256
        //        }
        //   164: aload_0        
        //   165: getfield        dev/nuker/pyro/f9p.c:Ldev/nuker/pyro/f0k;
        //   168: goto            172
        //   171: athrow         
        //   172: invokevirtual   dev/nuker/pyro/f0k.c:()Ljava/lang/Object;
        //   175: goto            179
        //   178: athrow         
        //   179: checkcast       Ljava/lang/Boolean;
        //   182: goto            186
        //   185: athrow         
        //   186: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   189: goto            193
        //   192: athrow         
        //   193: ifeq            255
        //   196: iload_1        
        //   197: ifeq            255
        //   200: getstatic       dev/nuker/pyro/fc.0:I
        //   203: ifgt            211
        //   206: ldc             232458359
        //   208: goto            213
        //   211: ldc             -295536681
        //   213: ldc             -1357368113
        //   215: ixor           
        //   216: lookupswitch {
        //          -1601587575: 211
        //          -1564263240: 260
        //          default: 244
        //        }
        //   244: goto            248
        //   247: athrow         
        //   248: invokestatic    dev/nuker/pyro/fec.b:()V
        //   251: goto            255
        //   254: athrow         
        //   255: return         
        //   256: aconst_null    
        //   257: athrow         
        //   258: aconst_null    
        //   259: athrow         
        //   260: aconst_null    
        //   261: athrow         
        //   262: pop            
        //   263: goto            24
        //   266: pop            
        //   267: aconst_null    
        //   268: goto            262
        //   271: dup            
        //   272: ifnull          262
        //   275: checkcast       Ljava/lang/Throwable;
        //   278: athrow         
        //   279: dup            
        //   280: ifnull          266
        //   283: checkcast       Ljava/lang/Throwable;
        //   286: athrow         
        //   287: aconst_null    
        //   288: athrow         
        //    RuntimeInvisibleTypeAnnotations: 00 02 16 01 00 00 21 00 00 16 02 00 00 21 00 00
        //    StackMapTable: 00 31 43 07 00 3D 04 FF 00 0B 00 00 00 01 07 00 3D FF 00 03 00 04 07 00 03 01 07 00 6E 07 00 70 00 00 46 07 00 72 FF 00 00 00 04 07 00 03 01 07 00 6E 07 00 70 00 04 07 00 03 01 07 00 6E 07 00 70 45 07 00 3D 00 4B 07 00 03 FF 00 01 00 04 07 00 03 01 07 00 6E 07 00 70 00 02 07 00 03 01 5E 07 00 03 46 07 00 3D FF 00 00 00 04 07 00 03 01 07 00 6E 07 00 70 00 02 07 00 03 07 00 48 45 07 00 3D FF 00 00 00 04 07 00 03 01 07 00 6E 07 00 70 00 02 07 00 03 07 00 74 FF 00 02 00 00 00 01 07 00 3D FF 00 00 00 04 07 00 03 01 07 00 6E 07 00 70 00 02 07 00 03 07 00 74 45 07 00 3D FF 00 00 00 04 07 00 03 01 07 00 6E 07 00 70 00 02 07 00 03 07 00 4D 42 07 00 2D FF 00 00 00 04 07 00 03 01 07 00 6E 07 00 70 00 02 07 00 03 07 00 4D 45 07 00 3D 00 0A 41 01 1D 46 07 00 31 40 07 00 5C 45 07 00 3D 40 07 00 74 45 07 00 3D 40 07 00 5F 45 07 00 3D 40 01 11 41 01 1E 42 07 00 3D 00 45 07 00 3D 00 00 41 07 00 03 01 41 07 00 3D 43 05 44 07 00 3D 47 05 47 07 00 3D
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     271    279    Any
        //  271    279    271    279    Ljava/lang/EnumConstantNotPresentException;
        //  287    289    3      8      Ljava/lang/AssertionError;
        //  31     38     38     39     Any
        //  31     38     31     32     Ljava/lang/EnumConstantNotPresentException;
        //  32     38     38     39     Any
        //  31     38     31     32     Ljava/lang/StringIndexOutOfBoundsException;
        //  32     38     38     39     Ljava/lang/ClassCastException;
        //  91     98     98     99     Any
        //  91     98     91     92     Any
        //  92     98     3      8      Any
        //  92     98     91     92     Ljava/lang/AssertionError;
        //  91     98     3      8      Any
        //  103    109    109    110    Any
        //  103    109    109    110    Any
        //  103    109    109    110    Any
        //  103    109    109    110    Ljava/lang/UnsupportedOperationException;
        //  103    109    109    110    Any
        //  113    120    120    121    Any
        //  113    120    113    114    Ljava/lang/NullPointerException;
        //  114    120    120    121    Any
        //  113    120    3      8      Ljava/lang/ArithmeticException;
        //  113    120    3      8      Any
        //  171    178    178    179    Any
        //  171    178    178    179    Ljava/lang/NullPointerException;
        //  171    178    3      8      Ljava/lang/AssertionError;
        //  171    178    171    172    Ljava/lang/NumberFormatException;
        //  171    178    178    179    Any
        //  185    192    192    193    Any
        //  185    192    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  186    192    185    186    Any
        //  185    192    185    186    Ljava/lang/NegativeArraySizeException;
        //  185    192    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  247    254    254    255    Any
        //  247    254    254    255    Any
        //  247    254    254    255    Any
        //  247    254    254    255    Ljava/lang/IllegalArgumentException;
        //  248    254    247    248    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:595)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void c(final f0w f0w) {
        fez.ar(this, 900124826, f0w);
    }
    
    @f0g(1337)
    @LauncherEventHide
    public void c(final f4u f4u) {
        fez.io(this, 363216737, f4u);
    }
    
    public int c(final int n) {
        return fez.52(this, 1703851098, n);
    }
    
    static {
        throw t;
    }
    
    public f9p() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: ifne            11
        //     6: ldc             1820218485
        //     8: goto            13
        //    11: ldc             -571767353
        //    13: ldc             659689070
        //    15: ixor           
        //    16: lookupswitch {
        //          -206892392: 11
        //          1261197851: 1338
        //          default: 44
        //        }
        //    44: aload_0        
        //    45: ldc             "\u3cd8\ub249\u8f9d\uada3\u67c5\u582f"
        //    47: invokestatic    invokestatic   !!! ERROR
        //    50: ldc             "\u3cf8\ub249\u8f9d\uada3\u67c5\u582f"
        //    52: invokestatic    invokestatic   !!! ERROR
        //    55: ldc             "\u3cff\ub249\u8f98\uadab\u67da\u5828\u7e00\u689a\uc2cc\ua33e\u9a27\u1310\uc0ed\u714e\u901a\u4c3f\ub208"
        //    57: invokestatic    invokestatic   !!! ERROR
        //    60: invokespecial   dev/nuker/pyro/fQ.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //    63: aload_0        
        //    64: new             Ldev/nuker/pyro/f0k;
        //    67: dup            
        //    68: ldc             "\u3cda\ub244\u8f99\uada5\u67ca\u583e"
        //    70: invokestatic    invokestatic   !!! ERROR
        //    73: ldc             "\u3cfa\ub244\u8f99\uada5\u67ca\u583e"
        //    75: invokestatic    invokestatic   !!! ERROR
        //    78: aconst_null    
        //    79: iconst_0       
        //    80: getstatic       dev/nuker/pyro/fc.c:I
        //    83: ifne            91
        //    86: ldc             708150430
        //    88: goto            93
        //    91: ldc             591020260
        //    93: ldc             1941649272
        //    95: ixor           
        //    96: lookupswitch {
        //          170035202: 91
        //          1502524390: 1314
        //          default: 124
        //        }
        //   124: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   127: putfield        dev/nuker/pyro/f9p.c:Ldev/nuker/pyro/f0k;
        //   130: aload_0        
        //   131: new             Ldev/nuker/pyro/f0o;
        //   134: dup            
        //   135: ldc             "\u3cd3\ub24a\u8f90\uada1"
        //   137: invokestatic    invokestatic   !!! ERROR
        //   140: ldc             "\u3cf3\ub24a\u8f90\uada1"
        //   142: getstatic       dev/nuker/pyro/fc.c:I
        //   145: ifne            153
        //   148: ldc             1853194955
        //   150: goto            155
        //   153: ldc             -495426715
        //   155: ldc             -2070442970
        //   157: ixor           
        //   158: lookupswitch {
        //          -354283795: 153
        //          1727000387: 184
        //          default: 1350
        //        }
        //   184: invokestatic    invokestatic   !!! ERROR
        //   187: aconst_null    
        //   188: getstatic       dev/nuker/pyro/f9o.0:Ldev/nuker/pyro/f9o;
        //   191: invokespecial   dev/nuker/pyro/f0o.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Enum;)V
        //   194: putfield        dev/nuker/pyro/f9p.c:Ldev/nuker/pyro/f0o;
        //   197: aload_0        
        //   198: new             Ldev/nuker/pyro/f0m;
        //   201: dup            
        //   202: ldc             "\u3cd9\ub249\u8f9d\uada0\u67c8\u5808\u7e50\u6886\uc2c6\ua32f"
        //   204: getstatic       dev/nuker/pyro/fc.c:I
        //   207: ifne            215
        //   210: ldc             -1660306762
        //   212: goto            217
        //   215: ldc             -882051514
        //   217: ldc             701817288
        //   219: ixor           
        //   220: lookupswitch {
        //          -1260561538: 1322
        //          877005840: 215
        //          default: 248
        //        }
        //   248: invokestatic    invokestatic   !!! ERROR
        //   251: ldc             "\u3cf9\ub249\u8f9d\uada0\u67c8\u5808\u7e50\u6886\uc2c6\ua32f"
        //   253: invokestatic    invokestatic   !!! ERROR
        //   256: aconst_null    
        //   257: dconst_1       
        //   258: dconst_0       
        //   259: ldc2_w          10.0
        //   262: getstatic       dev/nuker/pyro/fc.1:I
        //   265: ifne            273
        //   268: ldc             528457032
        //   270: goto            275
        //   273: ldc             971944646
        //   275: ldc             -1206999792
        //   277: ixor           
        //   278: lookupswitch {
        //          -2116020266: 304
        //          -1485752232: 273
        //          default: 1316
        //        }
        //   304: invokespecial   dev/nuker/pyro/f0m.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;DDD)V
        //   307: putfield        dev/nuker/pyro/f9p.c:Ldev/nuker/pyro/f0m;
        //   310: getstatic       dev/nuker/pyro/fc.c:I
        //   313: ifne            321
        //   316: ldc             -1050511056
        //   318: goto            323
        //   321: ldc             1288358931
        //   323: ldc             256954434
        //   325: ixor           
        //   326: lookupswitch {
        //          -835540622: 321
        //          1134173265: 352
        //          default: 1344
        //        }
        //   352: aload_0        
        //   353: new             Ldev/nuker/pyro/f0k;
        //   356: dup            
        //   357: ldc             "\u3cdf\ub24b\u8f9d\uada9\u67cc\u582f\u7e49\u688c\uc2cd"
        //   359: invokestatic    invokestatic   !!! ERROR
        //   362: ldc             "\u3cff\ub24b\u8f9d\uada9\u67cc\u582f\u7e49\u688c\uc2cd"
        //   364: invokestatic    invokestatic   !!! ERROR
        //   367: aconst_null    
        //   368: iconst_1       
        //   369: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   372: putfield        dev/nuker/pyro/f9p.0:Ldev/nuker/pyro/f0k;
        //   375: aload_0        
        //   376: new             Ldev/nuker/pyro/f0k;
        //   379: dup            
        //   380: ldc             "\u3cd9\ub249\u8f9d\uada0\u67c8"
        //   382: getstatic       dev/nuker/pyro/fc.c:I
        //   385: ifne            393
        //   388: ldc             165891740
        //   390: goto            395
        //   393: ldc             -598437215
        //   395: ldc             1992043965
        //   397: ixor           
        //   398: lookupswitch {
        //          -1427587300: 424
        //          2136957729: 393
        //          default: 1352
        //        }
        //   424: invokestatic    invokestatic   !!! ERROR
        //   427: ldc             "\u3cf9\ub249\u8f9d\uada0\u67c8"
        //   429: invokestatic    invokestatic   !!! ERROR
        //   432: aconst_null    
        //   433: iconst_0       
        //   434: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   437: putfield        dev/nuker/pyro/f9p.1:Ldev/nuker/pyro/f0k;
        //   440: aload_0        
        //   441: new             Ldev/nuker/pyro/f0m;
        //   444: dup            
        //   445: ldc             "\u3ccd\ub255\u8f91\uada1\u67c9"
        //   447: invokestatic    invokestatic   !!! ERROR
        //   450: ldc             "\u3ced\ub255\u8f91\uada1\u67c9"
        //   452: getstatic       dev/nuker/pyro/fc.c:I
        //   455: ifne            463
        //   458: ldc             713861127
        //   460: goto            465
        //   463: ldc             997539684
        //   465: ldc             265833025
        //   467: ixor           
        //   468: lookupswitch {
        //          626319942: 1342
        //          1550322841: 463
        //          default: 496
        //        }
        //   496: invokestatic    invokestatic   !!! ERROR
        //   499: aconst_null    
        //   500: ldc2_w          10.0
        //   503: dconst_0       
        //   504: ldc2_w          20.0
        //   507: getstatic       dev/nuker/pyro/fc.1:I
        //   510: ifne            518
        //   513: ldc             -1649387937
        //   515: goto            520
        //   518: ldc             -714233599
        //   520: ldc             -1701291065
        //   522: ixor           
        //   523: lookupswitch {
        //          120065432: 518
        //          1341518534: 548
        //          default: 1318
        //        }
        //   548: invokespecial   dev/nuker/pyro/f0m.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;DDD)V
        //   551: putfield        dev/nuker/pyro/f9p.0:Ldev/nuker/pyro/f0m;
        //   554: getstatic       dev/nuker/pyro/fc.0:I
        //   557: ifgt            565
        //   560: ldc             -1499331415
        //   562: goto            567
        //   565: ldc             1113637380
        //   567: ldc             -296477906
        //   569: ixor           
        //   570: lookupswitch {
        //          -1405822678: 596
        //          1224089479: 565
        //          default: 1340
        //        }
        //   596: aload_0        
        //   597: new             Ldev/nuker/pyro/f0m;
        //   600: dup            
        //   601: ldc             "\u3cdf\ub244\u8f97\uad9d"
        //   603: getstatic       dev/nuker/pyro/fc.c:I
        //   606: ifne            614
        //   609: ldc             -1711380051
        //   611: goto            616
        //   614: ldc             1033357762
        //   616: ldc             766334175
        //   618: ixor           
        //   619: lookupswitch {
        //          -1326179628: 614
        //          -1269613198: 1312
        //          default: 644
        //        }
        //   644: invokestatic    invokestatic   !!! ERROR
        //   647: ldc             "\u3cff\ub264\u8fb7\uad9d"
        //   649: invokestatic    invokestatic   !!! ERROR
        //   652: aconst_null    
        //   653: ldc2_w          0.83
        //   656: dconst_0       
        //   657: ldc2_w          10.0
        //   660: getstatic       dev/nuker/pyro/fc.1:I
        //   663: ifne            671
        //   666: ldc             -1331661061
        //   668: goto            673
        //   671: ldc             -1696266737
        //   673: ldc             267758589
        //   675: ixor           
        //   676: lookupswitch {
        //          -1084891898: 1328
        //          -575627999: 671
        //          default: 704
        //        }
        //   704: invokespecial   dev/nuker/pyro/f0m.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;DDD)V
        //   707: putfield        dev/nuker/pyro/f9p.1:Ldev/nuker/pyro/f0m;
        //   710: aload_0        
        //   711: new             Ldev/nuker/pyro/f0k;
        //   714: dup            
        //   715: ldc             "\u3cdf\ub24b\u8f80\uadad\u67eb\u583a\u7e4c\u688f\uc2e7\ua32a\u9a6a\u1305\uc0e5\u710b"
        //   717: invokestatic    invokestatic   !!! ERROR
        //   720: ldc             "\u3cff\ub24b\u8f80\uadad\u678d\u581d\u7e41\u688f\uc2cf\ua36b\u9a43\u1305\uc0ef\u710f\u901b\u4c36"
        //   722: getstatic       dev/nuker/pyro/fc.1:I
        //   725: ifne            734
        //   728: ldc_w           997556972
        //   731: goto            737
        //   734: ldc_w           1394510533
        //   737: ldc_w           -328927256
        //   740: ixor           
        //   741: lookupswitch {
        //          -1082491603: 768
        //          -686721788: 734
        //          default: 1354
        //        }
        //   768: invokestatic    invokestatic   !!! ERROR
        //   771: aconst_null    
        //   772: iconst_0       
        //   773: getstatic       dev/nuker/pyro/fc.1:I
        //   776: ifne            785
        //   779: ldc_w           1789953010
        //   782: goto            788
        //   785: ldc_w           -314649647
        //   788: ldc_w           1677606643
        //   791: ixor           
        //   792: lookupswitch {
        //          -1899959006: 820
        //          156155137: 785
        //          default: 1346
        //        }
        //   820: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   823: putfield        dev/nuker/pyro/f9p.2:Ldev/nuker/pyro/f0k;
        //   826: aload_0        
        //   827: new             Ldev/nuker/pyro/f0k;
        //   830: dup            
        //   831: ldc_w           "\u3cdf\ub24b\u8f80\uadad\u67e6\u5832\u7e43\u6888"
        //   834: invokestatic    invokestatic   !!! ERROR
        //   837: ldc_w           "\u3cff\ub24b\u8f80\uadad\u67e6\u5832\u7e43\u6888"
        //   840: invokestatic    invokestatic   !!! ERROR
        //   843: aconst_null    
        //   844: iconst_1       
        //   845: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   848: putfield        dev/nuker/pyro/f9p.3:Ldev/nuker/pyro/f0k;
        //   851: aload_0        
        //   852: aload_0        
        //   853: getfield        dev/nuker/pyro/f9p.c:Ldev/nuker/pyro/f0k;
        //   856: getstatic       dev/nuker/pyro/fc.1:I
        //   859: ifne            868
        //   862: ldc_w           710452655
        //   865: goto            871
        //   868: ldc_w           -1018072618
        //   871: ldc_w           207846627
        //   874: ixor           
        //   875: lookupswitch {
        //          -1064216583: 868
        //          641456460: 1330
        //          default: 900
        //        }
        //   900: invokevirtual   dev/nuker/pyro/f9p.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   903: pop            
        //   904: aload_0        
        //   905: aload_0        
        //   906: getfield        dev/nuker/pyro/f9p.c:Ldev/nuker/pyro/f0o;
        //   909: invokevirtual   dev/nuker/pyro/f9p.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   912: pop            
        //   913: aload_0        
        //   914: aload_0        
        //   915: getfield        dev/nuker/pyro/f9p.c:Ldev/nuker/pyro/f0m;
        //   918: invokevirtual   dev/nuker/pyro/f9p.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   921: pop            
        //   922: aload_0        
        //   923: aload_0        
        //   924: getfield        dev/nuker/pyro/f9p.0:Ldev/nuker/pyro/f0k;
        //   927: getstatic       dev/nuker/pyro/fc.1:I
        //   930: ifne            939
        //   933: ldc_w           -1258326020
        //   936: goto            942
        //   939: ldc_w           -802591844
        //   942: ldc_w           -1496407071
        //   945: ixor           
        //   946: lookupswitch {
        //          305255453: 1334
        //          619458086: 939
        //          default: 972
        //        }
        //   972: invokevirtual   dev/nuker/pyro/f9p.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   975: pop            
        //   976: aload_0        
        //   977: getstatic       dev/nuker/pyro/fc.c:I
        //   980: ifne            989
        //   983: ldc_w           -727329471
        //   986: goto            992
        //   989: ldc_w           -1145401870
        //   992: ldc_w           1419519976
        //   995: ixor           
        //   996: lookupswitch {
        //          -2143685975: 1336
        //          830132717: 989
        //          default: 1024
        //        }
        //  1024: aload_0        
        //  1025: getfield        dev/nuker/pyro/f9p.1:Ldev/nuker/pyro/f0k;
        //  1028: invokevirtual   dev/nuker/pyro/f9p.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //  1031: pop            
        //  1032: getstatic       dev/nuker/pyro/fc.1:I
        //  1035: ifne            1044
        //  1038: ldc_w           2101471831
        //  1041: goto            1047
        //  1044: ldc_w           -1208621619
        //  1047: ldc_w           1465115261
        //  1050: ixor           
        //  1051: lookupswitch {
        //          -1819040564: 1044
        //          705824810: 1326
        //          default: 1076
        //        }
        //  1076: aload_0        
        //  1077: getstatic       dev/nuker/pyro/fc.c:I
        //  1080: ifne            1089
        //  1083: ldc_w           259650505
        //  1086: goto            1092
        //  1089: ldc_w           -763431675
        //  1092: ldc_w           -17986937
        //  1095: ixor           
        //  1096: lookupswitch {
        //          -1679312639: 1089
        //          -241927858: 1332
        //          default: 1124
        //        }
        //  1124: aload_0        
        //  1125: getfield        dev/nuker/pyro/f9p.0:Ldev/nuker/pyro/f0m;
        //  1128: invokevirtual   dev/nuker/pyro/f9p.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //  1131: pop            
        //  1132: aload_0        
        //  1133: getstatic       dev/nuker/pyro/fc.c:I
        //  1136: ifne            1145
        //  1139: ldc_w           -693592921
        //  1142: goto            1148
        //  1145: ldc_w           -1863843677
        //  1148: ldc_w           896871037
        //  1151: ixor           
        //  1152: lookupswitch {
        //          -1516426530: 1180
        //          -472008998: 1145
        //          default: 1348
        //        }
        //  1180: aload_0        
        //  1181: getfield        dev/nuker/pyro/f9p.1:Ldev/nuker/pyro/f0m;
        //  1184: invokevirtual   dev/nuker/pyro/f9p.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //  1187: pop            
        //  1188: aload_0        
        //  1189: aload_0        
        //  1190: getfield        dev/nuker/pyro/f9p.2:Ldev/nuker/pyro/f0k;
        //  1193: invokevirtual   dev/nuker/pyro/f9p.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //  1196: pop            
        //  1197: aload_0        
        //  1198: aload_0        
        //  1199: getfield        dev/nuker/pyro/f9p.3:Ldev/nuker/pyro/f0k;
        //  1202: getstatic       dev/nuker/pyro/fc.1:I
        //  1205: ifne            1214
        //  1208: ldc_w           1944990591
        //  1211: goto            1217
        //  1214: ldc_w           -1037189562
        //  1217: ldc_w           1441860610
        //  1220: ixor           
        //  1221: lookupswitch {
        //          -1840195223: 1214
        //          639582077: 1324
        //          default: 1248
        //        }
        //  1248: invokevirtual   dev/nuker/pyro/f9p.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //  1251: pop            
        //  1252: aload_0        
        //  1253: getfield        dev/nuker/pyro/f9p.c:Ldev/nuker/pyro/f0o;
        //  1256: aload_0        
        //  1257: invokedynamic   BootstrapMethod #0, accept:(Ldev/nuker/pyro/f9p;)Ljava/util/function/Consumer;
        //  1262: getstatic       dev/nuker/pyro/fc.1:I
        //  1265: ifne            1274
        //  1268: ldc_w           202669606
        //  1271: goto            1277
        //  1274: ldc_w           -461849813
        //  1277: ldc_w           968429748
        //  1280: ixor           
        //  1281: lookupswitch {
        //          -574510177: 1308
        //          900558482: 1274
        //          default: 1320
        //        }
        //  1308: invokevirtual   dev/nuker/pyro/f0o.c:(Ljava/util/function/Consumer;)V
        //  1311: return         
        //  1312: aconst_null    
        //  1313: athrow         
        //  1314: aconst_null    
        //  1315: athrow         
        //  1316: aconst_null    
        //  1317: athrow         
        //  1318: aconst_null    
        //  1319: athrow         
        //  1320: aconst_null    
        //  1321: athrow         
        //  1322: aconst_null    
        //  1323: athrow         
        //  1324: aconst_null    
        //  1325: athrow         
        //  1326: aconst_null    
        //  1327: athrow         
        //  1328: aconst_null    
        //  1329: athrow         
        //  1330: aconst_null    
        //  1331: athrow         
        //  1332: aconst_null    
        //  1333: athrow         
        //  1334: aconst_null    
        //  1335: athrow         
        //  1336: aconst_null    
        //  1337: athrow         
        //  1338: aconst_null    
        //  1339: athrow         
        //  1340: aconst_null    
        //  1341: athrow         
        //  1342: aconst_null    
        //  1343: athrow         
        //  1344: aconst_null    
        //  1345: athrow         
        //  1346: aconst_null    
        //  1347: athrow         
        //  1348: aconst_null    
        //  1349: athrow         
        //  1350: aconst_null    
        //  1351: athrow         
        //  1352: aconst_null    
        //  1353: athrow         
        //  1354: aconst_null    
        //  1355: athrow         
        //    StackMapTable: 00 58 0B 41 01 1E FF 00 2E 00 01 07 00 03 00 07 07 00 03 08 00 40 08 00 40 07 00 4D 07 00 4D 05 01 FF 00 01 00 01 07 00 03 00 08 07 00 03 08 00 40 08 00 40 07 00 4D 07 00 4D 05 01 01 FF 00 1E 00 01 07 00 03 00 07 07 00 03 08 00 40 08 00 40 07 00 4D 07 00 4D 05 01 FF 00 1C 00 01 07 00 03 00 05 07 00 03 08 00 83 08 00 83 07 00 4D 07 00 4D FF 00 01 00 01 07 00 03 00 06 07 00 03 08 00 83 08 00 83 07 00 4D 07 00 4D 01 FF 00 1C 00 01 07 00 03 00 05 07 00 03 08 00 83 08 00 83 07 00 4D 07 00 4D FF 00 1E 00 01 07 00 03 00 04 07 00 03 08 00 C6 08 00 C6 07 00 4D FF 00 01 00 01 07 00 03 00 05 07 00 03 08 00 C6 08 00 C6 07 00 4D 01 FF 00 1E 00 01 07 00 03 00 04 07 00 03 08 00 C6 08 00 C6 07 00 4D FF 00 18 00 01 07 00 03 00 09 07 00 03 08 00 C6 08 00 C6 07 00 4D 07 00 4D 05 03 03 03 FF 00 01 00 01 07 00 03 00 0A 07 00 03 08 00 C6 08 00 C6 07 00 4D 07 00 4D 05 03 03 03 01 FF 00 1C 00 01 07 00 03 00 09 07 00 03 08 00 C6 08 00 C6 07 00 4D 07 00 4D 05 03 03 03 10 41 01 1C FF 00 28 00 01 07 00 03 00 04 07 00 03 08 01 78 08 01 78 07 00 4D FF 00 01 00 01 07 00 03 00 05 07 00 03 08 01 78 08 01 78 07 00 4D 01 FF 00 1C 00 01 07 00 03 00 04 07 00 03 08 01 78 08 01 78 07 00 4D FF 00 26 00 01 07 00 03 00 05 07 00 03 08 01 B9 08 01 B9 07 00 4D 07 00 4D FF 00 01 00 01 07 00 03 00 06 07 00 03 08 01 B9 08 01 B9 07 00 4D 07 00 4D 01 FF 00 1E 00 01 07 00 03 00 05 07 00 03 08 01 B9 08 01 B9 07 00 4D 07 00 4D FF 00 15 00 01 07 00 03 00 09 07 00 03 08 01 B9 08 01 B9 07 00 4D 07 00 4D 05 03 03 03 FF 00 01 00 01 07 00 03 00 0A 07 00 03 08 01 B9 08 01 B9 07 00 4D 07 00 4D 05 03 03 03 01 FF 00 1B 00 01 07 00 03 00 09 07 00 03 08 01 B9 08 01 B9 07 00 4D 07 00 4D 05 03 03 03 10 41 01 1C FF 00 11 00 01 07 00 03 00 04 07 00 03 08 02 55 08 02 55 07 00 4D FF 00 01 00 01 07 00 03 00 05 07 00 03 08 02 55 08 02 55 07 00 4D 01 FF 00 1B 00 01 07 00 03 00 04 07 00 03 08 02 55 08 02 55 07 00 4D FF 00 1A 00 01 07 00 03 00 09 07 00 03 08 02 55 08 02 55 07 00 4D 07 00 4D 05 03 03 03 FF 00 01 00 01 07 00 03 00 0A 07 00 03 08 02 55 08 02 55 07 00 4D 07 00 4D 05 03 03 03 01 FF 00 1E 00 01 07 00 03 00 09 07 00 03 08 02 55 08 02 55 07 00 4D 07 00 4D 05 03 03 03 FF 00 1D 00 01 07 00 03 00 05 07 00 03 08 02 C7 08 02 C7 07 00 4D 07 00 4D FF 00 02 00 01 07 00 03 00 06 07 00 03 08 02 C7 08 02 C7 07 00 4D 07 00 4D 01 FF 00 1E 00 01 07 00 03 00 05 07 00 03 08 02 C7 08 02 C7 07 00 4D 07 00 4D FF 00 10 00 01 07 00 03 00 07 07 00 03 08 02 C7 08 02 C7 07 00 4D 07 00 4D 05 01 FF 00 02 00 01 07 00 03 00 08 07 00 03 08 02 C7 08 02 C7 07 00 4D 07 00 4D 05 01 01 FF 00 1F 00 01 07 00 03 00 07 07 00 03 08 02 C7 08 02 C7 07 00 4D 07 00 4D 05 01 FF 00 2F 00 01 07 00 03 00 02 07 00 03 07 00 5C FF 00 02 00 01 07 00 03 00 03 07 00 03 07 00 5C 01 FF 00 1C 00 01 07 00 03 00 02 07 00 03 07 00 5C FF 00 26 00 01 07 00 03 00 02 07 00 03 07 00 5C FF 00 02 00 01 07 00 03 00 03 07 00 03 07 00 5C 01 FF 00 1D 00 01 07 00 03 00 02 07 00 03 07 00 5C 50 07 00 03 FF 00 02 00 01 07 00 03 00 02 07 00 03 01 5F 07 00 03 13 42 01 1C 4C 07 00 03 FF 00 02 00 01 07 00 03 00 02 07 00 03 01 5F 07 00 03 54 07 00 03 FF 00 02 00 01 07 00 03 00 02 07 00 03 01 5F 07 00 03 FF 00 21 00 01 07 00 03 00 02 07 00 03 07 00 5C FF 00 02 00 01 07 00 03 00 03 07 00 03 07 00 5C 01 FF 00 1E 00 01 07 00 03 00 02 07 00 03 07 00 5C FF 00 19 00 01 07 00 03 00 02 07 00 48 07 01 3E FF 00 02 00 01 07 00 03 00 03 07 00 48 07 01 3E 01 FF 00 1E 00 01 07 00 03 00 02 07 00 48 07 01 3E FF 00 03 00 01 07 00 03 00 04 07 00 03 08 02 55 08 02 55 07 00 4D FF 00 01 00 01 07 00 03 00 07 07 00 03 08 00 40 08 00 40 07 00 4D 07 00 4D 05 01 FF 00 01 00 01 07 00 03 00 09 07 00 03 08 00 C6 08 00 C6 07 00 4D 07 00 4D 05 03 03 03 FF 00 01 00 01 07 00 03 00 09 07 00 03 08 01 B9 08 01 B9 07 00 4D 07 00 4D 05 03 03 03 FF 00 01 00 01 07 00 03 00 02 07 00 48 07 01 3E FF 00 01 00 01 07 00 03 00 04 07 00 03 08 00 C6 08 00 C6 07 00 4D FF 00 01 00 01 07 00 03 00 02 07 00 03 07 00 5C 01 FF 00 01 00 01 07 00 03 00 09 07 00 03 08 02 55 08 02 55 07 00 4D 07 00 4D 05 03 03 03 FF 00 01 00 01 07 00 03 00 02 07 00 03 07 00 5C 41 07 00 03 FF 00 01 00 01 07 00 03 00 02 07 00 03 07 00 5C 41 07 00 03 FF 00 01 00 01 06 00 00 FF 00 01 00 01 07 00 03 00 00 FF 00 01 00 01 07 00 03 00 05 07 00 03 08 01 B9 08 01 B9 07 00 4D 07 00 4D 01 FF 00 01 00 01 07 00 03 00 07 07 00 03 08 02 C7 08 02 C7 07 00 4D 07 00 4D 05 01 41 07 00 03 FF 00 01 00 01 07 00 03 00 05 07 00 03 08 00 83 08 00 83 07 00 4D 07 00 4D FF 00 01 00 01 07 00 03 00 04 07 00 03 08 01 78 08 01 78 07 00 4D FF 00 01 00 01 07 00 03 00 05 07 00 03 08 02 C7 08 02 C7 07 00 4D 07 00 4D
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2695)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @f0g(1337)
    @LauncherEventHide
    public void c(final f4p f4p) {
        fez.6m(this, 399737683, f4p);
    }
}
