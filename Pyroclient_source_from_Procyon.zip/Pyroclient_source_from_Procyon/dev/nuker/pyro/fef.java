// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import org.jetbrains.annotations.Nullable;
import net.minecraft.block.Block;

public interface fef
{
    default static {
        throw t;
    }
    
    default boolean c(@Nullable final Block block) {
        throw new UnsupportedOperationException("Please report this to the binscure obfuscator developers");
    }
}
