// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import dev.nuker.pyro.security.inject.LauncherEventHide;
import net.minecraft.util.SoundEvent;
import java.util.List;

public class f8q extends fQ
{
    public List<SoundEvent> c;
    
    public f8q() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: ifne            11
        //     6: ldc             -1839207427
        //     8: goto            13
        //    11: ldc             -343615712
        //    13: ldc             1377755673
        //    15: ixor           
        //    16: lookupswitch {
        //          -1181076167: 44
        //          -1069479452: 11
        //          default: 334
        //        }
        //    44: aload_0        
        //    45: ldc             "\u3cee\ub24a\u8fa1\uadab\u67ba\u580b\u7e44\u68a9\uc2c2\ua34e"
        //    47: invokestatic    invokestatic   !!! ERROR
        //    50: ldc             "\u3cce\ub24a\u8f81\uadab\u67ba\u580b\u7e44\u6889\uc2c2\ua34e"
        //    52: getstatic       dev/nuker/pyro/fc.c:I
        //    55: ifne            63
        //    58: ldc             1555269559
        //    60: goto            65
        //    63: ldc             -360695349
        //    65: ldc             -72875841
        //    67: ixor           
        //    68: lookupswitch {
        //          -1497030343: 63
        //          -1491368184: 328
        //          default: 96
        //        }
        //    96: invokestatic    invokestatic   !!! ERROR
        //    99: aconst_null    
        //   100: getstatic       dev/nuker/pyro/fc.1:I
        //   103: ifne            111
        //   106: ldc             -2012384621
        //   108: goto            113
        //   111: ldc             1630581701
        //   113: ldc             490693457
        //   115: ixor           
        //   116: lookupswitch {
        //          -1791880766: 111
        //          2081411220: 144
        //          default: 336
        //        }
        //   144: invokespecial   dev/nuker/pyro/fQ.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   147: getstatic       dev/nuker/pyro/fc.c:I
        //   150: ifne            158
        //   153: ldc             -1977338221
        //   155: goto            160
        //   158: ldc             1755952973
        //   160: ldc             1536868209
        //   162: ixor           
        //   163: lookupswitch {
        //          -776042014: 330
        //          1459990187: 158
        //          default: 188
        //        }
        //   188: aload_0        
        //   189: bipush          7
        //   191: anewarray       Lnet/minecraft/util/SoundEvent;
        //   194: dup            
        //   195: iconst_0       
        //   196: getstatic       net/minecraft/init/SoundEvents.field_187719_p:Lnet/minecraft/util/SoundEvent;
        //   199: aastore        
        //   200: dup            
        //   201: iconst_1       
        //   202: getstatic       net/minecraft/init/SoundEvents.field_191258_p:Lnet/minecraft/util/SoundEvent;
        //   205: aastore        
        //   206: dup            
        //   207: iconst_2       
        //   208: getstatic       net/minecraft/init/SoundEvents.field_187716_o:Lnet/minecraft/util/SoundEvent;
        //   211: aastore        
        //   212: dup            
        //   213: iconst_3       
        //   214: getstatic       net/minecraft/init/SoundEvents.field_187725_r:Lnet/minecraft/util/SoundEvent;
        //   217: aastore        
        //   218: dup            
        //   219: iconst_4       
        //   220: getstatic       net/minecraft/init/SoundEvents.field_187722_q:Lnet/minecraft/util/SoundEvent;
        //   223: aastore        
        //   224: dup            
        //   225: iconst_5       
        //   226: getstatic       dev/nuker/pyro/fc.1:I
        //   229: ifne            237
        //   232: ldc             -12558969
        //   234: goto            239
        //   237: ldc             1953473569
        //   239: ldc             1939280482
        //   241: ixor           
        //   242: lookupswitch {
        //          -1932046363: 338
        //          1126106656: 237
        //          default: 268
        //        }
        //   268: getstatic       net/minecraft/init/SoundEvents.field_187713_n:Lnet/minecraft/util/SoundEvent;
        //   271: aastore        
        //   272: dup            
        //   273: bipush          6
        //   275: getstatic       net/minecraft/init/SoundEvents.field_187728_s:Lnet/minecraft/util/SoundEvent;
        //   278: aastore        
        //   279: invokestatic    java/util/Arrays.asList:([Ljava/lang/Object;)Ljava/util/List;
        //   282: getstatic       dev/nuker/pyro/fc.1:I
        //   285: ifne            293
        //   288: ldc             -129485711
        //   290: goto            295
        //   293: ldc             915559218
        //   295: ldc             -1567976679
        //   297: ixor           
        //   298: lookupswitch {
        //          -1810317269: 324
        //          1522706280: 293
        //          default: 332
        //        }
        //   324: putfield        dev/nuker/pyro/f8q.c:Ljava/util/List;
        //   327: return         
        //   328: aconst_null    
        //   329: athrow         
        //   330: aconst_null    
        //   331: athrow         
        //   332: aconst_null    
        //   333: athrow         
        //   334: aconst_null    
        //   335: athrow         
        //   336: aconst_null    
        //   337: athrow         
        //   338: aconst_null    
        //   339: athrow         
        //    StackMapTable: 00 18 0B 41 01 1E FF 00 12 00 01 06 00 03 06 07 00 55 07 00 55 FF 00 01 00 01 06 00 04 06 07 00 55 07 00 55 01 FF 00 1E 00 01 06 00 03 06 07 00 55 07 00 55 FF 00 0E 00 01 06 00 04 06 07 00 55 07 00 55 05 FF 00 01 00 01 06 00 05 06 07 00 55 07 00 55 05 01 FF 00 1E 00 01 06 00 04 06 07 00 55 07 00 55 05 FF 00 0D 00 01 07 00 03 00 00 41 01 1B FF 00 30 00 01 07 00 03 00 04 07 00 03 07 00 57 07 00 57 01 FF 00 01 00 01 07 00 03 00 05 07 00 03 07 00 57 07 00 57 01 01 FF 00 1C 00 01 07 00 03 00 04 07 00 03 07 00 57 07 00 57 01 FF 00 18 00 01 07 00 03 00 02 07 00 03 07 00 59 FF 00 01 00 01 07 00 03 00 03 07 00 03 07 00 59 01 FF 00 1C 00 01 07 00 03 00 02 07 00 03 07 00 59 FF 00 03 00 01 06 00 03 06 07 00 55 07 00 55 FF 00 01 00 01 07 00 03 00 00 FF 00 01 00 01 07 00 03 00 02 07 00 03 07 00 59 FF 00 01 00 01 06 00 00 FF 00 01 00 01 06 00 04 06 07 00 55 07 00 55 05 FF 00 01 00 01 07 00 03 00 04 07 00 03 07 00 57 07 00 57 01
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        throw t;
    }
    
    @f0g
    @LauncherEventHide
    public void c(final f4e f4e) {
        fez.2j(this, 78661137, f4e);
    }
}
