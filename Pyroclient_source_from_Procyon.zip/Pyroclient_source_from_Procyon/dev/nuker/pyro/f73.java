// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import dev.nuker.pyro.security.inject.LauncherEventHide;
import org.jetbrains.annotations.NotNull;

public class f73 extends fQ
{
    @NotNull
    public f0o<f72> c;
    @NotNull
    public f0p c;
    @NotNull
    public f0p 0;
    @NotNull
    public f0k c;
    @NotNull
    public f0k 0;
    @NotNull
    public f0k 1;
    
    @NotNull
    public f0k 0() {
        return fez.6E(this, 856716335);
    }
    
    @NotNull
    public f0k 3() {
        return fez.7s(this, 1382711264);
    }
    
    @NotNull
    public f0p 4() {
        return fez.4S(this, 1518873813);
    }
    
    public f73() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: ifne            11
        //     6: ldc             -381333537
        //     8: goto            13
        //    11: ldc             -671660347
        //    13: ldc             2053005478
        //    15: ixor           
        //    16: lookupswitch {
        //          -2049568321: 11
        //          -1826934919: 637
        //          default: 44
        //        }
        //    44: aload_0        
        //    45: ldc             "\u3d53\ub240\u8e03\uadab\u6771\u59a9\u7e54\u6901"
        //    47: invokestatic    invokestatic   !!! ERROR
        //    50: ldc             "\u3d73\ub240\u8e03\uadab\u6771\u59a9\u7e54\u6901"
        //    52: invokestatic    invokestatic   !!! ERROR
        //    55: ldc             "\u3d64\ub249\u8e03\uadab\u6765\u59b3\u7e00\u6901\uc2cc\ua381\u9bbc\u1310\uc176\u714e\u90ae\u4da7\ub215\u4c9a\u0144\u0758\u12f0\ufed0\u6ac7\u8851\u3611\u3d39\u7ffe\ua96b\ud1ef\u724d\u4462\u6bba\u7410\u9738\uc7b0\u4328\ufdf9\u10c9\u1854\u4ac5\u6601\uac07\u8d30\uf930\ubc9c"
        //    57: invokestatic    invokestatic   !!! ERROR
        //    60: invokespecial   dev/nuker/pyro/fQ.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //    63: getstatic       dev/nuker/pyro/fc.1:I
        //    66: ifne            74
        //    69: ldc             -447475615
        //    71: goto            76
        //    74: ldc             -587325701
        //    76: ldc             -1942497077
        //    78: ixor           
        //    79: lookupswitch {
        //          461165382: 74
        //          1768147114: 639
        //          default: 104
        //        }
        //   104: aload_0        
        //   105: getstatic       dev/nuker/pyro/fc.1:I
        //   108: ifne            116
        //   111: ldc             458695383
        //   113: goto            118
        //   116: ldc             -1006834700
        //   118: ldc             -544737453
        //   120: ixor           
        //   121: lookupswitch {
        //          -992946812: 633
        //          727672771: 116
        //          default: 148
        //        }
        //   148: aload_0        
        //   149: new             Ldev/nuker/pyro/f0o;
        //   152: dup            
        //   153: ldc             "\u3d48\ub24a\u8e0b\uada1"
        //   155: invokestatic    invokestatic   !!! ERROR
        //   158: ldc             "\u3d68\ub24a\u8e0b\uada1"
        //   160: invokestatic    invokestatic   !!! ERROR
        //   163: aconst_null    
        //   164: getstatic       dev/nuker/pyro/f72.c:Ldev/nuker/pyro/f72;
        //   167: checkcast       Ljava/lang/Enum;
        //   170: invokespecial   dev/nuker/pyro/f0o.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Enum;)V
        //   173: checkcast       Ldev/nuker/pyro/f0w;
        //   176: invokevirtual   dev/nuker/pyro/f73.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   179: checkcast       Ldev/nuker/pyro/f0o;
        //   182: putfield        dev/nuker/pyro/f73.c:Ldev/nuker/pyro/f0o;
        //   185: aload_0        
        //   186: getstatic       dev/nuker/pyro/fc.c:I
        //   189: ifne            197
        //   192: ldc             43861120
        //   194: goto            199
        //   197: ldc             -612397095
        //   199: ldc             1129289849
        //   201: ixor           
        //   202: lookupswitch {
        //          800897436: 197
        //          1104338169: 649
        //          default: 228
        //        }
        //   228: aload_0        
        //   229: new             Ldev/nuker/pyro/f0p;
        //   232: dup            
        //   233: ldc             "\u3d4d\ub24a\u8e1d\uadad\u6768\u59af\u7e4e\u690c\uc2c2\ua398"
        //   235: invokestatic    invokestatic   !!! ERROR
        //   238: ldc             "\u3d6d\ub24a\u8e1d\uadad\u6768\u59af\u7e4e\u690c\uc2c2\ua398"
        //   240: invokestatic    invokestatic   !!! ERROR
        //   243: ldc             "\u3d71\ub24d\u8e0a\uade4\u677a\u59af\u7e52\u6911\uc2d9\ua39b\u9bf2\u1310\uc178\u7102\u90e3\u4dbe\ub214\u4c9f\u014d\u0742\u12b9\ufed0\u6ad6\u8814\u3648\u3d20\u7fee\ua927\ud1f7\u7247\u4467\u6ba2\u7449\u976c\uc7a8\u432c\ufde9"
        //   245: invokestatic    invokestatic   !!! ERROR
        //   248: iconst_0       
        //   249: iconst_0       
        //   250: bipush          100
        //   252: iconst_1       
        //   253: invokespecial   dev/nuker/pyro/f0p.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIII)V
        //   256: checkcast       Ldev/nuker/pyro/f0w;
        //   259: invokevirtual   dev/nuker/pyro/f73.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   262: checkcast       Ldev/nuker/pyro/f0p;
        //   265: putfield        dev/nuker/pyro/f73.c:Ldev/nuker/pyro/f0p;
        //   268: getstatic       dev/nuker/pyro/fc.0:I
        //   271: ifgt            279
        //   274: ldc             949672351
        //   276: goto            281
        //   279: ldc             -1495017930
        //   281: ldc             1263558048
        //   283: ixor           
        //   284: lookupswitch {
        //          -307000426: 312
        //          1942651967: 279
        //          default: 645
        //        }
        //   312: aload_0        
        //   313: aload_0        
        //   314: new             Ldev/nuker/pyro/f0p;
        //   317: dup            
        //   318: ldc             "\u3d53\ub240\u8e1d\uadb0\u677b\u59a3\u7e41\u6914"
        //   320: invokestatic    invokestatic   !!! ERROR
        //   323: ldc             "\u3d73\ub240\u8e1d\uadb0\u677b\u59a3\u7e41\u6914"
        //   325: invokestatic    invokestatic   !!! ERROR
        //   328: ldc             "\u3d71\ub24d\u8e0a\uade4\u6764\u59a5\u7e52\u690c\uc2ca\ua397\u9bfd\u1308\uc139\u7118\u90a6\u4da4\ub21e\u4c90\u014b\u0755\u12a9\ufe84\u6ad6\u885b\u3644\u3d6f\u7fec\ua96e\ud1ec\u7242\u442b\u6bba\u7408\u9773\uc7ac"
        //   330: invokestatic    invokestatic   !!! ERROR
        //   333: iconst_0       
        //   334: iconst_0       
        //   335: bipush          100
        //   337: iconst_1       
        //   338: getstatic       dev/nuker/pyro/fc.0:I
        //   341: ifgt            349
        //   344: ldc             107315996
        //   346: goto            351
        //   349: ldc             -1068021831
        //   351: ldc             601992533
        //   353: ixor           
        //   354: lookupswitch {
        //          -474551572: 380
        //          629419593: 349
        //          default: 643
        //        }
        //   380: invokespecial   dev/nuker/pyro/f0p.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIII)V
        //   383: checkcast       Ldev/nuker/pyro/f0w;
        //   386: getstatic       dev/nuker/pyro/fc.c:I
        //   389: ifne            397
        //   392: ldc             -188204047
        //   394: goto            399
        //   397: ldc             544180765
        //   399: ldc             -436260675
        //   401: ixor           
        //   402: lookupswitch {
        //          288820044: 641
        //          642421405: 397
        //          default: 428
        //        }
        //   428: invokevirtual   dev/nuker/pyro/f73.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   431: checkcast       Ldev/nuker/pyro/f0p;
        //   434: getstatic       dev/nuker/pyro/fc.c:I
        //   437: ifne            445
        //   440: ldc             510127349
        //   442: goto            447
        //   445: ldc             1234056945
        //   447: ldc             -738699357
        //   449: ixor           
        //   450: lookupswitch {
        //          -1703517870: 476
        //          -845169834: 445
        //          default: 635
        //        }
        //   476: putfield        dev/nuker/pyro/f73.0:Ldev/nuker/pyro/f0p;
        //   479: aload_0        
        //   480: aload_0        
        //   481: new             Ldev/nuker/pyro/f0k;
        //   484: dup            
        //   485: ldc             "\u3d40\ub25d\u8e1f\uada8\u677d\u59b3\u7e49\u6917\uc2cd\ua387"
        //   487: invokestatic    invokestatic   !!! ERROR
        //   490: ldc             "\u3d60\ub25d\u8e1f\uada8\u677d\u59b3\u7e49\u6917\uc2cd\ua387"
        //   492: invokestatic    invokestatic   !!! ERROR
        //   495: ldc             "\u3d64\ub255\u8e1f\uada8\u676b\u59e0\u7e54\u6910\uc2c6\ua3d4\u9bea\u1301\uc175\u7101\u90a0\u4da1\ub205\u4c8a\u0102\u074c\u12bf\ufec0\u6ac6\u8852\u3658\u3d2a\u7fe9\ua927\ud1ef\u7240\u442b\u6bab\u7411\u9768\uc7a5\u4328\ufdff\u1080\u1849\u4ace\u6611"
        //   497: invokestatic    invokestatic   !!! ERROR
        //   500: iconst_1       
        //   501: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   504: checkcast       Ldev/nuker/pyro/f0w;
        //   507: invokevirtual   dev/nuker/pyro/f73.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   510: checkcast       Ldev/nuker/pyro/f0k;
        //   513: putfield        dev/nuker/pyro/f73.c:Ldev/nuker/pyro/f0k;
        //   516: aload_0        
        //   517: aload_0        
        //   518: new             Ldev/nuker/pyro/f0k;
        //   521: dup            
        //   522: ldc             "\u3d47\ub24a\u8e0d\uada6\u6777\u59b2\u7e53"
        //   524: invokestatic    invokestatic   !!! ERROR
        //   527: ldc             "\u3d67\ub24a\u8e0d\uada6\u6777\u59b2\u7e53"
        //   529: invokestatic    invokestatic   !!! ERROR
        //   532: ldc             "\u3d64\ub255\u8e1f\uada8\u676b\u59e0\u7e54\u6910\uc2c6\ua3d4\u9bea\u1301\uc175\u7101\u90a0\u4da1\ub205\u4c8a\u0102\u074c\u12bf\ufec0\u6ac6\u8852\u3658\u3d2a\u7fe9\ua927\ud1ef\u7240\u442b\u6ba8\u7400\u976b\uc7a1\u432e\ufde2\u108e\u1806\u4ac2\u660d\uac00\u8d3b\uf923\ubc8b\ua47a\u4c34\u3f0c\u4a2e\ua214\u785e\u916b\u3340\u6fd1"
        //   534: invokestatic    invokestatic   !!! ERROR
        //   537: iconst_1       
        //   538: getstatic       dev/nuker/pyro/fc.0:I
        //   541: ifgt            549
        //   544: ldc             967873543
        //   546: goto            551
        //   549: ldc             385951345
        //   551: ldc             1021547254
        //   553: ixor           
        //   554: lookupswitch {
        //          89327345: 549
        //          736277639: 580
        //          default: 647
        //        }
        //   580: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   583: checkcast       Ldev/nuker/pyro/f0w;
        //   586: invokevirtual   dev/nuker/pyro/f73.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   589: checkcast       Ldev/nuker/pyro/f0k;
        //   592: putfield        dev/nuker/pyro/f73.0:Ldev/nuker/pyro/f0k;
        //   595: aload_0        
        //   596: aload_0        
        //   597: new             Ldev/nuker/pyro/f0k;
        //   600: dup            
        //   601: ldc             "\u3d4b\ub24a\u8e1f\uadb1\u6761\u59a8"
        //   603: invokestatic    invokestatic   !!! ERROR
        //   606: ldc             "\u3d6b\ub24a\u8e3f\uadb1\u6761\u59a8"
        //   608: invokestatic    invokestatic   !!! ERROR
        //   611: ldc             "\u3d61\ub24c\u8e1c\uada5\u6770\u59ac\u7e45\u690b\uc283\ua397\u9bf3\u1308\uc175\u7107\u90b0\u4da1\ub21e\u4c9d\u0102\u074c\u12bf\ufed2\u6aca\u8859\u3654\u3d21\u7fef"
        //   613: invokestatic    invokestatic   !!! ERROR
        //   616: iconst_1       
        //   617: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   620: checkcast       Ldev/nuker/pyro/f0w;
        //   623: invokevirtual   dev/nuker/pyro/f73.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   626: checkcast       Ldev/nuker/pyro/f0k;
        //   629: putfield        dev/nuker/pyro/f73.1:Ldev/nuker/pyro/f0k;
        //   632: return         
        //   633: aconst_null    
        //   634: athrow         
        //   635: aconst_null    
        //   636: athrow         
        //   637: aconst_null    
        //   638: athrow         
        //   639: aconst_null    
        //   640: athrow         
        //   641: aconst_null    
        //   642: athrow         
        //   643: aconst_null    
        //   644: athrow         
        //   645: aconst_null    
        //   646: athrow         
        //   647: aconst_null    
        //   648: athrow         
        //   649: aconst_null    
        //   650: athrow         
        //    StackMapTable: 00 24 0B 41 01 1E FF 00 1D 00 01 07 00 03 00 00 41 01 1B 4B 07 00 03 FF 00 01 00 01 07 00 03 00 02 07 00 03 01 5D 07 00 03 70 07 00 03 FF 00 01 00 01 07 00 03 00 02 07 00 03 01 5C 07 00 03 32 41 01 1E FF 00 24 00 01 07 00 03 00 0B 07 00 03 07 00 03 08 01 3A 08 01 3A 07 00 A0 07 00 A0 07 00 A0 01 01 01 01 FF 00 01 00 01 07 00 03 00 0C 07 00 03 07 00 03 08 01 3A 08 01 3A 07 00 A0 07 00 A0 07 00 A0 01 01 01 01 01 FF 00 1C 00 01 07 00 03 00 0B 07 00 03 07 00 03 08 01 3A 08 01 3A 07 00 A0 07 00 A0 07 00 A0 01 01 01 01 FF 00 10 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 53 FF 00 01 00 01 07 00 03 00 04 07 00 03 07 00 03 07 00 53 01 FF 00 1C 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 53 FF 00 10 00 01 07 00 03 00 02 07 00 03 07 00 5D FF 00 01 00 01 07 00 03 00 03 07 00 03 07 00 5D 01 FF 00 1C 00 01 07 00 03 00 02 07 00 03 07 00 5D FF 00 48 00 01 07 00 03 00 08 07 00 03 07 00 03 08 02 06 08 02 06 07 00 A0 07 00 A0 07 00 A0 01 FF 00 01 00 01 07 00 03 00 09 07 00 03 07 00 03 08 02 06 08 02 06 07 00 A0 07 00 A0 07 00 A0 01 01 FF 00 1C 00 01 07 00 03 00 08 07 00 03 07 00 03 08 02 06 08 02 06 07 00 A0 07 00 A0 07 00 A0 01 74 07 00 03 FF 00 01 00 01 07 00 03 00 02 07 00 03 07 00 5D FF 00 01 00 01 06 00 00 FF 00 01 00 01 07 00 03 00 00 FF 00 01 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 53 FF 00 01 00 01 07 00 03 00 0B 07 00 03 07 00 03 08 01 3A 08 01 3A 07 00 A0 07 00 A0 07 00 A0 01 01 01 01 01 FF 00 01 00 01 07 00 03 00 08 07 00 03 07 00 03 08 02 06 08 02 06 07 00 A0 07 00 A0 07 00 A0 01 41 07 00 03
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2695)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @NotNull
    public f0p 1() {
        return fez.4Y(this, 998647364);
    }
    
    static {
        throw t;
    }
    
    @f0g
    @LauncherEventHide
    public void c(@NotNull final f4u f4u) {
        fez.ik(this, 1103616971, f4u);
    }
    
    @NotNull
    public f0o 2() {
        return fez.bu(this, 2084310159);
    }
    
    @f0g
    @LauncherEventHide
    public void c(@NotNull final f4x f4x) {
        fez.2d(this, 532814756, f4x);
    }
    
    @NotNull
    public f0k c() {
        return fez.73(this, 935003723);
    }
    
    @f0g
    @LauncherEventHide
    public void c(@NotNull final f4e p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          2798
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            2790
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            2782
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: getstatic       dev/nuker/pyro/fc.c:I
        //    29: ifne            37
        //    32: ldc             369345540
        //    34: goto            39
        //    37: ldc             -1207362398
        //    39: ldc             -931369723
        //    41: ixor           
        //    42: lookupswitch {
        //          -562059007: 37
        //          1886744999: 68
        //          default: 2735
        //        }
        //    68: aload_0        
        //    69: getfield        dev/nuker/pyro/f73.c:Lnet/minecraft/client/Minecraft;
        //    72: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //    75: ifnull          224
        //    78: aload_0        
        //    79: getfield        dev/nuker/pyro/f73.c:Lnet/minecraft/client/Minecraft;
        //    82: getstatic       dev/nuker/pyro/fc.1:I
        //    85: ifne            93
        //    88: ldc             261111047
        //    90: goto            95
        //    93: ldc             -1441828365
        //    95: ldc             1941098745
        //    97: ixor           
        //    98: lookupswitch {
        //          -641883894: 124
        //          2082663934: 93
        //          default: 2737
        //        }
        //   124: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   127: ifnull          224
        //   130: aload_1        
        //   131: goto            135
        //   134: athrow         
        //   135: invokevirtual   dev/nuker/pyro/f4e.c:()Ldev/nuker/pyro/f41;
        //   138: goto            142
        //   141: athrow         
        //   142: getstatic       dev/nuker/pyro/fc.c:I
        //   145: ifne            153
        //   148: ldc             464752955
        //   150: goto            155
        //   153: ldc             1905110805
        //   155: ldc             -682325212
        //   157: ixor           
        //   158: lookupswitch {
        //          -1495718863: 184
        //          -857269729: 153
        //          default: 2743
        //        }
        //   184: getstatic       dev/nuker/pyro/f41.c:Ldev/nuker/pyro/f41;
        //   187: if_acmpeq       196
        //   190: ldc_w           -1873937102
        //   193: goto            199
        //   196: ldc_w           -1873937091
        //   199: ldc_w           736747861
        //   202: ixor           
        //   203: tableswitch {
        //          2001221838: 224
        //          2001221839: 225
        //          default: 190
        //        }
        //   224: return         
        //   225: aload_0        
        //   226: getfield        dev/nuker/pyro/f73.c:Ldev/nuker/pyro/f0o;
        //   229: goto            233
        //   232: athrow         
        //   233: invokevirtual   dev/nuker/pyro/f0o.c:()Ljava/lang/Object;
        //   236: goto            240
        //   239: athrow         
        //   240: checkcast       Ldev/nuker/pyro/f72;
        //   243: getstatic       dev/nuker/pyro/f72.c:Ldev/nuker/pyro/f72;
        //   246: if_acmpne       2712
        //   249: aload_1        
        //   250: goto            254
        //   253: athrow         
        //   254: invokevirtual   dev/nuker/pyro/f4e.c:()Lnet/minecraft/network/Packet;
        //   257: goto            261
        //   260: athrow         
        //   261: instanceof      Lnet/minecraft/network/play/server/SPacketEntityStatus;
        //   264: ifeq            706
        //   267: getstatic       dev/nuker/pyro/fc.c:I
        //   270: ifne            279
        //   273: ldc_w           330033151
        //   276: goto            282
        //   279: ldc_w           1794396754
        //   282: ldc_w           1152831936
        //   285: ixor           
        //   286: lookupswitch {
        //          776110994: 312
        //          1461532223: 279
        //          default: 2717
        //        }
        //   312: aload_0        
        //   313: getstatic       dev/nuker/pyro/fc.c:I
        //   316: ifne            325
        //   319: ldc_w           -1821624867
        //   322: goto            328
        //   325: ldc_w           1333141649
        //   328: ldc_w           -1461713546
        //   331: ixor           
        //   332: lookupswitch {
        //          -409590297: 360
        //          999043243: 325
        //          default: 2753
        //        }
        //   360: getfield        dev/nuker/pyro/f73.0:Ldev/nuker/pyro/f0k;
        //   363: goto            367
        //   366: athrow         
        //   367: invokevirtual   dev/nuker/pyro/f0k.c:()Ljava/lang/Object;
        //   370: goto            374
        //   373: athrow         
        //   374: checkcast       Ljava/lang/Boolean;
        //   377: goto            381
        //   380: athrow         
        //   381: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   384: goto            388
        //   387: athrow         
        //   388: ifeq            706
        //   391: aload_1        
        //   392: getstatic       dev/nuker/pyro/fc.0:I
        //   395: ifgt            404
        //   398: ldc_w           -1894118532
        //   401: goto            407
        //   404: ldc_w           -657673159
        //   407: ldc_w           1853615123
        //   410: ixor           
        //   411: lookupswitch {
        //          -1229498326: 436
        //          -513677457: 404
        //          default: 2727
        //        }
        //   436: goto            440
        //   439: athrow         
        //   440: invokevirtual   dev/nuker/pyro/f4e.c:()Lnet/minecraft/network/Packet;
        //   443: goto            447
        //   446: athrow         
        //   447: dup            
        //   448: ifnonnull       481
        //   451: new             Lkotlin/TypeCastException;
        //   454: dup            
        //   455: ldc_w           "\u3d4b\ub250\u8e03\uafb9\u6103\u59a3\u7e41\u6916\uc0dc\ua5aa\u9be8\u1344\uc17b\u731a\u96d2\u4dab\ub210\u4c80\u0347\u0130\u12a4\ufecb\u6a8f\u8a4b\u306f\u3d21\u7fb6\ua969\ud3e4\u7473\u4467\u6bee\u741d\u9570\uc188\u4322\ufdac\u1087\u1a52\u4ce5\u664c\uac0f\u8d30\ufb39\ubaad\ua439\u4c30\u3f08\u4835\ua43e\u7813\u916c\u3351\u6dcd\uf082\u0ef1\u7a49\u0aa2\u9d6f\ud5d6\ue789\u4c6b\u484f\u14ce\u37ec\u518b\u7982\ue7f8\u5df1\u8d84\uebd4\u1df0\uf2c0\ub46d\uc618\u176d\u2aee\u6656\u467c\u7a5c\uca2f\u172e\u2b52\u8dd1\ud62d\u3842\u9b9a\u83e6\ucac8\ucbc3"
        //   458: goto            462
        //   461: athrow         
        //   462: invokestatic    invokestatic   !!! ERROR
        //   465: goto            469
        //   468: athrow         
        //   469: goto            473
        //   472: athrow         
        //   473: invokespecial   kotlin/TypeCastException.<init>:(Ljava/lang/String;)V
        //   476: goto            480
        //   479: athrow         
        //   480: athrow         
        //   481: checkcast       Lnet/minecraft/network/play/server/SPacketEntityStatus;
        //   484: getstatic       dev/nuker/pyro/fc.1:I
        //   487: ifne            496
        //   490: ldc_w           -483046851
        //   493: goto            499
        //   496: ldc_w           1531200463
        //   499: ldc_w           -411551068
        //   502: ixor           
        //   503: lookupswitch {
        //          -1136887445: 528
        //          72183961: 496
        //          default: 2721
        //        }
        //   528: astore_2       
        //   529: getstatic       dev/nuker/pyro/fc.1:I
        //   532: ifne            541
        //   535: ldc_w           -328181855
        //   538: goto            544
        //   541: ldc_w           -185819494
        //   544: ldc_w           -205150480
        //   547: ixor           
        //   548: lookupswitch {
        //          120141930: 576
        //          532017489: 541
        //          default: 2713
        //        }
        //   576: aload_2        
        //   577: goto            581
        //   580: athrow         
        //   581: invokevirtual   net/minecraft/network/play/server/SPacketEntityStatus.func_149160_c:()B
        //   584: goto            588
        //   587: athrow         
        //   588: bipush          31
        //   590: if_icmpne       2712
        //   593: aload_2        
        //   594: aload_0        
        //   595: getfield        dev/nuker/pyro/f73.c:Lnet/minecraft/client/Minecraft;
        //   598: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //   601: checkcast       Lnet/minecraft/world/World;
        //   604: goto            608
        //   607: athrow         
        //   608: invokevirtual   net/minecraft/network/play/server/SPacketEntityStatus.func_149161_a:(Lnet/minecraft/world/World;)Lnet/minecraft/entity/Entity;
        //   611: goto            615
        //   614: athrow         
        //   615: astore_3       
        //   616: aload_3        
        //   617: ifnull          2712
        //   620: aload_3        
        //   621: instanceof      Lnet/minecraft/entity/projectile/EntityFishHook;
        //   624: ifeq            2712
        //   627: aload_3        
        //   628: checkcast       Lnet/minecraft/entity/projectile/EntityFishHook;
        //   631: getfield        net/minecraft/entity/projectile/EntityFishHook.field_146043_c:Lnet/minecraft/entity/Entity;
        //   634: aload_0        
        //   635: getfield        dev/nuker/pyro/f73.c:Lnet/minecraft/client/Minecraft;
        //   638: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   641: if_acmpne       2712
        //   644: aload_1        
        //   645: getstatic       dev/nuker/pyro/fc.c:I
        //   648: ifne            657
        //   651: ldc_w           -706383342
        //   654: goto            660
        //   657: ldc_w           -1602302293
        //   660: ldc_w           1344705736
        //   663: ixor           
        //   664: lookupswitch {
        //          -2050758950: 2745
        //          128314843: 657
        //          default: 692
        //        }
        //   692: goto            696
        //   695: athrow         
        //   696: invokevirtual   dev/nuker/pyro/f4e.0:()V
        //   699: goto            703
        //   702: athrow         
        //   703: goto            2712
        //   706: getstatic       dev/nuker/pyro/fc.1:I
        //   709: ifne            718
        //   712: ldc_w           2030178200
        //   715: goto            721
        //   718: ldc_w           877437337
        //   721: ldc_w           442096403
        //   724: ixor           
        //   725: lookupswitch {
        //          773159562: 752
        //          1666962571: 718
        //          default: 2763
        //        }
        //   752: aload_1        
        //   753: getstatic       dev/nuker/pyro/fc.1:I
        //   756: ifne            765
        //   759: ldc_w           -645229897
        //   762: goto            768
        //   765: ldc_w           1691507190
        //   768: ldc_w           -2147456378
        //   771: ixor           
        //   772: lookupswitch {
        //          -455986320: 800
        //          1502279729: 765
        //          default: 2759
        //        }
        //   800: goto            804
        //   803: athrow         
        //   804: invokevirtual   dev/nuker/pyro/f4e.c:()Lnet/minecraft/network/Packet;
        //   807: goto            811
        //   810: athrow         
        //   811: instanceof      Lnet/minecraft/network/play/server/SPacketEntityVelocity;
        //   814: ifeq            1808
        //   817: aload_1        
        //   818: goto            822
        //   821: athrow         
        //   822: invokevirtual   dev/nuker/pyro/f4e.c:()Lnet/minecraft/network/Packet;
        //   825: goto            829
        //   828: athrow         
        //   829: dup            
        //   830: ifnonnull       863
        //   833: new             Lkotlin/TypeCastException;
        //   836: dup            
        //   837: ldc_w           "\u3d4b\ub250\u8e03\uafb9\u6103\u59a3\u7e41\u6916\uc0dc\ua5aa\u9be8\u1344\uc17b\u731a\u96d2\u4dab\ub210\u4c80\u0347\u0130\u12a4\ufecb\u6a8f\u8a4b\u306f\u3d21\u7fb6\ua969\ud3e4\u7473\u4467\u6bee\u741d\u9570\uc188\u4322\ufdac\u1087\u1a52\u4ce5\u664c\uac0f\u8d30\ufb39\ubaad\ua439\u4c30\u3f08\u4835\ua43e\u7813\u916c\u3351\u6dcd\uf082\u0ef1\u7a49\u0aa2\u9d6f\ud5d6\ue789\u4c6b\u484f\u14ce\u37ec\u518b\u7982\ue7f8\u5df1\u8d84\uebd4\u1df0\uf2c0\ub46d\uc618\u176d\u2aee\u6656\u467c\u7a5c\uca2f\u172e\u2b52\u8dd1\ud628\u3853\u9b97\u83fd\ucade\ucbd9\uafa1\ueb1c"
        //   840: goto            844
        //   843: athrow         
        //   844: invokestatic    invokestatic   !!! ERROR
        //   847: goto            851
        //   850: athrow         
        //   851: goto            855
        //   854: athrow         
        //   855: invokespecial   kotlin/TypeCastException.<init>:(Ljava/lang/String;)V
        //   858: goto            862
        //   861: athrow         
        //   862: athrow         
        //   863: checkcast       Lnet/minecraft/network/play/server/SPacketEntityVelocity;
        //   866: dup            
        //   867: ifnonnull       876
        //   870: ldc_w           981727791
        //   873: goto            879
        //   876: ldc_w           981727788
        //   879: ldc_w           -1948175582
        //   882: ixor           
        //   883: tableswitch {
        //          1657115162: 904
        //          1657115163: 980
        //          default: 870
        //        }
        //   904: new             Lkotlin/TypeCastException;
        //   907: dup            
        //   908: ldc_w           "\u3d4b\ub250\u8e03\uafb9\u6103\u59a3\u7e41\u6916\uc0dc\ua5aa\u9be8\u1344\uc17b\u731a\u96d2\u4dab\ub210\u4c80\u0347\u0130\u12a4\ufecb\u6a8f\u8a4b\u306f\u3d21\u7fb6\ua969\ud3e4\u7473\u4467\u6bee\u741d\u9570\uc188\u4322\ufdac\u108d\u1a52\u4ce7\u664c\uac0c\u8d2c\ufb3c\ubaad\ua428\u4c6c\u3f19\u482a\ua438\u7852\u912c\u3359\u6dd0\uf08d\u0ef7\u7a55\u0ae7\u9d12\ud5f6\ue784\u4c69\u485d\u1485\u37eb\u51ab\u799e\ue7fa\u5dfd\u8d82\ueb83\u1df5\uf2f5\ub460\uc614\u1765\u2ae2\u6656\u4640\u7a73\uca38\u1724\u2b43\u8ddb\ud60d\u3859\u9b89"
        //   911: goto            915
        //   914: athrow         
        //   915: invokestatic    invokestatic   !!! ERROR
        //   918: goto            922
        //   921: athrow         
        //   922: getstatic       dev/nuker/pyro/fc.0:I
        //   925: ifgt            934
        //   928: ldc_w           -292368393
        //   931: goto            937
        //   934: ldc_w           1165455951
        //   937: ldc_w           1574216148
        //   940: ixor           
        //   941: lookupswitch {
        //          -1287229917: 934
        //          413389723: 968
        //          default: 2749
        //        }
        //   968: goto            972
        //   971: athrow         
        //   972: invokespecial   kotlin/TypeCastException.<init>:(Ljava/lang/String;)V
        //   975: goto            979
        //   978: athrow         
        //   979: athrow         
        //   980: checkcast       Ldev/nuker/pyro/mixin/SPacketEntityVelocityAccessor;
        //   983: astore_2       
        //   984: aload_2        
        //   985: goto            989
        //   988: athrow         
        //   989: invokeinterface dev/nuker/pyro/mixin/SPacketEntityVelocityAccessor.getEntityID:()I
        //   994: goto            998
        //   997: athrow         
        //   998: aload_0        
        //   999: getfield        dev/nuker/pyro/f73.c:Lnet/minecraft/client/Minecraft;
        //  1002: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1005: dup            
        //  1006: pop            
        //  1007: goto            1011
        //  1010: athrow         
        //  1011: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_145782_y:()I
        //  1014: goto            1018
        //  1017: athrow         
        //  1018: if_icmpne       2712
        //  1021: aload_0        
        //  1022: getfield        dev/nuker/pyro/f73.c:Ldev/nuker/pyro/f0p;
        //  1025: goto            1029
        //  1028: athrow         
        //  1029: invokevirtual   dev/nuker/pyro/f0p.c:()Ljava/lang/Object;
        //  1032: goto            1036
        //  1035: athrow         
        //  1036: checkcast       Ljava/lang/Number;
        //  1039: goto            1043
        //  1042: athrow         
        //  1043: invokevirtual   java/lang/Number.intValue:()I
        //  1046: goto            1050
        //  1049: athrow         
        //  1050: ifne            1188
        //  1053: aload_0        
        //  1054: getfield        dev/nuker/pyro/f73.0:Ldev/nuker/pyro/f0p;
        //  1057: goto            1061
        //  1060: athrow         
        //  1061: invokevirtual   dev/nuker/pyro/f0p.c:()Ljava/lang/Object;
        //  1064: goto            1068
        //  1067: athrow         
        //  1068: checkcast       Ljava/lang/Number;
        //  1071: getstatic       dev/nuker/pyro/fc.0:I
        //  1074: ifgt            1083
        //  1077: ldc_w           333377752
        //  1080: goto            1086
        //  1083: ldc_w           74330460
        //  1086: ldc_w           148280239
        //  1089: ixor           
        //  1090: lookupswitch {
        //          -1376995926: 1083
        //          453534583: 2767
        //          default: 1116
        //        }
        //  1116: goto            1120
        //  1119: athrow         
        //  1120: invokevirtual   java/lang/Number.intValue:()I
        //  1123: goto            1127
        //  1126: athrow         
        //  1127: ifne            1188
        //  1130: aload_1        
        //  1131: getstatic       dev/nuker/pyro/fc.1:I
        //  1134: ifne            1143
        //  1137: ldc_w           992096823
        //  1140: goto            1146
        //  1143: ldc_w           -1209601480
        //  1146: ldc_w           -378206899
        //  1149: ixor           
        //  1150: lookupswitch {
        //          -766036102: 2765
        //          -702731114: 1143
        //          default: 1176
        //        }
        //  1176: goto            1180
        //  1179: athrow         
        //  1180: invokevirtual   dev/nuker/pyro/f4e.0:()V
        //  1183: goto            1187
        //  1186: athrow         
        //  1187: return         
        //  1188: aload_0        
        //  1189: getfield        dev/nuker/pyro/f73.c:Ldev/nuker/pyro/f0p;
        //  1192: getstatic       dev/nuker/pyro/fc.0:I
        //  1195: ifgt            1204
        //  1198: ldc_w           962559894
        //  1201: goto            1207
        //  1204: ldc_w           482708052
        //  1207: ldc_w           643147633
        //  1210: ixor           
        //  1211: lookupswitch {
        //          -1068420927: 1204
        //          520804583: 2755
        //          default: 1236
        //        }
        //  1236: goto            1240
        //  1239: athrow         
        //  1240: invokevirtual   dev/nuker/pyro/f0p.c:()Ljava/lang/Object;
        //  1243: goto            1247
        //  1246: athrow         
        //  1247: checkcast       Ljava/lang/Number;
        //  1250: goto            1254
        //  1253: athrow         
        //  1254: invokevirtual   java/lang/Number.intValue:()I
        //  1257: goto            1261
        //  1260: athrow         
        //  1261: bipush          100
        //  1263: if_icmpeq       1619
        //  1266: aload_2        
        //  1267: aload_2        
        //  1268: goto            1272
        //  1271: athrow         
        //  1272: invokeinterface dev/nuker/pyro/mixin/SPacketEntityVelocityAccessor.getMotionX:()I
        //  1277: goto            1281
        //  1280: athrow         
        //  1281: bipush          100
        //  1283: idiv           
        //  1284: getstatic       dev/nuker/pyro/fc.1:I
        //  1287: ifne            1296
        //  1290: ldc_w           1757304134
        //  1293: goto            1299
        //  1296: ldc_w           -300697224
        //  1299: ldc_w           380974030
        //  1302: ixor           
        //  1303: lookupswitch {
        //          -2143602862: 1296
        //          2114676360: 2769
        //          default: 1328
        //        }
        //  1328: aload_0        
        //  1329: getstatic       dev/nuker/pyro/fc.1:I
        //  1332: ifne            1341
        //  1335: ldc_w           1983778486
        //  1338: goto            1344
        //  1341: ldc_w           -206214833
        //  1344: ldc_w           -1775407030
        //  1347: ixor           
        //  1348: lookupswitch {
        //          -535593220: 1341
        //          1704466693: 1376
        //          default: 2771
        //        }
        //  1376: getfield        dev/nuker/pyro/f73.c:Ldev/nuker/pyro/f0p;
        //  1379: goto            1383
        //  1382: athrow         
        //  1383: invokevirtual   dev/nuker/pyro/f0p.c:()Ljava/lang/Object;
        //  1386: goto            1390
        //  1389: athrow         
        //  1390: checkcast       Ljava/lang/Number;
        //  1393: getstatic       dev/nuker/pyro/fc.c:I
        //  1396: ifne            1405
        //  1399: ldc_w           869607608
        //  1402: goto            1408
        //  1405: ldc_w           -445349956
        //  1408: ldc_w           -1761475030
        //  1411: ixor           
        //  1412: lookupswitch {
        //          -1529401710: 2747
        //          698799622: 1405
        //          default: 1440
        //        }
        //  1440: goto            1444
        //  1443: athrow         
        //  1444: invokevirtual   java/lang/Number.intValue:()I
        //  1447: goto            1451
        //  1450: athrow         
        //  1451: imul           
        //  1452: goto            1456
        //  1455: athrow         
        //  1456: invokeinterface dev/nuker/pyro/mixin/SPacketEntityVelocityAccessor.setMotionX:(I)V
        //  1461: goto            1465
        //  1464: athrow         
        //  1465: aload_2        
        //  1466: getstatic       dev/nuker/pyro/fc.1:I
        //  1469: ifne            1478
        //  1472: ldc_w           437842321
        //  1475: goto            1481
        //  1478: ldc_w           -1990773268
        //  1481: ldc_w           -426509005
        //  1484: ixor           
        //  1485: lookupswitch {
        //          -57996126: 2761
        //          1252549161: 1478
        //          default: 1512
        //        }
        //  1512: aload_2        
        //  1513: getstatic       dev/nuker/pyro/fc.0:I
        //  1516: ifgt            1525
        //  1519: ldc_w           -652444331
        //  1522: goto            1528
        //  1525: ldc_w           -257700368
        //  1528: ldc_w           -1122629763
        //  1531: ixor           
        //  1532: lookupswitch {
        //          1272295919: 1525
        //          1678408232: 2729
        //          default: 1560
        //        }
        //  1560: goto            1564
        //  1563: athrow         
        //  1564: invokeinterface dev/nuker/pyro/mixin/SPacketEntityVelocityAccessor.getMotionZ:()I
        //  1569: goto            1573
        //  1572: athrow         
        //  1573: bipush          100
        //  1575: idiv           
        //  1576: aload_0        
        //  1577: getfield        dev/nuker/pyro/f73.c:Ldev/nuker/pyro/f0p;
        //  1580: goto            1584
        //  1583: athrow         
        //  1584: invokevirtual   dev/nuker/pyro/f0p.c:()Ljava/lang/Object;
        //  1587: goto            1591
        //  1590: athrow         
        //  1591: checkcast       Ljava/lang/Number;
        //  1594: goto            1598
        //  1597: athrow         
        //  1598: invokevirtual   java/lang/Number.intValue:()I
        //  1601: goto            1605
        //  1604: athrow         
        //  1605: imul           
        //  1606: goto            1610
        //  1609: athrow         
        //  1610: invokeinterface dev/nuker/pyro/mixin/SPacketEntityVelocityAccessor.setMotionZ:(I)V
        //  1615: goto            1619
        //  1618: athrow         
        //  1619: aload_0        
        //  1620: getfield        dev/nuker/pyro/f73.0:Ldev/nuker/pyro/f0p;
        //  1623: goto            1627
        //  1626: athrow         
        //  1627: invokevirtual   dev/nuker/pyro/f0p.c:()Ljava/lang/Object;
        //  1630: goto            1634
        //  1633: athrow         
        //  1634: checkcast       Ljava/lang/Number;
        //  1637: getstatic       dev/nuker/pyro/fc.1:I
        //  1640: ifne            1649
        //  1643: ldc_w           627338388
        //  1646: goto            1652
        //  1649: ldc_w           824780539
        //  1652: ldc_w           1209438297
        //  1655: ixor           
        //  1656: lookupswitch {
        //          705042135: 1649
        //          1836252365: 2739
        //          default: 1684
        //        }
        //  1684: goto            1688
        //  1687: athrow         
        //  1688: invokevirtual   java/lang/Number.intValue:()I
        //  1691: goto            1695
        //  1694: athrow         
        //  1695: bipush          100
        //  1697: if_icmpeq       2712
        //  1700: getstatic       dev/nuker/pyro/fc.c:I
        //  1703: ifne            1712
        //  1706: ldc_w           -1959391227
        //  1709: goto            1715
        //  1712: ldc_w           1999420382
        //  1715: ldc_w           -986159448
        //  1718: ixor           
        //  1719: lookupswitch {
        //          -1307255434: 1744
        //          1309570733: 1712
        //          default: 2725
        //        }
        //  1744: aload_2        
        //  1745: aload_2        
        //  1746: goto            1750
        //  1749: athrow         
        //  1750: invokeinterface dev/nuker/pyro/mixin/SPacketEntityVelocityAccessor.getMotionY:()I
        //  1755: goto            1759
        //  1758: athrow         
        //  1759: bipush          100
        //  1761: idiv           
        //  1762: aload_0        
        //  1763: getfield        dev/nuker/pyro/f73.0:Ldev/nuker/pyro/f0p;
        //  1766: goto            1770
        //  1769: athrow         
        //  1770: invokevirtual   dev/nuker/pyro/f0p.c:()Ljava/lang/Object;
        //  1773: goto            1777
        //  1776: athrow         
        //  1777: checkcast       Ljava/lang/Number;
        //  1780: goto            1784
        //  1783: athrow         
        //  1784: invokevirtual   java/lang/Number.intValue:()I
        //  1787: goto            1791
        //  1790: athrow         
        //  1791: imul           
        //  1792: goto            1796
        //  1795: athrow         
        //  1796: invokeinterface dev/nuker/pyro/mixin/SPacketEntityVelocityAccessor.setMotionY:(I)V
        //  1801: goto            1805
        //  1804: athrow         
        //  1805: goto            2712
        //  1808: aload_1        
        //  1809: goto            1813
        //  1812: athrow         
        //  1813: invokevirtual   dev/nuker/pyro/f4e.c:()Lnet/minecraft/network/Packet;
        //  1816: goto            1820
        //  1819: athrow         
        //  1820: instanceof      Lnet/minecraft/network/play/server/SPacketExplosion;
        //  1823: ifeq            2712
        //  1826: aload_0        
        //  1827: getfield        dev/nuker/pyro/f73.c:Ldev/nuker/pyro/f0k;
        //  1830: goto            1834
        //  1833: athrow         
        //  1834: invokevirtual   dev/nuker/pyro/f0k.c:()Ljava/lang/Object;
        //  1837: goto            1841
        //  1840: athrow         
        //  1841: checkcast       Ljava/lang/Boolean;
        //  1844: getstatic       dev/nuker/pyro/fc.1:I
        //  1847: ifne            1856
        //  1850: ldc_w           -173341816
        //  1853: goto            1859
        //  1856: ldc_w           -1512005430
        //  1859: ldc_w           -1493398834
        //  1862: ixor           
        //  1863: lookupswitch {
        //          -101190811: 1856
        //          1398245702: 2723
        //          default: 1888
        //        }
        //  1888: goto            1892
        //  1891: athrow         
        //  1892: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //  1895: goto            1899
        //  1898: athrow         
        //  1899: ifeq            2712
        //  1902: aload_1        
        //  1903: getstatic       dev/nuker/pyro/fc.0:I
        //  1906: ifgt            1915
        //  1909: ldc_w           1945056475
        //  1912: goto            1918
        //  1915: ldc_w           -1646436314
        //  1918: ldc_w           -605536977
        //  1921: ixor           
        //  1922: lookupswitch {
        //          -2040673766: 1915
        //          -1475933708: 2719
        //          default: 1948
        //        }
        //  1948: goto            1952
        //  1951: athrow         
        //  1952: invokevirtual   dev/nuker/pyro/f4e.c:()Lnet/minecraft/network/Packet;
        //  1955: goto            1959
        //  1958: athrow         
        //  1959: dup            
        //  1960: ifnonnull       1993
        //  1963: new             Lkotlin/TypeCastException;
        //  1966: dup            
        //  1967: ldc_w           "\u3d4b\ub250\u8e03\uafb9\u6103\u59a3\u7e41\u6916\uc0dc\ua5aa\u9be8\u1344\uc17b\u731a\u96d2\u4dab\ub210\u4c80\u0347\u0130\u12a4\ufecb\u6a8f\u8a4b\u306f\u3d21\u7fb6\ua969\ud3e4\u7473\u4467\u6bee\u741d\u9570\uc188\u4322\ufdac\u1087\u1a52\u4ce5\u664c\uac0f\u8d30\ufb39\ubaad\ua439\u4c30\u3f08\u4835\ua43e\u7813\u916c\u3351\u6dcd\uf082\u0ef1\u7a49\u0aa2\u9d6f\ud5d6\ue789\u4c6b\u484f\u14ce\u37ec\u518b\u7982\ue7f8\u5df1\u8d84\uebd4\u1df0\uf2c0\ub46d\uc618\u176d\u2aee\u6656\u467c\u7a4a\uca2b\u172b\u2b49\u8ddb\ud617\u3859\u9b95"
        //  1970: goto            1974
        //  1973: athrow         
        //  1974: invokestatic    invokestatic   !!! ERROR
        //  1977: goto            1981
        //  1980: athrow         
        //  1981: goto            1985
        //  1984: athrow         
        //  1985: invokespecial   kotlin/TypeCastException.<init>:(Ljava/lang/String;)V
        //  1988: goto            1992
        //  1991: athrow         
        //  1992: athrow         
        //  1993: checkcast       Lnet/minecraft/network/play/server/SPacketExplosion;
        //  1996: dup            
        //  1997: ifnonnull       2075
        //  2000: new             Lkotlin/TypeCastException;
        //  2003: dup            
        //  2004: ldc_w           "\u3d4b\ub250\u8e03\uafb9\u6103\u59a3\u7e41\u6916\uc0dc\ua5aa\u9be8\u1344\uc17b\u731a\u96d2\u4dab\ub210\u4c80\u0347\u0130\u12a4\ufecb\u6a8f\u8a4b\u306f\u3d21\u7fb6\ua969\ud3e4\u7473\u4467\u6bee\u741d\u9570\uc188\u4322\ufdac\u108d\u1a52\u4ce7\u664c\uac0c\u8d2c\ufb3c\ubaad\ua428\u4c6c\u3f19\u482a\ua438\u7852\u912c\u3359\u6dd0\uf08d\u0ef7\u7a55\u0ae7\u9d12\ud5f6\ue784\u4c69\u485d\u1485\u37eb\u51ab\u7988\ue7fe\u5df8\u8d99\ueb89\u1dca\uf2ff\ub462\uc63a\u1765\u2ae8\u6647\u464a\u7a41\uca34\u1735"
        //  2007: getstatic       dev/nuker/pyro/fc.1:I
        //  2010: ifne            2019
        //  2013: ldc_w           131514149
        //  2016: goto            2022
        //  2019: ldc_w           -1216281924
        //  2022: ldc_w           -97451709
        //  2025: ixor           
        //  2026: lookupswitch {
        //          -1088819686: 2019
        //          -35144090: 2741
        //          default: 2052
        //        }
        //  2052: goto            2056
        //  2055: athrow         
        //  2056: invokestatic    invokestatic   !!! ERROR
        //  2059: goto            2063
        //  2062: athrow         
        //  2063: goto            2067
        //  2066: athrow         
        //  2067: invokespecial   kotlin/TypeCastException.<init>:(Ljava/lang/String;)V
        //  2070: goto            2074
        //  2073: athrow         
        //  2074: athrow         
        //  2075: checkcast       Ldev/nuker/pyro/mixin/SPacketExplosionAccessor;
        //  2078: astore_2       
        //  2079: aload_0        
        //  2080: getfield        dev/nuker/pyro/f73.c:Ldev/nuker/pyro/f0p;
        //  2083: goto            2087
        //  2086: athrow         
        //  2087: invokevirtual   dev/nuker/pyro/f0p.c:()Ljava/lang/Object;
        //  2090: goto            2094
        //  2093: athrow         
        //  2094: checkcast       Ljava/lang/Number;
        //  2097: goto            2101
        //  2100: athrow         
        //  2101: invokevirtual   java/lang/Number.intValue:()I
        //  2104: goto            2108
        //  2107: athrow         
        //  2108: ifne            2156
        //  2111: aload_0        
        //  2112: getfield        dev/nuker/pyro/f73.0:Ldev/nuker/pyro/f0p;
        //  2115: goto            2119
        //  2118: athrow         
        //  2119: invokevirtual   dev/nuker/pyro/f0p.c:()Ljava/lang/Object;
        //  2122: goto            2126
        //  2125: athrow         
        //  2126: checkcast       Ljava/lang/Number;
        //  2129: goto            2133
        //  2132: athrow         
        //  2133: invokevirtual   java/lang/Number.intValue:()I
        //  2136: goto            2140
        //  2139: athrow         
        //  2140: ifne            2156
        //  2143: aload_1        
        //  2144: goto            2148
        //  2147: athrow         
        //  2148: invokevirtual   dev/nuker/pyro/f4e.0:()V
        //  2151: goto            2155
        //  2154: athrow         
        //  2155: return         
        //  2156: aload_0        
        //  2157: getfield        dev/nuker/pyro/f73.c:Ldev/nuker/pyro/f0p;
        //  2160: goto            2164
        //  2163: athrow         
        //  2164: invokevirtual   dev/nuker/pyro/f0p.c:()Ljava/lang/Object;
        //  2167: goto            2171
        //  2170: athrow         
        //  2171: checkcast       Ljava/lang/Number;
        //  2174: getstatic       dev/nuker/pyro/fc.0:I
        //  2177: ifgt            2186
        //  2180: ldc_w           -1583543317
        //  2183: goto            2189
        //  2186: ldc_w           -1970549122
        //  2189: ldc_w           1705708276
        //  2192: ixor           
        //  2193: lookupswitch {
        //          -1003093729: 2731
        //          1551117758: 2186
        //          default: 2220
        //        }
        //  2220: goto            2224
        //  2223: athrow         
        //  2224: invokevirtual   java/lang/Number.intValue:()I
        //  2227: goto            2231
        //  2230: athrow         
        //  2231: bipush          100
        //  2233: if_icmpeq       2242
        //  2236: ldc_w           1384042328
        //  2239: goto            2245
        //  2242: ldc_w           1384042329
        //  2245: ldc_w           -1454123608
        //  2248: ixor           
        //  2249: tableswitch {
        //          -161860128: 2272
        //          -161860127: 2489
        //          default: 2236
        //        }
        //  2272: aload_2        
        //  2273: aload_2        
        //  2274: goto            2278
        //  2277: athrow         
        //  2278: invokeinterface dev/nuker/pyro/mixin/SPacketExplosionAccessor.getMotionX:()F
        //  2283: goto            2287
        //  2286: athrow         
        //  2287: bipush          100
        //  2289: i2f            
        //  2290: fdiv           
        //  2291: aload_0        
        //  2292: getfield        dev/nuker/pyro/f73.c:Ldev/nuker/pyro/f0p;
        //  2295: goto            2299
        //  2298: athrow         
        //  2299: invokevirtual   dev/nuker/pyro/f0p.c:()Ljava/lang/Object;
        //  2302: goto            2306
        //  2305: athrow         
        //  2306: checkcast       Ljava/lang/Number;
        //  2309: goto            2313
        //  2312: athrow         
        //  2313: invokevirtual   java/lang/Number.floatValue:()F
        //  2316: goto            2320
        //  2319: athrow         
        //  2320: fmul           
        //  2321: goto            2325
        //  2324: athrow         
        //  2325: invokeinterface dev/nuker/pyro/mixin/SPacketExplosionAccessor.setMotionX:(F)V
        //  2330: goto            2334
        //  2333: athrow         
        //  2334: aload_2        
        //  2335: aload_2        
        //  2336: goto            2340
        //  2339: athrow         
        //  2340: invokeinterface dev/nuker/pyro/mixin/SPacketExplosionAccessor.getMotionZ:()F
        //  2345: goto            2349
        //  2348: athrow         
        //  2349: bipush          100
        //  2351: i2f            
        //  2352: fdiv           
        //  2353: aload_0        
        //  2354: getfield        dev/nuker/pyro/f73.c:Ldev/nuker/pyro/f0p;
        //  2357: getstatic       dev/nuker/pyro/fc.1:I
        //  2360: ifne            2369
        //  2363: ldc_w           -1460644674
        //  2366: goto            2372
        //  2369: ldc_w           -712886422
        //  2372: ldc_w           -1420571616
        //  2375: ixor           
        //  2376: lookupswitch {
        //          61053086: 2369
        //          2127690570: 2404
        //          default: 2733
        //        }
        //  2404: goto            2408
        //  2407: athrow         
        //  2408: invokevirtual   dev/nuker/pyro/f0p.c:()Ljava/lang/Object;
        //  2411: goto            2415
        //  2414: athrow         
        //  2415: checkcast       Ljava/lang/Number;
        //  2418: goto            2422
        //  2421: athrow         
        //  2422: invokevirtual   java/lang/Number.floatValue:()F
        //  2425: goto            2429
        //  2428: athrow         
        //  2429: fmul           
        //  2430: getstatic       dev/nuker/pyro/fc.1:I
        //  2433: ifne            2442
        //  2436: ldc_w           -647282509
        //  2439: goto            2445
        //  2442: ldc_w           1130931629
        //  2445: ldc_w           1446405326
        //  2448: ixor           
        //  2449: lookupswitch {
        //          -1889721219: 2751
        //          -246613000: 2442
        //          default: 2476
        //        }
        //  2476: goto            2480
        //  2479: athrow         
        //  2480: invokeinterface dev/nuker/pyro/mixin/SPacketExplosionAccessor.setMotionZ:(F)V
        //  2485: goto            2489
        //  2488: athrow         
        //  2489: getstatic       dev/nuker/pyro/fc.0:I
        //  2492: ifgt            2501
        //  2495: ldc_w           320971481
        //  2498: goto            2504
        //  2501: ldc_w           1845047798
        //  2504: ldc_w           181198470
        //  2507: ixor           
        //  2508: lookupswitch {
        //          434994271: 2715
        //          512946677: 2501
        //          default: 2536
        //        }
        //  2536: aload_0        
        //  2537: getfield        dev/nuker/pyro/f73.0:Ldev/nuker/pyro/f0p;
        //  2540: goto            2544
        //  2543: athrow         
        //  2544: invokevirtual   dev/nuker/pyro/f0p.c:()Ljava/lang/Object;
        //  2547: goto            2551
        //  2550: athrow         
        //  2551: checkcast       Ljava/lang/Number;
        //  2554: goto            2558
        //  2557: athrow         
        //  2558: invokevirtual   java/lang/Number.intValue:()I
        //  2561: goto            2565
        //  2564: athrow         
        //  2565: bipush          100
        //  2567: if_icmpeq       2576
        //  2570: ldc_w           1650907080
        //  2573: goto            2579
        //  2576: ldc_w           1650907083
        //  2579: ldc_w           421871961
        //  2582: ixor           
        //  2583: tableswitch {
        //          -158913246: 2604
        //          -158913245: 2712
        //          default: 2570
        //        }
        //  2604: aload_2        
        //  2605: aload_2        
        //  2606: getstatic       dev/nuker/pyro/fc.c:I
        //  2609: ifne            2618
        //  2612: ldc_w           -390651673
        //  2615: goto            2621
        //  2618: ldc_w           -1730393868
        //  2621: ldc_w           1557108565
        //  2624: ixor           
        //  2625: lookupswitch {
        //          -1267157070: 2618
        //          -1005330527: 2652
        //          default: 2757
        //        }
        //  2652: goto            2656
        //  2655: athrow         
        //  2656: invokeinterface dev/nuker/pyro/mixin/SPacketExplosionAccessor.getMotionY:()F
        //  2661: goto            2665
        //  2664: athrow         
        //  2665: bipush          100
        //  2667: i2f            
        //  2668: fdiv           
        //  2669: aload_0        
        //  2670: getfield        dev/nuker/pyro/f73.0:Ldev/nuker/pyro/f0p;
        //  2673: goto            2677
        //  2676: athrow         
        //  2677: invokevirtual   dev/nuker/pyro/f0p.c:()Ljava/lang/Object;
        //  2680: goto            2684
        //  2683: athrow         
        //  2684: checkcast       Ljava/lang/Number;
        //  2687: goto            2691
        //  2690: athrow         
        //  2691: invokevirtual   java/lang/Number.floatValue:()F
        //  2694: goto            2698
        //  2697: athrow         
        //  2698: fmul           
        //  2699: goto            2703
        //  2702: athrow         
        //  2703: invokeinterface dev/nuker/pyro/mixin/SPacketExplosionAccessor.setMotionY:(F)V
        //  2708: goto            2712
        //  2711: athrow         
        //  2712: return         
        //  2713: aconst_null    
        //  2714: athrow         
        //  2715: aconst_null    
        //  2716: athrow         
        //  2717: aconst_null    
        //  2718: athrow         
        //  2719: aconst_null    
        //  2720: athrow         
        //  2721: aconst_null    
        //  2722: athrow         
        //  2723: aconst_null    
        //  2724: athrow         
        //  2725: aconst_null    
        //  2726: athrow         
        //  2727: aconst_null    
        //  2728: athrow         
        //  2729: aconst_null    
        //  2730: athrow         
        //  2731: aconst_null    
        //  2732: athrow         
        //  2733: aconst_null    
        //  2734: athrow         
        //  2735: aconst_null    
        //  2736: athrow         
        //  2737: aconst_null    
        //  2738: athrow         
        //  2739: aconst_null    
        //  2740: athrow         
        //  2741: aconst_null    
        //  2742: athrow         
        //  2743: aconst_null    
        //  2744: athrow         
        //  2745: aconst_null    
        //  2746: athrow         
        //  2747: aconst_null    
        //  2748: athrow         
        //  2749: aconst_null    
        //  2750: athrow         
        //  2751: aconst_null    
        //  2752: athrow         
        //  2753: aconst_null    
        //  2754: athrow         
        //  2755: aconst_null    
        //  2756: athrow         
        //  2757: aconst_null    
        //  2758: athrow         
        //  2759: aconst_null    
        //  2760: athrow         
        //  2761: aconst_null    
        //  2762: athrow         
        //  2763: aconst_null    
        //  2764: athrow         
        //  2765: aconst_null    
        //  2766: athrow         
        //  2767: aconst_null    
        //  2768: athrow         
        //  2769: aconst_null    
        //  2770: athrow         
        //  2771: aconst_null    
        //  2772: athrow         
        //  2773: pop            
        //  2774: goto            24
        //  2777: pop            
        //  2778: aconst_null    
        //  2779: goto            2773
        //  2782: dup            
        //  2783: ifnull          2773
        //  2786: checkcast       Ljava/lang/Throwable;
        //  2789: athrow         
        //  2790: dup            
        //  2791: ifnull          2777
        //  2794: checkcast       Ljava/lang/Throwable;
        //  2797: athrow         
        //  2798: aconst_null    
        //  2799: athrow         
        //    StackMapTable: 01 AF 43 07 00 E2 04 FF 00 0B 00 00 00 01 07 00 E2 FD 00 03 07 00 03 07 00 F7 0C 41 01 1C 58 07 00 EA FF 00 01 00 02 07 00 03 07 00 F7 00 02 07 00 EA 01 5C 07 00 EA 49 07 00 E2 40 07 00 F7 45 07 00 E2 40 07 00 FF 4A 07 00 FF FF 00 01 00 02 07 00 03 07 00 F7 00 02 07 00 FF 01 5C 07 00 FF 05 05 42 01 18 00 46 07 00 C2 40 07 00 43 45 07 00 E2 40 07 01 CC 4C 07 00 E2 40 07 00 F7 45 07 00 E2 40 07 01 CE 11 42 01 1D 4C 07 00 03 FF 00 02 00 02 07 00 03 07 00 F7 00 02 07 00 03 01 5F 07 00 03 45 07 00 C2 40 07 00 80 45 07 00 E2 40 07 01 CC 45 07 00 E2 40 07 01 16 45 07 00 E2 40 01 4F 07 00 F7 FF 00 02 00 02 07 00 03 07 00 F7 00 02 07 00 F7 01 5C 07 00 F7 42 07 00 CC 40 07 00 F7 45 07 00 E2 40 07 01 CE 4D 07 00 E2 FF 00 00 00 02 07 00 03 07 00 F7 00 04 07 01 CE 08 01 C3 08 01 C3 07 00 A0 45 07 00 E2 FF 00 00 00 02 07 00 03 07 00 F7 00 04 07 01 CE 08 01 C3 08 01 C3 07 00 A0 FF 00 02 00 00 00 01 07 00 E2 FF 00 00 00 02 07 00 03 07 00 F7 00 04 07 01 CE 08 01 C3 08 01 C3 07 00 A0 45 07 00 E2 FF 00 00 00 02 07 00 03 07 00 F7 00 02 07 01 CE 07 01 1F 40 07 01 CE 4E 07 01 0D FF 00 02 00 02 07 00 03 07 00 F7 00 02 07 01 0D 01 5C 07 01 0D FC 00 0C 07 01 0D 42 01 1F FF 00 03 00 00 00 01 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 0D 00 01 07 01 0D 45 07 00 E2 40 01 52 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 0D 00 02 07 01 0D 07 01 30 45 07 00 E2 40 07 01 D0 FF 00 29 00 04 07 00 03 07 00 F7 07 01 0D 07 01 D0 00 01 07 00 F7 FF 00 02 00 04 07 00 03 07 00 F7 07 01 0D 07 01 D0 00 02 07 00 F7 01 5F 07 00 F7 FF 00 02 00 00 00 01 07 00 E2 FF 00 00 00 04 07 00 03 07 00 F7 07 01 0D 07 01 D0 00 01 07 00 F7 45 07 00 E2 00 F9 00 02 0B 42 01 1E 4C 07 00 F7 FF 00 02 00 02 07 00 03 07 00 F7 00 02 07 00 F7 01 5F 07 00 F7 42 07 00 D2 40 07 00 F7 45 07 00 E2 40 07 01 CE 49 07 00 E2 40 07 00 F7 45 07 00 E2 40 07 01 CE 4D 07 00 D8 FF 00 00 00 02 07 00 03 07 00 F7 00 04 07 01 CE 08 03 41 08 03 41 07 00 A0 45 07 00 E2 FF 00 00 00 02 07 00 03 07 00 F7 00 04 07 01 CE 08 03 41 08 03 41 07 00 A0 42 07 00 E2 FF 00 00 00 02 07 00 03 07 00 F7 00 04 07 01 CE 08 03 41 08 03 41 07 00 A0 45 07 00 E2 FF 00 00 00 02 07 00 03 07 00 F7 00 02 07 01 CE 07 01 1F 40 07 01 CE 46 07 01 47 45 07 01 47 FF 00 02 00 02 07 00 03 07 00 F7 00 02 07 01 47 01 58 07 01 47 49 07 00 DC FF 00 00 00 02 07 00 03 07 00 F7 00 04 07 01 47 08 03 88 08 03 88 07 00 A0 45 07 00 E2 FF 00 00 00 02 07 00 03 07 00 F7 00 04 07 01 47 08 03 88 08 03 88 07 00 A0 FF 00 0B 00 02 07 00 03 07 00 F7 00 04 07 01 47 08 03 88 08 03 88 07 00 A0 FF 00 02 00 02 07 00 03 07 00 F7 00 05 07 01 47 08 03 88 08 03 88 07 00 A0 01 FF 00 1E 00 02 07 00 03 07 00 F7 00 04 07 01 47 08 03 88 08 03 88 07 00 A0 42 07 00 E2 FF 00 00 00 02 07 00 03 07 00 F7 00 04 07 01 47 08 03 88 08 03 88 07 00 A0 45 07 00 E2 FF 00 00 00 02 07 00 03 07 00 F7 00 02 07 01 47 07 01 1F 40 07 01 47 FF 00 07 00 03 07 00 03 07 00 F7 07 01 53 00 01 07 00 E2 40 07 01 53 47 07 00 E2 40 01 FF 00 0B 00 00 00 01 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 02 01 07 01 59 45 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 02 01 01 49 07 00 E2 40 07 00 5D 45 07 00 E2 40 07 01 CC 45 07 00 E2 40 07 01 5F 45 07 00 E2 40 01 49 07 00 E2 40 07 00 5D 45 07 00 E2 40 07 01 CC 4E 07 01 5F FF 00 02 00 03 07 00 03 07 00 F7 07 01 53 00 02 07 01 5F 01 5D 07 01 5F FF 00 02 00 00 00 01 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 01 07 01 5F 45 07 00 E2 40 01 4F 07 00 F7 FF 00 02 00 03 07 00 03 07 00 F7 07 01 53 00 02 07 00 F7 01 5D 07 00 F7 42 07 00 E2 40 07 00 F7 45 07 00 E2 00 00 4F 07 00 5D FF 00 02 00 03 07 00 03 07 00 F7 07 01 53 00 02 07 00 5D 01 5C 07 00 5D 42 07 00 E2 40 07 00 5D 45 07 00 E2 40 07 01 CC 45 07 00 E2 40 07 01 5F 45 07 00 E2 40 01 49 07 00 C4 FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 02 07 01 53 07 01 53 47 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 02 07 01 53 01 FF 00 0E 00 03 07 00 03 07 00 F7 07 01 53 00 02 07 01 53 01 FF 00 02 00 03 07 00 03 07 00 F7 07 01 53 00 03 07 01 53 01 01 FF 00 1C 00 03 07 00 03 07 00 F7 07 01 53 00 02 07 01 53 01 FF 00 0C 00 03 07 00 03 07 00 F7 07 01 53 00 03 07 01 53 01 07 00 03 FF 00 02 00 03 07 00 03 07 00 F7 07 01 53 00 04 07 01 53 01 07 00 03 01 FF 00 1F 00 03 07 00 03 07 00 F7 07 01 53 00 03 07 01 53 01 07 00 03 FF 00 05 00 00 00 01 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 03 07 01 53 01 07 00 5D 45 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 03 07 01 53 01 07 01 CC FF 00 0E 00 03 07 00 03 07 00 F7 07 01 53 00 03 07 01 53 01 07 01 5F FF 00 02 00 03 07 00 03 07 00 F7 07 01 53 00 04 07 01 53 01 07 01 5F 01 FF 00 1F 00 03 07 00 03 07 00 F7 07 01 53 00 03 07 01 53 01 07 01 5F 42 07 00 DA FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 03 07 01 53 01 07 01 5F 45 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 03 07 01 53 01 01 43 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 02 07 01 53 01 47 07 00 E2 00 4C 07 01 53 FF 00 02 00 03 07 00 03 07 00 F7 07 01 53 00 02 07 01 53 01 5E 07 01 53 FF 00 0C 00 03 07 00 03 07 00 F7 07 01 53 00 02 07 01 53 07 01 53 FF 00 02 00 03 07 00 03 07 00 F7 07 01 53 00 03 07 01 53 07 01 53 01 FF 00 1F 00 03 07 00 03 07 00 F7 07 01 53 00 02 07 01 53 07 01 53 42 07 00 D2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 02 07 01 53 07 01 53 47 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 02 07 01 53 01 49 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 03 07 01 53 01 07 00 5D 45 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 03 07 01 53 01 07 01 CC 45 07 00 DC FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 03 07 01 53 01 07 01 5F 45 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 03 07 01 53 01 01 43 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 02 07 01 53 01 47 07 00 E2 00 46 07 00 DA 40 07 00 5D 45 07 00 E2 40 07 01 CC 4E 07 01 5F FF 00 02 00 03 07 00 03 07 00 F7 07 01 53 00 02 07 01 5F 01 5F 07 01 5F 42 07 00 E2 40 07 01 5F 45 07 00 E2 40 01 10 42 01 1C 44 07 00 D4 FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 02 07 01 53 07 01 53 47 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 02 07 01 53 01 49 07 00 DE FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 03 07 01 53 01 07 00 5D 45 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 03 07 01 53 01 07 01 CC 45 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 03 07 01 53 01 07 01 5F 45 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 03 07 01 53 01 01 43 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 53 00 02 07 01 53 01 47 07 00 E2 00 FA 00 02 FF 00 03 00 00 00 01 07 00 E2 FF 00 00 00 02 07 00 03 07 00 F7 00 01 07 00 F7 45 07 00 E2 40 07 01 CE 4C 07 00 DC 40 07 00 80 45 07 00 E2 40 07 01 CC 4E 07 01 16 FF 00 02 00 02 07 00 03 07 00 F7 00 02 07 01 16 01 5C 07 01 16 FF 00 02 00 00 00 01 07 00 E2 FF 00 00 00 02 07 00 03 07 00 F7 00 01 07 01 16 45 07 00 E2 40 01 4F 07 00 F7 FF 00 02 00 02 07 00 03 07 00 F7 00 02 07 00 F7 01 5D 07 00 F7 42 07 00 E2 40 07 00 F7 45 07 00 E2 40 07 01 CE FF 00 0D 00 00 00 01 07 00 E2 FF 00 00 00 02 07 00 03 07 00 F7 00 04 07 01 CE 08 07 AB 08 07 AB 07 00 A0 45 07 00 E2 FF 00 00 00 02 07 00 03 07 00 F7 00 04 07 01 CE 08 07 AB 08 07 AB 07 00 A0 FF 00 02 00 00 00 01 07 00 E2 FF 00 00 00 02 07 00 03 07 00 F7 00 04 07 01 CE 08 07 AB 08 07 AB 07 00 A0 45 07 00 E2 FF 00 00 00 02 07 00 03 07 00 F7 00 02 07 01 CE 07 01 1F 40 07 01 CE FF 00 19 00 02 07 00 03 07 00 F7 00 04 07 01 95 08 07 D0 08 07 D0 07 00 A0 FF 00 02 00 02 07 00 03 07 00 F7 00 05 07 01 95 08 07 D0 08 07 D0 07 00 A0 01 FF 00 1D 00 02 07 00 03 07 00 F7 00 04 07 01 95 08 07 D0 08 07 D0 07 00 A0 42 07 00 E2 FF 00 00 00 02 07 00 03 07 00 F7 00 04 07 01 95 08 07 D0 08 07 D0 07 00 A0 45 07 00 E2 FF 00 00 00 02 07 00 03 07 00 F7 00 04 07 01 95 08 07 D0 08 07 D0 07 00 A0 FF 00 02 00 00 00 01 07 00 E2 FF 00 00 00 02 07 00 03 07 00 F7 00 04 07 01 95 08 07 D0 08 07 D0 07 00 A0 45 07 00 E2 FF 00 00 00 02 07 00 03 07 00 F7 00 02 07 01 95 07 01 1F 40 07 01 95 FF 00 0A 00 03 07 00 03 07 00 F7 07 01 A4 00 01 07 00 E2 40 07 00 5D 45 07 00 E2 40 07 01 CC 45 07 00 E2 40 07 01 5F 45 07 00 E2 40 01 FF 00 09 00 00 00 01 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 01 07 00 5D 45 07 00 E2 40 07 01 CC 45 07 00 DC 40 07 01 5F 45 07 00 E2 40 01 46 07 00 E2 40 07 00 F7 45 07 00 E2 00 00 46 07 00 E2 40 07 00 5D 45 07 00 E2 40 07 01 CC 4E 07 01 5F FF 00 02 00 03 07 00 03 07 00 F7 07 01 A4 00 02 07 01 5F 01 5E 07 01 5F 42 07 00 E2 40 07 01 5F 45 07 00 E2 40 01 04 05 42 01 1A 44 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 02 07 01 A4 07 01 A4 47 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 02 07 01 A4 02 FF 00 0A 00 00 00 01 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 03 07 01 A4 02 07 00 5D 45 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 03 07 01 A4 02 07 01 CC 45 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 03 07 01 A4 02 07 01 5F 45 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 03 07 01 A4 02 02 43 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 02 07 01 A4 02 47 07 00 E2 00 44 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 02 07 01 A4 07 01 A4 47 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 02 07 01 A4 02 FF 00 13 00 03 07 00 03 07 00 F7 07 01 A4 00 03 07 01 A4 02 07 00 5D FF 00 02 00 03 07 00 03 07 00 F7 07 01 A4 00 04 07 01 A4 02 07 00 5D 01 FF 00 1F 00 03 07 00 03 07 00 F7 07 01 A4 00 03 07 01 A4 02 07 00 5D 42 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 03 07 01 A4 02 07 00 5D 45 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 03 07 01 A4 02 07 01 CC 45 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 03 07 01 A4 02 07 01 5F 45 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 03 07 01 A4 02 02 FF 00 0C 00 03 07 00 03 07 00 F7 07 01 A4 00 02 07 01 A4 02 FF 00 02 00 03 07 00 03 07 00 F7 07 01 A4 00 03 07 01 A4 02 01 FF 00 1E 00 03 07 00 03 07 00 F7 07 01 A4 00 02 07 01 A4 02 FF 00 02 00 00 00 01 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 02 07 01 A4 02 47 07 00 E2 00 0B 42 01 1F 46 07 00 E2 40 07 00 5D 45 07 00 E2 40 07 01 CC 45 07 00 E2 40 07 01 5F 45 07 00 E2 40 01 04 05 42 01 18 FF 00 0D 00 03 07 00 03 07 00 F7 07 01 A4 00 02 07 01 A4 07 01 A4 FF 00 02 00 03 07 00 03 07 00 F7 07 01 A4 00 03 07 01 A4 07 01 A4 01 FF 00 1E 00 03 07 00 03 07 00 F7 07 01 A4 00 02 07 01 A4 07 01 A4 FF 00 02 00 00 00 01 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 02 07 01 A4 07 01 A4 47 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 02 07 01 A4 02 FF 00 0A 00 00 00 01 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 03 07 01 A4 02 07 00 5D 45 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 03 07 01 A4 02 07 01 CC 45 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 03 07 01 A4 02 07 01 5F 45 07 00 E2 FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 03 07 01 A4 02 02 43 07 00 CA FF 00 00 00 03 07 00 03 07 00 F7 07 01 A4 00 02 07 01 A4 02 47 07 00 E2 FA 00 00 FC 00 00 07 01 0D FF 00 01 00 03 07 00 03 07 00 F7 07 01 A4 00 00 FA 00 01 41 07 00 F7 41 07 01 0D 41 07 01 16 FC 00 01 07 01 53 FF 00 01 00 02 07 00 03 07 00 F7 00 01 07 00 F7 FF 00 01 00 03 07 00 03 07 00 F7 07 01 53 00 02 07 01 53 07 01 53 FF 00 01 00 03 07 00 03 07 00 F7 07 01 A4 00 01 07 01 5F FF 00 01 00 03 07 00 03 07 00 F7 07 01 A4 00 03 07 01 A4 02 07 00 5D FA 00 01 41 07 00 EA FF 00 01 00 03 07 00 03 07 00 F7 07 01 53 00 01 07 01 5F FF 00 01 00 02 07 00 03 07 00 F7 00 04 07 01 95 08 07 D0 08 07 D0 07 00 A0 41 07 00 FF FF 00 01 00 04 07 00 03 07 00 F7 07 01 0D 07 01 D0 00 01 07 00 F7 FF 00 01 00 03 07 00 03 07 00 F7 07 01 53 00 03 07 01 53 01 07 01 5F FF 00 01 00 02 07 00 03 07 00 F7 00 04 07 01 47 08 03 88 08 03 88 07 00 A0 FF 00 01 00 03 07 00 03 07 00 F7 07 01 A4 00 02 07 01 A4 02 FF 00 01 00 02 07 00 03 07 00 F7 00 01 07 00 03 FF 00 01 00 03 07 00 03 07 00 F7 07 01 53 00 01 07 00 5D FF 00 01 00 03 07 00 03 07 00 F7 07 01 A4 00 02 07 01 A4 07 01 A4 FF 00 01 00 02 07 00 03 07 00 F7 00 01 07 00 F7 FF 00 01 00 03 07 00 03 07 00 F7 07 01 53 00 01 07 01 53 FA 00 01 FF 00 01 00 03 07 00 03 07 00 F7 07 01 53 00 01 07 00 F7 41 07 01 5F FF 00 01 00 03 07 00 03 07 00 F7 07 01 53 00 02 07 01 53 01 FF 00 01 00 03 07 00 03 07 00 F7 07 01 53 00 03 07 01 53 01 07 00 03 FF 00 01 00 02 07 00 03 07 00 F7 00 01 07 00 E2 43 05 44 07 00 E2 47 05 47 07 00 E2
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     2782   2790   Ljava/lang/NullPointerException;
        //  2782   2790   2782   2790   Any
        //  2798   2800   3      8      Any
        //  134    141    141    142    Any
        //  135    141    141    142    Any
        //  135    141    141    142    Ljava/lang/ClassCastException;
        //  135    141    141    142    Ljava/lang/UnsupportedOperationException;
        //  135    141    134    135    Any
        //  232    239    239    240    Any
        //  232    239    239    240    Ljava/lang/NullPointerException;
        //  232    239    239    240    Any
        //  233    239    232    233    Ljava/lang/NullPointerException;
        //  233    239    3      8      Ljava/lang/NullPointerException;
        //  253    260    260    261    Any
        //  254    260    253    254    Ljava/lang/AssertionError;
        //  254    260    253    254    Any
        //  254    260    253    254    Any
        //  253    260    260    261    Any
        //  366    373    373    374    Any
        //  366    373    373    374    Ljava/lang/ArithmeticException;
        //  367    373    366    367    Ljava/lang/NullPointerException;
        //  367    373    3      8      Any
        //  367    373    3      8      Any
        //  380    387    387    388    Any
        //  380    387    380    381    Any
        //  380    387    3      8      Any
        //  380    387    387    388    Any
        //  380    387    3      8      Any
        //  439    446    446    447    Any
        //  439    446    439    440    Ljava/lang/NegativeArraySizeException;
        //  439    446    3      8      Any
        //  440    446    446    447    Any
        //  440    446    446    447    Ljava/util/ConcurrentModificationException;
        //  461    468    468    469    Any
        //  461    468    468    469    Ljava/lang/NullPointerException;
        //  461    468    468    469    Any
        //  462    468    468    469    Ljava/util/ConcurrentModificationException;
        //  461    468    461    462    Any
        //  473    479    479    480    Any
        //  473    479    479    480    Ljava/lang/UnsupportedOperationException;
        //  473    479    3      8      Any
        //  473    479    3      8      Any
        //  473    479    479    480    Ljava/lang/StringIndexOutOfBoundsException;
        //  581    587    587    588    Any
        //  581    587    3      8      Any
        //  581    587    587    588    Ljava/lang/IllegalArgumentException;
        //  581    587    3      8      Any
        //  581    587    3      8      Any
        //  607    614    614    615    Any
        //  607    614    607    608    Ljava/lang/NullPointerException;
        //  608    614    607    608    Any
        //  608    614    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  607    614    607    608    Ljava/util/ConcurrentModificationException;
        //  696    702    702    703    Any
        //  696    702    3      8      Any
        //  696    702    3      8      Ljava/lang/IllegalStateException;
        //  696    702    3      8      Ljava/lang/IllegalStateException;
        //  696    702    702    703    Ljava/lang/IllegalStateException;
        //  803    810    810    811    Any
        //  804    810    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  804    810    3      8      Ljava/lang/ArithmeticException;
        //  804    810    803    804    Ljava/lang/IllegalArgumentException;
        //  804    810    3      8      Any
        //  821    828    828    829    Any
        //  822    828    3      8      Any
        //  821    828    3      8      Ljava/lang/NullPointerException;
        //  822    828    3      8      Any
        //  821    828    821    822    Any
        //  843    850    850    851    Any
        //  843    850    3      8      Ljava/lang/ArithmeticException;
        //  844    850    850    851    Any
        //  844    850    850    851    Ljava/lang/IllegalArgumentException;
        //  843    850    843    844    Ljava/lang/EnumConstantNotPresentException;
        //  854    861    861    862    Any
        //  854    861    854    855    Any
        //  855    861    854    855    Ljava/lang/NullPointerException;
        //  855    861    861    862    Ljava/lang/IllegalStateException;
        //  854    861    854    855    Any
        //  914    921    921    922    Any
        //  914    921    3      8      Any
        //  915    921    914    915    Ljava/lang/IllegalArgumentException;
        //  914    921    914    915    Ljava/lang/UnsupportedOperationException;
        //  914    921    3      8      Ljava/lang/NumberFormatException;
        //  971    978    978    979    Any
        //  971    978    3      8      Ljava/lang/NullPointerException;
        //  971    978    978    979    Ljava/lang/RuntimeException;
        //  972    978    971    972    Any
        //  971    978    3      8      Ljava/lang/ArithmeticException;
        //  988    997    997    998    Any
        //  988    997    3      8      Any
        //  989    997    3      8      Any
        //  988    997    988    989    Ljava/lang/UnsupportedOperationException;
        //  989    997    988    989    Any
        //  1011   1017   1017   1018   Any
        //  1011   1017   3      8      Any
        //  1011   1017   1017   1018   Ljava/util/ConcurrentModificationException;
        //  1011   1017   3      8      Ljava/lang/NumberFormatException;
        //  1011   1017   3      8      Any
        //  1028   1035   1035   1036   Any
        //  1029   1035   3      8      Any
        //  1028   1035   1035   1036   Any
        //  1029   1035   1035   1036   Ljava/lang/NegativeArraySizeException;
        //  1028   1035   1028   1029   Any
        //  1042   1049   1049   1050   Any
        //  1043   1049   1049   1050   Any
        //  1042   1049   3      8      Ljava/lang/IllegalArgumentException;
        //  1043   1049   1042   1043   Any
        //  1043   1049   3      8      Any
        //  1060   1067   1067   1068   Any
        //  1061   1067   1060   1061   Ljava/util/ConcurrentModificationException;
        //  1061   1067   1060   1061   Any
        //  1060   1067   3      8      Ljava/lang/UnsupportedOperationException;
        //  1060   1067   1060   1061   Ljava/util/NoSuchElementException;
        //  1120   1126   1126   1127   Any
        //  1120   1126   1126   1127   Ljava/lang/IllegalStateException;
        //  1120   1126   1126   1127   Ljava/lang/IllegalStateException;
        //  1120   1126   1126   1127   Ljava/lang/StringIndexOutOfBoundsException;
        //  1120   1126   3      8      Any
        //  1179   1186   1186   1187   Any
        //  1180   1186   1179   1180   Any
        //  1179   1186   1179   1180   Any
        //  1179   1186   3      8      Any
        //  1179   1186   1179   1180   Any
        //  1239   1246   1246   1247   Any
        //  1239   1246   1239   1240   Any
        //  1240   1246   3      8      Ljava/lang/IllegalStateException;
        //  1240   1246   3      8      Ljava/lang/ArithmeticException;
        //  1240   1246   3      8      Ljava/lang/UnsupportedOperationException;
        //  1253   1260   1260   1261   Any
        //  1254   1260   1260   1261   Any
        //  1254   1260   1253   1254   Ljava/lang/IllegalStateException;
        //  1253   1260   1253   1254   Ljava/lang/IllegalArgumentException;
        //  1254   1260   1253   1254   Any
        //  1271   1280   1280   1281   Any
        //  1272   1280   1271   1272   Ljava/lang/ClassCastException;
        //  1272   1280   3      8      Any
        //  1271   1280   1280   1281   Ljava/lang/RuntimeException;
        //  1271   1280   1271   1272   Ljava/lang/ClassCastException;
        //  1383   1389   1389   1390   Any
        //  1383   1389   3      8      Ljava/lang/RuntimeException;
        //  1383   1389   3      8      Ljava/util/ConcurrentModificationException;
        //  1383   1389   1389   1390   Ljava/lang/EnumConstantNotPresentException;
        //  1383   1389   1389   1390   Ljava/lang/NegativeArraySizeException;
        //  1443   1450   1450   1451   Any
        //  1443   1450   3      8      Ljava/lang/IllegalArgumentException;
        //  1443   1450   1450   1451   Ljava/lang/EnumConstantNotPresentException;
        //  1443   1450   3      8      Any
        //  1444   1450   1443   1444   Ljava/lang/NumberFormatException;
        //  1455   1464   1464   1465   Any
        //  1456   1464   3      8      Any
        //  1456   1464   3      8      Any
        //  1455   1464   1455   1456   Any
        //  1456   1464   1455   1456   Any
        //  1563   1572   1572   1573   Any
        //  1564   1572   1572   1573   Ljava/lang/StringIndexOutOfBoundsException;
        //  1563   1572   1563   1564   Ljava/lang/IllegalArgumentException;
        //  1564   1572   3      8      Any
        //  1564   1572   1572   1573   Ljava/lang/NegativeArraySizeException;
        //  1583   1590   1590   1591   Any
        //  1584   1590   3      8      Any
        //  1583   1590   1590   1591   Any
        //  1584   1590   1583   1584   Any
        //  1583   1590   1590   1591   Any
        //  1597   1604   1604   1605   Any
        //  1597   1604   3      8      Ljava/lang/ArithmeticException;
        //  1597   1604   1597   1598   Ljava/lang/NullPointerException;
        //  1597   1604   1597   1598   Ljava/lang/IllegalArgumentException;
        //  1598   1604   3      8      Any
        //  1609   1618   1618   1619   Any
        //  1609   1618   1618   1619   Ljava/lang/RuntimeException;
        //  1609   1618   1618   1619   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1609   1618   3      8      Ljava/lang/ArithmeticException;
        //  1609   1618   1609   1610   Any
        //  1626   1633   1633   1634   Any
        //  1627   1633   3      8      Ljava/lang/NegativeArraySizeException;
        //  1626   1633   1626   1627   Ljava/lang/NumberFormatException;
        //  1626   1633   1633   1634   Any
        //  1626   1633   1633   1634   Ljava/util/ConcurrentModificationException;
        //  1687   1694   1694   1695   Any
        //  1687   1694   1687   1688   Any
        //  1687   1694   1694   1695   Any
        //  1687   1694   1687   1688   Any
        //  1687   1694   3      8      Any
        //  1749   1758   1758   1759   Any
        //  1750   1758   1758   1759   Ljava/lang/NumberFormatException;
        //  1750   1758   1749   1750   Ljava/lang/IndexOutOfBoundsException;
        //  1749   1758   3      8      Ljava/lang/ClassCastException;
        //  1750   1758   3      8      Any
        //  1769   1776   1776   1777   Any
        //  1770   1776   3      8      Any
        //  1769   1776   3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  1770   1776   1769   1770   Ljava/util/NoSuchElementException;
        //  1769   1776   1776   1777   Ljava/lang/IllegalArgumentException;
        //  1783   1790   1790   1791   Any
        //  1783   1790   3      8      Any
        //  1784   1790   1783   1784   Any
        //  1783   1790   3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1783   1790   1790   1791   Ljava/lang/IllegalArgumentException;
        //  1795   1804   1804   1805   Any
        //  1796   1804   1804   1805   Ljava/lang/RuntimeException;
        //  1795   1804   1795   1796   Ljava/lang/NumberFormatException;
        //  1795   1804   1795   1796   Any
        //  1795   1804   1804   1805   Any
        //  1813   1819   1819   1820   Any
        //  1813   1819   1819   1820   Ljava/lang/ClassCastException;
        //  1813   1819   3      8      Ljava/util/ConcurrentModificationException;
        //  1813   1819   1819   1820   Ljava/lang/NegativeArraySizeException;
        //  1813   1819   1819   1820   Ljava/lang/ArithmeticException;
        //  1833   1840   1840   1841   Any
        //  1834   1840   1840   1841   Any
        //  1834   1840   1833   1834   Ljava/lang/IllegalArgumentException;
        //  1834   1840   1833   1834   Ljava/lang/NegativeArraySizeException;
        //  1834   1840   1840   1841   Ljava/lang/UnsupportedOperationException;
        //  1892   1898   1898   1899   Any
        //  1892   1898   1898   1899   Any
        //  1892   1898   3      8      Ljava/lang/IllegalStateException;
        //  1892   1898   1898   1899   Any
        //  1892   1898   3      8      Ljava/util/ConcurrentModificationException;
        //  1951   1958   1958   1959   Any
        //  1951   1958   1958   1959   Ljava/lang/NumberFormatException;
        //  1951   1958   1951   1952   Ljava/lang/UnsupportedOperationException;
        //  1951   1958   1958   1959   Ljava/lang/UnsupportedOperationException;
        //  1952   1958   1951   1952   Any
        //  1974   1980   1980   1981   Any
        //  1974   1980   3      8      Ljava/lang/IndexOutOfBoundsException;
        //  1974   1980   1980   1981   Any
        //  1974   1980   1980   1981   Ljava/lang/ClassCastException;
        //  1974   1980   3      8      Ljava/util/ConcurrentModificationException;
        //  1985   1991   1991   1992   Any
        //  1985   1991   1991   1992   Ljava/util/NoSuchElementException;
        //  1985   1991   3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1985   1991   3      8      Ljava/lang/IndexOutOfBoundsException;
        //  1985   1991   1991   1992   Any
        //  2055   2062   2062   2063   Any
        //  2056   2062   2055   2056   Ljava/util/ConcurrentModificationException;
        //  2056   2062   3      8      Any
        //  2056   2062   2055   2056   Any
        //  2056   2062   2062   2063   Any
        //  2067   2073   2073   2074   Any
        //  2067   2073   2073   2074   Any
        //  2067   2073   2073   2074   Any
        //  2067   2073   2073   2074   Any
        //  2067   2073   2073   2074   Ljava/lang/AssertionError;
        //  2086   2093   2093   2094   Any
        //  2087   2093   3      8      Any
        //  2086   2093   2093   2094   Ljava/lang/RuntimeException;
        //  2086   2093   2086   2087   Ljava/lang/IllegalArgumentException;
        //  2086   2093   2086   2087   Any
        //  2100   2107   2107   2108   Any
        //  2101   2107   3      8      Any
        //  2101   2107   3      8      Any
        //  2100   2107   2100   2101   Any
        //  2101   2107   2107   2108   Ljava/lang/UnsupportedOperationException;
        //  2119   2125   2125   2126   Any
        //  2119   2125   2125   2126   Ljava/lang/NumberFormatException;
        //  2119   2125   2125   2126   Ljava/lang/AssertionError;
        //  2119   2125   3      8      Any
        //  2119   2125   3      8      Ljava/util/ConcurrentModificationException;
        //  2132   2139   2139   2140   Any
        //  2132   2139   2132   2133   Ljava/util/NoSuchElementException;
        //  2133   2139   2132   2133   Ljava/lang/EnumConstantNotPresentException;
        //  2132   2139   2132   2133   Ljava/util/ConcurrentModificationException;
        //  2132   2139   2139   2140   Ljava/lang/IllegalStateException;
        //  2147   2154   2154   2155   Any
        //  2147   2154   2147   2148   Any
        //  2147   2154   2147   2148   Ljava/util/ConcurrentModificationException;
        //  2148   2154   3      8      Any
        //  2148   2154   2147   2148   Ljava/lang/ArithmeticException;
        //  2163   2170   2170   2171   Any
        //  2164   2170   2170   2171   Any
        //  2164   2170   2163   2164   Any
        //  2164   2170   2163   2164   Any
        //  2163   2170   2163   2164   Any
        //  2223   2230   2230   2231   Any
        //  2224   2230   3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  2223   2230   2230   2231   Any
        //  2224   2230   2223   2224   Any
        //  2224   2230   2223   2224   Any
        //  2277   2286   2286   2287   Any
        //  2277   2286   3      8      Any
        //  2277   2286   2277   2278   Any
        //  2278   2286   2286   2287   Ljava/lang/NullPointerException;
        //  2278   2286   2286   2287   Ljava/lang/IllegalStateException;
        //  2299   2305   2305   2306   Any
        //  2299   2305   2305   2306   Any
        //  2299   2305   3      8      Ljava/lang/AssertionError;
        //  2299   2305   2305   2306   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  2299   2305   3      8      Any
        //  2312   2319   2319   2320   Any
        //  2313   2319   2312   2313   Any
        //  2312   2319   2312   2313   Ljava/lang/NegativeArraySizeException;
        //  2312   2319   2312   2313   Any
        //  2312   2319   3      8      Any
        //  2324   2333   2333   2334   Any
        //  2324   2333   3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  2325   2333   2324   2325   Any
        //  2324   2333   3      8      Ljava/lang/UnsupportedOperationException;
        //  2325   2333   3      8      Ljava/lang/UnsupportedOperationException;
        //  2339   2348   2348   2349   Any
        //  2339   2348   3      8      Ljava/util/NoSuchElementException;
        //  2339   2348   2339   2340   Any
        //  2339   2348   2348   2349   Ljava/lang/IndexOutOfBoundsException;
        //  2339   2348   2339   2340   Any
        //  2407   2414   2414   2415   Any
        //  2408   2414   3      8      Any
        //  2408   2414   2407   2408   Any
        //  2408   2414   2407   2408   Any
        //  2408   2414   2414   2415   Any
        //  2421   2428   2428   2429   Any
        //  2422   2428   2421   2422   Any
        //  2421   2428   3      8      Any
        //  2421   2428   2421   2422   Ljava/lang/UnsupportedOperationException;
        //  2422   2428   3      8      Any
        //  2480   2488   2488   2489   Any
        //  2480   2488   2488   2489   Ljava/lang/StringIndexOutOfBoundsException;
        //  2480   2488   3      8      Any
        //  2480   2488   2488   2489   Any
        //  2480   2488   3      8      Any
        //  2543   2550   2550   2551   Any
        //  2544   2550   3      8      Any
        //  2544   2550   3      8      Any
        //  2543   2550   2543   2544   Any
        //  2543   2550   3      8      Ljava/lang/UnsupportedOperationException;
        //  2557   2564   2564   2565   Any
        //  2557   2564   2564   2565   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  2558   2564   2564   2565   Ljava/lang/StringIndexOutOfBoundsException;
        //  2558   2564   3      8      Ljava/lang/UnsupportedOperationException;
        //  2558   2564   2557   2558   Any
        //  2656   2664   2664   2665   Any
        //  2656   2664   2664   2665   Ljava/util/NoSuchElementException;
        //  2656   2664   3      8      Any
        //  2656   2664   2664   2665   Any
        //  2656   2664   2664   2665   Ljava/lang/NegativeArraySizeException;
        //  2677   2683   2683   2684   Any
        //  2677   2683   3      8      Any
        //  2677   2683   2683   2684   Any
        //  2677   2683   2683   2684   Ljava/lang/StringIndexOutOfBoundsException;
        //  2677   2683   3      8      Any
        //  2690   2697   2697   2698   Any
        //  2691   2697   3      8      Any
        //  2690   2697   2690   2691   Any
        //  2691   2697   2690   2691   Ljava/lang/RuntimeException;
        //  2690   2697   3      8      Any
        //  2702   2711   2711   2712   Any
        //  2702   2711   2702   2703   Ljava/lang/ArithmeticException;
        //  2703   2711   2711   2712   Ljava/lang/RuntimeException;
        //  2702   2711   3      8      Ljava/lang/NegativeArraySizeException;
        //  2703   2711   2711   2712   Ljava/lang/ArithmeticException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:667)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
