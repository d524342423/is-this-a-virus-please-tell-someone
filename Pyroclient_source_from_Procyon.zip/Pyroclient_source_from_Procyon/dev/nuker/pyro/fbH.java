// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

public enum fbH
{
    public static fbH c;
    public static fbH 0;
    public static fbH 1;
    public static fbH[] c;
    
    public fbH(final String name, final int ordinal) {
        while (true) {
            Label_0014: {
                if (fc.1 == 0) {
                    n = 435921186;
                    break Label_0014;
                }
                n = -1261820831;
            }
            switch (n ^ 0x4A728575) {
                case 1401496663: {
                    continue;
                }
                case -21454572: {
                    while (true) {
                        int n2 = 0;
                        Label_0058: {
                            if (fc.0 <= 0) {
                                n2 = -1168159086;
                                break Label_0058;
                            }
                            n2 = 1979914389;
                        }
                        switch (n2 ^ 0xE4F1EEDE) {
                            case 1461796686: {
                                continue;
                            }
                            default: {
                                super(name, ordinal);
                                return;
                            }
                            case 1588502604: {
                                throw null;
                            }
                        }
                        break;
                    }
                    break;
                }
                default: {
                    throw null;
                }
            }
            break;
        }
    }
    
    static {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: anewarray       Ldev/nuker/pyro/fbH;
        //     4: dup            
        //     5: dup            
        //     6: iconst_0       
        //     7: new             Ldev/nuker/pyro/fbH;
        //    10: dup            
        //    11: ldc             "\u37a7\ub240\u84c4\ua17b"
        //    13: getstatic       dev/nuker/pyro/fc.1:I
        //    16: ifne            24
        //    19: ldc             767905618
        //    21: goto            26
        //    24: ldc             -799111891
        //    26: ldc             -2039973514
        //    28: ixor           
        //    29: lookupswitch {
        //          -1574018417: 24
        //          -1414711772: 248
        //          default: 56
        //        }
        //    56: invokestatic    invokestatic   !!! ERROR
        //    59: iconst_0       
        //    60: invokespecial   dev/nuker/pyro/fbH.<init>:(Ljava/lang/String;I)V
        //    63: dup            
        //    64: getstatic       dev/nuker/pyro/fc.0:I
        //    67: ifgt            75
        //    70: ldc             1313033234
        //    72: goto            77
        //    75: ldc             128813604
        //    77: ldc             -602271202
        //    79: ixor           
        //    80: lookupswitch {
        //          -1839636980: 75
        //          -608724934: 108
        //          default: 250
        //        }
        //   108: putstatic       dev/nuker/pyro/fbH.c:Ldev/nuker/pyro/fbH;
        //   111: aastore        
        //   112: dup            
        //   113: iconst_1       
        //   114: new             Ldev/nuker/pyro/fbH;
        //   117: dup            
        //   118: ldc             "\u37ad\ub24a\u84c1\ua166"
        //   120: invokestatic    invokestatic   !!! ERROR
        //   123: iconst_1       
        //   124: invokespecial   dev/nuker/pyro/fbH.<init>:(Ljava/lang/String;I)V
        //   127: dup            
        //   128: putstatic       dev/nuker/pyro/fbH.0:Ldev/nuker/pyro/fbH;
        //   131: aastore        
        //   132: dup            
        //   133: iconst_2       
        //   134: new             Ldev/nuker/pyro/fbH;
        //   137: dup            
        //   138: ldc             "\u37a9\ub240\u84c0\ua16b"
        //   140: getstatic       dev/nuker/pyro/fc.0:I
        //   143: ifgt            151
        //   146: ldc             1191230257
        //   148: goto            153
        //   151: ldc             -1784725882
        //   153: ldc             -1406434618
        //   155: ixor           
        //   156: lookupswitch {
        //          -349488649: 244
        //          395894306: 151
        //          default: 184
        //        }
        //   184: invokestatic    invokestatic   !!! ERROR
        //   187: iconst_2       
        //   188: invokespecial   dev/nuker/pyro/fbH.<init>:(Ljava/lang/String;I)V
        //   191: dup            
        //   192: putstatic       dev/nuker/pyro/fbH.1:Ldev/nuker/pyro/fbH;
        //   195: aastore        
        //   196: getstatic       dev/nuker/pyro/fc.c:I
        //   199: ifne            207
        //   202: ldc             1427039535
        //   204: goto            209
        //   207: ldc             1409694845
        //   209: ldc             -2043808244
        //   211: ixor           
        //   212: lookupswitch {
        //          -768882063: 240
        //          -752676061: 207
        //          default: 246
        //        }
        //   240: putstatic       dev/nuker/pyro/fbH.c:[Ldev/nuker/pyro/fbH;
        //   243: return         
        //   244: aconst_null    
        //   245: athrow         
        //   246: aconst_null    
        //   247: athrow         
        //   248: aconst_null    
        //   249: athrow         
        //   250: aconst_null    
        //   251: athrow         
        //    StackMapTable: 00 10 FF 00 18 00 00 00 07 07 00 42 07 00 42 07 00 42 01 08 00 07 08 00 07 07 00 1D FF 00 01 00 00 00 08 07 00 42 07 00 42 07 00 42 01 08 00 07 08 00 07 07 00 1D 01 FF 00 1D 00 00 00 07 07 00 42 07 00 42 07 00 42 01 08 00 07 08 00 07 07 00 1D FF 00 12 00 00 00 06 07 00 42 07 00 42 07 00 42 01 07 00 03 07 00 03 FF 00 01 00 00 00 07 07 00 42 07 00 42 07 00 42 01 07 00 03 07 00 03 01 FF 00 1E 00 00 00 06 07 00 42 07 00 42 07 00 42 01 07 00 03 07 00 03 FF 00 2A 00 00 00 07 07 00 42 07 00 42 07 00 42 01 08 00 86 08 00 86 07 00 1D FF 00 01 00 00 00 08 07 00 42 07 00 42 07 00 42 01 08 00 86 08 00 86 07 00 1D 01 FF 00 1E 00 00 00 07 07 00 42 07 00 42 07 00 42 01 08 00 86 08 00 86 07 00 1D FF 00 16 00 00 00 02 07 00 42 07 00 42 FF 00 01 00 00 00 03 07 00 42 07 00 42 01 FF 00 1E 00 00 00 02 07 00 42 07 00 42 FF 00 03 00 00 00 07 07 00 42 07 00 42 07 00 42 01 08 00 86 08 00 86 07 00 1D FF 00 01 00 00 00 02 07 00 42 07 00 42 FF 00 01 00 00 00 07 07 00 42 07 00 42 07 00 42 01 08 00 07 08 00 07 07 00 1D FF 00 01 00 00 00 06 07 00 42 07 00 42 07 00 42 01 07 00 03 07 00 03
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static fbH c(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          67
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            59
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            51
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: ldc             Ldev/nuker/pyro/fbH;.class
        //    26: aload_0        
        //    27: goto            31
        //    30: athrow         
        //    31: invokestatic    java/lang/Enum.valueOf:(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
        //    34: goto            38
        //    37: athrow         
        //    38: checkcast       Ldev/nuker/pyro/fbH;
        //    41: areturn        
        //    42: pop            
        //    43: goto            24
        //    46: pop            
        //    47: aconst_null    
        //    48: goto            42
        //    51: dup            
        //    52: ifnull          42
        //    55: checkcast       Ljava/lang/Throwable;
        //    58: athrow         
        //    59: dup            
        //    60: ifnull          46
        //    63: checkcast       Ljava/lang/Throwable;
        //    66: athrow         
        //    67: aconst_null    
        //    68: athrow         
        //    StackMapTable: 00 0D 43 07 00 4B 04 FF 00 0B 00 00 00 01 07 00 4B FC 00 03 07 00 1D 45 07 00 49 FF 00 00 00 01 07 00 1D 00 02 07 00 51 07 00 1D 45 07 00 4B 40 07 00 05 43 07 00 4B 43 05 44 07 00 4B 47 05 47 07 00 4B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     51     59     Any
        //  51     59     51     59     Any
        //  67     69     3      8      Any
        //  30     37     37     38     Any
        //  30     37     37     38     Ljava/lang/IllegalStateException;
        //  30     37     3      8      Ljava/lang/EnumConstantNotPresentException;
        //  31     37     3      8      Any
        //  30     37     30     31     Ljava/lang/NullPointerException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 23 out of bounds for length 23
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
