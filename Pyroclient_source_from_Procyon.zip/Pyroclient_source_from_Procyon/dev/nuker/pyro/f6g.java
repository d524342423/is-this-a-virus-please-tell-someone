// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

public enum f6g
{
    public static f6g c;
    public static f6g 0;
    public static f6g 1;
    public static f6g[] c;
    
    public f6g(final String name, final int ordinal) {
    }
    
    public static f6g c(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          67
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            59
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            51
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: ldc             Ldev/nuker/pyro/f6g;.class
        //    26: aload_0        
        //    27: goto            31
        //    30: athrow         
        //    31: invokestatic    java/lang/Enum.valueOf:(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
        //    34: goto            38
        //    37: athrow         
        //    38: checkcast       Ldev/nuker/pyro/f6g;
        //    41: areturn        
        //    42: pop            
        //    43: goto            24
        //    46: pop            
        //    47: aconst_null    
        //    48: goto            42
        //    51: dup            
        //    52: ifnull          42
        //    55: checkcast       Ljava/lang/Throwable;
        //    58: athrow         
        //    59: dup            
        //    60: ifnull          46
        //    63: checkcast       Ljava/lang/Throwable;
        //    66: athrow         
        //    67: aconst_null    
        //    68: athrow         
        //    StackMapTable: 00 0D 43 07 00 1A 04 FF 00 0B 00 00 00 01 07 00 1A FC 00 03 07 00 20 45 07 00 1A FF 00 00 00 01 07 00 20 00 02 07 00 22 07 00 20 45 07 00 1A 40 07 00 05 43 07 00 1A 43 05 44 07 00 1A 47 05 47 07 00 1A
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                  
        //  -----  -----  -----  -----  --------------------------------------
        //  8      20     51     59     Any
        //  51     59     51     59     Any
        //  67     69     3      8      Ljava/lang/NegativeArraySizeException;
        //  30     37     37     38     Any
        //  31     37     30     31     Any
        //  30     37     30     31     Any
        //  30     37     30     31     Ljava/lang/ArithmeticException;
        //  31     37     3      8      Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:543)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ldc             "\u3c96\ub24a\u8ff4\ua17a"
        //     6: invokestatic    invokestatic   !!! ERROR
        //     9: iconst_0       
        //    10: getstatic       dev/nuker/pyro/fc.0:I
        //    13: ifgt            21
        //    16: ldc             -802994286
        //    18: goto            23
        //    21: ldc             894830575
        //    23: ldc             405505728
        //    25: ixor           
        //    26: lookupswitch {
        //          -938950318: 246
        //          -55544982: 21
        //          default: 52
        //        }
        //    52: invokespecial   dev/nuker/pyro/f6g.<init>:(Ljava/lang/String;I)V
        //    55: putstatic       dev/nuker/pyro/f6g.c:Ldev/nuker/pyro/f6g;
        //    58: new             Ldev/nuker/pyro/f6g;
        //    61: dup            
        //    62: ldc             "\u3c9e\ub249\u8fe3\ua15a\u53b0\u585c\u7e42\u68e1\uce1d\u975c"
        //    64: invokestatic    invokestatic   !!! ERROR
        //    67: iconst_1       
        //    68: invokespecial   dev/nuker/pyro/f6g.<init>:(Ljava/lang/String;I)V
        //    71: getstatic       dev/nuker/pyro/fc.1:I
        //    74: ifne            82
        //    77: ldc             -1765813406
        //    79: goto            84
        //    82: ldc             51540700
        //    84: ldc             -579650381
        //    86: ixor           
        //    87: lookupswitch {
        //          -564048273: 112
        //          1271721937: 82
        //          default: 248
        //        }
        //   112: putstatic       dev/nuker/pyro/f6g.0:Ldev/nuker/pyro/f6g;
        //   115: new             Ldev/nuker/pyro/f6g;
        //   118: dup            
        //   119: ldc             "\u3c93\ub240\u8fe3"
        //   121: invokestatic    invokestatic   !!! ERROR
        //   124: iconst_2       
        //   125: getstatic       dev/nuker/pyro/fc.0:I
        //   128: ifgt            136
        //   131: ldc             216013308
        //   133: goto            138
        //   136: ldc             1822082622
        //   138: ldc             -1686034523
        //   140: ixor           
        //   141: lookupswitch {
        //          -1755234727: 136
        //          -149167717: 168
        //          default: 250
        //        }
        //   168: invokespecial   dev/nuker/pyro/f6g.<init>:(Ljava/lang/String;I)V
        //   171: putstatic       dev/nuker/pyro/f6g.1:Ldev/nuker/pyro/f6g;
        //   174: iconst_3       
        //   175: anewarray       Ldev/nuker/pyro/f6g;
        //   178: dup            
        //   179: iconst_0       
        //   180: getstatic       dev/nuker/pyro/f6g.c:Ldev/nuker/pyro/f6g;
        //   183: aastore        
        //   184: dup            
        //   185: iconst_1       
        //   186: getstatic       dev/nuker/pyro/f6g.0:Ldev/nuker/pyro/f6g;
        //   189: aastore        
        //   190: dup            
        //   191: iconst_2       
        //   192: getstatic       dev/nuker/pyro/f6g.1:Ldev/nuker/pyro/f6g;
        //   195: aastore        
        //   196: getstatic       dev/nuker/pyro/fc.1:I
        //   199: ifne            207
        //   202: ldc             -1632733383
        //   204: goto            209
        //   207: ldc             124880943
        //   209: ldc             2078511134
        //   211: ixor           
        //   212: lookupswitch {
        //          -447879385: 207
        //          2089949233: 240
        //          default: 244
        //        }
        //   240: putstatic       dev/nuker/pyro/f6g.c:[Ldev/nuker/pyro/f6g;
        //   243: return         
        //   244: aconst_null    
        //   245: athrow         
        //   246: aconst_null    
        //   247: athrow         
        //   248: aconst_null    
        //   249: athrow         
        //   250: aconst_null    
        //   251: athrow         
        //    StackMapTable: 00 10 FF 00 15 00 00 00 04 08 00 00 08 00 00 07 00 20 01 FF 00 01 00 00 00 05 08 00 00 08 00 00 07 00 20 01 01 FF 00 1C 00 00 00 04 08 00 00 08 00 00 07 00 20 01 5D 07 00 03 FF 00 01 00 00 00 02 07 00 03 01 5B 07 00 03 FF 00 17 00 00 00 04 08 00 73 08 00 73 07 00 20 01 FF 00 01 00 00 00 05 08 00 73 08 00 73 07 00 20 01 01 FF 00 1D 00 00 00 04 08 00 73 08 00 73 07 00 20 01 66 07 00 49 FF 00 01 00 00 00 02 07 00 49 01 5E 07 00 49 43 07 00 49 FF 00 01 00 00 00 04 08 00 00 08 00 00 07 00 20 01 41 07 00 03 FF 00 01 00 00 00 04 08 00 73 08 00 73 07 00 20 01
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
