// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.MovementInput;
import net.minecraft.entity.Entity;
import net.minecraft.client.entity.EntityPlayerSP;

public class fec extends fdZ
{
    public static double 5() {
        return fez.dH(null, 515236368);
    }
    
    public static double 9() {
        return fez.dB(null, 501202499);
    }
    
    public static double 6() {
        return fez.dJ(null, 1485039475);
    }
    
    public static boolean 4() {
        return fez.hN(null, 876040488);
    }
    
    public static void 3(final double n) {
        fez.i5(null, 1736409021, n);
    }
    
    public static double[] 4(final double n) {
        return fez.0s(null, 695684789, n);
    }
    
    public static void f() {
        fez.fV(null, 1295807994);
    }
    
    public static EntityPlayerSP 2() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getstatic       dev/nuker/pyro/fc.0:I
        //     4: ifeq            40
        //     7: pop            
        //     8: aconst_null    
        //     9: goto            32
        //    12: nop            
        //    13: nop            
        //    14: nop            
        //    15: athrow         
        //    16: getstatic       dev/nuker/pyro/fec.c:Lnet/minecraft/client/Minecraft;
        //    19: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //    22: areturn        
        //    23: pop            
        //    24: goto            16
        //    27: pop            
        //    28: aconst_null    
        //    29: goto            23
        //    32: dup            
        //    33: ifnull          23
        //    36: checkcast       Ljava/lang/Throwable;
        //    39: athrow         
        //    40: dup            
        //    41: ifnull          27
        //    44: checkcast       Ljava/lang/Throwable;
        //    47: athrow         
        //    StackMapTable: 00 06 4C 07 00 3D 03 46 07 00 3D 43 05 44 07 00 3D 47 05
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type
        //  -----  -----  -----  -----  ----
        //  0      12     32     40     Any
        //  32     40     32     40     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:543)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        throw t;
    }
    
    public static void 0(final double n) {
        fez.i0(null, 1170558685, n);
    }
    
    public static boolean a() {
        return fez.hK(null, 1588994964);
    }
    
    public static double c(final Entity p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          338
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            330
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            322
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: getstatic       dev/nuker/pyro/fc.c:I
        //    27: ifne            35
        //    30: ldc             150314393
        //    32: goto            37
        //    35: ldc             -1029919959
        //    37: ldc             548217411
        //    39: ixor           
        //    40: lookupswitch {
        //          -500070038: 68
        //          676904922: 35
        //          default: 309
        //        }
        //    68: aload_0        
        //    69: getfield        net/minecraft/entity/Entity.field_70165_t:D
        //    72: aload_0        
        //    73: getfield        net/minecraft/entity/Entity.field_70142_S:D
        //    76: dsub           
        //    77: ldc2_w          2.0
        //    80: goto            84
        //    83: athrow         
        //    84: invokestatic    java/lang/Math.pow:(DD)D
        //    87: goto            91
        //    90: athrow         
        //    91: dstore_1       
        //    92: aload_0        
        //    93: getstatic       dev/nuker/pyro/fc.0:I
        //    96: ifgt            104
        //    99: ldc             -587197833
        //   101: goto            106
        //   104: ldc             567964369
        //   106: ldc             1932927936
        //   108: ixor           
        //   109: lookupswitch {
        //          -1372180041: 104
        //          1391218961: 136
        //          default: 307
        //        }
        //   136: getfield        net/minecraft/entity/Entity.field_70161_v:D
        //   139: aload_0        
        //   140: getstatic       dev/nuker/pyro/fc.c:I
        //   143: ifne            151
        //   146: ldc             -1019301670
        //   148: goto            153
        //   151: ldc             -1762447918
        //   153: ldc             856366248
        //   155: ixor           
        //   156: lookupswitch {
        //          -461503428: 151
        //          -264917902: 305
        //          default: 184
        //        }
        //   184: getfield        net/minecraft/entity/Entity.field_70136_U:D
        //   187: dsub           
        //   188: ldc2_w          2.0
        //   191: goto            195
        //   194: athrow         
        //   195: invokestatic    java/lang/Math.pow:(DD)D
        //   198: goto            202
        //   201: athrow         
        //   202: dstore_3       
        //   203: dload_1        
        //   204: getstatic       dev/nuker/pyro/fc.0:I
        //   207: ifgt            215
        //   210: ldc             1705716959
        //   212: goto            217
        //   215: ldc             1909783965
        //   217: ldc             -1566116041
        //   219: ixor           
        //   220: lookupswitch {
        //          -955393048: 215
        //          -747500886: 248
        //          default: 311
        //        }
        //   248: dload_3        
        //   249: dadd           
        //   250: goto            254
        //   253: athrow         
        //   254: invokestatic    java/lang/Math.sqrt:(D)D
        //   257: goto            261
        //   260: athrow         
        //   261: ldc2_w          20.0
        //   264: dmul           
        //   265: ldc2_w          60.0
        //   268: dmul           
        //   269: ldc2_w          60.0
        //   272: dmul           
        //   273: goto            277
        //   276: athrow         
        //   277: invokestatic    java/lang/Math.floor:(D)D
        //   280: goto            284
        //   283: athrow         
        //   284: ldc2_w          100.0
        //   287: ddiv           
        //   288: goto            292
        //   291: athrow         
        //   292: invokestatic    java/lang/Math.round:(D)J
        //   295: goto            299
        //   298: athrow         
        //   299: ldc2_w          10
        //   302: ldiv           
        //   303: l2d            
        //   304: dreturn        
        //   305: aconst_null    
        //   306: athrow         
        //   307: aconst_null    
        //   308: athrow         
        //   309: aconst_null    
        //   310: athrow         
        //   311: aconst_null    
        //   312: athrow         
        //   313: pop            
        //   314: goto            24
        //   317: pop            
        //   318: aconst_null    
        //   319: goto            313
        //   322: dup            
        //   323: ifnull          313
        //   326: checkcast       Ljava/lang/Throwable;
        //   329: athrow         
        //   330: dup            
        //   331: ifnull          317
        //   334: checkcast       Ljava/lang/Throwable;
        //   337: athrow         
        //   338: aconst_null    
        //   339: athrow         
        //    StackMapTable: 00 2D 43 07 00 3D 04 FF 00 0B 00 00 00 01 07 00 3D FC 00 03 07 00 74 0A 41 01 1E 4E 07 00 5B FF 00 00 00 01 07 00 74 00 02 03 03 45 07 00 3D 40 03 FF 00 0C 00 02 07 00 74 03 00 01 07 00 74 FF 00 01 00 02 07 00 74 03 00 02 07 00 74 01 5D 07 00 74 FF 00 0E 00 02 07 00 74 03 00 02 03 07 00 74 FF 00 01 00 02 07 00 74 03 00 03 03 07 00 74 01 FF 00 1E 00 02 07 00 74 03 00 02 03 07 00 74 49 07 00 5F FF 00 00 00 02 07 00 74 03 00 02 03 03 45 07 00 3D 40 03 FF 00 0C 00 03 07 00 74 03 03 00 01 03 FF 00 01 00 03 07 00 74 03 03 00 02 03 01 5E 03 44 07 00 5D 40 03 45 07 00 3D 40 03 4E 07 00 6B 40 03 45 07 00 3D 40 03 46 07 00 3D 40 03 45 07 00 3D 40 04 FF 00 05 00 02 07 00 74 03 00 02 03 07 00 74 41 07 00 74 FA 00 01 FF 00 01 00 03 07 00 74 03 03 00 01 03 FF 00 01 00 01 07 00 74 00 01 07 00 5D 43 05 44 07 00 5D 47 05 47 07 00 3D
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     322    330    Ljava/lang/IllegalStateException;
        //  322    330    322    330    Ljava/util/NoSuchElementException;
        //  338    340    3      8      Any
        //  83     90     90     91     Any
        //  84     90     90     91     Ljava/lang/ClassCastException;
        //  83     90     83     84     Ljava/util/ConcurrentModificationException;
        //  83     90     3      8      Ljava/lang/RuntimeException;
        //  84     90     90     91     Ljava/lang/ArrayIndexOutOfBoundsException;
        //  194    201    201    202    Any
        //  194    201    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  194    201    201    202    Ljava/lang/UnsupportedOperationException;
        //  195    201    194    195    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  194    201    201    202    Ljava/lang/IllegalArgumentException;
        //  253    260    260    261    Any
        //  253    260    253    254    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  253    260    260    261    Ljava/lang/RuntimeException;
        //  253    260    253    254    Ljava/lang/EnumConstantNotPresentException;
        //  254    260    260    261    Ljava/lang/AssertionError;
        //  276    283    283    284    Any
        //  276    283    276    277    Ljava/lang/ArithmeticException;
        //  276    283    3      8      Any
        //  276    283    283    284    Ljava/lang/NumberFormatException;
        //  276    283    3      8      Ljava/lang/IllegalStateException;
        //  291    298    298    299    Any
        //  291    298    3      8      Any
        //  291    298    298    299    Ljava/lang/AssertionError;
        //  291    298    291    292    Any
        //  291    298    291    292    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 119 out of bounds for length 119
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static MovementInput 0() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          64
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            56
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            48
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: goto            28
        //    27: athrow         
        //    28: invokestatic    dev/nuker/pyro/fec.2:()Lnet/minecraft/client/entity/EntityPlayerSP;
        //    31: goto            35
        //    34: athrow         
        //    35: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71158_b:Lnet/minecraft/util/MovementInput;
        //    38: areturn        
        //    39: pop            
        //    40: goto            24
        //    43: pop            
        //    44: aconst_null    
        //    45: goto            39
        //    48: dup            
        //    49: ifnull          39
        //    52: checkcast       Ljava/lang/Throwable;
        //    55: athrow         
        //    56: dup            
        //    57: ifnull          43
        //    60: checkcast       Ljava/lang/Throwable;
        //    63: athrow         
        //    64: aconst_null    
        //    65: athrow         
        //    StackMapTable: 00 0D 43 07 00 3D 04 4B 07 00 3D 03 42 07 00 3D 00 45 07 00 3D 40 07 00 AA 43 07 00 5D 43 05 44 07 00 5D 47 05 47 07 00 3D
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                      
        //  -----  -----  -----  -----  ------------------------------------------
        //  8      20     48     56     Ljava/lang/ArrayIndexOutOfBoundsException;
        //  48     56     48     56     Ljava/lang/ClassCastException;
        //  64     66     3      8      Any
        //  27     34     34     35     Any
        //  27     34     27     28     Any
        //  28     34     34     35     Any
        //  28     34     3      8      Ljava/lang/IllegalArgumentException;
        //  28     34     3      8      Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 32 out of bounds for length 32
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static float d() {
        return fez.ec(null, 1097858073);
    }
    
    public static void b() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          655
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            647
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            639
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: iconst_0       
        //    25: istore_0       
        //    26: getstatic       dev/nuker/pyro/fc.0:I
        //    29: ifgt            37
        //    32: ldc             184666139
        //    34: goto            39
        //    37: ldc             1402619509
        //    39: ldc             -1077184628
        //    41: ixor           
        //    42: lookupswitch {
        //          -1261781097: 614
        //          2006548845: 37
        //          default: 68
        //        }
        //    68: iload_0        
        //    69: bipush          70
        //    71: if_icmpge       377
        //    74: getstatic       dev/nuker/pyro/fec.c:Lnet/minecraft/client/Minecraft;
        //    77: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //    80: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71174_a:Lnet/minecraft/client/network/NetHandlerPlayClient;
        //    83: new             Lnet/minecraft/network/play/client/CPacketPlayer$Position;
        //    86: dup            
        //    87: getstatic       dev/nuker/pyro/fec.c:Lnet/minecraft/client/Minecraft;
        //    90: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //    93: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70165_t:D
        //    96: getstatic       dev/nuker/pyro/fec.c:Lnet/minecraft/client/Minecraft;
        //    99: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   102: getstatic       dev/nuker/pyro/fc.0:I
        //   105: ifgt            113
        //   108: ldc             -652934014
        //   110: goto            115
        //   113: ldc             -1512377123
        //   115: ldc             118248813
        //   117: ixor           
        //   118: lookupswitch {
        //          -568765969: 618
        //          1276727018: 113
        //          default: 144
        //        }
        //   144: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70163_u:D
        //   147: ldc2_w          0.06
        //   150: dadd           
        //   151: getstatic       dev/nuker/pyro/fec.c:Lnet/minecraft/client/Minecraft;
        //   154: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   157: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70161_v:D
        //   160: iconst_0       
        //   161: goto            165
        //   164: athrow         
        //   165: invokespecial   net/minecraft/network/play/client/CPacketPlayer$Position.<init>:(DDDZ)V
        //   168: goto            172
        //   171: athrow         
        //   172: goto            176
        //   175: athrow         
        //   176: invokevirtual   net/minecraft/client/network/NetHandlerPlayClient.func_147297_a:(Lnet/minecraft/network/Packet;)V
        //   179: goto            183
        //   182: athrow         
        //   183: getstatic       dev/nuker/pyro/fec.c:Lnet/minecraft/client/Minecraft;
        //   186: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   189: getstatic       dev/nuker/pyro/fc.c:I
        //   192: ifne            200
        //   195: ldc             175416390
        //   197: goto            202
        //   200: ldc             -2054504476
        //   202: ldc             765177980
        //   204: ixor           
        //   205: lookupswitch {
        //          -1695281898: 200
        //          669979706: 620
        //          default: 232
        //        }
        //   232: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71174_a:Lnet/minecraft/client/network/NetHandlerPlayClient;
        //   235: new             Lnet/minecraft/network/play/client/CPacketPlayer$Position;
        //   238: dup            
        //   239: getstatic       dev/nuker/pyro/fec.c:Lnet/minecraft/client/Minecraft;
        //   242: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   245: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70165_t:D
        //   248: getstatic       dev/nuker/pyro/fec.c:Lnet/minecraft/client/Minecraft;
        //   251: getstatic       dev/nuker/pyro/fc.c:I
        //   254: ifne            262
        //   257: ldc             -1572592482
        //   259: goto            264
        //   262: ldc             147976150
        //   264: ldc             172409404
        //   266: ixor           
        //   267: lookupswitch {
        //          -1476204894: 262
        //          43462122: 292
        //          default: 626
        //        }
        //   292: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   295: getstatic       dev/nuker/pyro/fc.c:I
        //   298: ifne            306
        //   301: ldc             31338324
        //   303: goto            308
        //   306: ldc             -861910118
        //   308: ldc             -2144805136
        //   310: ixor           
        //   311: lookupswitch {
        //          -2114522716: 612
        //          -2028917181: 306
        //          default: 336
        //        }
        //   336: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70163_u:D
        //   339: getstatic       dev/nuker/pyro/fec.c:Lnet/minecraft/client/Minecraft;
        //   342: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   345: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70161_v:D
        //   348: iconst_0       
        //   349: goto            353
        //   352: athrow         
        //   353: invokespecial   net/minecraft/network/play/client/CPacketPlayer$Position.<init>:(DDDZ)V
        //   356: goto            360
        //   359: athrow         
        //   360: goto            364
        //   363: athrow         
        //   364: invokevirtual   net/minecraft/client/network/NetHandlerPlayClient.func_147297_a:(Lnet/minecraft/network/Packet;)V
        //   367: goto            371
        //   370: athrow         
        //   371: iinc            0, 1
        //   374: goto            26
        //   377: getstatic       dev/nuker/pyro/fc.c:I
        //   380: ifne            388
        //   383: ldc             1640641847
        //   385: goto            390
        //   388: ldc             1072377873
        //   390: ldc             -1846073537
        //   392: ixor           
        //   393: lookupswitch {
        //          -1373890770: 420
        //          -264433144: 388
        //          default: 628
        //        }
        //   420: getstatic       dev/nuker/pyro/fec.c:Lnet/minecraft/client/Minecraft;
        //   423: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   426: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71174_a:Lnet/minecraft/client/network/NetHandlerPlayClient;
        //   429: new             Lnet/minecraft/network/play/client/CPacketPlayer$Position;
        //   432: dup            
        //   433: getstatic       dev/nuker/pyro/fec.c:Lnet/minecraft/client/Minecraft;
        //   436: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   439: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70165_t:D
        //   442: getstatic       dev/nuker/pyro/fec.c:Lnet/minecraft/client/Minecraft;
        //   445: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   448: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70163_u:D
        //   451: ldc2_w          0.1
        //   454: dadd           
        //   455: getstatic       dev/nuker/pyro/fec.c:Lnet/minecraft/client/Minecraft;
        //   458: getstatic       dev/nuker/pyro/fc.0:I
        //   461: ifgt            469
        //   464: ldc             2076591496
        //   466: goto            471
        //   469: ldc             -902860598
        //   471: ldc             1235707446
        //   473: ixor           
        //   474: lookupswitch {
        //          -2088233220: 500
        //          845226942: 469
        //          default: 624
        //        }
        //   500: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   503: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70161_v:D
        //   506: iconst_0       
        //   507: getstatic       dev/nuker/pyro/fc.1:I
        //   510: ifne            518
        //   513: ldc             -1122449194
        //   515: goto            520
        //   518: ldc             -813332301
        //   520: ldc             1471889740
        //   522: ixor           
        //   523: lookupswitch {
        //          -1740715521: 548
        //          -358381158: 518
        //          default: 622
        //        }
        //   548: goto            552
        //   551: athrow         
        //   552: invokespecial   net/minecraft/network/play/client/CPacketPlayer$Position.<init>:(DDDZ)V
        //   555: goto            559
        //   558: athrow         
        //   559: getstatic       dev/nuker/pyro/fc.1:I
        //   562: ifne            570
        //   565: ldc             1674339543
        //   567: goto            572
        //   570: ldc             -1378196711
        //   572: ldc             309430682
        //   574: ixor           
        //   575: lookupswitch {
        //          -956417923: 570
        //          1908272461: 616
        //          default: 600
        //        }
        //   600: goto            604
        //   603: athrow         
        //   604: invokevirtual   net/minecraft/client/network/NetHandlerPlayClient.func_147297_a:(Lnet/minecraft/network/Packet;)V
        //   607: goto            611
        //   610: athrow         
        //   611: return         
        //   612: aconst_null    
        //   613: athrow         
        //   614: aconst_null    
        //   615: athrow         
        //   616: aconst_null    
        //   617: athrow         
        //   618: aconst_null    
        //   619: athrow         
        //   620: aconst_null    
        //   621: athrow         
        //   622: aconst_null    
        //   623: athrow         
        //   624: aconst_null    
        //   625: athrow         
        //   626: aconst_null    
        //   627: athrow         
        //   628: aconst_null    
        //   629: athrow         
        //   630: pop            
        //   631: goto            24
        //   634: pop            
        //   635: aconst_null    
        //   636: goto            630
        //   639: dup            
        //   640: ifnull          630
        //   643: checkcast       Ljava/lang/Throwable;
        //   646: athrow         
        //   647: dup            
        //   648: ifnull          634
        //   651: checkcast       Ljava/lang/Throwable;
        //   654: athrow         
        //   655: aconst_null    
        //   656: athrow         
        //    StackMapTable: 00 47 FF 00 03 00 01 01 00 01 07 00 3D FA 00 04 4B 07 00 3D 03 FC 00 01 01 0A 41 01 1C FF 00 2C 00 01 01 00 05 07 00 D3 08 00 53 08 00 53 03 07 00 AA FF 00 01 00 01 01 00 06 07 00 D3 08 00 53 08 00 53 03 07 00 AA 01 FF 00 1C 00 01 01 00 05 07 00 D3 08 00 53 08 00 53 03 07 00 AA 53 07 00 3D FF 00 00 00 01 01 00 07 07 00 D3 08 00 53 08 00 53 03 03 03 01 45 07 00 3D FF 00 00 00 01 01 00 02 07 00 D3 07 00 C3 42 07 00 5D FF 00 00 00 01 01 00 02 07 00 D3 07 00 C3 45 07 00 3D 00 50 07 00 AA FF 00 01 00 01 01 00 02 07 00 AA 01 5D 07 00 AA FF 00 1D 00 01 01 00 05 07 00 D3 08 00 EB 08 00 EB 03 07 00 43 FF 00 01 00 01 01 00 06 07 00 D3 08 00 EB 08 00 EB 03 07 00 43 01 FF 00 1B 00 01 01 00 05 07 00 D3 08 00 EB 08 00 EB 03 07 00 43 FF 00 0D 00 01 01 00 05 07 00 D3 08 00 EB 08 00 EB 03 07 00 AA FF 00 01 00 01 01 00 06 07 00 D3 08 00 EB 08 00 EB 03 07 00 AA 01 FF 00 1B 00 01 01 00 05 07 00 D3 08 00 EB 08 00 EB 03 07 00 AA 4F 07 00 3D FF 00 00 00 01 01 00 07 07 00 D3 08 00 EB 08 00 EB 03 03 03 01 45 07 00 3D FF 00 00 00 01 01 00 02 07 00 D3 07 00 C3 42 07 00 3D FF 00 00 00 01 01 00 02 07 00 D3 07 00 C3 45 07 00 3D 00 05 0A 41 01 1D FF 00 30 00 01 01 00 06 07 00 D3 08 01 AD 08 01 AD 03 03 07 00 43 FF 00 01 00 01 01 00 07 07 00 D3 08 01 AD 08 01 AD 03 03 07 00 43 01 FF 00 1C 00 01 01 00 06 07 00 D3 08 01 AD 08 01 AD 03 03 07 00 43 FF 00 11 00 01 01 00 07 07 00 D3 08 01 AD 08 01 AD 03 03 03 01 FF 00 01 00 01 01 00 08 07 00 D3 08 01 AD 08 01 AD 03 03 03 01 01 FF 00 1B 00 01 01 00 07 07 00 D3 08 01 AD 08 01 AD 03 03 03 01 42 07 00 3D FF 00 00 00 01 01 00 07 07 00 D3 08 01 AD 08 01 AD 03 03 03 01 45 07 00 3D FF 00 00 00 01 01 00 02 07 00 D3 07 00 C3 FF 00 0A 00 01 01 00 02 07 00 D3 07 00 C3 FF 00 01 00 01 01 00 03 07 00 D3 07 00 C3 01 FF 00 1B 00 01 01 00 02 07 00 D3 07 00 C3 42 07 00 59 FF 00 00 00 01 01 00 02 07 00 D3 07 00 C3 45 07 00 3D 00 FF 00 00 00 01 01 00 05 07 00 D3 08 00 EB 08 00 EB 03 07 00 AA 01 FF 00 01 00 01 01 00 02 07 00 D3 07 00 C3 FF 00 01 00 01 01 00 05 07 00 D3 08 00 53 08 00 53 03 07 00 AA 41 07 00 AA FF 00 01 00 01 01 00 07 07 00 D3 08 01 AD 08 01 AD 03 03 03 01 FF 00 01 00 01 01 00 06 07 00 D3 08 01 AD 08 01 AD 03 03 07 00 43 FF 00 01 00 01 01 00 05 07 00 D3 08 00 EB 08 00 EB 03 07 00 43 01 FF 00 01 00 00 00 01 07 00 3D 43 05 44 07 00 3D 47 05 FF 00 07 00 01 01 00 01 07 00 3D
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     639    647    Any
        //  639    647    639    647    Any
        //  655    657    3      8      Ljava/lang/ClassCastException;
        //  164    171    171    172    Any
        //  164    171    171    172    Ljava/lang/NullPointerException;
        //  164    171    164    165    Any
        //  165    171    171    172    Ljava/lang/IllegalStateException;
        //  165    171    164    165    Any
        //  175    182    182    183    Any
        //  175    182    175    176    Ljava/util/NoSuchElementException;
        //  176    182    175    176    Ljava/util/ConcurrentModificationException;
        //  175    182    175    176    Ljava/lang/IllegalStateException;
        //  175    182    3      8      Any
        //  352    359    359    360    Any
        //  352    359    3      8      Ljava/lang/AssertionError;
        //  352    359    3      8      Ljava/lang/NullPointerException;
        //  352    359    359    360    Ljava/lang/IndexOutOfBoundsException;
        //  353    359    352    353    Any
        //  363    370    370    371    Any
        //  363    370    363    364    Any
        //  363    370    370    371    Any
        //  364    370    363    364    Ljava/lang/IllegalStateException;
        //  364    370    363    364    Ljava/lang/NumberFormatException;
        //  551    558    558    559    Any
        //  552    558    558    559    Any
        //  551    558    551    552    Any
        //  552    558    3      8      Ljava/lang/IllegalStateException;
        //  551    558    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  603    610    610    611    Any
        //  604    610    610    611    Any
        //  604    610    3      8      Ljava/lang/NegativeArraySizeException;
        //  604    610    603    604    Ljava/lang/ClassCastException;
        //  603    610    3      8      Ljava/util/NoSuchElementException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 78 out of bounds for length 78
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static double[] c(final double n) {
        return fez.0s(null, 695684788, n);
    }
    
    public static float e() {
        return fez.eA(null, 177547003);
    }
    
    public static void 2(final double n) {
        fez.ic(null, 2059973521, n);
    }
    
    public static void 1(final float n) {
        fez.aU(null, 1507440738, n);
    }
    
    public static float 3() {
        return fez.ei(null, 1859943286);
    }
    
    public static void 0(final float n) {
        fez.bg(null, 538422834, n);
    }
    
    public static void 5(final double n) {
        fez.hW(null, 416274798, n);
    }
    
    public static void 1(final double n) {
        fez.i6(null, 2065031726, n);
    }
    
    public static float 1() {
        return fez.ez(null, 1197385506);
    }
    
    public static double 8() {
        return fez.dz(null, 177846124);
    }
    
    public static double c() {
        return fez.dx(null, 1122829688);
    }
    
    public static boolean 7() {
        return fez.hK(null, 1588994967);
    }
    
    public static void c(final f4p p0, final double p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          1190
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            1182
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            1174
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: goto            28
        //    27: athrow         
        //    28: invokestatic    dev/nuker/pyro/fec.0:()Lnet/minecraft/util/MovementInput;
        //    31: goto            35
        //    34: athrow         
        //    35: getfield        net/minecraft/util/MovementInput.field_192832_b:F
        //    38: f2d            
        //    39: dstore_3       
        //    40: goto            44
        //    43: athrow         
        //    44: invokestatic    dev/nuker/pyro/fec.0:()Lnet/minecraft/util/MovementInput;
        //    47: goto            51
        //    50: athrow         
        //    51: getfield        net/minecraft/util/MovementInput.field_78902_a:F
        //    54: f2d            
        //    55: dstore          5
        //    57: goto            61
        //    60: athrow         
        //    61: invokestatic    dev/nuker/pyro/fec.d:()F
        //    64: goto            68
        //    67: athrow         
        //    68: fstore          7
        //    70: dload_3        
        //    71: dconst_0       
        //    72: dcmpl          
        //    73: ifne            202
        //    76: getstatic       dev/nuker/pyro/fc.c:I
        //    79: ifne            88
        //    82: ldc_w           -19174567
        //    85: goto            91
        //    88: ldc_w           -19922402
        //    91: ldc_w           -987054594
        //    94: ixor           
        //    95: lookupswitch {
        //          1005704871: 88
        //          1006288864: 120
        //          default: 1155
        //        }
        //   120: dload           5
        //   122: dconst_0       
        //   123: dcmpl          
        //   124: ifne            202
        //   127: aload_0        
        //   128: dconst_0       
        //   129: goto            133
        //   132: athrow         
        //   133: invokevirtual   dev/nuker/pyro/f4p.0:(D)V
        //   136: goto            140
        //   139: athrow         
        //   140: aload_0        
        //   141: dconst_0       
        //   142: getstatic       dev/nuker/pyro/fc.1:I
        //   145: ifne            154
        //   148: ldc_w           -387992600
        //   151: goto            157
        //   154: ldc_w           -43920854
        //   157: ldc_w           -466114368
        //   160: ixor           
        //   161: lookupswitch {
        //          216537896: 1145
        //          1717283501: 154
        //          default: 188
        //        }
        //   188: goto            192
        //   191: athrow         
        //   192: invokevirtual   dev/nuker/pyro/f4p.c:(D)V
        //   195: goto            199
        //   198: athrow         
        //   199: goto            1136
        //   202: dload_3        
        //   203: dconst_0       
        //   204: dcmpl          
        //   205: ifeq            214
        //   208: ldc_w           1411831425
        //   211: goto            217
        //   214: ldc_w           1411831424
        //   217: ldc_w           -886748663
        //   220: ixor           
        //   221: tableswitch {
        //          1040660752: 244
        //          1040660753: 520
        //          default: 208
        //        }
        //   244: dload           5
        //   246: dconst_0       
        //   247: dcmpl          
        //   248: ifle            257
        //   251: ldc_w           -706761356
        //   254: goto            260
        //   257: ldc_w           -706761353
        //   260: ldc_w           1327668573
        //   263: ixor           
        //   264: tableswitch {
        //          905601106: 288
        //          905601107: 310
        //          default: 251
        //        }
        //   288: fload           7
        //   290: dload_3        
        //   291: dconst_0       
        //   292: dcmpl          
        //   293: ifle            301
        //   296: bipush          -45
        //   298: goto            303
        //   301: bipush          45
        //   303: i2f            
        //   304: fadd           
        //   305: fstore          7
        //   307: goto            371
        //   310: dload           5
        //   312: dconst_0       
        //   313: dcmpg          
        //   314: ifge            323
        //   317: ldc_w           621052124
        //   320: goto            326
        //   323: ldc_w           621052123
        //   326: ldc_w           355665919
        //   329: ixor           
        //   330: tableswitch {
        //          1617890886: 352
        //          1617890887: 371
        //          default: 317
        //        }
        //   352: fload           7
        //   354: dload_3        
        //   355: dconst_0       
        //   356: dcmpl          
        //   357: ifle            365
        //   360: bipush          45
        //   362: goto            367
        //   365: bipush          -45
        //   367: i2f            
        //   368: fadd           
        //   369: fstore          7
        //   371: dconst_0       
        //   372: getstatic       dev/nuker/pyro/fc.c:I
        //   375: ifne            384
        //   378: ldc_w           1270206753
        //   381: goto            387
        //   384: ldc_w           2080692457
        //   387: ldc_w           -1752607242
        //   390: ixor           
        //   391: lookupswitch {
        //          -600013609: 384
        //          -343044833: 416
        //          default: 1161
        //        }
        //   416: dstore          5
        //   418: dload_3        
        //   419: dconst_0       
        //   420: dcmpl          
        //   421: ifle            476
        //   424: dconst_1       
        //   425: getstatic       dev/nuker/pyro/fc.1:I
        //   428: ifne            437
        //   431: ldc_w           -1170711721
        //   434: goto            440
        //   437: ldc_w           -1742329661
        //   440: ldc_w           -2128669718
        //   443: ixor           
        //   444: lookupswitch {
        //          -336929993: 437
        //          992430269: 1141
        //          default: 472
        //        }
        //   472: dstore_3       
        //   473: goto            520
        //   476: dload_3        
        //   477: dconst_0       
        //   478: dcmpg          
        //   479: ifge            488
        //   482: ldc_w           -1403646265
        //   485: goto            491
        //   488: ldc_w           -1403646266
        //   491: ldc_w           1743157111
        //   494: ixor           
        //   495: tableswitch {
        //          -1755253920: 516
        //          -1755253919: 520
        //          default: 482
        //        }
        //   516: ldc2_w          -1.0
        //   519: dstore_3       
        //   520: aload_0        
        //   521: getstatic       dev/nuker/pyro/fc.1:I
        //   524: ifne            533
        //   527: ldc_w           -622436061
        //   530: goto            536
        //   533: ldc_w           -767035708
        //   536: ldc_w           2023673432
        //   539: ixor           
        //   540: lookupswitch {
        //          -1569149061: 533
        //          -1428604772: 568
        //          default: 1159
        //        }
        //   568: dload_3        
        //   569: getstatic       dev/nuker/pyro/fc.1:I
        //   572: ifne            581
        //   575: ldc_w           -151445976
        //   578: goto            584
        //   581: ldc_w           -928033025
        //   584: ldc_w           876416488
        //   587: ixor           
        //   588: lookupswitch {
        //          -1027337280: 581
        //          -57517289: 616
        //          default: 1149
        //        }
        //   616: dload_1        
        //   617: dmul           
        //   618: getstatic       dev/nuker/pyro/fc.0:I
        //   621: ifgt            630
        //   624: ldc_w           1045467970
        //   627: goto            633
        //   630: ldc_w           1889675979
        //   633: ldc_w           -1827330877
        //   636: ixor           
        //   637: lookupswitch {
        //          -1387939967: 630
        //          -474542584: 664
        //          default: 1137
        //        }
        //   664: fload           7
        //   666: ldc_w           90.0
        //   669: fadd           
        //   670: f2d            
        //   671: goto            675
        //   674: athrow         
        //   675: invokestatic    java/lang/Math.toRadians:(D)D
        //   678: goto            682
        //   681: athrow         
        //   682: goto            686
        //   685: athrow         
        //   686: invokestatic    java/lang/Math.cos:(D)D
        //   689: goto            693
        //   692: athrow         
        //   693: dmul           
        //   694: dload           5
        //   696: getstatic       dev/nuker/pyro/fc.0:I
        //   699: ifgt            708
        //   702: ldc_w           -1317112571
        //   705: goto            711
        //   708: ldc_w           -459744
        //   711: ldc_w           -2128765673
        //   714: ixor           
        //   715: lookupswitch {
        //          811853842: 708
        //          2128961847: 740
        //          default: 1163
        //        }
        //   740: dload_1        
        //   741: dmul           
        //   742: getstatic       dev/nuker/pyro/fc.0:I
        //   745: ifgt            754
        //   748: ldc_w           -1057937650
        //   751: goto            757
        //   754: ldc_w           -1200719779
        //   757: ldc_w           2124413571
        //   760: ixor           
        //   761: lookupswitch {
        //          -1100030579: 754
        //          -957250850: 788
        //          default: 1157
        //        }
        //   788: fload           7
        //   790: ldc_w           90.0
        //   793: fadd           
        //   794: f2d            
        //   795: goto            799
        //   798: athrow         
        //   799: invokestatic    java/lang/Math.toRadians:(D)D
        //   802: goto            806
        //   805: athrow         
        //   806: goto            810
        //   809: athrow         
        //   810: invokestatic    java/lang/Math.sin:(D)D
        //   813: goto            817
        //   816: athrow         
        //   817: dmul           
        //   818: dadd           
        //   819: getstatic       dev/nuker/pyro/fc.0:I
        //   822: ifgt            831
        //   825: ldc_w           -359655853
        //   828: goto            834
        //   831: ldc_w           -606443026
        //   834: ldc_w           1728582403
        //   837: ixor           
        //   838: lookupswitch {
        //          -1919417008: 1143
        //          -72731319: 831
        //          default: 864
        //        }
        //   864: goto            868
        //   867: athrow         
        //   868: invokevirtual   dev/nuker/pyro/f4p.0:(D)V
        //   871: goto            875
        //   874: athrow         
        //   875: getstatic       dev/nuker/pyro/fc.0:I
        //   878: ifgt            887
        //   881: ldc_w           -1843986177
        //   884: goto            890
        //   887: ldc_w           -61871077
        //   890: ldc_w           1309279545
        //   893: ixor           
        //   894: lookupswitch {
        //          -1304041182: 920
        //          -602077754: 887
        //          default: 1139
        //        }
        //   920: aload_0        
        //   921: dload_3        
        //   922: dload_1        
        //   923: dmul           
        //   924: fload           7
        //   926: ldc_w           90.0
        //   929: fadd           
        //   930: f2d            
        //   931: goto            935
        //   934: athrow         
        //   935: invokestatic    java/lang/Math.toRadians:(D)D
        //   938: goto            942
        //   941: athrow         
        //   942: goto            946
        //   945: athrow         
        //   946: invokestatic    java/lang/Math.sin:(D)D
        //   949: goto            953
        //   952: athrow         
        //   953: dmul           
        //   954: getstatic       dev/nuker/pyro/fc.1:I
        //   957: ifne            966
        //   960: ldc_w           993765966
        //   963: goto            969
        //   966: ldc_w           -1790898125
        //   969: ldc_w           -885498182
        //   972: ixor           
        //   973: lookupswitch {
        //          -268176140: 966
        //          1585008265: 1000
        //          default: 1153
        //        }
        //  1000: dload           5
        //  1002: dload_1        
        //  1003: dmul           
        //  1004: fload           7
        //  1006: ldc_w           90.0
        //  1009: fadd           
        //  1010: f2d            
        //  1011: getstatic       dev/nuker/pyro/fc.c:I
        //  1014: ifne            1023
        //  1017: ldc_w           2062834403
        //  1020: goto            1026
        //  1023: ldc_w           564551744
        //  1026: ldc_w           -1730161470
        //  1029: ixor           
        //  1030: lookupswitch {
        //          -1183206270: 1056
        //          -500462047: 1023
        //          default: 1151
        //        }
        //  1056: goto            1060
        //  1059: athrow         
        //  1060: invokestatic    java/lang/Math.toRadians:(D)D
        //  1063: goto            1067
        //  1066: athrow         
        //  1067: getstatic       dev/nuker/pyro/fc.c:I
        //  1070: ifne            1079
        //  1073: ldc_w           1231217529
        //  1076: goto            1082
        //  1079: ldc_w           -1576345856
        //  1082: ldc_w           -1567944534
        //  1085: ixor           
        //  1086: lookupswitch {
        //          -336989229: 1079
        //          8507306: 1112
        //          default: 1147
        //        }
        //  1112: goto            1116
        //  1115: athrow         
        //  1116: invokestatic    java/lang/Math.cos:(D)D
        //  1119: goto            1123
        //  1122: athrow         
        //  1123: dmul           
        //  1124: dsub           
        //  1125: goto            1129
        //  1128: athrow         
        //  1129: invokevirtual   dev/nuker/pyro/f4p.c:(D)V
        //  1132: goto            1136
        //  1135: athrow         
        //  1136: return         
        //  1137: aconst_null    
        //  1138: athrow         
        //  1139: aconst_null    
        //  1140: athrow         
        //  1141: aconst_null    
        //  1142: athrow         
        //  1143: aconst_null    
        //  1144: athrow         
        //  1145: aconst_null    
        //  1146: athrow         
        //  1147: aconst_null    
        //  1148: athrow         
        //  1149: aconst_null    
        //  1150: athrow         
        //  1151: aconst_null    
        //  1152: athrow         
        //  1153: aconst_null    
        //  1154: athrow         
        //  1155: aconst_null    
        //  1156: athrow         
        //  1157: aconst_null    
        //  1158: athrow         
        //  1159: aconst_null    
        //  1160: athrow         
        //  1161: aconst_null    
        //  1162: athrow         
        //  1163: aconst_null    
        //  1164: athrow         
        //  1165: pop            
        //  1166: goto            24
        //  1169: pop            
        //  1170: aconst_null    
        //  1171: goto            1165
        //  1174: dup            
        //  1175: ifnull          1165
        //  1178: checkcast       Ljava/lang/Throwable;
        //  1181: athrow         
        //  1182: dup            
        //  1183: ifnull          1169
        //  1186: checkcast       Ljava/lang/Throwable;
        //  1189: athrow         
        //  1190: aconst_null    
        //  1191: athrow         
        //    StackMapTable: 00 96 43 07 00 3D 04 FF 00 0B 00 00 00 01 07 00 3D FD 00 03 07 01 37 03 FF 00 02 00 00 00 01 07 00 3D FD 00 00 07 01 37 03 45 07 00 3D 40 07 01 29 FF 00 07 00 03 07 01 37 03 03 00 01 07 00 3D 00 45 07 00 3D 40 07 01 29 FF 00 08 00 00 00 01 07 00 3D FF 00 00 00 04 07 01 37 03 03 03 00 00 45 07 00 3D 40 02 FC 00 13 02 42 01 1C FF 00 0B 00 00 00 01 07 00 3D FF 00 00 00 05 07 01 37 03 03 03 02 00 02 07 01 37 03 45 07 00 3D 00 FF 00 0D 00 05 07 01 37 03 03 03 02 00 02 07 01 37 03 FF 00 02 00 05 07 01 37 03 03 03 02 00 03 07 01 37 03 01 FF 00 1E 00 05 07 01 37 03 03 03 02 00 02 07 01 37 03 FF 00 02 00 00 00 01 07 00 3D FF 00 00 00 05 07 01 37 03 03 03 02 00 02 07 01 37 03 45 07 00 3D 00 02 05 05 42 01 1A 06 05 42 01 1B 4C 02 FF 00 01 00 05 07 01 37 03 03 03 02 00 02 02 01 06 06 05 42 01 19 4C 02 FF 00 01 00 05 07 01 37 03 03 03 02 00 02 02 01 03 4C 03 FF 00 02 00 05 07 01 37 03 03 03 02 00 02 03 01 5C 03 54 03 FF 00 02 00 05 07 01 37 03 03 03 02 00 02 03 01 5F 03 03 05 05 42 01 18 03 4C 07 01 37 FF 00 02 00 05 07 01 37 03 03 03 02 00 02 07 01 37 01 5F 07 01 37 FF 00 0C 00 05 07 01 37 03 03 03 02 00 02 07 01 37 03 FF 00 02 00 05 07 01 37 03 03 03 02 00 03 07 01 37 03 01 FF 00 1F 00 05 07 01 37 03 03 03 02 00 02 07 01 37 03 FF 00 0D 00 05 07 01 37 03 03 03 02 00 02 07 01 37 03 FF 00 02 00 05 07 01 37 03 03 03 02 00 03 07 01 37 03 01 FF 00 1E 00 05 07 01 37 03 03 03 02 00 02 07 01 37 03 49 07 00 3D FF 00 00 00 05 07 01 37 03 03 03 02 00 03 07 01 37 03 03 45 07 00 3D FF 00 00 00 05 07 01 37 03 03 03 02 00 03 07 01 37 03 03 42 07 00 3D FF 00 00 00 05 07 01 37 03 03 03 02 00 03 07 01 37 03 03 45 07 00 3D FF 00 00 00 05 07 01 37 03 03 03 02 00 03 07 01 37 03 03 FF 00 0E 00 05 07 01 37 03 03 03 02 00 03 07 01 37 03 03 FF 00 02 00 05 07 01 37 03 03 03 02 00 04 07 01 37 03 03 01 FF 00 1C 00 05 07 01 37 03 03 03 02 00 03 07 01 37 03 03 FF 00 0D 00 05 07 01 37 03 03 03 02 00 03 07 01 37 03 03 FF 00 02 00 05 07 01 37 03 03 03 02 00 04 07 01 37 03 03 01 FF 00 1E 00 05 07 01 37 03 03 03 02 00 03 07 01 37 03 03 49 07 00 3D FF 00 00 00 05 07 01 37 03 03 03 02 00 04 07 01 37 03 03 03 45 07 00 3D FF 00 00 00 05 07 01 37 03 03 03 02 00 04 07 01 37 03 03 03 42 07 00 5F FF 00 00 00 05 07 01 37 03 03 03 02 00 04 07 01 37 03 03 03 45 07 00 3D FF 00 00 00 05 07 01 37 03 03 03 02 00 04 07 01 37 03 03 03 FF 00 0D 00 05 07 01 37 03 03 03 02 00 02 07 01 37 03 FF 00 02 00 05 07 01 37 03 03 03 02 00 03 07 01 37 03 01 FF 00 1D 00 05 07 01 37 03 03 03 02 00 02 07 01 37 03 42 07 00 3D FF 00 00 00 05 07 01 37 03 03 03 02 00 02 07 01 37 03 45 07 00 3D 00 0B 42 01 1D 4D 07 00 55 FF 00 00 00 05 07 01 37 03 03 03 02 00 03 07 01 37 03 03 45 07 00 3D FF 00 00 00 05 07 01 37 03 03 03 02 00 03 07 01 37 03 03 42 07 00 3D FF 00 00 00 05 07 01 37 03 03 03 02 00 03 07 01 37 03 03 45 07 00 3D FF 00 00 00 05 07 01 37 03 03 03 02 00 03 07 01 37 03 03 FF 00 0C 00 05 07 01 37 03 03 03 02 00 02 07 01 37 03 FF 00 02 00 05 07 01 37 03 03 03 02 00 03 07 01 37 03 01 FF 00 1E 00 05 07 01 37 03 03 03 02 00 02 07 01 37 03 FF 00 16 00 05 07 01 37 03 03 03 02 00 04 07 01 37 03 03 03 FF 00 02 00 05 07 01 37 03 03 03 02 00 05 07 01 37 03 03 03 01 FF 00 1D 00 05 07 01 37 03 03 03 02 00 04 07 01 37 03 03 03 42 07 00 3D FF 00 00 00 05 07 01 37 03 03 03 02 00 04 07 01 37 03 03 03 45 07 00 3D FF 00 00 00 05 07 01 37 03 03 03 02 00 04 07 01 37 03 03 03 FF 00 0B 00 05 07 01 37 03 03 03 02 00 04 07 01 37 03 03 03 FF 00 02 00 05 07 01 37 03 03 03 02 00 05 07 01 37 03 03 03 01 FF 00 1D 00 05 07 01 37 03 03 03 02 00 04 07 01 37 03 03 03 42 07 00 3D FF 00 00 00 05 07 01 37 03 03 03 02 00 04 07 01 37 03 03 03 45 07 00 3D FF 00 00 00 05 07 01 37 03 03 03 02 00 04 07 01 37 03 03 03 44 07 00 59 FF 00 00 00 05 07 01 37 03 03 03 02 00 02 07 01 37 03 45 07 00 3D 00 FF 00 00 00 05 07 01 37 03 03 03 02 00 02 07 01 37 03 01 41 03 FF 00 01 00 05 07 01 37 03 03 03 02 00 02 07 01 37 03 FF 00 01 00 05 07 01 37 03 03 03 02 00 02 07 01 37 03 FF 00 01 00 05 07 01 37 03 03 03 02 00 04 07 01 37 03 03 03 FF 00 01 00 05 07 01 37 03 03 03 02 00 02 07 01 37 03 FF 00 01 00 05 07 01 37 03 03 03 02 00 04 07 01 37 03 03 03 FF 00 01 00 05 07 01 37 03 03 03 02 00 02 07 01 37 03 01 FF 00 01 00 05 07 01 37 03 03 03 02 00 03 07 01 37 03 03 41 07 01 37 41 03 FF 00 01 00 05 07 01 37 03 03 03 02 00 03 07 01 37 03 03 FF 00 01 00 02 07 01 37 03 00 01 07 00 3D 43 05 44 07 00 3D 47 05 47 07 00 3D
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     1174   1182   Any
        //  1174   1182   1174   1182   Ljava/lang/RuntimeException;
        //  1190   1192   3      8      Ljava/lang/UnsupportedOperationException;
        //  28     34     34     35     Any
        //  28     34     34     35     Ljava/util/NoSuchElementException;
        //  28     34     3      8      Ljava/lang/AssertionError;
        //  28     34     3      8      Any
        //  28     34     3      8      Any
        //  43     50     50     51     Any
        //  44     50     50     51     Ljava/lang/ArithmeticException;
        //  44     50     43     44     Any
        //  44     50     3      8      Ljava/lang/NumberFormatException;
        //  44     50     50     51     Any
        //  61     67     67     68     Any
        //  61     67     67     68     Ljava/lang/ClassCastException;
        //  61     67     67     68     Ljava/lang/ClassCastException;
        //  61     67     67     68     Ljava/lang/NullPointerException;
        //  61     67     67     68     Ljava/util/NoSuchElementException;
        //  133    139    139    140    Any
        //  133    139    3      8      Any
        //  133    139    3      8      Any
        //  133    139    3      8      Any
        //  133    139    139    140    Ljava/lang/ArithmeticException;
        //  192    198    198    199    Any
        //  192    198    3      8      Ljava/lang/AssertionError;
        //  192    198    3      8      Ljava/lang/UnsupportedOperationException;
        //  192    198    3      8      Ljava/util/ConcurrentModificationException;
        //  192    198    3      8      Any
        //  674    681    681    682    Any
        //  675    681    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  674    681    674    675    Any
        //  675    681    681    682    Ljava/lang/ArithmeticException;
        //  675    681    3      8      Any
        //  685    692    692    693    Any
        //  685    692    692    693    Ljava/lang/IndexOutOfBoundsException;
        //  686    692    692    693    Ljava/lang/UnsupportedOperationException;
        //  686    692    692    693    Any
        //  685    692    685    686    Any
        //  798    805    805    806    Any
        //  798    805    805    806    Any
        //  798    805    3      8      Any
        //  799    805    3      8      Ljava/lang/ClassCastException;
        //  799    805    798    799    Any
        //  809    816    816    817    Any
        //  809    816    3      8      Any
        //  810    816    816    817    Any
        //  810    816    816    817    Ljava/lang/NumberFormatException;
        //  809    816    809    810    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  867    874    874    875    Any
        //  868    874    867    868    Ljava/util/NoSuchElementException;
        //  868    874    874    875    Ljava/lang/StringIndexOutOfBoundsException;
        //  868    874    3      8      Ljava/util/ConcurrentModificationException;
        //  867    874    867    868    Any
        //  934    941    941    942    Any
        //  934    941    941    942    Any
        //  934    941    941    942    Ljava/lang/IllegalArgumentException;
        //  934    941    941    942    Ljava/lang/StringIndexOutOfBoundsException;
        //  935    941    934    935    Ljava/lang/IllegalStateException;
        //  945    952    952    953    Any
        //  945    952    945    946    Any
        //  945    952    945    946    Any
        //  945    952    3      8      Any
        //  945    952    3      8      Ljava/lang/UnsupportedOperationException;
        //  1059   1066   1066   1067   Any
        //  1060   1066   1059   1060   Any
        //  1060   1066   1066   1067   Ljava/lang/NegativeArraySizeException;
        //  1059   1066   3      8      Ljava/lang/NegativeArraySizeException;
        //  1059   1066   1059   1060   Any
        //  1115   1122   1122   1123   Any
        //  1115   1122   1122   1123   Any
        //  1116   1122   1122   1123   Any
        //  1116   1122   1115   1116   Any
        //  1115   1122   1115   1116   Ljava/lang/IllegalStateException;
        //  1128   1135   1135   1136   Any
        //  1129   1135   3      8      Any
        //  1128   1135   3      8      Ljava/lang/ClassCastException;
        //  1129   1135   1135   1136   Any
        //  1129   1135   1128   1129   Ljava/lang/ClassCastException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:595)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void c(final double[] p0, final BlockPos p1, final double p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          1832
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            1824
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            1816
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_0        
        //    25: iconst_0       
        //    26: daload         
        //    27: dstore          4
        //    29: aload_0        
        //    30: iconst_1       
        //    31: daload         
        //    32: dstore          6
        //    34: aload_0        
        //    35: iconst_2       
        //    36: daload         
        //    37: dstore          8
        //    39: aload_1        
        //    40: getstatic       dev/nuker/pyro/fc.0:I
        //    43: ifgt            52
        //    46: ldc_w           -981565215
        //    49: goto            55
        //    52: ldc_w           -1672323968
        //    55: ldc_w           1863249462
        //    58: ixor           
        //    59: lookupswitch {
        //          -1435472169: 52
        //          -212028746: 84
        //          default: 1755
        //        }
        //    84: goto            88
        //    87: athrow         
        //    88: invokevirtual   net/minecraft/util/math/BlockPos.func_177958_n:()I
        //    91: goto            95
        //    94: athrow         
        //    95: i2d            
        //    96: dconst_0       
        //    97: dadd           
        //    98: dstore          10
        //   100: aload_1        
        //   101: goto            105
        //   104: athrow         
        //   105: invokevirtual   net/minecraft/util/math/BlockPos.func_177956_o:()I
        //   108: goto            112
        //   111: athrow         
        //   112: i2d            
        //   113: dconst_1       
        //   114: dadd           
        //   115: dstore          12
        //   117: aload_1        
        //   118: goto            122
        //   121: athrow         
        //   122: invokevirtual   net/minecraft/util/math/BlockPos.func_177952_p:()I
        //   125: goto            129
        //   128: athrow         
        //   129: i2d            
        //   130: dconst_0       
        //   131: dadd           
        //   132: dstore          14
        //   134: getstatic       dev/nuker/pyro/fc.1:I
        //   137: ifne            146
        //   140: ldc_w           1469110316
        //   143: goto            149
        //   146: ldc_w           -1942773987
        //   149: ldc_w           -1565108818
        //   152: ixor           
        //   153: lookupswitch {
        //          -182022782: 146
        //          780520115: 180
        //          default: 1763
        //        }
        //   180: dload           4
        //   182: dload           10
        //   184: dsub           
        //   185: goto            189
        //   188: athrow         
        //   189: invokestatic    java/lang/Math.abs:(D)D
        //   192: goto            196
        //   195: athrow         
        //   196: getstatic       dev/nuker/pyro/fc.c:I
        //   199: ifne            208
        //   202: ldc_w           1795197201
        //   205: goto            211
        //   208: ldc_w           -1935029308
        //   211: ldc_w           269018656
        //   214: ixor           
        //   215: lookupswitch {
        //          2064150321: 1785
        //          2144382344: 208
        //          default: 240
        //        }
        //   240: dload           6
        //   242: dload           12
        //   244: dsub           
        //   245: getstatic       dev/nuker/pyro/fc.1:I
        //   248: ifne            257
        //   251: ldc_w           -1309416803
        //   254: goto            260
        //   257: ldc_w           -1391977943
        //   260: ldc_w           -237797334
        //   263: ixor           
        //   264: lookupswitch {
        //          1075864247: 257
        //          1557895683: 292
        //          default: 1757
        //        }
        //   292: goto            296
        //   295: athrow         
        //   296: invokestatic    java/lang/Math.abs:(D)D
        //   299: goto            303
        //   302: athrow         
        //   303: dadd           
        //   304: dload           8
        //   306: getstatic       dev/nuker/pyro/fc.1:I
        //   309: ifne            318
        //   312: ldc_w           2131221737
        //   315: goto            321
        //   318: ldc_w           -1616037359
        //   321: ldc_w           1042276211
        //   324: ixor           
        //   325: lookupswitch {
        //          -1582111390: 352
        //          1092092826: 318
        //          default: 1779
        //        }
        //   352: dload           14
        //   354: dsub           
        //   355: goto            359
        //   358: athrow         
        //   359: invokestatic    java/lang/Math.abs:(D)D
        //   362: goto            366
        //   365: athrow         
        //   366: dadd           
        //   367: dstore          16
        //   369: iconst_0       
        //   370: istore          18
        //   372: dload           16
        //   374: dstore          19
        //   376: dload           19
        //   378: dload_2        
        //   379: dcmpl          
        //   380: ifle            1754
        //   383: getstatic       dev/nuker/pyro/fc.c:I
        //   386: ifne            395
        //   389: ldc_w           -1523079880
        //   392: goto            398
        //   395: ldc_w           -689925493
        //   398: ldc_w           831496928
        //   401: ixor           
        //   402: lookupswitch {
        //          -1799878696: 1801
        //          1407149112: 395
        //          default: 428
        //        }
        //   428: dload           4
        //   430: dload           10
        //   432: dsub           
        //   433: getstatic       dev/nuker/pyro/fc.1:I
        //   436: ifne            445
        //   439: ldc_w           1101482947
        //   442: goto            448
        //   445: ldc_w           766062727
        //   448: ldc_w           -1157893899
        //   451: ixor           
        //   452: lookupswitch {
        //          -1756184462: 480
        //          -77808842: 445
        //          default: 1791
        //        }
        //   480: goto            484
        //   483: athrow         
        //   484: invokestatic    java/lang/Math.abs:(D)D
        //   487: goto            491
        //   490: athrow         
        //   491: dload           6
        //   493: getstatic       dev/nuker/pyro/fc.1:I
        //   496: ifne            505
        //   499: ldc_w           -1257370713
        //   502: goto            508
        //   505: ldc_w           1726185587
        //   508: ldc_w           172299331
        //   511: ixor           
        //   512: lookupswitch {
        //          -1085595676: 1787
        //          1707455163: 505
        //          default: 540
        //        }
        //   540: dload           12
        //   542: dsub           
        //   543: goto            547
        //   546: athrow         
        //   547: invokestatic    java/lang/Math.abs:(D)D
        //   550: goto            554
        //   553: athrow         
        //   554: dadd           
        //   555: dload           8
        //   557: getstatic       dev/nuker/pyro/fc.0:I
        //   560: ifgt            569
        //   563: ldc_w           -558112212
        //   566: goto            572
        //   569: ldc_w           344741742
        //   572: ldc_w           -1378117584
        //   575: ixor           
        //   576: lookupswitch {
        //          -1185427618: 604
        //          1935702556: 569
        //          default: 1771
        //        }
        //   604: dload           14
        //   606: dsub           
        //   607: goto            611
        //   610: athrow         
        //   611: invokestatic    java/lang/Math.abs:(D)D
        //   614: goto            618
        //   617: athrow         
        //   618: dadd           
        //   619: dstore          16
        //   621: iload           18
        //   623: bipush          120
        //   625: if_icmple       629
        //   628: return         
        //   629: getstatic       dev/nuker/pyro/fc.c:I
        //   632: ifne            641
        //   635: ldc_w           -615338761
        //   638: goto            644
        //   641: ldc_w           -326736362
        //   644: ldc_w           -93573502
        //   647: ixor           
        //   648: lookupswitch {
        //          238942521: 641
        //          557744757: 1795
        //          default: 676
        //        }
        //   676: dload           4
        //   678: dload           10
        //   680: dsub           
        //   681: dstore          21
        //   683: dload           6
        //   685: dload           12
        //   687: dsub           
        //   688: dstore          23
        //   690: dload           8
        //   692: getstatic       dev/nuker/pyro/fc.c:I
        //   695: ifne            704
        //   698: ldc_w           1497143746
        //   701: goto            707
        //   704: ldc_w           1817942802
        //   707: ldc_w           1975042491
        //   710: ixor           
        //   711: lookupswitch {
        //          434330281: 736
        //          746870905: 704
        //          default: 1767
        //        }
        //   736: dload           14
        //   738: dsub           
        //   739: getstatic       dev/nuker/pyro/fc.1:I
        //   742: ifne            751
        //   745: ldc_w           -856096069
        //   748: goto            754
        //   751: ldc_w           148888614
        //   754: ldc_w           -231959339
        //   757: ixor           
        //   758: lookupswitch {
        //          1054185070: 1799
        //          1240619228: 751
        //          default: 784
        //        }
        //   784: dstore          25
        //   786: getstatic       dev/nuker/pyro/fc.1:I
        //   789: ifne            798
        //   792: ldc_w           1511901969
        //   795: goto            801
        //   798: ldc_w           1755148041
        //   801: ldc_w           -2098672092
        //   804: ixor           
        //   805: lookupswitch {
        //          -655030987: 798
        //          -361389779: 832
        //          default: 1783
        //        }
        //   832: iload           18
        //   834: iconst_1       
        //   835: iand           
        //   836: ifne            845
        //   839: ldc2_w          1.273197475E-314
        //   842: goto            846
        //   845: dconst_0       
        //   846: getstatic       dev/nuker/pyro/fc.1:I
        //   849: ifne            858
        //   852: ldc_w           -128839583
        //   855: goto            861
        //   858: ldc_w           -963682683
        //   861: ldc_w           1598095253
        //   864: ixor           
        //   865: lookupswitch {
        //          -1491931148: 1793
        //          -1343101034: 858
        //          default: 892
        //        }
        //   892: dstore          27
        //   894: getstatic       dev/nuker/pyro/fc.c:I
        //   897: ifne            906
        //   900: ldc_w           -1542627283
        //   903: goto            909
        //   906: ldc_w           -279866493
        //   909: ldc_w           -1211929814
        //   912: ixor           
        //   913: lookupswitch {
        //          332270343: 906
        //          1486026921: 940
        //          default: 1773
        //        }
        //   940: dload           21
        //   942: goto            946
        //   945: athrow         
        //   946: invokestatic    java/lang/Math.abs:(D)D
        //   949: goto            953
        //   952: athrow         
        //   953: dload           27
        //   955: goto            959
        //   958: athrow         
        //   959: invokestatic    java/lang/Math.min:(DD)D
        //   962: goto            966
        //   965: athrow         
        //   966: dstore          29
        //   968: dload           21
        //   970: dconst_0       
        //   971: dcmpg          
        //   972: ifge            1036
        //   975: dload           4
        //   977: getstatic       dev/nuker/pyro/fc.1:I
        //   980: ifne            989
        //   983: ldc_w           1996214198
        //   986: goto            992
        //   989: ldc_w           -658681968
        //   992: ldc_w           -476975018
        //   995: ixor           
        //   996: lookupswitch {
        //          -1788198944: 989
        //          992788422: 1024
        //          default: 1765
        //        }
        //  1024: dload           29
        //  1026: dadd           
        //  1027: dstore          4
        //  1029: dload           23
        //  1031: dstore          19
        //  1033: goto            1100
        //  1036: dload           21
        //  1038: dconst_0       
        //  1039: dcmpl          
        //  1040: ifle            1050
        //  1043: dload           4
        //  1045: dload           29
        //  1047: dsub           
        //  1048: dstore          4
        //  1050: getstatic       dev/nuker/pyro/fc.1:I
        //  1053: ifne            1062
        //  1056: ldc_w           -1719195224
        //  1059: goto            1065
        //  1062: ldc_w           -1025630250
        //  1065: ldc_w           -689266800
        //  1068: ixor           
        //  1069: lookupswitch {
        //          -1703206628: 1062
        //          1332590136: 1761
        //          default: 1096
        //        }
        //  1096: dload           23
        //  1098: dstore          19
        //  1100: dload           19
        //  1102: goto            1106
        //  1105: athrow         
        //  1106: invokestatic    java/lang/Math.abs:(D)D
        //  1109: goto            1113
        //  1112: athrow         
        //  1113: dconst_0       
        //  1114: goto            1118
        //  1117: athrow         
        //  1118: invokestatic    java/lang/Math.min:(DD)D
        //  1121: goto            1125
        //  1124: athrow         
        //  1125: dstore          21
        //  1127: getstatic       dev/nuker/pyro/fc.0:I
        //  1130: ifgt            1139
        //  1133: ldc_w           97165419
        //  1136: goto            1142
        //  1139: ldc_w           356715811
        //  1142: ldc_w           339589508
        //  1145: ixor           
        //  1146: lookupswitch {
        //          25080999: 1172
        //          301406703: 1139
        //          default: 1797
        //        }
        //  1172: dload           23
        //  1174: dconst_0       
        //  1175: dcmpg          
        //  1176: ifge            1283
        //  1179: dload           6
        //  1181: dload           21
        //  1183: dadd           
        //  1184: getstatic       dev/nuker/pyro/fc.c:I
        //  1187: ifne            1196
        //  1190: ldc_w           -1091563985
        //  1193: goto            1199
        //  1196: ldc_w           1143823813
        //  1199: ldc_w           2109776446
        //  1202: ixor           
        //  1203: lookupswitch {
        //          -1020220399: 1196
        //          971898875: 1228
        //          default: 1789
        //        }
        //  1228: dstore          6
        //  1230: getstatic       dev/nuker/pyro/fc.0:I
        //  1233: ifgt            1242
        //  1236: ldc_w           -1318167298
        //  1239: goto            1245
        //  1242: ldc_w           -1838504731
        //  1245: ldc_w           -2109388704
        //  1248: ixor           
        //  1249: lookupswitch {
        //          271576197: 1276
        //          858461342: 1242
        //          default: 1803
        //        }
        //  1276: dload           25
        //  1278: dstore          19
        //  1280: goto            1381
        //  1283: dload           23
        //  1285: dconst_0       
        //  1286: dcmpl          
        //  1287: ifle            1296
        //  1290: ldc_w           1482028213
        //  1293: goto            1299
        //  1296: ldc_w           1482028212
        //  1299: ldc_w           -1890159389
        //  1302: ixor           
        //  1303: tableswitch {
        //          -1375272788: 1324
        //          -1375272787: 1377
        //          default: 1290
        //        }
        //  1324: dload           6
        //  1326: getstatic       dev/nuker/pyro/fc.0:I
        //  1329: ifgt            1338
        //  1332: ldc_w           -189128344
        //  1335: goto            1341
        //  1338: ldc_w           -230523289
        //  1341: ldc_w           -511907362
        //  1344: ixor           
        //  1345: lookupswitch {
        //          322869177: 1372
        //          365349046: 1338
        //          default: 1805
        //        }
        //  1372: dload           21
        //  1374: dsub           
        //  1375: dstore          6
        //  1377: dload           25
        //  1379: dstore          19
        //  1381: dload           19
        //  1383: getstatic       dev/nuker/pyro/fc.c:I
        //  1386: ifne            1395
        //  1389: ldc_w           1423517386
        //  1392: goto            1398
        //  1395: ldc_w           378981637
        //  1398: ldc_w           -1942040192
        //  1401: ixor           
        //  1402: lookupswitch {
        //          -1700258683: 1428
        //          -655886518: 1395
        //          default: 1769
        //        }
        //  1428: goto            1432
        //  1431: athrow         
        //  1432: invokestatic    java/lang/Math.abs:(D)D
        //  1435: goto            1439
        //  1438: athrow         
        //  1439: dload           27
        //  1441: goto            1445
        //  1444: athrow         
        //  1445: invokestatic    java/lang/Math.min:(DD)D
        //  1448: goto            1452
        //  1451: athrow         
        //  1452: dstore          21
        //  1454: dload           25
        //  1456: dconst_0       
        //  1457: dcmpg          
        //  1458: ifge            1467
        //  1461: ldc_w           -1123923201
        //  1464: goto            1470
        //  1467: ldc_w           -1123923204
        //  1470: ldc_w           1760012506
        //  1473: ixor           
        //  1474: tableswitch {
        //          -1412709302: 1496
        //          -1412709301: 1506
        //          default: 1461
        //        }
        //  1496: dload           8
        //  1498: dload           21
        //  1500: dadd           
        //  1501: dstore          8
        //  1503: goto            1614
        //  1506: dload           25
        //  1508: dconst_0       
        //  1509: dcmpl          
        //  1510: ifle            1614
        //  1513: getstatic       dev/nuker/pyro/fc.c:I
        //  1516: ifne            1525
        //  1519: ldc_w           1757413048
        //  1522: goto            1528
        //  1525: ldc_w           -1232977653
        //  1528: ldc_w           -404473337
        //  1531: ixor           
        //  1532: lookupswitch {
        //          -1889811265: 1525
        //          1365670668: 1560
        //          default: 1759
        //        }
        //  1560: dload           8
        //  1562: dload           21
        //  1564: dsub           
        //  1565: getstatic       dev/nuker/pyro/fc.1:I
        //  1568: ifne            1577
        //  1571: ldc_w           -1308902511
        //  1574: goto            1580
        //  1577: ldc_w           -535026861
        //  1580: ldc_w           -1794554221
        //  1583: ixor           
        //  1584: lookupswitch {
        //          619904258: 1577
        //          1964336576: 1612
        //          default: 1777
        //        }
        //  1612: dstore          8
        //  1614: iinc            18, 1
        //  1617: getstatic       dev/nuker/pyro/fec.c:Lnet/minecraft/client/Minecraft;
        //  1620: getstatic       dev/nuker/pyro/fc.1:I
        //  1623: ifne            1632
        //  1626: ldc_w           -1404894460
        //  1629: goto            1635
        //  1632: ldc_w           -671888328
        //  1635: ldc_w           808747732
        //  1638: ixor           
        //  1639: lookupswitch {
        //          -1669889584: 1775
        //          -1354005680: 1632
        //          default: 1664
        //        }
        //  1664: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1667: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71174_a:Lnet/minecraft/client/network/NetHandlerPlayClient;
        //  1670: new             Lnet/minecraft/network/play/client/CPacketPlayer$Position;
        //  1673: dup            
        //  1674: dload           4
        //  1676: dload           6
        //  1678: dload           8
        //  1680: iconst_1       
        //  1681: goto            1685
        //  1684: athrow         
        //  1685: invokespecial   net/minecraft/network/play/client/CPacketPlayer$Position.<init>:(DDDZ)V
        //  1688: goto            1692
        //  1691: athrow         
        //  1692: getstatic       dev/nuker/pyro/fc.1:I
        //  1695: ifne            1704
        //  1698: ldc_w           -2111467778
        //  1701: goto            1707
        //  1704: ldc_w           2104305176
        //  1707: ldc_w           -1225712304
        //  1710: ixor           
        //  1711: lookupswitch {
        //          886346670: 1781
        //          1528719648: 1704
        //          default: 1736
        //        }
        //  1736: goto            1740
        //  1739: athrow         
        //  1740: invokevirtual   net/minecraft/client/network/NetHandlerPlayClient.func_147297_a:(Lnet/minecraft/network/Packet;)V
        //  1743: goto            1747
        //  1746: athrow         
        //  1747: dload           16
        //  1749: dstore          19
        //  1751: goto            376
        //  1754: return         
        //  1755: aconst_null    
        //  1756: athrow         
        //  1757: aconst_null    
        //  1758: athrow         
        //  1759: aconst_null    
        //  1760: athrow         
        //  1761: aconst_null    
        //  1762: athrow         
        //  1763: aconst_null    
        //  1764: athrow         
        //  1765: aconst_null    
        //  1766: athrow         
        //  1767: aconst_null    
        //  1768: athrow         
        //  1769: aconst_null    
        //  1770: athrow         
        //  1771: aconst_null    
        //  1772: athrow         
        //  1773: aconst_null    
        //  1774: athrow         
        //  1775: aconst_null    
        //  1776: athrow         
        //  1777: aconst_null    
        //  1778: athrow         
        //  1779: aconst_null    
        //  1780: athrow         
        //  1781: aconst_null    
        //  1782: athrow         
        //  1783: aconst_null    
        //  1784: athrow         
        //  1785: aconst_null    
        //  1786: athrow         
        //  1787: aconst_null    
        //  1788: athrow         
        //  1789: aconst_null    
        //  1790: athrow         
        //  1791: aconst_null    
        //  1792: athrow         
        //  1793: aconst_null    
        //  1794: athrow         
        //  1795: aconst_null    
        //  1796: athrow         
        //  1797: aconst_null    
        //  1798: athrow         
        //  1799: aconst_null    
        //  1800: athrow         
        //  1801: aconst_null    
        //  1802: athrow         
        //  1803: aconst_null    
        //  1804: athrow         
        //  1805: aconst_null    
        //  1806: athrow         
        //  1807: pop            
        //  1808: goto            24
        //  1811: pop            
        //  1812: aconst_null    
        //  1813: goto            1807
        //  1816: dup            
        //  1817: ifnull          1807
        //  1820: checkcast       Ljava/lang/Throwable;
        //  1823: athrow         
        //  1824: dup            
        //  1825: ifnull          1811
        //  1828: checkcast       Ljava/lang/Throwable;
        //  1831: athrow         
        //  1832: aconst_null    
        //  1833: athrow         
        //    StackMapTable: 00 CA FF 00 03 00 07 07 01 E5 07 01 80 03 03 03 03 03 00 01 07 00 3D FF 00 04 00 03 07 01 E5 07 01 80 03 00 00 FF 00 0B 00 00 00 01 07 00 3D FE 00 03 07 01 E5 07 01 80 03 FF 00 1B 00 06 07 01 E5 07 01 80 03 03 03 03 00 01 07 01 80 FF 00 02 00 06 07 01 E5 07 01 80 03 03 03 03 00 02 07 01 80 01 5C 07 01 80 42 07 00 3D 40 07 01 80 45 07 00 3D 40 01 FF 00 08 00 07 07 01 E5 07 01 80 03 03 03 03 03 00 01 07 00 3D 40 07 01 80 45 07 00 3D 40 01 FF 00 08 00 00 00 01 07 00 3D FF 00 00 00 08 07 01 E5 07 01 80 03 03 03 03 03 03 00 01 07 01 80 45 07 00 3D 40 01 FC 00 10 03 42 01 1E FF 00 07 00 00 00 01 07 00 3D FF 00 00 00 09 07 01 E5 07 01 80 03 03 03 03 03 03 03 00 01 03 45 07 00 3D 40 03 4B 03 FF 00 02 00 09 07 01 E5 07 01 80 03 03 03 03 03 03 03 00 02 03 01 5C 03 FF 00 10 00 09 07 01 E5 07 01 80 03 03 03 03 03 03 03 00 02 03 03 FF 00 02 00 09 07 01 E5 07 01 80 03 03 03 03 03 03 03 00 03 03 03 01 FF 00 1F 00 09 07 01 E5 07 01 80 03 03 03 03 03 03 03 00 02 03 03 42 07 00 5D FF 00 00 00 09 07 01 E5 07 01 80 03 03 03 03 03 03 03 00 02 03 03 45 07 00 3D FF 00 00 00 09 07 01 E5 07 01 80 03 03 03 03 03 03 03 00 02 03 03 FF 00 0E 00 09 07 01 E5 07 01 80 03 03 03 03 03 03 03 00 02 03 03 FF 00 02 00 09 07 01 E5 07 01 80 03 03 03 03 03 03 03 00 03 03 03 01 FF 00 1E 00 09 07 01 E5 07 01 80 03 03 03 03 03 03 03 00 02 03 03 FF 00 05 00 00 00 01 07 00 3D FF 00 00 00 09 07 01 E5 07 01 80 03 03 03 03 03 03 03 00 02 03 03 45 07 00 3D FF 00 00 00 09 07 01 E5 07 01 80 03 03 03 03 03 03 03 00 02 03 03 FE 00 09 03 01 03 12 42 01 1D 50 03 FF 00 02 00 0C 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 00 02 03 01 5F 03 42 07 00 3D 40 03 45 07 00 3D 40 03 FF 00 0D 00 0C 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 00 02 03 03 FF 00 02 00 0C 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 00 03 03 03 01 FF 00 1F 00 0C 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 00 02 03 03 45 07 00 3D FF 00 00 00 0C 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 00 02 03 03 45 07 00 3D FF 00 00 00 0C 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 00 02 03 03 FF 00 0E 00 0C 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 00 02 03 03 FF 00 02 00 0C 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 00 03 03 03 01 FF 00 1F 00 0C 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 00 02 03 03 45 07 00 3D FF 00 00 00 0C 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 00 02 03 03 45 07 00 3D FF 00 00 00 0C 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 00 02 03 03 0A 0B 42 01 1F FF 00 1B 00 0E 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 00 01 03 FF 00 02 00 0E 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 00 02 03 01 5C 03 4E 03 FF 00 02 00 0E 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 00 02 03 01 5D 03 FC 00 0D 03 42 01 1E 0C 40 03 4B 03 FF 00 02 00 0F 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 00 02 03 01 5E 03 FC 00 0D 03 42 01 1E 44 07 00 6D 40 03 45 07 00 3D 40 03 44 07 00 3D FF 00 00 00 10 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 00 02 03 03 45 07 00 3D 40 03 FF 00 16 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 01 03 FF 00 02 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 02 03 01 5F 03 0B 0D 0B 42 01 1E 03 FF 00 04 00 00 00 01 07 00 3D FF 00 00 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 01 03 45 07 00 3D 40 03 43 07 00 3D FF 00 00 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 02 03 03 45 07 00 3D 40 03 0D 42 01 1D 57 03 FF 00 02 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 02 03 01 5C 03 0D 42 01 1E 06 06 05 42 01 18 4D 03 FF 00 02 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 02 03 01 5E 03 04 03 4D 03 FF 00 02 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 02 03 01 5D 03 42 07 00 3D 40 03 45 07 00 3D 40 03 44 07 00 3D FF 00 00 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 02 03 03 45 07 00 3D 40 03 08 05 42 01 19 09 12 42 01 1F 50 03 FF 00 02 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 02 03 01 5F 03 01 51 07 00 43 FF 00 02 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 02 07 00 43 01 5C 07 00 43 53 07 00 59 FF 00 00 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 07 07 00 D3 08 06 86 08 06 86 03 03 03 01 45 07 00 3D FF 00 00 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 02 07 00 D3 07 00 C3 FF 00 0B 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 02 07 00 D3 07 00 C3 FF 00 02 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 03 07 00 D3 07 00 C3 01 FF 00 1C 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 02 07 00 D3 07 00 C3 42 07 00 63 FF 00 00 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 02 07 00 D3 07 00 C3 45 07 00 3D 00 FF 00 06 00 0C 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 00 00 FF 00 00 00 06 07 01 E5 07 01 80 03 03 03 03 00 01 07 01 80 FF 00 01 00 09 07 01 E5 07 01 80 03 03 03 03 03 03 03 00 02 03 03 FF 00 01 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 00 01 FF 00 01 00 09 07 01 E5 07 01 80 03 03 03 03 03 03 03 00 00 FF 00 01 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 01 03 FF 00 01 00 0E 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 00 01 03 FF 00 01 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 01 03 FF 00 01 00 0C 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 00 02 03 03 FF 00 01 00 10 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 00 00 FF 00 01 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 01 07 00 43 41 03 FF 00 01 00 09 07 01 E5 07 01 80 03 03 03 03 03 03 03 00 02 03 03 FF 00 01 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 02 07 00 D3 07 00 C3 F9 00 01 FF 00 01 00 09 07 01 E5 07 01 80 03 03 03 03 03 03 03 00 01 03 FF 00 01 00 0C 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 00 02 03 03 FF 00 01 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 01 03 FF 00 01 00 0C 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 00 01 03 FF 00 01 00 0F 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 00 01 03 F8 00 01 FF 00 01 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 00 FF 00 01 00 0E 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 00 01 03 F9 00 01 FF 00 01 00 11 07 01 E5 07 01 80 03 03 03 03 03 03 03 03 01 03 03 03 03 03 03 00 00 41 03 FF 00 01 00 03 07 01 E5 07 01 80 03 00 01 07 00 3D 43 05 44 07 00 3D 47 05 FF 00 07 00 07 07 01 E5 07 01 80 03 03 03 03 03 00 01 07 00 3D
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     1816   1824   Any
        //  1816   1824   1816   1824   Ljava/lang/NumberFormatException;
        //  1832   1834   3      8      Any
        //  87     94     94     95     Any
        //  88     94     87     88     Any
        //  87     94     87     88     Any
        //  87     94     87     88     Ljava/lang/IndexOutOfBoundsException;
        //  88     94     94     95     Any
        //  104    111    111    112    Any
        //  105    111    104    105    Any
        //  105    111    111    112    Any
        //  105    111    111    112    Ljava/lang/UnsupportedOperationException;
        //  104    111    3      8      Any
        //  122    128    128    129    Any
        //  122    128    3      8      Any
        //  122    128    3      8      Any
        //  122    128    128    129    Any
        //  122    128    128    129    Ljava/lang/NegativeArraySizeException;
        //  189    195    195    196    Any
        //  189    195    3      8      Ljava/lang/NegativeArraySizeException;
        //  189    195    195    196    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  189    195    195    196    Ljava/lang/IndexOutOfBoundsException;
        //  189    195    195    196    Any
        //  295    302    302    303    Any
        //  296    302    295    296    Ljava/lang/RuntimeException;
        //  295    302    3      8      Any
        //  295    302    302    303    Ljava/util/NoSuchElementException;
        //  296    302    302    303    Ljava/lang/IllegalStateException;
        //  359    365    365    366    Any
        //  359    365    365    366    Any
        //  359    365    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  359    365    365    366    Any
        //  359    365    365    366    Ljava/lang/IllegalStateException;
        //  483    490    490    491    Any
        //  484    490    483    484    Any
        //  484    490    490    491    Ljava/lang/NegativeArraySizeException;
        //  483    490    490    491    Ljava/lang/StringIndexOutOfBoundsException;
        //  483    490    483    484    Any
        //  546    553    553    554    Any
        //  546    553    546    547    Any
        //  546    553    546    547    Any
        //  546    553    553    554    Any
        //  546    553    3      8      Any
        //  610    617    617    618    Any
        //  611    617    3      8      Ljava/lang/AssertionError;
        //  611    617    3      8      Ljava/lang/ArithmeticException;
        //  610    617    610    611    Ljava/lang/IllegalArgumentException;
        //  611    617    610    611    Any
        //  945    952    952    953    Any
        //  945    952    952    953    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  946    952    952    953    Ljava/lang/ArithmeticException;
        //  945    952    945    946    Ljava/lang/NumberFormatException;
        //  945    952    3      8      Any
        //  958    965    965    966    Any
        //  959    965    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  959    965    3      8      Any
        //  958    965    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  959    965    958    959    Any
        //  1106   1112   1112   1113   Any
        //  1106   1112   3      8      Any
        //  1106   1112   3      8      Any
        //  1106   1112   1112   1113   Any
        //  1106   1112   1112   1113   Any
        //  1117   1124   1124   1125   Any
        //  1117   1124   1117   1118   Any
        //  1118   1124   1117   1118   Any
        //  1118   1124   1124   1125   Ljava/lang/IllegalArgumentException;
        //  1117   1124   1124   1125   Ljava/lang/IndexOutOfBoundsException;
        //  1431   1438   1438   1439   Any
        //  1431   1438   1431   1432   Any
        //  1431   1438   3      8      Ljava/lang/ArithmeticException;
        //  1432   1438   1431   1432   Any
        //  1432   1438   3      8      Ljava/lang/NullPointerException;
        //  1444   1451   1451   1452   Any
        //  1444   1451   1444   1445   Any
        //  1445   1451   1444   1445   Ljava/lang/ArithmeticException;
        //  1445   1451   3      8      Ljava/lang/UnsupportedOperationException;
        //  1444   1451   1451   1452   Ljava/lang/ArithmeticException;
        //  1684   1691   1691   1692   Any
        //  1685   1691   3      8      Any
        //  1684   1691   1691   1692   Any
        //  1685   1691   1691   1692   Any
        //  1685   1691   1684   1685   Ljava/lang/ClassCastException;
        //  1739   1746   1746   1747   Any
        //  1739   1746   1746   1747   Any
        //  1740   1746   3      8      Any
        //  1740   1746   1739   1740   Ljava/lang/UnsupportedOperationException;
        //  1739   1746   3      8      Ljava/lang/ArithmeticException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:577)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void c(final float n) {
        fez.aU(null, 1507440737, n);
    }
}
