// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import org.jetbrains.annotations.NotNull;
import java.util.List;

public class f7I extends f3Y
{
    @Override
    public void c(@NotNull final List list) {
        fez.iC(this, 244329404, list);
    }
    
    @NotNull
    @Override
    public List c() {
        return fez.iM(this, 417459086);
    }
    
    static {
        throw t;
    }
    
    public f7I() {
        while (true) {
            int n = 0;
            Label_0013: {
                if (fc.1 == 0) {
                    n = 1132543948;
                    break Label_0013;
                }
                n = -300815967;
            }
            switch (n ^ 0x8FAC3B11) {
                case -869464867: {
                    continue;
                }
                case 1639830192: {}
                default: {
                    throw null;
                }
            }
            break;
        }
    }
}
