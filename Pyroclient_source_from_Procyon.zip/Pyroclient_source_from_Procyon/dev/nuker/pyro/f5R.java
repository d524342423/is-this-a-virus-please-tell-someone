// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import dev.nuker.pyro.security.inject.LauncherEventHide;
import org.jetbrains.annotations.NotNull;
import net.minecraft.client.gui.ScaledResolution;
import org.jetbrains.annotations.Nullable;

public class f5R extends f5q
{
    public fe8 c;
    public float c;
    
    @Override
    public void c(@Nullable final f5t p0, final int p1, @Nullable final ScaledResolution p2, final float p3, final float p4) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          768
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            760
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            752
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: goto            28
        //    27: athrow         
        //    28: invokestatic    java/lang/System.currentTimeMillis:()J
        //    31: goto            35
        //    34: athrow         
        //    35: aload_0        
        //    36: getstatic       dev/nuker/pyro/fc.0:I
        //    39: ifgt            47
        //    42: ldc             -1069506496
        //    44: goto            49
        //    47: ldc             -982810567
        //    49: ldc             -1702035676
        //    51: ixor           
        //    52: lookupswitch {
        //          1523343204: 727
        //          1945391987: 47
        //          default: 80
        //        }
        //    80: getfield        dev/nuker/pyro/f5R.c:Ldev/nuker/pyro/fe8;
        //    83: goto            87
        //    86: athrow         
        //    87: invokevirtual   dev/nuker/pyro/fe8.0:()J
        //    90: goto            94
        //    93: athrow         
        //    94: lsub           
        //    95: l2f            
        //    96: ldc             1000.0
        //    98: fdiv           
        //    99: ldc             60.0
        //   101: frem           
        //   102: getstatic       dev/nuker/pyro/fc.1:I
        //   105: ifne            113
        //   108: ldc             1857195314
        //   110: goto            115
        //   113: ldc             1144249027
        //   115: ldc             371705208
        //   117: ixor           
        //   118: lookupswitch {
        //          436190992: 113
        //          2023049290: 737
        //          default: 144
        //        }
        //   144: fstore          6
        //   146: getstatic       dev/nuker/pyro/fc.1:I
        //   149: ifne            157
        //   152: ldc             -1230700561
        //   154: goto            159
        //   157: ldc             1103817457
        //   159: ldc             -1792468297
        //   161: ixor           
        //   162: lookupswitch {
        //          -723259322: 188
        //          596501848: 157
        //          default: 735
        //        }
        //   188: fload           6
        //   190: iconst_2       
        //   191: i2f            
        //   192: fcmpg          
        //   193: ifge            201
        //   196: ldc             315076610
        //   198: goto            203
        //   201: ldc             315076613
        //   203: ldc             930527905
        //   205: ixor           
        //   206: tableswitch {
        //          1264719174: 228
        //          1264719175: 312
        //          default: 196
        //        }
        //   228: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //   231: getfield        net/minecraft/client/Minecraft.field_71462_r:Lnet/minecraft/client/gui/GuiScreen;
        //   234: instanceof      Ldev/nuker/pyro/f5j;
        //   237: ifeq            311
        //   240: ldc             "\u3d57\ub240\u8e3c\uafa3\u6121\u5993\u7e00\u6931\uc0d3\ua5d1\u9b9d\u1317\uc14c\u7310\u96e5\u4d99\ub214\u4cb6\u0313\u0105\u1294\ufed7\u6afe\u8a4a\u3009\u3d0a\u7ff2\ua948\ud3f6\u7458\u444c\u6ba1\u743a\u9529\uc1e7\u4346\ufdff\u10ad\u1a54\u4c99\u662d\uac06\u8d0b\ufb79\uba81"
        //   242: goto            246
        //   245: athrow         
        //   246: invokestatic    invokestatic   !!! ERROR
        //   249: goto            253
        //   252: athrow         
        //   253: fconst_0       
        //   254: fconst_0       
        //   255: iconst_m1      
        //   256: getstatic       dev/nuker/pyro/fc.1:I
        //   259: ifne            267
        //   262: ldc             1058295781
        //   264: goto            269
        //   267: ldc             -2134955416
        //   269: ldc             -1047448842
        //   271: ixor           
        //   272: lookupswitch {
        //          -24806125: 267
        //          1093539998: 300
        //          default: 725
        //        }
        //   300: goto            304
        //   303: athrow         
        //   304: invokestatic    dev/nuker/pyro/fe6.1:(Ljava/lang/String;FFI)V
        //   307: goto            311
        //   310: athrow         
        //   311: return         
        //   312: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //   315: dup            
        //   316: pop            
        //   317: getstatic       dev/nuker/pyro/fc.c:I
        //   320: ifne            328
        //   323: ldc             161634386
        //   325: goto            330
        //   328: ldc             -2105743639
        //   330: ldc             -572499214
        //   332: ixor           
        //   333: lookupswitch {
        //          -733871456: 328
        //          1604107291: 360
        //          default: 731
        //        }
        //   360: goto            364
        //   363: athrow         
        //   364: invokevirtual   net/minecraft/client/Minecraft.func_71356_B:()Z
        //   367: goto            371
        //   370: athrow         
        //   371: ifeq            375
        //   374: return         
        //   375: getstatic       dev/nuker/pyro/fc.1:I
        //   378: ifne            386
        //   381: ldc             65220535
        //   383: goto            388
        //   386: ldc             621418753
        //   388: ldc             622401775
        //   390: ixor           
        //   391: lookupswitch {
        //          653932376: 739
        //          1290158111: 386
        //          default: 416
        //        }
        //   416: getstatic       kotlin/jvm/internal/StringCompanionObject.INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;
        //   419: getstatic       dev/nuker/pyro/fc.1:I
        //   422: ifne            430
        //   425: ldc             -419883302
        //   427: goto            432
        //   430: ldc             -1499414718
        //   432: ldc             -38787561
        //   434: ixor           
        //   435: lookupswitch {
        //          457781453: 729
        //          703933729: 430
        //          default: 460
        //        }
        //   460: astore          8
        //   462: ldc             "\u3d57\ub240\u8e3c\uafa3\u6121\u5993\u7e00\u6931\uc0d3\ua5d1\u9b9d\u1317\uc14c\u7310\u96e5\u4d99\ub214\u4cb6\u0313\u0105\u1294\ufed7\u6afe\u8a4a\u3009\u3d0a\u7ff2\ua948\ud3f6\u7458\u444c\u6ba1\u743a\u9529\uc1ba\u4348\ufdbe\u10ae\u1a17\u4c85\u6626\uac01\u8d17\ufb39\ubacb\ua408\u4c6c\u3f66"
        //   464: goto            468
        //   467: athrow         
        //   468: invokestatic    invokestatic   !!! ERROR
        //   471: goto            475
        //   474: athrow         
        //   475: astore          9
        //   477: iconst_1       
        //   478: anewarray       Ljava/lang/Object;
        //   481: dup            
        //   482: iconst_0       
        //   483: getstatic       dev/nuker/pyro/fc.0:I
        //   486: ifgt            494
        //   489: ldc             -1232606858
        //   491: goto            496
        //   494: ldc             845156292
        //   496: ldc             837984618
        //   498: ixor           
        //   499: lookupswitch {
        //          -2022356964: 494
        //          59944622: 524
        //          default: 733
        //        }
        //   524: fload           6
        //   526: goto            530
        //   529: athrow         
        //   530: invokestatic    java/lang/Float.valueOf:(F)Ljava/lang/Float;
        //   533: goto            537
        //   536: athrow         
        //   537: aastore        
        //   538: astore          10
        //   540: iconst_0       
        //   541: istore          11
        //   543: getstatic       dev/nuker/pyro/fc.c:I
        //   546: ifne            554
        //   549: ldc             1623091446
        //   551: goto            556
        //   554: ldc             797628065
        //   556: ldc             -1696379320
        //   558: ixor           
        //   559: lookupswitch {
        //          -1251370775: 584
        //          -94558530: 554
        //          default: 723
        //        }
        //   584: aload           9
        //   586: aload           10
        //   588: dup            
        //   589: arraylength    
        //   590: goto            594
        //   593: athrow         
        //   594: invokestatic    java/util/Arrays.copyOf:([Ljava/lang/Object;I)[Ljava/lang/Object;
        //   597: goto            601
        //   600: athrow         
        //   601: goto            605
        //   604: athrow         
        //   605: invokestatic    java/lang/String.format:(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
        //   608: goto            612
        //   611: athrow         
        //   612: dup            
        //   613: pop            
        //   614: astore          7
        //   616: aload_0        
        //   617: aload           7
        //   619: goto            623
        //   622: athrow         
        //   623: invokestatic    dev/nuker/pyro/fe6.c:(Ljava/lang/String;)F
        //   626: goto            630
        //   629: athrow         
        //   630: getstatic       dev/nuker/pyro/fc.0:I
        //   633: ifgt            641
        //   636: ldc             1125243770
        //   638: goto            643
        //   641: ldc             -395819277
        //   643: ldc             -122458776
        //   645: ixor           
        //   646: lookupswitch {
        //          -1146964462: 641
        //          282799003: 672
        //          default: 741
        //        }
        //   672: putfield        dev/nuker/pyro/f5R.c:F
        //   675: getstatic       dev/nuker/pyro/fy.c:Ldev/nuker/pyro/fy;
        //   678: dup            
        //   679: pop            
        //   680: goto            684
        //   683: athrow         
        //   684: invokevirtual   dev/nuker/pyro/fy.3:()Ldev/nuker/pyro/util/font/GameFontRenderer;
        //   687: goto            691
        //   690: athrow         
        //   691: aload           7
        //   693: aload_0        
        //   694: goto            698
        //   697: athrow         
        //   698: invokevirtual   dev/nuker/pyro/f5R.5:()F
        //   701: goto            705
        //   704: athrow         
        //   705: iconst_2       
        //   706: i2f            
        //   707: fdiv           
        //   708: fconst_0       
        //   709: iconst_m1      
        //   710: iconst_1       
        //   711: goto            715
        //   714: athrow         
        //   715: invokevirtual   dev/nuker/pyro/util/font/GameFontRenderer.drawCenteredString:(Ljava/lang/String;FFIZ)V
        //   718: goto            722
        //   721: athrow         
        //   722: return         
        //   723: aconst_null    
        //   724: athrow         
        //   725: aconst_null    
        //   726: athrow         
        //   727: aconst_null    
        //   728: athrow         
        //   729: aconst_null    
        //   730: athrow         
        //   731: aconst_null    
        //   732: athrow         
        //   733: aconst_null    
        //   734: athrow         
        //   735: aconst_null    
        //   736: athrow         
        //   737: aconst_null    
        //   738: athrow         
        //   739: aconst_null    
        //   740: athrow         
        //   741: aconst_null    
        //   742: athrow         
        //   743: pop            
        //   744: goto            24
        //   747: pop            
        //   748: aconst_null    
        //   749: goto            743
        //   752: dup            
        //   753: ifnull          743
        //   756: checkcast       Ljava/lang/Throwable;
        //   759: athrow         
        //   760: dup            
        //   761: ifnull          747
        //   764: checkcast       Ljava/lang/Throwable;
        //   767: athrow         
        //   768: aconst_null    
        //   769: athrow         
        //    StackMapTable: 00 6B 43 07 00 29 04 FF 00 0B 00 00 00 01 07 00 29 FF 00 03 00 06 07 00 03 07 00 B1 01 07 00 B3 02 02 00 00 42 07 00 29 00 45 07 00 29 40 04 FF 00 0B 00 06 07 00 03 07 00 B1 01 07 00 B3 02 02 00 02 04 07 00 03 FF 00 01 00 06 07 00 03 07 00 B1 01 07 00 B3 02 02 00 03 04 07 00 03 01 FF 00 1E 00 06 07 00 03 07 00 B1 01 07 00 B3 02 02 00 02 04 07 00 03 45 07 00 29 FF 00 00 00 06 07 00 03 07 00 B1 01 07 00 B3 02 02 00 02 04 07 00 39 45 07 00 29 FF 00 00 00 06 07 00 03 07 00 B1 01 07 00 B3 02 02 00 02 04 04 52 02 FF 00 01 00 06 07 00 03 07 00 B1 01 07 00 B3 02 02 00 02 02 01 5C 02 FC 00 0C 02 41 01 1C 07 04 41 01 18 50 07 00 18 40 07 00 90 45 07 00 29 40 07 00 90 FF 00 0D 00 07 07 00 03 07 00 B1 01 07 00 B3 02 02 02 00 04 07 00 90 02 02 01 FF 00 01 00 07 07 00 03 07 00 B1 01 07 00 B3 02 02 02 00 05 07 00 90 02 02 01 01 FF 00 1E 00 07 07 00 03 07 00 B1 01 07 00 B3 02 02 02 00 04 07 00 90 02 02 01 FF 00 02 00 00 00 01 07 00 29 FF 00 00 00 07 07 00 03 07 00 B1 01 07 00 B3 02 02 02 00 04 07 00 90 02 02 01 45 07 00 29 00 00 4F 07 00 50 FF 00 01 00 07 07 00 03 07 00 B1 01 07 00 B3 02 02 02 00 02 07 00 50 01 5D 07 00 50 42 07 00 29 40 07 00 50 45 07 00 29 40 01 03 0A 41 01 1B 4D 07 00 71 FF 00 01 00 07 07 00 03 07 00 B1 01 07 00 B3 02 02 02 00 02 07 00 71 01 5B 07 00 71 FF 00 06 00 09 07 00 03 07 00 B1 01 07 00 B3 02 02 02 00 07 00 71 00 01 07 00 B5 40 07 00 90 45 07 00 29 40 07 00 90 FF 00 12 00 0A 07 00 03 07 00 B1 01 07 00 B3 02 02 02 00 07 00 71 07 00 90 00 03 07 00 B7 07 00 B7 01 FF 00 01 00 0A 07 00 03 07 00 B1 01 07 00 B3 02 02 02 00 07 00 71 07 00 90 00 04 07 00 B7 07 00 B7 01 01 FF 00 1B 00 0A 07 00 03 07 00 B1 01 07 00 B3 02 02 02 00 07 00 71 07 00 90 00 03 07 00 B7 07 00 B7 01 FF 00 04 00 00 00 01 07 00 29 FF 00 00 00 0A 07 00 03 07 00 B1 01 07 00 B3 02 02 02 00 07 00 71 07 00 90 00 04 07 00 B7 07 00 B7 01 02 45 07 00 29 FF 00 00 00 0A 07 00 03 07 00 B1 01 07 00 B3 02 02 02 00 07 00 71 07 00 90 00 04 07 00 B7 07 00 B7 01 07 00 81 FD 00 10 07 00 B7 01 41 01 1B FF 00 08 00 00 00 01 07 00 29 FF 00 00 00 0C 07 00 03 07 00 B1 01 07 00 B3 02 02 02 00 07 00 71 07 00 90 07 00 B7 01 00 03 07 00 90 07 00 B7 01 45 07 00 29 FF 00 00 00 0C 07 00 03 07 00 B1 01 07 00 B3 02 02 02 00 07 00 71 07 00 90 07 00 B7 01 00 02 07 00 90 07 00 B7 42 07 00 29 FF 00 00 00 0C 07 00 03 07 00 B1 01 07 00 B3 02 02 02 00 07 00 71 07 00 90 07 00 B7 01 00 02 07 00 90 07 00 B7 45 07 00 29 40 07 00 90 FF 00 09 00 0C 07 00 03 07 00 B1 01 07 00 B3 02 02 02 07 00 90 07 00 71 07 00 90 07 00 B7 01 00 01 07 00 29 FF 00 00 00 0C 07 00 03 07 00 B1 01 07 00 B3 02 02 02 07 00 90 07 00 71 07 00 90 07 00 B7 01 00 02 07 00 03 07 00 90 45 07 00 29 FF 00 00 00 0C 07 00 03 07 00 B1 01 07 00 B3 02 02 02 07 00 90 07 00 71 07 00 90 07 00 B7 01 00 02 07 00 03 02 FF 00 0A 00 0C 07 00 03 07 00 B1 01 07 00 B3 02 02 02 07 00 90 07 00 71 07 00 90 07 00 B7 01 00 02 07 00 03 02 FF 00 01 00 0C 07 00 03 07 00 B1 01 07 00 B3 02 02 02 07 00 90 07 00 71 07 00 90 07 00 B7 01 00 03 07 00 03 02 01 FF 00 1C 00 0C 07 00 03 07 00 B1 01 07 00 B3 02 02 02 07 00 90 07 00 71 07 00 90 07 00 B7 01 00 02 07 00 03 02 4A 07 00 29 40 07 00 9E 45 07 00 29 40 07 00 AB FF 00 05 00 00 00 01 07 00 29 FF 00 00 00 0C 07 00 03 07 00 B1 01 07 00 B3 02 02 02 07 00 90 07 00 71 07 00 90 07 00 B7 01 00 03 07 00 AB 07 00 90 07 00 03 45 07 00 29 FF 00 00 00 0C 07 00 03 07 00 B1 01 07 00 B3 02 02 02 07 00 90 07 00 71 07 00 90 07 00 B7 01 00 03 07 00 AB 07 00 90 02 FF 00 08 00 00 00 01 07 00 29 FF 00 00 00 0C 07 00 03 07 00 B1 01 07 00 B3 02 02 02 07 00 90 07 00 71 07 00 90 07 00 B7 01 00 06 07 00 AB 07 00 90 02 02 01 01 45 07 00 29 00 FF 00 00 00 0C 07 00 03 07 00 B1 01 07 00 B3 02 02 02 00 07 00 71 07 00 90 07 00 B7 01 00 00 FF 00 01 00 07 07 00 03 07 00 B1 01 07 00 B3 02 02 02 00 04 07 00 90 02 02 01 FF 00 01 00 06 07 00 03 07 00 B1 01 07 00 B3 02 02 00 02 04 07 00 03 FF 00 01 00 07 07 00 03 07 00 B1 01 07 00 B3 02 02 02 00 01 07 00 71 41 07 00 50 FF 00 01 00 0A 07 00 03 07 00 B1 01 07 00 B3 02 02 02 00 07 00 71 07 00 90 00 03 07 00 B7 07 00 B7 01 F8 00 01 FF 00 01 00 06 07 00 03 07 00 B1 01 07 00 B3 02 02 00 01 02 FC 00 01 02 FF 00 01 00 0C 07 00 03 07 00 B1 01 07 00 B3 02 02 02 07 00 90 07 00 71 07 00 90 07 00 B7 01 00 02 07 00 03 02 FF 00 01 00 06 07 00 03 07 00 B1 01 07 00 B3 02 02 00 01 07 00 29 43 05 44 07 00 29 47 05 47 07 00 29
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     752    760    Any
        //  752    760    752    760    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  768    770    3      8      Ljava/lang/NumberFormatException;
        //  27     34     34     35     Any
        //  28     34     34     35     Ljava/lang/EnumConstantNotPresentException;
        //  27     34     34     35     Ljava/lang/NegativeArraySizeException;
        //  27     34     27     28     Any
        //  27     34     34     35     Any
        //  86     93     93     94     Any
        //  87     93     86     87     Any
        //  86     93     86     87     Ljava/lang/AssertionError;
        //  86     93     93     94     Ljava/lang/ArrayIndexOutOfBoundsException;
        //  87     93     3      8      Ljava/util/NoSuchElementException;
        //  245    252    252    253    Any
        //  246    252    252    253    Any
        //  246    252    245    246    Ljava/lang/NullPointerException;
        //  245    252    3      8      Ljava/util/NoSuchElementException;
        //  246    252    3      8      Any
        //  304    310    310    311    Any
        //  304    310    3      8      Ljava/lang/NumberFormatException;
        //  304    310    310    311    Ljava/util/NoSuchElementException;
        //  304    310    310    311    Any
        //  304    310    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  363    370    370    371    Any
        //  364    370    363    364    Any
        //  364    370    363    364    Any
        //  363    370    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  363    370    363    364    Any
        //  467    474    474    475    Any
        //  467    474    467    468    Ljava/lang/NumberFormatException;
        //  468    474    3      8      Any
        //  467    474    474    475    Any
        //  467    474    467    468    Ljava/lang/NegativeArraySizeException;
        //  530    536    536    537    Any
        //  530    536    536    537    Any
        //  530    536    536    537    Any
        //  530    536    3      8      Any
        //  530    536    536    537    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  594    600    600    601    Any
        //  594    600    3      8      Ljava/lang/ArithmeticException;
        //  594    600    3      8      Ljava/lang/IllegalStateException;
        //  594    600    3      8      Any
        //  594    600    600    601    Any
        //  604    611    611    612    Any
        //  604    611    604    605    Any
        //  605    611    611    612    Ljava/lang/ClassCastException;
        //  604    611    604    605    Ljava/lang/AssertionError;
        //  604    611    3      8      Ljava/lang/AssertionError;
        //  622    629    629    630    Any
        //  622    629    629    630    Ljava/lang/IndexOutOfBoundsException;
        //  623    629    622    623    Any
        //  622    629    622    623    Any
        //  623    629    622    623    Ljava/lang/ArithmeticException;
        //  683    690    690    691    Any
        //  684    690    690    691    Any
        //  683    690    683    684    Any
        //  683    690    690    691    Any
        //  683    690    683    684    Any
        //  698    704    704    705    Any
        //  698    704    704    705    Ljava/lang/ArithmeticException;
        //  698    704    3      8      Ljava/lang/ClassCastException;
        //  698    704    704    705    Ljava/util/NoSuchElementException;
        //  698    704    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  715    721    721    722    Any
        //  715    721    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  715    721    721    722    Ljava/lang/ClassCastException;
        //  715    721    3      8      Any
        //  715    721    3      8      Ljava/util/NoSuchElementException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:738)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public f5R() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: ldc             "\u3d77\ub240\u8e3c\uadb2\u6756\u5993\u7e6e\u6936\uc2d7\ua387\u9bd8\u1317\uc148\u7101\u908c\u4d8d\ub218\u4cbc\u0145"
        //     3: getstatic       dev/nuker/pyro/fc.1:I
        //     6: ifne            14
        //     9: ldc             -579781247
        //    11: goto            16
        //    14: ldc             -347779526
        //    16: ldc             375975377
        //    18: ixor           
        //    19: lookupswitch {
        //          -887500720: 14
        //          -47340565: 44
        //          default: 114
        //        }
        //    44: invokestatic    invokestatic   !!! ERROR
        //    47: aconst_null    
        //    48: iconst_2       
        //    49: aconst_null    
        //    50: invokespecial   dev/nuker/pyro/f5q.<init>:(Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
        //    53: getstatic       dev/nuker/pyro/fc.1:I
        //    56: ifne            64
        //    59: ldc             -1183608533
        //    61: goto            66
        //    64: ldc             -875834467
        //    66: ldc             -1100340258
        //    68: ixor           
        //    69: lookupswitch {
        //          -1573036125: 64
        //          119124725: 116
        //          default: 96
        //        }
        //    96: aload_0        
        //    97: new             Ldev/nuker/pyro/fe8;
        //   100: dup            
        //   101: invokespecial   dev/nuker/pyro/fe8.<init>:()V
        //   104: putfield        dev/nuker/pyro/f5R.c:Ldev/nuker/pyro/fe8;
        //   107: aload_0        
        //   108: ldc             50.0
        //   110: putfield        dev/nuker/pyro/f5R.c:F
        //   113: return         
        //   114: aconst_null    
        //   115: athrow         
        //   116: aconst_null    
        //   117: athrow         
        //    StackMapTable: 00 08 FF 00 0E 00 01 06 00 02 06 07 00 90 FF 00 01 00 01 06 00 03 06 07 00 90 01 FF 00 1B 00 01 06 00 02 06 07 00 90 FF 00 13 00 01 07 00 03 00 00 41 01 1D FF 00 11 00 01 06 00 02 06 07 00 90 FF 00 01 00 01 07 00 03 00 00
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2695)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @f0g
    @LauncherEventHide
    public void c(@NotNull final f4e f4e) {
        fez.2g(this, 1009386236, f4e);
    }
    
    static {
        throw t;
    }
    
    @Override
    public float 0() {
        return fez.ef(this, 2068008184);
    }
    
    @Override
    public float 5() {
        return fez.eP(this, 938611855);
    }
    
    @Override
    public boolean 1() {
        return fez.hv(this, 359565622);
    }
}
