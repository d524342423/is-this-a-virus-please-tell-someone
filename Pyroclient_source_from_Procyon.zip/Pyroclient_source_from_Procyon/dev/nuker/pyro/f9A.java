// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import net.minecraft.world.World;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.Minecraft;
import dev.nuker.pyro.security.inject.LauncherEventHide;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;

public class f9A extends fQ
{
    @NotNull
    public f0o<f9w> c;
    @NotNull
    public f0m c;
    @NotNull
    public f0k c;
    @NotNull
    public f0k 0;
    @NotNull
    public f0k 1;
    @Nullable
    public far c;
    public boolean c;
    public boolean 0;
    @Nullable
    public f6n c;
    public boolean 1;
    
    public void c(@Nullable final far far) {
        fez.8b(this, 718574810, far);
    }
    
    @f0g
    @LauncherEventHide
    public void c(@NotNull final f4e f4e) {
        fez.2h(this, 10317197, f4e);
    }
    
    @f0g
    @LauncherEventHide
    public void c(@NotNull final f4u p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          5072
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            5064
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            5056
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: aload_1        
        //    27: getstatic       dev/nuker/pyro/fc.1:I
        //    30: ifne            38
        //    33: ldc             -1156366695
        //    35: goto            40
        //    38: ldc             -1352658420
        //    40: ldc             2118589409
        //    42: ixor           
        //    43: lookupswitch {
        //          -984341128: 38
        //          -785970707: 68
        //          default: 5013
        //        }
        //    68: goto            72
        //    71: athrow         
        //    72: invokevirtual   dev/nuker/pyro/f4u.c:()Z
        //    75: goto            79
        //    78: athrow         
        //    79: ifne            4509
        //    82: aload_1        
        //    83: getstatic       dev/nuker/pyro/fc.c:I
        //    86: ifne            94
        //    89: ldc             -360530715
        //    91: goto            96
        //    94: ldc             -1230284188
        //    96: ldc             426488033
        //    98: ixor           
        //    99: lookupswitch {
        //          -589596612: 94
        //          -202830844: 4989
        //          default: 124
        //        }
        //   124: goto            128
        //   127: athrow         
        //   128: invokevirtual   dev/nuker/pyro/f4u.c:()Ldev/nuker/pyro/f41;
        //   131: goto            135
        //   134: athrow         
        //   135: getstatic       dev/nuker/pyro/f41.c:Ldev/nuker/pyro/f41;
        //   138: if_acmpne       4509
        //   141: aload_0        
        //   142: getfield        dev/nuker/pyro/f9A.1:Ldev/nuker/pyro/f0k;
        //   145: goto            149
        //   148: athrow         
        //   149: invokevirtual   dev/nuker/pyro/f0k.c:()Ljava/lang/Object;
        //   152: goto            156
        //   155: athrow         
        //   156: checkcast       Ljava/lang/Boolean;
        //   159: goto            163
        //   162: athrow         
        //   163: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   166: goto            170
        //   169: athrow         
        //   170: ifeq            178
        //   173: ldc             -1814412432
        //   175: goto            180
        //   178: ldc             -1814412431
        //   180: ldc             -975379258
        //   182: ixor           
        //   183: tableswitch {
        //          -1408413844: 204
        //          -1408413843: 4509
        //          default: 173
        //        }
        //   204: aload_0        
        //   205: getfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/f6n;
        //   208: ifnull          216
        //   211: ldc             -209291319
        //   213: goto            218
        //   216: ldc             -209291318
        //   218: ldc             -1899134436
        //   220: ixor           
        //   221: tableswitch {
        //          -90707030: 244
        //          -90707029: 4509
        //          default: 211
        //        }
        //   244: aload_0        
        //   245: getfield        dev/nuker/pyro/f9A.1:Z
        //   248: ifne            3474
        //   251: aload_0        
        //   252: goto            256
        //   255: athrow         
        //   256: invokespecial   dev/nuker/pyro/f9A.c:()Z
        //   259: goto            263
        //   262: athrow         
        //   263: ifne            267
        //   266: return         
        //   267: new             Lkotlin/jvm/internal/Ref$ObjectRef;
        //   270: dup            
        //   271: goto            275
        //   274: athrow         
        //   275: invokespecial   kotlin/jvm/internal/Ref$ObjectRef.<init>:()V
        //   278: goto            282
        //   281: athrow         
        //   282: astore_2       
        //   283: getstatic       dev/nuker/pyro/fc.c:I
        //   286: ifne            294
        //   289: ldc             48029351
        //   291: goto            296
        //   294: ldc             333552369
        //   296: ldc             601158105
        //   298: ixor           
        //   299: lookupswitch {
        //          -1154052484: 294
        //          554184574: 5043
        //          default: 324
        //        }
        //   324: aload_2        
        //   325: aconst_null    
        //   326: checkcast       Lnet/minecraft/util/EnumFacing;
        //   329: getstatic       dev/nuker/pyro/fc.c:I
        //   332: ifne            340
        //   335: ldc             1935324858
        //   337: goto            342
        //   340: ldc             904127481
        //   342: ldc             -682623495
        //   344: ixor           
        //   345: lookupswitch {
        //          -1542108349: 4923
        //          587664762: 340
        //          default: 372
        //        }
        //   372: putfield        kotlin/jvm/internal/Ref$ObjectRef.element:Ljava/lang/Object;
        //   375: new             Lkotlin/jvm/internal/Ref$BooleanRef;
        //   378: dup            
        //   379: goto            383
        //   382: athrow         
        //   383: invokespecial   kotlin/jvm/internal/Ref$BooleanRef.<init>:()V
        //   386: goto            390
        //   389: athrow         
        //   390: getstatic       dev/nuker/pyro/fc.0:I
        //   393: ifgt            401
        //   396: ldc             -1325042988
        //   398: goto            403
        //   401: ldc             -1486104695
        //   403: ldc             226045087
        //   405: ixor           
        //   406: lookupswitch {
        //          -1441596650: 432
        //          -1132700085: 401
        //          default: 5033
        //        }
        //   432: astore_3       
        //   433: aload_3        
        //   434: getstatic       dev/nuker/pyro/fc.1:I
        //   437: ifne            445
        //   440: ldc             -159070785
        //   442: goto            447
        //   445: ldc             -1012656617
        //   447: ldc             -195355504
        //   449: ixor           
        //   450: lookupswitch {
        //          48224559: 5001
        //          1704274319: 445
        //          default: 476
        //        }
        //   476: aload_0        
        //   477: getfield        dev/nuker/pyro/f9A.c:Lnet/minecraft/client/Minecraft;
        //   480: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   483: dup            
        //   484: pop            
        //   485: goto            489
        //   488: athrow         
        //   489: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_184592_cb:()Lnet/minecraft/item/ItemStack;
        //   492: goto            496
        //   495: athrow         
        //   496: dup            
        //   497: pop            
        //   498: goto            502
        //   501: athrow         
        //   502: invokevirtual   net/minecraft/item/ItemStack.func_77973_b:()Lnet/minecraft/item/Item;
        //   505: goto            509
        //   508: athrow         
        //   509: getstatic       net/minecraft/init/Items.field_185158_cP:Lnet/minecraft/item/Item;
        //   512: goto            516
        //   515: athrow         
        //   516: invokestatic    kotlin/jvm/internal/Intrinsics.areEqual:(Ljava/lang/Object;Ljava/lang/Object;)Z
        //   519: goto            523
        //   522: athrow         
        //   523: putfield        kotlin/jvm/internal/Ref$BooleanRef.element:Z
        //   526: aload_0        
        //   527: getfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/f6n;
        //   530: dup            
        //   531: ifnonnull       545
        //   534: goto            538
        //   537: athrow         
        //   538: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //   541: goto            545
        //   544: athrow         
        //   545: getstatic       dev/nuker/pyro/fc.1:I
        //   548: ifne            556
        //   551: ldc             -1808187129
        //   553: goto            558
        //   556: ldc             -1836324402
        //   558: ldc             -2025143652
        //   560: ixor           
        //   561: lookupswitch {
        //          326337435: 556
        //          364981074: 588
        //          default: 5035
        //        }
        //   588: goto            592
        //   591: athrow         
        //   592: invokevirtual   dev/nuker/pyro/f6n.0:()Ldev/nuker/pyro/feh;
        //   595: goto            599
        //   598: athrow         
        //   599: ifnull          1261
        //   602: aload_1        
        //   603: goto            607
        //   606: athrow         
        //   607: invokevirtual   dev/nuker/pyro/f4u.0:()V
        //   610: goto            614
        //   613: athrow         
        //   614: aload_1        
        //   615: aload_0        
        //   616: getfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/f6n;
        //   619: dup            
        //   620: ifnonnull       675
        //   623: getstatic       dev/nuker/pyro/fc.1:I
        //   626: ifne            634
        //   629: ldc             -1317742003
        //   631: goto            636
        //   634: ldc             873932398
        //   636: ldc             826403953
        //   638: ixor           
        //   639: lookupswitch {
        //          -2143996356: 4911
        //          -940788716: 634
        //          default: 664
        //        }
        //   664: goto            668
        //   667: athrow         
        //   668: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //   671: goto            675
        //   674: athrow         
        //   675: goto            679
        //   678: athrow         
        //   679: invokevirtual   dev/nuker/pyro/f6n.0:()Ldev/nuker/pyro/feh;
        //   682: goto            686
        //   685: athrow         
        //   686: dup            
        //   687: ifnonnull       695
        //   690: ldc             203548130
        //   692: goto            697
        //   695: ldc             203548157
        //   697: ldc             487914093
        //   699: ixor           
        //   700: tableswitch {
        //          577388318: 724
        //          577388319: 735
        //          default: 690
        //        }
        //   724: goto            728
        //   727: athrow         
        //   728: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //   731: goto            735
        //   734: athrow         
        //   735: getstatic       dev/nuker/pyro/fc.0:I
        //   738: ifgt            746
        //   741: ldc             241884427
        //   743: goto            748
        //   746: ldc             1653288852
        //   748: ldc             739810681
        //   750: ixor           
        //   751: lookupswitch {
        //          577912946: 746
        //          1318302445: 776
        //          default: 5037
        //        }
        //   776: goto            780
        //   779: athrow         
        //   780: invokevirtual   dev/nuker/pyro/feh.1:()Ldev/nuker/pyro/fex;
        //   783: goto            787
        //   786: athrow         
        //   787: goto            791
        //   790: athrow         
        //   791: invokevirtual   dev/nuker/pyro/fex.4:()Ldev/nuker/pyro/feu;
        //   794: goto            798
        //   797: athrow         
        //   798: goto            802
        //   801: athrow         
        //   802: invokevirtual   dev/nuker/pyro/feu.2:()F
        //   805: goto            809
        //   808: athrow         
        //   809: goto            813
        //   812: athrow         
        //   813: invokevirtual   dev/nuker/pyro/f4u.c:(F)V
        //   816: goto            820
        //   819: athrow         
        //   820: aload_1        
        //   821: aload_0        
        //   822: getstatic       dev/nuker/pyro/fc.0:I
        //   825: ifgt            833
        //   828: ldc             -2125617658
        //   830: goto            835
        //   833: ldc             -1110446280
        //   835: ldc             145609925
        //   837: ixor           
        //   838: lookupswitch {
        //          -1981779261: 833
        //          -1251853315: 864
        //          default: 5007
        //        }
        //   864: getfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/f6n;
        //   867: dup            
        //   868: ifnonnull       876
        //   871: ldc             18616343
        //   873: goto            878
        //   876: ldc             18616340
        //   878: ldc             484302906
        //   880: ixor           
        //   881: tableswitch {
        //          998498394: 904
        //          998498395: 915
        //          default: 871
        //        }
        //   904: goto            908
        //   907: athrow         
        //   908: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //   911: goto            915
        //   914: athrow         
        //   915: goto            919
        //   918: athrow         
        //   919: invokevirtual   dev/nuker/pyro/f6n.0:()Ldev/nuker/pyro/feh;
        //   922: goto            926
        //   925: athrow         
        //   926: dup            
        //   927: ifnonnull       983
        //   930: getstatic       dev/nuker/pyro/fc.c:I
        //   933: ifne            941
        //   936: ldc             -1750502505
        //   938: goto            943
        //   941: ldc             1216249182
        //   943: ldc             -778858010
        //   945: ixor           
        //   946: lookupswitch {
        //          -1712460616: 972
        //          1178264177: 941
        //          default: 5027
        //        }
        //   972: goto            976
        //   975: athrow         
        //   976: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //   979: goto            983
        //   982: athrow         
        //   983: getstatic       dev/nuker/pyro/fc.0:I
        //   986: ifgt            994
        //   989: ldc             -1140721962
        //   991: goto            996
        //   994: ldc             -1530071046
        //   996: ldc             621131953
        //   998: ixor           
        //   999: lookupswitch {
        //          -1727771033: 4947
        //          -1204449124: 994
        //          default: 1024
        //        }
        //  1024: goto            1028
        //  1027: athrow         
        //  1028: invokevirtual   dev/nuker/pyro/feh.1:()Ldev/nuker/pyro/fex;
        //  1031: goto            1035
        //  1034: athrow         
        //  1035: goto            1039
        //  1038: athrow         
        //  1039: invokevirtual   dev/nuker/pyro/fex.4:()Ldev/nuker/pyro/feu;
        //  1042: goto            1046
        //  1045: athrow         
        //  1046: goto            1050
        //  1049: athrow         
        //  1050: invokevirtual   dev/nuker/pyro/feu.0:()F
        //  1053: goto            1057
        //  1056: athrow         
        //  1057: getstatic       dev/nuker/pyro/fc.0:I
        //  1060: ifgt            1068
        //  1063: ldc             -1411808958
        //  1065: goto            1070
        //  1068: ldc             681398722
        //  1070: ldc             -910677063
        //  1072: ixor           
        //  1073: lookupswitch {
        //          -517637509: 1100
        //          1650567931: 1068
        //          default: 4993
        //        }
        //  1100: goto            1104
        //  1103: athrow         
        //  1104: invokevirtual   dev/nuker/pyro/f4u.0:(F)V
        //  1107: goto            1111
        //  1110: athrow         
        //  1111: aload_2        
        //  1112: getstatic       dev/nuker/pyro/fc.1:I
        //  1115: ifne            1123
        //  1118: ldc             1761327913
        //  1120: goto            1125
        //  1123: ldc             995493861
        //  1125: ldc             1744208159
        //  1127: ixor           
        //  1128: lookupswitch {
        //          252525110: 4987
        //          576022444: 1123
        //          default: 1156
        //        }
        //  1156: aload_0        
        //  1157: getfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/f6n;
        //  1160: dup            
        //  1161: ifnonnull       1175
        //  1164: goto            1168
        //  1167: athrow         
        //  1168: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //  1171: goto            1175
        //  1174: athrow         
        //  1175: goto            1179
        //  1178: athrow         
        //  1179: invokevirtual   dev/nuker/pyro/f6n.0:()Ldev/nuker/pyro/feh;
        //  1182: goto            1186
        //  1185: athrow         
        //  1186: dup            
        //  1187: ifnonnull       1201
        //  1190: goto            1194
        //  1193: athrow         
        //  1194: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //  1197: goto            1201
        //  1200: athrow         
        //  1201: getstatic       dev/nuker/pyro/fc.c:I
        //  1204: ifne            1212
        //  1207: ldc             2009154711
        //  1209: goto            1214
        //  1212: ldc             1091566482
        //  1214: ldc             -1272611418
        //  1216: ixor           
        //  1217: lookupswitch {
        //          -1008453327: 4983
        //          -461063772: 1212
        //          default: 1244
        //        }
        //  1244: goto            1248
        //  1247: athrow         
        //  1248: invokevirtual   dev/nuker/pyro/feh.0:()Lnet/minecraft/util/EnumFacing;
        //  1251: goto            1255
        //  1254: athrow         
        //  1255: putfield        kotlin/jvm/internal/Ref$ObjectRef.element:Ljava/lang/Object;
        //  1258: goto            1663
        //  1261: aload_2        
        //  1262: aload_0        
        //  1263: getfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/f6n;
        //  1266: dup            
        //  1267: ifnonnull       1281
        //  1270: goto            1274
        //  1273: athrow         
        //  1274: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //  1277: goto            1281
        //  1280: athrow         
        //  1281: checkcast       Lnet/minecraft/util/math/BlockPos;
        //  1284: iconst_1       
        //  1285: goto            1289
        //  1288: athrow         
        //  1289: invokestatic    dev/nuker/pyro/few.c:(Lnet/minecraft/util/math/BlockPos;Z)Lnet/minecraft/util/EnumFacing;
        //  1292: goto            1296
        //  1295: athrow         
        //  1296: getstatic       dev/nuker/pyro/fc.c:I
        //  1299: ifne            1308
        //  1302: ldc_w           440287264
        //  1305: goto            1311
        //  1308: ldc_w           -1834479724
        //  1311: ldc_w           1977742825
        //  1314: ixor           
        //  1315: lookupswitch {
        //          -414582147: 1340
        //          1876932041: 1308
        //          default: 4957
        //        }
        //  1340: putfield        kotlin/jvm/internal/Ref$ObjectRef.element:Ljava/lang/Object;
        //  1343: goto            1347
        //  1346: athrow         
        //  1347: invokestatic    dev/nuker/pyro/few.c:()Ldev/nuker/pyro/few;
        //  1350: goto            1354
        //  1353: athrow         
        //  1354: getstatic       dev/nuker/pyro/fc.c:I
        //  1357: ifne            1366
        //  1360: ldc_w           -374489920
        //  1363: goto            1369
        //  1366: ldc_w           2106734408
        //  1369: ldc_w           1779236962
        //  1372: ixor           
        //  1373: lookupswitch {
        //          -2086617950: 1366
        //          396310314: 1400
        //          default: 4913
        //        }
        //  1400: aload_0        
        //  1401: getfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/f6n;
        //  1404: dup            
        //  1405: ifnonnull       1463
        //  1408: getstatic       dev/nuker/pyro/fc.1:I
        //  1411: ifne            1420
        //  1414: ldc_w           -201011210
        //  1417: goto            1423
        //  1420: ldc_w           1734140170
        //  1423: ldc_w           -881208383
        //  1426: ixor           
        //  1427: lookupswitch {
        //          1065163831: 4953
        //          1633106688: 1420
        //          default: 1452
        //        }
        //  1452: goto            1456
        //  1455: athrow         
        //  1456: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //  1459: goto            1463
        //  1462: athrow         
        //  1463: checkcast       Lnet/minecraft/util/math/BlockPos;
        //  1466: aload_2        
        //  1467: getfield        kotlin/jvm/internal/Ref$ObjectRef.element:Ljava/lang/Object;
        //  1470: checkcast       Lnet/minecraft/util/EnumFacing;
        //  1473: goto            1477
        //  1476: athrow         
        //  1477: invokevirtual   dev/nuker/pyro/few.0:(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;)[F
        //  1480: goto            1484
        //  1483: athrow         
        //  1484: astore          4
        //  1486: aload_1        
        //  1487: goto            1491
        //  1490: athrow         
        //  1491: invokevirtual   dev/nuker/pyro/f4u.0:()V
        //  1494: goto            1498
        //  1497: athrow         
        //  1498: aload_1        
        //  1499: getstatic       dev/nuker/pyro/fc.0:I
        //  1502: ifgt            1511
        //  1505: ldc_w           -1777059283
        //  1508: goto            1514
        //  1511: ldc_w           421395822
        //  1514: ldc_w           431382656
        //  1517: ixor           
        //  1518: lookupswitch {
        //          -1885185363: 5009
        //          -91106381: 1511
        //          default: 1544
        //        }
        //  1544: aload           4
        //  1546: iconst_1       
        //  1547: faload         
        //  1548: goto            1552
        //  1551: athrow         
        //  1552: invokevirtual   dev/nuker/pyro/f4u.c:(F)V
        //  1555: goto            1559
        //  1558: athrow         
        //  1559: aload_1        
        //  1560: getstatic       dev/nuker/pyro/fc.0:I
        //  1563: ifgt            1572
        //  1566: ldc_w           -983166917
        //  1569: goto            1575
        //  1572: ldc_w           207546167
        //  1575: ldc_w           -1267408015
        //  1578: ixor           
        //  1579: lookupswitch {
        //          -1179851160: 1572
        //          1897067338: 5029
        //          default: 1604
        //        }
        //  1604: aload           4
        //  1606: iconst_0       
        //  1607: faload         
        //  1608: getstatic       dev/nuker/pyro/fc.0:I
        //  1611: ifgt            1620
        //  1614: ldc_w           1885495634
        //  1617: goto            1623
        //  1620: ldc_w           1836209296
        //  1623: ldc_w           2055953776
        //  1626: ixor           
        //  1627: lookupswitch {
        //          183057442: 4955
        //          845479158: 1620
        //          default: 1652
        //        }
        //  1652: goto            1656
        //  1655: athrow         
        //  1656: invokevirtual   dev/nuker/pyro/f4u.0:(F)V
        //  1659: goto            1663
        //  1662: athrow         
        //  1663: aload_0        
        //  1664: getstatic       dev/nuker/pyro/fc.c:I
        //  1667: ifne            1676
        //  1670: ldc_w           -382394804
        //  1673: goto            1679
        //  1676: ldc_w           468009558
        //  1679: ldc_w           364259047
        //  1682: ixor           
        //  1683: lookupswitch {
        //          -58509141: 5045
        //          1075053792: 1676
        //          default: 1708
        //        }
        //  1708: getfield        dev/nuker/pyro/f9A.c:Lnet/minecraft/client/Minecraft;
        //  1711: getstatic       dev/nuker/pyro/fc.0:I
        //  1714: ifgt            1723
        //  1717: ldc_w           120491308
        //  1720: goto            1726
        //  1723: ldc_w           -262485684
        //  1726: ldc_w           591497532
        //  1729: ixor           
        //  1730: lookupswitch {
        //          -753188752: 1756
        //          611255312: 1723
        //          default: 4907
        //        }
        //  1756: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1759: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70125_A:F
        //  1762: getstatic       dev/nuker/pyro/fc.1:I
        //  1765: ifne            1774
        //  1768: ldc_w           -1331166400
        //  1771: goto            1777
        //  1774: ldc_w           559311412
        //  1777: ldc_w           698960989
        //  1780: ixor           
        //  1781: lookupswitch {
        //          -1727967459: 4925
        //          -76397219: 1774
        //          default: 1808
        //        }
        //  1808: fstore          4
        //  1810: aload_0        
        //  1811: getfield        dev/nuker/pyro/f9A.c:Lnet/minecraft/client/Minecraft;
        //  1814: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1817: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70177_z:F
        //  1820: fstore          5
        //  1822: aload_0        
        //  1823: getfield        dev/nuker/pyro/f9A.c:Lnet/minecraft/client/Minecraft;
        //  1826: dup            
        //  1827: pop            
        //  1828: goto            1832
        //  1831: athrow         
        //  1832: invokevirtual   net/minecraft/client/Minecraft.func_184121_ak:()F
        //  1835: goto            1839
        //  1838: athrow         
        //  1839: getstatic       dev/nuker/pyro/fc.c:I
        //  1842: ifne            1851
        //  1845: ldc_w           -1675988476
        //  1848: goto            1854
        //  1851: ldc_w           -647161534
        //  1854: ldc_w           -1546363920
        //  1857: ixor           
        //  1858: lookupswitch {
        //          1070475764: 1851
        //          2058961586: 1884
        //          default: 5005
        //        }
        //  1884: fstore          6
        //  1886: aload_0        
        //  1887: getstatic       dev/nuker/pyro/fc.1:I
        //  1890: ifne            1899
        //  1893: ldc_w           810607191
        //  1896: goto            1902
        //  1899: ldc_w           -1056588248
        //  1902: ldc_w           -2077743420
        //  1905: ixor           
        //  1906: lookupswitch {
        //          -1434304372: 1899
        //          -1267153773: 4979
        //          default: 1932
        //        }
        //  1932: getfield        dev/nuker/pyro/f9A.c:Lnet/minecraft/client/Minecraft;
        //  1935: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1938: aload_1        
        //  1939: getstatic       dev/nuker/pyro/fc.1:I
        //  1942: ifne            1951
        //  1945: ldc_w           -165302950
        //  1948: goto            1954
        //  1951: ldc_w           2065312761
        //  1954: ldc_w           -1606983102
        //  1957: ixor           
        //  1958: lookupswitch {
        //          -1040569457: 1951
        //          1444073240: 4963
        //          default: 1984
        //        }
        //  1984: goto            1988
        //  1987: athrow         
        //  1988: invokevirtual   dev/nuker/pyro/f4u.2:()F
        //  1991: goto            1995
        //  1994: athrow         
        //  1995: putfield        net/minecraft/client/entity/EntityPlayerSP.field_70125_A:F
        //  1998: aload_0        
        //  1999: getstatic       dev/nuker/pyro/fc.1:I
        //  2002: ifne            2011
        //  2005: ldc_w           1202462160
        //  2008: goto            2014
        //  2011: ldc_w           -1850212839
        //  2014: ldc_w           1659450885
        //  2017: ixor           
        //  2018: lookupswitch {
        //          625290197: 4973
        //          961677203: 2011
        //          default: 2044
        //        }
        //  2044: getfield        dev/nuker/pyro/f9A.c:Lnet/minecraft/client/Minecraft;
        //  2047: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  2050: aload_1        
        //  2051: goto            2055
        //  2054: athrow         
        //  2055: invokevirtual   dev/nuker/pyro/f4u.5:()F
        //  2058: goto            2062
        //  2061: athrow         
        //  2062: getstatic       dev/nuker/pyro/fc.1:I
        //  2065: ifne            2074
        //  2068: ldc_w           946650548
        //  2071: goto            2077
        //  2074: ldc_w           1037844086
        //  2077: ldc_w           446463045
        //  2080: ixor           
        //  2081: lookupswitch {
        //          -172000369: 2074
        //          586203633: 4967
        //          default: 2108
        //        }
        //  2108: putfield        net/minecraft/client/entity/EntityPlayerSP.field_70177_z:F
        //  2111: aload_0        
        //  2112: getfield        dev/nuker/pyro/f9A.c:Lnet/minecraft/client/Minecraft;
        //  2115: getstatic       dev/nuker/pyro/fc.0:I
        //  2118: ifgt            2127
        //  2121: ldc_w           -1904548250
        //  2124: goto            2130
        //  2127: ldc_w           1788773105
        //  2130: ldc_w           -2013748809
        //  2133: ixor           
        //  2134: lookupswitch {
        //          -1189454284: 2127
        //          159533009: 5025
        //          default: 2160
        //        }
        //  2160: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  2163: getstatic       dev/nuker/pyro/fc.0:I
        //  2166: ifgt            2175
        //  2169: ldc_w           -1699205921
        //  2172: goto            2178
        //  2175: ldc_w           929234704
        //  2178: ldc_w           -1686004011
        //  2181: ixor           
        //  2182: lookupswitch {
        //          -1394384443: 2208
        //          20558346: 2175
        //          default: 4997
        //        }
        //  2208: aload_0        
        //  2209: getfield        dev/nuker/pyro/f9A.c:Lnet/minecraft/client/Minecraft;
        //  2212: getfield        net/minecraft/client/Minecraft.field_71442_b:Lnet/minecraft/client/multiplayer/PlayerControllerMP;
        //  2215: dup            
        //  2216: pop            
        //  2217: goto            2221
        //  2220: athrow         
        //  2221: invokevirtual   net/minecraft/client/multiplayer/PlayerControllerMP.func_78757_d:()F
        //  2224: goto            2228
        //  2227: athrow         
        //  2228: f2d            
        //  2229: getstatic       dev/nuker/pyro/fc.c:I
        //  2232: ifne            2241
        //  2235: ldc_w           2048462038
        //  2238: goto            2244
        //  2241: ldc_w           599273750
        //  2244: ldc_w           1579571700
        //  2247: ixor           
        //  2248: lookupswitch {
        //          -1027960177: 2241
        //          608130338: 5021
        //          default: 2276
        //        }
        //  2276: fload           6
        //  2278: goto            2282
        //  2281: athrow         
        //  2282: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_174822_a:(DF)Lnet/minecraft/util/math/RayTraceResult;
        //  2285: goto            2289
        //  2288: athrow         
        //  2289: astore          7
        //  2291: new             Lkotlin/jvm/internal/Ref$FloatRef;
        //  2294: dup            
        //  2295: getstatic       dev/nuker/pyro/fc.1:I
        //  2298: ifne            2307
        //  2301: ldc_w           1648758155
        //  2304: goto            2310
        //  2307: ldc_w           1165766850
        //  2310: ldc_w           -1325523016
        //  2313: ixor           
        //  2314: lookupswitch {
        //          -759688653: 4999
        //          508324331: 2307
        //          default: 2340
        //        }
        //  2340: goto            2344
        //  2343: athrow         
        //  2344: invokespecial   kotlin/jvm/internal/Ref$FloatRef.<init>:()V
        //  2347: goto            2351
        //  2350: athrow         
        //  2351: astore          8
        //  2353: aload           8
        //  2355: fconst_0       
        //  2356: getstatic       dev/nuker/pyro/fc.1:I
        //  2359: ifne            2368
        //  2362: ldc_w           1276475663
        //  2365: goto            2371
        //  2368: ldc_w           -207815721
        //  2371: ldc_w           -1775263496
        //  2374: ixor           
        //  2375: lookupswitch {
        //          -633677321: 4995
        //          -401042249: 2368
        //          default: 2400
        //        }
        //  2400: putfield        kotlin/jvm/internal/Ref$FloatRef.element:F
        //  2403: new             Lkotlin/jvm/internal/Ref$FloatRef;
        //  2406: dup            
        //  2407: getstatic       dev/nuker/pyro/fc.1:I
        //  2410: ifne            2419
        //  2413: ldc_w           275467117
        //  2416: goto            2422
        //  2419: ldc_w           -1282202951
        //  2422: ldc_w           -1561209698
        //  2425: ixor           
        //  2426: lookupswitch {
        //          -1298489357: 5015
        //          -629764585: 2419
        //          default: 2452
        //        }
        //  2452: goto            2456
        //  2455: athrow         
        //  2456: invokespecial   kotlin/jvm/internal/Ref$FloatRef.<init>:()V
        //  2459: goto            2463
        //  2462: athrow         
        //  2463: getstatic       dev/nuker/pyro/fc.0:I
        //  2466: ifgt            2475
        //  2469: ldc_w           372677641
        //  2472: goto            2478
        //  2475: ldc_w           392276727
        //  2478: ldc_w           -1763099746
        //  2481: ixor           
        //  2482: lookupswitch {
        //          -2132826217: 4941
        //          -352657819: 2475
        //          default: 2508
        //        }
        //  2508: astore          9
        //  2510: getstatic       dev/nuker/pyro/fc.0:I
        //  2513: ifgt            2522
        //  2516: ldc_w           -252333168
        //  2519: goto            2525
        //  2522: ldc_w           201964985
        //  2525: ldc_w           -1135743193
        //  2528: ixor           
        //  2529: lookupswitch {
        //          -1337699682: 2556
        //          1287150775: 2522
        //          default: 4991
        //        }
        //  2556: aload           9
        //  2558: fconst_0       
        //  2559: putfield        kotlin/jvm/internal/Ref$FloatRef.element:F
        //  2562: new             Lkotlin/jvm/internal/Ref$FloatRef;
        //  2565: dup            
        //  2566: goto            2570
        //  2569: athrow         
        //  2570: invokespecial   kotlin/jvm/internal/Ref$FloatRef.<init>:()V
        //  2573: goto            2577
        //  2576: athrow         
        //  2577: astore          10
        //  2579: aload           10
        //  2581: fconst_0       
        //  2582: getstatic       dev/nuker/pyro/fc.1:I
        //  2585: ifne            2594
        //  2588: ldc_w           -2047497535
        //  2591: goto            2597
        //  2594: ldc_w           -957691583
        //  2597: ldc_w           1454527653
        //  2600: ixor           
        //  2601: lookupswitch {
        //          -974949549: 2594
        //          -750256540: 5039
        //          default: 2628
        //        }
        //  2628: putfield        kotlin/jvm/internal/Ref$FloatRef.element:F
        //  2631: aload           7
        //  2633: ifnull          3091
        //  2636: aload           8
        //  2638: aload           7
        //  2640: getfield        net/minecraft/util/math/RayTraceResult.field_72307_f:Lnet/minecraft/util/math/Vec3d;
        //  2643: getstatic       dev/nuker/pyro/fc.0:I
        //  2646: ifgt            2655
        //  2649: ldc_w           618797782
        //  2652: goto            2658
        //  2655: ldc_w           145528404
        //  2658: ldc_w           -457978568
        //  2661: ixor           
        //  2662: lookupswitch {
        //          -1068378130: 2655
        //          -333489300: 2688
        //          default: 4909
        //        }
        //  2688: getfield        net/minecraft/util/math/Vec3d.field_72450_a:D
        //  2691: aload_0        
        //  2692: getfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/f6n;
        //  2695: dup            
        //  2696: ifnonnull       2755
        //  2699: getstatic       dev/nuker/pyro/fc.c:I
        //  2702: ifne            2711
        //  2705: ldc_w           -1529980471
        //  2708: goto            2714
        //  2711: ldc_w           555003935
        //  2714: ldc_w           534789122
        //  2717: ixor           
        //  2718: lookupswitch {
        //          -1154587189: 4961
        //          200873795: 2711
        //          default: 2744
        //        }
        //  2744: goto            2748
        //  2747: athrow         
        //  2748: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //  2751: goto            2755
        //  2754: athrow         
        //  2755: goto            2759
        //  2758: athrow         
        //  2759: invokevirtual   dev/nuker/pyro/f6n.func_177958_n:()I
        //  2762: goto            2766
        //  2765: athrow         
        //  2766: i2d            
        //  2767: dsub           
        //  2768: d2f            
        //  2769: putfield        kotlin/jvm/internal/Ref$FloatRef.element:F
        //  2772: aload           9
        //  2774: getstatic       dev/nuker/pyro/fc.0:I
        //  2777: ifgt            2786
        //  2780: ldc_w           1902488804
        //  2783: goto            2789
        //  2786: ldc_w           -1986817400
        //  2789: ldc_w           2077424564
        //  2792: ixor           
        //  2793: lookupswitch {
        //          -230594244: 2820
        //          179787600: 2786
        //          default: 4959
        //        }
        //  2820: aload           7
        //  2822: getfield        net/minecraft/util/math/RayTraceResult.field_72307_f:Lnet/minecraft/util/math/Vec3d;
        //  2825: getfield        net/minecraft/util/math/Vec3d.field_72448_b:D
        //  2828: aload_0        
        //  2829: getfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/f6n;
        //  2832: dup            
        //  2833: ifnonnull       2847
        //  2836: goto            2840
        //  2839: athrow         
        //  2840: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //  2843: goto            2847
        //  2846: athrow         
        //  2847: goto            2851
        //  2850: athrow         
        //  2851: invokevirtual   dev/nuker/pyro/f6n.func_177956_o:()I
        //  2854: goto            2858
        //  2857: athrow         
        //  2858: i2d            
        //  2859: dsub           
        //  2860: d2f            
        //  2861: putfield        kotlin/jvm/internal/Ref$FloatRef.element:F
        //  2864: getstatic       dev/nuker/pyro/fc.1:I
        //  2867: ifne            2876
        //  2870: ldc_w           1906526236
        //  2873: goto            2879
        //  2876: ldc_w           -978030835
        //  2879: ldc_w           980640839
        //  2882: ixor           
        //  2883: lookupswitch {
        //          -3732662: 2908
        //          1271934043: 2876
        //          default: 4949
        //        }
        //  2908: aload           10
        //  2910: aload           7
        //  2912: getstatic       dev/nuker/pyro/fc.c:I
        //  2915: ifne            2924
        //  2918: ldc_w           -1596833522
        //  2921: goto            2927
        //  2924: ldc_w           -674411257
        //  2927: ldc_w           -128129030
        //  2930: ixor           
        //  2931: lookupswitch {
        //          798075645: 2956
        //          1485743860: 2924
        //          default: 4945
        //        }
        //  2956: getfield        net/minecraft/util/math/RayTraceResult.field_72307_f:Lnet/minecraft/util/math/Vec3d;
        //  2959: getfield        net/minecraft/util/math/Vec3d.field_72449_c:D
        //  2962: aload_0        
        //  2963: getfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/f6n;
        //  2966: dup            
        //  2967: ifnonnull       3027
        //  2970: getstatic       dev/nuker/pyro/fc.c:I
        //  2973: ifne            2982
        //  2976: ldc_w           1211412556
        //  2979: goto            2985
        //  2982: ldc_w           -1576530037
        //  2985: ldc_w           -308897693
        //  2988: ixor           
        //  2989: lookupswitch {
        //          -1516099537: 2982
        //          1335793640: 3016
        //          default: 5011
        //        }
        //  3016: goto            3020
        //  3019: athrow         
        //  3020: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //  3023: goto            3027
        //  3026: athrow         
        //  3027: goto            3031
        //  3030: athrow         
        //  3031: invokevirtual   dev/nuker/pyro/f6n.func_177952_p:()I
        //  3034: goto            3038
        //  3037: athrow         
        //  3038: i2d            
        //  3039: dsub           
        //  3040: d2f            
        //  3041: getstatic       dev/nuker/pyro/fc.1:I
        //  3044: ifne            3053
        //  3047: ldc_w           -1623226580
        //  3050: goto            3056
        //  3053: ldc_w           792875839
        //  3056: ldc_w           478684755
        //  3059: ixor           
        //  3060: lookupswitch {
        //          -2085117569: 4965
        //          504457983: 3053
        //          default: 3088
        //        }
        //  3088: putfield        kotlin/jvm/internal/Ref$FloatRef.element:F
        //  3091: getstatic       dev/nuker/pyro/fc.0:I
        //  3094: ifgt            3103
        //  3097: ldc_w           -2011504131
        //  3100: goto            3106
        //  3103: ldc_w           -961257816
        //  3106: ldc_w           2008506699
        //  3109: ixor           
        //  3110: lookupswitch {
        //          -766980039: 3103
        //          -5406538: 4935
        //          default: 3136
        //        }
        //  3136: aload_0        
        //  3137: getfield        dev/nuker/pyro/f9A.c:Lnet/minecraft/client/Minecraft;
        //  3140: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  3143: fload           4
        //  3145: getstatic       dev/nuker/pyro/fc.1:I
        //  3148: ifne            3157
        //  3151: ldc_w           1730515668
        //  3154: goto            3160
        //  3157: ldc_w           985031926
        //  3160: ldc_w           -496814335
        //  3163: ixor           
        //  3164: lookupswitch {
        //          -2058967595: 3157
        //          -657107977: 3192
        //          default: 4939
        //        }
        //  3192: putfield        net/minecraft/client/entity/EntityPlayerSP.field_70125_A:F
        //  3195: getstatic       dev/nuker/pyro/fc.0:I
        //  3198: ifgt            3207
        //  3201: ldc_w           -504424021
        //  3204: goto            3210
        //  3207: ldc_w           122907352
        //  3210: ldc_w           141046697
        //  3213: ixor           
        //  3214: lookupswitch {
        //          -377017854: 4929
        //          -307366388: 3207
        //          default: 3240
        //        }
        //  3240: aload_0        
        //  3241: getfield        dev/nuker/pyro/f9A.c:Lnet/minecraft/client/Minecraft;
        //  3244: getstatic       dev/nuker/pyro/fc.c:I
        //  3247: ifne            3256
        //  3250: ldc_w           -297492792
        //  3253: goto            3259
        //  3256: ldc_w           -1846771031
        //  3259: ldc_w           -1704058076
        //  3262: ixor           
        //  3263: lookupswitch {
        //          -960287654: 3256
        //          1948958188: 4927
        //          default: 3288
        //        }
        //  3288: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  3291: getstatic       dev/nuker/pyro/fc.c:I
        //  3294: ifne            3303
        //  3297: ldc_w           -447912145
        //  3300: goto            3306
        //  3303: ldc_w           -965917510
        //  3306: ldc_w           489246740
        //  3309: ixor           
        //  3310: lookupswitch {
        //          -616295250: 3336
        //          -127649989: 3303
        //          default: 4975
        //        }
        //  3336: fload           5
        //  3338: getstatic       dev/nuker/pyro/fc.c:I
        //  3341: ifne            3350
        //  3344: ldc_w           1107825976
        //  3347: goto            3353
        //  3350: ldc_w           904378710
        //  3353: ldc_w           543356515
        //  3356: ixor           
        //  3357: lookupswitch {
        //          361058101: 3384
        //          1651172187: 3350
        //          default: 4905
        //        }
        //  3384: putfield        net/minecraft/client/entity/EntityPlayerSP.field_70177_z:F
        //  3387: aload_1        
        //  3388: new             Ldev/nuker/pyro/f9y;
        //  3391: dup            
        //  3392: aload_0        
        //  3393: aload_2        
        //  3394: aload_3        
        //  3395: aload           8
        //  3397: aload           9
        //  3399: aload           10
        //  3401: goto            3405
        //  3404: athrow         
        //  3405: invokespecial   dev/nuker/pyro/f9y.<init>:(Ldev/nuker/pyro/f9A;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlin/jvm/internal/Ref$BooleanRef;Lkotlin/jvm/internal/Ref$FloatRef;Lkotlin/jvm/internal/Ref$FloatRef;Lkotlin/jvm/internal/Ref$FloatRef;)V
        //  3408: goto            3412
        //  3411: athrow         
        //  3412: checkcast       Ljava/util/function/Consumer;
        //  3415: getstatic       dev/nuker/pyro/fc.c:I
        //  3418: ifne            3427
        //  3421: ldc_w           -870936153
        //  3424: goto            3430
        //  3427: ldc_w           -890651419
        //  3430: ldc_w           -2009604316
        //  3433: ixor           
        //  3434: lookupswitch {
        //          1121870785: 3460
        //          1143033475: 3427
        //          default: 4915
        //        }
        //  3460: goto            3464
        //  3463: athrow         
        //  3464: invokevirtual   dev/nuker/pyro/f4u.c:(Ljava/util/function/Consumer;)V
        //  3467: goto            3471
        //  3470: athrow         
        //  3471: goto            4509
        //  3474: aload_0        
        //  3475: getfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/f6n;
        //  3478: dup            
        //  3479: ifnonnull       3493
        //  3482: goto            3486
        //  3485: athrow         
        //  3486: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //  3489: goto            3493
        //  3492: athrow         
        //  3493: goto            3497
        //  3496: athrow         
        //  3497: invokevirtual   dev/nuker/pyro/f6n.func_177958_n:()I
        //  3500: goto            3504
        //  3503: athrow         
        //  3504: i2d            
        //  3505: dstore_2       
        //  3506: aload_0        
        //  3507: getstatic       dev/nuker/pyro/fc.1:I
        //  3510: ifne            3519
        //  3513: ldc_w           -783349175
        //  3516: goto            3522
        //  3519: ldc_w           19158057
        //  3522: ldc_w           1869673864
        //  3525: ixor           
        //  3526: lookupswitch {
        //          -1103102015: 4937
        //          1227727000: 3519
        //          default: 3552
        //        }
        //  3552: getfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/f6n;
        //  3555: dup            
        //  3556: ifnonnull       3570
        //  3559: goto            3563
        //  3562: athrow         
        //  3563: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //  3566: goto            3570
        //  3569: athrow         
        //  3570: goto            3574
        //  3573: athrow         
        //  3574: invokevirtual   dev/nuker/pyro/f6n.func_177956_o:()I
        //  3577: goto            3581
        //  3580: athrow         
        //  3581: i2d            
        //  3582: getstatic       dev/nuker/pyro/fc.1:I
        //  3585: ifne            3594
        //  3588: ldc_w           -2053198842
        //  3591: goto            3597
        //  3594: ldc_w           580108098
        //  3597: ldc_w           -2135596365
        //  3600: ixor           
        //  3601: lookupswitch {
        //          -1574511119: 3628
        //          86757045: 3594
        //          default: 4931
        //        }
        //  3628: dstore          4
        //  3630: getstatic       dev/nuker/pyro/fc.c:I
        //  3633: ifne            3642
        //  3636: ldc_w           -660725782
        //  3639: goto            3645
        //  3642: ldc_w           1255887161
        //  3645: ldc_w           -340119511
        //  3648: ixor           
        //  3649: lookupswitch {
        //          -1587453680: 3676
        //          858009539: 3642
        //          default: 4969
        //        }
        //  3676: aload_0        
        //  3677: getfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/f6n;
        //  3680: dup            
        //  3681: ifnonnull       3695
        //  3684: goto            3688
        //  3687: athrow         
        //  3688: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //  3691: goto            3695
        //  3694: athrow         
        //  3695: getstatic       dev/nuker/pyro/fc.0:I
        //  3698: ifgt            3707
        //  3701: ldc_w           -1223819584
        //  3704: goto            3710
        //  3707: ldc_w           1349839619
        //  3710: ldc_w           -1704358050
        //  3713: ixor           
        //  3714: lookupswitch {
        //          761557406: 4919
        //          1421499472: 3707
        //          default: 3740
        //        }
        //  3740: goto            3744
        //  3743: athrow         
        //  3744: invokevirtual   dev/nuker/pyro/f6n.func_177952_p:()I
        //  3747: goto            3751
        //  3750: athrow         
        //  3751: i2d            
        //  3752: getstatic       dev/nuker/pyro/fc.0:I
        //  3755: ifgt            3764
        //  3758: ldc_w           377838432
        //  3761: goto            3767
        //  3764: ldc_w           -1959070905
        //  3767: ldc_w           1766944143
        //  3770: ixor           
        //  3771: lookupswitch {
        //          -496263480: 3796
        //          2144614127: 3764
        //          default: 4951
        //        }
        //  3796: dstore          6
        //  3798: aload_0        
        //  3799: getstatic       dev/nuker/pyro/fc.c:I
        //  3802: ifne            3811
        //  3805: ldc_w           876256225
        //  3808: goto            3814
        //  3811: ldc_w           193503428
        //  3814: ldc_w           495088458
        //  3817: ixor           
        //  3818: lookupswitch {
        //          -1542863157: 3811
        //          699984043: 4971
        //          default: 3844
        //        }
        //  3844: getfield        dev/nuker/pyro/f9A.c:Lnet/minecraft/client/Minecraft;
        //  3847: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //  3850: aconst_null    
        //  3851: new             Lnet/minecraft/util/math/AxisAlignedBB;
        //  3854: dup            
        //  3855: dload_2        
        //  3856: dload           4
        //  3858: dload           6
        //  3860: getstatic       dev/nuker/pyro/fc.1:I
        //  3863: ifne            3872
        //  3866: ldc_w           755888458
        //  3869: goto            3875
        //  3872: ldc_w           -373698943
        //  3875: ldc_w           -1229669258
        //  3878: ixor           
        //  3879: lookupswitch {
        //          -1682354884: 3872
        //          1594716919: 3904
        //          default: 5041
        //        }
        //  3904: dload_2        
        //  3905: dconst_1       
        //  3906: dadd           
        //  3907: dload           4
        //  3909: ldc2_w          2.0
        //  3912: dadd           
        //  3913: dload           6
        //  3915: dconst_1       
        //  3916: dadd           
        //  3917: getstatic       dev/nuker/pyro/fc.0:I
        //  3920: ifgt            3929
        //  3923: ldc_w           -17200774
        //  3926: goto            3932
        //  3929: ldc_w           482277654
        //  3932: ldc_w           774372990
        //  3935: ixor           
        //  3936: lookupswitch {
        //          -790726908: 5031
        //          -404144940: 3929
        //          default: 3964
        //        }
        //  3964: goto            3968
        //  3967: athrow         
        //  3968: invokespecial   net/minecraft/util/math/AxisAlignedBB.<init>:(DDDDDD)V
        //  3971: goto            3975
        //  3974: athrow         
        //  3975: goto            3979
        //  3978: athrow         
        //  3979: invokevirtual   net/minecraft/client/multiplayer/WorldClient.func_72839_b:(Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/AxisAlignedBB;)Ljava/util/List;
        //  3982: goto            3986
        //  3985: athrow         
        //  3986: astore          8
        //  3988: aload           8
        //  3990: getstatic       dev/nuker/pyro/fc.1:I
        //  3993: ifne            4002
        //  3996: ldc_w           788181556
        //  3999: goto            4005
        //  4002: ldc_w           -124383667
        //  4005: ldc_w           1011747170
        //  4008: ixor           
        //  4009: lookupswitch {
        //          -992475345: 4036
        //          313834326: 4002
        //          default: 5023
        //        }
        //  4036: goto            4040
        //  4039: athrow         
        //  4040: invokeinterface java/util/List.iterator:()Ljava/util/Iterator;
        //  4045: goto            4049
        //  4048: athrow         
        //  4049: astore          10
        //  4051: aload           10
        //  4053: goto            4057
        //  4056: athrow         
        //  4057: invokeinterface java/util/Iterator.hasNext:()Z
        //  4062: goto            4066
        //  4065: athrow         
        //  4066: ifeq            4509
        //  4069: aload           10
        //  4071: goto            4075
        //  4074: athrow         
        //  4075: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //  4080: goto            4084
        //  4083: athrow         
        //  4084: checkcast       Lnet/minecraft/entity/Entity;
        //  4087: getstatic       dev/nuker/pyro/fc.0:I
        //  4090: ifgt            4099
        //  4093: ldc_w           -711777532
        //  4096: goto            4102
        //  4099: ldc_w           1730250370
        //  4102: ldc_w           -489549189
        //  4105: ixor           
        //  4106: lookupswitch {
        //          -2047634183: 4132
        //          927019391: 4099
        //          default: 4933
        //        }
        //  4132: astore          9
        //  4134: getstatic       dev/nuker/pyro/fc.1:I
        //  4137: ifne            4146
        //  4140: ldc_w           714175258
        //  4143: goto            4149
        //  4146: ldc_w           -815753764
        //  4149: ldc_w           -977379076
        //  4152: ixor           
        //  4153: lookupswitch {
        //          -282127386: 4146
        //          182383904: 4180
        //          default: 4977
        //        }
        //  4180: aload           9
        //  4182: instanceof      Lnet/minecraft/entity/item/EntityEnderCrystal;
        //  4185: ifeq            4506
        //  4188: aload           9
        //  4190: goto            4194
        //  4193: athrow         
        //  4194: invokestatic    dev/nuker/pyro/fdN.3:(Lnet/minecraft/entity/Entity;)Z
        //  4197: goto            4201
        //  4200: athrow         
        //  4201: ifeq            4506
        //  4204: goto            4208
        //  4207: athrow         
        //  4208: invokestatic    dev/nuker/pyro/few.c:()Ldev/nuker/pyro/few;
        //  4211: goto            4215
        //  4214: athrow         
        //  4215: aload           9
        //  4217: checkcast       Lnet/minecraft/entity/item/EntityEnderCrystal;
        //  4220: goto            4224
        //  4223: athrow         
        //  4224: invokevirtual   net/minecraft/entity/item/EntityEnderCrystal.func_174813_aQ:()Lnet/minecraft/util/math/AxisAlignedBB;
        //  4227: goto            4231
        //  4230: athrow         
        //  4231: iconst_0       
        //  4232: iconst_0       
        //  4233: iconst_0       
        //  4234: iconst_1       
        //  4235: goto            4239
        //  4238: athrow         
        //  4239: invokevirtual   dev/nuker/pyro/few.c:(Lnet/minecraft/util/math/AxisAlignedBB;ZZZZ)Ldev/nuker/pyro/fex;
        //  4242: goto            4246
        //  4245: athrow         
        //  4246: astore          11
        //  4248: aload_1        
        //  4249: getstatic       dev/nuker/pyro/fc.c:I
        //  4252: ifne            4261
        //  4255: ldc_w           130350470
        //  4258: goto            4264
        //  4261: ldc_w           -1103097281
        //  4264: ldc_w           -924613255
        //  4267: ixor           
        //  4268: lookupswitch {
        //          -1210371273: 4261
        //          -819496705: 4917
        //          default: 4296
        //        }
        //  4296: goto            4300
        //  4299: athrow         
        //  4300: invokevirtual   dev/nuker/pyro/f4u.0:()V
        //  4303: goto            4307
        //  4306: athrow         
        //  4307: aload_1        
        //  4308: aload           11
        //  4310: goto            4314
        //  4313: athrow         
        //  4314: invokevirtual   dev/nuker/pyro/fex.4:()Ldev/nuker/pyro/feu;
        //  4317: goto            4321
        //  4320: athrow         
        //  4321: goto            4325
        //  4324: athrow         
        //  4325: invokevirtual   dev/nuker/pyro/feu.2:()F
        //  4328: goto            4332
        //  4331: athrow         
        //  4332: goto            4336
        //  4335: athrow         
        //  4336: invokevirtual   dev/nuker/pyro/f4u.c:(F)V
        //  4339: goto            4343
        //  4342: athrow         
        //  4343: aload_1        
        //  4344: aload           11
        //  4346: goto            4350
        //  4349: athrow         
        //  4350: invokevirtual   dev/nuker/pyro/fex.4:()Ldev/nuker/pyro/feu;
        //  4353: goto            4357
        //  4356: athrow         
        //  4357: goto            4361
        //  4360: athrow         
        //  4361: invokevirtual   dev/nuker/pyro/feu.0:()F
        //  4364: goto            4368
        //  4367: athrow         
        //  4368: goto            4372
        //  4371: athrow         
        //  4372: invokevirtual   dev/nuker/pyro/f4u.0:(F)V
        //  4375: goto            4379
        //  4378: athrow         
        //  4379: aload_1        
        //  4380: new             Ldev/nuker/pyro/f9z;
        //  4383: dup            
        //  4384: getstatic       dev/nuker/pyro/fc.0:I
        //  4387: ifgt            4396
        //  4390: ldc_w           348189546
        //  4393: goto            4399
        //  4396: ldc_w           -1562866869
        //  4399: ldc_w           -169980266
        //  4402: ixor           
        //  4403: lookupswitch {
        //          -518078980: 4396
        //          1460061661: 4428
        //          default: 4985
        //        }
        //  4428: aload_0        
        //  4429: aload           9
        //  4431: goto            4435
        //  4434: athrow         
        //  4435: invokespecial   dev/nuker/pyro/f9z.<init>:(Ldev/nuker/pyro/f9A;Lnet/minecraft/entity/Entity;)V
        //  4438: goto            4442
        //  4441: athrow         
        //  4442: checkcast       Ljava/util/function/Consumer;
        //  4445: getstatic       dev/nuker/pyro/fc.c:I
        //  4448: ifne            4457
        //  4451: ldc_w           -333763060
        //  4454: goto            4460
        //  4457: ldc_w           1670999139
        //  4460: ldc_w           -2008459108
        //  4463: ixor           
        //  4464: lookupswitch {
        //          1180782997: 4457
        //          1683125904: 5017
        //          default: 4492
        //        }
        //  4492: goto            4496
        //  4495: athrow         
        //  4496: invokevirtual   dev/nuker/pyro/f4u.c:(Ljava/util/function/Consumer;)V
        //  4499: goto            4503
        //  4502: athrow         
        //  4503: goto            4509
        //  4506: goto            4051
        //  4509: getstatic       dev/nuker/pyro/f64.c:Ldev/nuker/pyro/f9Y;
        //  4512: getstatic       dev/nuker/pyro/fc.c:I
        //  4515: ifne            4524
        //  4518: ldc_w           -686999673
        //  4521: goto            4527
        //  4524: ldc_w           -1623686095
        //  4527: ldc_w           612030334
        //  4530: ixor           
        //  4531: lookupswitch {
        //          -689575771: 4524
        //          -210247431: 4981
        //          default: 4556
        //        }
        //  4556: getfield        dev/nuker/pyro/f9Y.c:Ldev/nuker/pyro/fw;
        //  4559: getstatic       dev/nuker/pyro/fc.c:I
        //  4562: ifne            4571
        //  4565: ldc_w           -1563112017
        //  4568: goto            4574
        //  4571: ldc_w           -377798531
        //  4574: ldc_w           -1688374741
        //  4577: ixor           
        //  4578: lookupswitch {
        //          965328772: 4571
        //          1915105878: 4604
        //          default: 4943
        //        }
        //  4604: goto            4608
        //  4607: athrow         
        //  4608: invokevirtual   dev/nuker/pyro/fw.0:()Ljava/lang/Object;
        //  4611: goto            4615
        //  4614: athrow         
        //  4615: dup            
        //  4616: pop            
        //  4617: checkcast       Ljava/lang/Boolean;
        //  4620: goto            4624
        //  4623: athrow         
        //  4624: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //  4627: goto            4631
        //  4630: athrow         
        //  4631: ifeq            4644
        //  4634: getstatic       dev/nuker/pyro/f64.c:Ldev/nuker/pyro/f9Y;
        //  4637: getfield        dev/nuker/pyro/f9Y.1:I
        //  4640: ifle            4644
        //  4643: return         
        //  4644: getstatic       dev/nuker/pyro/f64.c:Ldev/nuker/pyro/f68;
        //  4647: getfield        dev/nuker/pyro/f68.c:Ldev/nuker/pyro/fw;
        //  4650: goto            4654
        //  4653: athrow         
        //  4654: invokevirtual   dev/nuker/pyro/fw.0:()Ljava/lang/Object;
        //  4657: goto            4661
        //  4660: athrow         
        //  4661: dup            
        //  4662: pop            
        //  4663: checkcast       Ljava/lang/Boolean;
        //  4666: goto            4670
        //  4669: athrow         
        //  4670: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //  4673: goto            4677
        //  4676: athrow         
        //  4677: ifeq            4698
        //  4680: getstatic       dev/nuker/pyro/f64.c:Ldev/nuker/pyro/f68;
        //  4683: goto            4687
        //  4686: athrow         
        //  4687: invokevirtual   dev/nuker/pyro/f68.1:()Z
        //  4690: goto            4694
        //  4693: athrow         
        //  4694: ifeq            4698
        //  4697: return         
        //  4698: aload_0        
        //  4699: getfield        dev/nuker/pyro/f9A.c:Lnet/minecraft/client/Minecraft;
        //  4702: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  4705: dup            
        //  4706: pop            
        //  4707: getstatic       dev/nuker/pyro/fc.1:I
        //  4710: ifne            4719
        //  4713: ldc_w           1068421417
        //  4716: goto            4722
        //  4719: ldc_w           -1192115045
        //  4722: ldc_w           -1056199085
        //  4725: ixor           
        //  4726: lookupswitch {
        //          -1453976794: 4719
        //          -22708358: 4921
        //          default: 4752
        //        }
        //  4752: goto            4756
        //  4755: athrow         
        //  4756: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_184613_cA:()Z
        //  4759: goto            4763
        //  4762: athrow         
        //  4763: ifne            4904
        //  4766: aload_0        
        //  4767: getfield        dev/nuker/pyro/f9A.c:Lnet/minecraft/client/Minecraft;
        //  4770: getstatic       dev/nuker/pyro/fc.1:I
        //  4773: ifne            4782
        //  4776: ldc_w           -1887951089
        //  4779: goto            4785
        //  4782: ldc_w           1361097375
        //  4785: ldc_w           -1971975186
        //  4788: ixor           
        //  4789: lookupswitch {
        //          -287541464: 4782
        //          84815073: 5003
        //          default: 4816
        //        }
        //  4816: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  4819: getstatic       dev/nuker/pyro/fc.0:I
        //  4822: ifgt            4831
        //  4825: ldc_w           127309985
        //  4828: goto            4834
        //  4831: ldc_w           -524661736
        //  4834: ldc_w           287896515
        //  4837: ixor           
        //  4838: lookupswitch {
        //          -287555436: 4831
        //          381578082: 5019
        //          default: 4864
        //        }
        //  4864: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71075_bZ:Lnet/minecraft/entity/player/PlayerCapabilities;
        //  4867: getfield        net/minecraft/entity/player/PlayerCapabilities.field_75100_b:Z
        //  4870: ifne            4904
        //  4873: aload_0        
        //  4874: getfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/far;
        //  4877: dup            
        //  4878: ifnonnull       4892
        //  4881: goto            4885
        //  4884: athrow         
        //  4885: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //  4888: goto            4892
        //  4891: athrow         
        //  4892: aload_1        
        //  4893: goto            4897
        //  4896: athrow         
        //  4897: invokevirtual   dev/nuker/pyro/far.c:(Ldev/nuker/pyro/f4u;)V
        //  4900: goto            4904
        //  4903: athrow         
        //  4904: return         
        //  4905: aconst_null    
        //  4906: athrow         
        //  4907: aconst_null    
        //  4908: athrow         
        //  4909: aconst_null    
        //  4910: athrow         
        //  4911: aconst_null    
        //  4912: athrow         
        //  4913: aconst_null    
        //  4914: athrow         
        //  4915: aconst_null    
        //  4916: athrow         
        //  4917: aconst_null    
        //  4918: athrow         
        //  4919: aconst_null    
        //  4920: athrow         
        //  4921: aconst_null    
        //  4922: athrow         
        //  4923: aconst_null    
        //  4924: athrow         
        //  4925: aconst_null    
        //  4926: athrow         
        //  4927: aconst_null    
        //  4928: athrow         
        //  4929: aconst_null    
        //  4930: athrow         
        //  4931: aconst_null    
        //  4932: athrow         
        //  4933: aconst_null    
        //  4934: athrow         
        //  4935: aconst_null    
        //  4936: athrow         
        //  4937: aconst_null    
        //  4938: athrow         
        //  4939: aconst_null    
        //  4940: athrow         
        //  4941: aconst_null    
        //  4942: athrow         
        //  4943: aconst_null    
        //  4944: athrow         
        //  4945: aconst_null    
        //  4946: athrow         
        //  4947: aconst_null    
        //  4948: athrow         
        //  4949: aconst_null    
        //  4950: athrow         
        //  4951: aconst_null    
        //  4952: athrow         
        //  4953: aconst_null    
        //  4954: athrow         
        //  4955: aconst_null    
        //  4956: athrow         
        //  4957: aconst_null    
        //  4958: athrow         
        //  4959: aconst_null    
        //  4960: athrow         
        //  4961: aconst_null    
        //  4962: athrow         
        //  4963: aconst_null    
        //  4964: athrow         
        //  4965: aconst_null    
        //  4966: athrow         
        //  4967: aconst_null    
        //  4968: athrow         
        //  4969: aconst_null    
        //  4970: athrow         
        //  4971: aconst_null    
        //  4972: athrow         
        //  4973: aconst_null    
        //  4974: athrow         
        //  4975: aconst_null    
        //  4976: athrow         
        //  4977: aconst_null    
        //  4978: athrow         
        //  4979: aconst_null    
        //  4980: athrow         
        //  4981: aconst_null    
        //  4982: athrow         
        //  4983: aconst_null    
        //  4984: athrow         
        //  4985: aconst_null    
        //  4986: athrow         
        //  4987: aconst_null    
        //  4988: athrow         
        //  4989: aconst_null    
        //  4990: athrow         
        //  4991: aconst_null    
        //  4992: athrow         
        //  4993: aconst_null    
        //  4994: athrow         
        //  4995: aconst_null    
        //  4996: athrow         
        //  4997: aconst_null    
        //  4998: athrow         
        //  4999: aconst_null    
        //  5000: athrow         
        //  5001: aconst_null    
        //  5002: athrow         
        //  5003: aconst_null    
        //  5004: athrow         
        //  5005: aconst_null    
        //  5006: athrow         
        //  5007: aconst_null    
        //  5008: athrow         
        //  5009: aconst_null    
        //  5010: athrow         
        //  5011: aconst_null    
        //  5012: athrow         
        //  5013: aconst_null    
        //  5014: athrow         
        //  5015: aconst_null    
        //  5016: athrow         
        //  5017: aconst_null    
        //  5018: athrow         
        //  5019: aconst_null    
        //  5020: athrow         
        //  5021: aconst_null    
        //  5022: athrow         
        //  5023: aconst_null    
        //  5024: athrow         
        //  5025: aconst_null    
        //  5026: athrow         
        //  5027: aconst_null    
        //  5028: athrow         
        //  5029: aconst_null    
        //  5030: athrow         
        //  5031: aconst_null    
        //  5032: athrow         
        //  5033: aconst_null    
        //  5034: athrow         
        //  5035: aconst_null    
        //  5036: athrow         
        //  5037: aconst_null    
        //  5038: athrow         
        //  5039: aconst_null    
        //  5040: athrow         
        //  5041: aconst_null    
        //  5042: athrow         
        //  5043: aconst_null    
        //  5044: athrow         
        //  5045: aconst_null    
        //  5046: athrow         
        //  5047: pop            
        //  5048: goto            24
        //  5051: pop            
        //  5052: aconst_null    
        //  5053: goto            5047
        //  5056: dup            
        //  5057: ifnull          5047
        //  5060: checkcast       Ljava/lang/Throwable;
        //  5063: athrow         
        //  5064: dup            
        //  5065: ifnull          5051
        //  5068: checkcast       Ljava/lang/Throwable;
        //  5071: athrow         
        //  5072: aconst_null    
        //  5073: athrow         
        //    StackMapTable: 02 9A 43 07 00 49 04 FF 00 0B 00 00 00 01 07 00 49 FD 00 03 07 00 03 07 00 50 4D 07 00 50 FF 00 01 00 02 07 00 03 07 00 50 00 02 07 00 50 01 5B 07 00 50 42 07 00 2C 40 07 00 50 45 07 00 49 40 01 4E 07 00 50 FF 00 01 00 02 07 00 03 07 00 50 00 02 07 00 50 01 5B 07 00 50 42 07 00 49 40 07 00 50 45 07 00 49 40 07 00 5D 4C 07 00 28 40 07 00 64 45 07 00 49 40 07 02 56 45 07 00 49 40 07 00 69 45 07 00 49 40 01 02 04 41 01 17 06 04 41 01 19 4A 07 00 49 40 07 00 03 45 07 00 49 40 01 03 46 07 00 49 FF 00 00 00 02 07 00 03 07 00 50 00 02 08 01 0B 08 01 0B 45 07 00 49 40 07 00 79 FC 00 0B 07 00 79 41 01 1B FF 00 0F 00 03 07 00 03 07 00 50 07 00 79 00 02 07 00 79 07 00 82 FF 00 01 00 03 07 00 03 07 00 50 07 00 79 00 03 07 00 79 07 00 82 01 FF 00 1D 00 03 07 00 03 07 00 50 07 00 79 00 02 07 00 79 07 00 82 49 07 00 49 FF 00 00 00 03 07 00 03 07 00 50 07 00 79 00 02 08 01 77 08 01 77 45 07 00 49 40 07 00 8B 4A 07 00 8B FF 00 01 00 03 07 00 03 07 00 50 07 00 79 00 02 07 00 8B 01 5C 07 00 8B FF 00 0C 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 01 07 00 8B FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 8B 01 5C 07 00 8B 4B 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 8B 07 00 9D 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 8B 07 00 A3 44 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 8B 07 00 A3 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 8B 07 02 58 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 03 07 00 8B 07 02 58 07 02 58 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 8B 01 4D 07 00 28 40 07 00 BD 45 07 00 49 40 07 00 BD 4A 07 00 BD FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 BD 01 5D 07 00 BD FF 00 02 00 00 00 01 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 01 07 00 BD 45 07 00 49 40 07 00 CD 46 07 00 49 40 07 00 50 45 07 00 49 00 FF 00 13 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 BD FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 03 07 00 50 07 00 BD 01 FF 00 1B 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 BD 42 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 BD 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 BD 42 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 BD 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 CD FF 00 03 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 CD FF 00 04 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 CD FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 03 07 00 50 07 00 CD 01 FF 00 1A 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 CD FF 00 02 00 00 00 01 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 CD 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 CD FF 00 0A 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 CD FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 03 07 00 50 07 00 CD 01 FF 00 1B 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 CD 42 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 CD 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 D2 42 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 D2 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 D8 42 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 D8 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 02 42 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 02 45 07 00 49 00 FF 00 0C 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 03 FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 03 07 00 50 07 00 03 01 FF 00 1C 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 03 FF 00 06 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 BD FF 00 04 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 BD FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 03 07 00 50 07 00 BD 01 FF 00 19 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 BD 42 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 BD 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 BD 42 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 BD 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 CD FF 00 0E 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 CD FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 03 07 00 50 07 00 CD 01 FF 00 1C 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 CD FF 00 02 00 00 00 01 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 CD 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 CD FF 00 0A 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 CD FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 03 07 00 50 07 00 CD 01 FF 00 1B 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 CD 42 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 CD 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 D2 42 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 D2 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 D8 42 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 D8 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 02 FF 00 0A 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 02 FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 03 07 00 50 02 01 FF 00 1D 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 02 42 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 02 45 07 00 49 00 4B 07 00 79 FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 79 01 5E 07 00 79 4A 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 79 07 00 BD 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 79 07 00 BD FF 00 02 00 00 00 01 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 79 07 00 BD 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 79 07 00 CD 46 07 00 2C FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 79 07 00 CD 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 79 07 00 CD FF 00 0A 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 79 07 00 CD FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 03 07 00 79 07 00 CD 01 FF 00 1D 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 79 07 00 CD FF 00 02 00 00 00 01 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 79 07 00 CD 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 79 07 00 82 05 4B 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 79 07 00 BD 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 79 07 00 BD 46 07 00 2A FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 03 07 00 79 07 00 FD 01 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 79 07 00 82 FF 00 0B 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 79 07 00 82 FF 00 02 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 03 07 00 79 07 00 82 01 FF 00 1C 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 79 07 00 82 45 07 00 28 00 45 07 00 49 40 07 00 FF 4B 07 00 FF FF 00 02 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 FF 01 5E 07 00 FF FF 00 13 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 FF 07 00 BD FF 00 02 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 03 07 00 FF 07 00 BD 01 FF 00 1C 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 FF 07 00 BD 42 07 00 40 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 FF 07 00 BD 45 07 00 49 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 FF 07 00 BD 4C 07 00 28 FF 00 00 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 03 07 00 FF 07 00 FD 07 00 82 45 07 00 49 40 07 02 5A FF 00 05 00 00 00 01 07 00 49 FF 00 00 00 05 07 00 03 07 00 50 07 00 79 07 00 8B 07 02 5A 00 01 07 00 50 45 07 00 49 00 4C 07 00 50 FF 00 02 00 05 07 00 03 07 00 50 07 00 79 07 00 8B 07 02 5A 00 02 07 00 50 01 5D 07 00 50 46 07 00 49 FF 00 00 00 05 07 00 03 07 00 50 07 00 79 07 00 8B 07 02 5A 00 02 07 00 50 02 45 07 00 49 00 4C 07 00 50 FF 00 02 00 05 07 00 03 07 00 50 07 00 79 07 00 8B 07 02 5A 00 02 07 00 50 01 5C 07 00 50 FF 00 0F 00 05 07 00 03 07 00 50 07 00 79 07 00 8B 07 02 5A 00 02 07 00 50 02 FF 00 02 00 05 07 00 03 07 00 50 07 00 79 07 00 8B 07 02 5A 00 03 07 00 50 02 01 FF 00 1C 00 05 07 00 03 07 00 50 07 00 79 07 00 8B 07 02 5A 00 02 07 00 50 02 FF 00 02 00 00 00 01 07 00 49 FF 00 00 00 05 07 00 03 07 00 50 07 00 79 07 00 8B 07 02 5A 00 02 07 00 50 02 45 07 00 49 FA 00 00 4C 07 00 03 FF 00 02 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 03 01 5C 07 00 03 4E 07 00 97 FF 00 02 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 97 01 5D 07 00 97 51 02 FF 00 02 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 02 01 5E 02 FF 00 16 00 06 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 00 01 07 00 49 40 07 00 97 45 07 00 49 40 02 4B 02 FF 00 02 00 06 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 00 02 02 01 5D 02 FF 00 0E 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 01 07 00 03 FF 00 02 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 02 07 00 03 01 5D 07 00 03 FF 00 12 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 02 07 00 9D 07 00 50 FF 00 02 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 03 07 00 9D 07 00 50 01 FF 00 1D 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 02 07 00 9D 07 00 50 FF 00 02 00 00 00 01 07 00 49 FF 00 00 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 02 07 00 9D 07 00 50 45 07 00 49 FF 00 00 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 02 07 00 9D 02 4F 07 00 03 FF 00 02 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 02 07 00 03 01 5D 07 00 03 49 07 00 49 FF 00 00 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 02 07 00 9D 07 00 50 45 07 00 49 FF 00 00 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 02 07 00 9D 02 FF 00 0B 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 02 07 00 9D 02 FF 00 02 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 03 07 00 9D 02 01 FF 00 1E 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 02 07 00 9D 02 52 07 00 97 FF 00 02 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 02 07 00 97 01 5D 07 00 97 4E 07 00 9D FF 00 02 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 02 07 00 9D 01 5D 07 00 9D FF 00 0B 00 00 00 01 07 00 49 FF 00 00 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 02 07 00 9D 07 01 4C 45 07 00 49 FF 00 00 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 02 07 00 9D 02 FF 00 0C 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 02 07 00 9D 03 FF 00 02 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 03 07 00 9D 03 01 FF 00 1F 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 02 07 00 9D 03 44 07 00 42 FF 00 00 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 03 07 00 9D 03 02 45 07 00 49 40 07 01 6F FF 00 11 00 08 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 00 02 08 08 F3 08 08 F3 FF 00 02 00 08 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 00 03 08 08 F3 08 08 F3 01 FF 00 1D 00 08 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 00 02 08 08 F3 08 08 F3 42 07 00 34 FF 00 00 00 08 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 00 02 08 08 F3 08 08 F3 45 07 00 49 40 07 01 58 FF 00 10 00 09 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 00 02 07 01 58 02 FF 00 02 00 09 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 00 03 07 01 58 02 01 FF 00 1C 00 09 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 00 02 07 01 58 02 FF 00 12 00 09 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 00 02 08 09 63 08 09 63 FF 00 02 00 09 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 00 03 08 09 63 08 09 63 01 FF 00 1D 00 09 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 00 02 08 09 63 08 09 63 42 07 00 49 FF 00 00 00 09 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 00 02 08 09 63 08 09 63 45 07 00 49 40 07 01 58 4B 07 01 58 FF 00 02 00 09 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 00 02 07 01 58 01 5D 07 01 58 FC 00 0D 07 01 58 42 01 1E 4C 07 00 49 FF 00 00 00 0A 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 00 02 08 0A 02 08 0A 02 45 07 00 49 40 07 01 58 FF 00 10 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 01 58 02 FF 00 02 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 02 01 FF 00 1E 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 01 58 02 FF 00 1A 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 01 58 07 01 78 FF 00 02 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 07 01 78 01 FF 00 1D 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 01 58 07 01 78 FF 00 16 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 03 07 00 BD FF 00 02 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 04 07 01 58 03 07 00 BD 01 FF 00 1D 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 03 07 00 BD 42 07 00 28 FF 00 00 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 03 07 00 BD 45 07 00 49 FF 00 00 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 03 07 00 BD FF 00 02 00 00 00 01 07 00 49 FF 00 00 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 03 07 00 BD 45 07 00 49 FF 00 00 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 03 01 53 07 01 58 FF 00 02 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 01 58 01 5E 07 01 58 52 07 00 49 FF 00 00 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 03 07 00 BD 45 07 00 49 FF 00 00 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 03 07 00 BD 42 07 00 3E FF 00 00 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 03 07 00 BD 45 07 00 49 FF 00 00 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 03 01 11 42 01 1C FF 00 0F 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 01 58 07 01 6F FF 00 02 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 07 01 6F 01 FF 00 1C 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 01 58 07 01 6F FF 00 19 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 03 07 00 BD FF 00 02 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 04 07 01 58 03 07 00 BD 01 FF 00 1E 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 03 07 00 BD 42 07 00 42 FF 00 00 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 03 07 00 BD 45 07 00 49 FF 00 00 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 03 07 00 BD 42 07 00 49 FF 00 00 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 03 07 00 BD 45 07 00 49 FF 00 00 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 03 01 FF 00 0E 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 01 58 02 FF 00 02 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 02 01 FF 00 1F 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 01 58 02 02 0B 42 01 1D FF 00 14 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 00 9D 02 FF 00 02 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 00 9D 02 01 FF 00 1F 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 00 9D 02 0E 42 01 1D 4F 07 00 97 FF 00 02 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 00 97 01 5C 07 00 97 4E 07 00 9D FF 00 02 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 00 9D 01 5D 07 00 9D FF 00 0D 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 00 9D 02 FF 00 02 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 00 9D 02 01 FF 00 1E 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 00 9D 02 53 07 00 30 FF 00 00 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 09 07 00 50 08 0D 3C 08 0D 3C 07 00 03 07 00 79 07 00 8B 07 01 58 07 01 58 07 01 58 45 07 00 49 FF 00 00 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 00 50 07 01 B2 FF 00 0E 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 00 50 07 01 B7 FF 00 02 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 00 50 07 01 B7 01 FF 00 1D 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 00 50 07 01 B7 42 07 00 49 FF 00 00 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 00 50 07 01 B7 45 07 00 49 00 FF 00 02 00 02 07 00 03 07 00 50 00 00 4A 07 00 28 40 07 00 BD 45 07 00 49 40 07 00 BD 42 07 00 49 40 07 00 BD 45 07 00 49 40 01 FF 00 0E 00 03 07 00 03 07 00 50 03 00 01 07 00 03 FF 00 02 00 03 07 00 03 07 00 50 03 00 02 07 00 03 01 5D 07 00 03 49 07 00 49 40 07 00 BD 45 07 00 49 40 07 00 BD 42 07 00 49 40 07 00 BD 45 07 00 49 40 01 4C 03 FF 00 02 00 03 07 00 03 07 00 50 03 00 02 03 01 5E 03 FC 00 0D 03 42 01 1E 4A 07 00 32 40 07 00 BD 45 07 00 49 40 07 00 BD 4B 07 00 BD FF 00 02 00 04 07 00 03 07 00 50 03 03 00 02 07 00 BD 01 5D 07 00 BD 42 07 00 49 40 07 00 BD 45 07 00 49 40 01 4C 03 FF 00 02 00 04 07 00 03 07 00 50 03 03 00 02 03 01 5C 03 FF 00 0E 00 05 07 00 03 07 00 50 03 03 03 00 01 07 00 03 FF 00 02 00 05 07 00 03 07 00 50 03 03 03 00 02 07 00 03 01 5D 07 00 03 FF 00 1B 00 05 07 00 03 07 00 50 03 03 03 00 07 07 01 E2 05 08 0F 0B 08 0F 0B 03 03 03 FF 00 02 00 05 07 00 03 07 00 50 03 03 03 00 08 07 01 E2 05 08 0F 0B 08 0F 0B 03 03 03 01 FF 00 1C 00 05 07 00 03 07 00 50 03 03 03 00 07 07 01 E2 05 08 0F 0B 08 0F 0B 03 03 03 FF 00 18 00 05 07 00 03 07 00 50 03 03 03 00 0A 07 01 E2 05 08 0F 0B 08 0F 0B 03 03 03 03 03 03 FF 00 02 00 05 07 00 03 07 00 50 03 03 03 00 0B 07 01 E2 05 08 0F 0B 08 0F 0B 03 03 03 03 03 03 01 FF 00 1F 00 05 07 00 03 07 00 50 03 03 03 00 0A 07 01 E2 05 08 0F 0B 08 0F 0B 03 03 03 03 03 03 42 07 00 49 FF 00 00 00 05 07 00 03 07 00 50 03 03 03 00 0A 07 01 E2 05 08 0F 0B 08 0F 0B 03 03 03 03 03 03 45 07 00 49 FF 00 00 00 05 07 00 03 07 00 50 03 03 03 00 03 07 01 E2 05 07 01 D5 42 07 00 49 FF 00 00 00 05 07 00 03 07 00 50 03 03 03 00 03 07 01 E2 05 07 01 D5 45 07 00 49 40 07 01 EB FF 00 0F 00 06 07 00 03 07 00 50 03 03 03 07 01 EB 00 01 07 01 EB FF 00 02 00 06 07 00 03 07 00 50 03 03 03 07 01 EB 00 02 07 01 EB 01 5E 07 01 EB FF 00 02 00 00 00 01 07 00 49 FF 00 00 00 06 07 00 03 07 00 50 03 03 03 07 01 EB 00 01 07 01 EB 47 07 00 49 40 07 01 F1 FD 00 01 00 07 01 F1 44 07 00 36 40 07 01 F1 47 07 00 49 40 01 47 07 00 49 40 07 01 F1 47 07 00 49 40 07 02 56 4E 07 01 F9 FF 00 02 00 08 07 00 03 07 00 50 03 03 03 07 01 EB 00 07 01 F1 00 02 07 01 F9 01 5D 07 01 F9 FF 00 0D 00 08 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 00 00 42 01 1E 4C 07 00 49 40 07 01 F9 45 07 00 49 40 01 45 07 00 2C 00 45 07 00 49 40 07 00 FF 47 07 00 28 FF 00 00 00 08 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 00 02 07 00 FF 07 02 01 45 07 00 49 FF 00 00 00 08 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 00 02 07 00 FF 07 01 D5 46 07 00 49 FF 00 00 00 08 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 00 06 07 00 FF 07 01 D5 01 01 01 01 45 07 00 49 40 07 00 D2 FF 00 0E 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 01 07 00 50 FF 00 02 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 02 07 00 50 01 5F 07 00 50 42 07 00 49 40 07 00 50 45 07 00 49 00 FF 00 05 00 00 00 01 07 00 49 FF 00 00 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 02 07 00 50 07 00 D2 45 07 00 49 FF 00 00 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 02 07 00 50 07 00 D8 42 07 00 49 FF 00 00 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 02 07 00 50 07 00 D8 45 07 00 49 FF 00 00 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 02 07 00 50 02 42 07 00 49 FF 00 00 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 02 07 00 50 02 45 07 00 49 00 45 07 00 49 FF 00 00 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 02 07 00 50 07 00 D2 45 07 00 49 FF 00 00 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 02 07 00 50 07 00 D8 42 07 00 28 FF 00 00 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 02 07 00 50 07 00 D8 45 07 00 49 FF 00 00 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 02 07 00 50 02 42 07 00 38 FF 00 00 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 02 07 00 50 02 45 07 00 49 00 FF 00 10 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 03 07 00 50 08 11 1C 08 11 1C FF 00 02 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 04 07 00 50 08 11 1C 08 11 1C 01 FF 00 1C 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 03 07 00 50 08 11 1C 08 11 1C 45 07 00 49 FF 00 00 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 05 07 00 50 08 11 1C 08 11 1C 07 00 03 07 01 F9 45 07 00 49 FF 00 00 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 02 07 00 50 07 02 13 FF 00 0E 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 02 07 00 50 07 01 B7 FF 00 02 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 03 07 00 50 07 01 B7 01 FF 00 1F 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 02 07 00 50 07 01 B7 42 07 00 49 FF 00 00 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 02 07 00 50 07 01 B7 45 07 00 49 00 FA 00 02 FF 00 02 00 02 07 00 03 07 00 50 00 00 4E 07 02 26 FF 00 02 00 02 07 00 03 07 00 50 00 02 07 02 26 01 5C 07 02 26 4E 07 02 2E FF 00 02 00 02 07 00 03 07 00 50 00 02 07 02 2E 01 5D 07 02 2E 42 07 00 26 40 07 02 2E 45 07 00 49 40 07 02 56 47 07 00 49 40 07 00 69 45 07 00 49 40 01 0C 48 07 00 49 40 07 02 2E 45 07 00 49 40 07 02 56 47 07 00 49 40 07 00 69 45 07 00 49 40 01 48 07 00 49 40 07 02 36 45 07 00 49 40 01 03 54 07 00 9D FF 00 02 00 02 07 00 03 07 00 50 00 02 07 00 9D 01 5D 07 00 9D 42 07 00 49 40 07 00 9D 45 07 00 49 40 01 52 07 00 97 FF 00 02 00 02 07 00 03 07 00 50 00 02 07 00 97 01 5E 07 00 97 4E 07 00 9D FF 00 02 00 02 07 00 03 07 00 50 00 02 07 00 9D 01 5D 07 00 9D FF 00 13 00 00 00 01 07 00 49 FF 00 00 00 02 07 00 03 07 00 50 00 01 07 02 52 45 07 00 49 40 07 02 52 43 07 00 42 FF 00 00 00 02 07 00 03 07 00 50 00 02 07 02 52 07 00 50 45 07 00 49 00 FF 00 00 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 00 9D 02 FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 01 07 00 97 FF 00 01 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 01 58 07 01 78 FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 BD 41 07 00 FF FF 00 01 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 00 50 07 01 B7 FF 00 01 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 01 07 00 50 FF 00 01 00 04 07 00 03 07 00 50 03 03 00 01 07 00 BD FF 00 01 00 02 07 00 03 07 00 50 00 01 07 00 9D FF 00 01 00 03 07 00 03 07 00 50 07 00 79 00 02 07 00 79 07 00 82 FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 01 02 FF 00 01 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 01 07 00 97 01 FF 00 01 00 03 07 00 03 07 00 50 03 00 01 03 FF 00 01 00 08 07 00 03 07 00 50 03 03 03 07 01 EB 00 07 01 F1 00 01 07 01 F9 FF 00 01 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 00 FF 00 01 00 03 07 00 03 07 00 50 03 00 01 07 00 03 FF 00 01 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 00 9D 02 FF 00 01 00 09 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 00 01 07 01 58 FF 00 01 00 02 07 00 03 07 00 50 00 01 07 02 2E FF 00 01 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 01 58 07 01 6F FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 CD FF 00 01 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 00 FF 00 01 00 04 07 00 03 07 00 50 03 03 00 01 03 FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 FF 07 00 BD FF 00 01 00 05 07 00 03 07 00 50 07 00 79 07 00 8B 07 02 5A 00 02 07 00 50 02 FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 79 07 00 82 FF 00 01 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 01 07 01 58 FF 00 01 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 03 07 00 BD FF 00 01 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 02 07 00 9D 07 00 50 FF 00 01 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 01 58 02 FF 00 01 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 02 07 00 9D 02 FF 00 01 00 04 07 00 03 07 00 50 03 03 00 00 FF 00 01 00 05 07 00 03 07 00 50 03 03 03 00 01 07 00 03 FF 00 01 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 01 07 00 03 FF 00 01 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 01 07 00 9D FF 00 01 00 08 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 00 00 FF 00 01 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 01 07 00 03 FF 00 01 00 02 07 00 03 07 00 50 00 01 07 02 26 FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 79 07 00 CD FF 00 01 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 03 07 00 50 08 11 1C 08 11 1C FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 01 07 00 79 FF 00 01 00 02 07 00 03 07 00 50 00 01 07 00 50 FF 00 01 00 0A 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 00 00 FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 02 FF 00 01 00 09 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 00 02 07 01 58 02 FF 00 01 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 01 07 00 9D FF 00 01 00 08 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 00 02 08 08 F3 08 08 F3 FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 01 07 00 8B FF 00 01 00 02 07 00 03 07 00 50 00 01 07 00 97 FF 00 01 00 06 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 00 01 02 FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 03 FF 00 01 00 05 07 00 03 07 00 50 07 00 79 07 00 8B 07 02 5A 00 01 07 00 50 FF 00 01 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 03 07 01 58 03 07 00 BD FF 00 01 00 02 07 00 03 07 00 50 00 01 07 00 50 FF 00 01 00 09 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 00 02 08 09 63 08 09 63 FF 00 01 00 09 07 00 03 07 00 50 03 03 03 07 01 EB 07 01 F9 07 01 F1 07 00 D2 00 02 07 00 50 07 01 B7 FF 00 01 00 02 07 00 03 07 00 50 00 01 07 00 9D FF 00 01 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 02 07 00 9D 03 FF 00 01 00 06 07 00 03 07 00 50 03 03 03 07 01 EB 00 01 07 01 EB FF 00 01 00 07 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 00 01 07 00 97 FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 CD FF 00 01 00 05 07 00 03 07 00 50 07 00 79 07 00 8B 07 02 5A 00 01 07 00 50 FF 00 01 00 05 07 00 03 07 00 50 03 03 03 00 0A 07 01 E2 05 08 0F 0B 08 0F 0B 03 03 03 03 03 03 FF 00 01 00 03 07 00 03 07 00 50 07 00 79 00 01 07 00 8B FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 01 07 00 BD FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 02 07 00 50 07 00 CD FF 00 01 00 0B 07 00 03 07 00 50 07 00 79 07 00 8B 02 02 02 07 01 6F 07 01 58 07 01 58 07 01 58 00 02 07 01 58 02 FF 00 01 00 05 07 00 03 07 00 50 03 03 03 00 07 07 01 E2 05 08 0F 0B 08 0F 0B 03 03 03 FF 00 01 00 03 07 00 03 07 00 50 07 00 79 00 00 FF 00 01 00 04 07 00 03 07 00 50 07 00 79 07 00 8B 00 01 07 00 03 FF 00 01 00 02 07 00 03 07 00 50 00 01 07 00 28 43 05 44 07 00 28 47 05 47 07 00 49
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     5056   5064   Ljava/lang/StringIndexOutOfBoundsException;
        //  5056   5064   5056   5064   Ljava/lang/IllegalArgumentException;
        //  5072   5074   3      8      Ljava/lang/RuntimeException;
        //  71     78     78     79     Any
        //  71     78     78     79     Ljava/util/NoSuchElementException;
        //  72     78     71     72     Ljava/lang/AssertionError;
        //  72     78     3      8      Ljava/lang/NegativeArraySizeException;
        //  71     78     3      8      Ljava/lang/ClassCastException;
        //  127    134    134    135    Any
        //  128    134    3      8      Ljava/lang/NullPointerException;
        //  128    134    134    135    Ljava/lang/IllegalStateException;
        //  128    134    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  127    134    127    128    Any
        //  148    155    155    156    Any
        //  148    155    148    149    Ljava/lang/IllegalArgumentException;
        //  148    155    3      8      Ljava/lang/IllegalArgumentException;
        //  148    155    155    156    Ljava/lang/NumberFormatException;
        //  148    155    148    149    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  162    169    169    170    Any
        //  163    169    169    170    Any
        //  162    169    162    163    Any
        //  162    169    162    163    Any
        //  162    169    3      8      Ljava/lang/UnsupportedOperationException;
        //  255    262    262    263    Any
        //  256    262    3      8      Ljava/lang/IllegalArgumentException;
        //  256    262    255    256    Ljava/lang/ArithmeticException;
        //  255    262    3      8      Any
        //  255    262    255    256    Any
        //  274    281    281    282    Any
        //  275    281    274    275    Any
        //  274    281    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  274    281    274    275    Ljava/lang/NullPointerException;
        //  274    281    3      8      Ljava/lang/NegativeArraySizeException;
        //  382    389    389    390    Any
        //  383    389    382    383    Any
        //  383    389    389    390    Ljava/lang/RuntimeException;
        //  382    389    3      8      Any
        //  383    389    389    390    Ljava/lang/ArithmeticException;
        //  488    495    495    496    Any
        //  489    495    495    496    Ljava/lang/NumberFormatException;
        //  489    495    488    489    Any
        //  489    495    495    496    Ljava/lang/RuntimeException;
        //  488    495    3      8      Ljava/lang/IllegalArgumentException;
        //  501    508    508    509    Any
        //  501    508    501    502    Ljava/lang/ClassCastException;
        //  501    508    501    502    Ljava/util/ConcurrentModificationException;
        //  501    508    3      8      Ljava/lang/NumberFormatException;
        //  501    508    501    502    Any
        //  515    522    522    523    Any
        //  516    522    515    516    Any
        //  515    522    522    523    Any
        //  515    522    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  516    522    515    516    Ljava/lang/IndexOutOfBoundsException;
        //  537    544    544    545    Any
        //  537    544    3      8      Ljava/lang/AssertionError;
        //  537    544    537    538    Ljava/util/NoSuchElementException;
        //  538    544    544    545    Ljava/lang/EnumConstantNotPresentException;
        //  538    544    537    538    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  592    598    598    599    Any
        //  592    598    3      8      Any
        //  592    598    598    599    Any
        //  592    598    598    599    Ljava/lang/ClassCastException;
        //  592    598    3      8      Any
        //  606    613    613    614    Any
        //  606    613    606    607    Any
        //  607    613    606    607    Any
        //  607    613    613    614    Ljava/lang/AssertionError;
        //  607    613    606    607    Ljava/lang/IllegalArgumentException;
        //  667    674    674    675    Any
        //  668    674    3      8      Any
        //  668    674    3      8      Any
        //  668    674    667    668    Any
        //  668    674    3      8      Ljava/lang/IllegalArgumentException;
        //  678    685    685    686    Any
        //  679    685    678    679    Ljava/util/NoSuchElementException;
        //  678    685    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  678    685    678    679    Any
        //  679    685    678    679    Ljava/lang/ClassCastException;
        //  728    734    734    735    Any
        //  728    734    734    735    Ljava/util/NoSuchElementException;
        //  728    734    734    735    Ljava/util/ConcurrentModificationException;
        //  728    734    3      8      Ljava/lang/UnsupportedOperationException;
        //  728    734    734    735    Any
        //  779    786    786    787    Any
        //  779    786    3      8      Ljava/lang/RuntimeException;
        //  780    786    779    780    Ljava/lang/AssertionError;
        //  779    786    3      8      Any
        //  780    786    779    780    Any
        //  790    797    797    798    Any
        //  790    797    790    791    Any
        //  790    797    3      8      Ljava/util/ConcurrentModificationException;
        //  791    797    797    798    Any
        //  790    797    797    798    Any
        //  801    808    808    809    Any
        //  802    808    808    809    Any
        //  801    808    801    802    Ljava/lang/RuntimeException;
        //  802    808    801    802    Ljava/lang/AssertionError;
        //  802    808    3      8      Ljava/lang/ArithmeticException;
        //  812    819    819    820    Any
        //  812    819    819    820    Any
        //  813    819    819    820    Any
        //  813    819    819    820    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  812    819    812    813    Any
        //  907    914    914    915    Any
        //  907    914    3      8      Ljava/lang/IllegalArgumentException;
        //  908    914    3      8      Any
        //  908    914    907    908    Any
        //  908    914    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  918    925    925    926    Any
        //  919    925    3      8      Any
        //  918    925    918    919    Any
        //  919    925    925    926    Ljava/lang/UnsupportedOperationException;
        //  919    925    925    926    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  976    982    982    983    Any
        //  976    982    982    983    Any
        //  976    982    982    983    Ljava/lang/StringIndexOutOfBoundsException;
        //  976    982    3      8      Any
        //  976    982    3      8      Ljava/lang/IllegalArgumentException;
        //  1027   1034   1034   1035   Any
        //  1027   1034   3      8      Ljava/lang/ArithmeticException;
        //  1028   1034   3      8      Ljava/lang/NumberFormatException;
        //  1027   1034   3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1028   1034   1027   1028   Any
        //  1038   1045   1045   1046   Any
        //  1038   1045   1038   1039   Any
        //  1038   1045   3      8      Ljava/lang/NegativeArraySizeException;
        //  1038   1045   1038   1039   Any
        //  1038   1045   3      8      Ljava/lang/IllegalStateException;
        //  1049   1056   1056   1057   Any
        //  1050   1056   1056   1057   Any
        //  1049   1056   1056   1057   Ljava/util/ConcurrentModificationException;
        //  1049   1056   1049   1050   Ljava/lang/IllegalStateException;
        //  1049   1056   1049   1050   Any
        //  1103   1110   1110   1111   Any
        //  1104   1110   1110   1111   Any
        //  1104   1110   1103   1104   Ljava/lang/NumberFormatException;
        //  1104   1110   1103   1104   Any
        //  1103   1110   1103   1104   Ljava/lang/IndexOutOfBoundsException;
        //  1167   1174   1174   1175   Any
        //  1167   1174   1167   1168   Ljava/util/ConcurrentModificationException;
        //  1167   1174   1174   1175   Any
        //  1167   1174   1167   1168   Ljava/lang/NullPointerException;
        //  1168   1174   1167   1168   Any
        //  1179   1185   1185   1186   Any
        //  1179   1185   1185   1186   Ljava/lang/NumberFormatException;
        //  1179   1185   1185   1186   Any
        //  1179   1185   1185   1186   Ljava/lang/ArithmeticException;
        //  1179   1185   3      8      Ljava/lang/IllegalArgumentException;
        //  1193   1200   1200   1201   Any
        //  1193   1200   3      8      Ljava/lang/ClassCastException;
        //  1193   1200   3      8      Any
        //  1194   1200   1193   1194   Ljava/lang/AssertionError;
        //  1194   1200   1200   1201   Any
        //  1248   1254   1254   1255   Any
        //  1248   1254   3      8      Any
        //  1248   1254   1254   1255   Ljava/lang/NegativeArraySizeException;
        //  1248   1254   3      8      Ljava/lang/IllegalStateException;
        //  1248   1254   3      8      Any
        //  1273   1280   1280   1281   Any
        //  1273   1280   3      8      Ljava/lang/IllegalStateException;
        //  1274   1280   1273   1274   Ljava/lang/NullPointerException;
        //  1273   1280   3      8      Any
        //  1274   1280   1273   1274   Any
        //  1288   1295   1295   1296   Any
        //  1288   1295   1295   1296   Any
        //  1288   1295   3      8      Ljava/lang/RuntimeException;
        //  1288   1295   1288   1289   Ljava/util/NoSuchElementException;
        //  1288   1295   1295   1296   Any
        //  1346   1353   1353   1354   Any
        //  1346   1353   1346   1347   Ljava/lang/StringIndexOutOfBoundsException;
        //  1346   1353   1346   1347   Ljava/lang/NullPointerException;
        //  1346   1353   1346   1347   Ljava/util/ConcurrentModificationException;
        //  1346   1353   3      8      Any
        //  1455   1462   1462   1463   Any
        //  1455   1462   1462   1463   Any
        //  1456   1462   1462   1463   Any
        //  1456   1462   1455   1456   Ljava/util/ConcurrentModificationException;
        //  1456   1462   3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1476   1483   1483   1484   Any
        //  1477   1483   1476   1477   Ljava/util/NoSuchElementException;
        //  1476   1483   1476   1477   Ljava/util/NoSuchElementException;
        //  1476   1483   1476   1477   Ljava/lang/UnsupportedOperationException;
        //  1477   1483   1483   1484   Ljava/lang/UnsupportedOperationException;
        //  1491   1497   1497   1498   Any
        //  1491   1497   1497   1498   Ljava/lang/AssertionError;
        //  1491   1497   3      8      Ljava/lang/RuntimeException;
        //  1491   1497   1497   1498   Any
        //  1491   1497   3      8      Any
        //  1551   1558   1558   1559   Any
        //  1552   1558   1558   1559   Any
        //  1552   1558   1558   1559   Ljava/lang/IllegalArgumentException;
        //  1552   1558   1551   1552   Any
        //  1551   1558   3      8      Any
        //  1656   1662   1662   1663   Any
        //  1656   1662   3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1656   1662   3      8      Any
        //  1656   1662   1662   1663   Ljava/util/NoSuchElementException;
        //  1656   1662   3      8      Any
        //  1831   1838   1838   1839   Any
        //  1831   1838   1838   1839   Any
        //  1832   1838   3      8      Any
        //  1832   1838   1831   1832   Any
        //  1831   1838   3      8      Any
        //  1988   1994   1994   1995   Any
        //  1988   1994   1994   1995   Ljava/lang/NumberFormatException;
        //  1988   1994   3      8      Ljava/lang/ArithmeticException;
        //  1988   1994   3      8      Any
        //  1988   1994   1994   1995   Any
        //  2054   2061   2061   2062   Any
        //  2055   2061   3      8      Any
        //  2055   2061   2054   2055   Ljava/util/NoSuchElementException;
        //  2055   2061   2054   2055   Any
        //  2055   2061   3      8      Ljava/lang/IllegalStateException;
        //  2221   2227   2227   2228   Any
        //  2221   2227   3      8      Ljava/util/NoSuchElementException;
        //  2221   2227   3      8      Any
        //  2221   2227   2227   2228   Ljava/lang/UnsupportedOperationException;
        //  2221   2227   2227   2228   Any
        //  2281   2288   2288   2289   Any
        //  2282   2288   3      8      Any
        //  2282   2288   2281   2282   Ljava/lang/EnumConstantNotPresentException;
        //  2282   2288   2288   2289   Any
        //  2281   2288   2288   2289   Any
        //  2343   2350   2350   2351   Any
        //  2344   2350   2343   2344   Ljava/lang/IllegalStateException;
        //  2344   2350   3      8      Ljava/lang/ClassCastException;
        //  2343   2350   3      8      Any
        //  2344   2350   3      8      Any
        //  2455   2462   2462   2463   Any
        //  2456   2462   2455   2456   Any
        //  2455   2462   3      8      Ljava/util/ConcurrentModificationException;
        //  2456   2462   2455   2456   Ljava/lang/NumberFormatException;
        //  2455   2462   2462   2463   Ljava/lang/AssertionError;
        //  2569   2576   2576   2577   Any
        //  2569   2576   2569   2570   Any
        //  2569   2576   2569   2570   Any
        //  2570   2576   3      8      Ljava/lang/ClassCastException;
        //  2569   2576   3      8      Any
        //  2747   2754   2754   2755   Any
        //  2747   2754   2754   2755   Any
        //  2747   2754   3      8      Ljava/lang/NullPointerException;
        //  2748   2754   2747   2748   Ljava/lang/ArithmeticException;
        //  2748   2754   2747   2748   Ljava/util/ConcurrentModificationException;
        //  2759   2765   2765   2766   Any
        //  2759   2765   3      8      Any
        //  2759   2765   2765   2766   Ljava/lang/RuntimeException;
        //  2759   2765   2765   2766   Any
        //  2759   2765   3      8      Ljava/util/ConcurrentModificationException;
        //  2839   2846   2846   2847   Any
        //  2840   2846   3      8      Any
        //  2839   2846   2846   2847   Ljava/lang/UnsupportedOperationException;
        //  2839   2846   2839   2840   Any
        //  2839   2846   2839   2840   Any
        //  2850   2857   2857   2858   Any
        //  2851   2857   3      8      Ljava/lang/AssertionError;
        //  2850   2857   2857   2858   Any
        //  2851   2857   2857   2858   Any
        //  2850   2857   2850   2851   Ljava/lang/ArithmeticException;
        //  3019   3026   3026   3027   Any
        //  3020   3026   3019   3020   Ljava/lang/EnumConstantNotPresentException;
        //  3020   3026   3      8      Any
        //  3019   3026   3026   3027   Ljava/lang/RuntimeException;
        //  3020   3026   3026   3027   Any
        //  3030   3037   3037   3038   Any
        //  3030   3037   3      8      Any
        //  3031   3037   3037   3038   Any
        //  3030   3037   3030   3031   Ljava/lang/UnsupportedOperationException;
        //  3031   3037   3030   3031   Any
        //  3404   3411   3411   3412   Any
        //  3404   3411   3404   3405   Ljava/lang/ClassCastException;
        //  3404   3411   3411   3412   Any
        //  3405   3411   3411   3412   Any
        //  3405   3411   3411   3412   Ljava/lang/NumberFormatException;
        //  3463   3470   3470   3471   Any
        //  3464   3470   3470   3471   Any
        //  3463   3470   3      8      Any
        //  3463   3470   3463   3464   Ljava/util/ConcurrentModificationException;
        //  3463   3470   3463   3464   Any
        //  3485   3492   3492   3493   Any
        //  3485   3492   3492   3493   Ljava/lang/UnsupportedOperationException;
        //  3485   3492   3485   3486   Ljava/lang/EnumConstantNotPresentException;
        //  3485   3492   3      8      Ljava/lang/NegativeArraySizeException;
        //  3486   3492   3485   3486   Ljava/util/ConcurrentModificationException;
        //  3496   3503   3503   3504   Any
        //  3496   3503   3496   3497   Ljava/lang/AssertionError;
        //  3497   3503   3503   3504   Ljava/lang/StringIndexOutOfBoundsException;
        //  3497   3503   3503   3504   Ljava/lang/AssertionError;
        //  3497   3503   3496   3497   Ljava/util/NoSuchElementException;
        //  3562   3569   3569   3570   Any
        //  3562   3569   3569   3570   Ljava/lang/IllegalStateException;
        //  3562   3569   3562   3563   Any
        //  3562   3569   3      8      Ljava/lang/EnumConstantNotPresentException;
        //  3562   3569   3569   3570   Any
        //  3573   3580   3580   3581   Any
        //  3573   3580   3580   3581   Ljava/lang/NumberFormatException;
        //  3573   3580   3580   3581   Any
        //  3573   3580   3580   3581   Any
        //  3574   3580   3573   3574   Any
        //  3687   3694   3694   3695   Any
        //  3688   3694   3694   3695   Ljava/lang/AssertionError;
        //  3687   3694   3      8      Ljava/lang/EnumConstantNotPresentException;
        //  3687   3694   3694   3695   Ljava/lang/ClassCastException;
        //  3688   3694   3687   3688   Ljava/lang/NullPointerException;
        //  3743   3750   3750   3751   Any
        //  3743   3750   3750   3751   Ljava/lang/ArithmeticException;
        //  3744   3750   3      8      Any
        //  3743   3750   3743   3744   Any
        //  3744   3750   3743   3744   Any
        //  3967   3974   3974   3975   Any
        //  3968   3974   3967   3968   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  3967   3974   3967   3968   Any
        //  3967   3974   3974   3975   Any
        //  3967   3974   3974   3975   Any
        //  3978   3985   3985   3986   Any
        //  3978   3985   3978   3979   Any
        //  3979   3985   3      8      Any
        //  3979   3985   3      8      Any
        //  3978   3985   3978   3979   Ljava/lang/RuntimeException;
        //  4040   4048   4048   4049   Any
        //  4040   4048   4048   4049   Ljava/lang/RuntimeException;
        //  4040   4048   3      8      Ljava/lang/NumberFormatException;
        //  4040   4048   3      8      Ljava/lang/NegativeArraySizeException;
        //  4040   4048   4048   4049   Any
        //  4056   4065   4065   4066   Any
        //  4057   4065   4065   4066   Ljava/lang/UnsupportedOperationException;
        //  4056   4065   4056   4057   Ljava/lang/IndexOutOfBoundsException;
        //  4057   4065   3      8      Any
        //  4056   4065   3      8      Ljava/lang/NullPointerException;
        //  4074   4083   4083   4084   Any
        //  4074   4083   4074   4075   Any
        //  4074   4083   4074   4075   Ljava/lang/IllegalArgumentException;
        //  4075   4083   4074   4075   Ljava/lang/StringIndexOutOfBoundsException;
        //  4074   4083   3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  4193   4200   4200   4201   Any
        //  4193   4200   4193   4194   Any
        //  4194   4200   4193   4194   Any
        //  4193   4200   4200   4201   Any
        //  4193   4200   4193   4194   Any
        //  4207   4214   4214   4215   Any
        //  4207   4214   4214   4215   Ljava/lang/EnumConstantNotPresentException;
        //  4207   4214   4207   4208   Ljava/lang/AssertionError;
        //  4207   4214   4214   4215   Ljava/lang/IllegalArgumentException;
        //  4208   4214   4214   4215   Any
        //  4223   4230   4230   4231   Any
        //  4223   4230   4230   4231   Ljava/lang/NumberFormatException;
        //  4223   4230   4230   4231   Ljava/lang/IllegalStateException;
        //  4224   4230   4223   4224   Ljava/lang/RuntimeException;
        //  4223   4230   3      8      Any
        //  4238   4245   4245   4246   Any
        //  4239   4245   4238   4239   Ljava/util/NoSuchElementException;
        //  4239   4245   3      8      Any
        //  4239   4245   4238   4239   Any
        //  4239   4245   4238   4239   Any
        //  4299   4306   4306   4307   Any
        //  4299   4306   4306   4307   Any
        //  4299   4306   3      8      Ljava/lang/RuntimeException;
        //  4299   4306   4299   4300   Any
        //  4299   4306   4299   4300   Any
        //  4314   4320   4320   4321   Any
        //  4314   4320   4320   4321   Any
        //  4314   4320   3      8      Ljava/lang/IllegalArgumentException;
        //  4314   4320   4320   4321   Ljava/lang/RuntimeException;
        //  4314   4320   4320   4321   Ljava/lang/AssertionError;
        //  4324   4331   4331   4332   Any
        //  4325   4331   4324   4325   Ljava/lang/StringIndexOutOfBoundsException;
        //  4325   4331   4324   4325   Ljava/lang/IllegalStateException;
        //  4324   4331   4324   4325   Ljava/lang/IllegalArgumentException;
        //  4324   4331   4324   4325   Any
        //  4335   4342   4342   4343   Any
        //  4335   4342   3      8      Any
        //  4335   4342   4335   4336   Any
        //  4335   4342   4335   4336   Any
        //  4335   4342   4342   4343   Any
        //  4349   4356   4356   4357   Any
        //  4349   4356   4349   4350   Ljava/lang/IllegalArgumentException;
        //  4350   4356   4349   4350   Any
        //  4349   4356   4356   4357   Ljava/lang/RuntimeException;
        //  4350   4356   3      8      Any
        //  4360   4367   4367   4368   Any
        //  4360   4367   4360   4361   Ljava/lang/RuntimeException;
        //  4361   4367   3      8      Any
        //  4361   4367   4367   4368   Any
        //  4361   4367   3      8      Ljava/lang/NegativeArraySizeException;
        //  4371   4378   4378   4379   Any
        //  4372   4378   3      8      Any
        //  4371   4378   4371   4372   Ljava/lang/NumberFormatException;
        //  4371   4378   3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  4372   4378   4378   4379   Any
        //  4434   4441   4441   4442   Any
        //  4435   4441   4434   4435   Any
        //  4434   4441   4434   4435   Ljava/lang/IllegalStateException;
        //  4434   4441   4434   4435   Ljava/lang/NullPointerException;
        //  4435   4441   4434   4435   Ljava/lang/EnumConstantNotPresentException;
        //  4495   4502   4502   4503   Any
        //  4496   4502   3      8      Ljava/lang/IllegalStateException;
        //  4496   4502   4502   4503   Any
        //  4496   4502   4502   4503   Any
        //  4496   4502   4495   4496   Any
        //  4607   4614   4614   4615   Any
        //  4608   4614   4607   4608   Ljava/lang/IllegalArgumentException;
        //  4608   4614   4614   4615   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  4607   4614   4614   4615   Any
        //  4607   4614   4614   4615   Any
        //  4623   4630   4630   4631   Any
        //  4624   4630   4623   4624   Any
        //  4624   4630   3      8      Any
        //  4623   4630   4630   4631   Ljava/lang/StringIndexOutOfBoundsException;
        //  4624   4630   4630   4631   Any
        //  4653   4660   4660   4661   Any
        //  4654   4660   4653   4654   Ljava/lang/NumberFormatException;
        //  4654   4660   4653   4654   Ljava/lang/IllegalArgumentException;
        //  4654   4660   4653   4654   Any
        //  4654   4660   3      8      Ljava/lang/NullPointerException;
        //  4669   4676   4676   4677   Any
        //  4670   4676   4669   4670   Any
        //  4670   4676   4669   4670   Ljava/lang/RuntimeException;
        //  4670   4676   4676   4677   Ljava/lang/EnumConstantNotPresentException;
        //  4670   4676   4676   4677   Ljava/lang/ClassCastException;
        //  4686   4693   4693   4694   Any
        //  4686   4693   4693   4694   Ljava/lang/ClassCastException;
        //  4687   4693   4693   4694   Any
        //  4686   4693   4686   4687   Any
        //  4687   4693   4693   4694   Ljava/lang/NegativeArraySizeException;
        //  4755   4762   4762   4763   Any
        //  4756   4762   4755   4756   Ljava/lang/IllegalArgumentException;
        //  4756   4762   3      8      Ljava/lang/ClassCastException;
        //  4755   4762   3      8      Any
        //  4755   4762   4755   4756   Ljava/lang/AssertionError;
        //  4885   4891   4891   4892   Any
        //  4885   4891   4891   4892   Ljava/lang/EnumConstantNotPresentException;
        //  4885   4891   3      8      Ljava/lang/NullPointerException;
        //  4885   4891   3      8      Any
        //  4885   4891   3      8      Ljava/lang/IllegalStateException;
        //  4896   4903   4903   4904   Any
        //  4896   4903   3      8      Ljava/util/ConcurrentModificationException;
        //  4897   4903   4896   4897   Ljava/lang/EnumConstantNotPresentException;
        //  4896   4903   4903   4904   Any
        //  4897   4903   3      8      Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:577)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @NotNull
    public f0k 4() {
        return fez.7R(this, 870869423);
    }
    
    public static Minecraft c(final f9A p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getstatic       dev/nuker/pyro/fc.c:I
        //     4: ifeq            38
        //     7: pop            
        //     8: aconst_null    
        //     9: goto            30
        //    12: nop            
        //    13: nop            
        //    14: nop            
        //    15: athrow         
        //    16: aload_0        
        //    17: getfield        dev/nuker/pyro/f9A.c:Lnet/minecraft/client/Minecraft;
        //    20: areturn        
        //    21: pop            
        //    22: goto            16
        //    25: pop            
        //    26: aconst_null    
        //    27: goto            21
        //    30: dup            
        //    31: ifnull          21
        //    34: checkcast       Ljava/lang/Throwable;
        //    37: athrow         
        //    38: dup            
        //    39: ifnull          25
        //    42: checkcast       Ljava/lang/Throwable;
        //    45: athrow         
        //    StackMapTable: 00 06 FF 00 0C 00 00 00 01 07 00 49 FC 00 03 07 00 03 44 07 00 49 43 05 44 07 00 49 47 05
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type
        //  -----  -----  -----  -----  ----
        //  0      12     30     38     Any
        //  30     38     30     38     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:543)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public boolean 3() {
        return fez.hq(this, 115754441);
    }
    
    @NotNull
    public f0k 1() {
        return fez.7D(this, 1620130873);
    }
    
    @NotNull
    public f0m 8() {
        return fez.9m(this, 1845625895);
    }
    
    public boolean c() {
        return fez.hs(this, 1036993347);
    }
    
    @f0g
    @LauncherEventHide
    public void c(@NotNull final f4t f4t) {
        fez.jJ(this, 1298310468, f4t);
    }
    
    public boolean a() {
        return fez.hM(this, 463984234);
    }
    
    static {
        throw t;
    }
    
    @NotNull
    public f0o 9() {
        Object o = null;
        Block_0: {
            break Block_0;
        Label_0087:
            while (true) {
            Label_0070_Outer:
                do {
                    Label_0074: {
                        break Label_0074;
                        while (true) {
                            try {
                                o = null;
                                if (fc.1 == 0) {
                                    continue Label_0087;
                                }
                                null;
                                // iftrue(Label_0029:, fc.c != 0)
                                Label_0032: {
                                    while (true) {
                                        final int n = -1238428116;
                                        break Label_0032;
                                        continue Label_0070_Outer;
                                    }
                                    Label_0029: {
                                        final int n = -1359888115;
                                    }
                                    break Label_0032;
                                    Label_0064:
                                    return this.c;
                                }
                                // switch([Lcom.strobel.decompiler.ast.Label;@4128df0b, n ^ 0x8CABA5D9)
                                continue;
                                Label_0068: {
                                    throw null;
                                }
                            }
                            catch (ClassCastException ex) {
                                if (ex != null) {
                                    throw ex;
                                }
                                continue;
                            }
                            break;
                        }
                    }
                    continue Label_0087;
                } while (o == null);
                break;
            }
        }
        throw (Throwable)o;
    }
    
    @f0g
    @LauncherEventHide
    public void c(@Nullable final f4p f4p) {
        fez.6l(this, 1613559774, f4p);
    }
    
    @NotNull
    public f0k 7() {
        return fez.6L(this, 452214642);
    }
    
    public void 2() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          409
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            401
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            393
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: getstatic       dev/nuker/pyro/fc.1:I
        //    27: ifne            36
        //    30: ldc_w           -1150121641
        //    33: goto            39
        //    36: ldc_w           -1981652078
        //    39: ldc_w           -471520349
        //    42: ixor           
        //    43: lookupswitch {
        //          449865683: 36
        //          1486332660: 382
        //          default: 68
        //        }
        //    68: aload_0        
        //    69: aload_0        
        //    70: getfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/f0o;
        //    73: goto            77
        //    76: athrow         
        //    77: invokevirtual   dev/nuker/pyro/f0o.c:()Ljava/lang/Object;
        //    80: goto            84
        //    83: athrow         
        //    84: checkcast       Ldev/nuker/pyro/f9w;
        //    87: getstatic       dev/nuker/pyro/fc.1:I
        //    90: ifne            99
        //    93: ldc_w           1988073417
        //    96: goto            102
        //    99: ldc_w           1965281740
        //   102: ldc_w           -363248538
        //   105: ixor           
        //   106: lookupswitch {
        //          -1807265709: 99
        //          -1675177041: 380
        //          default: 132
        //        }
        //   132: getstatic       dev/nuker/pyro/f9x.c:[I
        //   135: swap           
        //   136: goto            140
        //   139: athrow         
        //   140: invokevirtual   dev/nuker/pyro/f9w.ordinal:()I
        //   143: goto            147
        //   146: athrow         
        //   147: iaload         
        //   148: tableswitch {
        //                2: 180
        //                3: 201
        //                4: 269
        //                5: 290
        //          default: 311
        //        }
        //   180: new             Ldev/nuker/pyro/faq;
        //   183: dup            
        //   184: goto            188
        //   187: athrow         
        //   188: invokespecial   dev/nuker/pyro/faq.<init>:()V
        //   191: goto            195
        //   194: athrow         
        //   195: checkcast       Ldev/nuker/pyro/far;
        //   198: goto            327
        //   201: new             Ldev/nuker/pyro/fao;
        //   204: dup            
        //   205: getstatic       dev/nuker/pyro/fc.c:I
        //   208: ifne            217
        //   211: ldc_w           -1190662081
        //   214: goto            220
        //   217: ldc_w           -1708270030
        //   220: ldc_w           697633009
        //   223: ixor           
        //   224: lookupswitch {
        //          -2074555125: 217
        //          -1869416242: 376
        //          default: 252
        //        }
        //   252: goto            256
        //   255: athrow         
        //   256: invokespecial   dev/nuker/pyro/fao.<init>:()V
        //   259: goto            263
        //   262: athrow         
        //   263: checkcast       Ldev/nuker/pyro/far;
        //   266: goto            327
        //   269: new             Ldev/nuker/pyro/fap;
        //   272: dup            
        //   273: goto            277
        //   276: athrow         
        //   277: invokespecial   dev/nuker/pyro/fap.<init>:()V
        //   280: goto            284
        //   283: athrow         
        //   284: checkcast       Ldev/nuker/pyro/far;
        //   287: goto            327
        //   290: new             Ldev/nuker/pyro/fan;
        //   293: dup            
        //   294: goto            298
        //   297: athrow         
        //   298: invokespecial   dev/nuker/pyro/fan.<init>:()V
        //   301: goto            305
        //   304: athrow         
        //   305: checkcast       Ldev/nuker/pyro/far;
        //   308: goto            327
        //   311: new             Lkotlin/NoWhenBranchMatchedException;
        //   314: dup            
        //   315: goto            319
        //   318: athrow         
        //   319: invokespecial   kotlin/NoWhenBranchMatchedException.<init>:()V
        //   322: goto            326
        //   325: athrow         
        //   326: athrow         
        //   327: getstatic       dev/nuker/pyro/fc.c:I
        //   330: ifne            339
        //   333: ldc_w           -911109261
        //   336: goto            342
        //   339: ldc_w           684933003
        //   342: ldc_w           276258548
        //   345: ixor           
        //   346: lookupswitch {
        //          -641282681: 378
        //          1258100927: 339
        //          default: 372
        //        }
        //   372: putfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/far;
        //   375: return         
        //   376: aconst_null    
        //   377: athrow         
        //   378: aconst_null    
        //   379: athrow         
        //   380: aconst_null    
        //   381: athrow         
        //   382: aconst_null    
        //   383: athrow         
        //   384: pop            
        //   385: goto            24
        //   388: pop            
        //   389: aconst_null    
        //   390: goto            384
        //   393: dup            
        //   394: ifnull          384
        //   397: checkcast       Ljava/lang/Throwable;
        //   400: athrow         
        //   401: dup            
        //   402: ifnull          388
        //   405: checkcast       Ljava/lang/Throwable;
        //   408: athrow         
        //   409: aconst_null    
        //   410: athrow         
        //    StackMapTable: 00 3B 43 07 00 49 04 FF 00 0B 00 00 00 01 07 00 49 FC 00 03 07 00 03 0B 42 01 1C FF 00 07 00 00 00 01 07 00 49 FF 00 00 00 01 07 00 03 00 02 07 00 03 07 02 99 45 07 00 49 FF 00 00 00 01 07 00 03 00 02 07 00 03 07 02 56 FF 00 0E 00 01 07 00 03 00 02 07 00 03 07 02 9C FF 00 02 00 01 07 00 03 00 03 07 00 03 07 02 9C 01 FF 00 1D 00 01 07 00 03 00 02 07 00 03 07 02 9C 46 07 00 49 FF 00 00 00 01 07 00 03 00 03 07 00 03 07 02 BD 07 02 9C 45 07 00 49 FF 00 00 00 01 07 00 03 00 03 07 00 03 07 02 BD 01 60 07 00 03 46 07 00 40 FF 00 00 00 01 07 00 03 00 03 07 00 03 08 00 B4 08 00 B4 45 07 00 49 FF 00 00 00 01 07 00 03 00 02 07 00 03 07 02 A9 45 07 00 03 FF 00 0F 00 01 07 00 03 00 03 07 00 03 08 00 C9 08 00 C9 FF 00 02 00 01 07 00 03 00 04 07 00 03 08 00 C9 08 00 C9 01 FF 00 1F 00 01 07 00 03 00 03 07 00 03 08 00 C9 08 00 C9 FF 00 02 00 00 00 01 07 00 49 FF 00 00 00 01 07 00 03 00 03 07 00 03 08 00 C9 08 00 C9 45 07 00 49 FF 00 00 00 01 07 00 03 00 02 07 00 03 07 02 AC 45 07 00 03 46 07 00 49 FF 00 00 00 01 07 00 03 00 03 07 00 03 08 01 0D 08 01 0D 45 07 00 49 FF 00 00 00 01 07 00 03 00 02 07 00 03 07 02 B2 45 07 00 03 46 07 00 3A FF 00 00 00 01 07 00 03 00 03 07 00 03 08 01 22 08 01 22 45 07 00 49 FF 00 00 00 01 07 00 03 00 02 07 00 03 07 02 B5 45 07 00 03 46 07 00 49 FF 00 00 00 01 07 00 03 00 03 07 00 03 08 01 37 08 01 37 45 07 00 49 FF 00 00 00 01 07 00 03 00 02 07 00 03 07 02 B8 FF 00 00 00 01 07 00 03 00 02 07 00 03 07 02 52 FF 00 0B 00 01 07 00 03 00 02 07 00 03 07 02 52 FF 00 02 00 01 07 00 03 00 03 07 00 03 07 02 52 01 FF 00 1D 00 01 07 00 03 00 02 07 00 03 07 02 52 FF 00 03 00 01 07 00 03 00 03 07 00 03 08 00 C9 08 00 C9 FF 00 01 00 01 07 00 03 00 02 07 00 03 07 02 52 FF 00 01 00 01 07 00 03 00 02 07 00 03 07 02 9C 01 41 07 00 49 43 05 44 07 00 49 47 05 47 07 00 49
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     393    401    Any
        //  393    401    393    401    Any
        //  409    411    3      8      Any
        //  77     83     83     84     Any
        //  77     83     83     84     Ljava/lang/IndexOutOfBoundsException;
        //  77     83     3      8      Ljava/lang/ArithmeticException;
        //  77     83     83     84     Any
        //  77     83     3      8      Ljava/lang/RuntimeException;
        //  139    146    146    147    Any
        //  140    146    3      8      Any
        //  139    146    146    147    Any
        //  139    146    3      8      Ljava/lang/IllegalArgumentException;
        //  139    146    139    140    Any
        //  187    194    194    195    Any
        //  187    194    194    195    Any
        //  188    194    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  187    194    194    195    Ljava/lang/IndexOutOfBoundsException;
        //  187    194    187    188    Ljava/util/ConcurrentModificationException;
        //  256    262    262    263    Any
        //  256    262    262    263    Any
        //  256    262    3      8      Ljava/lang/ArithmeticException;
        //  256    262    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  256    262    3      8      Ljava/lang/ArithmeticException;
        //  276    283    283    284    Any
        //  277    283    276    277    Ljava/lang/ArithmeticException;
        //  277    283    3      8      Any
        //  277    283    276    277    Any
        //  277    283    283    284    Any
        //  297    304    304    305    Any
        //  297    304    304    305    Ljava/lang/RuntimeException;
        //  298    304    3      8      Any
        //  298    304    297    298    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  297    304    304    305    Ljava/util/ConcurrentModificationException;
        //  318    325    325    326    Any
        //  319    325    3      8      Ljava/lang/ArithmeticException;
        //  318    325    325    326    Ljava/util/NoSuchElementException;
        //  319    325    318    319    Any
        //  319    325    3      8      Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:595)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void c(final f9A f9A, final Minecraft c) {
        Object o = null;
        Block_0: {
            break Block_0;
        Label_0088:
            while (true) {
            Label_0071_Outer:
                do {
                    Label_0075: {
                        break Label_0075;
                    Label_0071:
                        while (true) {
                            try {
                                o = null;
                                if (fc.c == 0) {
                                    continue Label_0088;
                                }
                                null;
                                Label_0029: {
                                    final int n = -1591070318;
                                }
                                // switch([Lcom.strobel.decompiler.ast.Label;@16237460, n ^ 0x6817E5E6)
                                while (true) {
                                    while (true) {
                                        break Label_0032;
                                        Label_0064:
                                        f9A.c = c;
                                        return;
                                        break Label_0071;
                                        Label_0069:
                                        throw null;
                                        final int n = -527609290;
                                        continue Label_0071_Outer;
                                    }
                                    continue;
                                }
                            }
                            // iftrue(Label_0029:, fc.c != 0)
                            catch (IllegalStateException ex) {
                                if (ex != null) {
                                    throw ex;
                                }
                                continue Label_0071;
                            }
                            break;
                        }
                    }
                    continue Label_0088;
                } while (o == null);
                break;
            }
        }
        throw (Throwable)o;
    }
    
    @Nullable
    public far 6() {
        return fez.5U(this, 1926763749);
    }
    
    public f9A() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: ldc_w           "\u3cfd\ub24a\u8fcd\uada3\u67b4\u5801\u7e4d\u68c4"
        //     4: invokestatic    invokestatic   !!! ERROR
        //     7: ldc_w           "\u3cdd\ub24a\u8fcd\uada3\u6794\u5801\u7e4d\u68c4"
        //    10: getstatic       dev/nuker/pyro/fc.c:I
        //    13: ifne            22
        //    16: ldc_w           -2078473036
        //    19: goto            25
        //    22: ldc_w           -906708501
        //    25: ldc_w           912770935
        //    28: ixor           
        //    29: lookupswitch {
        //          -1300577341: 22
        //          -7111012: 56
        //          default: 614
        //        }
        //    56: invokestatic    invokestatic   !!! ERROR
        //    59: ldc_w           "\u3cd0\ub249\u8fcf\uadab\u67a9\u5807\u7e00\u68cd\uc2cc\ua34d\u9a08\u1310\uc0ba\u714e\u9065\u4c09\ub21c\u4d4f\u0102\u078b\u1305\ufed6\u6b17\u885c\u3698\u3c89"
        //    62: invokestatic    invokestatic   !!! ERROR
        //    65: invokespecial   dev/nuker/pyro/fQ.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //    68: aload_0        
        //    69: aload_0        
        //    70: new             Ldev/nuker/pyro/f0o;
        //    73: dup            
        //    74: ldc_w           "\u3cfc\ub24a\u8fc7\uada1"
        //    77: invokestatic    invokestatic   !!! ERROR
        //    80: ldc_w           "\u3cdc\ub24a\u8fc7\uada1"
        //    83: invokestatic    invokestatic   !!! ERROR
        //    86: aconst_null    
        //    87: getstatic       dev/nuker/pyro/f9w.1:Ldev/nuker/pyro/f9w;
        //    90: checkcast       Ljava/lang/Enum;
        //    93: invokespecial   dev/nuker/pyro/f0o.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Enum;)V
        //    96: checkcast       Ldev/nuker/pyro/f0w;
        //    99: invokevirtual   dev/nuker/pyro/f9A.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   102: checkcast       Ldev/nuker/pyro/f0o;
        //   105: putfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/f0o;
        //   108: aload_0        
        //   109: aload_0        
        //   110: new             Ldev/nuker/pyro/f0m;
        //   113: dup            
        //   114: ldc_w           "\u3ce2\ub255\u8fc6\uada1\u67ba\u583d\u7e4e\u68d7"
        //   117: getstatic       dev/nuker/pyro/fc.0:I
        //   120: ifgt            129
        //   123: ldc_w           1048007508
        //   126: goto            132
        //   129: ldc_w           -42498106
        //   132: ldc_w           1375456217
        //   135: ixor           
        //   136: lookupswitch {
        //          -1400091617: 164
        //          1871485069: 129
        //          default: 610
        //        }
        //   164: invokestatic    invokestatic   !!! ERROR
        //   167: ldc_w           "\u3cc2\ub255\u8fc6\uada1\u67ba\u583d\u7e4e\u68d7"
        //   170: invokestatic    invokestatic   !!! ERROR
        //   173: aconst_null    
        //   174: ldc2_w          1.61
        //   177: dconst_0       
        //   178: ldc2_w          3.0
        //   181: dconst_0       
        //   182: bipush          64
        //   184: aconst_null    
        //   185: invokespecial   dev/nuker/pyro/f0m.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;DDDDILkotlin/jvm/internal/DefaultConstructorMarker;)V
        //   188: checkcast       Ldev/nuker/pyro/f0w;
        //   191: invokevirtual   dev/nuker/pyro/f9A.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   194: checkcast       Ldev/nuker/pyro/f0m;
        //   197: putfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/f0m;
        //   200: aload_0        
        //   201: aload_0        
        //   202: new             Ldev/nuker/pyro/f0k;
        //   205: dup            
        //   206: ldc_w           "\u3ce0\ub250\u8fca\uadb0\u6791\u581a\u7e67\u68c6\uc2cc\ua34d\u9a46\u1300"
        //   209: invokestatic    invokestatic   !!! ERROR
        //   212: ldc_w           "\u3cc2\ub251\u8fcc\uadb4\u6791\u581a\u7e67\u68c6\uc2cc\ua34d\u9a46\u1300"
        //   215: invokestatic    invokestatic   !!! ERROR
        //   218: ldc_w           "\u3cd5\ub24c\u8fd0\uada5\u67bc\u5818\u7e45\u68c7\uc283\ua374\u9a47\u130a\uc0b2\u7124\u907a\u4c11\ub201\u4d1f\u0155\u0785\u1301\ufeca\u6b43\u884d\u3692\u3c8e\u7fbb\ua8a7\ud1e1\u728c\u45db"
        //   221: invokestatic    invokestatic   !!! ERROR
        //   224: iconst_0       
        //   225: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   228: checkcast       Ldev/nuker/pyro/f0w;
        //   231: getstatic       dev/nuker/pyro/fc.c:I
        //   234: ifne            243
        //   237: ldc_w           -2079667278
        //   240: goto            246
        //   243: ldc_w           -1365990536
        //   246: ldc_w           1983654339
        //   249: ixor           
        //   250: lookupswitch {
        //          -660043077: 276
        //          -231284111: 243
        //          default: 604
        //        }
        //   276: invokevirtual   dev/nuker/pyro/f9A.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   279: checkcast       Ldev/nuker/pyro/f0k;
        //   282: putfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/f0k;
        //   285: aload_0        
        //   286: aload_0        
        //   287: new             Ldev/nuker/pyro/f0k;
        //   290: dup            
        //   291: ldc_w           "\u3ce4\ub256\u8fc6\uad90\u67b7\u5819\u7e45\u68c6"
        //   294: invokestatic    invokestatic   !!! ERROR
        //   297: ldc_w           "\u3cc4\ub256\u8fc6\uad90\u67b7\u5819\u7e45\u68c6"
        //   300: getstatic       dev/nuker/pyro/fc.0:I
        //   303: ifgt            312
        //   306: ldc_w           1455364033
        //   309: goto            315
        //   312: ldc_w           -668549339
        //   315: ldc_w           824858802
        //   318: ixor           
        //   319: lookupswitch {
        //          -2146926662: 312
        //          1737838451: 612
        //          default: 344
        //        }
        //   344: invokestatic    invokestatic   !!! ERROR
        //   347: aconst_null    
        //   348: iconst_0       
        //   349: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   352: checkcast       Ldev/nuker/pyro/f0w;
        //   355: invokevirtual   dev/nuker/pyro/f9A.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   358: checkcast       Ldev/nuker/pyro/f0k;
        //   361: putfield        dev/nuker/pyro/f9A.0:Ldev/nuker/pyro/f0k;
        //   364: aload_0        
        //   365: getstatic       dev/nuker/pyro/fc.0:I
        //   368: ifgt            377
        //   371: ldc_w           -1057021510
        //   374: goto            380
        //   377: ldc_w           -1206472819
        //   380: ldc_w           836584967
        //   383: ixor           
        //   384: lookupswitch {
        //          -249403459: 602
        //          689566509: 377
        //          default: 412
        //        }
        //   412: aload_0        
        //   413: new             Ldev/nuker/pyro/f0k;
        //   416: dup            
        //   417: ldc_w           "\u3ce4\ub256\u8fc6\uad87\u67ac\u580d\u7e53\u68c0\uc2c2\ua354"
        //   420: invokestatic    invokestatic   !!! ERROR
        //   423: ldc_w           "\u3cc4\ub256\u8fc6\uad87\u67ac\u580d\u7e53\u68c0\uc2c2\ua354"
        //   426: invokestatic    invokestatic   !!! ERROR
        //   429: ldc_w           "\u3cd0\ub251\u8fd7\uada1\u67b3\u5804\u7e54\u68c7\uc283\ua34c\u9a47\u1344\uc0a5\u7102\u906e\u4c1f\ub214\u4d1f\u0143\u0783\u1300\ufe84\u6b01\u8846\u3698\u3c9a\u7ff0\ua8eb\ud1e1\u72c2\u45dc\u6bbc\u75dc\u976b\uc771\u4292\ufde0\u1105\u1855\u4a03\u67f6\uac1b\u8cfa\uf933\ubc15\ua58d\u4c23\u3ecb\u4a62\ua2d2\u79e8\u9171\u3291\u6fc4\uf671\u0f0a\u7a49\u0b60\u9f34\ud332\ue623\u4c6f\u4999\u1685\u3142\u502c\u7995\ue62e\u5fea\u8b68\uea27\u1dd7\uf325"
        //   432: getstatic       dev/nuker/pyro/fc.0:I
        //   435: ifgt            444
        //   438: ldc_w           1636411162
        //   441: goto            447
        //   444: ldc_w           1047319610
        //   447: ldc_w           918507166
        //   450: ixor           
        //   451: lookupswitch {
        //          -284506204: 444
        //          1463216516: 616
        //          default: 476
        //        }
        //   476: invokestatic    invokestatic   !!! ERROR
        //   479: iconst_0       
        //   480: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   483: checkcast       Ldev/nuker/pyro/f0w;
        //   486: invokevirtual   dev/nuker/pyro/f9A.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   489: checkcast       Ldev/nuker/pyro/f0k;
        //   492: getstatic       dev/nuker/pyro/fc.0:I
        //   495: ifgt            504
        //   498: ldc_w           686349251
        //   501: goto            507
        //   504: ldc_w           -1031101911
        //   507: ldc_w           813259144
        //   510: ixor           
        //   511: lookupswitch {
        //          -218891359: 536
        //          412189259: 504
        //          default: 608
        //        }
        //   536: putfield        dev/nuker/pyro/f9A.1:Ldev/nuker/pyro/f0k;
        //   539: aload_0        
        //   540: getstatic       dev/nuker/pyro/fc.c:I
        //   543: ifne            552
        //   546: ldc_w           -1728069100
        //   549: goto            555
        //   552: ldc_w           -1861186162
        //   555: ldc_w           -1256755342
        //   558: ixor           
        //   559: lookupswitch {
        //          -1676014614: 552
        //          770223462: 606
        //          default: 584
        //        }
        //   584: getfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/f0o;
        //   587: new             Ldev/nuker/pyro/f9v;
        //   590: dup            
        //   591: aload_0        
        //   592: invokespecial   dev/nuker/pyro/f9v.<init>:(Ldev/nuker/pyro/f9A;)V
        //   595: checkcast       Ljava/util/function/Consumer;
        //   598: invokevirtual   dev/nuker/pyro/f0o.c:(Ljava/util/function/Consumer;)V
        //   601: return         
        //   602: aconst_null    
        //   603: athrow         
        //   604: aconst_null    
        //   605: athrow         
        //   606: aconst_null    
        //   607: athrow         
        //   608: aconst_null    
        //   609: athrow         
        //   610: aconst_null    
        //   611: athrow         
        //   612: aconst_null    
        //   613: athrow         
        //   614: aconst_null    
        //   615: athrow         
        //   616: aconst_null    
        //   617: athrow         
        //    StackMapTable: 00 20 FF 00 16 00 01 06 00 03 06 07 03 2D 07 03 2D FF 00 02 00 01 06 00 04 06 07 03 2D 07 03 2D 01 FF 00 1E 00 01 06 00 03 06 07 03 2D 07 03 2D FF 00 48 00 01 07 00 03 00 05 07 00 03 07 00 03 08 00 6E 08 00 6E 07 03 2D FF 00 02 00 01 07 00 03 00 06 07 00 03 07 00 03 08 00 6E 08 00 6E 07 03 2D 01 FF 00 1F 00 01 07 00 03 00 05 07 00 03 07 00 03 08 00 6E 08 00 6E 07 03 2D FF 00 4E 00 01 07 00 03 00 03 07 00 03 07 00 03 07 02 E7 FF 00 02 00 01 07 00 03 00 04 07 00 03 07 00 03 07 02 E7 01 FF 00 1D 00 01 07 00 03 00 03 07 00 03 07 00 03 07 02 E7 FF 00 23 00 01 07 00 03 00 06 07 00 03 07 00 03 08 01 1F 08 01 1F 07 03 2D 07 03 2D FF 00 02 00 01 07 00 03 00 07 07 00 03 07 00 03 08 01 1F 08 01 1F 07 03 2D 07 03 2D 01 FF 00 1C 00 01 07 00 03 00 06 07 00 03 07 00 03 08 01 1F 08 01 1F 07 03 2D 07 03 2D 60 07 00 03 FF 00 02 00 01 07 00 03 00 02 07 00 03 01 5F 07 00 03 FF 00 1F 00 01 07 00 03 00 07 07 00 03 07 00 03 08 01 9D 08 01 9D 07 03 2D 07 03 2D 07 03 2D FF 00 02 00 01 07 00 03 00 08 07 00 03 07 00 03 08 01 9D 08 01 9D 07 03 2D 07 03 2D 07 03 2D 01 FF 00 1C 00 01 07 00 03 00 07 07 00 03 07 00 03 08 01 9D 08 01 9D 07 03 2D 07 03 2D 07 03 2D FF 00 1B 00 01 07 00 03 00 02 07 00 03 07 00 64 FF 00 02 00 01 07 00 03 00 03 07 00 03 07 00 64 01 FF 00 1C 00 01 07 00 03 00 02 07 00 03 07 00 64 4F 07 00 03 FF 00 02 00 01 07 00 03 00 02 07 00 03 01 5C 07 00 03 51 07 00 03 FF 00 01 00 01 07 00 03 00 03 07 00 03 07 00 03 07 02 E7 41 07 00 03 FF 00 01 00 01 07 00 03 00 02 07 00 03 07 00 64 FF 00 01 00 01 07 00 03 00 05 07 00 03 07 00 03 08 00 6E 08 00 6E 07 03 2D FF 00 01 00 01 07 00 03 00 06 07 00 03 07 00 03 08 01 1F 08 01 1F 07 03 2D 07 03 2D FF 00 01 00 01 06 00 03 06 07 03 2D 07 03 2D FF 00 01 00 01 07 00 03 00 07 07 00 03 07 00 03 08 01 9D 08 01 9D 07 03 2D 07 03 2D 07 03 2D
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void c(final boolean b) {
        fez.3a(this, 1779782278, b);
    }
    
    public boolean 5() {
        return fez.gZ(this, 492040774);
    }
    
    public void 0(final boolean b) {
        fez.3l(this, 432805440, b);
    }
    
    @Nullable
    public f6n 0() {
        return fez.01(this, 1397713202);
    }
    
    @Override
    public void c(final boolean p0, @Nullable final EntityPlayerSP p1, @Nullable final World p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          856
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            848
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            840
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_0        
        //    25: iload_1        
        //    26: aload_2        
        //    27: getstatic       dev/nuker/pyro/fc.c:I
        //    30: ifne            39
        //    33: ldc_w           1377979418
        //    36: goto            42
        //    39: ldc_w           1151508092
        //    42: ldc_w           -671238555
        //    45: ixor           
        //    46: lookupswitch {
        //          -2048918913: 813
        //          1498026548: 39
        //          default: 72
        //        }
        //    72: aload_3        
        //    73: goto            77
        //    76: athrow         
        //    77: invokespecial   dev/nuker/pyro/fQ.c:(ZLnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/world/World;)V
        //    80: goto            84
        //    83: athrow         
        //    84: aload_0        
        //    85: iconst_0       
        //    86: getstatic       dev/nuker/pyro/fc.1:I
        //    89: ifne            98
        //    92: ldc_w           1102347162
        //    95: goto            101
        //    98: ldc_w           1182516724
        //   101: ldc_w           -1131399872
        //   104: ixor           
        //   105: lookupswitch {
        //          -47952166: 825
        //          1554143395: 98
        //          default: 132
        //        }
        //   132: putfield        dev/nuker/pyro/f9A.c:Z
        //   135: aload_0        
        //   136: iconst_0       
        //   137: putfield        dev/nuker/pyro/f9A.0:Z
        //   140: aload_0        
        //   141: goto            145
        //   144: athrow         
        //   145: invokevirtual   dev/nuker/pyro/f9A.2:()V
        //   148: goto            152
        //   151: athrow         
        //   152: getstatic       dev/nuker/pyro/f0b.c:Ldev/nuker/pyro/f0b;
        //   155: ldc_w           "\u3cfd\ub24a\u8fcd\uafb2\u6185\u5801\u7e4d\u68c4"
        //   158: goto            162
        //   161: athrow         
        //   162: invokestatic    invokestatic   !!! ERROR
        //   165: goto            169
        //   168: athrow         
        //   169: goto            173
        //   172: athrow         
        //   173: invokevirtual   dev/nuker/pyro/f0b.1:(Ljava/lang/String;)V
        //   176: goto            180
        //   179: athrow         
        //   180: aload_0        
        //   181: aconst_null    
        //   182: checkcast       Ldev/nuker/pyro/f6n;
        //   185: putfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/f6n;
        //   188: aload_0        
        //   189: iconst_0       
        //   190: putfield        dev/nuker/pyro/f9A.1:Z
        //   193: iload_1        
        //   194: ifeq            812
        //   197: aload_0        
        //   198: getfield        dev/nuker/pyro/f9A.1:Ldev/nuker/pyro/f0k;
        //   201: goto            205
        //   204: athrow         
        //   205: invokevirtual   dev/nuker/pyro/f0k.c:()Ljava/lang/Object;
        //   208: goto            212
        //   211: athrow         
        //   212: checkcast       Ljava/lang/Boolean;
        //   215: getstatic       dev/nuker/pyro/fc.c:I
        //   218: ifne            227
        //   221: ldc_w           98770488
        //   224: goto            230
        //   227: ldc_w           -351634129
        //   230: ldc_w           213476262
        //   233: ixor           
        //   234: lookupswitch {
        //          -407691639: 260
        //          156925342: 227
        //          default: 821
        //        }
        //   260: goto            264
        //   263: athrow         
        //   264: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   267: goto            271
        //   270: athrow         
        //   271: ifeq            280
        //   274: ldc_w           -682489866
        //   277: goto            283
        //   280: ldc_w           -682489865
        //   283: ldc_w           -550901272
        //   286: ixor           
        //   287: tableswitch {
        //          284679228: 308
        //          284679229: 812
        //          default: 274
        //        }
        //   308: getstatic       dev/nuker/pyro/f64.c:Ldev/nuker/pyro/f6t;
        //   311: goto            315
        //   314: athrow         
        //   315: invokevirtual   dev/nuker/pyro/f6t.i:()Ljava/util/ArrayList;
        //   318: goto            322
        //   321: athrow         
        //   322: astore          4
        //   324: ldc_w           30.0
        //   327: fstore          5
        //   329: getstatic       dev/nuker/pyro/fc.c:I
        //   332: ifne            341
        //   335: ldc_w           1996006553
        //   338: goto            344
        //   341: ldc_w           -1433676487
        //   344: ldc_w           -1031618880
        //   347: ixor           
        //   348: lookupswitch {
        //          -1267066279: 827
        //          -525678106: 341
        //          default: 376
        //        }
        //   376: aload           4
        //   378: goto            382
        //   381: athrow         
        //   382: invokevirtual   java/util/ArrayList.iterator:()Ljava/util/Iterator;
        //   385: goto            389
        //   388: athrow         
        //   389: astore          7
        //   391: aload           7
        //   393: getstatic       dev/nuker/pyro/fc.c:I
        //   396: ifne            405
        //   399: ldc_w           -1448055067
        //   402: goto            408
        //   405: ldc_w           -1862127130
        //   408: ldc_w           1614162703
        //   411: ixor           
        //   412: lookupswitch {
        //          -913947158: 405
        //          -248243479: 440
        //          default: 815
        //        }
        //   440: goto            444
        //   443: athrow         
        //   444: invokeinterface java/util/Iterator.hasNext:()Z
        //   449: goto            453
        //   452: athrow         
        //   453: ifeq            462
        //   456: ldc_w           371661222
        //   459: goto            465
        //   462: ldc_w           371661217
        //   465: ldc_w           -895161963
        //   468: ixor           
        //   469: tableswitch {
        //          -1190666138: 492
        //          -1190666137: 733
        //          default: 456
        //        }
        //   492: aload           7
        //   494: goto            498
        //   497: athrow         
        //   498: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   503: goto            507
        //   506: athrow         
        //   507: checkcast       Ldev/nuker/pyro/f6n;
        //   510: astore          6
        //   512: aload_0        
        //   513: getfield        dev/nuker/pyro/f9A.c:Lnet/minecraft/client/Minecraft;
        //   516: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   519: aload           6
        //   521: checkcast       Lnet/minecraft/util/math/BlockPos;
        //   524: getstatic       dev/nuker/pyro/fc.c:I
        //   527: ifne            536
        //   530: ldc_w           1571968498
        //   533: goto            539
        //   536: ldc_w           184809312
        //   539: ldc_w           -2007249701
        //   542: ixor           
        //   543: lookupswitch {
        //          -2091369541: 568
        //          -706111191: 536
        //          default: 819
        //        }
        //   568: goto            572
        //   571: athrow         
        //   572: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_174818_b:(Lnet/minecraft/util/math/BlockPos;)D
        //   575: goto            579
        //   578: athrow         
        //   579: dstore          8
        //   581: dload           8
        //   583: bipush          10
        //   585: i2d            
        //   586: dcmpl          
        //   587: ifle            593
        //   590: goto            730
        //   593: aload           6
        //   595: checkcast       Lnet/minecraft/util/math/BlockPos;
        //   598: aload_0        
        //   599: getfield        dev/nuker/pyro/f9A.c:Lnet/minecraft/client/Minecraft;
        //   602: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   605: checkcast       Lnet/minecraft/entity/EntityLivingBase;
        //   608: getstatic       dev/nuker/pyro/fc.c:I
        //   611: ifne            620
        //   614: ldc_w           -32449639
        //   617: goto            623
        //   620: ldc_w           1139727446
        //   623: ldc_w           -703905582
        //   626: ixor           
        //   627: lookupswitch {
        //          -1780114300: 652
        //          672897867: 620
        //          default: 823
        //        }
        //   652: goto            656
        //   655: athrow         
        //   656: invokestatic    dev/nuker/pyro/fdM.0:(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/entity/EntityLivingBase;)F
        //   659: goto            663
        //   662: athrow         
        //   663: fstore          10
        //   665: getstatic       dev/nuker/pyro/fc.1:I
        //   668: ifne            677
        //   671: ldc_w           -133137446
        //   674: goto            680
        //   677: ldc_w           -1690130515
        //   680: ldc_w           766715638
        //   683: ixor           
        //   684: lookupswitch {
        //          -1225686693: 712
        //          -710714068: 677
        //          default: 817
        //        }
        //   712: fload           10
        //   714: fload           5
        //   716: fcmpg          
        //   717: ifge            730
        //   720: fload           10
        //   722: fstore          5
        //   724: aload_0        
        //   725: aload           6
        //   727: putfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/f6n;
        //   730: goto            391
        //   733: aload_0        
        //   734: getfield        dev/nuker/pyro/f9A.c:Ldev/nuker/pyro/f6n;
        //   737: ifnonnull       812
        //   740: getstatic       dev/nuker/pyro/fc.c:I
        //   743: ifne            752
        //   746: ldc_w           577310515
        //   749: goto            755
        //   752: ldc_w           -2061259827
        //   755: ldc_w           -1110343018
        //   758: ixor           
        //   759: lookupswitch {
        //          -1615295067: 752
        //          955394395: 784
        //          default: 829
        //        }
        //   784: getstatic       dev/nuker/pyro/Pyro.INSTANCE:Ldev/nuker/pyro/Pyro;
        //   787: ldc_w           "\u3cdf\ub24a\u8f83\uafa6\u619a\u581d\u7e54\u68d5\uc0d0\ua565\u9a4d\u1344\uc0a5\u7313\u965f\u4c1f\ub214\u4d1f\u0347\u01b3\u1344\ufec7\u6b11\u8a5c\u30bf\u3c8f\u7ffa\ua8a7\ud3b1\u74b2\u45cb"
        //   790: goto            794
        //   793: athrow         
        //   794: invokestatic    invokestatic   !!! ERROR
        //   797: goto            801
        //   800: athrow         
        //   801: goto            805
        //   804: athrow         
        //   805: invokevirtual   dev/nuker/pyro/Pyro.sendMessage:(Ljava/lang/String;)V
        //   808: goto            812
        //   811: athrow         
        //   812: return         
        //   813: aconst_null    
        //   814: athrow         
        //   815: aconst_null    
        //   816: athrow         
        //   817: aconst_null    
        //   818: athrow         
        //   819: aconst_null    
        //   820: athrow         
        //   821: aconst_null    
        //   822: athrow         
        //   823: aconst_null    
        //   824: athrow         
        //   825: aconst_null    
        //   826: athrow         
        //   827: aconst_null    
        //   828: athrow         
        //   829: aconst_null    
        //   830: athrow         
        //   831: pop            
        //   832: goto            24
        //   835: pop            
        //   836: aconst_null    
        //   837: goto            831
        //   840: dup            
        //   841: ifnull          831
        //   844: checkcast       Ljava/lang/Throwable;
        //   847: athrow         
        //   848: dup            
        //   849: ifnull          835
        //   852: checkcast       Ljava/lang/Throwable;
        //   855: athrow         
        //   856: aconst_null    
        //   857: athrow         
        //    StackMapTable: 00 71 43 07 00 49 04 FF 00 0B 00 00 00 01 07 00 49 FF 00 03 00 04 07 00 03 01 07 00 9D 07 03 9A 00 00 FF 00 0E 00 04 07 00 03 01 07 00 9D 07 03 9A 00 03 07 00 03 01 07 00 9D FF 00 02 00 04 07 00 03 01 07 00 9D 07 03 9A 00 04 07 00 03 01 07 00 9D 01 FF 00 1D 00 04 07 00 03 01 07 00 9D 07 03 9A 00 03 07 00 03 01 07 00 9D FF 00 03 00 00 00 01 07 00 49 FF 00 00 00 04 07 00 03 01 07 00 9D 07 03 9A 00 04 07 00 03 01 07 00 9D 07 03 9A 45 07 00 49 00 FF 00 0D 00 04 07 00 03 01 07 00 9D 07 03 9A 00 02 07 00 03 01 FF 00 02 00 04 07 00 03 01 07 00 9D 07 03 9A 00 03 07 00 03 01 01 FF 00 1E 00 04 07 00 03 01 07 00 9D 07 03 9A 00 02 07 00 03 01 4B 07 00 49 40 07 00 03 45 07 00 49 00 48 07 00 2E FF 00 00 00 04 07 00 03 01 07 00 9D 07 03 9A 00 02 07 03 52 07 03 2D 45 07 00 49 FF 00 00 00 04 07 00 03 01 07 00 9D 07 03 9A 00 02 07 03 52 07 03 2D FF 00 02 00 00 00 01 07 00 49 FF 00 00 00 04 07 00 03 01 07 00 9D 07 03 9A 00 02 07 03 52 07 03 2D 45 07 00 49 00 57 07 00 2C 40 07 00 64 45 07 00 49 40 07 02 56 4E 07 00 69 FF 00 02 00 04 07 00 03 01 07 00 9D 07 03 9A 00 02 07 00 69 01 5D 07 00 69 42 07 00 49 40 07 00 69 45 07 00 49 40 01 02 05 42 01 18 45 07 00 49 40 07 03 65 45 07 00 49 40 07 03 6F FD 00 12 07 03 6F 02 42 01 1F 44 07 00 49 40 07 03 6F 45 07 00 49 40 07 01 F1 FD 00 01 00 07 01 F1 4D 07 01 F1 FF 00 02 00 08 07 00 03 01 07 00 9D 07 03 9A 07 03 6F 02 00 07 01 F1 00 02 07 01 F1 01 5F 07 01 F1 42 07 00 2E 40 07 01 F1 47 07 00 49 40 01 02 05 42 01 1A 44 07 00 49 40 07 01 F1 47 07 00 49 40 07 02 56 FF 00 1C 00 08 07 00 03 01 07 00 9D 07 03 9A 07 03 6F 02 07 00 BD 07 01 F1 00 02 07 00 9D 07 00 FD FF 00 02 00 08 07 00 03 01 07 00 9D 07 03 9A 07 03 6F 02 07 00 BD 07 01 F1 00 03 07 00 9D 07 00 FD 01 FF 00 1C 00 08 07 00 03 01 07 00 9D 07 03 9A 07 03 6F 02 07 00 BD 07 01 F1 00 02 07 00 9D 07 00 FD FF 00 02 00 00 00 01 07 00 49 FF 00 00 00 08 07 00 03 01 07 00 9D 07 03 9A 07 03 6F 02 07 00 BD 07 01 F1 00 02 07 00 9D 07 00 FD 45 07 00 49 40 03 FC 00 0D 03 FF 00 1A 00 09 07 00 03 01 07 00 9D 07 03 9A 07 03 6F 02 07 00 BD 07 01 F1 03 00 02 07 00 FD 07 03 7F FF 00 02 00 09 07 00 03 01 07 00 9D 07 03 9A 07 03 6F 02 07 00 BD 07 01 F1 03 00 03 07 00 FD 07 03 7F 01 FF 00 1C 00 09 07 00 03 01 07 00 9D 07 03 9A 07 03 6F 02 07 00 BD 07 01 F1 03 00 02 07 00 FD 07 03 7F 42 07 00 49 FF 00 00 00 09 07 00 03 01 07 00 9D 07 03 9A 07 03 6F 02 07 00 BD 07 01 F1 03 00 02 07 00 FD 07 03 7F 45 07 00 49 40 02 FC 00 0D 02 42 01 1F FA 00 11 FF 00 02 00 08 07 00 03 01 07 00 9D 07 03 9A 07 03 6F 02 00 07 01 F1 00 00 12 42 01 1C 48 07 00 49 FF 00 00 00 08 07 00 03 01 07 00 9D 07 03 9A 07 03 6F 02 00 07 01 F1 00 02 07 03 8F 07 03 2D 45 07 00 49 FF 00 00 00 08 07 00 03 01 07 00 9D 07 03 9A 07 03 6F 02 00 07 01 F1 00 02 07 03 8F 07 03 2D FF 00 02 00 00 00 01 07 00 49 FF 00 00 00 08 07 00 03 01 07 00 9D 07 03 9A 07 03 6F 02 00 07 01 F1 00 02 07 03 8F 07 03 2D 45 07 00 49 FF 00 00 00 04 07 00 03 01 07 00 9D 07 03 9A 00 00 FF 00 00 00 04 07 00 03 01 07 00 9D 07 03 9A 00 03 07 00 03 01 07 00 9D FF 00 01 00 08 07 00 03 01 07 00 9D 07 03 9A 07 03 6F 02 00 07 01 F1 00 01 07 01 F1 FF 00 01 00 0A 07 00 03 01 07 00 9D 07 03 9A 07 03 6F 02 07 00 BD 07 01 F1 03 02 00 00 FF 00 01 00 08 07 00 03 01 07 00 9D 07 03 9A 07 03 6F 02 07 00 BD 07 01 F1 00 02 07 00 9D 07 00 FD FF 00 01 00 04 07 00 03 01 07 00 9D 07 03 9A 00 01 07 00 69 FF 00 01 00 09 07 00 03 01 07 00 9D 07 03 9A 07 03 6F 02 07 00 BD 07 01 F1 03 00 02 07 00 FD 07 03 7F FF 00 01 00 04 07 00 03 01 07 00 9D 07 03 9A 00 02 07 00 03 01 FD 00 01 07 03 6F 02 FD 00 01 00 07 01 F1 FF 00 01 00 04 07 00 03 01 07 00 9D 07 03 9A 00 01 07 00 49 43 05 44 07 00 49 47 05 47 07 00 49
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     840    848    Ljava/util/ConcurrentModificationException;
        //  840    848    840    848    Any
        //  856    858    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  77     83     83     84     Any
        //  77     83     3      8      Any
        //  77     83     3      8      Ljava/util/ConcurrentModificationException;
        //  77     83     3      8      Ljava/lang/IllegalArgumentException;
        //  77     83     3      8      Any
        //  144    151    151    152    Any
        //  145    151    144    145    Ljava/lang/RuntimeException;
        //  145    151    144    145    Ljava/lang/AssertionError;
        //  145    151    144    145    Any
        //  144    151    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  161    168    168    169    Any
        //  162    168    3      8      Ljava/util/ConcurrentModificationException;
        //  161    168    168    169    Any
        //  162    168    3      8      Any
        //  161    168    161    162    Ljava/lang/NegativeArraySizeException;
        //  173    179    179    180    Any
        //  173    179    3      8      Any
        //  173    179    3      8      Ljava/lang/IllegalStateException;
        //  173    179    179    180    Any
        //  173    179    179    180    Any
        //  204    211    211    212    Any
        //  204    211    3      8      Any
        //  204    211    204    205    Ljava/lang/AssertionError;
        //  205    211    3      8      Any
        //  204    211    211    212    Ljava/lang/ClassCastException;
        //  263    270    270    271    Any
        //  263    270    263    264    Ljava/lang/NumberFormatException;
        //  264    270    3      8      Ljava/lang/IllegalArgumentException;
        //  263    270    263    264    Any
        //  263    270    263    264    Any
        //  314    321    321    322    Any
        //  315    321    321    322    Any
        //  315    321    314    315    Any
        //  315    321    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  315    321    314    315    Any
        //  381    388    388    389    Any
        //  382    388    381    382    Any
        //  381    388    3      8      Ljava/lang/IllegalStateException;
        //  382    388    381    382    Any
        //  381    388    381    382    Any
        //  443    452    452    453    Any
        //  444    452    3      8      Ljava/lang/ClassCastException;
        //  443    452    452    453    Ljava/lang/IllegalStateException;
        //  444    452    452    453    Ljava/lang/IndexOutOfBoundsException;
        //  443    452    443    444    Ljava/lang/NegativeArraySizeException;
        //  497    506    506    507    Any
        //  498    506    497    498    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  497    506    497    498    Ljava/lang/StringIndexOutOfBoundsException;
        //  498    506    497    498    Any
        //  498    506    497    498    Any
        //  572    578    578    579    Any
        //  572    578    3      8      Any
        //  572    578    578    579    Ljava/lang/ArithmeticException;
        //  572    578    3      8      Ljava/lang/ArithmeticException;
        //  572    578    3      8      Any
        //  655    662    662    663    Any
        //  656    662    655    656    Any
        //  656    662    662    663    Any
        //  656    662    655    656    Any
        //  655    662    662    663    Any
        //  793    800    800    801    Any
        //  794    800    3      8      Any
        //  794    800    793    794    Ljava/lang/ArithmeticException;
        //  793    800    793    794    Any
        //  793    800    793    794    Any
        //  805    811    811    812    Any
        //  805    811    811    812    Any
        //  805    811    3      8      Any
        //  805    811    811    812    Ljava/lang/IllegalArgumentException;
        //  805    811    3      8      Ljava/lang/ClassCastException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visitVariable(StackMappingVisitor.java:470)
        //     at com.strobel.assembler.ir.Instruction.accept(Instruction.java:556)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:403)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void 1(final boolean b) {
        fez.3k(this, 1301484697, b);
    }
    
    public void c(@Nullable final f6n f6n) {
        fez.0r(this, 1264650219, f6n);
    }
}
