// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

public enum fdi
{
    public static fdi c;
    public static fdi 0;
    public static fdi 1;
    public static fdi 2;
    public static fdi[] c;
    
    public static fdi c(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          110
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            102
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            94
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: ldc             Ldev/nuker/pyro/fdi;.class
        //    26: aload_0        
        //    27: getstatic       dev/nuker/pyro/fc.0:I
        //    30: ifgt            38
        //    33: ldc             -870110722
        //    35: goto            40
        //    38: ldc             1742758520
        //    40: ldc             1242673132
        //    42: ixor           
        //    43: lookupswitch {
        //          -2043509230: 38
        //          770821524: 68
        //          default: 83
        //        }
        //    68: goto            72
        //    71: athrow         
        //    72: invokestatic    java/lang/Enum.valueOf:(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
        //    75: goto            79
        //    78: athrow         
        //    79: checkcast       Ldev/nuker/pyro/fdi;
        //    82: areturn        
        //    83: aconst_null    
        //    84: athrow         
        //    85: pop            
        //    86: goto            24
        //    89: pop            
        //    90: aconst_null    
        //    91: goto            85
        //    94: dup            
        //    95: ifnull          85
        //    98: checkcast       Ljava/lang/Throwable;
        //   101: athrow         
        //   102: dup            
        //   103: ifnull          89
        //   106: checkcast       Ljava/lang/Throwable;
        //   109: athrow         
        //   110: aconst_null    
        //   111: athrow         
        //    StackMapTable: 00 11 43 07 00 1D 04 FF 00 0B 00 00 00 01 07 00 1D FC 00 03 07 00 26 FF 00 0D 00 01 07 00 26 00 02 07 00 28 07 00 26 FF 00 01 00 01 07 00 26 00 03 07 00 28 07 00 26 01 FF 00 1B 00 01 07 00 26 00 02 07 00 28 07 00 26 42 07 00 0E FF 00 00 00 01 07 00 26 00 02 07 00 28 07 00 26 45 07 00 1D 40 07 00 05 FF 00 03 00 01 07 00 26 00 02 07 00 28 07 00 26 41 07 00 0E 43 05 44 07 00 0E 47 05 47 07 00 1D
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     94     102    Ljava/lang/RuntimeException;
        //  94     102    94     102    Ljava/lang/EnumConstantNotPresentException;
        //  110    112    3      8      Ljava/util/ConcurrentModificationException;
        //  71     78     78     79     Any
        //  72     78     3      8      Any
        //  72     78     71     72     Ljava/util/NoSuchElementException;
        //  71     78     71     72     Ljava/lang/EnumConstantNotPresentException;
        //  71     78     78     79     Ljava/lang/StringIndexOutOfBoundsException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 44 out of bounds for length 44
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: anewarray       Ldev/nuker/pyro/fdi;
        //     4: dup            
        //     5: dup            
        //     6: iconst_0       
        //     7: new             Ldev/nuker/pyro/fdi;
        //    10: dup            
        //    11: ldc             "\u3702\ub24a\u8474\ua172\u5553\u53c5"
        //    13: invokestatic    invokestatic   !!! ERROR
        //    16: iconst_0       
        //    17: getstatic       dev/nuker/pyro/fc.1:I
        //    20: ifne            28
        //    23: ldc             1974212456
        //    25: goto            30
        //    28: ldc             -658828176
        //    30: ldc             2102385623
        //    32: ixor           
        //    33: lookupswitch {
        //          -1510682713: 60
        //          149146815: 28
        //          default: 266
        //        }
        //    60: invokespecial   dev/nuker/pyro/fdi.<init>:(Ljava/lang/String;I)V
        //    63: dup            
        //    64: putstatic       dev/nuker/pyro/fdi.c:Ldev/nuker/pyro/fdi;
        //    67: aastore        
        //    68: dup            
        //    69: iconst_1       
        //    70: new             Ldev/nuker/pyro/fdi;
        //    73: dup            
        //    74: ldc             "\u3702\ub266\u8456"
        //    76: invokestatic    invokestatic   !!! ERROR
        //    79: iconst_1       
        //    80: invokespecial   dev/nuker/pyro/fdi.<init>:(Ljava/lang/String;I)V
        //    83: dup            
        //    84: getstatic       dev/nuker/pyro/fc.0:I
        //    87: ifgt            95
        //    90: ldc             185797279
        //    92: goto            97
        //    95: ldc             888905881
        //    97: ldc             125775829
        //    99: ixor           
        //   100: lookupswitch {
        //          -438245494: 95
        //          208414026: 268
        //          default: 128
        //        }
        //   128: putstatic       dev/nuker/pyro/fdi.0:Ldev/nuker/pyro/fdi;
        //   131: aastore        
        //   132: dup            
        //   133: iconst_2       
        //   134: new             Ldev/nuker/pyro/fdi;
        //   137: dup            
        //   138: ldc             "\u3704\ub25c\u8476\ua176\u554a\u53cc\u7e4c"
        //   140: invokestatic    invokestatic   !!! ERROR
        //   143: iconst_2       
        //   144: getstatic       dev/nuker/pyro/fc.0:I
        //   147: ifgt            155
        //   150: ldc             1036741079
        //   152: goto            157
        //   155: ldc             -347759185
        //   157: ldc             509103667
        //   159: ixor           
        //   160: lookupswitch {
        //          -182594660: 188
        //          596846564: 155
        //          default: 264
        //        }
        //   188: invokespecial   dev/nuker/pyro/fdi.<init>:(Ljava/lang/String;I)V
        //   191: dup            
        //   192: putstatic       dev/nuker/pyro/fdi.1:Ldev/nuker/pyro/fdi;
        //   195: aastore        
        //   196: dup            
        //   197: iconst_3       
        //   198: new             Ldev/nuker/pyro/fdi;
        //   201: dup            
        //   202: ldc             "\u3705\ub24b\u8475\ua16b\u5553\u53c7\u7e54"
        //   204: invokestatic    invokestatic   !!! ERROR
        //   207: iconst_3       
        //   208: invokespecial   dev/nuker/pyro/fdi.<init>:(Ljava/lang/String;I)V
        //   211: dup            
        //   212: putstatic       dev/nuker/pyro/fdi.2:Ldev/nuker/pyro/fdi;
        //   215: aastore        
        //   216: getstatic       dev/nuker/pyro/fc.1:I
        //   219: ifne            227
        //   222: ldc             -1724008956
        //   224: goto            229
        //   227: ldc             608966836
        //   229: ldc             -272343428
        //   231: ixor           
        //   232: lookupswitch {
        //          -409643225: 227
        //          1996089464: 270
        //          default: 260
        //        }
        //   260: putstatic       dev/nuker/pyro/fdi.c:[Ldev/nuker/pyro/fdi;
        //   263: return         
        //   264: aconst_null    
        //   265: athrow         
        //   266: aconst_null    
        //   267: athrow         
        //   268: aconst_null    
        //   269: athrow         
        //   270: aconst_null    
        //   271: athrow         
        //    StackMapTable: 00 10 FF 00 1C 00 00 00 08 07 00 54 07 00 54 07 00 54 01 08 00 07 08 00 07 07 00 26 01 FF 00 01 00 00 00 09 07 00 54 07 00 54 07 00 54 01 08 00 07 08 00 07 07 00 26 01 01 FF 00 1D 00 00 00 08 07 00 54 07 00 54 07 00 54 01 08 00 07 08 00 07 07 00 26 01 FF 00 22 00 00 00 06 07 00 54 07 00 54 07 00 54 01 07 00 03 07 00 03 FF 00 01 00 00 00 07 07 00 54 07 00 54 07 00 54 01 07 00 03 07 00 03 01 FF 00 1E 00 00 00 06 07 00 54 07 00 54 07 00 54 01 07 00 03 07 00 03 FF 00 1A 00 00 00 08 07 00 54 07 00 54 07 00 54 01 08 00 86 08 00 86 07 00 26 01 FF 00 01 00 00 00 09 07 00 54 07 00 54 07 00 54 01 08 00 86 08 00 86 07 00 26 01 01 FF 00 1E 00 00 00 08 07 00 54 07 00 54 07 00 54 01 08 00 86 08 00 86 07 00 26 01 FF 00 26 00 00 00 02 07 00 54 07 00 54 FF 00 01 00 00 00 03 07 00 54 07 00 54 01 FF 00 1E 00 00 00 02 07 00 54 07 00 54 FF 00 03 00 00 00 08 07 00 54 07 00 54 07 00 54 01 08 00 86 08 00 86 07 00 26 01 FF 00 01 00 00 00 08 07 00 54 07 00 54 07 00 54 01 08 00 07 08 00 07 07 00 26 01 FF 00 01 00 00 00 06 07 00 54 07 00 54 07 00 54 01 07 00 03 07 00 03 FF 00 01 00 00 00 02 07 00 54 07 00 54
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public fdi(final String name, final int ordinal) {
    }
}
