// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import net.minecraft.client.entity.EntityPlayerSP;
import dev.nuker.pyro.security.inject.LauncherEventHide;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.network.Packet;
import java.util.LinkedList;

public class f9a extends fQ
{
    public LinkedList<Packet<?>> c;
    public EntityOtherPlayerMP c;
    
    @f0g
    @LauncherEventHide
    public void c(final f49 f49) {
        fez.3H(this, 411606350, f49);
    }
    
    static {
        throw t;
    }
    
    @Override
    public void c(final boolean p0, @Nullable final EntityPlayerSP p1, @Nullable final World p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          728
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            720
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            712
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_0        
        //    25: getstatic       dev/nuker/pyro/fc.c:I
        //    28: ifne            36
        //    31: ldc             1027961417
        //    33: goto            38
        //    36: ldc             1168660431
        //    38: ldc             -16556017
        //    40: ixor           
        //    41: lookupswitch {
        //          -1273477686: 36
        //          -1035595194: 683
        //          default: 68
        //        }
        //    68: iload_1        
        //    69: aload_2        
        //    70: aload_3        
        //    71: getstatic       dev/nuker/pyro/fc.1:I
        //    74: ifne            82
        //    77: ldc             2029189774
        //    79: goto            84
        //    82: ldc             -328275494
        //    84: ldc             -133411715
        //    86: ixor           
        //    87: lookupswitch {
        //          -2130790669: 687
        //          -1693190308: 82
        //          default: 112
        //        }
        //   112: goto            116
        //   115: athrow         
        //   116: invokespecial   dev/nuker/pyro/fQ.c:(ZLnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/world/World;)V
        //   119: goto            123
        //   122: athrow         
        //   123: iload_1        
        //   124: ifeq            218
        //   127: aload_0        
        //   128: getstatic       dev/nuker/pyro/fc.1:I
        //   131: ifne            139
        //   134: ldc             -1283483811
        //   136: goto            141
        //   139: ldc             755220964
        //   141: ldc             -628403887
        //   143: ixor           
        //   144: lookupswitch {
        //          -1749544143: 139
        //          1777649164: 685
        //          default: 172
        //        }
        //   172: getfield        dev/nuker/pyro/f9a.c:Ljava/util/LinkedList;
        //   175: goto            179
        //   178: athrow         
        //   179: invokevirtual   java/util/LinkedList.clear:()V
        //   182: goto            186
        //   185: athrow         
        //   186: aload_0        
        //   187: getstatic       dev/nuker/pyro/fe4.c:Ldev/nuker/pyro/fe4;
        //   190: aload_0        
        //   191: getfield        dev/nuker/pyro/f9a.c:Lnet/minecraft/client/Minecraft;
        //   194: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   197: sipush          -1337
        //   200: iconst_0       
        //   201: goto            205
        //   204: athrow         
        //   205: invokevirtual   dev/nuker/pyro/fe4.c:(Lnet/minecraft/entity/player/EntityPlayer;IZ)Lnet/minecraft/client/entity/EntityOtherPlayerMP;
        //   208: goto            212
        //   211: athrow         
        //   212: putfield        dev/nuker/pyro/f9a.c:Lnet/minecraft/client/entity/EntityOtherPlayerMP;
        //   215: goto            675
        //   218: aload_0        
        //   219: getstatic       dev/nuker/pyro/fc.1:I
        //   222: ifne            230
        //   225: ldc             -255796386
        //   227: goto            232
        //   230: ldc             779218919
        //   232: ldc             -1581861006
        //   234: ixor           
        //   235: lookupswitch {
        //          336438246: 230
        //          1366715436: 689
        //          default: 260
        //        }
        //   260: getfield        dev/nuker/pyro/f9a.c:Ljava/util/LinkedList;
        //   263: goto            267
        //   266: athrow         
        //   267: invokevirtual   java/util/LinkedList.isEmpty:()Z
        //   270: goto            274
        //   273: athrow         
        //   274: ifne            614
        //   277: aload_0        
        //   278: getfield        dev/nuker/pyro/f9a.c:Lnet/minecraft/client/Minecraft;
        //   281: getstatic       dev/nuker/pyro/fc.1:I
        //   284: ifne            292
        //   287: ldc             892740638
        //   289: goto            294
        //   292: ldc             417953270
        //   294: ldc             -529495091
        //   296: ixor           
        //   297: lookupswitch {
        //          -716787757: 292
        //          -124125637: 324
        //          default: 681
        //        }
        //   324: goto            328
        //   327: athrow         
        //   328: invokevirtual   net/minecraft/client/Minecraft.func_147114_u:()Lnet/minecraft/client/network/NetHandlerPlayClient;
        //   331: goto            335
        //   334: athrow         
        //   335: ifnull          614
        //   338: getstatic       dev/nuker/pyro/fc.0:I
        //   341: ifgt            349
        //   344: ldc             -986285061
        //   346: goto            351
        //   349: ldc             -29202094
        //   351: ldc             885652938
        //   353: ixor           
        //   354: lookupswitch {
        //          -234912207: 695
        //          230663504: 349
        //          default: 380
        //        }
        //   380: aload_0        
        //   381: getstatic       dev/nuker/pyro/fc.c:I
        //   384: ifne            392
        //   387: ldc             1791659888
        //   389: goto            394
        //   392: ldc             -886814642
        //   394: ldc             347725265
        //   396: ixor           
        //   397: lookupswitch {
        //          -543320673: 424
        //          2121487009: 392
        //          default: 693
        //        }
        //   424: getfield        dev/nuker/pyro/f9a.c:Lnet/minecraft/client/Minecraft;
        //   427: goto            431
        //   430: athrow         
        //   431: invokevirtual   net/minecraft/client/Minecraft.func_147114_u:()Lnet/minecraft/client/network/NetHandlerPlayClient;
        //   434: goto            438
        //   437: athrow         
        //   438: aload_0        
        //   439: getstatic       dev/nuker/pyro/fc.0:I
        //   442: ifgt            450
        //   445: ldc             412037328
        //   447: goto            452
        //   450: ldc             1922290020
        //   452: ldc             -464772959
        //   454: ixor           
        //   455: lookupswitch {
        //          -691758562: 450
        //          -54325135: 697
        //          default: 480
        //        }
        //   480: getfield        dev/nuker/pyro/f9a.c:Ljava/util/LinkedList;
        //   483: goto            487
        //   486: athrow         
        //   487: invokevirtual   java/util/LinkedList.getFirst:()Ljava/lang/Object;
        //   490: goto            494
        //   493: athrow         
        //   494: checkcast       Lnet/minecraft/network/Packet;
        //   497: goto            501
        //   500: athrow         
        //   501: invokevirtual   net/minecraft/client/network/NetHandlerPlayClient.func_147297_a:(Lnet/minecraft/network/Packet;)V
        //   504: goto            508
        //   507: athrow         
        //   508: getstatic       dev/nuker/pyro/fc.0:I
        //   511: ifgt            519
        //   514: ldc             -63873499
        //   516: goto            521
        //   519: ldc             -1756062884
        //   521: ldc             399283513
        //   523: ixor           
        //   524: lookupswitch {
        //          -434538865: 519
        //          -335688932: 699
        //          default: 552
        //        }
        //   552: aload_0        
        //   553: getstatic       dev/nuker/pyro/fc.1:I
        //   556: ifne            564
        //   559: ldc             -684909813
        //   561: goto            566
        //   564: ldc             -2037902974
        //   566: ldc             1209976007
        //   568: ixor           
        //   569: lookupswitch {
        //          -1890950578: 564
        //          -1623990324: 691
        //          default: 596
        //        }
        //   596: getfield        dev/nuker/pyro/f9a.c:Ljava/util/LinkedList;
        //   599: goto            603
        //   602: athrow         
        //   603: invokevirtual   java/util/LinkedList.removeFirst:()Ljava/lang/Object;
        //   606: goto            610
        //   609: athrow         
        //   610: pop            
        //   611: goto            218
        //   614: getstatic       dev/nuker/pyro/fe4.c:Ldev/nuker/pyro/fe4;
        //   617: getstatic       dev/nuker/pyro/fc.0:I
        //   620: ifgt            628
        //   623: ldc             1364799406
        //   625: goto            630
        //   628: ldc             1588031715
        //   630: ldc             807575172
        //   632: ixor           
        //   633: lookupswitch {
        //          -2085556978: 628
        //          1635496234: 701
        //          default: 660
        //        }
        //   660: aload_0        
        //   661: getfield        dev/nuker/pyro/f9a.c:Lnet/minecraft/client/entity/EntityOtherPlayerMP;
        //   664: goto            668
        //   667: athrow         
        //   668: invokevirtual   dev/nuker/pyro/fe4.c:(Lnet/minecraft/client/entity/EntityOtherPlayerMP;)V
        //   671: goto            675
        //   674: athrow         
        //   675: goto            680
        //   678: astore          4
        //   680: return         
        //   681: aconst_null    
        //   682: athrow         
        //   683: aconst_null    
        //   684: athrow         
        //   685: aconst_null    
        //   686: athrow         
        //   687: aconst_null    
        //   688: athrow         
        //   689: aconst_null    
        //   690: athrow         
        //   691: aconst_null    
        //   692: athrow         
        //   693: aconst_null    
        //   694: athrow         
        //   695: aconst_null    
        //   696: athrow         
        //   697: aconst_null    
        //   698: athrow         
        //   699: aconst_null    
        //   700: athrow         
        //   701: aconst_null    
        //   702: athrow         
        //   703: pop            
        //   704: goto            24
        //   707: pop            
        //   708: aconst_null    
        //   709: goto            703
        //   712: dup            
        //   713: ifnull          703
        //   716: checkcast       Ljava/lang/Throwable;
        //   719: athrow         
        //   720: dup            
        //   721: ifnull          707
        //   724: checkcast       Ljava/lang/Throwable;
        //   727: athrow         
        //   728: aconst_null    
        //   729: athrow         
        //    RuntimeInvisibleTypeAnnotations: 00 02 16 01 00 00 17 00 00 16 02 00 00 17 00 00
        //    StackMapTable: 00 61 43 07 00 37 04 FF 00 0B 00 00 00 01 07 00 37 FF 00 03 00 04 07 00 03 01 07 00 96 07 00 98 00 00 4B 07 00 03 FF 00 01 00 04 07 00 03 01 07 00 96 07 00 98 00 02 07 00 03 01 5D 07 00 03 FF 00 0D 00 04 07 00 03 01 07 00 96 07 00 98 00 04 07 00 03 01 07 00 96 07 00 98 FF 00 01 00 04 07 00 03 01 07 00 96 07 00 98 00 05 07 00 03 01 07 00 96 07 00 98 01 FF 00 1B 00 04 07 00 03 01 07 00 96 07 00 98 00 04 07 00 03 01 07 00 96 07 00 98 42 07 00 37 FF 00 00 00 04 07 00 03 01 07 00 96 07 00 98 00 04 07 00 03 01 07 00 96 07 00 98 45 07 00 37 00 4F 07 00 03 FF 00 01 00 04 07 00 03 01 07 00 96 07 00 98 00 02 07 00 03 01 5E 07 00 03 45 07 00 37 40 07 00 4B 45 07 00 37 00 51 07 00 37 FF 00 00 00 04 07 00 03 01 07 00 96 07 00 98 00 05 07 00 03 07 00 51 07 00 96 01 01 45 07 00 37 FF 00 00 00 04 07 00 03 01 07 00 96 07 00 98 00 02 07 00 03 07 00 9A 05 4B 07 00 03 FF 00 01 00 04 07 00 03 01 07 00 96 07 00 98 00 02 07 00 03 01 5B 07 00 03 45 07 00 25 40 07 00 4B 45 07 00 37 40 01 51 07 00 59 FF 00 01 00 04 07 00 03 01 07 00 96 07 00 98 00 02 07 00 59 01 5D 07 00 59 42 07 00 37 40 07 00 59 45 07 00 37 40 07 00 81 0D 41 01 1C 4B 07 00 03 FF 00 01 00 04 07 00 03 01 07 00 96 07 00 98 00 02 07 00 03 01 5D 07 00 03 45 07 00 37 40 07 00 59 45 07 00 37 40 07 00 81 FF 00 0B 00 04 07 00 03 01 07 00 96 07 00 98 00 02 07 00 81 07 00 03 FF 00 01 00 04 07 00 03 01 07 00 96 07 00 98 00 03 07 00 81 07 00 03 01 FF 00 1B 00 04 07 00 03 01 07 00 96 07 00 98 00 02 07 00 81 07 00 03 45 07 00 37 FF 00 00 00 04 07 00 03 01 07 00 96 07 00 98 00 02 07 00 81 07 00 4B 45 07 00 37 FF 00 00 00 04 07 00 03 01 07 00 96 07 00 98 00 02 07 00 81 07 00 9C 45 07 00 37 FF 00 00 00 04 07 00 03 01 07 00 96 07 00 98 00 02 07 00 81 07 00 7F 45 07 00 37 00 0A 41 01 1E 4B 07 00 03 FF 00 01 00 04 07 00 03 01 07 00 96 07 00 98 00 02 07 00 03 01 5D 07 00 03 45 07 00 25 40 07 00 4B 45 07 00 37 40 07 00 9C 03 4D 07 00 51 FF 00 01 00 04 07 00 03 01 07 00 96 07 00 98 00 02 07 00 51 01 5D 07 00 51 46 07 00 37 FF 00 00 00 04 07 00 03 01 07 00 96 07 00 98 00 02 07 00 51 07 00 9A 45 07 00 37 00 42 07 00 19 01 40 07 00 59 41 07 00 03 41 07 00 03 FF 00 01 00 04 07 00 03 01 07 00 96 07 00 98 00 04 07 00 03 01 07 00 96 07 00 98 41 07 00 03 41 07 00 03 41 07 00 03 01 FF 00 01 00 04 07 00 03 01 07 00 96 07 00 98 00 02 07 00 81 07 00 03 01 41 07 00 51 41 07 00 37 43 05 44 07 00 37 47 05 47 07 00 37
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  123    675    678    680    Ljava/lang/Exception;
        //  8      20     712    720    Any
        //  712    720    712    720    Any
        //  728    730    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  115    122    122    123    Any
        //  115    122    122    123    Ljava/lang/IndexOutOfBoundsException;
        //  116    122    115    116    Ljava/lang/StringIndexOutOfBoundsException;
        //  115    122    115    116    Any
        //  115    122    115    116    Ljava/lang/ArithmeticException;
        //  178    185    185    186    Any
        //  178    185    3      8      Any
        //  179    185    3      8      Ljava/lang/ClassCastException;
        //  178    185    3      8      Any
        //  179    185    178    179    Any
        //  204    211    211    212    Any
        //  204    211    204    205    Any
        //  204    211    211    212    Any
        //  205    211    204    205    Any
        //  205    211    204    205    Ljava/lang/UnsupportedOperationException;
        //  266    273    273    274    Any
        //  267    273    273    274    Ljava/lang/ArithmeticException;
        //  266    273    273    274    Any
        //  267    273    3      8      Any
        //  267    273    266    267    Ljava/util/ConcurrentModificationException;
        //  327    334    334    335    Any
        //  327    334    3      8      Any
        //  327    334    327    328    Any
        //  327    334    334    335    Any
        //  327    334    3      8      Any
        //  430    437    437    438    Any
        //  431    437    437    438    Any
        //  431    437    437    438    Ljava/lang/NumberFormatException;
        //  431    437    430    431    Ljava/lang/ClassCastException;
        //  430    437    430    431    Any
        //  486    493    493    494    Any
        //  486    493    493    494    Any
        //  486    493    486    487    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  487    493    3      8      Ljava/lang/RuntimeException;
        //  486    493    486    487    Any
        //  500    507    507    508    Any
        //  501    507    3      8      Any
        //  500    507    507    508    Ljava/util/NoSuchElementException;
        //  500    507    3      8      Ljava/lang/NumberFormatException;
        //  501    507    500    501    Any
        //  602    609    609    610    Any
        //  603    609    602    603    Ljava/util/ConcurrentModificationException;
        //  603    609    3      8      Ljava/lang/NegativeArraySizeException;
        //  602    609    3      8      Any
        //  602    609    3      8      Any
        //  667    674    674    675    Any
        //  668    674    667    668    Any
        //  668    674    674    675    Any
        //  668    674    3      8      Any
        //  667    674    667    668    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:577)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public f9a() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: ldc             "\u3cd3\ub249\u8faa\uadaa\u67d5"
        //     3: invokestatic    invokestatic   !!! ERROR
        //     6: ldc             "\u3cf3\ub249\u8faa\uadaa\u67d5"
        //     8: getstatic       dev/nuker/pyro/fc.0:I
        //    11: ifgt            19
        //    14: ldc             63280137
        //    16: goto            21
        //    19: ldc             -1834734848
        //    21: ldc             -1843687336
        //    23: ixor           
        //    24: lookupswitch {
        //          -1847720879: 19
        //          12565336: 52
        //          default: 75
        //        }
        //    52: invokestatic    invokestatic   !!! ERROR
        //    55: ldc             "\u3cf9\ub24a\u8faf\uada0\u67cd\u5874\u7e4d\u68bb\uc2d5\ua33d\u9a65\u1301\uc0db\u711a\u904f\u4c2c\ub210\u4d3c\u0149\u07e8\u1330\ufed7\u6b23\u8855\u36f1\u3cb7\u7ff4\ua8dc\ud1e9\u72ec\u45f8\u6bee\u75bc\u9777\uc710\u42f3\ufdf8\u112a\u1806\u4a78\u6793\uac0e\u8c90\uf936\ubc3a\ua5bc\u4c36"
        //    57: invokestatic    invokestatic   !!! ERROR
        //    60: invokespecial   dev/nuker/pyro/fQ.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //    63: aload_0        
        //    64: new             Ljava/util/LinkedList;
        //    67: dup            
        //    68: invokespecial   java/util/LinkedList.<init>:()V
        //    71: putfield        dev/nuker/pyro/f9a.c:Ljava/util/LinkedList;
        //    74: return         
        //    75: aconst_null    
        //    76: athrow         
        //    StackMapTable: 00 04 FF 00 13 00 01 06 00 03 06 07 00 B2 07 00 B2 FF 00 01 00 01 06 00 04 06 07 00 B2 07 00 B2 01 FF 00 1E 00 01 06 00 03 06 07 00 B2 07 00 B2 FF 00 16 00 01 06 00 03 06 07 00 B2 07 00 B2
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @f0g
    @LauncherEventHide
    public void c(final f4J f4J) {
        fez.ir(this, 1384961553, f4J);
    }
}
