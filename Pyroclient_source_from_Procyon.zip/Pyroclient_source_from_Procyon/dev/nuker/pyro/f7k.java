// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

public enum f7k
{
    public static f7k c;
    public static f7k 0;
    public static f7k 1;
    public static f7k 2;
    public static f7k 3;
    public static f7k[] c;
    
    public static f7k c(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          110
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            102
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            94
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: ldc             Ldev/nuker/pyro/f7k;.class
        //    26: aload_0        
        //    27: getstatic       dev/nuker/pyro/fc.1:I
        //    30: ifne            38
        //    33: ldc             -682569839
        //    35: goto            40
        //    38: ldc             802241630
        //    40: ldc             -1151331694
        //    42: ixor           
        //    43: lookupswitch {
        //          -1800327476: 68
        //          1815141635: 38
        //          default: 83
        //        }
        //    68: goto            72
        //    71: athrow         
        //    72: invokestatic    java/lang/Enum.valueOf:(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
        //    75: goto            79
        //    78: athrow         
        //    79: checkcast       Ldev/nuker/pyro/f7k;
        //    82: areturn        
        //    83: aconst_null    
        //    84: athrow         
        //    85: pop            
        //    86: goto            24
        //    89: pop            
        //    90: aconst_null    
        //    91: goto            85
        //    94: dup            
        //    95: ifnull          85
        //    98: checkcast       Ljava/lang/Throwable;
        //   101: athrow         
        //   102: dup            
        //   103: ifnull          89
        //   106: checkcast       Ljava/lang/Throwable;
        //   109: athrow         
        //   110: aconst_null    
        //   111: athrow         
        //    StackMapTable: 00 11 43 07 00 1C 04 FF 00 0B 00 00 00 01 07 00 1C FC 00 03 07 00 27 FF 00 0D 00 01 07 00 27 00 02 07 00 29 07 00 27 FF 00 01 00 01 07 00 27 00 03 07 00 29 07 00 27 01 FF 00 1B 00 01 07 00 27 00 02 07 00 29 07 00 27 FF 00 02 00 00 00 01 07 00 1C FF 00 00 00 01 07 00 27 00 02 07 00 29 07 00 27 45 07 00 1C 40 07 00 05 FF 00 03 00 01 07 00 27 00 02 07 00 29 07 00 27 41 07 00 1C 43 05 44 07 00 1C 47 05 47 07 00 1C
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     94     102    Any
        //  94     102    94     102    Any
        //  110    112    3      8      Any
        //  72     78     78     79     Any
        //  72     78     78     79     Ljava/lang/EnumConstantNotPresentException;
        //  72     78     78     79     Ljava/lang/NumberFormatException;
        //  72     78     3      8      Ljava/lang/NullPointerException;
        //  72     78     78     79     Ljava/lang/UnsupportedOperationException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 36 out of bounds for length 36
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public f7k(final String name, final int ordinal) {
    }
    
    static {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: anewarray       Ldev/nuker/pyro/f7k;
        //     4: dup            
        //     5: dup            
        //     6: iconst_0       
        //     7: new             Ldev/nuker/pyro/f7k;
        //    10: dup            
        //    11: ldc             "\u3cbb\ub244\u8fc4\ua16b"
        //    13: invokestatic    invokestatic   !!! ERROR
        //    16: iconst_0       
        //    17: invokespecial   dev/nuker/pyro/f7k.<init>:(Ljava/lang/String;I)V
        //    20: dup            
        //    21: getstatic       dev/nuker/pyro/fc.1:I
        //    24: ifne            32
        //    27: ldc             513383196
        //    29: goto            34
        //    32: ldc             377244575
        //    34: ldc             108271303
        //    36: ixor           
        //    37: lookupswitch {
        //          268983640: 64
        //          418221531: 32
        //          default: 242
        //        }
        //    64: putstatic       dev/nuker/pyro/f7k.c:Ldev/nuker/pyro/f7k;
        //    67: aastore        
        //    68: dup            
        //    69: iconst_1       
        //    70: new             Ldev/nuker/pyro/f7k;
        //    73: dup            
        //    74: ldc             "\u3cbb\ub244\u8fd4\ua16b\u53ce\u586a"
        //    76: invokestatic    invokestatic   !!! ERROR
        //    79: iconst_1       
        //    80: getstatic       dev/nuker/pyro/fc.c:I
        //    83: ifne            91
        //    86: ldc             61245487
        //    88: goto            93
        //    91: ldc             -1101996566
        //    93: ldc             -1639314584
        //    95: ixor           
        //    96: lookupswitch {
        //          -1645444281: 240
        //          -561380371: 91
        //          default: 124
        //        }
        //   124: invokespecial   dev/nuker/pyro/f7k.<init>:(Ljava/lang/String;I)V
        //   127: dup            
        //   128: putstatic       dev/nuker/pyro/f7k.0:Ldev/nuker/pyro/f7k;
        //   131: aastore        
        //   132: dup            
        //   133: iconst_2       
        //   134: new             Ldev/nuker/pyro/f7k;
        //   137: dup            
        //   138: ldc             "\u3cae\ub240\u8fc3\ua15d\u53c0\u587b\u7e4b"
        //   140: invokestatic    invokestatic   !!! ERROR
        //   143: iconst_2       
        //   144: invokespecial   dev/nuker/pyro/f7k.<init>:(Ljava/lang/String;I)V
        //   147: dup            
        //   148: putstatic       dev/nuker/pyro/f7k.1:Ldev/nuker/pyro/f7k;
        //   151: aastore        
        //   152: dup            
        //   153: iconst_3       
        //   154: new             Ldev/nuker/pyro/f7k;
        //   157: dup            
        //   158: ldc             "\u3cae\ub240\u8fda\ua176\u53e7\u5879\u7e43\u68d4\uce17\u9735"
        //   160: getstatic       dev/nuker/pyro/fc.0:I
        //   163: ifgt            171
        //   166: ldc             941984100
        //   168: goto            173
        //   171: ldc             936884235
        //   173: ldc             -1729558088
        //   175: ixor           
        //   176: lookupswitch {
        //          -1597210404: 171
        //          -1354845773: 204
        //          default: 244
        //        }
        //   204: invokestatic    invokestatic   !!! ERROR
        //   207: iconst_3       
        //   208: invokespecial   dev/nuker/pyro/f7k.<init>:(Ljava/lang/String;I)V
        //   211: dup            
        //   212: putstatic       dev/nuker/pyro/f7k.2:Ldev/nuker/pyro/f7k;
        //   215: aastore        
        //   216: dup            
        //   217: iconst_4       
        //   218: new             Ldev/nuker/pyro/f7k;
        //   221: dup            
        //   222: ldc             "\u3cb1\ub24c\u8fda\ua176\u53d5"
        //   224: invokestatic    invokestatic   !!! ERROR
        //   227: iconst_4       
        //   228: invokespecial   dev/nuker/pyro/f7k.<init>:(Ljava/lang/String;I)V
        //   231: dup            
        //   232: putstatic       dev/nuker/pyro/f7k.3:Ldev/nuker/pyro/f7k;
        //   235: aastore        
        //   236: putstatic       dev/nuker/pyro/f7k.c:[Ldev/nuker/pyro/f7k;
        //   239: return         
        //   240: aconst_null    
        //   241: athrow         
        //   242: aconst_null    
        //   243: athrow         
        //   244: aconst_null    
        //   245: athrow         
        //    StackMapTable: 00 0C FF 00 20 00 00 00 06 07 00 3E 07 00 3E 07 00 3E 01 07 00 03 07 00 03 FF 00 01 00 00 00 07 07 00 3E 07 00 3E 07 00 3E 01 07 00 03 07 00 03 01 FF 00 1D 00 00 00 06 07 00 3E 07 00 3E 07 00 3E 01 07 00 03 07 00 03 FF 00 1A 00 00 00 08 07 00 3E 07 00 3E 07 00 3E 01 08 00 46 08 00 46 07 00 27 01 FF 00 01 00 00 00 09 07 00 3E 07 00 3E 07 00 3E 01 08 00 46 08 00 46 07 00 27 01 01 FF 00 1E 00 00 00 08 07 00 3E 07 00 3E 07 00 3E 01 08 00 46 08 00 46 07 00 27 01 FF 00 2E 00 00 00 07 07 00 3E 07 00 3E 07 00 3E 01 08 00 9A 08 00 9A 07 00 27 FF 00 01 00 00 00 08 07 00 3E 07 00 3E 07 00 3E 01 08 00 9A 08 00 9A 07 00 27 01 FF 00 1E 00 00 00 07 07 00 3E 07 00 3E 07 00 3E 01 08 00 9A 08 00 9A 07 00 27 FF 00 23 00 00 00 08 07 00 3E 07 00 3E 07 00 3E 01 08 00 46 08 00 46 07 00 27 01 FF 00 01 00 00 00 06 07 00 3E 07 00 3E 07 00 3E 01 07 00 03 07 00 03 FF 00 01 00 00 00 07 07 00 3E 07 00 3E 07 00 3E 01 08 00 9A 08 00 9A 07 00 27
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2695)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
