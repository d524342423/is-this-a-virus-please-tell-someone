// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import java.util.concurrent.ConcurrentHashMap;

public class dc extends ConcurrentHashMap
{
    public static int c = 1514908535;
    public static int 0 = 1646725885;
    public static int 1 = 2095414588;
    
    dc() {
    }
    
    static {
        dc.1 = 1;
        dc.0 = 1;
        dc.c = -1;
    }
}
