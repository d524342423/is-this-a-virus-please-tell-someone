// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

public class faq extends far
{
    public double c;
    public double 0;
    public int c;
    public int 0;
    
    @Override
    public void c(final f4p p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          2941
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            2933
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            2925
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: getstatic       dev/nuker/pyro/fc.0:I
        //    27: ifgt            35
        //    30: ldc             -943722614
        //    32: goto            37
        //    35: ldc             1302771645
        //    37: ldc             -2100032463
        //    39: ixor           
        //    40: lookupswitch {
        //          -814564468: 68
        //          1164698555: 35
        //          default: 2898
        //        }
        //    68: aload_1        
        //    69: goto            73
        //    72: athrow         
        //    73: invokevirtual   dev/nuker/pyro/f4p.c:()Z
        //    76: goto            80
        //    79: athrow         
        //    80: ifne            88
        //    83: ldc             -1665282153
        //    85: goto            90
        //    88: ldc             -1665282154
        //    90: ldc             504647595
        //    92: ixor           
        //    93: tableswitch {
        //          89325688: 116
        //          89325689: 134
        //          default: 83
        //        }
        //   116: aload_1        
        //   117: goto            121
        //   120: athrow         
        //   121: invokevirtual   dev/nuker/pyro/f4p.c:()Ldev/nuker/pyro/f41;
        //   124: goto            128
        //   127: athrow         
        //   128: getstatic       dev/nuker/pyro/f41.c:Ldev/nuker/pyro/f41;
        //   131: if_acmpeq       135
        //   134: return         
        //   135: goto            139
        //   138: athrow         
        //   139: invokestatic    dev/nuker/pyro/fec.2:()Lnet/minecraft/client/entity/EntityPlayerSP;
        //   142: goto            146
        //   145: athrow         
        //   146: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70123_F:Z
        //   149: ifne            224
        //   152: goto            156
        //   155: athrow         
        //   156: invokestatic    dev/nuker/pyro/fec.2:()Lnet/minecraft/client/entity/EntityPlayerSP;
        //   159: goto            163
        //   162: athrow         
        //   163: getfield        net/minecraft/client/entity/EntityPlayerSP.field_191988_bg:F
        //   166: fconst_0       
        //   167: fcmpl          
        //   168: ifne            467
        //   171: goto            175
        //   174: athrow         
        //   175: invokestatic    dev/nuker/pyro/fec.2:()Lnet/minecraft/client/entity/EntityPlayerSP;
        //   178: goto            182
        //   181: athrow         
        //   182: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70702_br:F
        //   185: fconst_0       
        //   186: fcmpl          
        //   187: ifne            195
        //   190: ldc             -486145194
        //   192: goto            197
        //   195: ldc             -486145193
        //   197: ldc             368138042
        //   199: ixor           
        //   200: tableswitch {
        //          -303126312: 224
        //          -303126311: 467
        //          default: 190
        //        }
        //   224: aload_0        
        //   225: iconst_0       
        //   226: putfield        dev/nuker/pyro/faq.c:I
        //   229: aload_0        
        //   230: iconst_2       
        //   231: putfield        dev/nuker/pyro/faq.0:I
        //   234: aload_1        
        //   235: goto            239
        //   238: athrow         
        //   239: invokevirtual   dev/nuker/pyro/f4p.0:()V
        //   242: goto            246
        //   245: athrow         
        //   246: getstatic       dev/nuker/pyro/fc.1:I
        //   249: ifne            257
        //   252: ldc             -1491245751
        //   254: goto            259
        //   257: ldc             1701354812
        //   259: ldc             -1383510723
        //   261: ixor           
        //   262: lookupswitch {
        //          177481844: 2894
        //          1685248326: 257
        //          default: 288
        //        }
        //   288: aload_1        
        //   289: dconst_0       
        //   290: goto            294
        //   293: athrow         
        //   294: invokevirtual   dev/nuker/pyro/f4p.0:(D)V
        //   297: goto            301
        //   300: athrow         
        //   301: aload_1        
        //   302: dconst_0       
        //   303: getstatic       dev/nuker/pyro/fc.c:I
        //   306: ifne            314
        //   309: ldc             1757314228
        //   311: goto            316
        //   314: ldc             -1808887791
        //   316: ldc             -1263937880
        //   318: ixor           
        //   319: lookupswitch {
        //          -602428900: 2844
        //          551174044: 314
        //          default: 344
        //        }
        //   344: goto            348
        //   347: athrow         
        //   348: invokevirtual   dev/nuker/pyro/f4p.c:(D)V
        //   351: goto            355
        //   354: athrow         
        //   355: getstatic       dev/nuker/pyro/fc.1:I
        //   358: ifne            366
        //   361: ldc             1166381056
        //   363: goto            368
        //   366: ldc             2144376124
        //   368: ldc             -551472144
        //   370: ixor           
        //   371: lookupswitch {
        //          -1700486160: 366
        //          -1594775860: 396
        //          default: 2882
        //        }
        //   396: getstatic       dev/nuker/pyro/f0b.c:Ldev/nuker/pyro/f0b;
        //   399: ldc             "\u37f5\ub24a\u84b5\uafb2\u6abd\u5309\u7e4d\u63bc"
        //   401: getstatic       dev/nuker/pyro/fc.1:I
        //   404: ifne            412
        //   407: ldc             -1071409135
        //   409: goto            414
        //   412: ldc             1153761152
        //   414: ldc             295445971
        //   416: ixor           
        //   417: lookupswitch {
        //          -1692393513: 412
        //          -775963198: 2872
        //          default: 444
        //        }
        //   444: goto            448
        //   447: athrow         
        //   448: invokestatic    invokestatic   !!! ERROR
        //   451: goto            455
        //   454: athrow         
        //   455: goto            459
        //   458: athrow         
        //   459: invokevirtual   dev/nuker/pyro/f0b.1:(Ljava/lang/String;)V
        //   462: goto            466
        //   465: athrow         
        //   466: return         
        //   467: getstatic       dev/nuker/pyro/fc.c:I
        //   470: ifne            478
        //   473: ldc             -533684642
        //   475: goto            480
        //   478: ldc             -1039536094
        //   480: ldc             -1824335630
        //   482: ixor           
        //   483: lookupswitch {
        //          480985991: 478
        //          1936869036: 2902
        //          default: 508
        //        }
        //   508: getstatic       dev/nuker/pyro/f64.c:Ldev/nuker/pyro/f9A;
        //   511: goto            515
        //   514: athrow         
        //   515: invokevirtual   dev/nuker/pyro/f9A.4:()Ldev/nuker/pyro/f0k;
        //   518: goto            522
        //   521: athrow         
        //   522: getstatic       dev/nuker/pyro/fc.c:I
        //   525: ifne            533
        //   528: ldc             934742261
        //   530: goto            535
        //   533: ldc             1218218487
        //   535: ldc             -588056863
        //   537: ixor           
        //   538: lookupswitch {
        //          -347734508: 2904
        //          2097188851: 533
        //          default: 564
        //        }
        //   564: goto            568
        //   567: athrow         
        //   568: invokevirtual   dev/nuker/pyro/f0k.c:()Ljava/lang/Object;
        //   571: goto            575
        //   574: athrow         
        //   575: checkcast       Ljava/lang/Boolean;
        //   578: goto            582
        //   581: athrow         
        //   582: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   585: goto            589
        //   588: athrow         
        //   589: ifeq            711
        //   592: getstatic       dev/nuker/pyro/fc.c:I
        //   595: ifne            603
        //   598: ldc             -1362509140
        //   600: goto            605
        //   603: ldc             -1291013306
        //   605: ldc             1979418095
        //   607: ixor           
        //   608: lookupswitch {
        //          -617461949: 2888
        //          -255223277: 603
        //          default: 636
        //        }
        //   636: getstatic       dev/nuker/pyro/f0b.c:Ldev/nuker/pyro/f0b;
        //   639: ldc             "\u37f5\ub24a\u84b5\uafb2\u6abd\u5309\u7e4d\u63bc"
        //   641: getstatic       dev/nuker/pyro/fc.1:I
        //   644: ifne            652
        //   647: ldc             -1467754897
        //   649: goto            654
        //   652: ldc             -246495087
        //   654: ldc             -1867581731
        //   656: ixor           
        //   657: lookupswitch {
        //          -2065001967: 652
        //          942481586: 2870
        //          default: 684
        //        }
        //   684: goto            688
        //   687: athrow         
        //   688: invokestatic    invokestatic   !!! ERROR
        //   691: goto            695
        //   694: athrow         
        //   695: getstatic       dev/nuker/pyro/f07.0:Ldev/nuker/pyro/f07;
        //   698: ldc             2.5
        //   700: goto            704
        //   703: athrow         
        //   704: invokevirtual   dev/nuker/pyro/f0b.c:(Ljava/lang/String;Ldev/nuker/pyro/f07;F)V
        //   707: goto            711
        //   710: athrow         
        //   711: aload_0        
        //   712: getfield        dev/nuker/pyro/faq.0:I
        //   715: ifle            852
        //   718: goto            722
        //   721: athrow         
        //   722: invokestatic    dev/nuker/pyro/fec.2:()Lnet/minecraft/client/entity/EntityPlayerSP;
        //   725: goto            729
        //   728: athrow         
        //   729: getfield        net/minecraft/client/entity/EntityPlayerSP.field_191988_bg:F
        //   732: fconst_0       
        //   733: fcmpl          
        //   734: ifne            832
        //   737: getstatic       dev/nuker/pyro/fc.c:I
        //   740: ifne            748
        //   743: ldc             1792516434
        //   745: goto            750
        //   748: ldc             32614700
        //   750: ldc             1693289555
        //   752: ixor           
        //   753: lookupswitch {
        //          -1733624765: 748
        //          238693633: 2908
        //          default: 780
        //        }
        //   780: goto            784
        //   783: athrow         
        //   784: invokestatic    dev/nuker/pyro/fec.2:()Lnet/minecraft/client/entity/EntityPlayerSP;
        //   787: goto            791
        //   790: athrow         
        //   791: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70702_br:F
        //   794: fconst_0       
        //   795: fcmpl          
        //   796: ifeq            804
        //   799: ldc             -509920991
        //   801: goto            806
        //   804: ldc             -509920992
        //   806: ldc             152882919
        //   808: ixor           
        //   809: tableswitch {
        //          -787484788: 832
        //          -787484787: 852
        //          default: 799
        //        }
        //   832: aload_0        
        //   833: ldc2_w          0.09
        //   836: putfield        dev/nuker/pyro/faq.c:D
        //   839: aload_0        
        //   840: dup            
        //   841: getfield        dev/nuker/pyro/faq.0:I
        //   844: iconst_1       
        //   845: isub           
        //   846: putfield        dev/nuker/pyro/faq.0:I
        //   849: goto            1655
        //   852: aload_0        
        //   853: getfield        dev/nuker/pyro/faq.c:I
        //   856: iconst_1       
        //   857: if_icmpne       1026
        //   860: goto            864
        //   863: athrow         
        //   864: invokestatic    dev/nuker/pyro/fec.2:()Lnet/minecraft/client/entity/EntityPlayerSP;
        //   867: goto            871
        //   870: athrow         
        //   871: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70124_G:Z
        //   874: ifeq            1026
        //   877: getstatic       dev/nuker/pyro/fc.0:I
        //   880: ifgt            888
        //   883: ldc             -1201803877
        //   885: goto            890
        //   888: ldc             -1133839980
        //   890: ldc             1927817743
        //   892: ixor           
        //   893: lookupswitch {
        //          -894056556: 2864
        //          785525597: 888
        //          default: 920
        //        }
        //   920: goto            924
        //   923: athrow         
        //   924: invokestatic    dev/nuker/pyro/fec.2:()Lnet/minecraft/client/entity/EntityPlayerSP;
        //   927: goto            931
        //   930: athrow         
        //   931: getfield        net/minecraft/client/entity/EntityPlayerSP.field_191988_bg:F
        //   934: fconst_0       
        //   935: fcmpl          
        //   936: ifne            958
        //   939: goto            943
        //   942: athrow         
        //   943: invokestatic    dev/nuker/pyro/fec.2:()Lnet/minecraft/client/entity/EntityPlayerSP;
        //   946: goto            950
        //   949: athrow         
        //   950: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70702_br:F
        //   953: fconst_0       
        //   954: fcmpl          
        //   955: ifeq            1026
        //   958: aload_0        
        //   959: dconst_1       
        //   960: getstatic       dev/nuker/pyro/fc.c:I
        //   963: ifne            971
        //   966: ldc             -885032135
        //   968: goto            973
        //   971: ldc             1264632903
        //   973: ldc             -1461367913
        //   975: ixor           
        //   976: lookupswitch {
        //          -1086134151: 971
        //          1675243694: 2878
        //          default: 1004
        //        }
        //  1004: goto            1008
        //  1007: athrow         
        //  1008: invokestatic    dev/nuker/pyro/far.1:()D
        //  1011: goto            1015
        //  1014: athrow         
        //  1015: dadd           
        //  1016: ldc2_w          0.05
        //  1019: dsub           
        //  1020: putfield        dev/nuker/pyro/faq.c:D
        //  1023: goto            1655
        //  1026: aload_0        
        //  1027: getstatic       dev/nuker/pyro/fc.1:I
        //  1030: ifne            1038
        //  1033: ldc             2124279684
        //  1035: goto            1040
        //  1038: ldc             1052711484
        //  1040: ldc             1004777538
        //  1042: ixor           
        //  1043: lookupswitch {
        //          89959038: 1068
        //          1165909958: 1038
        //          default: 2886
        //        }
        //  1068: getfield        dev/nuker/pyro/faq.c:I
        //  1071: iconst_2       
        //  1072: if_icmpne       1426
        //  1075: getstatic       dev/nuker/pyro/fc.1:I
        //  1078: ifne            1086
        //  1081: ldc             941439770
        //  1083: goto            1088
        //  1086: ldc             1559919548
        //  1088: ldc             -102753250
        //  1090: ixor           
        //  1091: lookupswitch {
        //          -1040374012: 2856
        //          1834141819: 1086
        //          default: 1116
        //        }
        //  1116: goto            1120
        //  1119: athrow         
        //  1120: invokestatic    dev/nuker/pyro/fec.2:()Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1123: goto            1127
        //  1126: athrow         
        //  1127: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70124_G:Z
        //  1130: ifeq            1426
        //  1133: goto            1137
        //  1136: athrow         
        //  1137: invokestatic    dev/nuker/pyro/fec.2:()Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1140: goto            1144
        //  1143: athrow         
        //  1144: getstatic       dev/nuker/pyro/fc.c:I
        //  1147: ifne            1155
        //  1150: ldc             473665778
        //  1152: goto            1157
        //  1155: ldc             880877817
        //  1157: ldc             -1231498911
        //  1159: ixor           
        //  1160: lookupswitch {
        //          -1432141421: 2850
        //          -632367251: 1155
        //          default: 1188
        //        }
        //  1188: getfield        net/minecraft/client/entity/EntityPlayerSP.field_191988_bg:F
        //  1191: fconst_0       
        //  1192: fcmpl          
        //  1193: ifne            1215
        //  1196: goto            1200
        //  1199: athrow         
        //  1200: invokestatic    dev/nuker/pyro/fec.2:()Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1203: goto            1207
        //  1206: athrow         
        //  1207: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70702_br:F
        //  1210: fconst_0       
        //  1211: fcmpl          
        //  1212: ifeq            1426
        //  1215: aload_1        
        //  1216: goto            1220
        //  1219: athrow         
        //  1220: invokestatic    dev/nuker/pyro/fec.2:()Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1223: goto            1227
        //  1226: athrow         
        //  1227: ldc2_w          0.415
        //  1230: dup2_x1        
        //  1231: putfield        net/minecraft/client/entity/EntityPlayerSP.field_70181_x:D
        //  1234: goto            1238
        //  1237: athrow         
        //  1238: invokevirtual   dev/nuker/pyro/f4p.1:(D)V
        //  1241: goto            1245
        //  1244: athrow         
        //  1245: getstatic       dev/nuker/pyro/fc.0:I
        //  1248: ifgt            1256
        //  1251: ldc             -1081724339
        //  1253: goto            1258
        //  1256: ldc             -315545329
        //  1258: ldc             1610307657
        //  1260: ixor           
        //  1261: lookupswitch {
        //          -1435544468: 1256
        //          -528651772: 2846
        //          default: 1288
        //        }
        //  1288: aload_0        
        //  1289: dup            
        //  1290: getfield        dev/nuker/pyro/faq.c:D
        //  1293: getstatic       dev/nuker/pyro/f64.c:Ldev/nuker/pyro/f9A;
        //  1296: goto            1300
        //  1299: athrow         
        //  1300: invokevirtual   dev/nuker/pyro/f9A.8:()Ldev/nuker/pyro/f0m;
        //  1303: goto            1307
        //  1306: athrow         
        //  1307: goto            1311
        //  1310: athrow         
        //  1311: invokevirtual   dev/nuker/pyro/f0m.c:()Ljava/lang/Object;
        //  1314: goto            1318
        //  1317: athrow         
        //  1318: checkcast       Ljava/lang/Double;
        //  1321: getstatic       dev/nuker/pyro/fc.0:I
        //  1324: ifgt            1332
        //  1327: ldc             -325726755
        //  1329: goto            1334
        //  1332: ldc             -744747604
        //  1334: ldc             -2104807052
        //  1336: ixor           
        //  1337: lookupswitch {
        //          1360477400: 1364
        //          1847524521: 1332
        //          default: 2852
        //        }
        //  1364: goto            1368
        //  1367: athrow         
        //  1368: invokevirtual   java/lang/Double.doubleValue:()D
        //  1371: goto            1375
        //  1374: athrow         
        //  1375: dmul           
        //  1376: getstatic       dev/nuker/pyro/fc.0:I
        //  1379: ifgt            1387
        //  1382: ldc             -1782430011
        //  1384: goto            1389
        //  1387: ldc             562154846
        //  1389: ldc             -1834489718
        //  1391: ixor           
        //  1392: lookupswitch {
        //          -1289345580: 1420
        //          124104271: 1387
        //          default: 2880
        //        }
        //  1420: putfield        dev/nuker/pyro/faq.c:D
        //  1423: goto            1655
        //  1426: aload_0        
        //  1427: getfield        dev/nuker/pyro/faq.c:I
        //  1430: iconst_3       
        //  1431: if_icmpne       1594
        //  1434: ldc2_w          0.66
        //  1437: aload_0        
        //  1438: getfield        dev/nuker/pyro/faq.0:D
        //  1441: goto            1445
        //  1444: athrow         
        //  1445: invokestatic    dev/nuker/pyro/far.1:()D
        //  1448: goto            1452
        //  1451: athrow         
        //  1452: dsub           
        //  1453: dmul           
        //  1454: dstore_2       
        //  1455: getstatic       dev/nuker/pyro/fc.1:I
        //  1458: ifne            1466
        //  1461: ldc             294759364
        //  1463: goto            1468
        //  1466: ldc             1140673436
        //  1468: ldc             1210483803
        //  1470: ixor           
        //  1471: lookupswitch {
        //          198954951: 1496
        //          1505177503: 1466
        //          default: 2900
        //        }
        //  1496: aload_0        
        //  1497: getstatic       dev/nuker/pyro/fc.0:I
        //  1500: ifgt            1508
        //  1503: ldc             1177991380
        //  1505: goto            1510
        //  1508: ldc             -393524344
        //  1510: ldc             -1011640205
        //  1512: ixor           
        //  1513: lookupswitch {
        //          -2054872921: 2912
        //          -102999964: 1508
        //          default: 1540
        //        }
        //  1540: aload_0        
        //  1541: getfield        dev/nuker/pyro/faq.0:D
        //  1544: dload_2        
        //  1545: dsub           
        //  1546: getstatic       dev/nuker/pyro/fc.1:I
        //  1549: ifne            1557
        //  1552: ldc             380104160
        //  1554: goto            1559
        //  1557: ldc             -1064043277
        //  1559: ldc             -438170690
        //  1561: ixor           
        //  1562: lookupswitch {
        //          -213522850: 2866
        //          1051329922: 1557
        //          default: 1588
        //        }
        //  1588: putfield        dev/nuker/pyro/faq.c:D
        //  1591: goto            1655
        //  1594: aload_0        
        //  1595: aload_0        
        //  1596: getfield        dev/nuker/pyro/faq.0:D
        //  1599: aload_0        
        //  1600: getfield        dev/nuker/pyro/faq.0:D
        //  1603: ldc2_w          159.0
        //  1606: ddiv           
        //  1607: dsub           
        //  1608: getstatic       dev/nuker/pyro/fc.c:I
        //  1611: ifne            1619
        //  1614: ldc             904205652
        //  1616: goto            1621
        //  1619: ldc             -1647186480
        //  1621: ldc             1940363891
        //  1623: ixor           
        //  1624: lookupswitch {
        //          -1920051597: 1619
        //          1178767143: 2914
        //          default: 1652
        //        }
        //  1652: putfield        dev/nuker/pyro/faq.c:D
        //  1655: getstatic       dev/nuker/pyro/fc.c:I
        //  1658: ifne            1666
        //  1661: ldc             -1626259787
        //  1663: goto            1668
        //  1666: ldc             822290552
        //  1668: ldc             -1453585008
        //  1670: ixor           
        //  1671: lookupswitch {
        //          -1738594840: 1696
        //          911029029: 1666
        //          default: 2892
        //        }
        //  1696: aload_1        
        //  1697: goto            1701
        //  1700: athrow         
        //  1701: invokevirtual   dev/nuker/pyro/f4p.0:()V
        //  1704: goto            1708
        //  1707: athrow         
        //  1708: aload_1        
        //  1709: getstatic       dev/nuker/pyro/fc.0:I
        //  1712: ifgt            1721
        //  1715: ldc_w           -482812042
        //  1718: goto            1724
        //  1721: ldc_w           -1927480500
        //  1724: ldc_w           242702036
        //  1727: ixor           
        //  1728: lookupswitch {
        //          -1679727584: 1721
        //          -313554526: 2868
        //          default: 1756
        //        }
        //  1756: aload_0        
        //  1757: getfield        dev/nuker/pyro/faq.c:D
        //  1760: goto            1764
        //  1763: athrow         
        //  1764: invokestatic    dev/nuker/pyro/fec.c:(Ldev/nuker/pyro/f4p;D)V
        //  1767: goto            1771
        //  1770: athrow         
        //  1771: getstatic       dev/nuker/pyro/faq.c:Lnet/minecraft/client/Minecraft;
        //  1774: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //  1777: getstatic       dev/nuker/pyro/faq.c:Lnet/minecraft/client/Minecraft;
        //  1780: getstatic       dev/nuker/pyro/fc.0:I
        //  1783: ifgt            1792
        //  1786: ldc_w           -186912435
        //  1789: goto            1795
        //  1792: ldc_w           449998618
        //  1795: ldc_w           1306427043
        //  1798: ixor           
        //  1799: lookupswitch {
        //          -1190817810: 1792
        //          1460408761: 1824
        //          default: 2890
        //        }
        //  1824: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1827: getstatic       dev/nuker/pyro/faq.c:Lnet/minecraft/client/Minecraft;
        //  1830: getstatic       dev/nuker/pyro/fc.1:I
        //  1833: ifne            1842
        //  1836: ldc_w           589811315
        //  1839: goto            1845
        //  1842: ldc_w           941174675
        //  1845: ldc_w           1559381550
        //  1848: ixor           
        //  1849: lookupswitch {
        //          1693149629: 1876
        //          2144700509: 1842
        //          default: 2854
        //        }
        //  1876: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1879: goto            1883
        //  1882: athrow         
        //  1883: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_174813_aQ:()Lnet/minecraft/util/math/AxisAlignedBB;
        //  1886: goto            1890
        //  1889: athrow         
        //  1890: dconst_0       
        //  1891: getstatic       dev/nuker/pyro/fc.c:I
        //  1894: ifne            1903
        //  1897: ldc_w           1860460964
        //  1900: goto            1906
        //  1903: ldc_w           436745506
        //  1906: ldc_w           -251188402
        //  1909: ixor           
        //  1910: lookupswitch {
        //          -1612494102: 1903
        //          -351330708: 1936
        //          default: 2840
        //        }
        //  1936: getstatic       dev/nuker/pyro/faq.c:Lnet/minecraft/client/Minecraft;
        //  1939: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1942: getstatic       dev/nuker/pyro/fc.0:I
        //  1945: ifgt            1954
        //  1948: ldc_w           919517615
        //  1951: goto            1957
        //  1954: ldc_w           621015504
        //  1957: ldc_w           1815068126
        //  1960: ixor           
        //  1961: lookupswitch {
        //          1227639822: 1988
        //          1524696177: 1954
        //          default: 2842
        //        }
        //  1988: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70181_x:D
        //  1991: dconst_0       
        //  1992: goto            1996
        //  1995: athrow         
        //  1996: invokevirtual   net/minecraft/util/math/AxisAlignedBB.func_72317_d:(DDD)Lnet/minecraft/util/math/AxisAlignedBB;
        //  1999: goto            2003
        //  2002: athrow         
        //  2003: getstatic       dev/nuker/pyro/fc.1:I
        //  2006: ifne            2015
        //  2009: ldc_w           -445877947
        //  2012: goto            2018
        //  2015: ldc_w           -950540154
        //  2018: ldc_w           -995259189
        //  2021: ixor           
        //  2022: lookupswitch {
        //          -2123793421: 2015
        //          566361486: 2884
        //          default: 2048
        //        }
        //  2048: goto            2052
        //  2051: athrow         
        //  2052: invokevirtual   net/minecraft/client/multiplayer/WorldClient.func_184144_a:(Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/AxisAlignedBB;)Ljava/util/List;
        //  2055: goto            2059
        //  2058: athrow         
        //  2059: astore_2       
        //  2060: getstatic       dev/nuker/pyro/faq.c:Lnet/minecraft/client/Minecraft;
        //  2063: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //  2066: getstatic       dev/nuker/pyro/faq.c:Lnet/minecraft/client/Minecraft;
        //  2069: getstatic       dev/nuker/pyro/fc.1:I
        //  2072: ifne            2081
        //  2075: ldc_w           183503780
        //  2078: goto            2084
        //  2081: ldc_w           -961311475
        //  2084: ldc_w           -769025062
        //  2087: ixor           
        //  2088: lookupswitch {
        //          -856112711: 2081
        //          -656830338: 2848
        //          default: 2116
        //        }
        //  2116: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  2119: getstatic       dev/nuker/pyro/faq.c:Lnet/minecraft/client/Minecraft;
        //  2122: getstatic       dev/nuker/pyro/fc.1:I
        //  2125: ifne            2134
        //  2128: ldc_w           -549238097
        //  2131: goto            2137
        //  2134: ldc_w           -78594725
        //  2137: ldc_w           1446180170
        //  2140: ixor           
        //  2141: lookupswitch {
        //          -1989034011: 2874
        //          1118810111: 2134
        //          default: 2168
        //        }
        //  2168: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  2171: goto            2175
        //  2174: athrow         
        //  2175: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_174813_aQ:()Lnet/minecraft/util/math/AxisAlignedBB;
        //  2178: goto            2182
        //  2181: athrow         
        //  2182: dconst_0       
        //  2183: ldc2_w          -0.4
        //  2186: dconst_0       
        //  2187: getstatic       dev/nuker/pyro/fc.0:I
        //  2190: ifgt            2199
        //  2193: ldc_w           -1818054079
        //  2196: goto            2202
        //  2199: ldc_w           1205381061
        //  2202: ldc_w           -774628802
        //  2205: ixor           
        //  2206: lookupswitch {
        //          -1777549829: 2232
        //          1115072639: 2199
        //          default: 2876
        //        }
        //  2232: goto            2236
        //  2235: athrow         
        //  2236: invokevirtual   net/minecraft/util/math/AxisAlignedBB.func_72317_d:(DDD)Lnet/minecraft/util/math/AxisAlignedBB;
        //  2239: goto            2243
        //  2242: athrow         
        //  2243: goto            2247
        //  2246: athrow         
        //  2247: invokevirtual   net/minecraft/client/multiplayer/WorldClient.func_184144_a:(Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/AxisAlignedBB;)Ljava/util/List;
        //  2250: goto            2254
        //  2253: athrow         
        //  2254: astore_3       
        //  2255: getstatic       dev/nuker/pyro/fc.c:I
        //  2258: ifne            2267
        //  2261: ldc_w           -1134763491
        //  2264: goto            2270
        //  2267: ldc_w           -1329675938
        //  2270: ldc_w           1215066794
        //  2273: ixor           
        //  2274: lookupswitch {
        //          -198143817: 2267
        //          -120409100: 2300
        //          default: 2906
        //        }
        //  2300: goto            2304
        //  2303: athrow         
        //  2304: invokestatic    dev/nuker/pyro/fec.2:()Lnet/minecraft/client/entity/EntityPlayerSP;
        //  2307: goto            2311
        //  2310: athrow         
        //  2311: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70124_G:Z
        //  2314: ifne            2323
        //  2317: ldc_w           -96161202
        //  2320: goto            2326
        //  2323: ldc_w           -96161201
        //  2326: ldc_w           -219347704
        //  2329: ixor           
        //  2330: tableswitch {
        //          290680460: 2352
        //          290680461: 2647
        //          default: 2317
        //        }
        //  2352: aload_2        
        //  2353: goto            2357
        //  2356: athrow         
        //  2357: invokeinterface java/util/List.size:()I
        //  2362: goto            2366
        //  2365: athrow         
        //  2366: ifgt            2375
        //  2369: ldc_w           -294147676
        //  2372: goto            2378
        //  2375: ldc_w           -294147675
        //  2378: ldc_w           1427970092
        //  2381: ixor           
        //  2382: tableswitch {
        //          1993696016: 2404
        //          1993696017: 2512
        //          default: 2369
        //        }
        //  2404: getstatic       dev/nuker/pyro/fc.1:I
        //  2407: ifne            2416
        //  2410: ldc_w           -95692744
        //  2413: goto            2419
        //  2416: ldc_w           -1895678647
        //  2419: ldc_w           511813356
        //  2422: ixor           
        //  2423: lookupswitch {
        //          -1853645915: 2448
        //          -456491308: 2416
        //          default: 2858
        //        }
        //  2448: aload_3        
        //  2449: getstatic       dev/nuker/pyro/fc.1:I
        //  2452: ifne            2461
        //  2455: ldc_w           506487100
        //  2458: goto            2464
        //  2461: ldc_w           -1562890203
        //  2464: ldc_w           1521063859
        //  2467: ixor           
        //  2468: lookupswitch {
        //          -126769258: 2496
        //          1150940815: 2461
        //          default: 2838
        //        }
        //  2496: goto            2500
        //  2499: athrow         
        //  2500: invokeinterface java/util/List.size:()I
        //  2505: goto            2509
        //  2508: athrow         
        //  2509: ifle            2647
        //  2512: aload_0        
        //  2513: getfield        dev/nuker/pyro/faq.c:I
        //  2516: bipush          10
        //  2518: if_icmple       2647
        //  2521: aload_0        
        //  2522: getfield        dev/nuker/pyro/faq.c:I
        //  2525: bipush          38
        //  2527: if_icmplt       2617
        //  2530: aload_1        
        //  2531: goto            2535
        //  2534: athrow         
        //  2535: invokestatic    dev/nuker/pyro/fec.2:()Lnet/minecraft/client/entity/EntityPlayerSP;
        //  2538: goto            2542
        //  2541: athrow         
        //  2542: ldc2_w          -0.4
        //  2545: dup2_x1        
        //  2546: putfield        net/minecraft/client/entity/EntityPlayerSP.field_70181_x:D
        //  2549: goto            2553
        //  2552: athrow         
        //  2553: invokevirtual   dev/nuker/pyro/f4p.1:(D)V
        //  2556: goto            2560
        //  2559: athrow         
        //  2560: getstatic       dev/nuker/pyro/fc.1:I
        //  2563: ifne            2572
        //  2566: ldc_w           -1207014754
        //  2569: goto            2575
        //  2572: ldc_w           1916221516
        //  2575: ldc_w           1285459009
        //  2578: ixor           
        //  2579: lookupswitch {
        //          -191830305: 2572
        //          1051309069: 2604
        //          default: 2910
        //        }
        //  2604: aload_0        
        //  2605: iconst_0       
        //  2606: putfield        dev/nuker/pyro/faq.c:I
        //  2609: aload_0        
        //  2610: iconst_5       
        //  2611: putfield        dev/nuker/pyro/faq.0:I
        //  2614: goto            2647
        //  2617: aload_1        
        //  2618: goto            2622
        //  2621: athrow         
        //  2622: invokestatic    dev/nuker/pyro/fec.2:()Lnet/minecraft/client/entity/EntityPlayerSP;
        //  2625: goto            2629
        //  2628: athrow         
        //  2629: ldc2_w          -0.001
        //  2632: dup2_x1        
        //  2633: putfield        net/minecraft/client/entity/EntityPlayerSP.field_70181_x:D
        //  2636: goto            2640
        //  2639: athrow         
        //  2640: invokevirtual   dev/nuker/pyro/f4p.1:(D)V
        //  2643: goto            2647
        //  2646: athrow         
        //  2647: aload_0        
        //  2648: getstatic       dev/nuker/pyro/fc.c:I
        //  2651: ifne            2660
        //  2654: ldc_w           -9207047
        //  2657: goto            2663
        //  2660: ldc_w           1944861961
        //  2663: ldc_w           1322792312
        //  2666: ixor           
        //  2667: lookupswitch {
        //          -1314146431: 2896
        //          226614067: 2660
        //          default: 2692
        //        }
        //  2692: getfield        dev/nuker/pyro/faq.0:I
        //  2695: ifgt            2837
        //  2698: getstatic       dev/nuker/pyro/fc.1:I
        //  2701: ifne            2710
        //  2704: ldc_w           -2124110683
        //  2707: goto            2713
        //  2710: ldc_w           -115927038
        //  2713: ldc_w           -465539129
        //  2716: ixor           
        //  2717: lookupswitch {
        //          492271557: 2744
        //          1696910178: 2710
        //          default: 2860
        //        }
        //  2744: goto            2748
        //  2747: athrow         
        //  2748: invokestatic    dev/nuker/pyro/fec.2:()Lnet/minecraft/client/entity/EntityPlayerSP;
        //  2751: goto            2755
        //  2754: athrow         
        //  2755: getfield        net/minecraft/client/entity/EntityPlayerSP.field_191988_bg:F
        //  2758: fconst_0       
        //  2759: fcmpl          
        //  2760: ifne            2827
        //  2763: getstatic       dev/nuker/pyro/fc.1:I
        //  2766: ifne            2775
        //  2769: ldc_w           -1495491807
        //  2772: goto            2778
        //  2775: ldc_w           1784875845
        //  2778: ldc_w           -610680082
        //  2781: ixor           
        //  2782: lookupswitch {
        //          -1308964437: 2808
        //          2101696975: 2775
        //          default: 2862
        //        }
        //  2808: goto            2812
        //  2811: athrow         
        //  2812: invokestatic    dev/nuker/pyro/fec.2:()Lnet/minecraft/client/entity/EntityPlayerSP;
        //  2815: goto            2819
        //  2818: athrow         
        //  2819: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70702_br:F
        //  2822: fconst_0       
        //  2823: fcmpl          
        //  2824: ifeq            2837
        //  2827: aload_0        
        //  2828: dup            
        //  2829: getfield        dev/nuker/pyro/faq.c:I
        //  2832: iconst_1       
        //  2833: iadd           
        //  2834: putfield        dev/nuker/pyro/faq.c:I
        //  2837: return         
        //  2838: aconst_null    
        //  2839: athrow         
        //  2840: aconst_null    
        //  2841: athrow         
        //  2842: aconst_null    
        //  2843: athrow         
        //  2844: aconst_null    
        //  2845: athrow         
        //  2846: aconst_null    
        //  2847: athrow         
        //  2848: aconst_null    
        //  2849: athrow         
        //  2850: aconst_null    
        //  2851: athrow         
        //  2852: aconst_null    
        //  2853: athrow         
        //  2854: aconst_null    
        //  2855: athrow         
        //  2856: aconst_null    
        //  2857: athrow         
        //  2858: aconst_null    
        //  2859: athrow         
        //  2860: aconst_null    
        //  2861: athrow         
        //  2862: aconst_null    
        //  2863: athrow         
        //  2864: aconst_null    
        //  2865: athrow         
        //  2866: aconst_null    
        //  2867: athrow         
        //  2868: aconst_null    
        //  2869: athrow         
        //  2870: aconst_null    
        //  2871: athrow         
        //  2872: aconst_null    
        //  2873: athrow         
        //  2874: aconst_null    
        //  2875: athrow         
        //  2876: aconst_null    
        //  2877: athrow         
        //  2878: aconst_null    
        //  2879: athrow         
        //  2880: aconst_null    
        //  2881: athrow         
        //  2882: aconst_null    
        //  2883: athrow         
        //  2884: aconst_null    
        //  2885: athrow         
        //  2886: aconst_null    
        //  2887: athrow         
        //  2888: aconst_null    
        //  2889: athrow         
        //  2890: aconst_null    
        //  2891: athrow         
        //  2892: aconst_null    
        //  2893: athrow         
        //  2894: aconst_null    
        //  2895: athrow         
        //  2896: aconst_null    
        //  2897: athrow         
        //  2898: aconst_null    
        //  2899: athrow         
        //  2900: aconst_null    
        //  2901: athrow         
        //  2902: aconst_null    
        //  2903: athrow         
        //  2904: aconst_null    
        //  2905: athrow         
        //  2906: aconst_null    
        //  2907: athrow         
        //  2908: aconst_null    
        //  2909: athrow         
        //  2910: aconst_null    
        //  2911: athrow         
        //  2912: aconst_null    
        //  2913: athrow         
        //  2914: aconst_null    
        //  2915: athrow         
        //  2916: pop            
        //  2917: goto            24
        //  2920: pop            
        //  2921: aconst_null    
        //  2922: goto            2916
        //  2925: dup            
        //  2926: ifnull          2916
        //  2929: checkcast       Ljava/lang/Throwable;
        //  2932: athrow         
        //  2933: dup            
        //  2934: ifnull          2920
        //  2937: checkcast       Ljava/lang/Throwable;
        //  2940: athrow         
        //  2941: aconst_null    
        //  2942: athrow         
        //    StackMapTable: 01 83 43 07 00 30 04 FF 00 0B 00 00 00 01 07 00 30 FD 00 03 07 00 03 07 00 35 0A 41 01 1E 43 07 00 12 40 07 00 35 45 07 00 30 40 01 02 04 41 01 19 43 07 00 30 40 07 00 35 45 07 00 30 40 07 00 40 05 00 FF 00 02 00 00 00 01 07 00 30 FD 00 00 07 00 03 07 00 35 45 07 00 30 40 07 00 4B 48 07 00 30 00 45 07 00 30 40 07 00 4B 4A 07 00 12 00 45 07 00 30 40 07 00 4B 07 04 41 01 1A FF 00 0D 00 00 00 01 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 01 07 00 35 45 07 00 30 00 0A 41 01 1C 44 07 00 12 FF 00 00 00 02 07 00 03 07 00 35 00 02 07 00 35 03 45 07 00 30 00 FF 00 0C 00 02 07 00 03 07 00 35 00 02 07 00 35 03 FF 00 01 00 02 07 00 03 07 00 35 00 03 07 00 35 03 01 FF 00 1B 00 02 07 00 03 07 00 35 00 02 07 00 35 03 FF 00 02 00 00 00 01 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 02 07 00 35 03 45 07 00 30 00 0A 41 01 1B FF 00 0F 00 02 07 00 03 07 00 35 00 02 07 00 73 07 01 61 FF 00 01 00 02 07 00 03 07 00 35 00 03 07 00 73 07 01 61 01 FF 00 1D 00 02 07 00 03 07 00 35 00 02 07 00 73 07 01 61 42 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 02 07 00 73 07 01 61 45 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 02 07 00 73 07 01 61 42 07 00 12 FF 00 00 00 02 07 00 03 07 00 35 00 02 07 00 73 07 01 61 45 07 00 30 00 00 0A 41 01 1B 45 07 00 24 40 07 00 8D 45 07 00 30 40 07 00 96 4A 07 00 96 FF 00 01 00 02 07 00 03 07 00 35 00 02 07 00 96 01 5C 07 00 96 FF 00 02 00 00 00 01 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 01 07 00 96 45 07 00 30 40 07 01 63 45 07 00 30 40 07 00 9B 45 07 00 30 40 01 0D 41 01 1E FF 00 0F 00 02 07 00 03 07 00 35 00 02 07 00 73 07 01 61 FF 00 01 00 02 07 00 03 07 00 35 00 03 07 00 73 07 01 61 01 FF 00 1D 00 02 07 00 03 07 00 35 00 02 07 00 73 07 01 61 FF 00 02 00 00 00 01 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 02 07 00 73 07 01 61 45 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 02 07 00 73 07 01 61 47 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 04 07 00 73 07 01 61 07 00 A6 02 45 07 00 30 00 49 07 00 30 00 45 07 00 30 40 07 00 4B 12 41 01 1D 42 07 00 30 00 45 07 00 30 40 07 00 4B 07 04 41 01 19 13 4A 07 00 22 00 45 07 00 30 40 07 00 4B 10 41 01 1D 42 07 00 30 00 45 07 00 30 40 07 00 4B FF 00 0A 00 00 00 01 07 00 30 FD 00 00 07 00 03 07 00 35 45 07 00 30 40 07 00 4B 07 FF 00 0C 00 02 07 00 03 07 00 35 00 02 07 00 03 03 FF 00 01 00 02 07 00 03 07 00 35 00 03 07 00 03 03 01 FF 00 1E 00 02 07 00 03 07 00 35 00 02 07 00 03 03 42 07 00 24 FF 00 00 00 02 07 00 03 07 00 35 00 02 07 00 03 03 45 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 03 07 00 03 03 03 0A 4B 07 00 03 FF 00 01 00 02 07 00 03 07 00 35 00 02 07 00 03 01 5B 07 00 03 11 41 01 1B 42 07 00 30 00 45 07 00 30 40 07 00 4B FF 00 08 00 00 00 01 07 00 30 FD 00 00 07 00 03 07 00 35 45 07 00 30 40 07 00 4B 4A 07 00 4B FF 00 01 00 02 07 00 03 07 00 35 00 02 07 00 4B 01 5E 07 00 4B 4A 07 00 12 00 45 07 00 30 40 07 00 4B 07 43 07 00 0E 40 07 00 35 45 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 02 07 00 35 07 00 4B 49 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 02 07 00 35 03 45 07 00 30 00 0A 41 01 1D 4A 07 00 12 FF 00 00 00 02 07 00 03 07 00 35 00 03 07 00 03 03 07 00 8D 45 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 03 07 00 03 03 07 00 DE 42 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 03 07 00 03 03 07 00 DE 45 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 03 07 00 03 03 07 01 63 FF 00 0D 00 02 07 00 03 07 00 35 00 03 07 00 03 03 07 00 E1 FF 00 01 00 02 07 00 03 07 00 35 00 04 07 00 03 03 07 00 E1 01 FF 00 1D 00 02 07 00 03 07 00 35 00 03 07 00 03 03 07 00 E1 42 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 03 07 00 03 03 07 00 E1 45 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 03 07 00 03 03 03 FF 00 0B 00 02 07 00 03 07 00 35 00 02 07 00 03 03 FF 00 01 00 02 07 00 03 07 00 35 00 03 07 00 03 03 01 FF 00 1E 00 02 07 00 03 07 00 35 00 02 07 00 03 03 05 51 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 02 03 03 45 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 03 03 03 03 FC 00 0D 03 41 01 1B 4B 07 00 03 FF 00 01 00 03 07 00 03 07 00 35 03 00 02 07 00 03 01 5D 07 00 03 FF 00 10 00 03 07 00 03 07 00 35 03 00 02 07 00 03 03 FF 00 01 00 03 07 00 03 07 00 35 03 00 03 07 00 03 03 01 FF 00 1C 00 03 07 00 03 07 00 35 03 00 02 07 00 03 03 FA 00 05 FF 00 18 00 02 07 00 03 07 00 35 00 02 07 00 03 03 FF 00 01 00 02 07 00 03 07 00 35 00 03 07 00 03 03 01 FF 00 1E 00 02 07 00 03 07 00 35 00 02 07 00 03 03 02 0A 41 01 1B 43 07 00 30 40 07 00 35 45 07 00 30 00 4C 07 00 35 FF 00 02 00 02 07 00 03 07 00 35 00 02 07 00 35 01 5F 07 00 35 46 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 02 07 00 35 03 45 07 00 30 00 FF 00 14 00 02 07 00 03 07 00 35 00 02 07 01 2D 07 01 0A FF 00 02 00 02 07 00 03 07 00 35 00 03 07 01 2D 07 01 0A 01 FF 00 1C 00 02 07 00 03 07 00 35 00 02 07 01 2D 07 01 0A FF 00 11 00 02 07 00 03 07 00 35 00 03 07 01 2D 07 00 4B 07 01 0A FF 00 02 00 02 07 00 03 07 00 35 00 04 07 01 2D 07 00 4B 07 01 0A 01 FF 00 1E 00 02 07 00 03 07 00 35 00 03 07 01 2D 07 00 4B 07 01 0A 45 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 03 07 01 2D 07 00 4B 07 00 4B 45 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 03 07 01 2D 07 00 4B 07 01 24 FF 00 0C 00 02 07 00 03 07 00 35 00 04 07 01 2D 07 00 4B 07 01 24 03 FF 00 02 00 02 07 00 03 07 00 35 00 05 07 01 2D 07 00 4B 07 01 24 03 01 FF 00 1D 00 02 07 00 03 07 00 35 00 04 07 01 2D 07 00 4B 07 01 24 03 FF 00 11 00 02 07 00 03 07 00 35 00 05 07 01 2D 07 00 4B 07 01 24 03 07 00 4B FF 00 02 00 02 07 00 03 07 00 35 00 06 07 01 2D 07 00 4B 07 01 24 03 07 00 4B 01 FF 00 1E 00 02 07 00 03 07 00 35 00 05 07 01 2D 07 00 4B 07 01 24 03 07 00 4B 46 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 06 07 01 2D 07 00 4B 07 01 24 03 03 03 45 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 03 07 01 2D 07 00 4B 07 01 24 FF 00 0B 00 02 07 00 03 07 00 35 00 03 07 01 2D 07 00 4B 07 01 24 FF 00 02 00 02 07 00 03 07 00 35 00 04 07 01 2D 07 00 4B 07 01 24 01 FF 00 1D 00 02 07 00 03 07 00 35 00 03 07 01 2D 07 00 4B 07 01 24 42 07 00 30 FF 00 00 00 02 07 00 03 07 00 35 00 03 07 01 2D 07 00 4B 07 01 24 45 07 00 30 40 07 01 44 FF 00 15 00 03 07 00 03 07 00 35 07 01 44 00 02 07 01 2D 07 01 0A FF 00 02 00 03 07 00 03 07 00 35 07 01 44 00 03 07 01 2D 07 01 0A 01 FF 00 1F 00 03 07 00 03 07 00 35 07 01 44 00 02 07 01 2D 07 01 0A FF 00 11 00 03 07 00 03 07 00 35 07 01 44 00 03 07 01 2D 07 00 4B 07 01 0A FF 00 02 00 03 07 00 03 07 00 35 07 01 44 00 04 07 01 2D 07 00 4B 07 01 0A 01 FF 00 1E 00 03 07 00 03 07 00 35 07 01 44 00 03 07 01 2D 07 00 4B 07 01 0A 45 07 00 30 FF 00 00 00 03 07 00 03 07 00 35 07 01 44 00 03 07 01 2D 07 00 4B 07 00 4B 45 07 00 30 FF 00 00 00 03 07 00 03 07 00 35 07 01 44 00 03 07 01 2D 07 00 4B 07 01 24 FF 00 10 00 03 07 00 03 07 00 35 07 01 44 00 06 07 01 2D 07 00 4B 07 01 24 03 03 03 FF 00 02 00 03 07 00 03 07 00 35 07 01 44 00 07 07 01 2D 07 00 4B 07 01 24 03 03 03 01 FF 00 1D 00 03 07 00 03 07 00 35 07 01 44 00 06 07 01 2D 07 00 4B 07 01 24 03 03 03 42 07 00 14 FF 00 00 00 03 07 00 03 07 00 35 07 01 44 00 06 07 01 2D 07 00 4B 07 01 24 03 03 03 45 07 00 30 FF 00 00 00 03 07 00 03 07 00 35 07 01 44 00 03 07 01 2D 07 00 4B 07 01 24 FF 00 02 00 00 00 01 07 00 30 FF 00 00 00 03 07 00 03 07 00 35 07 01 44 00 03 07 01 2D 07 00 4B 07 01 24 45 07 00 30 40 07 01 44 FC 00 0C 07 01 44 42 01 1D FF 00 02 00 00 00 01 07 00 30 FF 00 00 00 04 07 00 03 07 00 35 07 01 44 07 01 44 00 00 45 07 00 30 40 07 00 4B 05 05 42 01 19 43 07 00 2A 40 07 01 44 47 07 00 30 40 01 02 05 42 01 19 0B 42 01 1C 4C 07 01 44 FF 00 02 00 04 07 00 03 07 00 35 07 01 44 07 01 44 00 02 07 01 44 01 5F 07 01 44 42 07 00 30 40 07 01 44 47 07 00 30 40 01 02 FF 00 15 00 00 00 01 07 00 30 FF 00 00 00 04 07 00 03 07 00 35 07 01 44 07 01 44 00 01 07 00 35 45 07 00 30 FF 00 00 00 04 07 00 03 07 00 35 07 01 44 07 01 44 00 02 07 00 35 07 00 4B 49 07 00 30 FF 00 00 00 04 07 00 03 07 00 35 07 01 44 07 01 44 00 02 07 00 35 03 45 07 00 30 00 0B 42 01 1C 0C 43 07 00 30 40 07 00 35 45 07 00 30 FF 00 00 00 04 07 00 03 07 00 35 07 01 44 07 01 44 00 02 07 00 35 07 00 4B 49 07 00 12 FF 00 00 00 04 07 00 03 07 00 35 07 01 44 07 01 44 00 02 07 00 35 03 45 07 00 30 00 4C 07 00 03 FF 00 02 00 04 07 00 03 07 00 35 07 01 44 07 01 44 00 02 07 00 03 01 5C 07 00 03 11 42 01 1E 42 07 00 30 00 45 07 00 30 40 07 00 4B 13 42 01 1D 42 07 00 30 00 45 07 00 30 40 07 00 4B 07 09 40 07 01 44 FF 00 01 00 02 07 00 03 07 00 35 00 04 07 01 2D 07 00 4B 07 01 24 03 FF 00 01 00 02 07 00 03 07 00 35 00 05 07 01 2D 07 00 4B 07 01 24 03 07 00 4B FF 00 01 00 02 07 00 03 07 00 35 00 02 07 00 35 03 01 FF 00 01 00 03 07 00 03 07 00 35 07 01 44 00 02 07 01 2D 07 01 0A FF 00 01 00 02 07 00 03 07 00 35 00 01 07 00 4B FF 00 01 00 02 07 00 03 07 00 35 00 03 07 00 03 03 07 00 E1 FF 00 01 00 02 07 00 03 07 00 35 00 03 07 01 2D 07 00 4B 07 01 0A 01 FD 00 01 07 01 44 07 01 44 01 01 F9 00 01 FF 00 01 00 03 07 00 03 07 00 35 03 00 02 07 00 03 03 FF 00 01 00 02 07 00 03 07 00 35 00 01 07 00 35 FF 00 01 00 02 07 00 03 07 00 35 00 02 07 00 73 07 01 61 FF 00 01 00 02 07 00 03 07 00 35 00 02 07 00 73 07 01 61 FF 00 01 00 03 07 00 03 07 00 35 07 01 44 00 03 07 01 2D 07 00 4B 07 01 0A FF 00 01 00 03 07 00 03 07 00 35 07 01 44 00 06 07 01 2D 07 00 4B 07 01 24 03 03 03 FF 00 01 00 02 07 00 03 07 00 35 00 02 07 00 03 03 FF 00 01 00 02 07 00 03 07 00 35 00 02 07 00 03 03 01 FF 00 01 00 02 07 00 03 07 00 35 00 03 07 01 2D 07 00 4B 07 01 24 41 07 00 03 01 FF 00 01 00 02 07 00 03 07 00 35 00 02 07 01 2D 07 01 0A 01 01 FF 00 01 00 04 07 00 03 07 00 35 07 01 44 07 01 44 00 01 07 00 03 F9 00 01 FC 00 01 03 FA 00 01 41 07 00 96 FD 00 01 07 01 44 07 01 44 F9 00 01 FD 00 01 07 01 44 07 01 44 FF 00 01 00 03 07 00 03 07 00 35 03 00 01 07 00 03 FF 00 01 00 02 07 00 03 07 00 35 00 02 07 00 03 03 41 07 00 12 43 05 44 07 00 12 47 05 47 07 00 30
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     2925   2933   Ljava/lang/NumberFormatException;
        //  2925   2933   2925   2933   Ljava/lang/ArithmeticException;
        //  2941   2943   3      8      Any
        //  72     79     79     80     Any
        //  72     79     3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  73     79     3      8      Any
        //  73     79     3      8      Any
        //  72     79     72     73     Ljava/lang/RuntimeException;
        //  120    127    127    128    Any
        //  120    127    120    121    Any
        //  121    127    127    128    Ljava/lang/IllegalStateException;
        //  121    127    120    121    Any
        //  121    127    120    121    Any
        //  139    145    145    146    Any
        //  139    145    3      8      Any
        //  139    145    3      8      Ljava/util/ConcurrentModificationException;
        //  139    145    145    146    Ljava/lang/EnumConstantNotPresentException;
        //  139    145    145    146    Ljava/lang/UnsupportedOperationException;
        //  155    162    162    163    Any
        //  156    162    3      8      Ljava/util/NoSuchElementException;
        //  155    162    162    163    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  156    162    155    156    Any
        //  156    162    155    156    Ljava/lang/IndexOutOfBoundsException;
        //  174    181    181    182    Any
        //  175    181    3      8      Ljava/util/NoSuchElementException;
        //  174    181    174    175    Ljava/lang/IllegalStateException;
        //  174    181    3      8      Ljava/lang/AssertionError;
        //  174    181    174    175    Ljava/lang/NullPointerException;
        //  239    245    245    246    Any
        //  239    245    245    246    Any
        //  239    245    245    246    Any
        //  239    245    3      8      Ljava/lang/NegativeArraySizeException;
        //  239    245    3      8      Ljava/util/ConcurrentModificationException;
        //  293    300    300    301    Any
        //  293    300    293    294    Ljava/lang/NegativeArraySizeException;
        //  293    300    293    294    Ljava/lang/UnsupportedOperationException;
        //  293    300    3      8      Ljava/lang/UnsupportedOperationException;
        //  294    300    293    294    Ljava/lang/ArithmeticException;
        //  348    354    354    355    Any
        //  348    354    354    355    Ljava/lang/IllegalStateException;
        //  348    354    3      8      Any
        //  348    354    3      8      Ljava/lang/NullPointerException;
        //  348    354    354    355    Ljava/lang/EnumConstantNotPresentException;
        //  447    454    454    455    Any
        //  447    454    3      8      Any
        //  447    454    3      8      Any
        //  448    454    447    448    Ljava/lang/EnumConstantNotPresentException;
        //  447    454    447    448    Any
        //  458    465    465    466    Any
        //  459    465    465    466    Ljava/lang/NegativeArraySizeException;
        //  458    465    3      8      Ljava/lang/IllegalArgumentException;
        //  459    465    465    466    Ljava/lang/NullPointerException;
        //  458    465    458    459    Ljava/lang/RuntimeException;
        //  514    521    521    522    Any
        //  515    521    3      8      Any
        //  515    521    514    515    Ljava/lang/NegativeArraySizeException;
        //  515    521    521    522    Ljava/lang/NumberFormatException;
        //  515    521    521    522    Ljava/lang/EnumConstantNotPresentException;
        //  568    574    574    575    Any
        //  568    574    574    575    Ljava/lang/ClassCastException;
        //  568    574    574    575    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  568    574    574    575    Ljava/lang/IllegalArgumentException;
        //  568    574    574    575    Any
        //  581    588    588    589    Any
        //  582    588    3      8      Ljava/lang/IllegalStateException;
        //  581    588    3      8      Any
        //  581    588    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  581    588    581    582    Any
        //  688    694    694    695    Any
        //  688    694    694    695    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  688    694    3      8      Any
        //  688    694    3      8      Ljava/lang/AssertionError;
        //  688    694    694    695    Any
        //  703    710    710    711    Any
        //  704    710    703    704    Any
        //  704    710    710    711    Ljava/lang/RuntimeException;
        //  704    710    703    704    Any
        //  704    710    710    711    Ljava/lang/StringIndexOutOfBoundsException;
        //  721    728    728    729    Any
        //  722    728    3      8      Any
        //  721    728    728    729    Ljava/lang/StringIndexOutOfBoundsException;
        //  721    728    721    722    Any
        //  722    728    3      8      Ljava/util/ConcurrentModificationException;
        //  783    790    790    791    Any
        //  783    790    783    784    Any
        //  784    790    790    791    Any
        //  783    790    790    791    Ljava/lang/NegativeArraySizeException;
        //  784    790    3      8      Ljava/lang/IllegalArgumentException;
        //  863    870    870    871    Any
        //  864    870    3      8      Any
        //  864    870    863    864    Ljava/lang/NullPointerException;
        //  863    870    3      8      Any
        //  863    870    3      8      Any
        //  923    930    930    931    Any
        //  923    930    930    931    Ljava/lang/IndexOutOfBoundsException;
        //  924    930    930    931    Ljava/lang/IllegalStateException;
        //  923    930    923    924    Any
        //  924    930    923    924    Any
        //  943    949    949    950    Any
        //  943    949    949    950    Any
        //  943    949    3      8      Any
        //  943    949    949    950    Any
        //  943    949    3      8      Ljava/lang/NumberFormatException;
        //  1007   1014   1014   1015   Any
        //  1007   1014   1007   1008   Ljava/lang/NegativeArraySizeException;
        //  1008   1014   1014   1015   Ljava/lang/UnsupportedOperationException;
        //  1007   1014   3      8      Ljava/lang/IndexOutOfBoundsException;
        //  1007   1014   1014   1015   Ljava/lang/IllegalArgumentException;
        //  1119   1126   1126   1127   Any
        //  1119   1126   3      8      Ljava/util/ConcurrentModificationException;
        //  1120   1126   1126   1127   Any
        //  1120   1126   1126   1127   Any
        //  1120   1126   1119   1120   Any
        //  1137   1143   1143   1144   Any
        //  1137   1143   1143   1144   Ljava/lang/IndexOutOfBoundsException;
        //  1137   1143   3      8      Ljava/lang/NumberFormatException;
        //  1137   1143   1143   1144   Any
        //  1137   1143   1143   1144   Ljava/lang/RuntimeException;
        //  1199   1206   1206   1207   Any
        //  1200   1206   3      8      Ljava/lang/AssertionError;
        //  1200   1206   1199   1200   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1200   1206   3      8      Any
        //  1200   1206   1199   1200   Ljava/util/ConcurrentModificationException;
        //  1219   1226   1226   1227   Any
        //  1220   1226   1219   1220   Ljava/lang/ArithmeticException;
        //  1219   1226   3      8      Any
        //  1219   1226   3      8      Ljava/lang/NullPointerException;
        //  1219   1226   3      8      Any
        //  1237   1244   1244   1245   Any
        //  1238   1244   1237   1238   Any
        //  1238   1244   1237   1238   Ljava/lang/ClassCastException;
        //  1237   1244   3      8      Any
        //  1237   1244   3      8      Ljava/util/NoSuchElementException;
        //  1299   1306   1306   1307   Any
        //  1300   1306   1299   1300   Ljava/lang/UnsupportedOperationException;
        //  1300   1306   1299   1300   Ljava/lang/IndexOutOfBoundsException;
        //  1299   1306   1306   1307   Any
        //  1299   1306   1299   1300   Ljava/lang/UnsupportedOperationException;
        //  1310   1317   1317   1318   Any
        //  1310   1317   1317   1318   Ljava/util/ConcurrentModificationException;
        //  1311   1317   1310   1311   Any
        //  1310   1317   1310   1311   Any
        //  1310   1317   3      8      Ljava/lang/NullPointerException;
        //  1367   1374   1374   1375   Any
        //  1367   1374   3      8      Ljava/lang/AssertionError;
        //  1368   1374   1374   1375   Ljava/lang/NumberFormatException;
        //  1368   1374   1367   1368   Ljava/lang/UnsupportedOperationException;
        //  1368   1374   1367   1368   Any
        //  1444   1451   1451   1452   Any
        //  1444   1451   3      8      Ljava/lang/IllegalStateException;
        //  1444   1451   3      8      Any
        //  1445   1451   1451   1452   Ljava/lang/IndexOutOfBoundsException;
        //  1444   1451   1444   1445   Any
        //  1700   1707   1707   1708   Any
        //  1701   1707   1700   1701   Any
        //  1700   1707   3      8      Ljava/lang/NumberFormatException;
        //  1700   1707   3      8      Ljava/lang/RuntimeException;
        //  1700   1707   1707   1708   Ljava/lang/ArithmeticException;
        //  1763   1770   1770   1771   Any
        //  1763   1770   3      8      Any
        //  1764   1770   3      8      Ljava/lang/RuntimeException;
        //  1764   1770   3      8      Any
        //  1763   1770   1763   1764   Any
        //  1882   1889   1889   1890   Any
        //  1882   1889   3      8      Ljava/lang/NullPointerException;
        //  1882   1889   1889   1890   Any
        //  1883   1889   1882   1883   Any
        //  1882   1889   1889   1890   Ljava/util/NoSuchElementException;
        //  1995   2002   2002   2003   Any
        //  1995   2002   1995   1996   Any
        //  1995   2002   1995   1996   Any
        //  1996   2002   2002   2003   Any
        //  1995   2002   2002   2003   Any
        //  2051   2058   2058   2059   Any
        //  2052   2058   2051   2052   Any
        //  2051   2058   2058   2059   Ljava/lang/ClassCastException;
        //  2051   2058   3      8      Any
        //  2052   2058   2051   2052   Ljava/lang/EnumConstantNotPresentException;
        //  2174   2181   2181   2182   Any
        //  2174   2181   3      8      Ljava/lang/IndexOutOfBoundsException;
        //  2174   2181   3      8      Any
        //  2175   2181   2174   2175   Any
        //  2175   2181   3      8      Ljava/lang/ArithmeticException;
        //  2235   2242   2242   2243   Any
        //  2236   2242   3      8      Any
        //  2235   2242   2235   2236   Ljava/lang/IllegalStateException;
        //  2235   2242   2242   2243   Ljava/lang/NegativeArraySizeException;
        //  2236   2242   3      8      Any
        //  2247   2253   2253   2254   Any
        //  2247   2253   2253   2254   Any
        //  2247   2253   2253   2254   Any
        //  2247   2253   2253   2254   Ljava/lang/ArithmeticException;
        //  2247   2253   3      8      Any
        //  2304   2310   2310   2311   Any
        //  2304   2310   2310   2311   Any
        //  2304   2310   2310   2311   Any
        //  2304   2310   2310   2311   Any
        //  2304   2310   2310   2311   Ljava/lang/UnsupportedOperationException;
        //  2356   2365   2365   2366   Any
        //  2356   2365   2356   2357   Ljava/lang/StringIndexOutOfBoundsException;
        //  2356   2365   3      8      Ljava/lang/UnsupportedOperationException;
        //  2356   2365   3      8      Ljava/util/ConcurrentModificationException;
        //  2356   2365   2365   2366   Ljava/lang/NumberFormatException;
        //  2499   2508   2508   2509   Any
        //  2499   2508   2499   2500   Ljava/lang/IllegalArgumentException;
        //  2499   2508   2499   2500   Any
        //  2500   2508   2499   2500   Ljava/lang/ClassCastException;
        //  2499   2508   2508   2509   Any
        //  2535   2541   2541   2542   Any
        //  2535   2541   2541   2542   Any
        //  2535   2541   2541   2542   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  2535   2541   2541   2542   Any
        //  2535   2541   3      8      Ljava/util/ConcurrentModificationException;
        //  2552   2559   2559   2560   Any
        //  2552   2559   2552   2553   Any
        //  2553   2559   2552   2553   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  2553   2559   2552   2553   Any
        //  2553   2559   2559   2560   Ljava/util/NoSuchElementException;
        //  2621   2628   2628   2629   Any
        //  2622   2628   2621   2622   Ljava/lang/AssertionError;
        //  2622   2628   2621   2622   Any
        //  2622   2628   3      8      Any
        //  2622   2628   2628   2629   Any
        //  2639   2646   2646   2647   Any
        //  2640   2646   2639   2640   Ljava/lang/RuntimeException;
        //  2640   2646   3      8      Ljava/lang/UnsupportedOperationException;
        //  2639   2646   2639   2640   Ljava/lang/StringIndexOutOfBoundsException;
        //  2640   2646   2646   2647   Ljava/lang/IllegalArgumentException;
        //  2747   2754   2754   2755   Any
        //  2747   2754   3      8      Any
        //  2748   2754   2747   2748   Ljava/lang/AssertionError;
        //  2748   2754   3      8      Ljava/lang/NumberFormatException;
        //  2748   2754   2747   2748   Ljava/util/ConcurrentModificationException;
        //  2811   2818   2818   2819   Any
        //  2811   2818   3      8      Ljava/lang/IllegalArgumentException;
        //  2811   2818   2811   2812   Ljava/lang/IllegalStateException;
        //  2812   2818   2818   2819   Ljava/lang/UnsupportedOperationException;
        //  2812   2818   2811   2812   Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:595)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        throw t;
    }
    
    public faq() {
        this.c = 0;
        while (true) {
            int n = 0;
            Label_0024: {
                if (fc.1 == 0) {
                    n = 1990959968;
                    break Label_0024;
                }
                n = -726296986;
            }
            switch (n ^ 0x243B1240) {
                case 1385214240: {
                    continue;
                }
                case -259095514: {
                    this.0 = 2;
                }
                default: {
                    throw null;
                }
            }
            break;
        }
    }
    
    @Override
    public void 0() {
        fez.gC(this, 595860459);
    }
    
    @Override
    public void c(final f4u f4u) {
        fez.ij(this, 2099528004, f4u);
    }
    
    @Override
    public void c() {
        fez.fS(this, 462108070);
    }
}
