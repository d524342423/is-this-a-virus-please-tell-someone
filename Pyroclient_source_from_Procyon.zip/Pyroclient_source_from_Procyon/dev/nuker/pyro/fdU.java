// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import net.minecraft.util.EnumHand;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.play.client.CPacketPlayer$Rotation;
import java.util.NoSuchElementException;
import net.minecraft.network.Packet;
import net.minecraft.world.World;
import net.minecraft.block.Block;
import net.minecraft.util.Tuple;
import net.minecraft.util.EnumFacing;
import net.minecraft.block.state.IBlockState;
import org.jetbrains.annotations.Nullable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.NotNull;
import net.minecraft.client.Minecraft;

public class fdU
{
    public Minecraft c;
    @NotNull
    public static fdU c;
    public static fdR c;
    
    @NotNull
    public Vec3d c() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          424
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            416
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            408
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: new             Lnet/minecraft/util/math/Vec3d;
        //    27: dup            
        //    28: getstatic       dev/nuker/pyro/fc.c:I
        //    31: ifne            39
        //    34: ldc             -653883318
        //    36: goto            41
        //    39: ldc             -218558918
        //    41: ldc             -1725982749
        //    43: ixor           
        //    44: lookupswitch {
        //          1075388329: 39
        //          1810274777: 72
        //          default: 389
        //        }
        //    72: aload_0        
        //    73: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //    76: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //    79: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70165_t:D
        //    82: aload_0        
        //    83: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //    86: getstatic       dev/nuker/pyro/fc.0:I
        //    89: ifgt            97
        //    92: ldc             763308271
        //    94: goto            99
        //    97: ldc             -1977006861
        //    99: ldc             -1370177733
        //   101: ixor           
        //   102: lookupswitch {
        //          -2094295084: 97
        //          612236232: 128
        //          default: 393
        //        }
        //   128: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   131: getstatic       dev/nuker/pyro/fc.1:I
        //   134: ifne            142
        //   137: ldc             -135253930
        //   139: goto            144
        //   142: ldc             -1683549056
        //   144: ldc             277921233
        //   146: ixor           
        //   147: lookupswitch {
        //          -413102713: 391
        //          35340117: 142
        //          default: 172
        //        }
        //   172: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70163_u:D
        //   175: getstatic       dev/nuker/pyro/fc.0:I
        //   178: ifgt            186
        //   181: ldc             499602146
        //   183: goto            188
        //   186: ldc             1016635510
        //   188: ldc             -1146210498
        //   190: ixor           
        //   191: lookupswitch {
        //          -1503042084: 387
        //          -311316681: 186
        //          default: 216
        //        }
        //   216: aload_0        
        //   217: getstatic       dev/nuker/pyro/fc.0:I
        //   220: ifgt            228
        //   223: ldc             1322540337
        //   225: goto            230
        //   228: ldc             -1472617441
        //   230: ldc             291219895
        //   232: ixor           
        //   233: lookupswitch {
        //          -1184756312: 260
        //          1603269766: 228
        //          default: 395
        //        }
        //   260: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   263: getstatic       dev/nuker/pyro/fc.1:I
        //   266: ifne            274
        //   269: ldc             200554569
        //   271: goto            276
        //   274: ldc             -1155980216
        //   276: ldc             1740431683
        //   278: ixor           
        //   279: lookupswitch {
        //          -1362492675: 274
        //          1816713482: 397
        //          default: 304
        //        }
        //   304: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   307: goto            311
        //   310: athrow         
        //   311: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_70047_e:()F
        //   314: goto            318
        //   317: athrow         
        //   318: f2d            
        //   319: dadd           
        //   320: aload_0        
        //   321: getstatic       dev/nuker/pyro/fc.0:I
        //   324: ifgt            332
        //   327: ldc             57619255
        //   329: goto            334
        //   332: ldc             1962761948
        //   334: ldc             -2108617340
        //   336: ixor           
        //   337: lookupswitch {
        //          -2126627149: 332
        //          -156478632: 364
        //          default: 385
        //        }
        //   364: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   367: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   370: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70161_v:D
        //   373: goto            377
        //   376: athrow         
        //   377: invokespecial   net/minecraft/util/math/Vec3d.<init>:(DDD)V
        //   380: goto            384
        //   383: athrow         
        //   384: areturn        
        //   385: aconst_null    
        //   386: athrow         
        //   387: aconst_null    
        //   388: athrow         
        //   389: aconst_null    
        //   390: athrow         
        //   391: aconst_null    
        //   392: athrow         
        //   393: aconst_null    
        //   394: athrow         
        //   395: aconst_null    
        //   396: athrow         
        //   397: aconst_null    
        //   398: athrow         
        //   399: pop            
        //   400: goto            24
        //   403: pop            
        //   404: aconst_null    
        //   405: goto            399
        //   408: dup            
        //   409: ifnull          399
        //   412: checkcast       Ljava/lang/Throwable;
        //   415: athrow         
        //   416: dup            
        //   417: ifnull          403
        //   420: checkcast       Ljava/lang/Throwable;
        //   423: athrow         
        //   424: aconst_null    
        //   425: athrow         
        //    StackMapTable: 00 2D 43 07 00 1B 04 FF 00 0B 00 00 00 01 07 00 1B FC 00 03 07 00 03 FF 00 0E 00 01 07 00 03 00 02 08 00 18 08 00 18 FF 00 01 00 01 07 00 03 00 03 08 00 18 08 00 18 01 FF 00 1E 00 01 07 00 03 00 02 08 00 18 08 00 18 FF 00 18 00 01 07 00 03 00 04 08 00 18 08 00 18 03 07 00 26 FF 00 01 00 01 07 00 03 00 05 08 00 18 08 00 18 03 07 00 26 01 FF 00 1C 00 01 07 00 03 00 04 08 00 18 08 00 18 03 07 00 26 FF 00 0D 00 01 07 00 03 00 04 08 00 18 08 00 18 03 07 00 2C FF 00 01 00 01 07 00 03 00 05 08 00 18 08 00 18 03 07 00 2C 01 FF 00 1B 00 01 07 00 03 00 04 08 00 18 08 00 18 03 07 00 2C FF 00 0D 00 01 07 00 03 00 04 08 00 18 08 00 18 03 03 FF 00 01 00 01 07 00 03 00 05 08 00 18 08 00 18 03 03 01 FF 00 1B 00 01 07 00 03 00 04 08 00 18 08 00 18 03 03 FF 00 0B 00 01 07 00 03 00 05 08 00 18 08 00 18 03 03 07 00 03 FF 00 01 00 01 07 00 03 00 06 08 00 18 08 00 18 03 03 07 00 03 01 FF 00 1D 00 01 07 00 03 00 05 08 00 18 08 00 18 03 03 07 00 03 FF 00 0D 00 01 07 00 03 00 05 08 00 18 08 00 18 03 03 07 00 26 FF 00 01 00 01 07 00 03 00 06 08 00 18 08 00 18 03 03 07 00 26 01 FF 00 1B 00 01 07 00 03 00 05 08 00 18 08 00 18 03 03 07 00 26 45 07 00 1B FF 00 00 00 01 07 00 03 00 05 08 00 18 08 00 18 03 03 07 00 2C 45 07 00 1B FF 00 00 00 01 07 00 03 00 05 08 00 18 08 00 18 03 03 02 FF 00 0D 00 01 07 00 03 00 05 08 00 18 08 00 18 03 03 07 00 03 FF 00 01 00 01 07 00 03 00 06 08 00 18 08 00 18 03 03 07 00 03 01 FF 00 1D 00 01 07 00 03 00 05 08 00 18 08 00 18 03 03 07 00 03 4B 07 00 1B FF 00 00 00 01 07 00 03 00 05 08 00 18 08 00 18 03 03 03 45 07 00 1B 40 07 00 1D FF 00 00 00 01 07 00 03 00 05 08 00 18 08 00 18 03 03 07 00 03 FF 00 01 00 01 07 00 03 00 04 08 00 18 08 00 18 03 03 FF 00 01 00 01 07 00 03 00 02 08 00 18 08 00 18 FF 00 01 00 01 07 00 03 00 04 08 00 18 08 00 18 03 07 00 2C FF 00 01 00 01 07 00 03 00 04 08 00 18 08 00 18 03 07 00 26 FF 00 01 00 01 07 00 03 00 05 08 00 18 08 00 18 03 03 07 00 03 FF 00 01 00 01 07 00 03 00 05 08 00 18 08 00 18 03 03 07 00 26 41 07 00 55 43 05 44 07 00 55 47 05 47 07 00 1B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                      
        //  -----  -----  -----  -----  ------------------------------------------
        //  8      20     408    416    Ljava/lang/NullPointerException;
        //  408    416    408    416    Ljava/lang/IndexOutOfBoundsException;
        //  424    426    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  310    317    317    318    Any
        //  310    317    3      8      Any
        //  311    317    310    311    Ljava/lang/IndexOutOfBoundsException;
        //  311    317    310    311    Any
        //  311    317    317    318    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  376    383    383    384    Any
        //  377    383    376    377    Any
        //  376    383    383    384    Any
        //  377    383    376    377    Any
        //  377    383    376    377    Ljava/lang/IllegalStateException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:595)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static fdU 1() {
        return fez.4z(null, 710389133);
    }
    
    @NotNull
    public Vec2f c(@NotNull final Vec3d p0, @NotNull final Vec3d p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          1144
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            1136
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            1128
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: aload_2        
        //    27: pop            
        //    28: aload_2        
        //    29: getfield        net/minecraft/util/math/Vec3d.field_72450_a:D
        //    32: aload_1        
        //    33: getfield        net/minecraft/util/math/Vec3d.field_72450_a:D
        //    36: dsub           
        //    37: dstore_3       
        //    38: getstatic       dev/nuker/pyro/fc.0:I
        //    41: ifgt            49
        //    44: ldc             254479659
        //    46: goto            51
        //    49: ldc             -919729639
        //    51: ldc             1367349381
        //    53: ixor           
        //    54: lookupswitch {
        //          -609317393: 49
        //          1588270510: 1105
        //          default: 80
        //        }
        //    80: aload_2        
        //    81: getstatic       dev/nuker/pyro/fc.c:I
        //    84: ifne            92
        //    87: ldc             -828560569
        //    89: goto            94
        //    92: ldc             1313264709
        //    94: ldc             756792796
        //    96: ixor           
        //    97: lookupswitch {
        //          -477718885: 92
        //          1667066265: 124
        //          default: 1111
        //        }
        //   124: getfield        net/minecraft/util/math/Vec3d.field_72448_b:D
        //   127: aload_1        
        //   128: getfield        net/minecraft/util/math/Vec3d.field_72448_b:D
        //   131: dsub           
        //   132: dstore          5
        //   134: getstatic       dev/nuker/pyro/fc.0:I
        //   137: ifgt            145
        //   140: ldc             86120770
        //   142: goto            147
        //   145: ldc             -1098106498
        //   147: ldc             496223755
        //   149: ixor           
        //   150: lookupswitch {
        //          414310217: 1093
        //          1445498490: 145
        //          default: 176
        //        }
        //   176: aload_2        
        //   177: getstatic       dev/nuker/pyro/fc.0:I
        //   180: ifgt            188
        //   183: ldc             1608197824
        //   185: goto            190
        //   188: ldc             -1694971653
        //   190: ldc             -642308166
        //   192: ixor           
        //   193: lookupswitch {
        //          -2039742086: 188
        //          1129312065: 220
        //          default: 1107
        //        }
        //   220: getfield        net/minecraft/util/math/Vec3d.field_72449_c:D
        //   223: getstatic       dev/nuker/pyro/fc.0:I
        //   226: ifgt            234
        //   229: ldc             1343362154
        //   231: goto            236
        //   234: ldc             2030188734
        //   236: ldc             775240575
        //   238: ixor           
        //   239: lookupswitch {
        //          550940385: 234
        //          2116497173: 1081
        //          default: 264
        //        }
        //   264: aload_1        
        //   265: getfield        net/minecraft/util/math/Vec3d.field_72449_c:D
        //   268: dsub           
        //   269: dstore          7
        //   271: dload_3        
        //   272: dload_3        
        //   273: dmul           
        //   274: dload           7
        //   276: getstatic       dev/nuker/pyro/fc.0:I
        //   279: ifgt            287
        //   282: ldc             1141711000
        //   284: goto            289
        //   287: ldc             1989762811
        //   289: ldc             -1341240357
        //   291: ixor           
        //   292: lookupswitch {
        //          -963177184: 320
        //          -201102525: 287
        //          default: 1079
        //        }
        //   320: dload           7
        //   322: dmul           
        //   323: dadd           
        //   324: getstatic       dev/nuker/pyro/fc.c:I
        //   327: ifne            335
        //   330: ldc             1705688459
        //   332: goto            337
        //   335: ldc             -858743557
        //   337: ldc             1011497933
        //   339: ixor           
        //   340: lookupswitch {
        //          -258300106: 368
        //          1507886662: 335
        //          default: 1115
        //        }
        //   368: goto            372
        //   371: athrow         
        //   372: invokestatic    java/lang/Math.sqrt:(D)D
        //   375: goto            379
        //   378: athrow         
        //   379: dstore          9
        //   381: getstatic       dev/nuker/pyro/fc.0:I
        //   384: ifgt            392
        //   387: ldc             2088844360
        //   389: goto            394
        //   392: ldc             -199846328
        //   394: ldc             931068599
        //   396: ixor           
        //   397: lookupswitch {
        //          -1016566529: 424
        //          1275053823: 392
        //          default: 1091
        //        }
        //   424: dload           7
        //   426: dload_3        
        //   427: goto            431
        //   430: athrow         
        //   431: invokestatic    java/lang/Math.atan2:(DD)D
        //   434: goto            438
        //   437: athrow         
        //   438: goto            442
        //   441: athrow         
        //   442: invokestatic    java/lang/Math.toDegrees:(D)D
        //   445: goto            449
        //   448: athrow         
        //   449: d2f            
        //   450: ldc             90.0
        //   452: fsub           
        //   453: getstatic       dev/nuker/pyro/fc.c:I
        //   456: ifne            464
        //   459: ldc             -485617166
        //   461: goto            466
        //   464: ldc             2098175754
        //   466: ldc             -501871934
        //   468: ixor           
        //   469: lookupswitch {
        //          -1625713208: 496
        //          18357040: 464
        //          default: 1083
        //        }
        //   496: fstore          11
        //   498: getstatic       dev/nuker/pyro/fc.1:I
        //   501: ifne            509
        //   504: ldc             -980439968
        //   506: goto            511
        //   509: ldc             1498107983
        //   511: ldc             -2134611518
        //   513: ixor           
        //   514: lookupswitch {
        //          1162593698: 1095
        //          1842983667: 509
        //          default: 540
        //        }
        //   540: dload           5
        //   542: dload           9
        //   544: goto            548
        //   547: athrow         
        //   548: invokestatic    java/lang/Math.atan2:(DD)D
        //   551: goto            555
        //   554: athrow         
        //   555: goto            559
        //   558: athrow         
        //   559: invokestatic    java/lang/Math.toDegrees:(D)D
        //   562: goto            566
        //   565: athrow         
        //   566: dneg           
        //   567: d2f            
        //   568: fstore          12
        //   570: new             Lnet/minecraft/util/math/Vec2f;
        //   573: dup            
        //   574: getstatic       dev/nuker/pyro/fc.0:I
        //   577: ifgt            585
        //   580: ldc             954799017
        //   582: goto            587
        //   585: ldc             1804736017
        //   587: ldc             1791440032
        //   589: ixor           
        //   590: lookupswitch {
        //          22356657: 616
        //          1378756361: 585
        //          default: 1087
        //        }
        //   616: aload_0        
        //   617: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   620: getstatic       dev/nuker/pyro/fc.c:I
        //   623: ifne            631
        //   626: ldc             1051155908
        //   628: goto            633
        //   631: ldc             1982049334
        //   633: ldc             1125400560
        //   635: ixor           
        //   636: lookupswitch {
        //          892834758: 664
        //          2108908084: 631
        //          default: 1101
        //        }
        //   664: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   667: getstatic       dev/nuker/pyro/fc.c:I
        //   670: ifne            678
        //   673: ldc             -562952631
        //   675: goto            680
        //   678: ldc             -2109138191
        //   680: ldc             -390781082
        //   682: ixor           
        //   683: lookupswitch {
        //          919019823: 678
        //          1794915735: 708
        //          default: 1113
        //        }
        //   708: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70177_z:F
        //   711: fload           11
        //   713: aload_0        
        //   714: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   717: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   720: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70177_z:F
        //   723: fsub           
        //   724: getstatic       dev/nuker/pyro/fc.0:I
        //   727: ifgt            735
        //   730: ldc             -1740335876
        //   732: goto            737
        //   735: ldc             1947322431
        //   737: ldc             -1141253778
        //   739: ixor           
        //   740: lookupswitch {
        //          -89487016: 735
        //          599608722: 1097
        //          default: 768
        //        }
        //   768: goto            772
        //   771: athrow         
        //   772: invokestatic    net/minecraft/util/math/MathHelper.func_76142_g:(F)F
        //   775: goto            779
        //   778: athrow         
        //   779: fadd           
        //   780: getstatic       dev/nuker/pyro/fc.1:I
        //   783: ifne            791
        //   786: ldc             -416936064
        //   788: goto            793
        //   791: ldc             -94998892
        //   793: ldc             1863665013
        //   795: ixor           
        //   796: lookupswitch {
        //          -2009904395: 791
        //          -1790759967: 824
        //          default: 1103
        //        }
        //   824: aload_0        
        //   825: getstatic       dev/nuker/pyro/fc.1:I
        //   828: ifne            836
        //   831: ldc             -1240103829
        //   833: goto            838
        //   836: ldc             -1933503578
        //   838: ldc             270385692
        //   840: ixor           
        //   841: lookupswitch {
        //          -1663249990: 868
        //          -1509407113: 836
        //          default: 1109
        //        }
        //   868: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   871: getstatic       dev/nuker/pyro/fc.c:I
        //   874: ifne            882
        //   877: ldc             -2022934791
        //   879: goto            884
        //   882: ldc             529652059
        //   884: ldc             -523966962
        //   886: ixor           
        //   887: lookupswitch {
        //          1328322248: 882
        //          1739100407: 1099
        //          default: 912
        //        }
        //   912: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   915: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70125_A:F
        //   918: getstatic       dev/nuker/pyro/fc.0:I
        //   921: ifgt            929
        //   924: ldc             -145777520
        //   926: goto            931
        //   929: ldc             -1302115603
        //   931: ldc             -813266383
        //   933: ixor           
        //   934: lookupswitch {
        //          460493444: 929
        //          952702625: 1117
        //          default: 960
        //        }
        //   960: fload           12
        //   962: aload_0        
        //   963: getstatic       dev/nuker/pyro/fc.0:I
        //   966: ifgt            974
        //   969: ldc             1352610620
        //   971: goto            976
        //   974: ldc             -226022715
        //   976: ldc             1614424716
        //   978: ixor           
        //   979: lookupswitch {
        //          -1833107383: 1004
        //          816126384: 974
        //          default: 1085
        //        }
        //  1004: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //  1007: getstatic       dev/nuker/pyro/fc.c:I
        //  1010: ifne            1018
        //  1013: ldc             -824798819
        //  1015: goto            1020
        //  1018: ldc             -692227178
        //  1020: ldc             -2125174768
        //  1022: ixor           
        //  1023: lookupswitch {
        //          -1599837103: 1018
        //          1333983629: 1089
        //          default: 1048
        //        }
        //  1048: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1051: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70125_A:F
        //  1054: fsub           
        //  1055: goto            1059
        //  1058: athrow         
        //  1059: invokestatic    net/minecraft/util/math/MathHelper.func_76142_g:(F)F
        //  1062: goto            1066
        //  1065: athrow         
        //  1066: fadd           
        //  1067: goto            1071
        //  1070: athrow         
        //  1071: invokespecial   net/minecraft/util/math/Vec2f.<init>:(FF)V
        //  1074: goto            1078
        //  1077: athrow         
        //  1078: areturn        
        //  1079: aconst_null    
        //  1080: athrow         
        //  1081: aconst_null    
        //  1082: athrow         
        //  1083: aconst_null    
        //  1084: athrow         
        //  1085: aconst_null    
        //  1086: athrow         
        //  1087: aconst_null    
        //  1088: athrow         
        //  1089: aconst_null    
        //  1090: athrow         
        //  1091: aconst_null    
        //  1092: athrow         
        //  1093: aconst_null    
        //  1094: athrow         
        //  1095: aconst_null    
        //  1096: athrow         
        //  1097: aconst_null    
        //  1098: athrow         
        //  1099: aconst_null    
        //  1100: athrow         
        //  1101: aconst_null    
        //  1102: athrow         
        //  1103: aconst_null    
        //  1104: athrow         
        //  1105: aconst_null    
        //  1106: athrow         
        //  1107: aconst_null    
        //  1108: athrow         
        //  1109: aconst_null    
        //  1110: athrow         
        //  1111: aconst_null    
        //  1112: athrow         
        //  1113: aconst_null    
        //  1114: athrow         
        //  1115: aconst_null    
        //  1116: athrow         
        //  1117: aconst_null    
        //  1118: athrow         
        //  1119: pop            
        //  1120: goto            24
        //  1123: pop            
        //  1124: aconst_null    
        //  1125: goto            1119
        //  1128: dup            
        //  1129: ifnull          1119
        //  1132: checkcast       Ljava/lang/Throwable;
        //  1135: athrow         
        //  1136: dup            
        //  1137: ifnull          1123
        //  1140: checkcast       Ljava/lang/Throwable;
        //  1143: athrow         
        //  1144: aconst_null    
        //  1145: athrow         
        //    StackMapTable: 00 79 FF 00 03 00 06 07 00 03 07 00 1D 07 00 1D 03 03 03 00 01 07 00 1B F8 00 04 FF 00 0B 00 00 00 01 07 00 1B FE 00 03 07 00 03 07 00 1D 07 00 1D FC 00 18 03 41 01 1C 4B 07 00 1D FF 00 01 00 04 07 00 03 07 00 1D 07 00 1D 03 00 02 07 00 1D 01 5D 07 00 1D FC 00 14 03 41 01 1C 4B 07 00 1D FF 00 01 00 05 07 00 03 07 00 1D 07 00 1D 03 03 00 02 07 00 1D 01 5D 07 00 1D 4D 03 FF 00 01 00 05 07 00 03 07 00 1D 07 00 1D 03 03 00 02 03 01 5B 03 FF 00 16 00 06 07 00 03 07 00 1D 07 00 1D 03 03 03 00 02 03 03 FF 00 01 00 06 07 00 03 07 00 1D 07 00 1D 03 03 03 00 03 03 03 01 FF 00 1E 00 06 07 00 03 07 00 1D 07 00 1D 03 03 03 00 02 03 03 4E 03 FF 00 01 00 06 07 00 03 07 00 1D 07 00 1D 03 03 03 00 02 03 01 5E 03 FF 00 02 00 00 00 01 07 00 1B FF 00 00 00 06 07 00 03 07 00 1D 07 00 1D 03 03 03 00 01 03 45 07 00 1B 40 03 FC 00 0C 03 41 01 1D FF 00 05 00 00 00 01 07 00 1B FF 00 00 00 07 07 00 03 07 00 1D 07 00 1D 03 03 03 03 00 02 03 03 45 07 00 1B 40 03 42 07 00 0D 40 03 45 07 00 1B 40 03 4E 02 FF 00 01 00 07 07 00 03 07 00 1D 07 00 1D 03 03 03 03 00 02 02 01 5D 02 FC 00 0C 02 41 01 1C 46 07 00 13 FF 00 00 00 08 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 00 02 03 03 45 07 00 1B 40 03 42 07 00 11 40 03 45 07 00 1B 40 03 FF 00 12 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 02 08 02 3A 08 02 3A FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 03 08 02 3A 08 02 3A 01 FF 00 1C 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 02 08 02 3A 08 02 3A FF 00 0E 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 03 08 02 3A 08 02 3A 07 00 26 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 07 00 26 01 FF 00 1E 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 03 08 02 3A 08 02 3A 07 00 26 FF 00 0D 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 03 08 02 3A 08 02 3A 07 00 2C FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 07 00 2C 01 FF 00 1B 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 03 08 02 3A 08 02 3A 07 00 2C FF 00 1A 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 02 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 05 08 02 3A 08 02 3A 02 02 01 FF 00 1E 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 02 42 07 00 1B FF 00 00 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 02 45 07 00 1B FF 00 00 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 02 FF 00 0B 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 03 08 02 3A 08 02 3A 02 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 01 FF 00 1E 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 03 08 02 3A 08 02 3A 02 FF 00 0B 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 07 00 03 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 05 08 02 3A 08 02 3A 02 07 00 03 01 FF 00 1D 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 07 00 03 FF 00 0D 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 07 00 26 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 05 08 02 3A 08 02 3A 02 07 00 26 01 FF 00 1B 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 07 00 26 FF 00 10 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 02 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 05 08 02 3A 08 02 3A 02 02 01 FF 00 1C 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 02 FF 00 0D 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 06 08 02 3A 08 02 3A 02 02 02 07 00 03 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 07 08 02 3A 08 02 3A 02 02 02 07 00 03 01 FF 00 1B 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 06 08 02 3A 08 02 3A 02 02 02 07 00 03 FF 00 0D 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 06 08 02 3A 08 02 3A 02 02 02 07 00 26 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 07 08 02 3A 08 02 3A 02 02 02 07 00 26 01 FF 00 1B 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 06 08 02 3A 08 02 3A 02 02 02 07 00 26 49 07 00 1B FF 00 00 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 05 08 02 3A 08 02 3A 02 02 02 45 07 00 1B FF 00 00 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 05 08 02 3A 08 02 3A 02 02 02 43 07 00 13 FF 00 00 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 02 45 07 00 1B 40 07 00 9F FF 00 00 00 06 07 00 03 07 00 1D 07 00 1D 03 03 03 00 02 03 03 FF 00 01 00 05 07 00 03 07 00 1D 07 00 1D 03 03 00 01 03 FF 00 01 00 07 07 00 03 07 00 1D 07 00 1D 03 03 03 03 00 01 02 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 06 08 02 3A 08 02 3A 02 02 02 07 00 03 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 02 08 02 3A 08 02 3A FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 06 08 02 3A 08 02 3A 02 02 02 07 00 26 F9 00 01 F9 00 01 FE 00 01 03 03 02 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 02 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 07 00 26 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 03 08 02 3A 08 02 3A 07 00 26 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 03 08 02 3A 08 02 3A 02 FF 00 01 00 04 07 00 03 07 00 1D 07 00 1D 03 00 00 FF 00 01 00 05 07 00 03 07 00 1D 07 00 1D 03 03 00 01 07 00 1D FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 07 00 03 FF 00 01 00 04 07 00 03 07 00 1D 07 00 1D 03 00 01 07 00 1D FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 03 08 02 3A 08 02 3A 07 00 2C FF 00 01 00 06 07 00 03 07 00 1D 07 00 1D 03 03 03 00 01 03 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 02 FF 00 01 00 03 07 00 03 07 00 1D 07 00 1D 00 01 07 00 1B 43 05 44 07 00 1B 47 05 FF 00 07 00 06 07 00 03 07 00 1D 07 00 1D 03 03 03 00 01 07 00 1B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                      
        //  -----  -----  -----  -----  ------------------------------------------
        //  8      20     1128   1136   Any
        //  1128   1136   1128   1136   Any
        //  1144   1146   3      8      Ljava/util/NoSuchElementException;
        //  372    378    378    379    Any
        //  372    378    3      8      Any
        //  372    378    378    379    Any
        //  372    378    3      8      Any
        //  372    378    3      8      Any
        //  431    437    437    438    Any
        //  431    437    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  431    437    437    438    Any
        //  431    437    437    438    Ljava/lang/NullPointerException;
        //  431    437    437    438    Any
        //  441    448    448    449    Any
        //  442    448    3      8      Any
        //  441    448    441    442    Ljava/lang/NullPointerException;
        //  441    448    448    449    Any
        //  442    448    448    449    Ljava/lang/AssertionError;
        //  547    554    554    555    Any
        //  547    554    3      8      Any
        //  548    554    547    548    Ljava/lang/IllegalStateException;
        //  547    554    3      8      Any
        //  548    554    3      8      Any
        //  558    565    565    566    Any
        //  559    565    565    566    Any
        //  559    565    3      8      Any
        //  559    565    3      8      Ljava/lang/NumberFormatException;
        //  558    565    558    559    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  771    778    778    779    Any
        //  772    778    3      8      Ljava/lang/UnsupportedOperationException;
        //  772    778    771    772    Any
        //  772    778    771    772    Any
        //  771    778    771    772    Any
        //  1058   1065   1065   1066   Any
        //  1059   1065   1058   1059   Any
        //  1059   1065   1065   1066   Any
        //  1059   1065   1065   1066   Ljava/lang/UnsupportedOperationException;
        //  1058   1065   1058   1059   Ljava/lang/NegativeArraySizeException;
        //  1070   1077   1077   1078   Any
        //  1070   1077   1070   1071   Ljava/lang/IllegalStateException;
        //  1070   1077   3      8      Any
        //  1070   1077   3      8      Any
        //  1071   1077   3      8      Ljava/lang/IllegalStateException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visitVariable(StackMappingVisitor.java:470)
        //     at com.strobel.assembler.ir.Instruction.accept(Instruction.java:556)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:403)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @NotNull
    public Vec2f c(@NotNull final Vec3d p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          843
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            835
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            827
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: aload_0        
        //    27: getstatic       dev/nuker/pyro/fc.c:I
        //    30: ifne            38
        //    33: ldc             -791323636
        //    35: goto            40
        //    38: ldc             -964013337
        //    40: ldc             -2132724464
        //    42: ixor           
        //    43: lookupswitch {
        //          1181444087: 68
        //          1345612060: 38
        //          default: 794
        //        }
        //    68: goto            72
        //    71: athrow         
        //    72: invokevirtual   dev/nuker/pyro/fdU.c:()Lnet/minecraft/util/math/Vec3d;
        //    75: goto            79
        //    78: athrow         
        //    79: astore_2       
        //    80: aload_1        
        //    81: getfield        net/minecraft/util/math/Vec3d.field_72450_a:D
        //    84: aload_2        
        //    85: getfield        net/minecraft/util/math/Vec3d.field_72450_a:D
        //    88: dsub           
        //    89: dstore_3       
        //    90: aload_1        
        //    91: getfield        net/minecraft/util/math/Vec3d.field_72448_b:D
        //    94: aload_2        
        //    95: getfield        net/minecraft/util/math/Vec3d.field_72448_b:D
        //    98: dsub           
        //    99: dstore          5
        //   101: aload_1        
        //   102: getfield        net/minecraft/util/math/Vec3d.field_72449_c:D
        //   105: getstatic       dev/nuker/pyro/fc.1:I
        //   108: ifne            116
        //   111: ldc             -919780281
        //   113: goto            118
        //   116: ldc             1751376790
        //   118: ldc             -316577214
        //   120: ixor           
        //   121: lookupswitch {
        //          604777989: 804
        //          680020285: 116
        //          default: 148
        //        }
        //   148: aload_2        
        //   149: getfield        net/minecraft/util/math/Vec3d.field_72449_c:D
        //   152: dsub           
        //   153: getstatic       dev/nuker/pyro/fc.c:I
        //   156: ifne            164
        //   159: ldc             -137479400
        //   161: goto            166
        //   164: ldc             -555244212
        //   166: ldc             -1429238342
        //   168: ixor           
        //   169: lookupswitch {
        //          1560393378: 816
        //          1980416112: 164
        //          default: 196
        //        }
        //   196: dstore          7
        //   198: dload_3        
        //   199: dload_3        
        //   200: dmul           
        //   201: dload           7
        //   203: dload           7
        //   205: dmul           
        //   206: dadd           
        //   207: goto            211
        //   210: athrow         
        //   211: invokestatic    java/lang/Math.sqrt:(D)D
        //   214: goto            218
        //   217: athrow         
        //   218: dstore          9
        //   220: dload           7
        //   222: dload_3        
        //   223: goto            227
        //   226: athrow         
        //   227: invokestatic    java/lang/Math.atan2:(DD)D
        //   230: goto            234
        //   233: athrow         
        //   234: getstatic       dev/nuker/pyro/fc.1:I
        //   237: ifne            245
        //   240: ldc             855667669
        //   242: goto            247
        //   245: ldc             -1623754490
        //   247: ldc             -614237895
        //   249: ixor           
        //   250: lookupswitch {
        //          -396162324: 245
        //          1146355775: 276
        //          default: 810
        //        }
        //   276: goto            280
        //   279: athrow         
        //   280: invokestatic    java/lang/Math.toDegrees:(D)D
        //   283: goto            287
        //   286: athrow         
        //   287: d2f            
        //   288: ldc             90.0
        //   290: fsub           
        //   291: getstatic       dev/nuker/pyro/fc.0:I
        //   294: ifgt            302
        //   297: ldc             1657690910
        //   299: goto            304
        //   302: ldc             1798819297
        //   304: ldc             2107429813
        //   306: ixor           
        //   307: lookupswitch {
        //          380313172: 332
        //          525502635: 302
        //          default: 808
        //        }
        //   332: fstore          11
        //   334: dload           5
        //   336: dload           9
        //   338: goto            342
        //   341: athrow         
        //   342: invokestatic    java/lang/Math.atan2:(DD)D
        //   345: goto            349
        //   348: athrow         
        //   349: getstatic       dev/nuker/pyro/fc.c:I
        //   352: ifne            360
        //   355: ldc             -2144781937
        //   357: goto            362
        //   360: ldc             1063211134
        //   362: ldc             1710746498
        //   364: ixor           
        //   365: lookupswitch {
        //          -1636441523: 360
        //          -438382067: 802
        //          default: 392
        //        }
        //   392: goto            396
        //   395: athrow         
        //   396: invokestatic    java/lang/Math.toDegrees:(D)D
        //   399: goto            403
        //   402: athrow         
        //   403: dneg           
        //   404: d2f            
        //   405: fstore          12
        //   407: new             Lnet/minecraft/util/math/Vec2f;
        //   410: dup            
        //   411: aload_0        
        //   412: getstatic       dev/nuker/pyro/fc.0:I
        //   415: ifgt            423
        //   418: ldc             -42262078
        //   420: goto            425
        //   423: ldc             -1801114273
        //   425: ldc             -794355101
        //   427: ixor           
        //   428: lookupswitch {
        //          -2130861316: 423
        //          769407905: 814
        //          default: 456
        //        }
        //   456: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   459: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   462: getstatic       dev/nuker/pyro/fc.c:I
        //   465: ifne            473
        //   468: ldc             917291580
        //   470: goto            475
        //   473: ldc             727862329
        //   475: ldc             -1320027292
        //   477: ixor           
        //   478: lookupswitch {
        //          -2013447848: 798
        //          1780624096: 473
        //          default: 504
        //        }
        //   504: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70177_z:F
        //   507: fload           11
        //   509: aload_0        
        //   510: getstatic       dev/nuker/pyro/fc.1:I
        //   513: ifne            521
        //   516: ldc             -789320404
        //   518: goto            523
        //   521: ldc             448211909
        //   523: ldc             588142610
        //   525: ixor           
        //   526: lookupswitch {
        //          -201476802: 806
        //          540839370: 521
        //          default: 552
        //        }
        //   552: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   555: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   558: getstatic       dev/nuker/pyro/fc.0:I
        //   561: ifgt            569
        //   564: ldc             87157235
        //   566: goto            571
        //   569: ldc             -100194318
        //   571: ldc             -540142970
        //   573: ixor           
        //   574: lookupswitch {
        //          -620758155: 792
        //          -465800924: 569
        //          default: 600
        //        }
        //   600: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70177_z:F
        //   603: fsub           
        //   604: goto            608
        //   607: athrow         
        //   608: invokestatic    net/minecraft/util/math/MathHelper.func_76142_g:(F)F
        //   611: goto            615
        //   614: athrow         
        //   615: fadd           
        //   616: aload_0        
        //   617: getstatic       dev/nuker/pyro/fc.0:I
        //   620: ifgt            628
        //   623: ldc             -1740365134
        //   625: goto            630
        //   628: ldc             258129624
        //   630: ldc             512256368
        //   632: ixor           
        //   633: lookupswitch {
        //          -2033431614: 628
        //          300603304: 660
        //          default: 800
        //        }
        //   660: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   663: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   666: getstatic       dev/nuker/pyro/fc.1:I
        //   669: ifne            677
        //   672: ldc             -2023736082
        //   674: goto            679
        //   677: ldc             -932644802
        //   679: ldc             -1490576045
        //   681: ixor           
        //   682: lookupswitch {
        //          -1932210750: 677
        //          541565373: 812
        //          default: 708
        //        }
        //   708: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70125_A:F
        //   711: fload           12
        //   713: aload_0        
        //   714: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   717: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   720: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70125_A:F
        //   723: fsub           
        //   724: goto            728
        //   727: athrow         
        //   728: invokestatic    net/minecraft/util/math/MathHelper.func_76142_g:(F)F
        //   731: goto            735
        //   734: athrow         
        //   735: fadd           
        //   736: getstatic       dev/nuker/pyro/fc.1:I
        //   739: ifne            747
        //   742: ldc             -1817531754
        //   744: goto            749
        //   747: ldc             646129833
        //   749: ldc             -241321969
        //   751: ixor           
        //   752: lookupswitch {
        //          445817981: 747
        //          1647776409: 796
        //          default: 780
        //        }
        //   780: goto            784
        //   783: athrow         
        //   784: invokespecial   net/minecraft/util/math/Vec2f.<init>:(FF)V
        //   787: goto            791
        //   790: athrow         
        //   791: areturn        
        //   792: aconst_null    
        //   793: athrow         
        //   794: aconst_null    
        //   795: athrow         
        //   796: aconst_null    
        //   797: athrow         
        //   798: aconst_null    
        //   799: athrow         
        //   800: aconst_null    
        //   801: athrow         
        //   802: aconst_null    
        //   803: athrow         
        //   804: aconst_null    
        //   805: athrow         
        //   806: aconst_null    
        //   807: athrow         
        //   808: aconst_null    
        //   809: athrow         
        //   810: aconst_null    
        //   811: athrow         
        //   812: aconst_null    
        //   813: athrow         
        //   814: aconst_null    
        //   815: athrow         
        //   816: aconst_null    
        //   817: athrow         
        //   818: pop            
        //   819: goto            24
        //   822: pop            
        //   823: aconst_null    
        //   824: goto            818
        //   827: dup            
        //   828: ifnull          818
        //   831: checkcast       Ljava/lang/Throwable;
        //   834: athrow         
        //   835: dup            
        //   836: ifnull          822
        //   839: checkcast       Ljava/lang/Throwable;
        //   842: athrow         
        //   843: aconst_null    
        //   844: athrow         
        //    StackMapTable: 00 61 FF 00 03 00 06 07 00 03 07 00 1D 07 00 1D 03 03 03 00 01 07 00 1B FF 00 04 00 02 07 00 03 07 00 1D 00 00 FF 00 0B 00 00 00 01 07 00 1B FD 00 03 07 00 03 07 00 1D 4D 07 00 03 FF 00 01 00 02 07 00 03 07 00 1D 00 02 07 00 03 01 5B 07 00 03 42 07 00 1B 40 07 00 03 45 07 00 1B 40 07 00 1D FF 00 24 00 05 07 00 03 07 00 1D 07 00 1D 03 03 00 01 03 FF 00 01 00 05 07 00 03 07 00 1D 07 00 1D 03 03 00 02 03 01 5D 03 4F 03 FF 00 01 00 05 07 00 03 07 00 1D 07 00 1D 03 03 00 02 03 01 5D 03 FF 00 0D 00 06 07 00 03 07 00 1D 07 00 1D 03 03 03 00 01 07 00 55 40 03 45 07 00 1B 40 03 FF 00 07 00 07 07 00 03 07 00 1D 07 00 1D 03 03 03 03 00 01 07 00 1B FF 00 00 00 07 07 00 03 07 00 1D 07 00 1D 03 03 03 03 00 02 03 03 45 07 00 1B 40 03 4A 03 FF 00 01 00 07 07 00 03 07 00 1D 07 00 1D 03 03 03 03 00 02 03 01 5C 03 42 07 00 1B 40 03 45 07 00 1B 40 03 4E 02 FF 00 01 00 07 07 00 03 07 00 1D 07 00 1D 03 03 03 03 00 02 02 01 5B 02 FF 00 08 00 00 00 01 07 00 1B FF 00 00 00 08 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 00 02 03 03 45 07 00 1B 40 03 4A 03 FF 00 01 00 08 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 00 02 03 01 5D 03 42 07 00 66 40 03 45 07 00 1B 40 03 FF 00 13 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 03 08 01 97 08 01 97 07 00 03 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 01 97 08 01 97 07 00 03 01 FF 00 1E 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 03 08 01 97 08 01 97 07 00 03 FF 00 10 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 03 08 01 97 08 01 97 07 00 2C FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 01 97 08 01 97 07 00 2C 01 FF 00 1C 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 03 08 01 97 08 01 97 07 00 2C FF 00 10 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 05 08 01 97 08 01 97 02 02 07 00 03 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 06 08 01 97 08 01 97 02 02 07 00 03 01 FF 00 1C 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 05 08 01 97 08 01 97 02 02 07 00 03 FF 00 10 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 05 08 01 97 08 01 97 02 02 07 00 2C FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 06 08 01 97 08 01 97 02 02 07 00 2C 01 FF 00 1C 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 05 08 01 97 08 01 97 02 02 07 00 2C 46 07 00 1B FF 00 00 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 01 97 08 01 97 02 02 45 07 00 1B FF 00 00 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 01 97 08 01 97 02 02 FF 00 0C 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 01 97 08 01 97 02 07 00 03 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 05 08 01 97 08 01 97 02 07 00 03 01 FF 00 1D 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 01 97 08 01 97 02 07 00 03 FF 00 10 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 01 97 08 01 97 02 07 00 2C FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 05 08 01 97 08 01 97 02 07 00 2C 01 FF 00 1C 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 01 97 08 01 97 02 07 00 2C 52 07 00 1B FF 00 00 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 05 08 01 97 08 01 97 02 02 02 45 07 00 1B FF 00 00 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 05 08 01 97 08 01 97 02 02 02 FF 00 0B 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 01 97 08 01 97 02 02 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 05 08 01 97 08 01 97 02 02 01 FF 00 1E 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 01 97 08 01 97 02 02 42 07 00 1B FF 00 00 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 01 97 08 01 97 02 02 45 07 00 1B 40 07 00 9F FF 00 00 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 05 08 01 97 08 01 97 02 02 07 00 2C FF 00 01 00 02 07 00 03 07 00 1D 00 01 07 00 03 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 01 97 08 01 97 02 02 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 03 08 01 97 08 01 97 07 00 2C FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 01 97 08 01 97 02 07 00 03 FF 00 01 00 08 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 00 01 03 FF 00 01 00 05 07 00 03 07 00 1D 07 00 1D 03 03 00 01 03 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 05 08 01 97 08 01 97 02 02 07 00 03 FF 00 01 00 07 07 00 03 07 00 1D 07 00 1D 03 03 03 03 00 01 02 41 03 FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 04 08 01 97 08 01 97 02 07 00 2C FF 00 01 00 09 07 00 03 07 00 1D 07 00 1D 03 03 03 03 02 02 00 03 08 01 97 08 01 97 07 00 03 FF 00 01 00 05 07 00 03 07 00 1D 07 00 1D 03 03 00 01 03 FF 00 01 00 02 07 00 03 07 00 1D 00 01 07 00 1B 43 05 44 07 00 1B 47 05 FF 00 07 00 06 07 00 03 07 00 1D 07 00 1D 03 03 03 00 01 07 00 1B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     827    835    Any
        //  827    835    827    835    Ljava/lang/IndexOutOfBoundsException;
        //  843    845    3      8      Any
        //  71     78     78     79     Any
        //  71     78     71     72     Ljava/lang/NegativeArraySizeException;
        //  72     78     71     72     Any
        //  71     78     71     72     Ljava/lang/RuntimeException;
        //  71     78     78     79     Any
        //  210    217    217    218    Any
        //  210    217    3      8      Any
        //  211    217    3      8      Ljava/lang/ClassCastException;
        //  210    217    210    211    Ljava/util/NoSuchElementException;
        //  211    217    210    211    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  226    233    233    234    Any
        //  226    233    226    227    Any
        //  227    233    226    227    Any
        //  227    233    233    234    Ljava/lang/NullPointerException;
        //  227    233    233    234    Any
        //  279    286    286    287    Any
        //  279    286    279    280    Any
        //  279    286    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  280    286    286    287    Any
        //  279    286    279    280    Any
        //  342    348    348    349    Any
        //  342    348    3      8      Ljava/lang/NullPointerException;
        //  342    348    3      8      Any
        //  342    348    348    349    Ljava/lang/ClassCastException;
        //  342    348    348    349    Any
        //  395    402    402    403    Any
        //  396    402    402    403    Ljava/lang/ClassCastException;
        //  396    402    402    403    Any
        //  395    402    395    396    Ljava/lang/UnsupportedOperationException;
        //  395    402    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  607    614    614    615    Any
        //  608    614    614    615    Ljava/lang/AssertionError;
        //  607    614    614    615    Any
        //  607    614    607    608    Any
        //  607    614    614    615    Any
        //  727    734    734    735    Any
        //  728    734    3      8      Ljava/lang/NegativeArraySizeException;
        //  728    734    727    728    Any
        //  728    734    727    728    Any
        //  728    734    734    735    Any
        //  783    790    790    791    Any
        //  784    790    783    784    Any
        //  784    790    783    784    Any
        //  783    790    790    791    Any
        //  784    790    3      8      Ljava/lang/IllegalStateException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:617)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public fdU(@NotNull final Minecraft c) {
        while (true) {
            int n = 0;
            Label_0015: {
                if (fc.1 == 0) {
                    n = 1334054876;
                    break Label_0015;
                }
                n = -1369864653;
            }
            switch (n ^ 0x20CB092F) {
                case 1867450099: {
                    continue;
                }
                case -1902997732: {
                    while (true) {
                        int n2 = 0;
                        Label_0065: {
                            if (fc.1 == 0) {
                                n2 = 511565640;
                                break Label_0065;
                            }
                            n2 = -1574196251;
                        }
                        switch (n2 ^ 0x17DF319B) {
                            case -1998372652: {
                                continue;
                            }
                            default: {
                                this.c = c;
                                return;
                            }
                            case 161672915: {
                                throw null;
                            }
                        }
                        break;
                    }
                    break;
                }
                default: {
                    throw null;
                }
            }
            break;
        }
    }
    
    @NotNull
    public IBlockState c(@Nullable final BlockPos p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          71
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            63
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            55
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_0        
        //    25: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //    28: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //    31: aload_1        
        //    32: goto            36
        //    35: athrow         
        //    36: invokevirtual   net/minecraft/client/multiplayer/WorldClient.func_180495_p:(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
        //    39: goto            43
        //    42: athrow         
        //    43: dup            
        //    44: pop            
        //    45: areturn        
        //    46: pop            
        //    47: goto            24
        //    50: pop            
        //    51: aconst_null    
        //    52: goto            46
        //    55: dup            
        //    56: ifnull          46
        //    59: checkcast       Ljava/lang/Throwable;
        //    62: athrow         
        //    63: dup            
        //    64: ifnull          50
        //    67: checkcast       Ljava/lang/Throwable;
        //    70: athrow         
        //    71: aconst_null    
        //    72: athrow         
        //    StackMapTable: 00 0D 43 07 00 1B 04 FF 00 0B 00 00 00 01 07 00 1B FD 00 03 07 00 03 07 01 16 4A 07 00 1B FF 00 00 00 02 07 00 03 07 01 16 00 02 07 01 11 07 01 16 45 07 00 1B 40 07 01 18 42 07 00 55 43 05 44 07 00 55 47 05 47 07 00 1B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     55     63     Ljava/lang/NumberFormatException;
        //  55     63     55     63     Ljava/lang/ArithmeticException;
        //  71     73     3      8      Ljava/lang/ArithmeticException;
        //  35     42     42     43     Any
        //  35     42     3      8      Any
        //  36     42     3      8      Ljava/lang/RuntimeException;
        //  36     42     35     36     Ljava/lang/StringIndexOutOfBoundsException;
        //  36     42     35     36     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 37 out of bounds for length 37
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Nullable
    public EnumFacing 1(@Nullable final BlockPos p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          494
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            486
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            478
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: getstatic       net/minecraft/util/EnumFacing.field_82609_l:[Lnet/minecraft/util/EnumFacing;
        //    27: getstatic       dev/nuker/pyro/fc.c:I
        //    30: ifne            39
        //    33: ldc_w           2051188320
        //    36: goto            42
        //    39: ldc_w           -1368773374
        //    42: ldc_w           -47503947
        //    45: ixor           
        //    46: lookupswitch {
        //          -2023128107: 457
        //          -1125619893: 39
        //          default: 72
        //        }
        //    72: astore          4
        //    74: getstatic       dev/nuker/pyro/fc.c:I
        //    77: ifne            86
        //    80: ldc_w           1441906013
        //    83: goto            89
        //    86: ldc_w           -1801701168
        //    89: ldc_w           434177529
        //    92: ixor           
        //    93: lookupswitch {
        //          649864648: 86
        //          1276164260: 467
        //          default: 120
        //        }
        //   120: aload           4
        //   122: arraylength    
        //   123: istore          5
        //   125: iconst_0       
        //   126: getstatic       dev/nuker/pyro/fc.c:I
        //   129: ifne            138
        //   132: ldc_w           1224030017
        //   135: goto            141
        //   138: ldc_w           -1821356208
        //   141: ldc_w           -298293880
        //   144: ixor           
        //   145: lookupswitch {
        //          -1826809026: 138
        //          -1496493367: 461
        //          default: 172
        //        }
        //   172: istore_3       
        //   173: iload_3        
        //   174: iload           5
        //   176: if_icmpge       455
        //   179: aload           4
        //   181: getstatic       dev/nuker/pyro/fc.1:I
        //   184: ifne            193
        //   187: ldc_w           -1416809293
        //   190: goto            196
        //   193: ldc_w           -515154913
        //   196: ldc_w           -591827649
        //   199: ixor           
        //   200: lookupswitch {
        //          1039282464: 228
        //          1999919500: 193
        //          default: 465
        //        }
        //   228: iload_3        
        //   229: aaload         
        //   230: astore_2       
        //   231: aload_0        
        //   232: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   235: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //   238: new             Lnet/minecraft/util/math/Vec3d;
        //   241: dup            
        //   242: aload_0        
        //   243: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   246: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   249: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70165_t:D
        //   252: aload_0        
        //   253: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   256: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   259: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70163_u:D
        //   262: aload_0        
        //   263: getstatic       dev/nuker/pyro/fc.1:I
        //   266: ifne            275
        //   269: ldc_w           -511104798
        //   272: goto            278
        //   275: ldc_w           300341410
        //   278: ldc_w           1715318094
        //   281: ixor           
        //   282: lookupswitch {
        //          -2018212436: 459
        //          -1993811462: 275
        //          default: 308
        //        }
        //   308: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   311: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   314: goto            318
        //   317: athrow         
        //   318: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_70047_e:()F
        //   321: goto            325
        //   324: athrow         
        //   325: f2d            
        //   326: dadd           
        //   327: aload_0        
        //   328: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   331: getstatic       dev/nuker/pyro/fc.c:I
        //   334: ifne            343
        //   337: ldc_w           1423984994
        //   340: goto            346
        //   343: ldc_w           679081104
        //   346: ldc_w           -1419945581
        //   349: ixor           
        //   350: lookupswitch {
        //          -2094748413: 376
        //          -4386575: 343
        //          default: 463
        //        }
        //   376: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   379: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70161_v:D
        //   382: goto            386
        //   385: athrow         
        //   386: invokespecial   net/minecraft/util/math/Vec3d.<init>:(DDD)V
        //   389: goto            393
        //   392: athrow         
        //   393: aload_0        
        //   394: aload_1        
        //   395: aload_0        
        //   396: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   399: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //   402: dup            
        //   403: pop            
        //   404: checkcast       Lnet/minecraft/world/World;
        //   407: aload_2        
        //   408: dup            
        //   409: pop            
        //   410: goto            414
        //   413: athrow         
        //   414: invokevirtual   dev/nuker/pyro/fdU.c:(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/world/World;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/Vec3d;
        //   417: goto            421
        //   420: athrow         
        //   421: iconst_0       
        //   422: iconst_1       
        //   423: iconst_0       
        //   424: goto            428
        //   427: athrow         
        //   428: invokevirtual   net/minecraft/client/multiplayer/WorldClient.func_147447_a:(Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;ZZZ)Lnet/minecraft/util/math/RayTraceResult;
        //   431: goto            435
        //   434: athrow         
        //   435: dup            
        //   436: ifnull          442
        //   439: goto            445
        //   442: pop            
        //   443: aload_2        
        //   444: areturn        
        //   445: dup            
        //   446: pop            
        //   447: astore          6
        //   449: iinc            3, 1
        //   452: goto            173
        //   455: aconst_null    
        //   456: areturn        
        //   457: aconst_null    
        //   458: athrow         
        //   459: aconst_null    
        //   460: athrow         
        //   461: aconst_null    
        //   462: athrow         
        //   463: aconst_null    
        //   464: athrow         
        //   465: aconst_null    
        //   466: athrow         
        //   467: aconst_null    
        //   468: athrow         
        //   469: pop            
        //   470: goto            24
        //   473: pop            
        //   474: aconst_null    
        //   475: goto            469
        //   478: dup            
        //   479: ifnull          469
        //   482: checkcast       Ljava/lang/Throwable;
        //   485: athrow         
        //   486: dup            
        //   487: ifnull          473
        //   490: checkcast       Ljava/lang/Throwable;
        //   493: athrow         
        //   494: aconst_null    
        //   495: athrow         
        //    StackMapTable: 00 35 FF 00 03 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 01 07 00 1B FF 00 04 00 02 07 00 03 07 01 16 00 00 FF 00 0B 00 00 00 01 07 00 1B FD 00 03 07 00 03 07 01 16 4E 07 01 3D FF 00 02 00 02 07 00 03 07 01 16 00 02 07 01 3D 01 5D 07 01 3D FE 00 0D 00 00 07 01 3D 42 01 1E FF 00 11 00 06 07 00 03 07 01 16 00 00 07 01 3D 01 00 01 01 FF 00 02 00 06 07 00 03 07 01 16 00 00 07 01 3D 01 00 02 01 01 5E 01 FF 00 00 00 06 07 00 03 07 01 16 00 01 07 01 3D 01 00 00 53 07 01 3D FF 00 02 00 06 07 00 03 07 01 16 00 01 07 01 3D 01 00 02 07 01 3D 01 5F 07 01 3D FF 00 2E 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 06 07 01 11 08 00 EE 08 00 EE 03 03 07 00 03 FF 00 02 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 07 07 01 11 08 00 EE 08 00 EE 03 03 07 00 03 01 FF 00 1D 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 06 07 01 11 08 00 EE 08 00 EE 03 03 07 00 03 48 07 00 1B FF 00 00 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 06 07 01 11 08 00 EE 08 00 EE 03 03 07 00 2C 45 07 00 1B FF 00 00 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 06 07 01 11 08 00 EE 08 00 EE 03 03 02 FF 00 11 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 06 07 01 11 08 00 EE 08 00 EE 03 03 07 00 26 FF 00 02 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 07 07 01 11 08 00 EE 08 00 EE 03 03 07 00 26 01 FF 00 1D 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 06 07 01 11 08 00 EE 08 00 EE 03 03 07 00 26 48 07 00 1B FF 00 00 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 06 07 01 11 08 00 EE 08 00 EE 03 03 03 45 07 00 1B FF 00 00 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 02 07 01 11 07 00 1D 53 07 00 1B FF 00 00 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 06 07 01 11 07 00 1D 07 00 03 07 01 16 07 01 35 07 01 1D 45 07 00 1B FF 00 00 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 03 07 01 11 07 00 1D 07 00 1D FF 00 05 00 00 00 01 07 00 1B FF 00 00 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 06 07 01 11 07 00 1D 07 00 1D 01 01 01 45 07 00 1B 40 07 01 3F 46 07 01 3F 42 07 01 3F FF 00 09 00 06 07 00 03 07 01 16 00 01 07 01 3D 01 00 00 FF 00 01 00 02 07 00 03 07 01 16 00 01 07 01 3D FF 00 01 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 06 07 01 11 08 00 EE 08 00 EE 03 03 07 00 03 FF 00 01 00 06 07 00 03 07 01 16 00 00 07 01 3D 01 00 01 01 FF 00 01 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 06 07 01 11 08 00 EE 08 00 EE 03 03 07 00 26 FF 00 01 00 06 07 00 03 07 01 16 00 01 07 01 3D 01 00 01 07 01 3D FF 00 01 00 05 07 00 03 07 01 16 00 00 07 01 3D 00 00 FF 00 01 00 02 07 00 03 07 01 16 00 01 07 00 1B 43 05 44 07 00 1B 47 05 FF 00 07 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 01 07 00 1B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     478    486    Any
        //  478    486    478    486    Ljava/util/ConcurrentModificationException;
        //  494    496    3      8      Ljava/lang/NullPointerException;
        //  317    324    324    325    Any
        //  317    324    317    318    Ljava/lang/IllegalStateException;
        //  318    324    317    318    Any
        //  317    324    3      8      Any
        //  318    324    324    325    Any
        //  385    392    392    393    Any
        //  385    392    385    386    Any
        //  385    392    392    393    Any
        //  385    392    3      8      Ljava/lang/UnsupportedOperationException;
        //  386    392    3      8      Any
        //  413    420    420    421    Any
        //  413    420    413    414    Ljava/lang/NumberFormatException;
        //  413    420    413    414    Any
        //  414    420    413    414    Ljava/lang/NumberFormatException;
        //  413    420    3      8      Any
        //  428    434    434    435    Any
        //  428    434    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  428    434    3      8      Any
        //  428    434    3      8      Any
        //  428    434    434    435    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:586)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Nullable
    public Tuple 3(@NotNull final BlockPos p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          525
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            517
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            509
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: goto            30
        //    29: athrow         
        //    30: invokestatic    net/minecraft/util/EnumFacing.values:()[Lnet/minecraft/util/EnumFacing;
        //    33: goto            37
        //    36: athrow         
        //    37: astore          4
        //    39: aload           4
        //    41: arraylength    
        //    42: istore          5
        //    44: iconst_0       
        //    45: istore_3       
        //    46: iload_3        
        //    47: getstatic       dev/nuker/pyro/fc.0:I
        //    50: ifgt            59
        //    53: ldc_w           -552182534
        //    56: goto            62
        //    59: ldc_w           359961773
        //    62: ldc_w           1737502408
        //    65: ixor           
        //    66: lookupswitch {
        //          -1199148494: 498
        //          -759374275: 59
        //          default: 92
        //        }
        //    92: iload           5
        //    94: if_icmpge       103
        //    97: ldc_w           987706238
        //   100: goto            106
        //   103: ldc_w           987706237
        //   106: ldc_w           1298648351
        //   109: ixor           
        //   110: tableswitch {
        //          -277742398: 132
        //          -277742397: 484
        //          default: 97
        //        }
        //   132: aload           4
        //   134: iload_3        
        //   135: aaload         
        //   136: getstatic       dev/nuker/pyro/fc.c:I
        //   139: ifne            148
        //   142: ldc_w           -1586320736
        //   145: goto            151
        //   148: ldc_w           299200846
        //   151: ldc_w           1075135811
        //   154: ixor           
        //   155: lookupswitch {
        //          -1641913784: 148
        //          -513282077: 486
        //          default: 180
        //        }
        //   180: astore_2       
        //   181: aload_1        
        //   182: getstatic       dev/nuker/pyro/fc.1:I
        //   185: ifne            194
        //   188: ldc_w           -1896755962
        //   191: goto            197
        //   194: ldc_w           90637338
        //   197: ldc_w           1107519895
        //   200: ixor           
        //   201: lookupswitch {
        //          -856513391: 488
        //          1583131371: 194
        //          default: 228
        //        }
        //   228: aload_2        
        //   229: getstatic       dev/nuker/pyro/fc.0:I
        //   232: ifgt            241
        //   235: ldc_w           1014006315
        //   238: goto            244
        //   241: ldc_w           840355189
        //   244: ldc_w           793565435
        //   247: ixor           
        //   248: lookupswitch {
        //          -1989205570: 241
        //          322722512: 492
        //          default: 276
        //        }
        //   276: goto            280
        //   279: athrow         
        //   280: invokevirtual   net/minecraft/util/math/BlockPos.func_177972_a:(Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/BlockPos;
        //   283: goto            287
        //   286: athrow         
        //   287: astore          6
        //   289: aload_2        
        //   290: goto            294
        //   293: athrow         
        //   294: invokevirtual   net/minecraft/util/EnumFacing.func_176734_d:()Lnet/minecraft/util/EnumFacing;
        //   297: goto            301
        //   300: athrow         
        //   301: getstatic       dev/nuker/pyro/fc.c:I
        //   304: ifne            313
        //   307: ldc_w           -743791549
        //   310: goto            316
        //   313: ldc_w           -685255466
        //   316: ldc_w           1360619309
        //   319: ixor           
        //   320: lookupswitch {
        //          -2102148242: 490
        //          -145072122: 313
        //          default: 348
        //        }
        //   348: astore          7
        //   350: getstatic       dev/nuker/pyro/fc.0:I
        //   353: ifgt            362
        //   356: ldc_w           -1972823787
        //   359: goto            365
        //   362: ldc_w           187386890
        //   365: ldc_w           1911449199
        //   368: ixor           
        //   369: lookupswitch {
        //          -75006086: 496
        //          644749583: 362
        //          default: 396
        //        }
        //   396: aload_0        
        //   397: aload           6
        //   399: getstatic       dev/nuker/pyro/fc.0:I
        //   402: ifgt            411
        //   405: ldc_w           1445541043
        //   408: goto            414
        //   411: ldc_w           1489210816
        //   414: ldc_w           -1245746201
        //   417: ixor           
        //   418: lookupswitch {
        //          -476684460: 494
        //          1182656157: 411
        //          default: 444
        //        }
        //   444: goto            448
        //   447: athrow         
        //   448: invokevirtual   dev/nuker/pyro/fdU.2:(Lnet/minecraft/util/math/BlockPos;)Z
        //   451: goto            455
        //   454: athrow         
        //   455: ifeq            478
        //   458: new             Lnet/minecraft/util/Tuple;
        //   461: dup            
        //   462: aload           6
        //   464: aload           7
        //   466: goto            470
        //   469: athrow         
        //   470: invokespecial   net/minecraft/util/Tuple.<init>:(Ljava/lang/Object;Ljava/lang/Object;)V
        //   473: goto            477
        //   476: athrow         
        //   477: areturn        
        //   478: iinc            3, 1
        //   481: goto            46
        //   484: aconst_null    
        //   485: areturn        
        //   486: aconst_null    
        //   487: athrow         
        //   488: aconst_null    
        //   489: athrow         
        //   490: aconst_null    
        //   491: athrow         
        //   492: aconst_null    
        //   493: athrow         
        //   494: aconst_null    
        //   495: athrow         
        //   496: aconst_null    
        //   497: athrow         
        //   498: aconst_null    
        //   499: athrow         
        //   500: pop            
        //   501: goto            24
        //   504: pop            
        //   505: aconst_null    
        //   506: goto            500
        //   509: dup            
        //   510: ifnull          500
        //   513: checkcast       Ljava/lang/Throwable;
        //   516: athrow         
        //   517: dup            
        //   518: ifnull          504
        //   521: checkcast       Ljava/lang/Throwable;
        //   524: athrow         
        //   525: aconst_null    
        //   526: athrow         
        //    StackMapTable: 00 40 43 07 00 1B 04 FF 00 0B 00 00 00 01 07 00 1B FD 00 03 07 00 03 07 01 16 FF 00 04 00 00 00 01 07 00 1B FD 00 00 07 00 03 07 01 16 45 07 00 1B 40 07 01 3D FF 00 08 00 06 07 00 03 07 01 16 00 01 07 01 3D 01 00 00 4C 01 FF 00 02 00 06 07 00 03 07 01 16 00 01 07 01 3D 01 00 02 01 01 5D 01 04 05 42 01 19 4F 07 01 1D FF 00 02 00 06 07 00 03 07 01 16 00 01 07 01 3D 01 00 02 07 01 1D 01 5C 07 01 1D FF 00 0D 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 01 07 01 16 FF 00 02 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 02 07 01 16 01 5E 07 01 16 FF 00 0C 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 02 07 01 16 07 01 1D FF 00 02 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 03 07 01 16 07 01 1D 01 FF 00 1F 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 02 07 01 16 07 01 1D FF 00 02 00 00 00 01 07 00 1B FF 00 00 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 02 07 01 16 07 01 1D 45 07 00 1B 40 07 01 16 FF 00 05 00 07 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 07 01 16 00 01 07 00 1B 40 07 01 1D 45 07 00 1B 40 07 01 1D 4B 07 01 1D FF 00 02 00 07 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 07 01 16 00 02 07 01 1D 01 5F 07 01 1D FC 00 0D 07 01 1D 42 01 1E FF 00 0E 00 08 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 07 01 16 07 01 1D 00 02 07 00 03 07 01 16 FF 00 02 00 08 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 07 01 16 07 01 1D 00 03 07 00 03 07 01 16 01 FF 00 1D 00 08 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 07 01 16 07 01 1D 00 02 07 00 03 07 01 16 42 07 00 1B FF 00 00 00 08 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 07 01 16 07 01 1D 00 02 07 00 03 07 01 16 45 07 00 1B 40 01 4D 07 00 1B FF 00 00 00 08 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 07 01 16 07 01 1D 00 04 08 01 CA 08 01 CA 07 01 16 07 01 1D 45 07 00 1B 40 07 01 6D 00 FF 00 05 00 06 07 00 03 07 01 16 00 01 07 01 3D 01 00 00 41 07 01 1D FF 00 01 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 01 07 01 16 FF 00 01 00 07 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 07 01 16 00 01 07 01 1D FF 00 01 00 06 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 00 02 07 01 16 07 01 1D FF 00 01 00 08 07 00 03 07 01 16 07 01 1D 01 07 01 3D 01 07 01 16 07 01 1D 00 02 07 00 03 07 01 16 01 FF 00 01 00 06 07 00 03 07 01 16 00 01 07 01 3D 01 00 01 01 FF 00 01 00 02 07 00 03 07 01 16 00 01 07 00 1B 43 05 44 07 00 1B 47 05 47 07 00 1B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     509    517    Any
        //  509    517    509    517    Ljava/lang/IllegalArgumentException;
        //  525    527    3      8      Ljava/lang/ClassCastException;
        //  30     36     36     37     Any
        //  30     36     36     37     Ljava/lang/ClassCastException;
        //  30     36     3      8      Ljava/lang/UnsupportedOperationException;
        //  30     36     36     37     Ljava/lang/StringIndexOutOfBoundsException;
        //  30     36     36     37     Ljava/lang/RuntimeException;
        //  280    286    286    287    Any
        //  280    286    286    287    Ljava/lang/RuntimeException;
        //  280    286    286    287    Ljava/lang/StringIndexOutOfBoundsException;
        //  280    286    3      8      Ljava/util/NoSuchElementException;
        //  280    286    3      8      Ljava/lang/NegativeArraySizeException;
        //  293    300    300    301    Any
        //  293    300    293    294    Any
        //  293    300    293    294    Any
        //  293    300    3      8      Ljava/lang/NegativeArraySizeException;
        //  294    300    293    294    Any
        //  447    454    454    455    Any
        //  448    454    454    455    Ljava/lang/EnumConstantNotPresentException;
        //  448    454    447    448    Any
        //  448    454    3      8      Any
        //  447    454    447    448    Any
        //  469    476    476    477    Any
        //  470    476    3      8      Any
        //  470    476    469    470    Any
        //  469    476    476    477    Ljava/lang/NegativeArraySizeException;
        //  470    476    476    477    Ljava/util/NoSuchElementException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:595)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void 0(@NotNull final Vec3d vec3d, final boolean b) {
        fez.4(this, 342200364, vec3d, b);
    }
    
    @NotNull
    public Block 0(@Nullable final BlockPos p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          78
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            70
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            62
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_0        
        //    25: aload_1        
        //    26: goto            30
        //    29: athrow         
        //    30: invokevirtual   dev/nuker/pyro/fdU.c:(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
        //    33: goto            37
        //    36: athrow         
        //    37: goto            41
        //    40: athrow         
        //    41: invokeinterface net/minecraft/block/state/IBlockState.func_177230_c:()Lnet/minecraft/block/Block;
        //    46: goto            50
        //    49: athrow         
        //    50: dup            
        //    51: pop            
        //    52: areturn        
        //    53: pop            
        //    54: goto            24
        //    57: pop            
        //    58: aconst_null    
        //    59: goto            53
        //    62: dup            
        //    63: ifnull          53
        //    66: checkcast       Ljava/lang/Throwable;
        //    69: athrow         
        //    70: dup            
        //    71: ifnull          57
        //    74: checkcast       Ljava/lang/Throwable;
        //    77: athrow         
        //    78: aconst_null    
        //    79: athrow         
        //    StackMapTable: 00 11 43 07 00 1B 04 FF 00 0B 00 00 00 01 07 00 1B FD 00 03 07 00 03 07 01 16 44 07 00 55 FF 00 00 00 02 07 00 03 07 01 16 00 02 07 00 03 07 01 16 45 07 00 1B 40 07 01 18 42 07 00 1B 40 07 01 18 47 07 00 1B 40 07 01 7F 42 07 00 1B 43 05 44 07 00 1B 47 05 47 07 00 1B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     62     70     Any
        //  62     70     62     70     Ljava/lang/IndexOutOfBoundsException;
        //  78     80     3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  29     36     36     37     Any
        //  29     36     29     30     Ljava/lang/NumberFormatException;
        //  29     36     3      8      Any
        //  29     36     29     30     Ljava/util/NoSuchElementException;
        //  30     36     3      8      Ljava/lang/UnsupportedOperationException;
        //  40     49     49     50     Any
        //  41     49     3      8      Ljava/lang/ArithmeticException;
        //  41     49     40     41     Any
        //  40     49     3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  40     49     40     41     Ljava/lang/StringIndexOutOfBoundsException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 27 out of bounds for length 27
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public boolean c(@Nullable final Block block) {
        return fez.2G(this, 796966139, block);
    }
    
    public void c(@NotNull final Vec3d p0, @Nullable final EnumFacing p1, final boolean p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          177
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            169
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            161
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: aload_0        
        //    27: aload_0        
        //    28: aload_1        
        //    29: getstatic       dev/nuker/pyro/fc.c:I
        //    32: ifne            41
        //    35: ldc_w           -328087302
        //    38: goto            44
        //    41: ldc_w           -731002318
        //    44: ldc_w           984357659
        //    47: ixor           
        //    48: lookupswitch {
        //          -690105375: 150
        //          1771009931: 41
        //          default: 76
        //        }
        //    76: aload_2        
        //    77: goto            81
        //    80: athrow         
        //    81: invokevirtual   dev/nuker/pyro/fdU.c:(Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/Vec2f;
        //    84: goto            88
        //    87: athrow         
        //    88: iload_3        
        //    89: getstatic       dev/nuker/pyro/fc.c:I
        //    92: ifne            101
        //    95: ldc_w           440654198
        //    98: goto            104
        //   101: ldc_w           -1562486666
        //   104: ldc_w           -535784333
        //   107: ixor           
        //   108: lookupswitch {
        //          -95204091: 101
        //          1120848901: 136
        //          default: 148
        //        }
        //   136: goto            140
        //   139: athrow         
        //   140: invokevirtual   dev/nuker/pyro/fdU.c:(Lnet/minecraft/util/math/Vec2f;Z)V
        //   143: goto            147
        //   146: athrow         
        //   147: return         
        //   148: aconst_null    
        //   149: athrow         
        //   150: aconst_null    
        //   151: athrow         
        //   152: pop            
        //   153: goto            24
        //   156: pop            
        //   157: aconst_null    
        //   158: goto            152
        //   161: dup            
        //   162: ifnull          152
        //   165: checkcast       Ljava/lang/Throwable;
        //   168: athrow         
        //   169: dup            
        //   170: ifnull          156
        //   173: checkcast       Ljava/lang/Throwable;
        //   176: athrow         
        //   177: aconst_null    
        //   178: athrow         
        //    StackMapTable: 00 19 43 07 00 1B 04 FF 00 0B 00 00 00 01 07 00 1B FF 00 03 00 04 07 00 03 07 00 1D 07 01 1D 01 00 00 FF 00 10 00 04 07 00 03 07 00 1D 07 01 1D 01 00 03 07 00 03 07 00 03 07 00 1D FF 00 02 00 04 07 00 03 07 00 1D 07 01 1D 01 00 04 07 00 03 07 00 03 07 00 1D 01 FF 00 1F 00 04 07 00 03 07 00 1D 07 01 1D 01 00 03 07 00 03 07 00 03 07 00 1D 43 07 00 11 FF 00 00 00 04 07 00 03 07 00 1D 07 01 1D 01 00 04 07 00 03 07 00 03 07 00 1D 07 01 1D 45 07 00 1B FF 00 00 00 04 07 00 03 07 00 1D 07 01 1D 01 00 02 07 00 03 07 00 9F FF 00 0C 00 04 07 00 03 07 00 1D 07 01 1D 01 00 03 07 00 03 07 00 9F 01 FF 00 02 00 04 07 00 03 07 00 1D 07 01 1D 01 00 04 07 00 03 07 00 9F 01 01 FF 00 1F 00 04 07 00 03 07 00 1D 07 01 1D 01 00 03 07 00 03 07 00 9F 01 42 07 00 1B FF 00 00 00 04 07 00 03 07 00 1D 07 01 1D 01 00 03 07 00 03 07 00 9F 01 45 07 00 1B 00 FF 00 00 00 04 07 00 03 07 00 1D 07 01 1D 01 00 03 07 00 03 07 00 9F 01 FF 00 01 00 04 07 00 03 07 00 1D 07 01 1D 01 00 03 07 00 03 07 00 03 07 00 1D 41 07 00 1B 43 05 44 07 00 1B 47 05 47 07 00 1B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                      
        //  -----  -----  -----  -----  ------------------------------------------
        //  8      20     161    169    Any
        //  161    169    161    169    Ljava/lang/IndexOutOfBoundsException;
        //  177    179    3      8      Any
        //  80     87     87     88     Any
        //  81     87     80     81     Ljava/lang/ArrayIndexOutOfBoundsException;
        //  80     87     3      8      Ljava/lang/ArithmeticException;
        //  80     87     87     88     Any
        //  81     87     87     88     Ljava/lang/ArithmeticException;
        //  139    146    146    147    Any
        //  140    146    139    140    Any
        //  139    146    139    140    Any
        //  140    146    146    147    Any
        //  140    146    139    140    Ljava/lang/NumberFormatException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 56 out of bounds for length 56
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void c(@NotNull final Vec3d vec3d, final boolean b) {
        fez.4(this, 342200365, vec3d, b);
    }
    
    @NotNull
    public Vec3d c(@Nullable final BlockPos p0, @NotNull final World p1, @NotNull final EnumFacing p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          1730
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            1722
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            1714
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_2        
        //    25: pop            
        //    26: aload_3        
        //    27: pop            
        //    28: aload_2        
        //    29: getstatic       dev/nuker/pyro/fc.1:I
        //    32: ifne            41
        //    35: ldc_w           -618332997
        //    38: goto            44
        //    41: ldc_w           -1496486157
        //    44: ldc_w           2108202824
        //    47: ixor           
        //    48: lookupswitch {
        //          -1681675596: 41
        //          -1500748813: 1665
        //          default: 76
        //        }
        //    76: aload_1        
        //    77: goto            81
        //    80: athrow         
        //    81: invokevirtual   net/minecraft/world/World.func_180495_p:(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
        //    84: goto            88
        //    87: athrow         
        //    88: astore          4
        //    90: aload           4
        //    92: getstatic       dev/nuker/pyro/fc.1:I
        //    95: ifne            104
        //    98: ldc_w           1508892215
        //   101: goto            107
        //   104: ldc_w           -891275742
        //   107: ldc_w           -793596872
        //   110: ixor           
        //   111: lookupswitch {
        //          -1990364657: 104
        //          441621018: 136
        //          default: 1667
        //        }
        //   136: aload_2        
        //   137: checkcast       Lnet/minecraft/world/IBlockAccess;
        //   140: getstatic       dev/nuker/pyro/fc.1:I
        //   143: ifne            152
        //   146: ldc_w           1281887952
        //   149: goto            155
        //   152: ldc_w           -687718999
        //   155: ldc_w           599249537
        //   158: ixor           
        //   159: lookupswitch {
        //          787081165: 152
        //          1876941905: 1657
        //          default: 184
        //        }
        //   184: aload_1        
        //   185: goto            189
        //   188: athrow         
        //   189: invokeinterface net/minecraft/block/state/IBlockState.func_185900_c:(Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/AxisAlignedBB;
        //   194: goto            198
        //   197: athrow         
        //   198: astore          5
        //   200: aconst_null    
        //   201: astore          6
        //   203: aload           5
        //   205: getfield        net/minecraft/util/math/AxisAlignedBB.field_72340_a:D
        //   208: getstatic       dev/nuker/pyro/fc.0:I
        //   211: ifgt            220
        //   214: ldc_w           1451850936
        //   217: goto            223
        //   220: ldc_w           1114851909
        //   223: ldc_w           703679943
        //   226: ixor           
        //   227: lookupswitch {
        //          -1261036282: 220
        //          2138583423: 1697
        //          default: 252
        //        }
        //   252: aload           5
        //   254: getfield        net/minecraft/util/math/AxisAlignedBB.field_72336_d:D
        //   257: aload           5
        //   259: getfield        net/minecraft/util/math/AxisAlignedBB.field_72340_a:D
        //   262: dsub           
        //   263: ldc2_w          2.0
        //   266: ddiv           
        //   267: dadd           
        //   268: dstore          7
        //   270: aload           5
        //   272: getstatic       dev/nuker/pyro/fc.c:I
        //   275: ifne            284
        //   278: ldc_w           484833618
        //   281: goto            287
        //   284: ldc_w           -583017933
        //   287: ldc_w           382270859
        //   290: ixor           
        //   291: lookupswitch {
        //          -780738570: 284
        //          170722521: 1701
        //          default: 316
        //        }
        //   316: getfield        net/minecraft/util/math/AxisAlignedBB.field_72338_b:D
        //   319: aload           5
        //   321: getfield        net/minecraft/util/math/AxisAlignedBB.field_72337_e:D
        //   324: getstatic       dev/nuker/pyro/fc.c:I
        //   327: ifne            336
        //   330: ldc_w           51737800
        //   333: goto            339
        //   336: ldc_w           -1641892246
        //   339: ldc_w           -1805660389
        //   342: ixor           
        //   343: lookupswitch {
        //          -2124801225: 336
        //          -1756709933: 1661
        //          default: 368
        //        }
        //   368: aload           5
        //   370: getfield        net/minecraft/util/math/AxisAlignedBB.field_72338_b:D
        //   373: dsub           
        //   374: ldc2_w          2.0
        //   377: ddiv           
        //   378: dadd           
        //   379: dstore          9
        //   381: getstatic       dev/nuker/pyro/fc.1:I
        //   384: ifne            393
        //   387: ldc_w           -1317437163
        //   390: goto            396
        //   393: ldc_w           1492923235
        //   396: ldc_w           -1873111322
        //   399: ixor           
        //   400: lookupswitch {
        //          182101569: 393
        //          555948019: 1669
        //          default: 428
        //        }
        //   428: aload           5
        //   430: getstatic       dev/nuker/pyro/fc.0:I
        //   433: ifgt            442
        //   436: ldc_w           1563409158
        //   439: goto            445
        //   442: ldc_w           69027543
        //   445: ldc_w           1578678819
        //   448: ixor           
        //   449: lookupswitch {
        //          53936421: 442
        //          1510341876: 476
        //          default: 1671
        //        }
        //   476: getfield        net/minecraft/util/math/AxisAlignedBB.field_72339_c:D
        //   479: getstatic       dev/nuker/pyro/fc.1:I
        //   482: ifne            491
        //   485: ldc_w           -765822536
        //   488: goto            494
        //   491: ldc_w           1646822927
        //   494: ldc_w           -1982265154
        //   497: ixor           
        //   498: lookupswitch {
        //          488422719: 491
        //          1535340806: 1691
        //          default: 524
        //        }
        //   524: aload           5
        //   526: getfield        net/minecraft/util/math/AxisAlignedBB.field_72334_f:D
        //   529: aload           5
        //   531: getfield        net/minecraft/util/math/AxisAlignedBB.field_72339_c:D
        //   534: dsub           
        //   535: ldc2_w          2.0
        //   538: ddiv           
        //   539: dadd           
        //   540: dstore          11
        //   542: aload_3        
        //   543: goto            547
        //   546: athrow         
        //   547: invokevirtual   net/minecraft/util/EnumFacing.func_176740_k:()Lnet/minecraft/util/EnumFacing$Axis;
        //   550: goto            554
        //   553: athrow         
        //   554: dup            
        //   555: ifnonnull       562
        //   558: pop            
        //   559: goto            1388
        //   562: getstatic       dev/nuker/pyro/fdT.c:[I
        //   565: swap           
        //   566: getstatic       dev/nuker/pyro/fc.0:I
        //   569: ifgt            578
        //   572: ldc_w           1037321682
        //   575: goto            581
        //   578: ldc_w           1644341671
        //   581: ldc_w           1138186210
        //   584: ixor           
        //   585: lookupswitch {
        //          567672389: 612
        //          2114130480: 578
        //          default: 1675
        //        }
        //   612: goto            616
        //   615: athrow         
        //   616: invokevirtual   net/minecraft/util/EnumFacing$Axis.ordinal:()I
        //   619: goto            623
        //   622: athrow         
        //   623: iaload         
        //   624: tableswitch {
        //                2: 652
        //                3: 990
        //                4: 1146
        //          default: 1388
        //        }
        //   652: new             Lnet/minecraft/util/math/Vec3d;
        //   655: dup            
        //   656: aload           5
        //   658: getstatic       dev/nuker/pyro/fc.1:I
        //   661: ifne            670
        //   664: ldc_w           1964975437
        //   667: goto            673
        //   670: ldc_w           -67515835
        //   673: ldc_w           -1250854101
        //   676: ixor           
        //   677: lookupswitch {
        //          -1066508698: 670
        //          1317581166: 704
        //          default: 1683
        //        }
        //   704: getfield        net/minecraft/util/math/AxisAlignedBB.field_72340_a:D
        //   707: getstatic       dev/nuker/pyro/fc.c:I
        //   710: ifne            719
        //   713: ldc_w           245795462
        //   716: goto            722
        //   719: ldc_w           727370854
        //   722: ldc_w           -795837003
        //   725: ixor           
        //   726: lookupswitch {
        //          -566823117: 719
        //          -70602285: 752
        //          default: 1659
        //        }
        //   752: aload           5
        //   754: getfield        net/minecraft/util/math/AxisAlignedBB.field_72336_d:D
        //   757: getstatic       dev/nuker/pyro/fc.c:I
        //   760: ifne            769
        //   763: ldc_w           -722888289
        //   766: goto            772
        //   769: ldc_w           1594898517
        //   772: ldc_w           645255359
        //   775: ixor           
        //   776: lookupswitch {
        //          -1269971769: 769
        //          -224638688: 1703
        //          default: 804
        //        }
        //   804: aload           5
        //   806: getfield        net/minecraft/util/math/AxisAlignedBB.field_72340_a:D
        //   809: dsub           
        //   810: aload_3        
        //   811: getstatic       dev/nuker/pyro/fc.0:I
        //   814: ifgt            823
        //   817: ldc_w           -774543568
        //   820: goto            826
        //   823: ldc_w           -419375166
        //   826: ldc_w           -723536610
        //   829: ixor           
        //   830: lookupswitch {
        //          84595246: 823
        //          870277852: 856
        //          default: 1689
        //        }
        //   856: goto            860
        //   859: athrow         
        //   860: invokevirtual   net/minecraft/util/EnumFacing.func_176743_c:()Lnet/minecraft/util/EnumFacing$AxisDirection;
        //   863: goto            867
        //   866: athrow         
        //   867: getstatic       dev/nuker/pyro/fc.c:I
        //   870: ifne            879
        //   873: ldc_w           -1989405193
        //   876: goto            882
        //   879: ldc_w           1440350538
        //   882: ldc_w           -455139628
        //   885: ixor           
        //   886: lookupswitch {
        //          -1556102852: 879
        //          1840450339: 1699
        //          default: 912
        //        }
        //   912: getstatic       net/minecraft/util/EnumFacing$AxisDirection.POSITIVE:Lnet/minecraft/util/EnumFacing$AxisDirection;
        //   915: if_acmpne       922
        //   918: iconst_1       
        //   919: goto            923
        //   922: iconst_0       
        //   923: i2d            
        //   924: dmul           
        //   925: dadd           
        //   926: getstatic       dev/nuker/pyro/fc.0:I
        //   929: ifgt            938
        //   932: ldc_w           793990557
        //   935: goto            941
        //   938: ldc_w           448081827
        //   941: ldc_w           -1744660496
        //   944: ixor           
        //   945: lookupswitch {
        //          -1219378579: 1693
        //          1933813506: 938
        //          default: 972
        //        }
        //   972: dload           9
        //   974: dload           11
        //   976: goto            980
        //   979: athrow         
        //   980: invokespecial   net/minecraft/util/math/Vec3d.<init>:(DDD)V
        //   983: goto            987
        //   986: athrow         
        //   987: goto            1527
        //   990: new             Lnet/minecraft/util/math/Vec3d;
        //   993: dup            
        //   994: dload           7
        //   996: aload           5
        //   998: getfield        net/minecraft/util/math/AxisAlignedBB.field_72338_b:D
        //  1001: aload           5
        //  1003: getfield        net/minecraft/util/math/AxisAlignedBB.field_72337_e:D
        //  1006: getstatic       dev/nuker/pyro/fc.1:I
        //  1009: ifne            1018
        //  1012: ldc_w           -664936809
        //  1015: goto            1021
        //  1018: ldc_w           -204638472
        //  1021: ldc_w           -565879434
        //  1024: ixor           
        //  1025: lookupswitch {
        //          -2114711578: 1018
        //          102269921: 1695
        //          default: 1052
        //        }
        //  1052: aload           5
        //  1054: getstatic       dev/nuker/pyro/fc.0:I
        //  1057: ifgt            1066
        //  1060: ldc_w           1297174926
        //  1063: goto            1069
        //  1066: ldc_w           -1355741525
        //  1069: ldc_w           -684983995
        //  1072: ixor           
        //  1073: lookupswitch {
        //          -1703237429: 1066
        //          2015035374: 1100
        //          default: 1687
        //        }
        //  1100: getfield        net/minecraft/util/math/AxisAlignedBB.field_72338_b:D
        //  1103: dsub           
        //  1104: aload_3        
        //  1105: goto            1109
        //  1108: athrow         
        //  1109: invokevirtual   net/minecraft/util/EnumFacing.func_176743_c:()Lnet/minecraft/util/EnumFacing$AxisDirection;
        //  1112: goto            1116
        //  1115: athrow         
        //  1116: getstatic       net/minecraft/util/EnumFacing$AxisDirection.POSITIVE:Lnet/minecraft/util/EnumFacing$AxisDirection;
        //  1119: if_acmpne       1126
        //  1122: iconst_1       
        //  1123: goto            1127
        //  1126: iconst_0       
        //  1127: i2d            
        //  1128: dmul           
        //  1129: dadd           
        //  1130: dload           11
        //  1132: goto            1136
        //  1135: athrow         
        //  1136: invokespecial   net/minecraft/util/math/Vec3d.<init>:(DDD)V
        //  1139: goto            1143
        //  1142: athrow         
        //  1143: goto            1527
        //  1146: new             Lnet/minecraft/util/math/Vec3d;
        //  1149: dup            
        //  1150: dload           7
        //  1152: getstatic       dev/nuker/pyro/fc.c:I
        //  1155: ifne            1164
        //  1158: ldc_w           -999029977
        //  1161: goto            1167
        //  1164: ldc_w           -1316745327
        //  1167: ldc_w           1989812284
        //  1170: ixor           
        //  1171: lookupswitch {
        //          -1704178569: 1164
        //          -1293016293: 1673
        //          default: 1196
        //        }
        //  1196: dload           9
        //  1198: aload           5
        //  1200: getstatic       dev/nuker/pyro/fc.0:I
        //  1203: ifgt            1212
        //  1206: ldc_w           861366842
        //  1209: goto            1215
        //  1212: ldc_w           2092742933
        //  1215: ldc_w           -2034463428
        //  1218: ixor           
        //  1219: lookupswitch {
        //          -1242831098: 1212
        //          -100649943: 1244
        //          default: 1655
        //        }
        //  1244: getfield        net/minecraft/util/math/AxisAlignedBB.field_72339_c:D
        //  1247: aload           5
        //  1249: getfield        net/minecraft/util/math/AxisAlignedBB.field_72334_f:D
        //  1252: getstatic       dev/nuker/pyro/fc.c:I
        //  1255: ifne            1264
        //  1258: ldc_w           2013662590
        //  1261: goto            1267
        //  1264: ldc_w           1690260982
        //  1267: ldc_w           1937510688
        //  1270: ixor           
        //  1271: lookupswitch {
        //          192552030: 1663
        //          561127457: 1264
        //          default: 1296
        //        }
        //  1296: aload           5
        //  1298: getfield        net/minecraft/util/math/AxisAlignedBB.field_72339_c:D
        //  1301: dsub           
        //  1302: getstatic       dev/nuker/pyro/fc.c:I
        //  1305: ifne            1314
        //  1308: ldc_w           1164206865
        //  1311: goto            1317
        //  1314: ldc_w           1671611869
        //  1317: ldc_w           1999988280
        //  1320: ixor           
        //  1321: lookupswitch {
        //          345482213: 1348
        //          844170537: 1314
        //          default: 1685
        //        }
        //  1348: aload_3        
        //  1349: goto            1353
        //  1352: athrow         
        //  1353: invokevirtual   net/minecraft/util/EnumFacing.func_176743_c:()Lnet/minecraft/util/EnumFacing$AxisDirection;
        //  1356: goto            1360
        //  1359: athrow         
        //  1360: getstatic       net/minecraft/util/EnumFacing$AxisDirection.POSITIVE:Lnet/minecraft/util/EnumFacing$AxisDirection;
        //  1363: if_acmpne       1370
        //  1366: iconst_1       
        //  1367: goto            1371
        //  1370: iconst_0       
        //  1371: i2d            
        //  1372: dmul           
        //  1373: dadd           
        //  1374: goto            1378
        //  1377: athrow         
        //  1378: invokespecial   net/minecraft/util/math/Vec3d.<init>:(DDD)V
        //  1381: goto            1385
        //  1384: athrow         
        //  1385: goto            1527
        //  1388: new             Ljava/lang/IllegalStateException;
        //  1391: dup            
        //  1392: new             Ljava/lang/StringBuilder;
        //  1395: dup            
        //  1396: goto            1400
        //  1399: athrow         
        //  1400: invokespecial   java/lang/StringBuilder.<init>:()V
        //  1403: goto            1407
        //  1406: athrow         
        //  1407: ldc_w           "\u370d\ub24b\u847f\uafad\u6ae8\u53d8\u7e43\u6379\uc0d7\uae1a\u91c1\u1312\ucb0d\u7313\u9d3c\u47d0\ub230\u46e4\u0340\u0adf\u18df\ufec5\u60b9\u8a51\u3b81\u3712"
        //  1410: goto            1414
        //  1413: athrow         
        //  1414: invokestatic    invokestatic   !!! ERROR
        //  1417: goto            1421
        //  1420: athrow         
        //  1421: goto            1425
        //  1424: athrow         
        //  1425: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1428: goto            1432
        //  1431: athrow         
        //  1432: aload_3        
        //  1433: goto            1437
        //  1436: athrow         
        //  1437: invokevirtual   net/minecraft/util/EnumFacing.func_176740_k:()Lnet/minecraft/util/EnumFacing$Axis;
        //  1440: goto            1444
        //  1443: athrow         
        //  1444: goto            1448
        //  1447: athrow         
        //  1448: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/Object;)Ljava/lang/StringBuilder;
        //  1451: goto            1455
        //  1454: athrow         
        //  1455: goto            1459
        //  1458: athrow         
        //  1459: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1462: goto            1466
        //  1465: athrow         
        //  1466: getstatic       dev/nuker/pyro/fc.1:I
        //  1469: ifne            1478
        //  1472: ldc_w           1302823885
        //  1475: goto            1481
        //  1478: ldc_w           239312482
        //  1481: ldc_w           -1002578975
        //  1484: ixor           
        //  1485: lookupswitch {
        //          -1986373588: 1679
        //          -1484711199: 1478
        //          default: 1512
        //        }
        //  1512: goto            1516
        //  1515: athrow         
        //  1516: invokespecial   java/lang/IllegalStateException.<init>:(Ljava/lang/String;)V
        //  1519: goto            1523
        //  1522: athrow         
        //  1523: checkcast       Ljava/lang/Throwable;
        //  1526: athrow         
        //  1527: getstatic       dev/nuker/pyro/fc.1:I
        //  1530: ifne            1539
        //  1533: ldc_w           -2124734369
        //  1536: goto            1542
        //  1539: ldc_w           -489187896
        //  1542: ldc_w           -1021389663
        //  1545: ixor           
        //  1546: lookupswitch {
        //          566837609: 1572
        //          1111880958: 1539
        //          default: 1681
        //        }
        //  1572: astore          6
        //  1574: new             Lnet/minecraft/util/math/Vec3d;
        //  1577: dup            
        //  1578: aload_1        
        //  1579: checkcast       Lnet/minecraft/util/math/Vec3i;
        //  1582: getstatic       dev/nuker/pyro/fc.0:I
        //  1585: ifgt            1594
        //  1588: ldc_w           812239525
        //  1591: goto            1597
        //  1594: ldc_w           -485492592
        //  1597: ldc_w           1310130445
        //  1600: ixor           
        //  1601: lookupswitch {
        //          1613724233: 1594
        //          2122238888: 1677
        //          default: 1628
        //        }
        //  1628: goto            1632
        //  1631: athrow         
        //  1632: invokespecial   net/minecraft/util/math/Vec3d.<init>:(Lnet/minecraft/util/math/Vec3i;)V
        //  1635: goto            1639
        //  1638: athrow         
        //  1639: aload           6
        //  1641: goto            1645
        //  1644: athrow         
        //  1645: invokevirtual   net/minecraft/util/math/Vec3d.func_178787_e:(Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;
        //  1648: goto            1652
        //  1651: athrow         
        //  1652: dup            
        //  1653: pop            
        //  1654: areturn        
        //  1655: aconst_null    
        //  1656: athrow         
        //  1657: aconst_null    
        //  1658: athrow         
        //  1659: aconst_null    
        //  1660: athrow         
        //  1661: aconst_null    
        //  1662: athrow         
        //  1663: aconst_null    
        //  1664: athrow         
        //  1665: aconst_null    
        //  1666: athrow         
        //  1667: aconst_null    
        //  1668: athrow         
        //  1669: aconst_null    
        //  1670: athrow         
        //  1671: aconst_null    
        //  1672: athrow         
        //  1673: aconst_null    
        //  1674: athrow         
        //  1675: aconst_null    
        //  1676: athrow         
        //  1677: aconst_null    
        //  1678: athrow         
        //  1679: aconst_null    
        //  1680: athrow         
        //  1681: aconst_null    
        //  1682: athrow         
        //  1683: aconst_null    
        //  1684: athrow         
        //  1685: aconst_null    
        //  1686: athrow         
        //  1687: aconst_null    
        //  1688: athrow         
        //  1689: aconst_null    
        //  1690: athrow         
        //  1691: aconst_null    
        //  1692: athrow         
        //  1693: aconst_null    
        //  1694: athrow         
        //  1695: aconst_null    
        //  1696: athrow         
        //  1697: aconst_null    
        //  1698: athrow         
        //  1699: aconst_null    
        //  1700: athrow         
        //  1701: aconst_null    
        //  1702: athrow         
        //  1703: aconst_null    
        //  1704: athrow         
        //  1705: pop            
        //  1706: goto            24
        //  1709: pop            
        //  1710: aconst_null    
        //  1711: goto            1705
        //  1714: dup            
        //  1715: ifnull          1705
        //  1718: checkcast       Ljava/lang/Throwable;
        //  1721: athrow         
        //  1722: dup            
        //  1723: ifnull          1709
        //  1726: checkcast       Ljava/lang/Throwable;
        //  1729: athrow         
        //  1730: aconst_null    
        //  1731: athrow         
        //    StackMapTable: 00 C5 43 07 00 1B 04 FF 00 0B 00 00 00 01 07 00 1B FF 00 03 00 04 07 00 03 07 01 16 07 01 35 07 01 1D 00 00 50 07 01 35 FF 00 02 00 04 07 00 03 07 01 16 07 01 35 07 01 1D 00 02 07 01 35 01 5F 07 01 35 43 07 00 1B FF 00 00 00 04 07 00 03 07 01 16 07 01 35 07 01 1D 00 02 07 01 35 07 01 16 45 07 00 1B 40 07 01 18 FF 00 0F 00 05 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 00 01 07 01 18 FF 00 02 00 05 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 00 02 07 01 18 01 5C 07 01 18 FF 00 0F 00 05 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 00 02 07 01 18 07 01 9C FF 00 02 00 05 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 00 03 07 01 18 07 01 9C 01 FF 00 1C 00 05 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 00 02 07 01 18 07 01 9C 43 07 00 55 FF 00 00 00 05 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 00 03 07 01 18 07 01 9C 07 01 16 47 07 00 1B 40 07 01 A5 FF 00 15 00 07 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 00 01 03 FF 00 02 00 07 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 00 02 03 01 5C 03 FF 00 1F 00 08 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 00 01 07 01 A5 FF 00 02 00 08 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 00 02 07 01 A5 01 5C 07 01 A5 FF 00 13 00 08 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 00 02 03 03 FF 00 02 00 08 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 00 03 03 03 01 FF 00 1C 00 08 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 00 02 03 03 FC 00 18 03 42 01 1F 4D 07 01 A5 FF 00 02 00 09 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 00 02 07 01 A5 01 5E 07 01 A5 4E 03 FF 00 02 00 09 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 00 02 03 01 5D 03 FF 00 15 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 01 07 00 1B 40 07 01 1D 45 07 00 1B 40 07 01 D9 47 07 01 D9 FF 00 0F 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 02 07 02 36 07 01 D9 FF 00 02 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 07 02 36 07 01 D9 01 FF 00 1E 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 02 07 02 36 07 01 D9 42 07 00 13 FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 02 07 02 36 07 01 D9 45 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 02 07 02 36 01 1C FF 00 11 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 08 02 8C 08 02 8C 07 01 A5 FF 00 02 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 04 08 02 8C 08 02 8C 07 01 A5 01 FF 00 1E 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 08 02 8C 08 02 8C 07 01 A5 FF 00 0E 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 08 02 8C 08 02 8C 03 FF 00 02 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 04 08 02 8C 08 02 8C 03 01 FF 00 1D 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 08 02 8C 08 02 8C 03 FF 00 10 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 04 08 02 8C 08 02 8C 03 03 FF 00 02 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 05 08 02 8C 08 02 8C 03 03 01 FF 00 1F 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 04 08 02 8C 08 02 8C 03 03 FF 00 12 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 05 08 02 8C 08 02 8C 03 03 07 01 1D FF 00 02 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 06 08 02 8C 08 02 8C 03 03 07 01 1D 01 FF 00 1D 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 05 08 02 8C 08 02 8C 03 03 07 01 1D 42 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 05 08 02 8C 08 02 8C 03 03 07 01 1D 45 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 05 08 02 8C 08 02 8C 03 03 07 01 F2 FF 00 0B 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 05 08 02 8C 08 02 8C 03 03 07 01 F2 FF 00 02 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 06 08 02 8C 08 02 8C 03 03 07 01 F2 01 FF 00 1D 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 05 08 02 8C 08 02 8C 03 03 07 01 F2 FF 00 09 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 04 08 02 8C 08 02 8C 03 03 FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 05 08 02 8C 08 02 8C 03 03 01 FF 00 0E 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 08 02 8C 08 02 8C 03 FF 00 02 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 04 08 02 8C 08 02 8C 03 01 FF 00 1E 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 08 02 8C 08 02 8C 03 46 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 05 08 02 8C 08 02 8C 03 03 03 45 07 00 1B 40 07 00 1D 02 FF 00 1B 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 05 08 03 DE 08 03 DE 03 03 03 FF 00 02 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 06 08 03 DE 08 03 DE 03 03 03 01 FF 00 1E 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 05 08 03 DE 08 03 DE 03 03 03 FF 00 0D 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 06 08 03 DE 08 03 DE 03 03 03 07 01 A5 FF 00 02 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 07 08 03 DE 08 03 DE 03 03 03 07 01 A5 01 FF 00 1E 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 06 08 03 DE 08 03 DE 03 03 03 07 01 A5 FF 00 07 00 00 00 01 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 06 08 03 DE 08 03 DE 03 03 03 07 01 1D 45 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 06 08 03 DE 08 03 DE 03 03 03 07 01 F2 FF 00 09 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 05 08 03 DE 08 03 DE 03 03 03 FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 06 08 03 DE 08 03 DE 03 03 03 01 47 07 00 60 FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 05 08 03 DE 08 03 DE 03 03 03 45 07 00 1B 40 07 00 1D 02 FF 00 11 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 08 04 7A 08 04 7A 03 FF 00 02 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 04 08 04 7A 08 04 7A 03 01 FF 00 1C 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 08 04 7A 08 04 7A 03 FF 00 0F 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 05 08 04 7A 08 04 7A 03 03 07 01 A5 FF 00 02 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 06 08 04 7A 08 04 7A 03 03 07 01 A5 01 FF 00 1C 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 05 08 04 7A 08 04 7A 03 03 07 01 A5 FF 00 13 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 06 08 04 7A 08 04 7A 03 03 03 03 FF 00 02 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 07 08 04 7A 08 04 7A 03 03 03 03 01 FF 00 1C 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 06 08 04 7A 08 04 7A 03 03 03 03 FF 00 11 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 06 08 04 7A 08 04 7A 03 03 03 03 FF 00 02 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 07 08 04 7A 08 04 7A 03 03 03 03 01 FF 00 1E 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 06 08 04 7A 08 04 7A 03 03 03 03 43 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 07 08 04 7A 08 04 7A 03 03 03 03 07 01 1D 45 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 07 08 04 7A 08 04 7A 03 03 03 03 07 01 F2 FF 00 09 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 06 08 04 7A 08 04 7A 03 03 03 03 FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 07 08 04 7A 08 04 7A 03 03 03 03 01 45 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 05 08 04 7A 08 04 7A 03 03 03 45 07 00 1B 40 07 00 1D 02 4A 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 04 08 05 6C 08 05 6C 08 05 70 08 05 70 45 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 08 05 6C 08 05 6C 07 02 0D 45 07 01 43 FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 04 08 05 6C 08 05 6C 07 02 0D 07 02 38 45 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 04 08 05 6C 08 05 6C 07 02 0D 07 02 38 42 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 04 08 05 6C 08 05 6C 07 02 0D 07 02 38 45 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 08 05 6C 08 05 6C 07 02 0D FF 00 03 00 00 00 01 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 04 08 05 6C 08 05 6C 07 02 0D 07 01 1D 45 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 04 08 05 6C 08 05 6C 07 02 0D 07 01 D9 42 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 04 08 05 6C 08 05 6C 07 02 0D 07 01 D9 45 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 08 05 6C 08 05 6C 07 02 0D 42 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 08 05 6C 08 05 6C 07 02 0D 45 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 08 05 6C 08 05 6C 07 02 38 FF 00 0B 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 08 05 6C 08 05 6C 07 02 38 FF 00 02 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 04 08 05 6C 08 05 6C 07 02 38 01 FF 00 1E 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 08 05 6C 08 05 6C 07 02 38 42 07 00 13 FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 08 05 6C 08 05 6C 07 02 38 45 07 00 1B 40 07 00 13 43 07 00 1D 4B 07 00 1D FF 00 02 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 02 07 00 1D 01 5D 07 00 1D FF 00 15 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 07 00 1D 03 03 03 00 03 08 06 26 08 06 26 07 02 2B FF 00 02 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 07 00 1D 03 03 03 00 04 08 06 26 08 06 26 07 02 2B 01 FF 00 1E 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 07 00 1D 03 03 03 00 03 08 06 26 08 06 26 07 02 2B 42 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 07 00 1D 03 03 03 00 03 08 06 26 08 06 26 07 02 2B 45 07 00 1B 40 07 00 1D 44 07 00 68 FF 00 00 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 07 00 1D 03 03 03 00 02 07 00 1D 07 00 1D 45 07 00 1B 40 07 00 1D FF 00 02 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 05 08 04 7A 08 04 7A 03 03 07 01 A5 FF 00 01 00 05 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 00 02 07 01 18 07 01 9C FF 00 01 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 08 02 8C 08 02 8C 03 FF 00 01 00 08 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 00 02 03 03 FF 00 01 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 06 08 04 7A 08 04 7A 03 03 03 03 FF 00 01 00 04 07 00 03 07 01 16 07 01 35 07 01 1D 00 01 07 01 35 FF 00 01 00 05 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 00 01 07 01 18 FF 00 01 00 09 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 00 00 41 07 01 A5 FF 00 01 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 08 04 7A 08 04 7A 03 FF 00 01 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 02 07 02 36 07 01 D9 FF 00 01 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 07 00 1D 03 03 03 00 03 08 06 26 08 06 26 07 02 2B FF 00 01 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 08 05 6C 08 05 6C 07 02 38 41 07 00 1D FF 00 01 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 08 02 8C 08 02 8C 07 01 A5 FF 00 01 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 06 08 04 7A 08 04 7A 03 03 03 03 FF 00 01 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 06 08 03 DE 08 03 DE 03 03 03 07 01 A5 FF 00 01 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 05 08 02 8C 08 02 8C 03 03 07 01 1D FF 00 01 00 09 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 00 01 03 FF 00 01 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 03 08 02 8C 08 02 8C 03 FF 00 01 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 05 08 03 DE 08 03 DE 03 03 03 FF 00 01 00 07 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 00 01 03 FF 00 01 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 05 08 02 8C 08 02 8C 03 03 07 01 F2 FF 00 01 00 08 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 00 01 07 01 A5 FF 00 01 00 0A 07 00 03 07 01 16 07 01 35 07 01 1D 07 01 18 07 01 A5 05 03 03 03 00 04 08 02 8C 08 02 8C 03 03 FF 00 01 00 04 07 00 03 07 01 16 07 01 35 07 01 1D 00 01 07 00 1B 43 05 44 07 00 1B 47 05 47 07 00 1B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     1714   1722   Any
        //  1714   1722   1714   1722   Any
        //  1730   1732   3      8      Any
        //  80     87     87     88     Any
        //  81     87     87     88     Any
        //  81     87     87     88     Any
        //  80     87     3      8      Ljava/lang/NullPointerException;
        //  81     87     80     81     Any
        //  188    197    197    198    Any
        //  188    197    188    189    Ljava/lang/EnumConstantNotPresentException;
        //  188    197    188    189    Ljava/lang/NullPointerException;
        //  189    197    3      8      Ljava/lang/ClassCastException;
        //  189    197    188    189    Ljava/lang/IllegalArgumentException;
        //  546    553    553    554    Any
        //  546    553    546    547    Any
        //  547    553    546    547    Ljava/lang/ArithmeticException;
        //  546    553    3      8      Any
        //  546    553    3      8      Ljava/lang/IllegalStateException;
        //  615    622    622    623    Any
        //  616    622    622    623    Any
        //  615    622    622    623    Any
        //  615    622    622    623    Any
        //  616    622    615    616    Ljava/lang/IllegalStateException;
        //  859    866    866    867    Any
        //  859    866    866    867    Ljava/lang/ArithmeticException;
        //  860    866    866    867    Ljava/lang/IllegalStateException;
        //  860    866    866    867    Ljava/lang/RuntimeException;
        //  860    866    859    860    Any
        //  979    986    986    987    Any
        //  980    986    979    980    Any
        //  980    986    979    980    Any
        //  979    986    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  980    986    3      8      Ljava/lang/NullPointerException;
        //  1109   1115   1115   1116   Any
        //  1109   1115   1115   1116   Any
        //  1109   1115   3      8      Any
        //  1109   1115   1115   1116   Any
        //  1109   1115   3      8      Ljava/util/NoSuchElementException;
        //  1135   1142   1142   1143   Any
        //  1135   1142   1142   1143   Ljava/lang/NegativeArraySizeException;
        //  1136   1142   1135   1136   Ljava/util/NoSuchElementException;
        //  1136   1142   1142   1143   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1135   1142   3      8      Ljava/lang/RuntimeException;
        //  1352   1359   1359   1360   Any
        //  1353   1359   1352   1353   Any
        //  1352   1359   1352   1353   Any
        //  1352   1359   1359   1360   Any
        //  1352   1359   1359   1360   Ljava/lang/NegativeArraySizeException;
        //  1377   1384   1384   1385   Any
        //  1377   1384   1384   1385   Ljava/lang/NumberFormatException;
        //  1377   1384   1377   1378   Any
        //  1377   1384   1377   1378   Ljava/lang/IndexOutOfBoundsException;
        //  1377   1384   3      8      Ljava/lang/ClassCastException;
        //  1399   1406   1406   1407   Any
        //  1400   1406   1399   1400   Ljava/lang/NegativeArraySizeException;
        //  1399   1406   1399   1400   Any
        //  1400   1406   1406   1407   Ljava/lang/RuntimeException;
        //  1399   1406   3      8      Any
        //  1413   1420   1420   1421   Any
        //  1413   1420   1420   1421   Ljava/lang/ArithmeticException;
        //  1413   1420   1420   1421   Any
        //  1414   1420   3      8      Any
        //  1414   1420   1413   1414   Ljava/lang/IllegalArgumentException;
        //  1424   1431   1431   1432   Any
        //  1425   1431   3      8      Ljava/util/ConcurrentModificationException;
        //  1425   1431   3      8      Any
        //  1424   1431   1431   1432   Ljava/lang/EnumConstantNotPresentException;
        //  1424   1431   1424   1425   Any
        //  1437   1443   1443   1444   Any
        //  1437   1443   3      8      Any
        //  1437   1443   1443   1444   Any
        //  1437   1443   1443   1444   Any
        //  1437   1443   1443   1444   Ljava/util/NoSuchElementException;
        //  1447   1454   1454   1455   Any
        //  1447   1454   1447   1448   Ljava/util/ConcurrentModificationException;
        //  1447   1454   1447   1448   Any
        //  1447   1454   1447   1448   Any
        //  1447   1454   1454   1455   Ljava/lang/IllegalStateException;
        //  1458   1465   1465   1466   Any
        //  1459   1465   3      8      Ljava/lang/RuntimeException;
        //  1458   1465   1458   1459   Any
        //  1458   1465   3      8      Any
        //  1459   1465   1465   1466   Ljava/lang/ClassCastException;
        //  1515   1522   1522   1523   Any
        //  1515   1522   1522   1523   Any
        //  1515   1522   1522   1523   Any
        //  1515   1522   1515   1516   Ljava/lang/IllegalStateException;
        //  1515   1522   1522   1523   Any
        //  1631   1638   1638   1639   Any
        //  1632   1638   1631   1632   Any
        //  1631   1638   1631   1632   Any
        //  1632   1638   3      8      Any
        //  1631   1638   1631   1632   Any
        //  1644   1651   1651   1652   Any
        //  1644   1651   1651   1652   Any
        //  1645   1651   3      8      Ljava/lang/IllegalStateException;
        //  1644   1651   1644   1645   Ljava/lang/NegativeArraySizeException;
        //  1645   1651   3      8      Ljava/lang/ClassCastException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visitVariable(StackMappingVisitor.java:470)
        //     at com.strobel.assembler.ir.Instruction.accept(Instruction.java:556)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:403)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void 0(@NotNull final Vec2f vec2f, final boolean b) {
        Object o = null;
        Label_0008: {
            break Label_0008;
        Label_0548:
            while (true) {
                do {
                    Label_0535: {
                        break Label_0535;
                        try {
                            o = null;
                            if (fc.c != 0) {
                                null;
                                goto Label_0540;
                            }
                            continue Label_0548;
                            CPacketPlayer$Rotation cPacketPlayer$Rotation = null;
                            final Packet packet = (Packet)cPacketPlayer$Rotation;
                            // switch([Lcom.strobel.decompiler.ast.Label;@27030328, n2 ^ 0x16AB2A1D)
                            // iftrue(Label_0330:, fc.c != 0)
                            int n;
                            int n2;
                            int n3;
                            int n4;
                            int n5;
                            NetHandlerPlayClient field_71174_a;
                            final NoSuchElementException ex;
                            int n6;
                            Minecraft c;
                            boolean field_70122_E;
                            Minecraft c2 = null;
                            EntityPlayerSP field_71439_g = null;
                            int n7;
                            int n8;
                            int n9;
                            float field_189983_j;
                            Minecraft c3;
                            float field_189982_i;
                            Label_0089_Outer:Block_6_Outer:Label_0476_Outer:
                            while (true) {
                            Label_0476:
                                while (true) {
                                    Block_15: {
                                        while (true) {
                                            while (true) {
                                            Label_0149_Outer:
                                                while (true) {
                                                    while (true) {
                                                    Label_0149:
                                                        while (true) {
                                                            Label_0276_Outer:Block_13_Outer:Label_0203_Outer:
                                                            while (true) {
                                                                Label_0039: {
                                                                Label_0203:
                                                                    while (true) {
                                                                        while (true) {
                                                                            Label_0263: {
                                                                                Label_0383: {
                                                                                    while (true) {
                                                                                        while (true) {
                                                                                            Label_0256: {
                                                                                                break Label_0256;
                                                                                                n = 1337762673;
                                                                                                break Label_0089;
                                                                                                Label_0304: {
                                                                                                    this.c.field_71439_g.field_70125_A = vec2f.field_189983_j;
                                                                                                }
                                                                                                Block_12: {
                                                                                                    break Block_12;
                                                                                                    Label_0517:
                                                                                                    throw null;
                                                                                                    n3 = -1396058641;
                                                                                                    break Label_0383;
                                                                                                }
                                                                                                n4 = 1709355688;
                                                                                                break Label_0149_Outer;
                                                                                                Label_0527:
                                                                                                throw null;
                                                                                                n5 = -611789516;
                                                                                                break Label_0039;
                                                                                                try {
                                                                                                    field_71174_a.func_147297_a(packet);
                                                                                                }
                                                                                                catch (ArithmeticException ex2) {}
                                                                                                catch (IndexOutOfBoundsException ex3) {}
                                                                                                catch (NoSuchElementException ex) {}
                                                                                                finally {
                                                                                                    throw ex;
                                                                                                }
                                                                                            }
                                                                                            break Label_0263;
                                                                                            n2 = 1885334951;
                                                                                            continue Block_13_Outer;
                                                                                            Label_0273: {
                                                                                                n2 = 1885334950;
                                                                                            }
                                                                                            continue Block_13_Outer;
                                                                                        }
                                                                                        Label_0515: {
                                                                                            throw null;
                                                                                        }
                                                                                        Label_0380:
                                                                                        n3 = -659819773;
                                                                                        break Label_0383;
                                                                                        Label_0232:
                                                                                        field_70122_E = c.field_71439_g.field_70122_E;
                                                                                        goto Label_0242;
                                                                                        Label_0364:
                                                                                        c2 = this.c;
                                                                                        continue Block_6_Outer;
                                                                                    }
                                                                                    Label_0036: {
                                                                                        n5 = 476460621;
                                                                                    }
                                                                                    break Label_0039;
                                                                                    Label_0523:
                                                                                    throw null;
                                                                                    Label_0200:
                                                                                    n6 = -700669333;
                                                                                    continue Label_0203;
                                                                                }
                                                                                Label_0508: {
                                                                                    field_71439_g.field_70177_z = vec2f.field_189982_i;
                                                                                }
                                                                                return;
                                                                            }
                                                                            continue Label_0203_Outer;
                                                                        }
                                                                        Label_0460: {
                                                                            break Block_15;
                                                                        }
                                                                        n6 = 1021078000;
                                                                        continue Label_0203;
                                                                    }
                                                                    Label_0519: {
                                                                        throw null;
                                                                    }
                                                                    n7 = -445465113;
                                                                    continue Label_0149;
                                                                }
                                                                Label_0330: {
                                                                    n4 = -455979219;
                                                                }
                                                                break Label_0149_Outer;
                                                                Label_0473:
                                                                n8 = 62421155;
                                                                continue Label_0476;
                                                                Label_0086:
                                                                n = 1406650406;
                                                                continue Label_0276_Outer;
                                                            }
                                                            Label_0525: {
                                                                throw null;
                                                            }
                                                            Label_0146:
                                                            n7 = 1865997054;
                                                            continue Label_0149;
                                                        }
                                                        Label_0412: {
                                                            field_71439_g = c2.field_71439_g;
                                                        }
                                                        Block_14: {
                                                            break Block_14;
                                                            Label_0427:
                                                            n9 = -1990999350;
                                                            continue;
                                                            Label_0529:
                                                            throw null;
                                                        }
                                                        n9 = -1420574898;
                                                        continue;
                                                    }
                                                    Label_0514: {
                                                        return;
                                                    }
                                                    continue Label_0149_Outer;
                                                }
                                                Label_0521: {
                                                    throw null;
                                                }
                                                Label_0180:
                                                field_189983_j = vec2f.field_189983_j;
                                                c = this.c;
                                                continue Label_0476_Outer;
                                            }
                                            Label_0120: {
                                                field_71174_a = c3.field_71439_g.field_71174_a;
                                            }
                                            cPacketPlayer$Rotation = new(net.minecraft.network.play.client.CPacketPlayer$Rotation.class);
                                            field_189982_i = vec2f.field_189982_i;
                                            continue;
                                        }
                                    }
                                    n8 = 1603578138;
                                    continue Label_0476;
                                }
                                Label_0068: {
                                    c3 = this.c;
                                }
                                continue Label_0089_Outer;
                            }
                        }
                        // switch([Lcom.strobel.decompiler.ast.Label;@6299fd3f, n6 ^ 0xA5972A51)
                        // iftrue(Label_0380:, fc.0 > 0)
                        // switch([Lcom.strobel.decompiler.ast.Label;@3b719288, n ^ 0x9A3B3560)
                        // switch([Lcom.strobel.decompiler.ast.Label;@e723126, n3 ^ 0x5D9AEDA0)
                        // iftrue(Label_0273:, !b)
                        // switch([Lcom.strobel.decompiler.ast.Label;@31577983, n7 ^ 0x2E80C3F9)
                        // iftrue(Label_0473:, fc.1 != 0)
                        // switch([Lcom.strobel.decompiler.ast.Label;@1c8a1a93, n8 ^ 0xA4000E4F)
                        // switch([Lcom.strobel.decompiler.ast.Label;@2b582e58, n9 ^ 0x68ED38C7)
                        // switch([Lcom.strobel.decompiler.ast.Label;@34bcd114, n5 ^ 0xB702C678)
                        // iftrue(Label_0427:, fc.c != 0)
                        // iftrue(Label_0036:, fc.1 != 0)
                        // switch([Lcom.strobel.decompiler.ast.Label;@3e2d2d61, n4 ^ 0x5EE0E192)
                        // iftrue(Label_0200:, fc.0 > 0)
                        // iftrue(Label_0146:, fc.0 > 0)
                        // iftrue(Label_0086:, fc.1 != 0)
                        catch (NoSuchElementException ex4) {}
                    }
                    continue Label_0548;
                } while (o == null);
                break;
            }
        }
        throw (Throwable)o;
    }
    
    @NotNull
    public Vec2f 0(@NotNull final Vec3d p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          474
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            466
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            458
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: aload_1        
        //    27: getfield        net/minecraft/util/math/Vec3d.field_72450_a:D
        //    30: dstore_2       
        //    31: aload_1        
        //    32: getstatic       dev/nuker/pyro/fc.0:I
        //    35: ifgt            44
        //    38: ldc_w           -1021207746
        //    41: goto            47
        //    44: ldc_w           -1983691527
        //    47: ldc_w           -936632767
        //    50: ixor           
        //    51: lookupswitch {
        //          -130946190: 44
        //          185435519: 437
        //          default: 76
        //        }
        //    76: getfield        net/minecraft/util/math/Vec3d.field_72448_b:D
        //    79: dstore          4
        //    81: aload_1        
        //    82: getfield        net/minecraft/util/math/Vec3d.field_72449_c:D
        //    85: dstore          6
        //    87: dload_2        
        //    88: dload_2        
        //    89: dmul           
        //    90: getstatic       dev/nuker/pyro/fc.1:I
        //    93: ifne            102
        //    96: ldc_w           -1543753646
        //    99: goto            105
        //   102: ldc_w           1716699340
        //   105: ldc_w           -140136245
        //   108: ixor           
        //   109: lookupswitch {
        //          -747048879: 102
        //          1415151769: 447
        //          default: 136
        //        }
        //   136: dload           6
        //   138: dload           6
        //   140: dmul           
        //   141: dadd           
        //   142: goto            146
        //   145: athrow         
        //   146: invokestatic    java/lang/Math.sqrt:(D)D
        //   149: goto            153
        //   152: athrow         
        //   153: dstore          8
        //   155: dload           6
        //   157: dload_2        
        //   158: goto            162
        //   161: athrow         
        //   162: invokestatic    java/lang/Math.atan2:(DD)D
        //   165: goto            169
        //   168: athrow         
        //   169: goto            173
        //   172: athrow         
        //   173: invokestatic    java/lang/Math.toDegrees:(D)D
        //   176: goto            180
        //   179: athrow         
        //   180: d2f            
        //   181: ldc             90.0
        //   183: fsub           
        //   184: fstore          10
        //   186: dload           4
        //   188: getstatic       dev/nuker/pyro/fc.1:I
        //   191: ifne            200
        //   194: ldc_w           -1610675833
        //   197: goto            203
        //   200: ldc_w           -2051056135
        //   203: ldc_w           -271565308
        //   206: ixor           
        //   207: lookupswitch {
        //          -823425302: 200
        //          1882142595: 445
        //          default: 232
        //        }
        //   232: dload           8
        //   234: goto            238
        //   237: athrow         
        //   238: invokestatic    java/lang/Math.atan2:(DD)D
        //   241: goto            245
        //   244: athrow         
        //   245: goto            249
        //   248: athrow         
        //   249: invokestatic    java/lang/Math.toDegrees:(D)D
        //   252: goto            256
        //   255: athrow         
        //   256: dneg           
        //   257: d2f            
        //   258: getstatic       dev/nuker/pyro/fc.1:I
        //   261: ifne            270
        //   264: ldc_w           2110947101
        //   267: goto            273
        //   270: ldc_w           -1915385059
        //   273: ldc_w           67921297
        //   276: ixor           
        //   277: lookupswitch {
        //          -1982206324: 304
        //          2044598924: 270
        //          default: 441
        //        }
        //   304: fstore          11
        //   306: new             Lnet/minecraft/util/math/Vec2f;
        //   309: dup            
        //   310: fload           10
        //   312: getstatic       dev/nuker/pyro/fc.0:I
        //   315: ifgt            324
        //   318: ldc_w           -916381460
        //   321: goto            327
        //   324: ldc_w           1926992754
        //   327: ldc_w           -987542704
        //   330: ixor           
        //   331: lookupswitch {
        //          -1332228211: 324
        //          205679548: 443
        //          default: 356
        //        }
        //   356: goto            360
        //   359: athrow         
        //   360: invokestatic    net/minecraft/util/math/MathHelper.func_76142_g:(F)F
        //   363: goto            367
        //   366: athrow         
        //   367: getstatic       dev/nuker/pyro/fc.1:I
        //   370: ifne            379
        //   373: ldc_w           -2130329162
        //   376: goto            382
        //   379: ldc_w           -1064039138
        //   382: ldc_w           97463137
        //   385: ixor           
        //   386: lookupswitch {
        //          -2067076393: 439
        //          -859961715: 379
        //          default: 412
        //        }
        //   412: fload           11
        //   414: goto            418
        //   417: athrow         
        //   418: invokestatic    net/minecraft/util/math/MathHelper.func_76142_g:(F)F
        //   421: goto            425
        //   424: athrow         
        //   425: goto            429
        //   428: athrow         
        //   429: invokespecial   net/minecraft/util/math/Vec2f.<init>:(FF)V
        //   432: goto            436
        //   435: athrow         
        //   436: areturn        
        //   437: aconst_null    
        //   438: athrow         
        //   439: aconst_null    
        //   440: athrow         
        //   441: aconst_null    
        //   442: athrow         
        //   443: aconst_null    
        //   444: athrow         
        //   445: aconst_null    
        //   446: athrow         
        //   447: aconst_null    
        //   448: athrow         
        //   449: pop            
        //   450: goto            24
        //   453: pop            
        //   454: aconst_null    
        //   455: goto            449
        //   458: dup            
        //   459: ifnull          449
        //   462: checkcast       Ljava/lang/Throwable;
        //   465: athrow         
        //   466: dup            
        //   467: ifnull          453
        //   470: checkcast       Ljava/lang/Throwable;
        //   473: athrow         
        //   474: aconst_null    
        //   475: athrow         
        //    StackMapTable: 00 41 FF 00 03 00 05 07 00 03 07 00 1D 03 03 03 00 01 07 00 1B F8 00 04 FF 00 0B 00 00 00 01 07 00 1B FD 00 03 07 00 03 07 00 1D FF 00 13 00 03 07 00 03 07 00 1D 03 00 01 07 00 1D FF 00 02 00 03 07 00 03 07 00 1D 03 00 02 07 00 1D 01 5C 07 00 1D FF 00 19 00 05 07 00 03 07 00 1D 03 03 03 00 01 03 FF 00 02 00 05 07 00 03 07 00 1D 03 03 03 00 02 03 01 5E 03 48 07 00 1B 40 03 45 07 00 1B 40 03 FF 00 07 00 06 07 00 03 07 00 1D 03 03 03 03 00 01 07 00 1B FF 00 00 00 06 07 00 03 07 00 1D 03 03 03 03 00 02 03 03 45 07 00 1B 40 03 42 07 00 0D 40 03 45 07 00 1B 40 03 FF 00 13 00 07 07 00 03 07 00 1D 03 03 03 03 02 00 01 03 FF 00 02 00 07 07 00 03 07 00 1D 03 03 03 03 02 00 02 03 01 5C 03 44 07 00 1B FF 00 00 00 07 07 00 03 07 00 1D 03 03 03 03 02 00 02 03 03 45 07 00 1B 40 03 42 07 00 1B 40 03 45 07 00 1B 40 03 4D 02 FF 00 02 00 07 07 00 03 07 00 1D 03 03 03 03 02 00 02 02 01 5E 02 FF 00 13 00 08 07 00 03 07 00 1D 03 03 03 03 02 02 00 03 08 01 32 08 01 32 02 FF 00 02 00 08 07 00 03 07 00 1D 03 03 03 03 02 02 00 04 08 01 32 08 01 32 02 01 FF 00 1C 00 08 07 00 03 07 00 1D 03 03 03 03 02 02 00 03 08 01 32 08 01 32 02 42 07 00 1B FF 00 00 00 08 07 00 03 07 00 1D 03 03 03 03 02 02 00 03 08 01 32 08 01 32 02 45 07 00 1B FF 00 00 00 08 07 00 03 07 00 1D 03 03 03 03 02 02 00 03 08 01 32 08 01 32 02 FF 00 0B 00 08 07 00 03 07 00 1D 03 03 03 03 02 02 00 03 08 01 32 08 01 32 02 FF 00 02 00 08 07 00 03 07 00 1D 03 03 03 03 02 02 00 04 08 01 32 08 01 32 02 01 FF 00 1D 00 08 07 00 03 07 00 1D 03 03 03 03 02 02 00 03 08 01 32 08 01 32 02 44 07 00 66 FF 00 00 00 08 07 00 03 07 00 1D 03 03 03 03 02 02 00 04 08 01 32 08 01 32 02 02 45 07 00 1B FF 00 00 00 08 07 00 03 07 00 1D 03 03 03 03 02 02 00 04 08 01 32 08 01 32 02 02 42 07 00 55 FF 00 00 00 08 07 00 03 07 00 1D 03 03 03 03 02 02 00 04 08 01 32 08 01 32 02 02 45 07 00 1B 40 07 00 9F FF 00 00 00 03 07 00 03 07 00 1D 03 00 01 07 00 1D FF 00 01 00 08 07 00 03 07 00 1D 03 03 03 03 02 02 00 03 08 01 32 08 01 32 02 FF 00 01 00 07 07 00 03 07 00 1D 03 03 03 03 02 00 01 02 FF 00 01 00 08 07 00 03 07 00 1D 03 03 03 03 02 02 00 03 08 01 32 08 01 32 02 FF 00 01 00 07 07 00 03 07 00 1D 03 03 03 03 02 00 01 03 FF 00 01 00 05 07 00 03 07 00 1D 03 03 03 00 01 03 FF 00 01 00 02 07 00 03 07 00 1D 00 01 07 00 1B 43 05 44 07 00 1B 47 05 FF 00 07 00 05 07 00 03 07 00 1D 03 03 03 00 01 07 00 1B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     458    466    Any
        //  458    466    458    466    Any
        //  474    476    3      8      Ljava/lang/NegativeArraySizeException;
        //  145    152    152    153    Any
        //  146    152    145    146    Any
        //  145    152    145    146    Any
        //  145    152    152    153    Any
        //  145    152    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  161    168    168    169    Any
        //  162    168    161    162    Any
        //  162    168    168    169    Ljava/util/ConcurrentModificationException;
        //  161    168    161    162    Any
        //  161    168    3      8      Ljava/lang/UnsupportedOperationException;
        //  172    179    179    180    Any
        //  172    179    172    173    Ljava/lang/NullPointerException;
        //  173    179    3      8      Ljava/lang/AssertionError;
        //  173    179    3      8      Ljava/lang/IllegalArgumentException;
        //  172    179    179    180    Ljava/lang/RuntimeException;
        //  237    244    244    245    Any
        //  238    244    237    238    Any
        //  238    244    237    238    Any
        //  238    244    3      8      Any
        //  238    244    237    238    Any
        //  248    255    255    256    Any
        //  249    255    3      8      Ljava/lang/AssertionError;
        //  249    255    255    256    Ljava/lang/NullPointerException;
        //  248    255    248    249    Any
        //  249    255    3      8      Any
        //  359    366    366    367    Any
        //  359    366    366    367    Ljava/lang/NumberFormatException;
        //  359    366    3      8      Ljava/util/NoSuchElementException;
        //  359    366    3      8      Any
        //  359    366    359    360    Any
        //  417    424    424    425    Any
        //  417    424    424    425    Any
        //  417    424    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  417    424    417    418    Ljava/lang/UnsupportedOperationException;
        //  418    424    424    425    Any
        //  428    435    435    436    Any
        //  429    435    435    436    Any
        //  429    435    428    429    Ljava/lang/IllegalStateException;
        //  428    435    428    429    Ljava/lang/IllegalStateException;
        //  429    435    428    429    Ljava/lang/ClassCastException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:733)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void c(@NotNull final Vec2f p0, final boolean p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          251
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            243
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            235
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: aload_0        
        //    27: getstatic       dev/nuker/pyro/fc.c:I
        //    30: ifne            39
        //    33: ldc_w           -801507689
        //    36: goto            42
        //    39: ldc_w           56166260
        //    42: ldc_w           -1086261988
        //    45: ixor           
        //    46: lookupswitch {
        //          -1428836125: 39
        //          1870201739: 224
        //          default: 72
        //        }
        //    72: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //    75: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //    78: getstatic       dev/nuker/pyro/fc.0:I
        //    81: ifgt            90
        //    84: ldc_w           -354026145
        //    87: goto            93
        //    90: ldc_w           508174456
        //    93: ldc_w           813015020
        //    96: ixor           
        //    97: lookupswitch {
        //          -1772315467: 90
        //          -628071757: 222
        //          default: 124
        //        }
        //   124: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71174_a:Lnet/minecraft/client/network/NetHandlerPlayClient;
        //   127: new             Lnet/minecraft/network/play/client/CPacketPlayer$Rotation;
        //   130: dup            
        //   131: getstatic       dev/nuker/pyro/fc.c:I
        //   134: ifne            143
        //   137: ldc_w           1715778842
        //   140: goto            146
        //   143: ldc_w           -539696516
        //   146: ldc_w           -1389575540
        //   149: ixor           
        //   150: lookupswitch {
        //          -882346090: 220
        //          797944345: 143
        //          default: 176
        //        }
        //   176: aload_1        
        //   177: getfield        net/minecraft/util/math/Vec2f.field_189982_i:F
        //   180: aload_1        
        //   181: getfield        net/minecraft/util/math/Vec2f.field_189983_j:F
        //   184: aload_0        
        //   185: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   188: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   191: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70122_E:Z
        //   194: goto            198
        //   197: athrow         
        //   198: invokespecial   net/minecraft/network/play/client/CPacketPlayer$Rotation.<init>:(FFZ)V
        //   201: goto            205
        //   204: athrow         
        //   205: checkcast       Lnet/minecraft/network/Packet;
        //   208: goto            212
        //   211: athrow         
        //   212: invokevirtual   net/minecraft/client/network/NetHandlerPlayClient.func_147297_a:(Lnet/minecraft/network/Packet;)V
        //   215: goto            219
        //   218: athrow         
        //   219: return         
        //   220: aconst_null    
        //   221: athrow         
        //   222: aconst_null    
        //   223: athrow         
        //   224: aconst_null    
        //   225: athrow         
        //   226: pop            
        //   227: goto            24
        //   230: pop            
        //   231: aconst_null    
        //   232: goto            226
        //   235: dup            
        //   236: ifnull          226
        //   239: checkcast       Ljava/lang/Throwable;
        //   242: athrow         
        //   243: dup            
        //   244: ifnull          230
        //   247: checkcast       Ljava/lang/Throwable;
        //   250: athrow         
        //   251: aconst_null    
        //   252: athrow         
        //    StackMapTable: 00 1D 43 07 00 1B 04 FF 00 0B 00 00 00 01 07 00 1B FE 00 03 07 00 03 07 00 9F 01 4E 07 00 03 FF 00 02 00 03 07 00 03 07 00 9F 01 00 02 07 00 03 01 5D 07 00 03 51 07 00 2C FF 00 02 00 03 07 00 03 07 00 9F 01 00 02 07 00 2C 01 5E 07 00 2C FF 00 12 00 03 07 00 03 07 00 9F 01 00 03 07 02 5B 08 00 7F 08 00 7F FF 00 02 00 03 07 00 03 07 00 9F 01 00 04 07 02 5B 08 00 7F 08 00 7F 01 FF 00 1D 00 03 07 00 03 07 00 9F 01 00 03 07 02 5B 08 00 7F 08 00 7F 54 07 00 64 FF 00 00 00 03 07 00 03 07 00 9F 01 00 06 07 02 5B 08 00 7F 08 00 7F 02 02 01 45 07 00 1B FF 00 00 00 03 07 00 03 07 00 9F 01 00 02 07 02 5B 07 02 44 45 07 00 1B FF 00 00 00 03 07 00 03 07 00 9F 01 00 02 07 02 5B 07 02 59 45 07 00 1B 00 FF 00 00 00 03 07 00 03 07 00 9F 01 00 03 07 02 5B 08 00 7F 08 00 7F 41 07 00 2C 41 07 00 03 41 07 00 1B 43 05 44 07 00 1B 47 05 47 07 00 1B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                     
        //  -----  -----  -----  -----  -----------------------------------------
        //  8      20     235    243    Any
        //  235    243    235    243    Any
        //  251    253    3      8      Any
        //  197    204    204    205    Any
        //  198    204    3      8      Ljava/lang/ArithmeticException;
        //  198    204    3      8      Any
        //  197    204    197    198    Ljava/lang/NumberFormatException;
        //  198    204    3      8      Any
        //  211    218    218    219    Any
        //  211    218    3      8      Ljava/lang/NumberFormatException;
        //  212    218    211    212    Any
        //  211    218    218    219    Ljava/lang/UnsupportedOperationException;
        //  212    218    211    212    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:595)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void c(final fdU fdU) {
        fez.d6(null, 1137479461, fdU);
    }
    
    @NotNull
    public Vec2f c(@NotNull final EnumFacing p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          95
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            87
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            79
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: new             Lnet/minecraft/util/math/Vec2f;
        //    29: dup            
        //    30: aload_1        
        //    31: goto            35
        //    34: athrow         
        //    35: invokevirtual   net/minecraft/util/EnumFacing.func_185119_l:()F
        //    38: goto            42
        //    41: athrow         
        //    42: aload_1        
        //    43: goto            47
        //    46: athrow         
        //    47: invokevirtual   net/minecraft/util/EnumFacing.func_96559_d:()I
        //    50: goto            54
        //    53: athrow         
        //    54: bipush          90
        //    56: imul           
        //    57: i2f            
        //    58: goto            62
        //    61: athrow         
        //    62: invokespecial   net/minecraft/util/math/Vec2f.<init>:(FF)V
        //    65: goto            69
        //    68: athrow         
        //    69: areturn        
        //    70: pop            
        //    71: goto            24
        //    74: pop            
        //    75: aconst_null    
        //    76: goto            70
        //    79: dup            
        //    80: ifnull          70
        //    83: checkcast       Ljava/lang/Throwable;
        //    86: athrow         
        //    87: dup            
        //    88: ifnull          74
        //    91: checkcast       Ljava/lang/Throwable;
        //    94: athrow         
        //    95: aconst_null    
        //    96: athrow         
        //    StackMapTable: 00 15 43 07 00 1B 04 FF 00 0B 00 00 00 01 07 00 1B FD 00 03 07 00 03 07 01 1D 49 07 00 68 FF 00 00 00 02 07 00 03 07 01 1D 00 03 08 00 1A 08 00 1A 07 01 1D 45 07 00 1B FF 00 00 00 02 07 00 03 07 01 1D 00 03 08 00 1A 08 00 1A 02 43 07 00 1B FF 00 00 00 02 07 00 03 07 01 1D 00 04 08 00 1A 08 00 1A 02 07 01 1D 45 07 00 1B FF 00 00 00 02 07 00 03 07 01 1D 00 04 08 00 1A 08 00 1A 02 01 46 07 00 1B FF 00 00 00 02 07 00 03 07 01 1D 00 04 08 00 1A 08 00 1A 02 02 45 07 00 1B 40 07 00 9F 40 07 00 1B 43 05 44 07 00 1B 47 05 47 07 00 1B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     79     87     Any
        //  79     87     79     87     Any
        //  95     97     3      8      Any
        //  34     41     41     42     Any
        //  34     41     3      8      Ljava/lang/AssertionError;
        //  34     41     3      8      Any
        //  35     41     3      8      Ljava/lang/IndexOutOfBoundsException;
        //  34     41     34     35     Ljava/lang/NegativeArraySizeException;
        //  46     53     53     54     Any
        //  46     53     46     47     Any
        //  47     53     53     54     Any
        //  47     53     3      8      Any
        //  47     53     3      8      Ljava/lang/IllegalArgumentException;
        //  61     68     68     69     Any
        //  62     68     61     62     Ljava/lang/IndexOutOfBoundsException;
        //  62     68     61     62     Ljava/util/ConcurrentModificationException;
        //  62     68     3      8      Any
        //  61     68     61     62     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:543)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public boolean c(@NotNull final BlockPos p0, @NotNull final fdS p1, final boolean p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          2166
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            2158
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            2150
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: aload_2        
        //    27: pop            
        //    28: aload_0        
        //    29: getstatic       dev/nuker/pyro/fc.0:I
        //    32: ifgt            41
        //    35: ldc_w           1159170847
        //    38: goto            44
        //    41: ldc_w           1335224526
        //    44: ldc_w           -558522598
        //    47: ixor           
        //    48: lookupswitch {
        //          -1860143148: 76
        //          -1683876859: 41
        //          default: 2105
        //        }
        //    76: aload_1        
        //    77: goto            81
        //    80: athrow         
        //    81: invokevirtual   dev/nuker/pyro/fdU.3:(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/Tuple;
        //    84: goto            88
        //    87: athrow         
        //    88: astore          4
        //    90: aload           4
        //    92: ifnull          101
        //    95: ldc_w           1701185620
        //    98: goto            104
        //   101: ldc_w           1701185623
        //   104: ldc_w           -517149631
        //   107: ixor           
        //   108: tableswitch {
        //          144033834: 132
        //          144033835: 2081
        //          default: 95
        //        }
        //   132: aload_0        
        //   133: aload           4
        //   135: goto            139
        //   138: athrow         
        //   139: invokevirtual   net/minecraft/util/Tuple.func_76341_a:()Ljava/lang/Object;
        //   142: goto            146
        //   145: athrow         
        //   146: checkcast       Lnet/minecraft/util/math/BlockPos;
        //   149: aload_0        
        //   150: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   153: getstatic       dev/nuker/pyro/fc.c:I
        //   156: ifne            165
        //   159: ldc_w           769502054
        //   162: goto            168
        //   165: ldc_w           1322005496
        //   168: ldc_w           -579877255
        //   171: ixor           
        //   172: lookupswitch {
        //          -256742113: 2101
        //          239950874: 165
        //          default: 200
        //        }
        //   200: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //   203: dup            
        //   204: pop            
        //   205: checkcast       Lnet/minecraft/world/World;
        //   208: getstatic       dev/nuker/pyro/fc.0:I
        //   211: ifgt            220
        //   214: ldc_w           1495293908
        //   217: goto            223
        //   220: ldc_w           971543403
        //   223: ldc_w           -1691159574
        //   226: ixor           
        //   227: lookupswitch {
        //          -1562746751: 252
        //          -1038963650: 220
        //          default: 2133
        //        }
        //   252: aload           4
        //   254: getstatic       dev/nuker/pyro/fc.0:I
        //   257: ifgt            266
        //   260: ldc_w           -1355565512
        //   263: goto            269
        //   266: ldc_w           12587649
        //   269: ldc_w           1835237451
        //   272: ixor           
        //   273: lookupswitch {
        //          -1034930573: 2119
        //          1316823186: 266
        //          default: 300
        //        }
        //   300: goto            304
        //   303: athrow         
        //   304: invokevirtual   net/minecraft/util/Tuple.func_76340_b:()Ljava/lang/Object;
        //   307: goto            311
        //   310: athrow         
        //   311: dup            
        //   312: pop            
        //   313: checkcast       Lnet/minecraft/util/EnumFacing;
        //   316: goto            320
        //   319: athrow         
        //   320: invokevirtual   dev/nuker/pyro/fdU.c:(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/world/World;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/Vec3d;
        //   323: goto            327
        //   326: athrow         
        //   327: astore          5
        //   329: aload_0        
        //   330: getstatic       dev/nuker/pyro/fc.1:I
        //   333: ifne            342
        //   336: ldc_w           738932313
        //   339: goto            345
        //   342: ldc_w           -786929564
        //   345: ldc_w           -2146892552
        //   348: ixor           
        //   349: lookupswitch {
        //          -1409142111: 342
        //          1360096412: 376
        //          default: 2129
        //        }
        //   376: goto            380
        //   379: athrow         
        //   380: invokevirtual   dev/nuker/pyro/fdU.0:()Lnet/minecraft/util/math/Vec2f;
        //   383: goto            387
        //   386: athrow         
        //   387: astore          6
        //   389: getstatic       dev/nuker/pyro/fc.c:I
        //   392: ifne            401
        //   395: ldc_w           101844981
        //   398: goto            404
        //   401: ldc_w           1806630242
        //   404: ldc_w           -297827192
        //   407: ixor           
        //   408: lookupswitch {
        //          -1264079561: 401
        //          -399670403: 2093
        //          default: 436
        //        }
        //   436: aload_2        
        //   437: getstatic       dev/nuker/pyro/fdS.c:Ldev/nuker/pyro/fdS;
        //   440: if_acmpeq       558
        //   443: aload_0        
        //   444: getstatic       dev/nuker/pyro/fc.c:I
        //   447: ifne            456
        //   450: ldc_w           1886855094
        //   453: goto            459
        //   456: ldc_w           -1304323894
        //   459: ldc_w           -821962789
        //   462: ixor           
        //   463: lookupswitch {
        //          -1082734483: 456
        //          2101366545: 488
        //          default: 2091
        //        }
        //   488: aload           5
        //   490: aload_2        
        //   491: getstatic       dev/nuker/pyro/fc.0:I
        //   494: ifgt            503
        //   497: ldc_w           -1412949
        //   500: goto            506
        //   503: ldc_w           -1621177382
        //   506: ldc_w           -1350640271
        //   509: ixor           
        //   510: lookupswitch {
        //          807409323: 536
        //          1351921114: 503
        //          default: 2121
        //        }
        //   536: getstatic       dev/nuker/pyro/fdS.0:Ldev/nuker/pyro/fdS;
        //   539: if_acmpne       546
        //   542: iconst_1       
        //   543: goto            547
        //   546: iconst_0       
        //   547: goto            551
        //   550: athrow         
        //   551: invokevirtual   dev/nuker/pyro/fdU.0:(Lnet/minecraft/util/math/Vec3d;Z)V
        //   554: goto            558
        //   557: athrow         
        //   558: iconst_0       
        //   559: getstatic       dev/nuker/pyro/fc.1:I
        //   562: ifne            571
        //   565: ldc_w           -1718183461
        //   568: goto            574
        //   571: ldc_w           -1234244602
        //   574: ldc_w           1796407085
        //   577: ixor           
        //   578: lookupswitch {
        //          -579071189: 604
        //          -226203914: 571
        //          default: 2139
        //        }
        //   604: istore          7
        //   606: aload_0        
        //   607: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   610: getstatic       dev/nuker/pyro/fc.1:I
        //   613: ifne            622
        //   616: ldc_w           -752603277
        //   619: goto            625
        //   622: ldc_w           -483361854
        //   625: ldc_w           -133846534
        //   628: ixor           
        //   629: lookupswitch {
        //          456512056: 656
        //          723617417: 622
        //          default: 2111
        //        }
        //   656: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //   659: getstatic       dev/nuker/pyro/fc.c:I
        //   662: ifne            671
        //   665: ldc_w           -502360263
        //   668: goto            674
        //   671: ldc_w           990924397
        //   674: ldc_w           -674236511
        //   677: ixor           
        //   678: lookupswitch {
        //          -320882228: 704
        //          901865624: 671
        //          default: 2083
        //        }
        //   704: aload           4
        //   706: getstatic       dev/nuker/pyro/fc.c:I
        //   709: ifne            718
        //   712: ldc_w           599131960
        //   715: goto            721
        //   718: ldc_w           -1564553666
        //   721: ldc_w           -2041887150
        //   724: ixor           
        //   725: lookupswitch {
        //          -1510129302: 718
        //          620071020: 752
        //          default: 2123
        //        }
        //   752: goto            756
        //   755: athrow         
        //   756: invokevirtual   net/minecraft/util/Tuple.func_76341_a:()Ljava/lang/Object;
        //   759: goto            763
        //   762: athrow         
        //   763: checkcast       Lnet/minecraft/util/math/BlockPos;
        //   766: goto            770
        //   769: athrow         
        //   770: invokevirtual   net/minecraft/client/multiplayer/WorldClient.func_180495_p:(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
        //   773: goto            777
        //   776: athrow         
        //   777: dup            
        //   778: pop            
        //   779: goto            783
        //   782: athrow         
        //   783: invokeinterface net/minecraft/block/state/IBlockState.func_177230_c:()Lnet/minecraft/block/Block;
        //   788: goto            792
        //   791: athrow         
        //   792: astore          8
        //   794: aload_0        
        //   795: aload           8
        //   797: goto            801
        //   800: athrow         
        //   801: invokevirtual   dev/nuker/pyro/fdU.c:(Lnet/minecraft/block/Block;)Z
        //   804: goto            808
        //   807: athrow         
        //   808: ifeq            814
        //   811: iconst_1       
        //   812: istore          7
        //   814: iload           7
        //   816: ifeq            825
        //   819: ldc_w           -1949938176
        //   822: goto            828
        //   825: ldc_w           -1949938173
        //   828: ldc_w           -141166839
        //   831: ixor           
        //   832: tableswitch {
        //          -123244014: 856
        //          -123244013: 1042
        //          default: 819
        //        }
        //   856: aload_0        
        //   857: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   860: getstatic       dev/nuker/pyro/fc.0:I
        //   863: ifgt            872
        //   866: ldc_w           -599899911
        //   869: goto            875
        //   872: ldc_w           -718094278
        //   875: ldc_w           -1446305359
        //   878: ixor           
        //   879: lookupswitch {
        //          1979015496: 2085
        //          2070479552: 872
        //          default: 904
        //        }
        //   904: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   907: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71174_a:Lnet/minecraft/client/network/NetHandlerPlayClient;
        //   910: new             Lnet/minecraft/network/play/client/CPacketEntityAction;
        //   913: dup            
        //   914: aload_0        
        //   915: getstatic       dev/nuker/pyro/fc.0:I
        //   918: ifgt            927
        //   921: ldc_w           -1421167996
        //   924: goto            930
        //   927: ldc_w           1944545483
        //   930: ldc_w           802584444
        //   933: ixor           
        //   934: lookupswitch {
        //          -2070100488: 927
        //          1546723255: 960
        //          default: 2135
        //        }
        //   960: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   963: getstatic       dev/nuker/pyro/fc.1:I
        //   966: ifne            975
        //   969: ldc_w           -1202080969
        //   972: goto            978
        //   975: ldc_w           1996478827
        //   978: ldc_w           909407114
        //   981: ixor           
        //   982: lookupswitch {
        //          -1905409859: 975
        //          1087089377: 1008
        //          default: 2125
        //        }
        //  1008: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1011: checkcast       Lnet/minecraft/entity/Entity;
        //  1014: getstatic       net/minecraft/network/play/client/CPacketEntityAction$Action.START_SNEAKING:Lnet/minecraft/network/play/client/CPacketEntityAction$Action;
        //  1017: goto            1021
        //  1020: athrow         
        //  1021: invokespecial   net/minecraft/network/play/client/CPacketEntityAction.<init>:(Lnet/minecraft/entity/Entity;Lnet/minecraft/network/play/client/CPacketEntityAction$Action;)V
        //  1024: goto            1028
        //  1027: athrow         
        //  1028: checkcast       Lnet/minecraft/network/Packet;
        //  1031: goto            1035
        //  1034: athrow         
        //  1035: invokevirtual   net/minecraft/client/network/NetHandlerPlayClient.func_147297_a:(Lnet/minecraft/network/Packet;)V
        //  1038: goto            1042
        //  1041: athrow         
        //  1042: getstatic       dev/nuker/pyro/fc.c:I
        //  1045: ifne            1054
        //  1048: ldc_w           1493337107
        //  1051: goto            1057
        //  1054: ldc_w           -207222194
        //  1057: ldc_w           -1163261644
        //  1060: ixor           
        //  1061: lookupswitch {
        //          -475493081: 2137
        //          2116380621: 1054
        //          default: 1088
        //        }
        //  1088: iload_3        
        //  1089: ifeq            1469
        //  1092: getstatic       dev/nuker/pyro/fc.1:I
        //  1095: ifne            1104
        //  1098: ldc_w           842196682
        //  1101: goto            1107
        //  1104: ldc_w           -1537722942
        //  1107: ldc_w           -965657913
        //  1110: ixor           
        //  1111: lookupswitch {
        //          -196879347: 1104
        //          1646857989: 1136
        //          default: 2113
        //        }
        //  1136: aload           5
        //  1138: getfield        net/minecraft/util/math/Vec3d.field_72450_a:D
        //  1141: aload           4
        //  1143: getstatic       dev/nuker/pyro/fc.0:I
        //  1146: ifgt            1155
        //  1149: ldc_w           -123113240
        //  1152: goto            1158
        //  1155: ldc_w           -1017749208
        //  1158: ldc_w           -189364677
        //  1161: ixor           
        //  1162: lookupswitch {
        //          203421395: 1155
        //          937486099: 1188
        //          default: 2131
        //        }
        //  1188: goto            1192
        //  1191: athrow         
        //  1192: invokevirtual   net/minecraft/util/Tuple.func_76341_a:()Ljava/lang/Object;
        //  1195: goto            1199
        //  1198: athrow         
        //  1199: dup            
        //  1200: pop            
        //  1201: checkcast       Lnet/minecraft/util/math/BlockPos;
        //  1204: getstatic       dev/nuker/pyro/fc.1:I
        //  1207: ifne            1216
        //  1210: ldc_w           -1375977130
        //  1213: goto            1219
        //  1216: ldc_w           -1172897209
        //  1219: ldc_w           -1299153969
        //  1222: ixor           
        //  1223: lookupswitch {
        //          143096200: 1248
        //          527186585: 1216
        //          default: 2095
        //        }
        //  1248: goto            1252
        //  1251: athrow         
        //  1252: invokevirtual   net/minecraft/util/math/BlockPos.func_177958_n:()I
        //  1255: goto            1259
        //  1258: athrow         
        //  1259: i2d            
        //  1260: dsub           
        //  1261: d2f            
        //  1262: fstore          9
        //  1264: aload           5
        //  1266: getfield        net/minecraft/util/math/Vec3d.field_72448_b:D
        //  1269: aload           4
        //  1271: goto            1275
        //  1274: athrow         
        //  1275: invokevirtual   net/minecraft/util/Tuple.func_76341_a:()Ljava/lang/Object;
        //  1278: goto            1282
        //  1281: athrow         
        //  1282: dup            
        //  1283: pop            
        //  1284: checkcast       Lnet/minecraft/util/math/BlockPos;
        //  1287: goto            1291
        //  1290: athrow         
        //  1291: invokevirtual   net/minecraft/util/math/BlockPos.func_177956_o:()I
        //  1294: goto            1298
        //  1297: athrow         
        //  1298: i2d            
        //  1299: dsub           
        //  1300: d2f            
        //  1301: fstore          10
        //  1303: aload           5
        //  1305: getfield        net/minecraft/util/math/Vec3d.field_72449_c:D
        //  1308: aload           4
        //  1310: goto            1314
        //  1313: athrow         
        //  1314: invokevirtual   net/minecraft/util/Tuple.func_76341_a:()Ljava/lang/Object;
        //  1317: goto            1321
        //  1320: athrow         
        //  1321: dup            
        //  1322: pop            
        //  1323: checkcast       Lnet/minecraft/util/math/BlockPos;
        //  1326: goto            1330
        //  1329: athrow         
        //  1330: invokevirtual   net/minecraft/util/math/BlockPos.func_177952_p:()I
        //  1333: goto            1337
        //  1336: athrow         
        //  1337: i2d            
        //  1338: dsub           
        //  1339: d2f            
        //  1340: fstore          11
        //  1342: aload_0        
        //  1343: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //  1346: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1349: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71174_a:Lnet/minecraft/client/network/NetHandlerPlayClient;
        //  1352: new             Lnet/minecraft/network/play/client/CPacketPlayerTryUseItemOnBlock;
        //  1355: dup            
        //  1356: aload           4
        //  1358: goto            1362
        //  1361: athrow         
        //  1362: invokevirtual   net/minecraft/util/Tuple.func_76341_a:()Ljava/lang/Object;
        //  1365: goto            1369
        //  1368: athrow         
        //  1369: checkcast       Lnet/minecraft/util/math/BlockPos;
        //  1372: getstatic       dev/nuker/pyro/fc.c:I
        //  1375: ifne            1384
        //  1378: ldc_w           460335884
        //  1381: goto            1387
        //  1384: ldc_w           101488475
        //  1387: ldc_w           1200800646
        //  1390: ixor           
        //  1391: lookupswitch {
        //          1100895453: 1416
        //          1558374538: 1384
        //          default: 2117
        //        }
        //  1416: aload           4
        //  1418: goto            1422
        //  1421: athrow         
        //  1422: invokevirtual   net/minecraft/util/Tuple.func_76340_b:()Ljava/lang/Object;
        //  1425: goto            1429
        //  1428: athrow         
        //  1429: checkcast       Lnet/minecraft/util/EnumFacing;
        //  1432: getstatic       net/minecraft/util/EnumHand.MAIN_HAND:Lnet/minecraft/util/EnumHand;
        //  1435: fload           9
        //  1437: fload           10
        //  1439: fload           11
        //  1441: goto            1445
        //  1444: athrow         
        //  1445: invokespecial   net/minecraft/network/play/client/CPacketPlayerTryUseItemOnBlock.<init>:(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/util/EnumHand;FFF)V
        //  1448: goto            1452
        //  1451: athrow         
        //  1452: checkcast       Lnet/minecraft/network/Packet;
        //  1455: goto            1459
        //  1458: athrow         
        //  1459: invokevirtual   net/minecraft/client/network/NetHandlerPlayClient.func_147297_a:(Lnet/minecraft/network/Packet;)V
        //  1462: goto            1466
        //  1465: athrow         
        //  1466: goto            1763
        //  1469: aload_0        
        //  1470: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //  1473: getfield        net/minecraft/client/Minecraft.field_71442_b:Lnet/minecraft/client/multiplayer/PlayerControllerMP;
        //  1476: aload_0        
        //  1477: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //  1480: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1483: getstatic       dev/nuker/pyro/fc.c:I
        //  1486: ifne            1495
        //  1489: ldc_w           1629068162
        //  1492: goto            1498
        //  1495: ldc_w           -1842150227
        //  1498: ldc_w           1954910036
        //  1501: ixor           
        //  1502: lookupswitch {
        //          -28142750: 1495
        //          362550486: 2097
        //          default: 1528
        //        }
        //  1528: aload_0        
        //  1529: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //  1532: getstatic       dev/nuker/pyro/fc.1:I
        //  1535: ifne            1544
        //  1538: ldc_w           -1015568239
        //  1541: goto            1547
        //  1544: ldc_w           -1455490345
        //  1547: ldc_w           1417799271
        //  1550: ixor           
        //  1551: lookupswitch {
        //          -1745465610: 1544
        //          -37806928: 1576
        //          default: 2115
        //        }
        //  1576: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //  1579: getstatic       dev/nuker/pyro/fc.0:I
        //  1582: ifgt            1591
        //  1585: ldc_w           1014831323
        //  1588: goto            1594
        //  1591: ldc_w           -93968147
        //  1594: ldc_w           -636225785
        //  1597: ixor           
        //  1598: lookupswitch {
        //          -428937252: 2087
        //          1578179040: 1591
        //          default: 1624
        //        }
        //  1624: aload           4
        //  1626: goto            1630
        //  1629: athrow         
        //  1630: invokevirtual   net/minecraft/util/Tuple.func_76341_a:()Ljava/lang/Object;
        //  1633: goto            1637
        //  1636: athrow         
        //  1637: checkcast       Lnet/minecraft/util/math/BlockPos;
        //  1640: getstatic       dev/nuker/pyro/fc.0:I
        //  1643: ifgt            1652
        //  1646: ldc_w           -1188799899
        //  1649: goto            1655
        //  1652: ldc_w           1454568777
        //  1655: ldc_w           450816594
        //  1658: ixor           
        //  1659: lookupswitch {
        //          -1543851977: 2107
        //          793853770: 1652
        //          default: 1684
        //        }
        //  1684: aload           4
        //  1686: getstatic       dev/nuker/pyro/fc.c:I
        //  1689: ifne            1698
        //  1692: ldc_w           556248141
        //  1695: goto            1701
        //  1698: ldc_w           908770676
        //  1701: ldc_w           937652908
        //  1704: ixor           
        //  1705: lookupswitch {
        //          30003160: 1732
        //          382000865: 1698
        //          default: 2103
        //        }
        //  1732: goto            1736
        //  1735: athrow         
        //  1736: invokevirtual   net/minecraft/util/Tuple.func_76340_b:()Ljava/lang/Object;
        //  1739: goto            1743
        //  1742: athrow         
        //  1743: checkcast       Lnet/minecraft/util/EnumFacing;
        //  1746: aload           5
        //  1748: getstatic       net/minecraft/util/EnumHand.MAIN_HAND:Lnet/minecraft/util/EnumHand;
        //  1751: goto            1755
        //  1754: athrow         
        //  1755: invokevirtual   net/minecraft/client/multiplayer/PlayerControllerMP.func_187099_a:(Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult;
        //  1758: goto            1762
        //  1761: athrow         
        //  1762: pop            
        //  1763: aload_0        
        //  1764: getstatic       dev/nuker/pyro/fc.0:I
        //  1767: ifgt            1776
        //  1770: ldc_w           1874601050
        //  1773: goto            1779
        //  1776: ldc_w           2126728536
        //  1779: ldc_w           1947551751
        //  1782: ixor           
        //  1783: lookupswitch {
        //          181798239: 1808
        //          464088157: 1776
        //          default: 2099
        //        }
        //  1808: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //  1811: getstatic       dev/nuker/pyro/fc.0:I
        //  1814: ifgt            1823
        //  1817: ldc_w           -182016076
        //  1820: goto            1826
        //  1823: ldc_w           2090000161
        //  1826: ldc_w           1192634594
        //  1829: ixor           
        //  1830: lookupswitch {
        //          -1305440426: 2127
        //          -1176330471: 1823
        //          default: 1856
        //        }
        //  1856: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1859: getstatic       net/minecraft/util/EnumHand.MAIN_HAND:Lnet/minecraft/util/EnumHand;
        //  1862: goto            1866
        //  1865: athrow         
        //  1866: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_184609_a:(Lnet/minecraft/util/EnumHand;)V
        //  1869: goto            1873
        //  1872: athrow         
        //  1873: iload           7
        //  1875: ifeq            1884
        //  1878: ldc_w           -1286042110
        //  1881: goto            1887
        //  1884: ldc_w           -1286042109
        //  1887: ldc_w           -1295948084
        //  1890: ixor           
        //  1891: tableswitch {
        //          53727644: 1912
        //          53727645: 2057
        //          default: 1878
        //        }
        //  1912: aload_0        
        //  1913: getstatic       dev/nuker/pyro/fc.1:I
        //  1916: ifne            1925
        //  1919: ldc_w           -252924942
        //  1922: goto            1928
        //  1925: ldc_w           260701499
        //  1928: ldc_w           1289845542
        //  1931: ixor           
        //  1932: lookupswitch {
        //          -2001288804: 1925
        //          -1139945260: 2109
        //          default: 1960
        //        }
        //  1960: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //  1963: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1966: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71174_a:Lnet/minecraft/client/network/NetHandlerPlayClient;
        //  1969: new             Lnet/minecraft/network/play/client/CPacketEntityAction;
        //  1972: dup            
        //  1973: aload_0        
        //  1974: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //  1977: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1980: checkcast       Lnet/minecraft/entity/Entity;
        //  1983: getstatic       net/minecraft/network/play/client/CPacketEntityAction$Action.STOP_SNEAKING:Lnet/minecraft/network/play/client/CPacketEntityAction$Action;
        //  1986: getstatic       dev/nuker/pyro/fc.1:I
        //  1989: ifne            1998
        //  1992: ldc_w           -951844585
        //  1995: goto            2001
        //  1998: ldc_w           1100407137
        //  2001: ldc_w           667712976
        //  2004: ixor           
        //  2005: lookupswitch {
        //          -1706378043: 1998
        //          -527926073: 2089
        //          default: 2032
        //        }
        //  2032: goto            2036
        //  2035: athrow         
        //  2036: invokespecial   net/minecraft/network/play/client/CPacketEntityAction.<init>:(Lnet/minecraft/entity/Entity;Lnet/minecraft/network/play/client/CPacketEntityAction$Action;)V
        //  2039: goto            2043
        //  2042: athrow         
        //  2043: checkcast       Lnet/minecraft/network/Packet;
        //  2046: goto            2050
        //  2049: athrow         
        //  2050: invokevirtual   net/minecraft/client/network/NetHandlerPlayClient.func_147297_a:(Lnet/minecraft/network/Packet;)V
        //  2053: goto            2057
        //  2056: athrow         
        //  2057: aload_2        
        //  2058: getstatic       dev/nuker/pyro/fdS.2:Ldev/nuker/pyro/fdS;
        //  2061: if_acmpne       2079
        //  2064: aload_0        
        //  2065: aload           6
        //  2067: iconst_0       
        //  2068: goto            2072
        //  2071: athrow         
        //  2072: invokevirtual   dev/nuker/pyro/fdU.c:(Lnet/minecraft/util/math/Vec2f;Z)V
        //  2075: goto            2079
        //  2078: athrow         
        //  2079: iconst_1       
        //  2080: ireturn        
        //  2081: iconst_0       
        //  2082: ireturn        
        //  2083: aconst_null    
        //  2084: athrow         
        //  2085: aconst_null    
        //  2086: athrow         
        //  2087: aconst_null    
        //  2088: athrow         
        //  2089: aconst_null    
        //  2090: athrow         
        //  2091: aconst_null    
        //  2092: athrow         
        //  2093: aconst_null    
        //  2094: athrow         
        //  2095: aconst_null    
        //  2096: athrow         
        //  2097: aconst_null    
        //  2098: athrow         
        //  2099: aconst_null    
        //  2100: athrow         
        //  2101: aconst_null    
        //  2102: athrow         
        //  2103: aconst_null    
        //  2104: athrow         
        //  2105: aconst_null    
        //  2106: athrow         
        //  2107: aconst_null    
        //  2108: athrow         
        //  2109: aconst_null    
        //  2110: athrow         
        //  2111: aconst_null    
        //  2112: athrow         
        //  2113: aconst_null    
        //  2114: athrow         
        //  2115: aconst_null    
        //  2116: athrow         
        //  2117: aconst_null    
        //  2118: athrow         
        //  2119: aconst_null    
        //  2120: athrow         
        //  2121: aconst_null    
        //  2122: athrow         
        //  2123: aconst_null    
        //  2124: athrow         
        //  2125: aconst_null    
        //  2126: athrow         
        //  2127: aconst_null    
        //  2128: athrow         
        //  2129: aconst_null    
        //  2130: athrow         
        //  2131: aconst_null    
        //  2132: athrow         
        //  2133: aconst_null    
        //  2134: athrow         
        //  2135: aconst_null    
        //  2136: athrow         
        //  2137: aconst_null    
        //  2138: athrow         
        //  2139: aconst_null    
        //  2140: athrow         
        //  2141: pop            
        //  2142: goto            24
        //  2145: pop            
        //  2146: aconst_null    
        //  2147: goto            2141
        //  2150: dup            
        //  2151: ifnull          2141
        //  2154: checkcast       Ljava/lang/Throwable;
        //  2157: athrow         
        //  2158: dup            
        //  2159: ifnull          2145
        //  2162: checkcast       Ljava/lang/Throwable;
        //  2165: athrow         
        //  2166: aconst_null    
        //  2167: athrow         
        //    StackMapTable: 01 03 43 07 00 1B 04 FF 00 0B 00 00 00 01 07 00 1B FF 00 03 00 04 07 00 03 07 01 16 07 02 BA 01 00 00 50 07 00 03 FF 00 02 00 04 07 00 03 07 01 16 07 02 BA 01 00 02 07 00 03 01 5F 07 00 03 43 07 01 1B FF 00 00 00 04 07 00 03 07 01 16 07 02 BA 01 00 02 07 00 03 07 01 16 45 07 00 1B 40 07 01 6D FC 00 06 07 01 6D 05 42 01 1B 45 07 00 1B FF 00 00 00 05 07 00 03 07 01 16 07 02 BA 01 07 01 6D 00 02 07 00 03 07 01 6D 45 07 00 1B FF 00 00 00 05 07 00 03 07 01 16 07 02 BA 01 07 01 6D 00 02 07 00 03 07 00 05 FF 00 12 00 05 07 00 03 07 01 16 07 02 BA 01 07 01 6D 00 03 07 00 03 07 01 16 07 00 26 FF 00 02 00 05 07 00 03 07 01 16 07 02 BA 01 07 01 6D 00 04 07 00 03 07 01 16 07 00 26 01 FF 00 1F 00 05 07 00 03 07 01 16 07 02 BA 01 07 01 6D 00 03 07 00 03 07 01 16 07 00 26 FF 00 13 00 05 07 00 03 07 01 16 07 02 BA 01 07 01 6D 00 03 07 00 03 07 01 16 07 01 35 FF 00 02 00 05 07 00 03 07 01 16 07 02 BA 01 07 01 6D 00 04 07 00 03 07 01 16 07 01 35 01 FF 00 1C 00 05 07 00 03 07 01 16 07 02 BA 01 07 01 6D 00 03 07 00 03 07 01 16 07 01 35 FF 00 0D 00 05 07 00 03 07 01 16 07 02 BA 01 07 01 6D 00 04 07 00 03 07 01 16 07 01 35 07 01 6D FF 00 02 00 05 07 00 03 07 01 16 07 02 BA 01 07 01 6D 00 05 07 00 03 07 01 16 07 01 35 07 01 6D 01 FF 00 1E 00 05 07 00 03 07 01 16 07 02 BA 01 07 01 6D 00 04 07 00 03 07 01 16 07 01 35 07 01 6D FF 00 02 00 00 00 01 07 00 1B FF 00 00 00 05 07 00 03 07 01 16 07 02 BA 01 07 01 6D 00 04 07 00 03 07 01 16 07 01 35 07 01 6D 45 07 00 1B FF 00 00 00 05 07 00 03 07 01 16 07 02 BA 01 07 01 6D 00 04 07 00 03 07 01 16 07 01 35 07 00 05 47 07 00 1B FF 00 00 00 05 07 00 03 07 01 16 07 02 BA 01 07 01 6D 00 04 07 00 03 07 01 16 07 01 35 07 01 1D 45 07 00 1B 40 07 00 1D FF 00 0E 00 06 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 00 01 07 00 03 FF 00 02 00 06 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 00 02 07 00 03 01 5E 07 00 03 42 07 00 1B 40 07 00 03 45 07 00 1B 40 07 00 9F FC 00 0D 07 00 9F 42 01 1F 53 07 00 03 FF 00 02 00 07 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 00 02 07 00 03 01 5C 07 00 03 FF 00 0E 00 07 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 00 03 07 00 03 07 00 1D 07 02 BA FF 00 02 00 07 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 00 04 07 00 03 07 00 1D 07 02 BA 01 FF 00 1D 00 07 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 00 03 07 00 03 07 00 1D 07 02 BA FF 00 09 00 07 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 00 02 07 00 03 07 00 1D FF 00 00 00 07 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 00 03 07 00 03 07 00 1D 01 42 07 00 1B FF 00 00 00 07 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 00 03 07 00 03 07 00 1D 01 45 07 00 1B 00 4C 01 FF 00 02 00 07 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 00 02 01 01 5D 01 FF 00 11 00 08 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 00 01 07 00 26 FF 00 02 00 08 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 00 02 07 00 26 01 5E 07 00 26 4E 07 01 11 FF 00 02 00 08 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 00 02 07 01 11 01 5D 07 01 11 FF 00 0D 00 08 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 00 02 07 01 11 07 01 6D FF 00 02 00 08 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 00 03 07 01 11 07 01 6D 01 FF 00 1E 00 08 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 00 02 07 01 11 07 01 6D 42 07 00 1B FF 00 00 00 08 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 00 02 07 01 11 07 01 6D 45 07 00 1B FF 00 00 00 08 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 00 02 07 01 11 07 00 05 45 07 00 1B FF 00 00 00 08 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 00 02 07 01 11 07 01 16 45 07 00 1B 40 07 01 18 44 07 00 1B 40 07 01 18 47 07 00 1B 40 07 01 7F FF 00 07 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 01 07 00 1B FF 00 00 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 07 00 03 07 01 7F 45 07 00 1B 40 01 05 04 05 42 01 1B 4F 07 00 26 FF 00 02 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 07 00 26 01 5C 07 00 26 FF 00 16 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 04 07 02 5B 08 03 8E 08 03 8E 07 00 03 FF 00 02 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 05 07 02 5B 08 03 8E 08 03 8E 07 00 03 01 FF 00 1D 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 04 07 02 5B 08 03 8E 08 03 8E 07 00 03 FF 00 0E 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 04 07 02 5B 08 03 8E 08 03 8E 07 00 26 FF 00 02 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 05 07 02 5B 08 03 8E 08 03 8E 07 00 26 01 FF 00 1D 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 04 07 02 5B 08 03 8E 08 03 8E 07 00 26 4B 07 00 1B FF 00 00 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 05 07 02 5B 08 03 8E 08 03 8E 07 02 E5 07 02 E7 45 07 00 1B FF 00 00 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 07 02 5B 07 02 DD FF 00 05 00 00 00 01 07 00 1B FF 00 00 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 07 02 5B 07 02 59 45 07 00 1B 00 0B 42 01 1E 0F 42 01 1C FF 00 12 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 03 07 01 6D FF 00 02 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 03 03 07 01 6D 01 FF 00 1D 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 03 07 01 6D 42 07 00 1B FF 00 00 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 03 07 01 6D 45 07 00 1B FF 00 00 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 03 07 00 05 FF 00 10 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 03 07 01 16 FF 00 02 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 03 03 07 01 16 01 FF 00 1C 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 03 07 01 16 42 07 00 1B FF 00 00 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 03 07 01 16 45 07 00 1B FF 00 00 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 03 01 FF 00 0E 00 0A 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 02 00 01 07 00 0F FF 00 00 00 0A 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 02 00 02 03 07 01 6D 45 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 02 00 02 03 07 00 05 47 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 02 00 02 03 07 01 16 45 07 00 1B FF 00 00 00 0A 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 02 00 02 03 01 FF 00 0E 00 0B 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 02 02 00 01 07 00 1B FF 00 00 00 0B 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 02 02 00 02 03 07 01 6D 45 07 00 1B FF 00 00 00 0B 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 02 02 00 02 03 07 00 05 47 07 00 55 FF 00 00 00 0B 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 02 02 00 02 03 07 01 16 45 07 00 1B FF 00 00 00 0B 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 02 02 00 02 03 01 FF 00 17 00 00 00 01 07 00 1B FF 00 00 00 0C 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 02 02 02 00 04 07 02 5B 08 05 48 08 05 48 07 01 6D 45 07 00 1B FF 00 00 00 0C 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 02 02 02 00 04 07 02 5B 08 05 48 08 05 48 07 00 05 FF 00 0E 00 0C 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 02 02 02 00 04 07 02 5B 08 05 48 08 05 48 07 01 16 FF 00 02 00 0C 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 02 02 02 00 05 07 02 5B 08 05 48 08 05 48 07 01 16 01 FF 00 1C 00 0C 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 02 02 02 00 04 07 02 5B 08 05 48 08 05 48 07 01 16 44 07 00 13 FF 00 00 00 0C 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 02 02 02 00 05 07 02 5B 08 05 48 08 05 48 07 01 16 07 01 6D 45 07 00 1B FF 00 00 00 0C 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 02 02 02 00 05 07 02 5B 08 05 48 08 05 48 07 01 16 07 00 05 4E 07 01 1B FF 00 00 00 0C 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 02 02 02 00 09 07 02 5B 08 05 48 08 05 48 07 01 16 07 01 1D 07 03 0A 02 02 02 45 07 00 1B FF 00 00 00 0C 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 02 02 02 00 02 07 02 5B 07 03 05 45 07 00 1B FF 00 00 00 0C 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 02 02 02 00 02 07 02 5B 07 02 59 45 07 00 1B 00 F8 00 02 FF 00 19 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 07 03 26 07 00 2C FF 00 02 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 03 07 03 26 07 00 2C 01 FF 00 1D 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 07 03 26 07 00 2C FF 00 0F 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 03 07 03 26 07 00 2C 07 00 26 FF 00 02 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 04 07 03 26 07 00 2C 07 00 26 01 FF 00 1C 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 03 07 03 26 07 00 2C 07 00 26 FF 00 0E 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 03 07 03 26 07 00 2C 07 01 11 FF 00 02 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 04 07 03 26 07 00 2C 07 01 11 01 FF 00 1D 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 03 07 03 26 07 00 2C 07 01 11 FF 00 04 00 00 00 01 07 00 1B FF 00 00 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 04 07 03 26 07 00 2C 07 01 11 07 01 6D 45 07 00 1B FF 00 00 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 04 07 03 26 07 00 2C 07 01 11 07 00 05 FF 00 0E 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 04 07 03 26 07 00 2C 07 01 11 07 01 16 FF 00 02 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 05 07 03 26 07 00 2C 07 01 11 07 01 16 01 FF 00 1C 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 04 07 03 26 07 00 2C 07 01 11 07 01 16 FF 00 0D 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 05 07 03 26 07 00 2C 07 01 11 07 01 16 07 01 6D FF 00 02 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 06 07 03 26 07 00 2C 07 01 11 07 01 16 07 01 6D 01 FF 00 1E 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 05 07 03 26 07 00 2C 07 01 11 07 01 16 07 01 6D 42 07 00 1B FF 00 00 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 05 07 03 26 07 00 2C 07 01 11 07 01 16 07 01 6D 45 07 00 1B FF 00 00 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 05 07 03 26 07 00 2C 07 01 11 07 01 16 07 00 05 FF 00 0A 00 00 00 01 07 00 1B FF 00 00 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 07 07 03 26 07 00 2C 07 01 11 07 01 16 07 01 1D 07 00 1D 07 03 0A 45 07 00 1B 40 07 03 44 00 4C 07 00 03 FF 00 02 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 07 00 03 01 5C 07 00 03 4E 07 00 26 FF 00 02 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 07 00 26 01 5D 07 00 26 48 07 00 1B FF 00 00 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 07 00 2C 07 03 0A 45 07 00 1B 00 04 05 42 01 18 4C 07 00 03 FF 00 02 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 07 00 03 01 5F 07 00 03 FF 00 25 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 05 07 02 5B 08 07 B1 08 07 B1 07 02 E5 07 02 E7 FF 00 02 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 06 07 02 5B 08 07 B1 08 07 B1 07 02 E5 07 02 E7 01 FF 00 1E 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 05 07 02 5B 08 07 B1 08 07 B1 07 02 E5 07 02 E7 42 07 00 1B FF 00 00 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 05 07 02 5B 08 07 B1 08 07 B1 07 02 E5 07 02 E7 45 07 00 1B FF 00 00 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 07 02 5B 07 02 DD 45 07 00 55 FF 00 00 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 07 02 5B 07 02 59 45 07 00 1B 00 4D 07 00 1B FF 00 00 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 03 07 00 03 07 00 9F 01 45 07 00 1B 00 FF 00 01 00 05 07 00 03 07 01 16 07 02 BA 01 07 01 6D 00 00 FF 00 01 00 08 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 00 01 07 01 11 FF 00 01 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 01 07 00 26 FF 00 01 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 03 07 03 26 07 00 2C 07 01 11 FF 00 01 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 05 07 02 5B 08 07 B1 08 07 B1 07 02 E5 07 02 E7 FF 00 01 00 07 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 00 01 07 00 03 01 FF 00 01 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 03 07 01 16 FF 00 01 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 07 03 26 07 00 2C 41 07 00 03 FF 00 01 00 05 07 00 03 07 01 16 07 02 BA 01 07 01 6D 00 03 07 00 03 07 01 16 07 00 26 FF 00 01 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 05 07 03 26 07 00 2C 07 01 11 07 01 16 07 01 6D FF 00 01 00 04 07 00 03 07 01 16 07 02 BA 01 00 01 07 00 03 FF 00 01 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 04 07 03 26 07 00 2C 07 01 11 07 01 16 41 07 00 03 FF 00 01 00 08 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 00 01 07 00 26 FC 00 01 07 01 7F FF 00 01 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 03 07 03 26 07 00 2C 07 00 26 FF 00 01 00 0C 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 02 02 02 00 04 07 02 5B 08 05 48 08 05 48 07 01 16 FF 00 01 00 05 07 00 03 07 01 16 07 02 BA 01 07 01 6D 00 04 07 00 03 07 01 16 07 01 35 07 01 6D FF 00 01 00 07 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 00 03 07 00 03 07 00 1D 07 02 BA FF 00 01 00 08 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 00 02 07 01 11 07 01 6D FF 00 01 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 04 07 02 5B 08 03 8E 08 03 8E 07 00 26 41 07 00 26 FF 00 01 00 06 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 00 01 07 00 03 FF 00 01 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 02 03 07 01 6D FF 00 01 00 05 07 00 03 07 01 16 07 02 BA 01 07 01 6D 00 03 07 00 03 07 01 16 07 01 35 FF 00 01 00 09 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 01 07 01 7F 00 04 07 02 5B 08 03 8E 08 03 8E 07 00 03 01 FF 00 01 00 07 07 00 03 07 01 16 07 02 BA 01 07 01 6D 07 00 1D 07 00 9F 00 01 01 FF 00 01 00 04 07 00 03 07 01 16 07 02 BA 01 00 01 07 00 1B 43 05 44 07 00 1B 47 05 47 07 00 1B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     2150   2158   Ljava/lang/NullPointerException;
        //  2150   2158   2150   2158   Any
        //  2166   2168   3      8      Ljava/lang/ArithmeticException;
        //  80     87     87     88     Any
        //  81     87     87     88     Any
        //  80     87     3      8      Any
        //  80     87     3      8      Any
        //  80     87     80     81     Ljava/util/ConcurrentModificationException;
        //  138    145    145    146    Any
        //  139    145    138    139    Any
        //  139    145    3      8      Ljava/util/NoSuchElementException;
        //  139    145    145    146    Ljava/util/NoSuchElementException;
        //  139    145    138    139    Any
        //  304    310    310    311    Any
        //  304    310    3      8      Any
        //  304    310    310    311    Any
        //  304    310    3      8      Any
        //  304    310    3      8      Any
        //  319    326    326    327    Any
        //  320    326    319    320    Ljava/lang/EnumConstantNotPresentException;
        //  320    326    326    327    Ljava/lang/RuntimeException;
        //  320    326    326    327    Ljava/util/ConcurrentModificationException;
        //  319    326    319    320    Any
        //  379    386    386    387    Any
        //  379    386    379    380    Ljava/lang/NullPointerException;
        //  379    386    386    387    Any
        //  380    386    379    380    Any
        //  380    386    3      8      Any
        //  550    557    557    558    Any
        //  550    557    550    551    Any
        //  551    557    557    558    Ljava/lang/NumberFormatException;
        //  551    557    550    551    Ljava/lang/ArithmeticException;
        //  550    557    557    558    Ljava/lang/ArithmeticException;
        //  755    762    762    763    Any
        //  755    762    755    756    Any
        //  755    762    755    756    Any
        //  755    762    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  756    762    762    763    Any
        //  769    776    776    777    Any
        //  770    776    3      8      Any
        //  769    776    769    770    Any
        //  770    776    3      8      Any
        //  769    776    3      8      Ljava/lang/RuntimeException;
        //  782    791    791    792    Any
        //  782    791    791    792    Any
        //  782    791    791    792    Any
        //  783    791    782    783    Ljava/util/NoSuchElementException;
        //  782    791    782    783    Any
        //  800    807    807    808    Any
        //  801    807    800    801    Any
        //  801    807    800    801    Any
        //  800    807    800    801    Ljava/lang/IllegalStateException;
        //  800    807    800    801    Ljava/lang/NegativeArraySizeException;
        //  1020   1027   1027   1028   Any
        //  1021   1027   1020   1021   Ljava/lang/IndexOutOfBoundsException;
        //  1021   1027   1020   1021   Ljava/lang/UnsupportedOperationException;
        //  1021   1027   1020   1021   Any
        //  1020   1027   1020   1021   Ljava/lang/ClassCastException;
        //  1035   1041   1041   1042   Any
        //  1035   1041   1041   1042   Ljava/lang/NullPointerException;
        //  1035   1041   3      8      Ljava/util/ConcurrentModificationException;
        //  1035   1041   3      8      Any
        //  1035   1041   1041   1042   Ljava/lang/NullPointerException;
        //  1191   1198   1198   1199   Any
        //  1192   1198   1198   1199   Any
        //  1191   1198   1198   1199   Any
        //  1192   1198   1191   1192   Any
        //  1191   1198   1191   1192   Any
        //  1251   1258   1258   1259   Any
        //  1251   1258   3      8      Ljava/lang/AssertionError;
        //  1251   1258   1251   1252   Any
        //  1251   1258   1251   1252   Any
        //  1252   1258   3      8      Any
        //  1274   1281   1281   1282   Any
        //  1275   1281   1281   1282   Ljava/lang/RuntimeException;
        //  1274   1281   1274   1275   Ljava/lang/IndexOutOfBoundsException;
        //  1274   1281   1281   1282   Any
        //  1275   1281   1281   1282   Ljava/lang/NegativeArraySizeException;
        //  1290   1297   1297   1298   Any
        //  1290   1297   3      8      Any
        //  1291   1297   1297   1298   Any
        //  1290   1297   1297   1298   Ljava/util/ConcurrentModificationException;
        //  1290   1297   1290   1291   Any
        //  1313   1320   1320   1321   Any
        //  1313   1320   1320   1321   Any
        //  1313   1320   3      8      Any
        //  1314   1320   1313   1314   Any
        //  1314   1320   1320   1321   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1329   1336   1336   1337   Any
        //  1330   1336   1336   1337   Any
        //  1329   1336   1336   1337   Ljava/lang/RuntimeException;
        //  1330   1336   1329   1330   Ljava/lang/RuntimeException;
        //  1330   1336   1329   1330   Ljava/lang/EnumConstantNotPresentException;
        //  1362   1368   1368   1369   Any
        //  1362   1368   3      8      Any
        //  1362   1368   3      8      Any
        //  1362   1368   1368   1369   Ljava/lang/IllegalArgumentException;
        //  1362   1368   1368   1369   Any
        //  1421   1428   1428   1429   Any
        //  1421   1428   1421   1422   Ljava/lang/IllegalStateException;
        //  1421   1428   3      8      Any
        //  1422   1428   1428   1429   Ljava/lang/UnsupportedOperationException;
        //  1421   1428   3      8      Any
        //  1444   1451   1451   1452   Any
        //  1444   1451   3      8      Any
        //  1445   1451   3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1445   1451   1444   1445   Ljava/util/ConcurrentModificationException;
        //  1445   1451   1451   1452   Any
        //  1458   1465   1465   1466   Any
        //  1458   1465   1458   1459   Ljava/lang/EnumConstantNotPresentException;
        //  1458   1465   1465   1466   Ljava/lang/IllegalArgumentException;
        //  1458   1465   1458   1459   Any
        //  1458   1465   3      8      Any
        //  1630   1636   1636   1637   Any
        //  1630   1636   3      8      Any
        //  1630   1636   1636   1637   Any
        //  1630   1636   1636   1637   Ljava/lang/IllegalArgumentException;
        //  1630   1636   3      8      Any
        //  1735   1742   1742   1743   Any
        //  1736   1742   3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1735   1742   1742   1743   Any
        //  1735   1742   1735   1736   Any
        //  1735   1742   1742   1743   Ljava/lang/IllegalStateException;
        //  1755   1761   1761   1762   Any
        //  1755   1761   3      8      Ljava/lang/IllegalStateException;
        //  1755   1761   1761   1762   Any
        //  1755   1761   3      8      Any
        //  1755   1761   1761   1762   Any
        //  1865   1872   1872   1873   Any
        //  1866   1872   3      8      Any
        //  1866   1872   3      8      Ljava/lang/EnumConstantNotPresentException;
        //  1866   1872   1865   1866   Any
        //  1865   1872   3      8      Ljava/lang/ArithmeticException;
        //  2035   2042   2042   2043   Any
        //  2036   2042   2035   2036   Any
        //  2036   2042   2035   2036   Any
        //  2035   2042   2042   2043   Ljava/lang/RuntimeException;
        //  2036   2042   2042   2043   Ljava/lang/NegativeArraySizeException;
        //  2049   2056   2056   2057   Any
        //  2049   2056   2049   2050   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  2049   2056   2056   2057   Ljava/lang/ClassCastException;
        //  2050   2056   2056   2057   Any
        //  2050   2056   2049   2050   Ljava/lang/IllegalStateException;
        //  2071   2078   2078   2079   Any
        //  2072   2078   3      8      Any
        //  2072   2078   3      8      Any
        //  2072   2078   2071   2072   Any
        //  2072   2078   2071   2072   Ljava/lang/ArithmeticException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:595)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @NotNull
    public Vec2f c(@NotNull final Vec3d p0, @Nullable final EnumFacing p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          840
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            832
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            824
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: getstatic       dev/nuker/pyro/fc.c:I
        //    29: ifne            38
        //    32: ldc_w           1335588791
        //    35: goto            41
        //    38: ldc_w           1102795339
        //    41: ldc_w           1845114783
        //    44: ixor           
        //    45: lookupswitch {
        //          576798760: 795
        //          1920755370: 38
        //          default: 72
        //        }
        //    72: aload_0        
        //    73: goto            77
        //    76: athrow         
        //    77: invokevirtual   dev/nuker/pyro/fdU.c:()Lnet/minecraft/util/math/Vec3d;
        //    80: goto            84
        //    83: athrow         
        //    84: astore_3       
        //    85: aload_1        
        //    86: getfield        net/minecraft/util/math/Vec3d.field_72450_a:D
        //    89: aload_3        
        //    90: getfield        net/minecraft/util/math/Vec3d.field_72450_a:D
        //    93: dsub           
        //    94: getstatic       dev/nuker/pyro/fc.0:I
        //    97: ifgt            106
        //   100: ldc_w           1076845205
        //   103: goto            109
        //   106: ldc_w           988122811
        //   109: ldc_w           -1539925105
        //   112: ixor           
        //   113: lookupswitch {
        //          -1630333644: 140
        //          -468074214: 106
        //          default: 813
        //        }
        //   140: dstore          4
        //   142: aload_1        
        //   143: getfield        net/minecraft/util/math/Vec3d.field_72448_b:D
        //   146: aload_3        
        //   147: getstatic       dev/nuker/pyro/fc.c:I
        //   150: ifne            159
        //   153: ldc_w           -329897080
        //   156: goto            162
        //   159: ldc_w           1642182322
        //   162: ldc_w           -2021460346
        //   165: ixor           
        //   166: lookupswitch {
        //          -429703116: 192
        //          1809112334: 159
        //          default: 791
        //        }
        //   192: getfield        net/minecraft/util/math/Vec3d.field_72448_b:D
        //   195: dsub           
        //   196: dstore          6
        //   198: getstatic       dev/nuker/pyro/fc.1:I
        //   201: ifne            210
        //   204: ldc_w           2030490926
        //   207: goto            213
        //   210: ldc_w           -1886099454
        //   213: ldc_w           -134415197
        //   216: ixor           
        //   217: lookupswitch {
        //          -1896207987: 210
        //          2020119713: 244
        //          default: 801
        //        }
        //   244: aload_1        
        //   245: getstatic       dev/nuker/pyro/fc.1:I
        //   248: ifne            257
        //   251: ldc_w           -84391579
        //   254: goto            260
        //   257: ldc_w           1610463943
        //   260: ldc_w           -1117093493
        //   263: ixor           
        //   264: lookupswitch {
        //          -493405364: 292
        //          1200802030: 257
        //          default: 803
        //        }
        //   292: getfield        net/minecraft/util/math/Vec3d.field_72449_c:D
        //   295: aload_3        
        //   296: getfield        net/minecraft/util/math/Vec3d.field_72449_c:D
        //   299: dsub           
        //   300: dstore          8
        //   302: dload           4
        //   304: dload           4
        //   306: dmul           
        //   307: dload           8
        //   309: dload           8
        //   311: dmul           
        //   312: dadd           
        //   313: goto            317
        //   316: athrow         
        //   317: invokestatic    java/lang/Math.sqrt:(D)D
        //   320: goto            324
        //   323: athrow         
        //   324: getstatic       dev/nuker/pyro/fc.1:I
        //   327: ifne            336
        //   330: ldc_w           296181240
        //   333: goto            339
        //   336: ldc_w           -803950124
        //   339: ldc_w           734159928
        //   342: ixor           
        //   343: lookupswitch {
        //          -1674499115: 336
        //          979712448: 793
        //          default: 368
        //        }
        //   368: dstore          10
        //   370: dload           8
        //   372: dload           4
        //   374: goto            378
        //   377: athrow         
        //   378: invokestatic    java/lang/Math.atan2:(DD)D
        //   381: goto            385
        //   384: athrow         
        //   385: getstatic       dev/nuker/pyro/fc.1:I
        //   388: ifne            397
        //   391: ldc_w           -1104573067
        //   394: goto            400
        //   397: ldc_w           -796132238
        //   400: ldc_w           -1090854404
        //   403: ixor           
        //   404: lookupswitch {
        //          13855881: 397
        //          1852906894: 432
        //          default: 811
        //        }
        //   432: goto            436
        //   435: athrow         
        //   436: invokestatic    java/lang/Math.toDegrees:(D)D
        //   439: goto            443
        //   442: athrow         
        //   443: d2f            
        //   444: ldc             90.0
        //   446: fsub           
        //   447: getstatic       dev/nuker/pyro/fc.1:I
        //   450: ifne            459
        //   453: ldc_w           -185157235
        //   456: goto            462
        //   459: ldc_w           444409398
        //   462: ldc_w           -1775550639
        //   465: ixor           
        //   466: lookupswitch {
        //          -1940514457: 492
        //          1658685148: 459
        //          default: 809
        //        }
        //   492: fstore          12
        //   494: getstatic       dev/nuker/pyro/fc.0:I
        //   497: ifgt            506
        //   500: ldc_w           -1564156738
        //   503: goto            509
        //   506: ldc_w           1010563958
        //   509: ldc_w           1007020719
        //   512: ixor           
        //   513: lookupswitch {
        //          -1631504879: 506
        //          4067801: 540
        //          default: 797
        //        }
        //   540: dload           6
        //   542: dload           10
        //   544: goto            548
        //   547: athrow         
        //   548: invokestatic    java/lang/Math.atan2:(DD)D
        //   551: goto            555
        //   554: athrow         
        //   555: goto            559
        //   558: athrow         
        //   559: invokestatic    java/lang/Math.toDegrees:(D)D
        //   562: goto            566
        //   565: athrow         
        //   566: dneg           
        //   567: d2f            
        //   568: fstore          13
        //   570: new             Lnet/minecraft/util/math/Vec2f;
        //   573: dup            
        //   574: aload_0        
        //   575: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   578: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   581: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70177_z:F
        //   584: fload           12
        //   586: aload_0        
        //   587: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   590: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   593: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70177_z:F
        //   596: fsub           
        //   597: getstatic       dev/nuker/pyro/fc.0:I
        //   600: ifgt            609
        //   603: ldc_w           642845649
        //   606: goto            612
        //   609: ldc_w           -533541986
        //   612: ldc_w           1192254599
        //   615: ixor           
        //   616: lookupswitch {
        //          -1490905319: 644
        //          1631672150: 609
        //          default: 805
        //        }
        //   644: goto            648
        //   647: athrow         
        //   648: invokestatic    net/minecraft/util/math/MathHelper.func_76142_g:(F)F
        //   651: goto            655
        //   654: athrow         
        //   655: fadd           
        //   656: getstatic       dev/nuker/pyro/fc.1:I
        //   659: ifne            668
        //   662: ldc_w           -1353778431
        //   665: goto            671
        //   668: ldc_w           -1078654195
        //   671: ldc_w           800454640
        //   674: ixor           
        //   675: lookupswitch {
        //          -2131030799: 799
        //          -1272186996: 668
        //          default: 700
        //        }
        //   700: aload_0        
        //   701: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   704: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   707: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70125_A:F
        //   710: fload           13
        //   712: getstatic       dev/nuker/pyro/fc.0:I
        //   715: ifgt            724
        //   718: ldc_w           -550378100
        //   721: goto            727
        //   724: ldc_w           471495353
        //   727: ldc_w           -471368110
        //   730: ixor           
        //   731: lookupswitch {
        //          358583151: 724
        //          1020697566: 807
        //          default: 756
        //        }
        //   756: aload_0        
        //   757: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   760: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   763: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70125_A:F
        //   766: fsub           
        //   767: goto            771
        //   770: athrow         
        //   771: invokestatic    net/minecraft/util/math/MathHelper.func_76142_g:(F)F
        //   774: goto            778
        //   777: athrow         
        //   778: fadd           
        //   779: goto            783
        //   782: athrow         
        //   783: invokespecial   net/minecraft/util/math/Vec2f.<init>:(FF)V
        //   786: goto            790
        //   789: athrow         
        //   790: areturn        
        //   791: aconst_null    
        //   792: athrow         
        //   793: aconst_null    
        //   794: athrow         
        //   795: aconst_null    
        //   796: athrow         
        //   797: aconst_null    
        //   798: athrow         
        //   799: aconst_null    
        //   800: athrow         
        //   801: aconst_null    
        //   802: athrow         
        //   803: aconst_null    
        //   804: athrow         
        //   805: aconst_null    
        //   806: athrow         
        //   807: aconst_null    
        //   808: athrow         
        //   809: aconst_null    
        //   810: athrow         
        //   811: aconst_null    
        //   812: athrow         
        //   813: aconst_null    
        //   814: athrow         
        //   815: pop            
        //   816: goto            24
        //   819: pop            
        //   820: aconst_null    
        //   821: goto            815
        //   824: dup            
        //   825: ifnull          815
        //   828: checkcast       Ljava/lang/Throwable;
        //   831: athrow         
        //   832: dup            
        //   833: ifnull          819
        //   836: checkcast       Ljava/lang/Throwable;
        //   839: athrow         
        //   840: aconst_null    
        //   841: athrow         
        //    StackMapTable: 00 5D 43 07 00 1B 04 FF 00 0B 00 00 00 01 07 00 1B FE 00 03 07 00 03 07 00 1D 07 01 1D 0D 42 01 1E 43 07 00 60 40 07 00 03 45 07 00 1B 40 07 00 1D FF 00 15 00 04 07 00 03 07 00 1D 07 01 1D 07 00 1D 00 01 03 FF 00 02 00 04 07 00 03 07 00 1D 07 01 1D 07 00 1D 00 02 03 01 5E 03 FF 00 12 00 05 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 00 02 03 07 00 1D FF 00 02 00 05 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 00 03 03 07 00 1D 01 FF 00 1D 00 05 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 00 02 03 07 00 1D FC 00 11 03 42 01 1E 4C 07 00 1D FF 00 02 00 06 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 00 02 07 00 1D 01 5F 07 00 1D FF 00 17 00 07 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 00 01 07 00 1B 40 03 45 07 00 1B 40 03 4B 03 FF 00 02 00 07 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 00 02 03 01 5C 03 FF 00 08 00 00 00 01 07 00 1B FF 00 00 00 08 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 00 02 03 03 45 07 00 1B 40 03 4B 03 FF 00 02 00 08 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 00 02 03 01 5F 03 FF 00 02 00 00 00 01 07 00 1B FF 00 00 00 08 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 00 01 03 45 07 00 1B 40 03 4F 02 FF 00 02 00 08 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 00 02 02 01 5D 02 FC 00 0D 02 42 01 1E 46 07 00 0F FF 00 00 00 09 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 02 00 02 03 03 45 07 00 1B 40 03 42 07 00 1B 40 03 45 07 00 1B 40 03 FF 00 2A 00 0A 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 02 FF 00 02 00 0A 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 02 02 00 05 08 02 3A 08 02 3A 02 02 01 FF 00 1F 00 0A 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 02 FF 00 02 00 00 00 01 07 00 1B FF 00 00 00 0A 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 02 45 07 00 1B FF 00 00 00 0A 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 02 FF 00 0C 00 0A 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 02 02 00 03 08 02 3A 08 02 3A 02 FF 00 02 00 0A 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 01 FF 00 1C 00 0A 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 02 02 00 03 08 02 3A 08 02 3A 02 FF 00 17 00 0A 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 02 02 00 05 08 02 3A 08 02 3A 02 02 02 FF 00 02 00 0A 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 02 02 00 06 08 02 3A 08 02 3A 02 02 02 01 FF 00 1C 00 0A 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 02 02 00 05 08 02 3A 08 02 3A 02 02 02 FF 00 0D 00 00 00 01 07 00 1B FF 00 00 00 0A 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 02 02 00 05 08 02 3A 08 02 3A 02 02 02 45 07 00 1B FF 00 00 00 0A 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 02 02 00 05 08 02 3A 08 02 3A 02 02 02 43 07 00 1B FF 00 00 00 0A 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 02 45 07 00 1B 40 07 00 9F FF 00 00 00 05 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 00 02 03 07 00 1D FF 00 01 00 07 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 00 01 03 FF 00 01 00 03 07 00 03 07 00 1D 07 01 1D 00 00 FF 00 01 00 09 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 02 00 00 FF 00 01 00 0A 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 02 02 00 03 08 02 3A 08 02 3A 02 FF 00 01 00 06 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 00 00 41 07 00 1D FF 00 01 00 0A 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 02 02 00 04 08 02 3A 08 02 3A 02 02 FF 00 01 00 0A 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 02 02 00 05 08 02 3A 08 02 3A 02 02 02 FF 00 01 00 08 07 00 03 07 00 1D 07 01 1D 07 00 1D 03 03 03 03 00 01 02 41 03 FF 00 01 00 04 07 00 03 07 00 1D 07 01 1D 07 00 1D 00 01 03 FF 00 01 00 03 07 00 03 07 00 1D 07 01 1D 00 01 07 00 1B 43 05 44 07 00 1B 47 05 47 07 00 1B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     824    832    Any
        //  824    832    824    832    Ljava/lang/IndexOutOfBoundsException;
        //  840    842    3      8      Ljava/lang/IllegalStateException;
        //  76     83     83     84     Any
        //  76     83     76     77     Ljava/util/NoSuchElementException;
        //  76     83     3      8      Ljava/lang/EnumConstantNotPresentException;
        //  76     83     3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  76     83     3      8      Ljava/lang/IllegalStateException;
        //  316    323    323    324    Any
        //  317    323    316    317    Any
        //  316    323    323    324    Ljava/lang/NumberFormatException;
        //  316    323    323    324    Any
        //  316    323    323    324    Ljava/lang/IllegalArgumentException;
        //  378    384    384    385    Any
        //  378    384    384    385    Ljava/lang/IndexOutOfBoundsException;
        //  378    384    384    385    Any
        //  378    384    384    385    Ljava/lang/EnumConstantNotPresentException;
        //  378    384    384    385    Ljava/lang/NullPointerException;
        //  436    442    442    443    Any
        //  436    442    442    443    Any
        //  436    442    442    443    Ljava/lang/UnsupportedOperationException;
        //  436    442    3      8      Ljava/lang/NumberFormatException;
        //  436    442    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  547    554    554    555    Any
        //  547    554    554    555    Any
        //  547    554    3      8      Any
        //  548    554    547    548    Ljava/lang/IndexOutOfBoundsException;
        //  548    554    3      8      Any
        //  558    565    565    566    Any
        //  559    565    558    559    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  559    565    3      8      Ljava/lang/IllegalArgumentException;
        //  559    565    565    566    Ljava/util/ConcurrentModificationException;
        //  559    565    558    559    Any
        //  648    654    654    655    Any
        //  648    654    654    655    Ljava/lang/AssertionError;
        //  648    654    654    655    Ljava/lang/UnsupportedOperationException;
        //  648    654    654    655    Ljava/lang/NumberFormatException;
        //  648    654    3      8      Any
        //  771    777    777    778    Any
        //  771    777    3      8      Any
        //  771    777    3      8      Any
        //  771    777    3      8      Any
        //  771    777    777    778    Ljava/util/ConcurrentModificationException;
        //  782    789    789    790    Any
        //  783    789    782    783    Any
        //  782    789    3      8      Any
        //  782    789    782    783    Ljava/lang/NumberFormatException;
        //  782    789    789    790    Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visitVariable(StackMappingVisitor.java:470)
        //     at com.strobel.assembler.ir.Instruction.accept(Instruction.java:556)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:403)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void c(@Nullable final BlockPos p0, @Nullable final EnumFacing p1, @Nullable final Vec3d p2, @Nullable final EnumHand p3) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          252
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            244
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            236
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_0        
        //    25: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //    28: getfield        net/minecraft/client/Minecraft.field_71442_b:Lnet/minecraft/client/multiplayer/PlayerControllerMP;
        //    31: aload_0        
        //    32: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //    35: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //    38: aload_0        
        //    39: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //    42: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //    45: getstatic       dev/nuker/pyro/fc.1:I
        //    48: ifne            57
        //    51: ldc_w           1128883318
        //    54: goto            60
        //    57: ldc_w           1678597891
        //    60: ldc_w           -1440039288
        //    63: ixor           
        //    64: lookupswitch {
        //          -548815347: 57
        //          -379331842: 221
        //          default: 92
        //        }
        //    92: aload_1        
        //    93: getstatic       dev/nuker/pyro/fc.1:I
        //    96: ifne            105
        //    99: ldc_w           -206485462
        //   102: goto            108
        //   105: ldc_w           -449519477
        //   108: ldc_w           348582406
        //   111: ixor           
        //   112: lookupswitch {
        //          -411583956: 223
        //          2022314532: 105
        //          default: 140
        //        }
        //   140: aload_2        
        //   141: aload_3        
        //   142: aload           4
        //   144: getstatic       dev/nuker/pyro/fc.0:I
        //   147: ifgt            156
        //   150: ldc_w           77792602
        //   153: goto            159
        //   156: ldc_w           443659741
        //   159: ldc_w           918135598
        //   162: ixor           
        //   163: lookupswitch {
        //          -1738931369: 156
        //          840607348: 225
        //          default: 188
        //        }
        //   188: goto            192
        //   191: athrow         
        //   192: invokevirtual   net/minecraft/client/multiplayer/PlayerControllerMP.func_187099_a:(Lnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/client/multiplayer/WorldClient;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult;
        //   195: goto            199
        //   198: athrow         
        //   199: pop            
        //   200: aload_0        
        //   201: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   204: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   207: aload           4
        //   209: goto            213
        //   212: athrow         
        //   213: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_184609_a:(Lnet/minecraft/util/EnumHand;)V
        //   216: goto            220
        //   219: athrow         
        //   220: return         
        //   221: aconst_null    
        //   222: athrow         
        //   223: aconst_null    
        //   224: athrow         
        //   225: aconst_null    
        //   226: athrow         
        //   227: pop            
        //   228: goto            24
        //   231: pop            
        //   232: aconst_null    
        //   233: goto            227
        //   236: dup            
        //   237: ifnull          227
        //   240: checkcast       Ljava/lang/Throwable;
        //   243: athrow         
        //   244: dup            
        //   245: ifnull          231
        //   248: checkcast       Ljava/lang/Throwable;
        //   251: athrow         
        //   252: aconst_null    
        //   253: athrow         
        //    StackMapTable: 00 1D 43 07 00 1B 04 FF 00 0B 00 00 00 01 07 00 1B FF 00 03 00 05 07 00 03 07 01 16 07 01 1D 07 00 1D 07 03 0A 00 00 FF 00 20 00 05 07 00 03 07 01 16 07 01 1D 07 00 1D 07 03 0A 00 03 07 03 26 07 00 2C 07 01 11 FF 00 02 00 05 07 00 03 07 01 16 07 01 1D 07 00 1D 07 03 0A 00 04 07 03 26 07 00 2C 07 01 11 01 FF 00 1F 00 05 07 00 03 07 01 16 07 01 1D 07 00 1D 07 03 0A 00 03 07 03 26 07 00 2C 07 01 11 FF 00 0C 00 05 07 00 03 07 01 16 07 01 1D 07 00 1D 07 03 0A 00 04 07 03 26 07 00 2C 07 01 11 07 01 16 FF 00 02 00 05 07 00 03 07 01 16 07 01 1D 07 00 1D 07 03 0A 00 05 07 03 26 07 00 2C 07 01 11 07 01 16 01 FF 00 1F 00 05 07 00 03 07 01 16 07 01 1D 07 00 1D 07 03 0A 00 04 07 03 26 07 00 2C 07 01 11 07 01 16 FF 00 0F 00 05 07 00 03 07 01 16 07 01 1D 07 00 1D 07 03 0A 00 07 07 03 26 07 00 2C 07 01 11 07 01 16 07 01 1D 07 00 1D 07 03 0A FF 00 02 00 05 07 00 03 07 01 16 07 01 1D 07 00 1D 07 03 0A 00 08 07 03 26 07 00 2C 07 01 11 07 01 16 07 01 1D 07 00 1D 07 03 0A 01 FF 00 1C 00 05 07 00 03 07 01 16 07 01 1D 07 00 1D 07 03 0A 00 07 07 03 26 07 00 2C 07 01 11 07 01 16 07 01 1D 07 00 1D 07 03 0A 42 07 00 11 FF 00 00 00 05 07 00 03 07 01 16 07 01 1D 07 00 1D 07 03 0A 00 07 07 03 26 07 00 2C 07 01 11 07 01 16 07 01 1D 07 00 1D 07 03 0A 45 07 00 1B 40 07 03 44 4C 07 00 55 FF 00 00 00 05 07 00 03 07 01 16 07 01 1D 07 00 1D 07 03 0A 00 02 07 00 2C 07 03 0A 45 07 00 1B 00 FF 00 00 00 05 07 00 03 07 01 16 07 01 1D 07 00 1D 07 03 0A 00 03 07 03 26 07 00 2C 07 01 11 FF 00 01 00 05 07 00 03 07 01 16 07 01 1D 07 00 1D 07 03 0A 00 04 07 03 26 07 00 2C 07 01 11 07 01 16 FF 00 01 00 05 07 00 03 07 01 16 07 01 1D 07 00 1D 07 03 0A 00 07 07 03 26 07 00 2C 07 01 11 07 01 16 07 01 1D 07 00 1D 07 03 0A 41 07 00 1B 43 05 44 07 00 1B 47 05 47 07 00 1B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     236    244    Ljava/lang/IllegalStateException;
        //  236    244    236    244    Any
        //  252    254    3      8      Ljava/lang/ArithmeticException;
        //  191    198    198    199    Any
        //  191    198    198    199    Ljava/util/NoSuchElementException;
        //  192    198    198    199    Any
        //  192    198    191    192    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  192    198    198    199    Ljava/lang/NullPointerException;
        //  212    219    219    220    Any
        //  212    219    212    213    Ljava/util/ConcurrentModificationException;
        //  212    219    219    220    Any
        //  213    219    212    213    Ljava/lang/NegativeArraySizeException;
        //  212    219    3      8      Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:543)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        fdU.c = new fdR(null);
        final Minecraft func_71410_x = Minecraft.func_71410_x();
        while (true) {
            int n = 0;
            Label_0035: {
                if (fc.1 == 0) {
                    n = 369921578;
                    break Label_0035;
                }
                n = 390772864;
            }
            switch (n ^ 0xA000BCC6) {
                case -680348520: {
                    continue;
                }
                default: {
                    final fdU c = new fdU(func_71410_x);
                    while (true) {
                        int n2 = 0;
                        Label_0082: {
                            if (fc.1 == 0) {
                                n2 = -1336872716;
                                break Label_0082;
                            }
                            n2 = 121315162;
                        }
                        switch (n2 ^ 0xA58E6BF0) {
                            case -1248865330: {
                                continue;
                            }
                            default: {
                                fdU.c = c;
                                return;
                            }
                            case 366910212: {
                                throw null;
                            }
                        }
                        break;
                    }
                    break;
                }
                case -1240714516: {
                    throw null;
                }
            }
            break;
        }
    }
    
    public boolean 2(@Nullable final BlockPos blockPos) {
        return fez.3y(this, 1818750589, blockPos);
    }
    
    @NotNull
    public Vec2f 0() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          227
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            219
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            211
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: new             Lnet/minecraft/util/math/Vec2f;
        //    27: dup            
        //    28: getstatic       dev/nuker/pyro/fc.1:I
        //    31: ifne            40
        //    34: ldc_w           -1613131533
        //    37: goto            43
        //    40: ldc_w           425282644
        //    43: ldc_w           291365098
        //    46: ixor           
        //    47: lookupswitch {
        //          -1903923175: 196
        //          1428938001: 40
        //          default: 72
        //        }
        //    72: aload_0        
        //    73: getstatic       dev/nuker/pyro/fc.1:I
        //    76: ifne            85
        //    79: ldc_w           1493159782
        //    82: goto            88
        //    85: ldc_w           -387175388
        //    88: ldc_w           377164924
        //    91: ixor           
        //    92: lookupswitch {
        //          -769089622: 85
        //          1317329690: 198
        //          default: 120
        //        }
        //   120: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   123: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   126: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70177_z:F
        //   129: aload_0        
        //   130: getfield        dev/nuker/pyro/fdU.c:Lnet/minecraft/client/Minecraft;
        //   133: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   136: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70125_A:F
        //   139: getstatic       dev/nuker/pyro/fc.c:I
        //   142: ifne            151
        //   145: ldc_w           -2087433710
        //   148: goto            154
        //   151: ldc_w           1741761872
        //   154: ldc_w           1917439437
        //   157: ixor           
        //   158: lookupswitch {
        //          -237140001: 151
        //          362340509: 184
        //          default: 200
        //        }
        //   184: goto            188
        //   187: athrow         
        //   188: invokespecial   net/minecraft/util/math/Vec2f.<init>:(FF)V
        //   191: goto            195
        //   194: athrow         
        //   195: areturn        
        //   196: aconst_null    
        //   197: athrow         
        //   198: aconst_null    
        //   199: athrow         
        //   200: aconst_null    
        //   201: athrow         
        //   202: pop            
        //   203: goto            24
        //   206: pop            
        //   207: aconst_null    
        //   208: goto            202
        //   211: dup            
        //   212: ifnull          202
        //   215: checkcast       Ljava/lang/Throwable;
        //   218: athrow         
        //   219: dup            
        //   220: ifnull          206
        //   223: checkcast       Ljava/lang/Throwable;
        //   226: athrow         
        //   227: aconst_null    
        //   228: athrow         
        //    StackMapTable: 00 19 43 07 00 1B 04 FF 00 0B 00 00 00 01 07 00 1B FC 00 03 07 00 03 FF 00 0F 00 01 07 00 03 00 02 08 00 18 08 00 18 FF 00 02 00 01 07 00 03 00 03 08 00 18 08 00 18 01 FF 00 1C 00 01 07 00 03 00 02 08 00 18 08 00 18 FF 00 0C 00 01 07 00 03 00 03 08 00 18 08 00 18 07 00 03 FF 00 02 00 01 07 00 03 00 04 08 00 18 08 00 18 07 00 03 01 FF 00 1F 00 01 07 00 03 00 03 08 00 18 08 00 18 07 00 03 FF 00 1E 00 01 07 00 03 00 04 08 00 18 08 00 18 02 02 FF 00 02 00 01 07 00 03 00 05 08 00 18 08 00 18 02 02 01 FF 00 1D 00 01 07 00 03 00 04 08 00 18 08 00 18 02 02 42 07 00 1B FF 00 00 00 01 07 00 03 00 04 08 00 18 08 00 18 02 02 45 07 00 1B 40 07 00 9F FF 00 00 00 01 07 00 03 00 02 08 00 18 08 00 18 FF 00 01 00 01 07 00 03 00 03 08 00 18 08 00 18 07 00 03 FF 00 01 00 01 07 00 03 00 04 08 00 18 08 00 18 02 02 41 07 00 1B 43 05 44 07 00 1B 47 05 47 07 00 1B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                 
        //  -----  -----  -----  -----  -------------------------------------
        //  8      20     211    219    Any
        //  211    219    211    219    Any
        //  227    229    3      8      Any
        //  187    194    194    195    Any
        //  188    194    3      8      Any
        //  187    194    187    188    Any
        //  187    194    187    188    Any
        //  187    194    194    195    Ljava/lang/IndexOutOfBoundsException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:543)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
