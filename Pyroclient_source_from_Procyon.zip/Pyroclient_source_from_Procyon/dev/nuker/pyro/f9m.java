// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import net.minecraft.client.entity.EntityPlayerSP;
import dev.nuker.pyro.security.inject.LauncherEventHide;

public class f9m extends fQ
{
    public f0o<f9l> c;
    public int 1;
    public boolean c;
    
    public void c(final f0w f0w) {
        fez.av(this, 1594356651, f0w);
    }
    
    @f0g
    @LauncherEventHide
    public void c(final f4e f4e) {
        fez.2i(this, 715279434, f4e);
    }
    
    @f0g(4)
    @LauncherEventHide
    public void c(final f4p f4p) {
        fez.6l(this, 1613559777, f4p);
    }
    
    static {
        throw t;
    }
    
    @Override
    public void c(final boolean p0, @Nullable final EntityPlayerSP p1, @Nullable final World p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          287
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            279
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            271
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_0        
        //    25: iload_1        
        //    26: aload_2        
        //    27: aload_3        
        //    28: getstatic       dev/nuker/pyro/fc.c:I
        //    31: ifne            39
        //    34: ldc             -645406253
        //    36: goto            41
        //    39: ldc             1495238313
        //    41: ldc             -1010971567
        //    43: ixor           
        //    44: lookupswitch {
        //          46726799: 39
        //          440020354: 254
        //          default: 72
        //        }
        //    72: goto            76
        //    75: athrow         
        //    76: invokespecial   dev/nuker/pyro/fQ.c:(ZLnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/world/World;)V
        //    79: goto            83
        //    82: athrow         
        //    83: aload_0        
        //    84: aload_0        
        //    85: getstatic       dev/nuker/pyro/fc.0:I
        //    88: ifgt            96
        //    91: ldc             666433414
        //    93: goto            98
        //    96: ldc             1011519597
        //    98: ldc             218856102
        //   100: ixor           
        //   101: lookupswitch {
        //          716410144: 96
        //          826403531: 128
        //          default: 256
        //        }
        //   128: getfield        dev/nuker/pyro/f9m.c:Ldev/nuker/pyro/f0o;
        //   131: goto            135
        //   134: athrow         
        //   135: invokevirtual   dev/nuker/pyro/f0o.c:()Ljava/lang/Object;
        //   138: goto            142
        //   141: athrow         
        //   142: getstatic       dev/nuker/pyro/fc.c:I
        //   145: ifne            153
        //   148: ldc             1641291898
        //   150: goto            155
        //   153: ldc             -518884540
        //   155: ldc             -315205506
        //   157: ixor           
        //   158: lookupswitch {
        //          -1931315196: 258
        //          -814136939: 153
        //          default: 184
        //        }
        //   184: goto            188
        //   187: athrow         
        //   188: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   191: goto            195
        //   194: athrow         
        //   195: goto            199
        //   198: athrow         
        //   199: invokevirtual   dev/nuker/pyro/f9m.5:(Ljava/lang/String;)V
        //   202: goto            206
        //   205: athrow         
        //   206: getstatic       dev/nuker/pyro/fc.0:I
        //   209: ifgt            217
        //   212: ldc             -1234578327
        //   214: goto            219
        //   217: ldc             157403992
        //   219: ldc             950350529
        //   221: ixor           
        //   222: lookupswitch {
        //          -1899174232: 217
        //          834992537: 248
        //          default: 260
        //        }
        //   248: aload_0        
        //   249: iconst_0       
        //   250: putfield        dev/nuker/pyro/f9m.c:Z
        //   253: return         
        //   254: aconst_null    
        //   255: athrow         
        //   256: aconst_null    
        //   257: athrow         
        //   258: aconst_null    
        //   259: athrow         
        //   260: aconst_null    
        //   261: athrow         
        //   262: pop            
        //   263: goto            24
        //   266: pop            
        //   267: aconst_null    
        //   268: goto            262
        //   271: dup            
        //   272: ifnull          262
        //   275: checkcast       Ljava/lang/Throwable;
        //   278: athrow         
        //   279: dup            
        //   280: ifnull          266
        //   283: checkcast       Ljava/lang/Throwable;
        //   286: athrow         
        //   287: aconst_null    
        //   288: athrow         
        //    RuntimeInvisibleTypeAnnotations: 00 02 16 01 00 00 27 00 00 16 02 00 00 27 00 00
        //    StackMapTable: 00 29 43 07 00 3F 04 FF 00 0B 00 00 00 01 07 00 3F FF 00 03 00 04 07 00 03 01 07 00 67 07 00 69 00 00 FF 00 0E 00 04 07 00 03 01 07 00 67 07 00 69 00 04 07 00 03 01 07 00 67 07 00 69 FF 00 01 00 04 07 00 03 01 07 00 67 07 00 69 00 05 07 00 03 01 07 00 67 07 00 69 01 FF 00 1E 00 04 07 00 03 01 07 00 67 07 00 69 00 04 07 00 03 01 07 00 67 07 00 69 FF 00 02 00 00 00 01 07 00 3F FF 00 00 00 04 07 00 03 01 07 00 67 07 00 69 00 04 07 00 03 01 07 00 67 07 00 69 45 07 00 3F 00 FF 00 0C 00 04 07 00 03 01 07 00 67 07 00 69 00 02 07 00 03 07 00 03 FF 00 01 00 04 07 00 03 01 07 00 67 07 00 69 00 03 07 00 03 07 00 03 01 FF 00 1D 00 04 07 00 03 01 07 00 67 07 00 69 00 02 07 00 03 07 00 03 45 07 00 3F FF 00 00 00 04 07 00 03 01 07 00 67 07 00 69 00 02 07 00 03 07 00 50 45 07 00 3F FF 00 00 00 04 07 00 03 01 07 00 67 07 00 69 00 02 07 00 03 07 00 6B FF 00 0A 00 04 07 00 03 01 07 00 67 07 00 69 00 02 07 00 03 07 00 6B FF 00 01 00 04 07 00 03 01 07 00 67 07 00 69 00 03 07 00 03 07 00 6B 01 FF 00 1C 00 04 07 00 03 01 07 00 67 07 00 69 00 02 07 00 03 07 00 6B 42 07 00 3F FF 00 00 00 04 07 00 03 01 07 00 67 07 00 69 00 02 07 00 03 07 00 6B 45 07 00 3F FF 00 00 00 04 07 00 03 01 07 00 67 07 00 69 00 02 07 00 03 07 00 58 42 07 00 3F FF 00 00 00 04 07 00 03 01 07 00 67 07 00 69 00 02 07 00 03 07 00 58 45 07 00 3F 00 0A 41 01 1C FF 00 05 00 04 07 00 03 01 07 00 67 07 00 69 00 04 07 00 03 01 07 00 67 07 00 69 FF 00 01 00 04 07 00 03 01 07 00 67 07 00 69 00 02 07 00 03 07 00 03 FF 00 01 00 04 07 00 03 01 07 00 67 07 00 69 00 02 07 00 03 07 00 6B 01 41 07 00 6D 43 05 44 07 00 6D 47 05 47 07 00 3F
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     271    279    Ljava/lang/ClassCastException;
        //  271    279    271    279    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  287    289    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  76     82     82     83     Any
        //  76     82     82     83     Ljava/lang/StringIndexOutOfBoundsException;
        //  76     82     82     83     Any
        //  76     82     82     83     Ljava/lang/EnumConstantNotPresentException;
        //  76     82     82     83     Any
        //  134    141    141    142    Any
        //  134    141    3      8      Any
        //  134    141    141    142    Any
        //  135    141    134    135    Any
        //  134    141    134    135    Ljava/lang/IllegalStateException;
        //  187    194    194    195    Any
        //  188    194    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  187    194    187    188    Any
        //  187    194    187    188    Ljava/lang/AssertionError;
        //  188    194    3      8      Any
        //  198    205    205    206    Any
        //  198    205    198    199    Any
        //  198    205    3      8      Ljava/lang/ArithmeticException;
        //  199    205    3      8      Ljava/lang/UnsupportedOperationException;
        //  199    205    198    199    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 95 out of bounds for length 95
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public f9m() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: ldc             "\u3cdb\ub244\u8f84\uadb0\u67d9\u582f\u7e49\u688d"
        //     3: invokestatic    invokestatic   !!! ERROR
        //     6: ldc             "\u3cfb\ub244\u8f84\uadb0\u67f9\u582f\u7e49\u688d"
        //     8: invokestatic    invokestatic   !!! ERROR
        //    11: ldc             "\u3cfc\ub249\u8f9b\uadab\u67dd\u582b\u7e00\u6899\uc2cc\ua339\u9a24\u1310\uc0ee\u714e\u9016\u4c3f\ub207\u4d0e\u0102\u07ff\u1329\ufed7\u6b43\u8851\u36fb\u3cf7\u7ff2\ua8f1\ud1a0\u72e1\u45f2\u6bba\u7594\u976a"
        //    13: invokestatic    invokestatic   !!! ERROR
        //    16: invokespecial   dev/nuker/pyro/fQ.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //    19: aload_0        
        //    20: new             Ldev/nuker/pyro/f0o;
        //    23: dup            
        //    24: ldc             "\u3cd0\ub24a\u8f93\uada1"
        //    26: invokestatic    invokestatic   !!! ERROR
        //    29: ldc             "\u3cf0\ub24a\u8f93\uada1"
        //    31: getstatic       dev/nuker/pyro/fc.1:I
        //    34: ifne            42
        //    37: ldc             1578865759
        //    39: goto            44
        //    42: ldc             514350962
        //    44: ldc             -610744651
        //    46: ixor           
        //    47: lookupswitch {
        //          -2054991126: 292
        //          996449056: 42
        //          default: 72
        //        }
        //    72: invokestatic    invokestatic   !!! ERROR
        //    75: aconst_null    
        //    76: getstatic       dev/nuker/pyro/fc.0:I
        //    79: ifgt            87
        //    82: ldc             -720143196
        //    84: goto            89
        //    87: ldc             66645913
        //    89: ldc             1457812363
        //    91: ixor           
        //    92: lookupswitch {
        //          -2080960721: 296
        //          -1267511621: 87
        //          default: 120
        //        }
        //   120: getstatic       dev/nuker/pyro/f9l.c:Ldev/nuker/pyro/f9l;
        //   123: invokespecial   dev/nuker/pyro/f0o.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Enum;)V
        //   126: putfield        dev/nuker/pyro/f9m.c:Ldev/nuker/pyro/f0o;
        //   129: aload_0        
        //   130: iconst_0       
        //   131: getstatic       dev/nuker/pyro/fc.1:I
        //   134: ifne            142
        //   137: ldc             -9606629
        //   139: goto            144
        //   142: ldc             -2053959444
        //   144: ldc             -32386788
        //   146: ixor           
        //   147: lookupswitch {
        //          24951559: 142
        //          2072166896: 172
        //          default: 298
        //        }
        //   172: putfield        dev/nuker/pyro/f9m.1:I
        //   175: aload_0        
        //   176: iconst_0       
        //   177: getstatic       dev/nuker/pyro/fc.c:I
        //   180: ifne            188
        //   183: ldc             664646722
        //   185: goto            190
        //   188: ldc             949229796
        //   190: ldc             1754498239
        //   192: ixor           
        //   193: lookupswitch {
        //          1326330109: 290
        //          2072630784: 188
        //          default: 220
        //        }
        //   220: putfield        dev/nuker/pyro/f9m.c:Z
        //   223: aload_0        
        //   224: getstatic       dev/nuker/pyro/fc.c:I
        //   227: ifne            235
        //   230: ldc             -1678340629
        //   232: goto            237
        //   235: ldc             -1088574843
        //   237: ldc             2090408494
        //   239: ixor           
        //   240: lookupswitch {
        //          -1014714197: 268
        //          -412117051: 235
        //          default: 294
        //        }
        //   268: aload_0        
        //   269: getfield        dev/nuker/pyro/f9m.c:Ldev/nuker/pyro/f0o;
        //   272: invokevirtual   dev/nuker/pyro/f9m.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   275: pop            
        //   276: aload_0        
        //   277: getfield        dev/nuker/pyro/f9m.c:Ldev/nuker/pyro/f0o;
        //   280: aload_0        
        //   281: invokedynamic   BootstrapMethod #0, accept:(Ldev/nuker/pyro/f9m;)Ljava/util/function/Consumer;
        //   286: invokevirtual   dev/nuker/pyro/f0o.c:(Ljava/util/function/Consumer;)V
        //   289: return         
        //   290: aconst_null    
        //   291: athrow         
        //   292: aconst_null    
        //   293: athrow         
        //   294: aconst_null    
        //   295: athrow         
        //   296: aconst_null    
        //   297: athrow         
        //   298: aconst_null    
        //   299: athrow         
        //    StackMapTable: 00 14 FF 00 2A 00 01 07 00 03 00 05 07 00 03 08 00 14 08 00 14 07 00 58 07 00 58 FF 00 01 00 01 07 00 03 00 06 07 00 03 08 00 14 08 00 14 07 00 58 07 00 58 01 FF 00 1B 00 01 07 00 03 00 05 07 00 03 08 00 14 08 00 14 07 00 58 07 00 58 FF 00 0E 00 01 07 00 03 00 06 07 00 03 08 00 14 08 00 14 07 00 58 07 00 58 05 FF 00 01 00 01 07 00 03 00 07 07 00 03 08 00 14 08 00 14 07 00 58 07 00 58 05 01 FF 00 1E 00 01 07 00 03 00 06 07 00 03 08 00 14 08 00 14 07 00 58 07 00 58 05 FF 00 15 00 01 07 00 03 00 02 07 00 03 01 FF 00 01 00 01 07 00 03 00 03 07 00 03 01 01 FF 00 1B 00 01 07 00 03 00 02 07 00 03 01 FF 00 0F 00 01 07 00 03 00 02 07 00 03 01 FF 00 01 00 01 07 00 03 00 03 07 00 03 01 01 FF 00 1D 00 01 07 00 03 00 02 07 00 03 01 4E 07 00 03 FF 00 01 00 01 07 00 03 00 02 07 00 03 01 5E 07 00 03 FF 00 15 00 01 07 00 03 00 02 07 00 03 01 FF 00 01 00 01 07 00 03 00 05 07 00 03 08 00 14 08 00 14 07 00 58 07 00 58 41 07 00 03 FF 00 01 00 01 07 00 03 00 06 07 00 03 08 00 14 08 00 14 07 00 58 07 00 58 05 FF 00 01 00 01 07 00 03 00 02 07 00 03 01
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2695)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
