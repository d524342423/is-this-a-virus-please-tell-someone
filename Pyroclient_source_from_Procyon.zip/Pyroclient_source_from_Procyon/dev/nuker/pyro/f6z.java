// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraftforge.event.world.WorldEvent;
import dev.nuker.pyro.security.inject.LauncherEventHide;
import net.minecraft.entity.EntityLivingBase;

public class f6z extends fQ
{
    public f0k c;
    public f0k 0;
    public f0k 1;
    public f0k 2;
    public f0k 3;
    public f0k 4;
    public f0k 5;
    public f0k 6;
    public EntityLivingBase c;
    public float c;
    public float 0;
    
    public boolean c(final EntityLivingBase entityLivingBase) {
        return fez.jv(this, 1454477741, entityLivingBase);
    }
    
    public f6z() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: ifne            11
        //     6: ldc             -1312881334
        //     8: goto            13
        //    11: ldc             -328127953
        //    13: ldc             248893559
        //    15: ixor           
        //    16: lookupswitch {
        //          -1083517635: 11
        //          -492504488: 44
        //          default: 1040
        //        }
        //    44: aload_0        
        //    45: ldc             "\u3caf\ub24a\u8ff0\uada5\u6793\u5845"
        //    47: getstatic       dev/nuker/pyro/fc.0:I
        //    50: ifgt            58
        //    53: ldc             -1453261432
        //    55: goto            60
        //    58: ldc             1804432745
        //    60: ldc             -625689257
        //    62: ixor           
        //    63: lookupswitch {
        //          -1529878414: 58
        //          1943290079: 1060
        //          default: 88
        //        }
        //    88: invokestatic    invokestatic   !!! ERROR
        //    91: ldc             "\u3c8f\ub24a\u8ff0\uad85\u6793\u5845"
        //    93: invokestatic    invokestatic   !!! ERROR
        //    96: ldc             "\u3c8c\ub250\u8ff3\uadab\u6797\u5849\u7e54\u68f9\uc2c0\ua37d\u9a18\u1308\uc088\u714e\u904a\u4c49\ub21c\u4d68\u0102\u07b0\u1357\ufed1\u6b35\u8814\u36bb\u3cc8\u7fec\ua8cf\ud1e1\u72b2\u45c3\u6bba\u75e0\u976a\uc746\u42ca\ufdf8\u1172"
        //    98: getstatic       dev/nuker/pyro/fc.0:I
        //   101: ifgt            109
        //   104: ldc             -2082438260
        //   106: goto            111
        //   109: ldc             1623285325
        //   111: ldc             -830149699
        //   113: ixor           
        //   114: lookupswitch {
        //          419761838: 109
        //          1298425905: 1038
        //          default: 140
        //        }
        //   140: invokestatic    invokestatic   !!! ERROR
        //   143: invokespecial   dev/nuker/pyro/fQ.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   146: aload_0        
        //   147: getstatic       dev/nuker/pyro/fc.c:I
        //   150: ifne            158
        //   153: ldc             2125566591
        //   155: goto            160
        //   158: ldc             1579803406
        //   160: ldc             327107736
        //   162: ixor           
        //   163: lookupswitch {
        //          1297524630: 188
        //          1842271975: 158
        //          default: 1062
        //        }
        //   188: aload_0        
        //   189: new             Ldev/nuker/pyro/f0k;
        //   192: dup            
        //   193: ldc             "\u3cbd\ub249\u8fe6\uadbd\u679f\u585a\u7e53"
        //   195: getstatic       dev/nuker/pyro/fc.0:I
        //   198: ifgt            206
        //   201: ldc             22365094
        //   203: goto            208
        //   206: ldc             -952966979
        //   208: ldc             -1785671943
        //   210: ixor           
        //   211: lookupswitch {
        //          -2100547889: 206
        //          -1798992545: 1044
        //          default: 236
        //        }
        //   236: invokestatic    invokestatic   !!! ERROR
        //   239: ldc             "\u3c9d\ub249\u8fe6\uadbd\u679f\u585a\u7e53"
        //   241: getstatic       dev/nuker/pyro/fc.0:I
        //   244: ifgt            252
        //   247: ldc             -1863607205
        //   249: goto            254
        //   252: ldc             2046448427
        //   254: ldc             -1235628416
        //   256: ixor           
        //   257: lookupswitch {
        //          649220827: 1064
        //          736302362: 252
        //          default: 284
        //        }
        //   284: invokestatic    invokestatic   !!! ERROR
        //   287: aconst_null    
        //   288: iconst_1       
        //   289: getstatic       dev/nuker/pyro/fc.0:I
        //   292: ifgt            300
        //   295: ldc             -748314703
        //   297: goto            302
        //   300: ldc             -1939949216
        //   302: ldc             1382734859
        //   304: ixor           
        //   305: lookupswitch {
        //          -2129706054: 300
        //          -566991509: 332
        //          default: 1048
        //        }
        //   332: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   335: invokevirtual   dev/nuker/pyro/f6z.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   338: checkcast       Ldev/nuker/pyro/f0k;
        //   341: putfield        dev/nuker/pyro/f6z.c:Ldev/nuker/pyro/f0k;
        //   344: aload_0        
        //   345: aload_0        
        //   346: new             Ldev/nuker/pyro/f0k;
        //   349: dup            
        //   350: ldc             "\u3ca0\ub24a\u8fe9\uadb7\u678e\u584d\u7e52\u68e3"
        //   352: invokestatic    invokestatic   !!! ERROR
        //   355: ldc             "\u3c80\ub24a\u8fe9\uadb7\u678e\u584d\u7e52\u68e3"
        //   357: getstatic       dev/nuker/pyro/fc.1:I
        //   360: ifne            368
        //   363: ldc             1865177898
        //   365: goto            370
        //   368: ldc             -281661422
        //   370: ldc             470853107
        //   372: ixor           
        //   373: lookupswitch {
        //          -215575071: 400
        //          1933377241: 368
        //          default: 1052
        //        }
        //   400: invokestatic    invokestatic   !!! ERROR
        //   403: aconst_null    
        //   404: iconst_0       
        //   405: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   408: getstatic       dev/nuker/pyro/fc.1:I
        //   411: ifne            419
        //   414: ldc             -1917601681
        //   416: goto            421
        //   419: ldc             1751894378
        //   421: ldc             1550924693
        //   423: ixor           
        //   424: lookupswitch {
        //          -775781382: 1034
        //          -442159038: 419
        //          default: 452
        //        }
        //   452: invokevirtual   dev/nuker/pyro/f6z.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   455: checkcast       Ldev/nuker/pyro/f0k;
        //   458: putfield        dev/nuker/pyro/f6z.0:Ldev/nuker/pyro/f0k;
        //   461: getstatic       dev/nuker/pyro/fc.0:I
        //   464: ifgt            472
        //   467: ldc             561463657
        //   469: goto            474
        //   472: ldc             1472460543
        //   474: ldc             -191078043
        //   476: ixor           
        //   477: lookupswitch {
        //          -1554016358: 504
        //          -706011124: 472
        //          default: 1054
        //        }
        //   504: aload_0        
        //   505: getstatic       dev/nuker/pyro/fc.0:I
        //   508: ifgt            516
        //   511: ldc             1503604306
        //   513: goto            518
        //   516: ldc             240104119
        //   518: ldc             -2010471960
        //   520: ixor           
        //   521: lookupswitch {
        //          -776630342: 1046
        //          1164594559: 516
        //          default: 548
        //        }
        //   548: aload_0        
        //   549: new             Ldev/nuker/pyro/f0k;
        //   552: dup            
        //   553: ldc             "\u3ca3\ub240\u8ff2\uadb0\u6788\u5849\u7e4c\u68e3"
        //   555: invokestatic    invokestatic   !!! ERROR
        //   558: ldc             "\u3c83\ub240\u8ff2\uadb0\u6788\u5849\u7e4c\u68e3"
        //   560: invokestatic    invokestatic   !!! ERROR
        //   563: aconst_null    
        //   564: iconst_0       
        //   565: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   568: getstatic       dev/nuker/pyro/fc.c:I
        //   571: ifne            579
        //   574: ldc             -2079047501
        //   576: goto            581
        //   579: ldc             1457063498
        //   581: ldc             1356324147
        //   583: ixor           
        //   584: lookupswitch {
        //          -725377664: 579
        //          101636985: 612
        //          default: 1036
        //        }
        //   612: invokevirtual   dev/nuker/pyro/f6z.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   615: checkcast       Ldev/nuker/pyro/f0k;
        //   618: putfield        dev/nuker/pyro/f6z.1:Ldev/nuker/pyro/f0k;
        //   621: aload_0        
        //   622: aload_0        
        //   623: new             Ldev/nuker/pyro/f0k;
        //   626: dup            
        //   627: ldc             "\u3cac\ub24b\u8fee\uada9\u679b\u5844\u7e53"
        //   629: getstatic       dev/nuker/pyro/fc.c:I
        //   632: ifne            640
        //   635: ldc             2024355854
        //   637: goto            642
        //   640: ldc             -380981892
        //   642: ldc             -885383184
        //   644: ixor           
        //   645: lookupswitch {
        //          -1282201602: 640
        //          577811084: 672
        //          default: 1056
        //        }
        //   672: invokestatic    invokestatic   !!! ERROR
        //   675: ldc             "\u3c8c\ub24b\u8fee\uada9\u679b\u5844\u7e53"
        //   677: invokestatic    invokestatic   !!! ERROR
        //   680: aconst_null    
        //   681: iconst_0       
        //   682: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   685: invokevirtual   dev/nuker/pyro/f6z.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   688: checkcast       Ldev/nuker/pyro/f0k;
        //   691: putfield        dev/nuker/pyro/f6z.2:Ldev/nuker/pyro/f0k;
        //   694: aload_0        
        //   695: aload_0        
        //   696: new             Ldev/nuker/pyro/f0k;
        //   699: dup            
        //   700: ldc             "\u3cb9\ub244\u8fea\uada1\u679e"
        //   702: invokestatic    invokestatic   !!! ERROR
        //   705: ldc             "\u3c99\ub244\u8fea\uada1\u679e"
        //   707: getstatic       dev/nuker/pyro/fc.1:I
        //   710: ifne            718
        //   713: ldc             -738742585
        //   715: goto            720
        //   718: ldc             283963243
        //   720: ldc             1152819372
        //   722: ixor           
        //   723: lookupswitch {
        //          -1757344149: 1050
        //          566182874: 718
        //          default: 748
        //        }
        //   748: invokestatic    invokestatic   !!! ERROR
        //   751: aconst_null    
        //   752: iconst_0       
        //   753: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   756: invokevirtual   dev/nuker/pyro/f6z.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   759: checkcast       Ldev/nuker/pyro/f0k;
        //   762: putfield        dev/nuker/pyro/f6z.3:Ldev/nuker/pyro/f0k;
        //   765: getstatic       dev/nuker/pyro/fc.c:I
        //   768: ifne            776
        //   771: ldc             1580622281
        //   773: goto            778
        //   776: ldc             -915116227
        //   778: ldc             -672368348
        //   780: ixor           
        //   781: lookupswitch {
        //          -1982195475: 776
        //          513283609: 808
        //          default: 1032
        //        }
        //   808: aload_0        
        //   809: aload_0        
        //   810: new             Ldev/nuker/pyro/f0k;
        //   813: dup            
        //   814: ldc             "\u3ca4\ub24b\u8ff1\uadad\u6789\u5841\u7e42\u68fc\uc2c6\ua36f"
        //   816: invokestatic    invokestatic   !!! ERROR
        //   819: ldc             "\u3c84\ub24b\u8ff1\uadad\u6789\u5841\u7e42\u68fc\uc2c6\ua36f"
        //   821: invokestatic    invokestatic   !!! ERROR
        //   824: aconst_null    
        //   825: iconst_1       
        //   826: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   829: invokevirtual   dev/nuker/pyro/f6z.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   832: checkcast       Ldev/nuker/pyro/f0k;
        //   835: putfield        dev/nuker/pyro/f6z.4:Ldev/nuker/pyro/f0k;
        //   838: getstatic       dev/nuker/pyro/fc.0:I
        //   841: ifgt            849
        //   844: ldc             -696944133
        //   846: goto            851
        //   849: ldc             -713897342
        //   851: ldc             -1355066739
        //   853: ixor           
        //   854: lookupswitch {
        //          2035166070: 849
        //          2051643407: 880
        //          default: 1066
        //        }
        //   880: aload_0        
        //   881: aload_0        
        //   882: new             Ldev/nuker/pyro/f0k;
        //   885: dup            
        //   886: ldc             "\u3cac\ub257\u8fea\uadab\u6788\u584b\u7e48\u68f5\uc2c0\ua377"
        //   888: invokestatic    invokestatic   !!! ERROR
        //   891: ldc             "\u3c8c\ub257\u8fea\uadab\u6788\u586b\u7e48\u68f5\uc2c0\ua377"
        //   893: invokestatic    invokestatic   !!! ERROR
        //   896: aconst_null    
        //   897: iconst_1       
        //   898: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   901: invokevirtual   dev/nuker/pyro/f6z.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   904: checkcast       Ldev/nuker/pyro/f0k;
        //   907: putfield        dev/nuker/pyro/f6z.5:Ldev/nuker/pyro/f0k;
        //   910: aload_0        
        //   911: aload_0        
        //   912: new             Ldev/nuker/pyro/f0k;
        //   915: dup            
        //   916: ldc             "\u3cb9\ub240\u8fe6\uada9\u6789"
        //   918: invokestatic    invokestatic   !!! ERROR
        //   921: ldc             "\u3c99\ub240\u8fe6\uada9\u6789"
        //   923: invokestatic    invokestatic   !!! ERROR
        //   926: aconst_null    
        //   927: iconst_0       
        //   928: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   931: invokevirtual   dev/nuker/pyro/f6z.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   934: checkcast       Ldev/nuker/pyro/f0k;
        //   937: putfield        dev/nuker/pyro/f6z.6:Ldev/nuker/pyro/f0k;
        //   940: getstatic       dev/nuker/pyro/fc.1:I
        //   943: ifne            951
        //   946: ldc             -1041014894
        //   948: goto            953
        //   951: ldc             -572504836
        //   953: ldc             -46600877
        //   955: ixor           
        //   956: lookupswitch {
        //          551070127: 984
        //          1019982529: 951
        //          default: 1058
        //        }
        //   984: aload_0        
        //   985: aconst_null    
        //   986: getstatic       dev/nuker/pyro/fc.1:I
        //   989: ifne            997
        //   992: ldc             407774955
        //   994: goto            999
        //   997: ldc             1434218859
        //   999: ldc             1557563193
        //  1001: ixor           
        //  1002: lookupswitch {
        //          1150853586: 1042
        //          1183711836: 997
        //          default: 1028
        //        }
        //  1028: putfield        dev/nuker/pyro/f6z.c:Lnet/minecraft/entity/EntityLivingBase;
        //  1031: return         
        //  1032: aconst_null    
        //  1033: athrow         
        //  1034: aconst_null    
        //  1035: athrow         
        //  1036: aconst_null    
        //  1037: athrow         
        //  1038: aconst_null    
        //  1039: athrow         
        //  1040: aconst_null    
        //  1041: athrow         
        //  1042: aconst_null    
        //  1043: athrow         
        //  1044: aconst_null    
        //  1045: athrow         
        //  1046: aconst_null    
        //  1047: athrow         
        //  1048: aconst_null    
        //  1049: athrow         
        //  1050: aconst_null    
        //  1051: athrow         
        //  1052: aconst_null    
        //  1053: athrow         
        //  1054: aconst_null    
        //  1055: athrow         
        //  1056: aconst_null    
        //  1057: athrow         
        //  1058: aconst_null    
        //  1059: athrow         
        //  1060: aconst_null    
        //  1061: athrow         
        //  1062: aconst_null    
        //  1063: athrow         
        //  1064: aconst_null    
        //  1065: athrow         
        //  1066: aconst_null    
        //  1067: athrow         
        //    StackMapTable: 00 48 0B 41 01 1E FF 00 0D 00 01 06 00 02 06 07 00 A3 FF 00 01 00 01 06 00 03 06 07 00 A3 01 FF 00 1B 00 01 06 00 02 06 07 00 A3 FF 00 14 00 01 06 00 04 06 07 00 A3 07 00 A3 07 00 A3 FF 00 01 00 01 06 00 05 06 07 00 A3 07 00 A3 07 00 A3 01 FF 00 1C 00 01 06 00 04 06 07 00 A3 07 00 A3 07 00 A3 FF 00 11 00 01 07 00 03 00 01 07 00 03 FF 00 01 00 01 07 00 03 00 02 07 00 03 01 5B 07 00 03 FF 00 11 00 01 07 00 03 00 05 07 00 03 07 00 03 08 00 BD 08 00 BD 07 00 A3 FF 00 01 00 01 07 00 03 00 06 07 00 03 07 00 03 08 00 BD 08 00 BD 07 00 A3 01 FF 00 1B 00 01 07 00 03 00 05 07 00 03 07 00 03 08 00 BD 08 00 BD 07 00 A3 FF 00 0F 00 01 07 00 03 00 06 07 00 03 07 00 03 08 00 BD 08 00 BD 07 00 A3 07 00 A3 FF 00 01 00 01 07 00 03 00 07 07 00 03 07 00 03 08 00 BD 08 00 BD 07 00 A3 07 00 A3 01 FF 00 1D 00 01 07 00 03 00 06 07 00 03 07 00 03 08 00 BD 08 00 BD 07 00 A3 07 00 A3 FF 00 0F 00 01 07 00 03 00 08 07 00 03 07 00 03 08 00 BD 08 00 BD 07 00 A3 07 00 A3 05 01 FF 00 01 00 01 07 00 03 00 09 07 00 03 07 00 03 08 00 BD 08 00 BD 07 00 A3 07 00 A3 05 01 01 FF 00 1D 00 01 07 00 03 00 08 07 00 03 07 00 03 08 00 BD 08 00 BD 07 00 A3 07 00 A3 05 01 FF 00 23 00 01 07 00 03 00 06 07 00 03 07 00 03 08 01 5A 08 01 5A 07 00 A3 07 00 A3 FF 00 01 00 01 07 00 03 00 07 07 00 03 07 00 03 08 01 5A 08 01 5A 07 00 A3 07 00 A3 01 FF 00 1D 00 01 07 00 03 00 06 07 00 03 07 00 03 08 01 5A 08 01 5A 07 00 A3 07 00 A3 FF 00 12 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 3F FF 00 01 00 01 07 00 03 00 04 07 00 03 07 00 03 07 00 3F 01 FF 00 1E 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 3F 13 41 01 1D 4B 07 00 03 FF 00 01 00 01 07 00 03 00 02 07 00 03 01 5D 07 00 03 FF 00 1E 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 3F FF 00 01 00 01 07 00 03 00 04 07 00 03 07 00 03 07 00 3F 01 FF 00 1E 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 3F FF 00 1B 00 01 07 00 03 00 05 07 00 03 07 00 03 08 02 6F 08 02 6F 07 00 A3 FF 00 01 00 01 07 00 03 00 06 07 00 03 07 00 03 08 02 6F 08 02 6F 07 00 A3 01 FF 00 1D 00 01 07 00 03 00 05 07 00 03 07 00 03 08 02 6F 08 02 6F 07 00 A3 FF 00 2D 00 01 07 00 03 00 06 07 00 03 07 00 03 08 02 B8 08 02 B8 07 00 A3 07 00 A3 FF 00 01 00 01 07 00 03 00 07 07 00 03 07 00 03 08 02 B8 08 02 B8 07 00 A3 07 00 A3 01 FF 00 1B 00 01 07 00 03 00 06 07 00 03 07 00 03 08 02 B8 08 02 B8 07 00 A3 07 00 A3 1B 41 01 1D 28 41 01 1C FB 00 46 41 01 1E FF 00 0C 00 01 07 00 03 00 02 07 00 03 05 FF 00 01 00 01 07 00 03 00 03 07 00 03 05 01 FF 00 1C 00 01 07 00 03 00 02 07 00 03 05 03 FF 00 01 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 3F FF 00 01 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 3F FF 00 01 00 01 06 00 04 06 07 00 A3 07 00 A3 07 00 A3 01 FF 00 01 00 01 07 00 03 00 02 07 00 03 05 FF 00 01 00 01 07 00 03 00 05 07 00 03 07 00 03 08 00 BD 08 00 BD 07 00 A3 41 07 00 03 FF 00 01 00 01 07 00 03 00 08 07 00 03 07 00 03 08 00 BD 08 00 BD 07 00 A3 07 00 A3 05 01 FF 00 01 00 01 07 00 03 00 06 07 00 03 07 00 03 08 02 B8 08 02 B8 07 00 A3 07 00 A3 FF 00 01 00 01 07 00 03 00 06 07 00 03 07 00 03 08 01 5A 08 01 5A 07 00 A3 07 00 A3 01 FF 00 01 00 01 07 00 03 00 05 07 00 03 07 00 03 08 02 6F 08 02 6F 07 00 A3 01 FF 00 01 00 01 06 00 02 06 07 00 A3 FF 00 01 00 01 07 00 03 00 01 07 00 03 FF 00 01 00 01 07 00 03 00 06 07 00 03 07 00 03 08 00 BD 08 00 BD 07 00 A3 07 00 A3 01
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public boolean c() {
        return fez.hu(this, 1283419884);
    }
    
    @f0g
    @LauncherEventHide
    public void c(final f4u f4u) {
        fez.ie(this, 535106316, f4u);
    }
    
    public float c(final EntityLivingBase p0, final double p1, final double p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          588
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            580
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            572
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: getfield        net/minecraft/entity/EntityLivingBase.field_70163_u:D
        //    28: aload_1        
        //    29: goto            33
        //    32: athrow         
        //    33: invokevirtual   net/minecraft/entity/EntityLivingBase.func_70047_e:()F
        //    36: goto            40
        //    39: athrow         
        //    40: fconst_2       
        //    41: fdiv           
        //    42: f2d            
        //    43: dadd           
        //    44: aload_0        
        //    45: getfield        dev/nuker/pyro/f6z.c:Lnet/minecraft/client/Minecraft;
        //    48: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //    51: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70163_u:D
        //    54: aload_0        
        //    55: getfield        dev/nuker/pyro/f6z.c:Lnet/minecraft/client/Minecraft;
        //    58: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //    61: goto            65
        //    64: athrow         
        //    65: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_70047_e:()F
        //    68: goto            72
        //    71: athrow         
        //    72: f2d            
        //    73: dadd           
        //    74: dsub           
        //    75: dstore          6
        //    77: aload_1        
        //    78: getfield        net/minecraft/entity/EntityLivingBase.field_70165_t:D
        //    81: aload_0        
        //    82: getfield        dev/nuker/pyro/f6z.c:Lnet/minecraft/client/Minecraft;
        //    85: getstatic       dev/nuker/pyro/fc.1:I
        //    88: ifne            96
        //    91: ldc             1424798707
        //    93: goto            98
        //    96: ldc             -603531178
        //    98: ldc             -1377663686
        //   100: ixor           
        //   101: lookupswitch {
        //          -116508983: 96
        //          1910791532: 128
        //          default: 549
        //        }
        //   128: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   131: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70165_t:D
        //   134: dsub           
        //   135: getstatic       dev/nuker/pyro/fc.1:I
        //   138: ifne            146
        //   141: ldc             1832646186
        //   143: goto            148
        //   146: ldc             -1759925779
        //   148: ldc             -190640813
        //   150: ixor           
        //   151: lookupswitch {
        //          -1718027399: 146
        //          1673176254: 176
        //          default: 553
        //        }
        //   176: dstore          8
        //   178: aload_1        
        //   179: getstatic       dev/nuker/pyro/fc.c:I
        //   182: ifne            190
        //   185: ldc             1616041694
        //   187: goto            192
        //   190: ldc             -800701868
        //   192: ldc             675931057
        //   194: ixor           
        //   195: lookupswitch {
        //          -133193243: 220
        //          1209742703: 190
        //          default: 547
        //        }
        //   220: getfield        net/minecraft/entity/EntityLivingBase.field_70161_v:D
        //   223: aload_0        
        //   224: getstatic       dev/nuker/pyro/fc.1:I
        //   227: ifne            235
        //   230: ldc             -1406838
        //   232: goto            237
        //   235: ldc             -407912869
        //   237: ldc             -1777778671
        //   239: ixor           
        //   240: lookupswitch {
        //          1776535707: 235
        //          1906769482: 268
        //          default: 559
        //        }
        //   268: getfield        dev/nuker/pyro/f6z.c:Lnet/minecraft/client/Minecraft;
        //   271: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   274: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70161_v:D
        //   277: dsub           
        //   278: dstore          10
        //   280: dload           8
        //   282: dstore          12
        //   284: getstatic       dev/nuker/pyro/fc.0:I
        //   287: ifgt            295
        //   290: ldc             505816655
        //   292: goto            297
        //   295: ldc             579897603
        //   297: ldc             -1379875943
        //   299: ixor           
        //   300: lookupswitch {
        //          -1890563430: 328
        //          -1276713514: 295
        //          default: 561
        //        }
        //   328: dload           12
        //   330: dload           12
        //   332: dmul           
        //   333: dstore          14
        //   335: getstatic       dev/nuker/pyro/fc.1:I
        //   338: ifne            346
        //   341: ldc             -19332614
        //   343: goto            348
        //   346: ldc             -1275411618
        //   348: ldc             826646200
        //   350: ixor           
        //   351: lookupswitch {
        //          -2101387802: 376
        //          -811819198: 346
        //          default: 555
        //        }
        //   376: dload           10
        //   378: getstatic       dev/nuker/pyro/fc.c:I
        //   381: ifne            389
        //   384: ldc             2143672821
        //   386: goto            391
        //   389: ldc             -1579230016
        //   391: ldc             -430056899
        //   393: ixor           
        //   394: lookupswitch {
        //          -1718090808: 551
        //          1904372277: 389
        //          default: 420
        //        }
        //   420: dstore          16
        //   422: aload_0        
        //   423: dload_2        
        //   424: dload           4
        //   426: getstatic       dev/nuker/pyro/fc.1:I
        //   429: ifne            437
        //   432: ldc             -989271586
        //   434: goto            439
        //   437: ldc             1168851577
        //   439: ldc             -339110290
        //   441: ixor           
        //   442: lookupswitch {
        //          670360955: 437
        //          784433072: 545
        //          default: 468
        //        }
        //   468: dload           14
        //   470: dload           16
        //   472: getstatic       dev/nuker/pyro/fc.c:I
        //   475: ifne            483
        //   478: ldc             -346623725
        //   480: goto            485
        //   483: ldc             -1301666003
        //   485: ldc             211121011
        //   487: ixor           
        //   488: lookupswitch {
        //          -1090562978: 516
        //          -406617504: 483
        //          default: 557
        //        }
        //   516: dload           16
        //   518: dmul           
        //   519: dadd           
        //   520: goto            524
        //   523: athrow         
        //   524: invokestatic    java/lang/Math.sqrt:(D)D
        //   527: goto            531
        //   530: athrow         
        //   531: dload           6
        //   533: goto            537
        //   536: athrow         
        //   537: invokevirtual   dev/nuker/pyro/f6z.c:(DDDD)F
        //   540: goto            544
        //   543: athrow         
        //   544: freturn        
        //   545: aconst_null    
        //   546: athrow         
        //   547: aconst_null    
        //   548: athrow         
        //   549: aconst_null    
        //   550: athrow         
        //   551: aconst_null    
        //   552: athrow         
        //   553: aconst_null    
        //   554: athrow         
        //   555: aconst_null    
        //   556: athrow         
        //   557: aconst_null    
        //   558: athrow         
        //   559: aconst_null    
        //   560: athrow         
        //   561: aconst_null    
        //   562: athrow         
        //   563: pop            
        //   564: goto            24
        //   567: pop            
        //   568: aconst_null    
        //   569: goto            563
        //   572: dup            
        //   573: ifnull          563
        //   576: checkcast       Ljava/lang/Throwable;
        //   579: athrow         
        //   580: dup            
        //   581: ifnull          567
        //   584: checkcast       Ljava/lang/Throwable;
        //   587: athrow         
        //   588: aconst_null    
        //   589: athrow         
        //    StackMapTable: 00 3D 43 07 00 C2 04 FF 00 0B 00 00 00 01 07 00 C2 FF 00 03 00 04 07 00 03 07 00 C4 03 03 00 00 47 07 00 C2 FF 00 00 00 04 07 00 03 07 00 C4 03 03 00 02 03 07 00 C4 45 07 00 C2 FF 00 00 00 04 07 00 03 07 00 C4 03 03 00 02 03 02 57 07 00 B4 FF 00 00 00 04 07 00 03 07 00 C4 03 03 00 03 03 03 07 00 D7 45 07 00 C2 FF 00 00 00 04 07 00 03 07 00 C4 03 03 00 03 03 03 02 FF 00 17 00 05 07 00 03 07 00 C4 03 03 03 00 02 03 07 00 D1 FF 00 01 00 05 07 00 03 07 00 C4 03 03 03 00 03 03 07 00 D1 01 FF 00 1D 00 05 07 00 03 07 00 C4 03 03 03 00 02 03 07 00 D1 51 03 FF 00 01 00 05 07 00 03 07 00 C4 03 03 03 00 02 03 01 5B 03 FF 00 0D 00 06 07 00 03 07 00 C4 03 03 03 03 00 01 07 00 C4 FF 00 01 00 06 07 00 03 07 00 C4 03 03 03 03 00 02 07 00 C4 01 5B 07 00 C4 FF 00 0E 00 06 07 00 03 07 00 C4 03 03 03 03 00 02 03 07 00 03 FF 00 01 00 06 07 00 03 07 00 C4 03 03 03 03 00 03 03 07 00 03 01 FF 00 1E 00 06 07 00 03 07 00 C4 03 03 03 03 00 02 03 07 00 03 FD 00 1A 03 03 41 01 1E FC 00 11 03 41 01 1B 4C 03 FF 00 01 00 09 07 00 03 07 00 C4 03 03 03 03 03 03 03 00 02 03 01 5C 03 FF 00 10 00 0A 07 00 03 07 00 C4 03 03 03 03 03 03 03 03 00 03 07 00 03 03 03 FF 00 01 00 0A 07 00 03 07 00 C4 03 03 03 03 03 03 03 03 00 04 07 00 03 03 03 01 FF 00 1C 00 0A 07 00 03 07 00 C4 03 03 03 03 03 03 03 03 00 03 07 00 03 03 03 FF 00 0E 00 0A 07 00 03 07 00 C4 03 03 03 03 03 03 03 03 00 05 07 00 03 03 03 03 03 FF 00 01 00 0A 07 00 03 07 00 C4 03 03 03 03 03 03 03 03 00 06 07 00 03 03 03 03 03 01 FF 00 1E 00 0A 07 00 03 07 00 C4 03 03 03 03 03 03 03 03 00 05 07 00 03 03 03 03 03 FF 00 06 00 00 00 01 07 00 C2 FF 00 00 00 0A 07 00 03 07 00 C4 03 03 03 03 03 03 03 03 00 04 07 00 03 03 03 03 45 07 00 C2 FF 00 00 00 0A 07 00 03 07 00 C4 03 03 03 03 03 03 03 03 00 04 07 00 03 03 03 03 FF 00 04 00 00 00 01 07 00 C2 FF 00 00 00 0A 07 00 03 07 00 C4 03 03 03 03 03 03 03 03 00 05 07 00 03 03 03 03 03 45 07 00 C2 40 02 FF 00 00 00 0A 07 00 03 07 00 C4 03 03 03 03 03 03 03 03 00 03 07 00 03 03 03 FF 00 01 00 06 07 00 03 07 00 C4 03 03 03 03 00 01 07 00 C4 FF 00 01 00 05 07 00 03 07 00 C4 03 03 03 00 02 03 07 00 D1 FF 00 01 00 09 07 00 03 07 00 C4 03 03 03 03 03 03 03 00 01 03 FF 00 01 00 05 07 00 03 07 00 C4 03 03 03 00 01 03 FF 00 01 00 09 07 00 03 07 00 C4 03 03 03 03 03 03 03 00 00 FF 00 01 00 0A 07 00 03 07 00 C4 03 03 03 03 03 03 03 03 00 05 07 00 03 03 03 03 03 FF 00 01 00 06 07 00 03 07 00 C4 03 03 03 03 00 02 03 07 00 03 FD 00 01 03 03 FF 00 01 00 04 07 00 03 07 00 C4 03 03 00 01 07 00 C2 43 05 44 07 00 C2 47 05 47 07 00 C2
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                      
        //  -----  -----  -----  -----  ------------------------------------------
        //  8      20     572    580    Any
        //  572    580    572    580    Ljava/lang/NullPointerException;
        //  588    590    3      8      Any
        //  32     39     39     40     Any
        //  32     39     3      8      Any
        //  32     39     39     40     Ljava/lang/ClassCastException;
        //  32     39     3      8      Any
        //  32     39     32     33     Any
        //  64     71     71     72     Any
        //  65     71     64     65     Ljava/lang/NullPointerException;
        //  65     71     3      8      Any
        //  64     71     71     72     Ljava/lang/IllegalArgumentException;
        //  64     71     71     72     Ljava/lang/ArithmeticException;
        //  524    530    530    531    Any
        //  524    530    3      8      Ljava/lang/NegativeArraySizeException;
        //  524    530    3      8      Any
        //  524    530    530    531    Ljava/lang/IllegalStateException;
        //  524    530    3      8      Ljava/lang/ArithmeticException;
        //  537    543    543    544    Any
        //  537    543    543    544    Any
        //  537    543    543    544    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  537    543    3      8      Any
        //  537    543    543    544    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:586)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public EntityLivingBase c(final f4u p0, final float p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          895
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            887
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            879
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: fload_2        
        //    25: getstatic       dev/nuker/pyro/fc.c:I
        //    28: ifne            37
        //    31: ldc_w           -1126729014
        //    34: goto            40
        //    37: ldc_w           616360885
        //    40: ldc_w           -1730150976
        //    43: ixor           
        //    44: lookupswitch {
        //          -781299805: 37
        //          604538634: 854
        //          default: 72
        //        }
        //    72: fstore_3       
        //    73: aconst_null    
        //    74: astore          4
        //    76: aload_0        
        //    77: getfield        dev/nuker/pyro/f6z.c:Lnet/minecraft/client/Minecraft;
        //    80: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //    83: getfield        net/minecraft/client/multiplayer/WorldClient.field_72996_f:Ljava/util/List;
        //    86: goto            90
        //    89: athrow         
        //    90: invokeinterface java/util/List.iterator:()Ljava/util/Iterator;
        //    95: goto            99
        //    98: athrow         
        //    99: dup            
        //   100: astore          5
        //   102: getstatic       dev/nuker/pyro/fc.c:I
        //   105: ifne            114
        //   108: ldc_w           779236180
        //   111: goto            117
        //   114: ldc_w           -184469465
        //   117: ldc_w           1034966766
        //   120: ixor           
        //   121: lookupswitch {
        //          331507130: 852
        //          992860400: 114
        //          default: 148
        //        }
        //   148: astore          6
        //   150: aload           6
        //   152: getstatic       dev/nuker/pyro/fc.c:I
        //   155: ifne            164
        //   158: ldc_w           425015662
        //   161: goto            167
        //   164: ldc_w           -1424403651
        //   167: ldc_w           -417796487
        //   170: ixor           
        //   171: lookupswitch {
        //          -28453097: 164
        //          1275182404: 196
        //          default: 858
        //        }
        //   196: goto            200
        //   199: athrow         
        //   200: invokeinterface java/util/Iterator.hasNext:()Z
        //   205: goto            209
        //   208: athrow         
        //   209: ifeq            845
        //   212: getstatic       dev/nuker/pyro/fc.0:I
        //   215: ifgt            224
        //   218: ldc_w           32422302
        //   221: goto            227
        //   224: ldc_w           1114429107
        //   227: ldc_w           -1529851346
        //   230: ixor           
        //   231: lookupswitch {
        //          -1522603088: 862
        //          927391047: 224
        //          default: 256
        //        }
        //   256: aload           5
        //   258: goto            262
        //   261: athrow         
        //   262: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   267: goto            271
        //   270: athrow         
        //   271: checkcast       Lnet/minecraft/entity/Entity;
        //   274: dup            
        //   275: getstatic       dev/nuker/pyro/fc.c:I
        //   278: ifne            287
        //   281: ldc_w           -1176032767
        //   284: goto            290
        //   287: ldc_w           557979986
        //   290: ldc_w           -918429975
        //   293: ixor           
        //   294: lookupswitch {
        //          -402405445: 320
        //          1889989864: 287
        //          default: 868
        //        }
        //   320: astore          7
        //   322: instanceof      Lnet/minecraft/entity/EntityLivingBase;
        //   325: ifne            335
        //   328: aload           5
        //   330: astore          6
        //   332: goto            842
        //   335: aload           7
        //   337: checkcast       Lnet/minecraft/entity/EntityLivingBase;
        //   340: astore          8
        //   342: aload_0        
        //   343: aload           8
        //   345: goto            349
        //   348: athrow         
        //   349: invokevirtual   dev/nuker/pyro/f6z.c:(Lnet/minecraft/entity/EntityLivingBase;)Z
        //   352: goto            356
        //   355: athrow         
        //   356: ifne            365
        //   359: ldc_w           1705179131
        //   362: goto            368
        //   365: ldc_w           1705179132
        //   368: ldc_w           332931544
        //   371: ixor           
        //   372: tableswitch {
        //          -319443898: 396
        //          -319443897: 447
        //          default: 359
        //        }
        //   396: getstatic       dev/nuker/pyro/fc.1:I
        //   399: ifne            408
        //   402: ldc_w           -1594384541
        //   405: goto            411
        //   408: ldc_w           1387484588
        //   411: ldc_w           2079875756
        //   414: ixor           
        //   415: lookupswitch {
        //          -619708977: 856
        //          894941611: 408
        //          default: 440
        //        }
        //   440: aload           5
        //   442: astore          6
        //   444: goto            842
        //   447: aload_0        
        //   448: aload           8
        //   450: goto            454
        //   453: athrow         
        //   454: invokevirtual   dev/nuker/pyro/f6z.0:(Lnet/minecraft/entity/EntityLivingBase;)[F
        //   457: goto            461
        //   460: athrow         
        //   461: astore          9
        //   463: aload_1        
        //   464: goto            468
        //   467: athrow         
        //   468: invokevirtual   dev/nuker/pyro/f4u.5:()F
        //   471: goto            475
        //   474: athrow         
        //   475: aload           9
        //   477: iconst_0       
        //   478: faload         
        //   479: goto            483
        //   482: athrow         
        //   483: invokestatic    dev/nuker/pyro/fev.c:(FF)F
        //   486: goto            490
        //   489: athrow         
        //   490: fstore          10
        //   492: aload_1        
        //   493: goto            497
        //   496: athrow         
        //   497: invokevirtual   dev/nuker/pyro/f4u.2:()F
        //   500: goto            504
        //   503: athrow         
        //   504: aload           9
        //   506: iconst_1       
        //   507: faload         
        //   508: goto            512
        //   511: athrow         
        //   512: invokestatic    dev/nuker/pyro/fev.c:(FF)F
        //   515: goto            519
        //   518: athrow         
        //   519: getstatic       dev/nuker/pyro/fc.1:I
        //   522: ifne            531
        //   525: ldc_w           971717992
        //   528: goto            534
        //   531: ldc_w           1178574420
        //   534: ldc_w           -1041909726
        //   537: ixor           
        //   538: lookupswitch {
        //          -1032285551: 531
        //          -133266102: 864
        //          default: 564
        //        }
        //   564: fstore          11
        //   566: fload           10
        //   568: fload_2        
        //   569: fcmpl          
        //   570: ifle            579
        //   573: ldc_w           795885607
        //   576: goto            582
        //   579: ldc_w           795885606
        //   582: ldc_w           -1881598299
        //   585: ixor           
        //   586: tableswitch {
        //          1095937284: 608
        //          1095937285: 659
        //          default: 573
        //        }
        //   608: getstatic       dev/nuker/pyro/fc.0:I
        //   611: ifgt            620
        //   614: ldc_w           1964043659
        //   617: goto            623
        //   620: ldc_w           -1302190842
        //   623: ldc_w           -1142026549
        //   626: ixor           
        //   627: lookupswitch {
        //          -822156480: 620
        //          160181197: 652
        //          default: 860
        //        }
        //   652: aload           5
        //   654: astore          6
        //   656: goto            842
        //   659: getstatic       dev/nuker/pyro/fc.c:I
        //   662: ifne            671
        //   665: ldc_w           2022343213
        //   668: goto            674
        //   671: ldc_w           -86630116
        //   674: ldc_w           -1407220004
        //   677: ixor           
        //   678: lookupswitch {
        //          -728431375: 671
        //          1456056256: 704
        //          default: 850
        //        }
        //   704: fload           11
        //   706: fload_2        
        //   707: fcmpl          
        //   708: ifle            718
        //   711: aload           5
        //   713: astore          6
        //   715: goto            842
        //   718: fload           10
        //   720: fload           11
        //   722: fadd           
        //   723: fconst_2       
        //   724: fdiv           
        //   725: dup            
        //   726: getstatic       dev/nuker/pyro/fc.1:I
        //   729: ifne            738
        //   732: ldc_w           1741332841
        //   735: goto            741
        //   738: ldc_w           -337708977
        //   741: ldc_w           1073304155
        //   744: ixor           
        //   745: lookupswitch {
        //          1113694612: 738
        //          1479799602: 848
        //          default: 772
        //        }
        //   772: fstore          12
        //   774: fload_3        
        //   775: fcmpl          
        //   776: ifle            831
        //   779: getstatic       dev/nuker/pyro/fc.c:I
        //   782: ifne            791
        //   785: ldc_w           -134981612
        //   788: goto            794
        //   791: ldc_w           -2018261786
        //   794: ldc_w           282780338
        //   797: ixor           
        //   798: lookupswitch {
        //          -1754716588: 824
        //          -416367962: 791
        //          default: 866
        //        }
        //   824: aload           5
        //   826: astore          6
        //   828: goto            842
        //   831: fload           12
        //   833: fstore_3       
        //   834: aload           8
        //   836: astore          4
        //   838: aload           5
        //   840: astore          6
        //   842: goto            150
        //   845: aload           4
        //   847: areturn        
        //   848: aconst_null    
        //   849: athrow         
        //   850: aconst_null    
        //   851: athrow         
        //   852: aconst_null    
        //   853: athrow         
        //   854: aconst_null    
        //   855: athrow         
        //   856: aconst_null    
        //   857: athrow         
        //   858: aconst_null    
        //   859: athrow         
        //   860: aconst_null    
        //   861: athrow         
        //   862: aconst_null    
        //   863: athrow         
        //   864: aconst_null    
        //   865: athrow         
        //   866: aconst_null    
        //   867: athrow         
        //   868: aconst_null    
        //   869: athrow         
        //   870: pop            
        //   871: goto            24
        //   874: pop            
        //   875: aconst_null    
        //   876: goto            870
        //   879: dup            
        //   880: ifnull          870
        //   883: checkcast       Ljava/lang/Throwable;
        //   886: athrow         
        //   887: dup            
        //   888: ifnull          874
        //   891: checkcast       Ljava/lang/Throwable;
        //   894: athrow         
        //   895: aconst_null    
        //   896: athrow         
        //    StackMapTable: 00 69 FF 00 03 00 05 07 00 03 07 01 47 02 02 07 00 C4 00 01 07 00 C2 F9 00 04 FF 00 0B 00 00 00 01 07 00 C2 FE 00 03 07 00 03 07 01 47 02 4C 02 FF 00 02 00 03 07 00 03 07 01 47 02 00 02 02 01 5F 02 FF 00 10 00 05 07 00 03 07 01 47 02 02 05 00 01 07 00 C2 40 07 01 1F 47 07 00 C2 40 07 01 2B FF 00 0E 00 06 07 00 03 07 01 47 02 02 05 07 01 2B 00 01 07 01 2B FF 00 02 00 06 07 00 03 07 01 47 02 02 05 07 01 2B 00 02 07 01 2B 01 5E 07 01 2B FF 00 01 00 07 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 00 00 4D 07 01 2B FF 00 02 00 07 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 00 02 07 01 2B 01 5C 07 01 2B 42 07 00 B4 40 07 01 2B 47 07 00 C2 40 01 0E 42 01 1C 44 07 00 C2 40 07 01 2B 47 07 00 C2 40 07 01 64 FF 00 0F 00 07 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 00 02 07 01 37 07 01 37 FF 00 02 00 07 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 00 03 07 01 37 07 01 37 01 FF 00 1D 00 07 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 00 02 07 01 37 07 01 37 FC 00 0E 07 01 37 FF 00 0C 00 00 00 01 07 00 C2 FF 00 00 00 09 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 07 01 37 07 00 C4 00 02 07 00 03 07 00 C4 45 07 00 C2 40 01 02 05 42 01 1B 0B 42 01 1C 06 45 07 00 B6 FF 00 00 00 09 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 07 01 37 07 00 C4 00 02 07 00 03 07 00 C4 45 07 00 C2 40 07 01 66 FF 00 05 00 0A 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 07 01 37 07 00 C4 07 01 66 00 01 07 00 C2 40 07 01 47 45 07 00 C2 40 02 FF 00 06 00 00 00 01 07 00 C2 FF 00 00 00 0A 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 07 01 37 07 00 C4 07 01 66 00 02 02 02 45 07 00 C2 40 02 FF 00 05 00 0B 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 07 01 37 07 00 C4 07 01 66 02 00 01 07 00 C2 40 07 01 47 45 07 00 C2 40 02 46 07 00 BE FF 00 00 00 0B 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 07 01 37 07 00 C4 07 01 66 02 00 02 02 02 45 07 00 C2 40 02 4B 02 FF 00 02 00 0B 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 07 01 37 07 00 C4 07 01 66 02 00 02 02 01 5D 02 FC 00 08 02 05 42 01 19 0B 42 01 1C 06 0B 42 01 1D 0D FF 00 13 00 0C 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 07 01 37 07 00 C4 07 01 66 02 02 00 02 02 02 FF 00 02 00 0C 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 07 01 37 07 00 C4 07 01 66 02 02 00 03 02 02 01 FF 00 1E 00 0C 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 07 01 37 07 00 C4 07 01 66 02 02 00 02 02 02 FC 00 12 02 42 01 1D 06 FF 00 0A 00 08 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 07 01 37 00 00 FA 00 02 FF 00 02 00 0C 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 07 01 37 07 00 C4 07 01 66 02 02 00 02 02 02 01 FF 00 01 00 06 07 00 03 07 01 47 02 02 05 07 01 2B 00 01 07 01 2B FF 00 01 00 03 07 00 03 07 01 47 02 00 01 02 FF 00 01 00 09 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 07 01 37 07 00 C4 00 00 FF 00 01 00 07 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 00 01 07 01 2B FF 00 01 00 0C 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 07 01 37 07 00 C4 07 01 66 02 02 00 00 FF 00 01 00 07 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 00 00 FF 00 01 00 0B 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 07 01 37 07 00 C4 07 01 66 02 00 01 02 FD 00 01 02 02 FF 00 01 00 07 07 00 03 07 01 47 02 02 07 00 C4 07 01 2B 07 01 2B 00 02 07 01 37 07 01 37 FF 00 01 00 03 07 00 03 07 01 47 02 00 01 07 01 08 43 05 44 07 01 08 47 05 FF 00 07 00 05 07 00 03 07 01 47 02 02 07 00 C4 00 01 07 00 C2
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                     
        //  -----  -----  -----  -----  -----------------------------------------
        //  8      20     879    887    Ljava/lang/RuntimeException;
        //  879    887    879    887    Ljava/lang/IllegalArgumentException;
        //  895    897    3      8      Any
        //  89     98     98     99     Any
        //  90     98     89     90     Any
        //  89     98     3      8      Any
        //  89     98     98     99     Any
        //  90     98     89     90     Any
        //  199    208    208    209    Any
        //  200    208    3      8      Ljava/lang/NullPointerException;
        //  200    208    208    209    Ljava/lang/IndexOutOfBoundsException;
        //  200    208    199    200    Ljava/lang/NullPointerException;
        //  200    208    208    209    Any
        //  261    270    270    271    Any
        //  261    270    261    262    Any
        //  262    270    261    262    Any
        //  262    270    3      8      Any
        //  262    270    3      8      Ljava/lang/UnsupportedOperationException;
        //  349    355    355    356    Any
        //  349    355    3      8      Ljava/lang/AssertionError;
        //  349    355    355    356    Any
        //  349    355    3      8      Any
        //  349    355    3      8      Ljava/lang/IllegalArgumentException;
        //  453    460    460    461    Any
        //  454    460    453    454    Ljava/lang/ClassCastException;
        //  454    460    3      8      Any
        //  454    460    3      8      Any
        //  454    460    460    461    Any
        //  467    474    474    475    Any
        //  468    474    474    475    Ljava/lang/NullPointerException;
        //  467    474    474    475    Any
        //  468    474    3      8      Any
        //  468    474    467    468    Any
        //  483    489    489    490    Any
        //  483    489    489    490    Any
        //  483    489    489    490    Ljava/lang/IllegalStateException;
        //  483    489    3      8      Any
        //  483    489    489    490    Any
        //  496    503    503    504    Any
        //  497    503    496    497    Ljava/util/NoSuchElementException;
        //  497    503    496    497    Any
        //  497    503    503    504    Ljava/lang/IllegalArgumentException;
        //  496    503    503    504    Ljava/lang/ArithmeticException;
        //  511    518    518    519    Any
        //  512    518    518    519    Any
        //  512    518    518    519    Ljava/lang/ArithmeticException;
        //  511    518    511    512    Ljava/lang/IllegalStateException;
        //  512    518    3      8      Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:543)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public float c(final double p0, final double p1, final double p2, final double p3) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          659
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            651
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            643
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: ldc2_w          2.0
        //    27: dload           7
        //    29: dmul           
        //    30: dstore          9
        //    32: dload_1        
        //    33: dstore          11
        //    35: dload           9
        //    37: dload           11
        //    39: dload           11
        //    41: dmul           
        //    42: dmul           
        //    43: dstore          7
        //    45: dload_3        
        //    46: dload_3        
        //    47: getstatic       dev/nuker/pyro/fc.1:I
        //    50: ifne            59
        //    53: ldc_w           481443383
        //    56: goto            62
        //    59: ldc_w           1863367019
        //    62: ldc_w           1252383685
        //    65: ixor           
        //    66: lookupswitch {
        //          632644270: 92
        //          1444406770: 59
        //          default: 620
        //        }
        //    92: dload           5
        //    94: dload           5
        //    96: dmul           
        //    97: dmul           
        //    98: dload           7
        //   100: dadd           
        //   101: dmul           
        //   102: dstore          7
        //   104: dload_1        
        //   105: dstore          13
        //   107: getstatic       dev/nuker/pyro/fc.c:I
        //   110: ifne            119
        //   113: ldc_w           -762729196
        //   116: goto            122
        //   119: ldc_w           -2057279173
        //   122: ldc_w           -799269586
        //   125: ixor           
        //   126: lookupswitch {
        //          47558714: 628
        //          369005467: 119
        //          default: 152
        //        }
        //   152: dload           13
        //   154: dload           13
        //   156: dmul           
        //   157: getstatic       dev/nuker/pyro/fc.0:I
        //   160: ifgt            169
        //   163: ldc_w           -1578537956
        //   166: goto            172
        //   169: ldc_w           -545505126
        //   172: ldc_w           576477384
        //   175: ixor           
        //   176: lookupswitch {
        //          -2085276460: 169
        //          -48228270: 204
        //          default: 614
        //        }
        //   204: dload_1        
        //   205: dmul           
        //   206: dload_1        
        //   207: dmul           
        //   208: getstatic       dev/nuker/pyro/fc.0:I
        //   211: ifgt            220
        //   214: ldc_w           -1880527837
        //   217: goto            223
        //   220: ldc_w           -32576988
        //   223: ldc_w           1440633355
        //   226: ixor           
        //   227: lookupswitch {
        //          -633913816: 618
        //          1569201945: 220
        //          default: 252
        //        }
        //   252: dload           7
        //   254: dsub           
        //   255: getstatic       dev/nuker/pyro/fc.0:I
        //   258: ifgt            267
        //   261: ldc_w           -775474034
        //   264: goto            270
        //   267: ldc_w           34422765
        //   270: ldc_w           -1651275973
        //   273: ixor           
        //   274: lookupswitch {
        //          -209777680: 267
        //          1280619445: 626
        //          default: 300
        //        }
        //   300: goto            304
        //   303: athrow         
        //   304: invokestatic    java/lang/Math.sqrt:(D)D
        //   307: goto            311
        //   310: athrow         
        //   311: dstore          7
        //   313: dload_1        
        //   314: dstore          15
        //   316: getstatic       dev/nuker/pyro/fc.0:I
        //   319: ifgt            328
        //   322: ldc_w           -1695255676
        //   325: goto            331
        //   328: ldc_w           264737946
        //   331: ldc_w           -1261947286
        //   334: ixor           
        //   335: lookupswitch {
        //          -1156603152: 360
        //          775701998: 328
        //          default: 622
        //        }
        //   360: dload           15
        //   362: dload           15
        //   364: dmul           
        //   365: dload           7
        //   367: dadd           
        //   368: getstatic       dev/nuker/pyro/fc.1:I
        //   371: ifne            380
        //   374: ldc_w           -1483541733
        //   377: goto            383
        //   380: ldc_w           -1046111823
        //   383: ldc_w           -2135222561
        //   386: ixor           
        //   387: lookupswitch {
        //          657057220: 380
        //          1092521838: 412
        //          default: 630
        //        }
        //   412: dstore          17
        //   414: dload_1        
        //   415: dstore          19
        //   417: dload           19
        //   419: getstatic       dev/nuker/pyro/fc.c:I
        //   422: ifne            431
        //   425: ldc_w           1687824128
        //   428: goto            434
        //   431: ldc_w           1698533346
        //   434: ldc_w           -144465080
        //   437: ixor           
        //   438: lookupswitch {
        //          -1812364216: 624
        //          666555716: 431
        //          default: 464
        //        }
        //   464: dload           19
        //   466: dmul           
        //   467: dload           7
        //   469: dsub           
        //   470: dstore_1       
        //   471: dload           17
        //   473: dload_3        
        //   474: getstatic       dev/nuker/pyro/fc.0:I
        //   477: ifgt            486
        //   480: ldc_w           -1703875083
        //   483: goto            489
        //   486: ldc_w           539217847
        //   489: ldc_w           1157086292
        //   492: ixor           
        //   493: lookupswitch {
        //          -561557087: 616
        //          -76265305: 486
        //          default: 520
        //        }
        //   520: dload           5
        //   522: dmul           
        //   523: getstatic       dev/nuker/pyro/fc.0:I
        //   526: ifgt            535
        //   529: ldc_w           1628830949
        //   532: goto            538
        //   535: ldc_w           -203849440
        //   538: ldc_w           -1245114525
        //   541: ixor           
        //   542: lookupswitch {
        //          -841971388: 535
        //          -723717242: 632
        //          default: 568
        //        }
        //   568: goto            572
        //   571: athrow         
        //   572: invokestatic    java/lang/Math.atan2:(DD)D
        //   575: goto            579
        //   578: athrow         
        //   579: dstore          7
        //   581: dload_1        
        //   582: dload_3        
        //   583: dload           5
        //   585: dmul           
        //   586: goto            590
        //   589: athrow         
        //   590: invokestatic    java/lang/Math.atan2:(DD)D
        //   593: goto            597
        //   596: athrow         
        //   597: dstore_1       
        //   598: dload           7
        //   600: dload_1        
        //   601: goto            605
        //   604: athrow         
        //   605: invokestatic    java/lang/Math.min:(DD)D
        //   608: goto            612
        //   611: athrow         
        //   612: d2f            
        //   613: freturn        
        //   614: aconst_null    
        //   615: athrow         
        //   616: aconst_null    
        //   617: athrow         
        //   618: aconst_null    
        //   619: athrow         
        //   620: aconst_null    
        //   621: athrow         
        //   622: aconst_null    
        //   623: athrow         
        //   624: aconst_null    
        //   625: athrow         
        //   626: aconst_null    
        //   627: athrow         
        //   628: aconst_null    
        //   629: athrow         
        //   630: aconst_null    
        //   631: athrow         
        //   632: aconst_null    
        //   633: athrow         
        //   634: pop            
        //   635: goto            24
        //   638: pop            
        //   639: aconst_null    
        //   640: goto            634
        //   643: dup            
        //   644: ifnull          634
        //   647: checkcast       Ljava/lang/Throwable;
        //   650: athrow         
        //   651: dup            
        //   652: ifnull          638
        //   655: checkcast       Ljava/lang/Throwable;
        //   658: athrow         
        //   659: aconst_null    
        //   660: athrow         
        //    StackMapTable: 00 41 FF 00 03 00 08 07 00 03 03 03 03 03 03 03 03 00 01 07 00 C2 F8 00 04 FF 00 0B 00 00 00 01 07 00 C2 FF 00 03 00 05 07 00 03 03 03 03 03 00 00 FF 00 22 00 07 07 00 03 03 03 03 03 03 03 00 02 03 03 FF 00 02 00 07 07 00 03 03 03 03 03 03 03 00 03 03 03 01 FF 00 1D 00 07 07 00 03 03 03 03 03 03 03 00 02 03 03 FC 00 1A 03 42 01 1D 50 03 FF 00 02 00 08 07 00 03 03 03 03 03 03 03 03 00 02 03 01 5F 03 4F 03 FF 00 02 00 08 07 00 03 03 03 03 03 03 03 03 00 02 03 01 5C 03 4E 03 FF 00 02 00 08 07 00 03 03 03 03 03 03 03 03 00 02 03 01 5D 03 42 07 00 C2 40 03 45 07 00 C2 40 03 FC 00 10 03 42 01 1C 53 03 FF 00 02 00 09 07 00 03 03 03 03 03 03 03 03 03 00 02 03 01 5C 03 FF 00 12 00 0B 07 00 03 03 03 03 03 03 03 03 03 03 03 00 01 03 FF 00 02 00 0B 07 00 03 03 03 03 03 03 03 03 03 03 03 00 02 03 01 5D 03 FF 00 15 00 0B 07 00 03 03 03 03 03 03 03 03 03 03 03 00 02 03 03 FF 00 02 00 0B 07 00 03 03 03 03 03 03 03 03 03 03 03 00 03 03 03 01 FF 00 1E 00 0B 07 00 03 03 03 03 03 03 03 03 03 03 03 00 02 03 03 FF 00 0E 00 0B 07 00 03 03 03 03 03 03 03 03 03 03 03 00 02 03 03 FF 00 02 00 0B 07 00 03 03 03 03 03 03 03 03 03 03 03 00 03 03 03 01 FF 00 1D 00 0B 07 00 03 03 03 03 03 03 03 03 03 03 03 00 02 03 03 FF 00 02 00 00 00 01 07 00 C2 FF 00 00 00 0B 07 00 03 03 03 03 03 03 03 03 03 03 03 00 02 03 03 45 07 00 C2 40 03 49 07 00 C0 FF 00 00 00 0B 07 00 03 03 03 03 03 03 03 03 03 03 03 00 02 03 03 45 07 00 C2 40 03 46 07 00 C2 FF 00 00 00 0B 07 00 03 03 03 03 03 03 03 03 03 03 03 00 02 03 03 45 07 00 C2 40 03 FF 00 01 00 08 07 00 03 03 03 03 03 03 03 03 00 01 03 FF 00 01 00 0B 07 00 03 03 03 03 03 03 03 03 03 03 03 00 02 03 03 FF 00 01 00 08 07 00 03 03 03 03 03 03 03 03 00 01 03 FF 00 01 00 07 07 00 03 03 03 03 03 03 03 00 02 03 03 FD 00 01 03 03 FF 00 01 00 0B 07 00 03 03 03 03 03 03 03 03 03 03 03 00 01 03 FF 00 01 00 08 07 00 03 03 03 03 03 03 03 03 00 01 03 01 FF 00 01 00 09 07 00 03 03 03 03 03 03 03 03 03 00 01 03 FF 00 01 00 0B 07 00 03 03 03 03 03 03 03 03 03 03 03 00 02 03 03 FF 00 01 00 05 07 00 03 03 03 03 03 00 01 07 00 C2 43 05 44 07 00 C2 47 05 FF 00 07 00 08 07 00 03 03 03 03 03 03 03 03 00 01 07 00 C2
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     643    651    Any
        //  643    651    643    651    Ljava/lang/NullPointerException;
        //  659    661    3      8      Any
        //  303    310    310    311    Any
        //  303    310    303    304    Any
        //  304    310    3      8      Any
        //  304    310    310    311    Ljava/lang/RuntimeException;
        //  304    310    303    304    Ljava/lang/StringIndexOutOfBoundsException;
        //  572    578    578    579    Any
        //  572    578    578    579    Any
        //  572    578    3      8      Ljava/lang/ArithmeticException;
        //  572    578    3      8      Any
        //  572    578    3      8      Ljava/lang/AssertionError;
        //  589    596    596    597    Any
        //  589    596    589    590    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  589    596    3      8      Any
        //  589    596    3      8      Any
        //  590    596    3      8      Ljava/lang/NumberFormatException;
        //  604    611    611    612    Any
        //  605    611    604    605    Any
        //  604    611    611    612    Any
        //  604    611    611    612    Any
        //  604    611    611    612    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:590)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @f0g
    @LauncherEventHide
    public void c(final WorldEvent p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getstatic       dev/nuker/pyro/fc.c:I
        //     4: ifeq            39
        //     7: pop            
        //     8: aconst_null    
        //     9: goto            31
        //    12: nop            
        //    13: nop            
        //    14: nop            
        //    15: athrow         
        //    16: aload_0        
        //    17: aconst_null    
        //    18: putfield        dev/nuker/pyro/f6z.c:Lnet/minecraft/entity/EntityLivingBase;
        //    21: return         
        //    22: pop            
        //    23: goto            16
        //    26: pop            
        //    27: aconst_null    
        //    28: goto            22
        //    31: dup            
        //    32: ifnull          22
        //    35: checkcast       Ljava/lang/Throwable;
        //    38: athrow         
        //    39: dup            
        //    40: ifnull          26
        //    43: checkcast       Ljava/lang/Throwable;
        //    46: athrow         
        //    StackMapTable: 00 06 FF 00 0C 00 00 00 01 07 00 C2 FD 00 03 07 00 03 07 01 94 45 07 00 C2 43 05 44 07 00 C2 47 05
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type
        //  -----  -----  -----  -----  ----
        //  0      12     31     39     Any
        //  31     39     31     39     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:543)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void c(final boolean p0, @Nullable final EntityPlayerSP p1, @Nullable final World p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          129
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            121
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            113
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_0        
        //    25: iload_1        
        //    26: aload_2        
        //    27: aload_3        
        //    28: goto            32
        //    31: athrow         
        //    32: invokespecial   dev/nuker/pyro/fQ.c:(ZLnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/world/World;)V
        //    35: goto            39
        //    38: athrow         
        //    39: aload_0        
        //    40: fconst_0       
        //    41: getstatic       dev/nuker/pyro/fc.1:I
        //    44: ifne            53
        //    47: ldc_w           1545848090
        //    50: goto            56
        //    53: ldc_w           144434641
        //    56: ldc_w           441343942
        //    59: ixor           
        //    60: lookupswitch {
        //          -552526984: 53
        //          1181588188: 102
        //          default: 88
        //        }
        //    88: putfield        dev/nuker/pyro/f6z.c:F
        //    91: aload_0        
        //    92: fconst_0       
        //    93: putfield        dev/nuker/pyro/f6z.0:F
        //    96: aload_0        
        //    97: aconst_null    
        //    98: putfield        dev/nuker/pyro/f6z.c:Lnet/minecraft/entity/EntityLivingBase;
        //   101: return         
        //   102: aconst_null    
        //   103: athrow         
        //   104: pop            
        //   105: goto            24
        //   108: pop            
        //   109: aconst_null    
        //   110: goto            104
        //   113: dup            
        //   114: ifnull          104
        //   117: checkcast       Ljava/lang/Throwable;
        //   120: athrow         
        //   121: dup            
        //   122: ifnull          108
        //   125: checkcast       Ljava/lang/Throwable;
        //   128: athrow         
        //   129: aconst_null    
        //   130: athrow         
        //    RuntimeInvisibleTypeAnnotations: 00 02 16 01 00 01 96 00 00 16 02 00 01 96 00 00
        //    StackMapTable: 00 11 43 07 00 C2 04 FF 00 0B 00 00 00 01 07 00 C2 FF 00 03 00 04 07 00 03 01 07 00 D7 07 01 A3 00 00 46 07 00 C2 FF 00 00 00 04 07 00 03 01 07 00 D7 07 01 A3 00 04 07 00 03 01 07 00 D7 07 01 A3 45 07 00 C2 00 FF 00 0D 00 04 07 00 03 01 07 00 D7 07 01 A3 00 02 07 00 03 02 FF 00 02 00 04 07 00 03 01 07 00 D7 07 01 A3 00 03 07 00 03 02 01 FF 00 1F 00 04 07 00 03 01 07 00 D7 07 01 A3 00 02 07 00 03 02 FF 00 0D 00 04 07 00 03 01 07 00 D7 07 01 A3 00 02 07 00 03 02 41 07 00 C2 43 05 44 07 00 C2 47 05 47 07 00 C2
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     113    121    Any
        //  113    121    113    121    Ljava/lang/IllegalArgumentException;
        //  129    131    3      8      Any
        //  31     38     38     39     Any
        //  32     38     3      8      Ljava/util/ConcurrentModificationException;
        //  31     38     3      8      Any
        //  32     38     3      8      Ljava/lang/ArithmeticException;
        //  31     38     31     32     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:543)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        throw t;
    }
    
    public float[] 0(final EntityLivingBase entityLivingBase) {
        return fez.02(this, 669260386, entityLivingBase);
    }
}
