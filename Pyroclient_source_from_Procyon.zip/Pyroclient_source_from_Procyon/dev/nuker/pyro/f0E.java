// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

public class f0E
{
    public void c(final int p0, final int p1, final int p2, final int p3, final int p4) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          1313
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            1305
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            1297
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: iload_1        
        //    25: istore          6
        //    27: getstatic       dev/nuker/pyro/fc.c:I
        //    30: ifne            38
        //    33: ldc             898168223
        //    35: goto            40
        //    38: ldc             -1340049250
        //    40: ldc             -1099610502
        //    42: ixor           
        //    43: lookupswitch {
        //          -1946307611: 38
        //          240467684: 68
        //          default: 1258
        //        }
        //    68: iload_2        
        //    69: istore          7
        //    71: iload_3        
        //    72: istore          8
        //    74: getstatic       dev/nuker/pyro/fc.c:I
        //    77: ifne            85
        //    80: ldc             -1645475726
        //    82: goto            87
        //    85: ldc             535026680
        //    87: ldc             1730896100
        //    89: ixor           
        //    90: lookupswitch {
        //          -2122936049: 85
        //          -87594858: 1280
        //          default: 116
        //        }
        //   116: iload           4
        //   118: istore          9
        //   120: iload           6
        //   122: iload           8
        //   124: if_icmpge       264
        //   127: getstatic       dev/nuker/pyro/fc.c:I
        //   130: ifne            138
        //   133: ldc             1135902701
        //   135: goto            140
        //   138: ldc             -774114069
        //   140: ldc             272831039
        //   142: ixor           
        //   143: lookupswitch {
        //          127413121: 138
        //          1408724434: 1248
        //          default: 168
        //        }
        //   168: iload           6
        //   170: istore          10
        //   172: iload           8
        //   174: getstatic       dev/nuker/pyro/fc.1:I
        //   177: ifne            185
        //   180: ldc             1980719258
        //   182: goto            187
        //   185: ldc             110008674
        //   187: ldc             -1362894042
        //   189: ixor           
        //   190: lookupswitch {
        //          -1471317436: 216
        //          -657685572: 185
        //          default: 1276
        //        }
        //   216: istore          6
        //   218: getstatic       dev/nuker/pyro/fc.c:I
        //   221: ifne            229
        //   224: ldc             452084240
        //   226: goto            231
        //   229: ldc             -1768576470
        //   231: ldc             -746904833
        //   233: ixor           
        //   234: lookupswitch {
        //          -913743633: 1274
        //          -237235713: 229
        //          default: 260
        //        }
        //   260: iload           10
        //   262: istore          8
        //   264: iload           7
        //   266: iload           9
        //   268: if_icmpge       450
        //   271: getstatic       dev/nuker/pyro/fc.0:I
        //   274: ifgt            282
        //   277: ldc             -281741993
        //   279: goto            284
        //   282: ldc             -1778870858
        //   284: ldc             -5001074
        //   286: ixor           
        //   287: lookupswitch {
        //          277300697: 1272
        //          969533022: 282
        //          default: 312
        //        }
        //   312: iload           7
        //   314: getstatic       dev/nuker/pyro/fc.c:I
        //   317: ifne            325
        //   320: ldc             -944159408
        //   322: goto            327
        //   325: ldc             -523396190
        //   327: ldc             869325173
        //   329: ixor           
        //   330: lookupswitch {
        //          -753057065: 356
        //          -194405339: 325
        //          default: 1262
        //        }
        //   356: istore          10
        //   358: iload           9
        //   360: istore          7
        //   362: getstatic       dev/nuker/pyro/fc.1:I
        //   365: ifne            373
        //   368: ldc             820672826
        //   370: goto            375
        //   373: ldc             -904114925
        //   375: ldc             290049247
        //   377: ixor           
        //   378: lookupswitch {
        //          -294088221: 373
        //          564377061: 1284
        //          default: 404
        //        }
        //   404: iload           10
        //   406: getstatic       dev/nuker/pyro/fc.c:I
        //   409: ifne            417
        //   412: ldc             -1200630450
        //   414: goto            419
        //   417: ldc             -689926181
        //   419: ldc             -2024513523
        //   421: ixor           
        //   422: lookupswitch {
        //          -1311570579: 417
        //          1060877635: 1270
        //          default: 448
        //        }
        //   448: istore          9
        //   450: iload           5
        //   452: bipush          24
        //   454: ishr           
        //   455: sipush          255
        //   458: iand           
        //   459: i2f            
        //   460: ldc             255.0
        //   462: fdiv           
        //   463: fstore          10
        //   465: iload           5
        //   467: bipush          16
        //   469: ishr           
        //   470: sipush          255
        //   473: iand           
        //   474: i2f            
        //   475: ldc             255.0
        //   477: fdiv           
        //   478: getstatic       dev/nuker/pyro/fc.1:I
        //   481: ifne            489
        //   484: ldc             -1516492195
        //   486: goto            491
        //   489: ldc             1641688212
        //   491: ldc             -6616186
        //   493: ixor           
        //   494: lookupswitch {
        //          -1639897326: 520
        //          1510416859: 489
        //          default: 1264
        //        }
        //   520: fstore          11
        //   522: iload           5
        //   524: bipush          8
        //   526: ishr           
        //   527: sipush          255
        //   530: iand           
        //   531: i2f            
        //   532: ldc             255.0
        //   534: fdiv           
        //   535: getstatic       dev/nuker/pyro/fc.c:I
        //   538: ifne            546
        //   541: ldc             977996259
        //   543: goto            548
        //   546: ldc             -225342302
        //   548: ldc             994478217
        //   550: ixor           
        //   551: lookupswitch {
        //          17662314: 1252
        //          405016073: 546
        //          default: 576
        //        }
        //   576: fstore          12
        //   578: iload           5
        //   580: sipush          255
        //   583: iand           
        //   584: i2f            
        //   585: ldc             255.0
        //   587: fdiv           
        //   588: fstore          13
        //   590: goto            594
        //   593: athrow         
        //   594: invokestatic    net/minecraft/client/renderer/Tessellator.func_178181_a:()Lnet/minecraft/client/renderer/Tessellator;
        //   597: goto            601
        //   600: athrow         
        //   601: astore          14
        //   603: getstatic       dev/nuker/pyro/fc.c:I
        //   606: ifne            614
        //   609: ldc             243532295
        //   611: goto            616
        //   614: ldc             898547685
        //   616: ldc             932774465
        //   618: ixor           
        //   619: lookupswitch {
        //          35110308: 644
        //          958201926: 614
        //          default: 1250
        //        }
        //   644: aload           14
        //   646: dup            
        //   647: pop            
        //   648: getstatic       dev/nuker/pyro/fc.0:I
        //   651: ifgt            659
        //   654: ldc             771076715
        //   656: goto            661
        //   659: ldc             1275763528
        //   661: ldc             745079897
        //   663: ixor           
        //   664: lookupswitch {
        //          27047474: 659
        //          1617141521: 692
        //          default: 1286
        //        }
        //   692: goto            696
        //   695: athrow         
        //   696: invokevirtual   net/minecraft/client/renderer/Tessellator.func_178180_c:()Lnet/minecraft/client/renderer/BufferBuilder;
        //   699: goto            703
        //   702: athrow         
        //   703: astore          15
        //   705: goto            709
        //   708: athrow         
        //   709: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179147_l:()V
        //   712: goto            716
        //   715: athrow         
        //   716: getstatic       dev/nuker/pyro/fc.c:I
        //   719: ifne            727
        //   722: ldc             1626079123
        //   724: goto            729
        //   727: ldc             -131125236
        //   729: ldc             -1009786771
        //   731: ixor           
        //   732: lookupswitch {
        //          -1557913602: 727
        //          1004589153: 760
        //          default: 1266
        //        }
        //   760: goto            764
        //   763: athrow         
        //   764: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179090_x:()V
        //   767: goto            771
        //   770: athrow         
        //   771: getstatic       net/minecraft/client/renderer/GlStateManager$SourceFactor.SRC_ALPHA:Lnet/minecraft/client/renderer/GlStateManager$SourceFactor;
        //   774: getstatic       net/minecraft/client/renderer/GlStateManager$DestFactor.ONE_MINUS_SRC_ALPHA:Lnet/minecraft/client/renderer/GlStateManager$DestFactor;
        //   777: getstatic       net/minecraft/client/renderer/GlStateManager$SourceFactor.ONE:Lnet/minecraft/client/renderer/GlStateManager$SourceFactor;
        //   780: getstatic       net/minecraft/client/renderer/GlStateManager$DestFactor.ZERO:Lnet/minecraft/client/renderer/GlStateManager$DestFactor;
        //   783: goto            787
        //   786: athrow         
        //   787: invokestatic    net/minecraft/client/renderer/GlStateManager.func_187428_a:(Lnet/minecraft/client/renderer/GlStateManager$SourceFactor;Lnet/minecraft/client/renderer/GlStateManager$DestFactor;Lnet/minecraft/client/renderer/GlStateManager$SourceFactor;Lnet/minecraft/client/renderer/GlStateManager$DestFactor;)V
        //   790: goto            794
        //   793: athrow         
        //   794: fload           11
        //   796: fload           12
        //   798: fload           13
        //   800: fload           10
        //   802: goto            806
        //   805: athrow         
        //   806: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179131_c:(FFFF)V
        //   809: goto            813
        //   812: athrow         
        //   813: aload           15
        //   815: bipush          7
        //   817: getstatic       net/minecraft/client/renderer/vertex/DefaultVertexFormats.field_181705_e:Lnet/minecraft/client/renderer/vertex/VertexFormat;
        //   820: goto            824
        //   823: athrow         
        //   824: invokevirtual   net/minecraft/client/renderer/BufferBuilder.func_181668_a:(ILnet/minecraft/client/renderer/vertex/VertexFormat;)V
        //   827: goto            831
        //   830: athrow         
        //   831: aload           15
        //   833: iload           6
        //   835: i2d            
        //   836: iload           9
        //   838: i2d            
        //   839: dconst_0       
        //   840: goto            844
        //   843: athrow         
        //   844: invokevirtual   net/minecraft/client/renderer/BufferBuilder.func_181662_b:(DDD)Lnet/minecraft/client/renderer/BufferBuilder;
        //   847: goto            851
        //   850: athrow         
        //   851: goto            855
        //   854: athrow         
        //   855: invokevirtual   net/minecraft/client/renderer/BufferBuilder.func_181675_d:()V
        //   858: goto            862
        //   861: athrow         
        //   862: aload           15
        //   864: getstatic       dev/nuker/pyro/fc.0:I
        //   867: ifgt            875
        //   870: ldc             -2113781104
        //   872: goto            877
        //   875: ldc             1465847012
        //   877: ldc             -1289770940
        //   879: ixor           
        //   880: lookupswitch {
        //          -465525600: 908
        //          824044244: 875
        //          default: 1282
        //        }
        //   908: iload           8
        //   910: i2d            
        //   911: iload           9
        //   913: i2d            
        //   914: dconst_0       
        //   915: goto            919
        //   918: athrow         
        //   919: invokevirtual   net/minecraft/client/renderer/BufferBuilder.func_181662_b:(DDD)Lnet/minecraft/client/renderer/BufferBuilder;
        //   922: goto            926
        //   925: athrow         
        //   926: goto            930
        //   929: athrow         
        //   930: invokevirtual   net/minecraft/client/renderer/BufferBuilder.func_181675_d:()V
        //   933: goto            937
        //   936: athrow         
        //   937: getstatic       dev/nuker/pyro/fc.0:I
        //   940: ifgt            948
        //   943: ldc             1537218954
        //   945: goto            950
        //   948: ldc             -574358026
        //   950: ldc             -1202470710
        //   952: ixor           
        //   953: lookupswitch {
        //          -470558400: 948
        //          1703951676: 980
        //          default: 1256
        //        }
        //   980: aload           15
        //   982: iload           8
        //   984: i2d            
        //   985: iload           7
        //   987: i2d            
        //   988: dconst_0       
        //   989: goto            993
        //   992: athrow         
        //   993: invokevirtual   net/minecraft/client/renderer/BufferBuilder.func_181662_b:(DDD)Lnet/minecraft/client/renderer/BufferBuilder;
        //   996: goto            1000
        //   999: athrow         
        //  1000: goto            1004
        //  1003: athrow         
        //  1004: invokevirtual   net/minecraft/client/renderer/BufferBuilder.func_181675_d:()V
        //  1007: goto            1011
        //  1010: athrow         
        //  1011: aload           15
        //  1013: iload           6
        //  1015: i2d            
        //  1016: iload           7
        //  1018: i2d            
        //  1019: dconst_0       
        //  1020: getstatic       dev/nuker/pyro/fc.1:I
        //  1023: ifne            1031
        //  1026: ldc             -1055554791
        //  1028: goto            1033
        //  1031: ldc             -493874306
        //  1033: ldc             -1306010578
        //  1035: ixor           
        //  1036: lookupswitch {
        //          1354223440: 1064
        //          1932681015: 1031
        //          default: 1268
        //        }
        //  1064: goto            1068
        //  1067: athrow         
        //  1068: invokevirtual   net/minecraft/client/renderer/BufferBuilder.func_181662_b:(DDD)Lnet/minecraft/client/renderer/BufferBuilder;
        //  1071: goto            1075
        //  1074: athrow         
        //  1075: getstatic       dev/nuker/pyro/fc.c:I
        //  1078: ifne            1086
        //  1081: ldc             831609401
        //  1083: goto            1088
        //  1086: ldc             -701388763
        //  1088: ldc             -1676125145
        //  1090: ixor           
        //  1091: lookupswitch {
        //          -1383528930: 1086
        //          1244263426: 1116
        //          default: 1260
        //        }
        //  1116: goto            1120
        //  1119: athrow         
        //  1120: invokevirtual   net/minecraft/client/renderer/BufferBuilder.func_181675_d:()V
        //  1123: goto            1127
        //  1126: athrow         
        //  1127: aload           14
        //  1129: goto            1133
        //  1132: athrow         
        //  1133: invokevirtual   net/minecraft/client/renderer/Tessellator.func_78381_a:()V
        //  1136: goto            1140
        //  1139: athrow         
        //  1140: getstatic       dev/nuker/pyro/fc.1:I
        //  1143: ifne            1151
        //  1146: ldc             -50292603
        //  1148: goto            1153
        //  1151: ldc             -620542400
        //  1153: ldc             -655981951
        //  1155: ixor           
        //  1156: lookupswitch {
        //          65389761: 1184
        //          635836932: 1151
        //          default: 1254
        //        }
        //  1184: goto            1188
        //  1187: athrow         
        //  1188: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179098_w:()V
        //  1191: goto            1195
        //  1194: athrow         
        //  1195: getstatic       dev/nuker/pyro/fc.c:I
        //  1198: ifne            1206
        //  1201: ldc             -1675617168
        //  1203: goto            1208
        //  1206: ldc             171331478
        //  1208: ldc             628100404
        //  1210: ixor           
        //  1211: lookupswitch {
        //          -1185935036: 1278
        //          -735142629: 1206
        //          default: 1236
        //        }
        //  1236: goto            1240
        //  1239: athrow         
        //  1240: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179084_k:()V
        //  1243: goto            1247
        //  1246: athrow         
        //  1247: return         
        //  1248: aconst_null    
        //  1249: athrow         
        //  1250: aconst_null    
        //  1251: athrow         
        //  1252: aconst_null    
        //  1253: athrow         
        //  1254: aconst_null    
        //  1255: athrow         
        //  1256: aconst_null    
        //  1257: athrow         
        //  1258: aconst_null    
        //  1259: athrow         
        //  1260: aconst_null    
        //  1261: athrow         
        //  1262: aconst_null    
        //  1263: athrow         
        //  1264: aconst_null    
        //  1265: athrow         
        //  1266: aconst_null    
        //  1267: athrow         
        //  1268: aconst_null    
        //  1269: athrow         
        //  1270: aconst_null    
        //  1271: athrow         
        //  1272: aconst_null    
        //  1273: athrow         
        //  1274: aconst_null    
        //  1275: athrow         
        //  1276: aconst_null    
        //  1277: athrow         
        //  1278: aconst_null    
        //  1279: athrow         
        //  1280: aconst_null    
        //  1281: athrow         
        //  1282: aconst_null    
        //  1283: athrow         
        //  1284: aconst_null    
        //  1285: athrow         
        //  1286: aconst_null    
        //  1287: athrow         
        //  1288: pop            
        //  1289: goto            24
        //  1292: pop            
        //  1293: aconst_null    
        //  1294: goto            1288
        //  1297: dup            
        //  1298: ifnull          1288
        //  1301: checkcast       Ljava/lang/Throwable;
        //  1304: athrow         
        //  1305: dup            
        //  1306: ifnull          1292
        //  1309: checkcast       Ljava/lang/Throwable;
        //  1312: athrow         
        //  1313: aconst_null    
        //  1314: athrow         
        //    StackMapTable: 00 A3 FF 00 03 00 0E 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 00 01 07 00 29 FF 00 04 00 06 07 00 03 01 01 01 01 01 00 00 FF 00 0B 00 00 00 01 07 00 29 FF 00 03 00 06 07 00 03 01 01 01 01 01 00 00 FC 00 0D 01 41 01 1B FD 00 10 01 01 41 01 1C FC 00 15 01 41 01 1B FF 00 10 00 0B 07 00 03 01 01 01 01 01 01 01 01 01 01 00 01 01 FF 00 01 00 0B 07 00 03 01 01 01 01 01 01 01 01 01 01 00 02 01 01 5C 01 0C 41 01 1C FA 00 03 11 41 01 1B 4C 01 FF 00 01 00 0A 07 00 03 01 01 01 01 01 01 01 01 01 00 02 01 01 5C 01 FC 00 10 01 41 01 1C 4C 01 FF 00 01 00 0B 07 00 03 01 01 01 01 01 01 01 01 01 01 00 02 01 01 5C 01 FA 00 01 FF 00 26 00 0B 07 00 03 01 01 01 01 01 01 01 01 01 02 00 01 02 FF 00 01 00 0B 07 00 03 01 01 01 01 01 01 01 01 01 02 00 02 02 01 5C 02 FF 00 19 00 0C 07 00 03 01 01 01 01 01 01 01 01 01 02 02 00 01 02 FF 00 01 00 0C 07 00 03 01 01 01 01 01 01 01 01 01 02 02 00 02 02 01 5B 02 FF 00 10 00 00 00 01 07 00 29 FF 00 00 00 0E 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 00 00 45 07 00 29 40 07 00 52 FC 00 0C 07 00 52 41 01 1B 4E 07 00 52 FF 00 01 00 0F 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 00 02 07 00 52 01 5E 07 00 52 42 07 00 0B 40 07 00 52 45 07 00 29 40 07 00 8E FF 00 04 00 10 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 07 00 8E 00 01 07 00 29 00 45 07 00 29 00 0A 41 01 1E 42 07 00 11 00 45 07 00 29 00 4E 07 00 29 FF 00 00 00 10 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 07 00 8E 00 04 07 00 6E 07 00 74 07 00 6E 07 00 74 45 07 00 29 00 4A 07 00 29 FF 00 00 00 10 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 07 00 8E 00 04 02 02 02 02 45 07 00 29 00 49 07 00 09 FF 00 00 00 10 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 07 00 8E 00 03 07 00 8E 01 07 00 B6 45 07 00 29 00 FF 00 0B 00 00 00 01 07 00 29 FF 00 00 00 10 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 07 00 8E 00 04 07 00 8E 03 03 03 45 07 00 29 40 07 00 8E 42 07 00 15 40 07 00 8E 45 07 00 29 00 4C 07 00 8E FF 00 01 00 10 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 07 00 8E 00 02 07 00 8E 01 5E 07 00 8E 49 07 00 29 FF 00 00 00 10 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 07 00 8E 00 04 07 00 8E 03 03 03 45 07 00 29 40 07 00 8E 42 07 00 29 40 07 00 8E 45 07 00 29 00 0A 41 01 1D FF 00 0B 00 00 00 01 07 00 29 FF 00 00 00 10 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 07 00 8E 00 04 07 00 8E 03 03 03 45 07 00 29 40 07 00 8E FF 00 02 00 00 00 01 07 00 29 FF 00 00 00 10 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 07 00 8E 00 01 07 00 8E 45 07 00 29 00 FF 00 13 00 10 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 07 00 8E 00 04 07 00 8E 03 03 03 FF 00 01 00 10 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 07 00 8E 00 05 07 00 8E 03 03 03 01 FF 00 1E 00 10 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 07 00 8E 00 04 07 00 8E 03 03 03 42 07 00 29 FF 00 00 00 10 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 07 00 8E 00 04 07 00 8E 03 03 03 45 07 00 29 40 07 00 8E 4A 07 00 8E FF 00 01 00 10 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 07 00 8E 00 02 07 00 8E 01 5B 07 00 8E 42 07 00 29 40 07 00 8E 45 07 00 29 00 44 07 00 29 40 07 00 52 45 07 00 29 00 0A 41 01 1E FF 00 02 00 00 00 01 07 00 29 FF 00 00 00 10 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 07 00 8E 00 00 45 07 00 29 00 0A 41 01 1B 42 07 00 29 00 45 07 00 29 00 FF 00 00 00 0A 07 00 03 01 01 01 01 01 01 01 01 01 00 00 FF 00 01 00 0F 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 00 00 FF 00 01 00 0C 07 00 03 01 01 01 01 01 01 01 01 01 02 02 00 01 02 FF 00 01 00 10 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 07 00 8E 00 00 01 FF 00 01 00 07 07 00 03 01 01 01 01 01 01 00 00 FF 00 01 00 10 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 07 00 8E 00 01 07 00 8E FF 00 01 00 0A 07 00 03 01 01 01 01 01 01 01 01 01 00 01 01 FF 00 01 00 0B 07 00 03 01 01 01 01 01 01 01 01 01 02 00 01 02 FF 00 01 00 10 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 07 00 8E 00 00 FF 00 01 00 10 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 07 00 8E 00 04 07 00 8E 03 03 03 FF 00 01 00 0B 07 00 03 01 01 01 01 01 01 01 01 01 01 00 01 01 FA 00 01 FC 00 01 01 41 01 FF 00 01 00 10 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 07 00 8E 00 00 FF 00 01 00 09 07 00 03 01 01 01 01 01 01 01 01 00 00 FF 00 01 00 10 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 07 00 8E 00 01 07 00 8E FF 00 01 00 0B 07 00 03 01 01 01 01 01 01 01 01 01 01 00 00 FF 00 01 00 0F 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 07 00 52 00 01 07 00 52 FF 00 01 00 06 07 00 03 01 01 01 01 01 00 01 07 00 29 43 05 44 07 00 29 47 05 FF 00 07 00 0E 07 00 03 01 01 01 01 01 01 01 01 01 02 02 02 02 00 01 07 00 29
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     1297   1305   Any
        //  1297   1305   1297   1305   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1313   1315   3      8      Ljava/lang/AssertionError;
        //  594    600    600    601    Any
        //  594    600    3      8      Any
        //  594    600    600    601    Any
        //  594    600    600    601    Any
        //  594    600    600    601    Any
        //  695    702    702    703    Any
        //  696    702    3      8      Any
        //  695    702    3      8      Ljava/util/ConcurrentModificationException;
        //  696    702    3      8      Any
        //  696    702    695    696    Ljava/lang/AssertionError;
        //  708    715    715    716    Any
        //  708    715    3      8      Ljava/util/ConcurrentModificationException;
        //  709    715    3      8      Ljava/lang/NullPointerException;
        //  709    715    715    716    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  709    715    708    709    Any
        //  763    770    770    771    Any
        //  763    770    763    764    Ljava/lang/IllegalArgumentException;
        //  764    770    3      8      Any
        //  763    770    770    771    Any
        //  764    770    770    771    Any
        //  786    793    793    794    Any
        //  786    793    786    787    Any
        //  787    793    786    787    Ljava/lang/IllegalArgumentException;
        //  786    793    786    787    Ljava/lang/IllegalStateException;
        //  787    793    793    794    Ljava/lang/EnumConstantNotPresentException;
        //  805    812    812    813    Any
        //  805    812    3      8      Any
        //  806    812    805    806    Any
        //  806    812    812    813    Ljava/lang/NegativeArraySizeException;
        //  805    812    805    806    Any
        //  823    830    830    831    Any
        //  823    830    830    831    Ljava/lang/IndexOutOfBoundsException;
        //  824    830    823    824    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  823    830    830    831    Ljava/lang/NullPointerException;
        //  823    830    3      8      Ljava/lang/ClassCastException;
        //  844    850    850    851    Any
        //  844    850    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  844    850    850    851    Any
        //  844    850    850    851    Ljava/lang/IndexOutOfBoundsException;
        //  844    850    3      8      Ljava/lang/NullPointerException;
        //  854    861    861    862    Any
        //  854    861    861    862    Any
        //  854    861    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  854    861    854    855    Ljava/lang/EnumConstantNotPresentException;
        //  855    861    3      8      Ljava/lang/UnsupportedOperationException;
        //  918    925    925    926    Any
        //  918    925    918    919    Ljava/lang/AssertionError;
        //  919    925    3      8      Any
        //  919    925    925    926    Any
        //  918    925    918    919    Ljava/lang/IllegalStateException;
        //  929    936    936    937    Any
        //  929    936    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  929    936    936    937    Ljava/util/ConcurrentModificationException;
        //  930    936    929    930    Ljava/util/ConcurrentModificationException;
        //  929    936    929    930    Any
        //  993    999    999    1000   Any
        //  993    999    999    1000   Ljava/lang/NegativeArraySizeException;
        //  993    999    3      8      Any
        //  993    999    999    1000   Ljava/util/NoSuchElementException;
        //  993    999    999    1000   Any
        //  1004   1010   1010   1011   Any
        //  1004   1010   1010   1011   Ljava/lang/EnumConstantNotPresentException;
        //  1004   1010   3      8      Any
        //  1004   1010   3      8      Any
        //  1004   1010   1010   1011   Any
        //  1067   1074   1074   1075   Any
        //  1068   1074   3      8      Any
        //  1068   1074   3      8      Any
        //  1067   1074   1067   1068   Any
        //  1067   1074   1067   1068   Any
        //  1119   1126   1126   1127   Any
        //  1120   1126   3      8      Ljava/lang/IndexOutOfBoundsException;
        //  1119   1126   1119   1120   Ljava/util/ConcurrentModificationException;
        //  1119   1126   3      8      Any
        //  1120   1126   1119   1120   Any
        //  1132   1139   1139   1140   Any
        //  1132   1139   3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1132   1139   1139   1140   Any
        //  1132   1139   1132   1133   Any
        //  1133   1139   1132   1133   Ljava/lang/UnsupportedOperationException;
        //  1188   1194   1194   1195   Any
        //  1188   1194   1194   1195   Ljava/lang/IllegalArgumentException;
        //  1188   1194   3      8      Ljava/lang/IllegalStateException;
        //  1188   1194   3      8      Ljava/lang/AssertionError;
        //  1188   1194   1194   1195   Any
        //  1239   1246   1246   1247   Any
        //  1239   1246   1246   1247   Any
        //  1240   1246   1239   1240   Any
        //  1239   1246   3      8      Any
        //  1240   1246   3      8      Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visitVariable(StackMappingVisitor.java:470)
        //     at com.strobel.assembler.ir.Instruction.accept(Instruction.java:556)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:403)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public f0E() {
    }
    
    static {
        throw t;
    }
    
    public f0E(final DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }
}
