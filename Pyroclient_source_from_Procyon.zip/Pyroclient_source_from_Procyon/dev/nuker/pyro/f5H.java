// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import net.minecraft.client.gui.ScaledResolution;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;

public class f5H extends f5q
{
    @NotNull
    public f5h[] c;
    
    @NotNull
    public f5h[] c() {
        Object o = null;
        Block_0: {
            break Block_0;
        Label_0038:
            while (true) {
                do {
                    Label_0025: {
                        break Label_0025;
                        try {
                            o = null;
                            if (fc.0 != 0) {
                                null;
                                goto Label_0030;
                            }
                            continue Label_0038;
                            return this.c;
                        }
                        catch (StringIndexOutOfBoundsException ex) {}
                    }
                    continue Label_0038;
                } while (o == null);
                break;
            }
        }
        throw (Throwable)o;
    }
    
    @Override
    public boolean 1() {
        return fez.hv(this, 359565625);
    }
    
    public f5H() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: ldc             "\u3d54\ub24a\u8e2c\uadad\u672f\u5996\u7e43\u692e\uc2d7\ua3c6\u9bcc\u130a\uc15d"
        //     3: invokestatic    invokestatic   !!! ERROR
        //     6: aconst_null    
        //     7: iconst_2       
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifne            20
        //    15: ldc             1862387883
        //    17: goto            22
        //    20: ldc             -1762353715
        //    22: ldc             39595849
        //    24: ixor           
        //    25: lookupswitch {
        //          -1800883580: 52
        //          1834870754: 20
        //          default: 136
        //        }
        //    52: invokespecial   dev/nuker/pyro/f5q.<init>:(Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
        //    55: aload_0        
        //    56: iconst_4       
        //    57: anewarray       Ldev/nuker/pyro/f5h;
        //    60: dup            
        //    61: iconst_0       
        //    62: aconst_null    
        //    63: checkcast       Ldev/nuker/pyro/f5h;
        //    66: aastore        
        //    67: dup            
        //    68: iconst_1       
        //    69: aconst_null    
        //    70: checkcast       Ldev/nuker/pyro/f5h;
        //    73: aastore        
        //    74: dup            
        //    75: iconst_2       
        //    76: aconst_null    
        //    77: checkcast       Ldev/nuker/pyro/f5h;
        //    80: aastore        
        //    81: dup            
        //    82: iconst_3       
        //    83: aconst_null    
        //    84: checkcast       Ldev/nuker/pyro/f5h;
        //    87: aastore        
        //    88: getstatic       dev/nuker/pyro/fc.0:I
        //    91: ifgt            99
        //    94: ldc             -616469992
        //    96: goto            101
        //    99: ldc             -1031646417
        //   101: ldc             1370038594
        //   103: ixor           
        //   104: lookupswitch {
        //          -1964487846: 99
        //          -1825869203: 132
        //          default: 138
        //        }
        //   132: putfield        dev/nuker/pyro/f5H.c:[Ldev/nuker/pyro/f5h;
        //   135: return         
        //   136: aconst_null    
        //   137: athrow         
        //   138: aconst_null    
        //   139: athrow         
        //    StackMapTable: 00 08 FF 00 14 00 01 06 00 05 06 07 00 38 05 01 05 FF 00 01 00 01 06 00 06 06 07 00 38 05 01 05 01 FF 00 1D 00 01 06 00 05 06 07 00 38 05 01 05 FF 00 2E 00 01 07 00 03 00 02 07 00 03 07 00 39 FF 00 01 00 01 07 00 03 00 03 07 00 03 07 00 39 01 FF 00 1E 00 01 07 00 03 00 02 07 00 03 07 00 39 FF 00 03 00 01 06 00 05 06 07 00 38 05 01 05 FF 00 01 00 01 07 00 03 00 02 07 00 03 07 00 39
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public float 0() {
        return fez.dY(this, 478365850);
    }
    
    static {
        throw t;
    }
    
    @Override
    public float 5() {
        return fez.dR(this, 1326550666);
    }
    
    public void c(@NotNull final f5h[] c) {
        Object o = null;
        Block_0: {
            break Block_0;
        Label_0087:
            while (true) {
            Label_0029_Outer:
                do {
                    Label_0074: {
                        break Label_0074;
                        try {
                            o = null;
                            if (fc.c != 0) {
                                null;
                                goto Label_0079;
                            }
                            continue Label_0087;
                            // switch([Lcom.strobel.decompiler.ast.Label;@6eafa08d, n ^ 0x9147AC45)
                            // iftrue(Label_0027:, fc.1 != 0)
                            while (true) {
                                while (true) {
                                    final int n = -1425510858;
                                    Label_0060: {
                                        this.c = c;
                                    }
                                    return;
                                    continue Label_0029_Outer;
                                }
                                Label_0027: {
                                    final int n = -25225076;
                                }
                                continue;
                            }
                            Label_0068: {
                                throw null;
                            }
                        }
                        catch (EnumConstantNotPresentException ex) {}
                    }
                    continue Label_0087;
                } while (o == null);
                break;
            }
        }
        throw (Throwable)o;
    }
    
    public void c(final f5h p0, final int p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          1022
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            1014
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            1006
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: dup            
        //    26: ifnonnull       40
        //    29: goto            33
        //    32: athrow         
        //    33: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //    36: goto            40
        //    39: athrow         
        //    40: getstatic       dev/nuker/pyro/fc.c:I
        //    43: ifne            51
        //    46: ldc             -864280064
        //    48: goto            53
        //    51: ldc             137914526
        //    53: ldc             -179094889
        //    55: ixor           
        //    56: lookupswitch {
        //          545779688: 51
        //          959387799: 979
        //          default: 84
        //        }
        //    84: goto            88
        //    87: athrow         
        //    88: invokevirtual   dev/nuker/pyro/f5h.3:()I
        //    91: goto            95
        //    94: athrow         
        //    95: istore_3       
        //    96: aload_1        
        //    97: goto            101
        //   100: athrow         
        //   101: invokevirtual   dev/nuker/pyro/f5h.c:()I
        //   104: goto            108
        //   107: athrow         
        //   108: istore          4
        //   110: iload_3        
        //   111: ifne            130
        //   114: aload_1        
        //   115: iload           4
        //   117: iconst_1       
        //   118: iadd           
        //   119: goto            123
        //   122: athrow         
        //   123: invokevirtual   dev/nuker/pyro/f5h.c:(I)V
        //   126: goto            130
        //   129: athrow         
        //   130: iload_3        
        //   131: ifle            139
        //   134: ldc             -1024041323
        //   136: goto            141
        //   139: ldc             -1024041322
        //   141: ldc             589350848
        //   143: ixor           
        //   144: tableswitch {
        //          -1012059478: 168
        //          -1012059477: 278
        //          default: 134
        //        }
        //   168: iload           4
        //   170: sipush          300
        //   173: if_icmpge       278
        //   176: aload_1        
        //   177: getstatic       dev/nuker/pyro/fc.0:I
        //   180: ifgt            188
        //   183: ldc             188590773
        //   185: goto            190
        //   188: ldc             349640088
        //   190: ldc             799154879
        //   192: ixor           
        //   193: lookupswitch {
        //          614434826: 188
        //          997537575: 220
        //          default: 983
        //        }
        //   220: iload_3        
        //   221: iconst_2       
        //   222: isub           
        //   223: getstatic       dev/nuker/pyro/fc.c:I
        //   226: ifne            234
        //   229: ldc             1677945669
        //   231: goto            236
        //   234: ldc             1530938490
        //   236: ldc             1487714003
        //   238: ixor           
        //   239: lookupswitch {
        //          65860265: 264
        //          1018158486: 234
        //          default: 975
        //        }
        //   264: goto            268
        //   267: athrow         
        //   268: invokevirtual   dev/nuker/pyro/f5h.0:(I)V
        //   271: goto            275
        //   274: athrow         
        //   275: goto            493
        //   278: iload           4
        //   280: sipush          300
        //   283: if_icmplt       493
        //   286: iload_3        
        //   287: i2f            
        //   288: aload_0        
        //   289: goto            293
        //   292: athrow         
        //   293: invokevirtual   dev/nuker/pyro/f5H.5:()F
        //   296: goto            300
        //   299: athrow         
        //   300: fcmpg          
        //   301: ifge            309
        //   304: ldc             -1647302055
        //   306: goto            311
        //   309: ldc             -1647302056
        //   311: ldc             305977153
        //   313: ixor           
        //   314: tableswitch {
        //          534379056: 336
        //          534379057: 398
        //          default: 304
        //        }
        //   336: aload_1        
        //   337: iload_3        
        //   338: iconst_3       
        //   339: iadd           
        //   340: getstatic       dev/nuker/pyro/fc.c:I
        //   343: ifne            351
        //   346: ldc             -316319977
        //   348: goto            353
        //   351: ldc             1520563328
        //   353: ldc             1459426398
        //   355: ixor           
        //   356: lookupswitch {
        //          -1143454903: 351
        //          207413470: 384
        //          default: 985
        //        }
        //   384: goto            388
        //   387: athrow         
        //   388: invokevirtual   dev/nuker/pyro/f5h.0:(I)V
        //   391: goto            395
        //   394: athrow         
        //   395: goto            493
        //   398: aload_1        
        //   399: iload           4
        //   401: iconst_1       
        //   402: iadd           
        //   403: goto            407
        //   406: athrow         
        //   407: invokevirtual   dev/nuker/pyro/f5h.c:(I)V
        //   410: goto            414
        //   413: athrow         
        //   414: getstatic       dev/nuker/pyro/fc.c:I
        //   417: ifne            425
        //   420: ldc             1932531214
        //   422: goto            427
        //   425: ldc             -2017412566
        //   427: ldc             2083890732
        //   429: ixor           
        //   430: lookupswitch {
        //          -951833523: 425
        //          252031010: 991
        //          default: 456
        //        }
        //   456: iload           4
        //   458: sipush          330
        //   461: if_icmplt       493
        //   464: goto            468
        //   467: athrow         
        //   468: invokestatic    dev/nuker/pyro/f5i.c:()Ldev/nuker/pyro/f5i;
        //   471: goto            475
        //   474: athrow         
        //   475: getfield        dev/nuker/pyro/f5i.c:Ljava/util/List;
        //   478: aload_1        
        //   479: goto            483
        //   482: athrow         
        //   483: invokeinterface java/util/List.remove:(Ljava/lang/Object;)Z
        //   488: goto            492
        //   491: athrow         
        //   492: pop            
        //   493: bipush          8
        //   495: istore          5
        //   497: goto            501
        //   500: athrow         
        //   501: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179094_E:()V
        //   504: goto            508
        //   507: athrow         
        //   508: iload_3        
        //   509: i2f            
        //   510: iload_2        
        //   511: i2f            
        //   512: fconst_0       
        //   513: goto            517
        //   516: athrow         
        //   517: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179109_b:(FFF)V
        //   520: goto            524
        //   523: athrow         
        //   524: fconst_0       
        //   525: fconst_0       
        //   526: aload_0        
        //   527: goto            531
        //   530: athrow         
        //   531: invokevirtual   dev/nuker/pyro/f5H.5:()F
        //   534: goto            538
        //   537: athrow         
        //   538: aload_0        
        //   539: getstatic       dev/nuker/pyro/fc.0:I
        //   542: ifgt            550
        //   545: ldc             1852970701
        //   547: goto            552
        //   550: ldc             1796904870
        //   552: ldc             452517937
        //   554: ixor           
        //   555: lookupswitch {
        //          1910667159: 580
        //          1955264252: 550
        //          default: 993
        //        }
        //   580: goto            584
        //   583: athrow         
        //   584: invokevirtual   dev/nuker/pyro/f5H.0:()F
        //   587: goto            591
        //   590: athrow         
        //   591: ldc             -1728053248
        //   593: goto            597
        //   596: athrow         
        //   597: invokestatic    dev/nuker/pyro/fe6.0:(FFFFI)V
        //   600: goto            604
        //   603: athrow         
        //   604: fconst_0       
        //   605: fconst_0       
        //   606: iload           5
        //   608: i2f            
        //   609: aload_0        
        //   610: getstatic       dev/nuker/pyro/fc.0:I
        //   613: ifgt            621
        //   616: ldc             -295528963
        //   618: goto            623
        //   621: ldc             -756544907
        //   623: ldc             260996313
        //   625: ixor           
        //   626: lookupswitch {
        //          -580487508: 652
        //          -504567516: 621
        //          default: 977
        //        }
        //   652: goto            656
        //   655: athrow         
        //   656: invokevirtual   dev/nuker/pyro/f5H.0:()F
        //   659: goto            663
        //   662: athrow         
        //   663: aload_1        
        //   664: goto            668
        //   667: athrow         
        //   668: invokevirtual   dev/nuker/pyro/f5h.1:()I
        //   671: goto            675
        //   674: athrow         
        //   675: getstatic       dev/nuker/pyro/fc.c:I
        //   678: ifne            686
        //   681: ldc             1420578798
        //   683: goto            688
        //   686: ldc             -2045064704
        //   688: ldc             1059683867
        //   690: ixor           
        //   691: lookupswitch {
        //          -1187793893: 716
        //          1803891189: 686
        //          default: 987
        //        }
        //   716: goto            720
        //   719: athrow         
        //   720: invokestatic    dev/nuker/pyro/fe6.0:(FFFFI)V
        //   723: goto            727
        //   726: athrow         
        //   727: goto            731
        //   730: athrow         
        //   731: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179094_E:()V
        //   734: goto            738
        //   737: athrow         
        //   738: ldc2_w          1.1
        //   741: ldc2_w          1.1
        //   744: ldc2_w          1.1
        //   747: goto            751
        //   750: athrow         
        //   751: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179139_a:(DDD)V
        //   754: goto            758
        //   757: athrow         
        //   758: getstatic       dev/nuker/pyro/fc.1:I
        //   761: ifne            769
        //   764: ldc             -553170739
        //   766: goto            771
        //   769: ldc             1170359870
        //   771: ldc             -1501119479
        //   773: ixor           
        //   774: lookupswitch {
        //          -482018761: 800
        //          2038559940: 769
        //          default: 995
        //        }
        //   800: aload_1        
        //   801: goto            805
        //   804: athrow         
        //   805: invokevirtual   dev/nuker/pyro/f5h.2:()Ljava/lang/String;
        //   808: goto            812
        //   811: athrow         
        //   812: getstatic       dev/nuker/pyro/fc.0:I
        //   815: ifgt            823
        //   818: ldc             -1483302771
        //   820: goto            825
        //   823: ldc             -915159643
        //   825: ldc             -531050987
        //   827: ixor           
        //   828: lookupswitch {
        //          -229974233: 823
        //          1204704920: 989
        //          default: 856
        //        }
        //   856: iload           5
        //   858: i2f            
        //   859: iconst_2       
        //   860: i2f            
        //   861: fadd           
        //   862: ldc             4.0
        //   864: iconst_m1      
        //   865: goto            869
        //   868: athrow         
        //   869: invokestatic    dev/nuker/pyro/fe6.1:(Ljava/lang/String;FFI)V
        //   872: goto            876
        //   875: athrow         
        //   876: goto            880
        //   879: athrow         
        //   880: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179121_F:()V
        //   883: goto            887
        //   886: athrow         
        //   887: aload_1        
        //   888: goto            892
        //   891: athrow         
        //   892: invokevirtual   dev/nuker/pyro/f5h.0:()Ljava/lang/String;
        //   895: goto            899
        //   898: athrow         
        //   899: iload           5
        //   901: i2f            
        //   902: iconst_4       
        //   903: i2f            
        //   904: fadd           
        //   905: ldc             18.0
        //   907: iconst_m1      
        //   908: getstatic       dev/nuker/pyro/fc.1:I
        //   911: ifne            919
        //   914: ldc             1446371650
        //   916: goto            921
        //   919: ldc             -438456250
        //   921: ldc             -1885506257
        //   923: ixor           
        //   924: lookupswitch {
        //          -991513302: 919
        //          -643263379: 981
        //          default: 952
        //        }
        //   952: goto            956
        //   955: athrow         
        //   956: invokestatic    dev/nuker/pyro/fe6.1:(Ljava/lang/String;FFI)V
        //   959: goto            963
        //   962: athrow         
        //   963: goto            967
        //   966: athrow         
        //   967: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179121_F:()V
        //   970: goto            974
        //   973: athrow         
        //   974: return         
        //   975: aconst_null    
        //   976: athrow         
        //   977: aconst_null    
        //   978: athrow         
        //   979: aconst_null    
        //   980: athrow         
        //   981: aconst_null    
        //   982: athrow         
        //   983: aconst_null    
        //   984: athrow         
        //   985: aconst_null    
        //   986: athrow         
        //   987: aconst_null    
        //   988: athrow         
        //   989: aconst_null    
        //   990: athrow         
        //   991: aconst_null    
        //   992: athrow         
        //   993: aconst_null    
        //   994: athrow         
        //   995: aconst_null    
        //   996: athrow         
        //   997: pop            
        //   998: goto            24
        //  1001: pop            
        //  1002: aconst_null    
        //  1003: goto            997
        //  1006: dup            
        //  1007: ifnull          997
        //  1010: checkcast       Ljava/lang/Throwable;
        //  1013: athrow         
        //  1014: dup            
        //  1015: ifnull          1001
        //  1018: checkcast       Ljava/lang/Throwable;
        //  1021: athrow         
        //  1022: aconst_null    
        //  1023: athrow         
        //    StackMapTable: 00 A8 43 07 00 15 04 FF 00 0B 00 00 00 01 07 00 15 FE 00 03 07 00 03 07 00 33 01 47 07 00 52 40 07 00 33 45 07 00 15 40 07 00 33 4A 07 00 33 FF 00 01 00 03 07 00 03 07 00 33 01 00 02 07 00 33 01 5E 07 00 33 42 07 00 15 40 07 00 33 45 07 00 15 40 01 FF 00 04 00 00 00 01 07 00 15 FF 00 00 00 04 07 00 03 07 00 33 01 01 00 01 07 00 33 45 07 00 15 40 01 FF 00 0D 00 00 00 01 07 00 15 FF 00 00 00 05 07 00 03 07 00 33 01 01 01 00 02 07 00 33 01 45 07 00 15 00 03 04 41 01 1A 53 07 00 33 FF 00 01 00 05 07 00 03 07 00 33 01 01 01 00 02 07 00 33 01 5D 07 00 33 FF 00 0D 00 05 07 00 03 07 00 33 01 01 01 00 02 07 00 33 01 FF 00 01 00 05 07 00 03 07 00 33 01 01 01 00 03 07 00 33 01 01 FF 00 1B 00 05 07 00 03 07 00 33 01 01 01 00 02 07 00 33 01 42 07 00 15 FF 00 00 00 05 07 00 03 07 00 33 01 01 01 00 02 07 00 33 01 45 07 00 15 00 02 FF 00 0D 00 00 00 01 07 00 15 FF 00 00 00 05 07 00 03 07 00 33 01 01 01 00 02 02 07 00 03 45 07 00 15 FF 00 00 00 05 07 00 03 07 00 33 01 01 01 00 02 02 02 03 04 41 01 18 FF 00 0E 00 05 07 00 03 07 00 33 01 01 01 00 02 07 00 33 01 FF 00 01 00 05 07 00 03 07 00 33 01 01 01 00 03 07 00 33 01 01 FF 00 1E 00 05 07 00 03 07 00 33 01 01 01 00 02 07 00 33 01 42 07 00 15 FF 00 00 00 05 07 00 03 07 00 33 01 01 01 00 02 07 00 33 01 45 07 00 15 00 02 47 07 00 15 FF 00 00 00 05 07 00 03 07 00 33 01 01 01 00 02 07 00 33 01 45 07 00 15 00 0A 41 01 1C 4A 07 00 15 00 45 07 00 15 40 07 00 90 46 07 00 57 FF 00 00 00 05 07 00 03 07 00 33 01 01 01 00 02 07 00 98 07 00 33 47 07 00 15 40 01 00 FF 00 06 00 06 07 00 03 07 00 33 01 01 01 01 00 01 07 00 15 00 45 07 00 15 00 47 07 00 15 FF 00 00 00 06 07 00 03 07 00 33 01 01 01 01 00 03 02 02 02 45 07 00 15 00 45 07 00 5B FF 00 00 00 06 07 00 03 07 00 33 01 01 01 01 00 03 02 02 07 00 03 45 07 00 15 FF 00 00 00 06 07 00 03 07 00 33 01 01 01 01 00 03 02 02 02 FF 00 0B 00 06 07 00 03 07 00 33 01 01 01 01 00 04 02 02 02 07 00 03 FF 00 01 00 06 07 00 03 07 00 33 01 01 01 01 00 05 02 02 02 07 00 03 01 FF 00 1B 00 06 07 00 03 07 00 33 01 01 01 01 00 04 02 02 02 07 00 03 42 07 00 15 FF 00 00 00 06 07 00 03 07 00 33 01 01 01 01 00 04 02 02 02 07 00 03 45 07 00 15 FF 00 00 00 06 07 00 03 07 00 33 01 01 01 01 00 04 02 02 02 02 44 07 00 15 FF 00 00 00 06 07 00 03 07 00 33 01 01 01 01 00 05 02 02 02 02 01 45 07 00 15 00 FF 00 10 00 06 07 00 03 07 00 33 01 01 01 01 00 04 02 02 02 07 00 03 FF 00 01 00 06 07 00 03 07 00 33 01 01 01 01 00 05 02 02 02 07 00 03 01 FF 00 1C 00 06 07 00 03 07 00 33 01 01 01 01 00 04 02 02 02 07 00 03 42 07 00 15 FF 00 00 00 06 07 00 03 07 00 33 01 01 01 01 00 04 02 02 02 07 00 03 45 07 00 15 FF 00 00 00 06 07 00 03 07 00 33 01 01 01 01 00 04 02 02 02 02 43 07 00 15 FF 00 00 00 06 07 00 03 07 00 33 01 01 01 01 00 05 02 02 02 02 07 00 33 45 07 00 15 FF 00 00 00 06 07 00 03 07 00 33 01 01 01 01 00 05 02 02 02 02 01 FF 00 0A 00 06 07 00 03 07 00 33 01 01 01 01 00 05 02 02 02 02 01 FF 00 01 00 06 07 00 03 07 00 33 01 01 01 01 00 06 02 02 02 02 01 01 FF 00 1B 00 06 07 00 03 07 00 33 01 01 01 01 00 05 02 02 02 02 01 42 07 00 15 FF 00 00 00 06 07 00 03 07 00 33 01 01 01 01 00 05 02 02 02 02 01 45 07 00 15 00 42 07 00 15 00 45 07 00 15 00 4B 07 00 15 FF 00 00 00 06 07 00 03 07 00 33 01 01 01 01 00 03 03 03 03 45 07 00 15 00 0A 41 01 1C 43 07 00 15 40 07 00 33 45 07 00 15 40 07 00 38 4A 07 00 38 FF 00 01 00 06 07 00 03 07 00 33 01 01 01 01 00 02 07 00 38 01 5E 07 00 38 4B 07 00 15 FF 00 00 00 06 07 00 03 07 00 33 01 01 01 01 00 04 07 00 38 02 02 01 45 07 00 15 00 42 07 00 15 00 45 07 00 15 00 43 07 00 65 40 07 00 33 45 07 00 15 40 07 00 38 FF 00 13 00 06 07 00 03 07 00 33 01 01 01 01 00 04 07 00 38 02 02 01 FF 00 01 00 06 07 00 03 07 00 33 01 01 01 01 00 05 07 00 38 02 02 01 01 FF 00 1E 00 06 07 00 03 07 00 33 01 01 01 01 00 04 07 00 38 02 02 01 42 07 00 15 FF 00 00 00 06 07 00 03 07 00 33 01 01 01 01 00 04 07 00 38 02 02 01 45 07 00 15 00 FF 00 02 00 00 00 01 07 00 15 FF 00 00 00 06 07 00 03 07 00 33 01 01 01 01 00 00 45 07 00 15 00 FF 00 00 00 05 07 00 03 07 00 33 01 01 01 00 02 07 00 33 01 FF 00 01 00 06 07 00 03 07 00 33 01 01 01 01 00 04 02 02 02 07 00 03 FF 00 01 00 03 07 00 03 07 00 33 01 00 01 07 00 33 FF 00 01 00 06 07 00 03 07 00 33 01 01 01 01 00 04 07 00 38 02 02 01 FF 00 01 00 05 07 00 03 07 00 33 01 01 01 00 01 07 00 33 FF 00 01 00 05 07 00 03 07 00 33 01 01 01 00 02 07 00 33 01 FF 00 01 00 06 07 00 03 07 00 33 01 01 01 01 00 05 02 02 02 02 01 41 07 00 38 FA 00 01 FF 00 01 00 06 07 00 03 07 00 33 01 01 01 01 00 04 02 02 02 07 00 03 01 FF 00 01 00 03 07 00 03 07 00 33 01 00 01 07 00 15 43 05 44 07 00 15 47 05 47 07 00 15
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     1006   1014   Any
        //  1006   1014   1006   1014   Any
        //  1022   1024   3      8      Any
        //  32     39     39     40     Any
        //  32     39     3      8      Ljava/lang/IllegalArgumentException;
        //  33     39     32     33     Ljava/lang/RuntimeException;
        //  33     39     39     40     Any
        //  32     39     3      8      Ljava/util/ConcurrentModificationException;
        //  87     94     94     95     Any
        //  87     94     87     88     Ljava/util/NoSuchElementException;
        //  88     94     87     88     Any
        //  88     94     3      8      Any
        //  88     94     94     95     Any
        //  101    107    107    108    Any
        //  101    107    107    108    Any
        //  101    107    107    108    Ljava/util/NoSuchElementException;
        //  101    107    107    108    Ljava/lang/ClassCastException;
        //  101    107    3      8      Any
        //  123    129    129    130    Any
        //  123    129    129    130    Any
        //  123    129    129    130    Any
        //  123    129    129    130    Ljava/lang/NumberFormatException;
        //  123    129    129    130    Ljava/util/ConcurrentModificationException;
        //  267    274    274    275    Any
        //  267    274    267    268    Ljava/util/ConcurrentModificationException;
        //  267    274    3      8      Any
        //  268    274    3      8      Any
        //  268    274    267    268    Any
        //  293    299    299    300    Any
        //  293    299    3      8      Any
        //  293    299    299    300    Any
        //  293    299    3      8      Any
        //  293    299    299    300    Ljava/lang/RuntimeException;
        //  387    394    394    395    Any
        //  387    394    394    395    Ljava/lang/RuntimeException;
        //  387    394    394    395    Ljava/lang/EnumConstantNotPresentException;
        //  388    394    387    388    Any
        //  387    394    3      8      Ljava/util/ConcurrentModificationException;
        //  406    413    413    414    Any
        //  406    413    406    407    Any
        //  407    413    406    407    Any
        //  406    413    3      8      Ljava/util/NoSuchElementException;
        //  407    413    413    414    Ljava/lang/UnsupportedOperationException;
        //  467    474    474    475    Any
        //  467    474    467    468    Ljava/lang/IndexOutOfBoundsException;
        //  468    474    467    468    Any
        //  467    474    467    468    Any
        //  468    474    474    475    Any
        //  482    491    491    492    Any
        //  483    491    482    483    Ljava/util/ConcurrentModificationException;
        //  483    491    3      8      Any
        //  482    491    3      8      Any
        //  483    491    491    492    Any
        //  500    507    507    508    Any
        //  501    507    3      8      Any
        //  500    507    500    501    Any
        //  500    507    3      8      Any
        //  500    507    507    508    Ljava/util/ConcurrentModificationException;
        //  516    523    523    524    Any
        //  516    523    516    517    Any
        //  516    523    3      8      Ljava/lang/IllegalArgumentException;
        //  517    523    516    517    Ljava/lang/NullPointerException;
        //  517    523    516    517    Any
        //  530    537    537    538    Any
        //  530    537    537    538    Ljava/lang/AssertionError;
        //  530    537    530    531    Ljava/lang/ClassCastException;
        //  531    537    537    538    Ljava/lang/ArithmeticException;
        //  531    537    3      8      Any
        //  583    590    590    591    Any
        //  584    590    583    584    Ljava/lang/AssertionError;
        //  583    590    590    591    Any
        //  584    590    583    584    Any
        //  584    590    590    591    Ljava/lang/ClassCastException;
        //  596    603    603    604    Any
        //  597    603    596    597    Ljava/util/NoSuchElementException;
        //  596    603    3      8      Any
        //  597    603    596    597    Any
        //  597    603    3      8      Any
        //  655    662    662    663    Any
        //  656    662    655    656    Ljava/lang/IllegalArgumentException;
        //  655    662    655    656    Any
        //  655    662    655    656    Ljava/lang/IllegalArgumentException;
        //  655    662    662    663    Ljava/lang/IndexOutOfBoundsException;
        //  667    674    674    675    Any
        //  667    674    674    675    Ljava/lang/NumberFormatException;
        //  667    674    674    675    Ljava/lang/UnsupportedOperationException;
        //  668    674    3      8      Any
        //  668    674    667    668    Any
        //  719    726    726    727    Any
        //  720    726    719    720    Ljava/lang/NumberFormatException;
        //  720    726    726    727    Ljava/lang/IllegalArgumentException;
        //  719    726    719    720    Ljava/lang/NumberFormatException;
        //  719    726    719    720    Any
        //  730    737    737    738    Any
        //  730    737    730    731    Any
        //  730    737    730    731    Ljava/lang/ArithmeticException;
        //  731    737    730    731    Ljava/util/ConcurrentModificationException;
        //  730    737    730    731    Ljava/lang/IllegalStateException;
        //  750    757    757    758    Any
        //  750    757    757    758    Ljava/lang/UnsupportedOperationException;
        //  750    757    757    758    Any
        //  751    757    757    758    Any
        //  751    757    750    751    Any
        //  804    811    811    812    Any
        //  804    811    811    812    Ljava/lang/NumberFormatException;
        //  804    811    3      8      Ljava/lang/ClassCastException;
        //  804    811    804    805    Any
        //  805    811    811    812    Any
        //  868    875    875    876    Any
        //  868    875    3      8      Ljava/lang/NegativeArraySizeException;
        //  868    875    868    869    Ljava/lang/UnsupportedOperationException;
        //  869    875    868    869    Any
        //  868    875    868    869    Any
        //  879    886    886    887    Any
        //  880    886    886    887    Any
        //  880    886    879    880    Ljava/lang/StringIndexOutOfBoundsException;
        //  879    886    879    880    Any
        //  879    886    879    880    Ljava/lang/NegativeArraySizeException;
        //  891    898    898    899    Any
        //  892    898    3      8      Ljava/lang/AssertionError;
        //  892    898    898    899    Any
        //  891    898    3      8      Any
        //  891    898    891    892    Ljava/lang/ArithmeticException;
        //  955    962    962    963    Any
        //  956    962    955    956    Ljava/lang/NegativeArraySizeException;
        //  955    962    3      8      Any
        //  956    962    962    963    Ljava/lang/IllegalArgumentException;
        //  955    962    955    956    Any
        //  967    973    973    974    Any
        //  967    973    3      8      Ljava/lang/IllegalStateException;
        //  967    973    3      8      Any
        //  967    973    3      8      Any
        //  967    973    973    974    Ljava/lang/NumberFormatException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:776)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void c(@Nullable final f5t p0, final int p1, @Nullable final ScaledResolution p2, final float p3, final float p4) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          1184
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            1176
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            1168
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //    27: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //    30: ifnull          42
        //    33: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //    36: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //    39: ifnonnull       112
        //    42: getstatic       dev/nuker/pyro/fc.1:I
        //    45: ifne            53
        //    48: ldc             338824693
        //    50: goto            55
        //    53: ldc             1333455435
        //    55: ldc             1931550388
        //    57: ixor           
        //    58: lookupswitch {
        //          1012659455: 84
        //          1729303361: 53
        //          default: 1151
        //        }
        //    84: goto            88
        //    87: athrow         
        //    88: invokestatic    dev/nuker/pyro/f5i.c:()Ldev/nuker/pyro/f5i;
        //    91: goto            95
        //    94: athrow         
        //    95: getfield        dev/nuker/pyro/f5i.c:Ljava/util/List;
        //    98: goto            102
        //   101: athrow         
        //   102: invokeinterface java/util/List.clear:()V
        //   107: goto            111
        //   110: athrow         
        //   111: return         
        //   112: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //   115: getfield        net/minecraft/client/Minecraft.field_71462_r:Lnet/minecraft/client/gui/GuiScreen;
        //   118: instanceof      Ldev/nuker/pyro/f5j;
        //   121: ifeq            129
        //   124: ldc             -265371800
        //   126: goto            131
        //   129: ldc             -265371799
        //   131: ldc             -66316690
        //   133: ixor           
        //   134: tableswitch {
        //          407196172: 156
        //          407196173: 552
        //          default: 124
        //        }
        //   156: fconst_0       
        //   157: fconst_0       
        //   158: aload_0        
        //   159: goto            163
        //   162: athrow         
        //   163: invokevirtual   dev/nuker/pyro/f5H.5:()F
        //   166: goto            170
        //   169: athrow         
        //   170: getstatic       dev/nuker/pyro/fc.c:I
        //   173: ifne            181
        //   176: ldc             2096773289
        //   178: goto            183
        //   181: ldc             225271883
        //   183: ldc             1653600679
        //   185: ixor           
        //   186: lookupswitch {
        //          -2041600634: 181
        //          511035662: 1155
        //          default: 212
        //        }
        //   212: aload_0        
        //   213: getstatic       dev/nuker/pyro/fc.1:I
        //   216: ifne            224
        //   219: ldc             -590227582
        //   221: goto            226
        //   224: ldc             -1914974924
        //   226: ldc             -1197416126
        //   228: ixor           
        //   229: lookupswitch {
        //          -1672622057: 224
        //          1685141184: 1147
        //          default: 256
        //        }
        //   256: goto            260
        //   259: athrow         
        //   260: invokevirtual   dev/nuker/pyro/f5H.0:()F
        //   263: goto            267
        //   266: athrow         
        //   267: ldc             -1728053248
        //   269: goto            273
        //   272: athrow         
        //   273: invokestatic    dev/nuker/pyro/fe6.0:(FFFFI)V
        //   276: goto            280
        //   279: athrow         
        //   280: fconst_0       
        //   281: fconst_0       
        //   282: ldc             8.0
        //   284: aload_0        
        //   285: goto            289
        //   288: athrow         
        //   289: invokevirtual   dev/nuker/pyro/f5H.0:()F
        //   292: goto            296
        //   295: athrow         
        //   296: ldc             -1234904
        //   298: getstatic       dev/nuker/pyro/fc.1:I
        //   301: ifne            310
        //   304: ldc_w           -1081917572
        //   307: goto            313
        //   310: ldc_w           441103183
        //   313: ldc_w           -1329924180
        //   316: ixor           
        //   317: lookupswitch {
        //          -1427094301: 344
        //          255445200: 310
        //          default: 1133
        //        }
        //   344: goto            348
        //   347: athrow         
        //   348: invokestatic    dev/nuker/pyro/fe6.0:(FFFFI)V
        //   351: goto            355
        //   354: athrow         
        //   355: goto            359
        //   358: athrow         
        //   359: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179094_E:()V
        //   362: goto            366
        //   365: athrow         
        //   366: ldc2_w          1.1
        //   369: ldc2_w          1.1
        //   372: ldc2_w          1.1
        //   375: goto            379
        //   378: athrow         
        //   379: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179139_a:(DDD)V
        //   382: goto            386
        //   385: athrow         
        //   386: ldc_w           "\u3d54\ub24a\u8e2c\uafbc\u613c\u5996\u7e43\u692e\uc0c6\ua5d5\u9bcc\u130a\uc15d"
        //   389: goto            393
        //   392: athrow         
        //   393: invokestatic    invokestatic   !!! ERROR
        //   396: goto            400
        //   399: athrow         
        //   400: ldc_w           10.0
        //   403: ldc             4.0
        //   405: iconst_m1      
        //   406: goto            410
        //   409: athrow         
        //   410: invokestatic    dev/nuker/pyro/fe6.1:(Ljava/lang/String;FFI)V
        //   413: goto            417
        //   416: athrow         
        //   417: getstatic       dev/nuker/pyro/fc.c:I
        //   420: ifne            429
        //   423: ldc_w           -2136284567
        //   426: goto            432
        //   429: ldc_w           -411543461
        //   432: ldc_w           1975105216
        //   435: ixor           
        //   436: lookupswitch {
        //          -1832784229: 464
        //          -183282519: 429
        //          default: 1145
        //        }
        //   464: goto            468
        //   467: athrow         
        //   468: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179121_F:()V
        //   471: goto            475
        //   474: athrow         
        //   475: ldc_w           "\u3d4e\ub24d\u8e31\uafa6\u617a\u5996\u7e53\u696f\uc0d3\ua5d2\u9b83\u1301\uc156\u731e\u96e6\u4d87\ub21d\u4ca1\u0312"
        //   478: goto            482
        //   481: athrow         
        //   482: invokestatic    invokestatic   !!! ERROR
        //   485: goto            489
        //   488: athrow         
        //   489: ldc_w           12.0
        //   492: ldc             18.0
        //   494: iconst_m1      
        //   495: getstatic       dev/nuker/pyro/fc.0:I
        //   498: ifgt            507
        //   501: ldc_w           1781192759
        //   504: goto            510
        //   507: ldc_w           1158154288
        //   510: ldc_w           715616589
        //   513: ixor           
        //   514: lookupswitch {
        //          -71622125: 507
        //          1083025786: 1139
        //          default: 540
        //        }
        //   540: goto            544
        //   543: athrow         
        //   544: invokestatic    dev/nuker/pyro/fe6.1:(Ljava/lang/String;FFI)V
        //   547: goto            551
        //   550: athrow         
        //   551: return         
        //   552: iconst_0       
        //   553: istore          6
        //   555: aload_0        
        //   556: getfield        dev/nuker/pyro/f5H.c:[Ldev/nuker/pyro/f5h;
        //   559: arraylength    
        //   560: istore          7
        //   562: iload           6
        //   564: getstatic       dev/nuker/pyro/fc.1:I
        //   567: ifne            576
        //   570: ldc_w           78385444
        //   573: goto            579
        //   576: ldc_w           1049527406
        //   579: ldc_w           -1000174417
        //   582: ixor           
        //   583: lookupswitch {
        //          -1060201077: 1149
        //          1672822735: 576
        //          default: 608
        //        }
        //   608: iload           7
        //   610: if_icmpge       619
        //   613: ldc_w           -55098249
        //   616: goto            622
        //   619: ldc_w           -55098250
        //   622: ldc_w           -1921487697
        //   625: ixor           
        //   626: tableswitch {
        //          -476163664: 648
        //          -476163663: 1132
        //          default: 613
        //        }
        //   648: goto            652
        //   651: athrow         
        //   652: invokestatic    dev/nuker/pyro/f5i.c:()Ldev/nuker/pyro/f5i;
        //   655: goto            659
        //   658: athrow         
        //   659: getfield        dev/nuker/pyro/f5i.c:Ljava/util/List;
        //   662: goto            666
        //   665: athrow         
        //   666: invokeinterface java/util/List.size:()I
        //   671: goto            675
        //   674: athrow         
        //   675: iload           6
        //   677: iconst_1       
        //   678: iadd           
        //   679: if_icmpge       685
        //   682: goto            1126
        //   685: getstatic       dev/nuker/pyro/fc.1:I
        //   688: ifne            697
        //   691: ldc_w           -1033504300
        //   694: goto            700
        //   697: ldc_w           842996962
        //   700: ldc_w           1521603009
        //   703: ixor           
        //   704: lookupswitch {
        //          -1730926571: 697
        //          1754189091: 732
        //          default: 1143
        //        }
        //   732: goto            736
        //   735: athrow         
        //   736: invokestatic    dev/nuker/pyro/f5i.c:()Ldev/nuker/pyro/f5i;
        //   739: goto            743
        //   742: athrow         
        //   743: getstatic       dev/nuker/pyro/fc.c:I
        //   746: ifne            755
        //   749: ldc_w           -687407546
        //   752: goto            758
        //   755: ldc_w           -1995807344
        //   758: ldc_w           -2142375169
        //   761: ixor           
        //   762: lookupswitch {
        //          31171533: 755
        //          1464536249: 1153
        //          default: 788
        //        }
        //   788: getfield        dev/nuker/pyro/f5i.c:Ljava/util/List;
        //   791: goto            795
        //   794: athrow         
        //   795: invokeinterface java/util/List.size:()I
        //   800: goto            804
        //   803: athrow         
        //   804: iload           6
        //   806: iconst_1       
        //   807: iadd           
        //   808: if_icmplt       817
        //   811: ldc_w           -203879154
        //   814: goto            820
        //   817: ldc_w           -203879167
        //   820: ldc_w           20250169
        //   823: ixor           
        //   824: tableswitch {
        //          -438573458: 848
        //          -438573457: 1069
        //          default: 811
        //        }
        //   848: getstatic       dev/nuker/pyro/fc.1:I
        //   851: ifne            860
        //   854: ldc_w           -1064958664
        //   857: goto            863
        //   860: ldc_w           311313248
        //   863: ldc_w           680511186
        //   866: ixor           
        //   867: lookupswitch {
        //          -402013206: 1157
        //          1680674284: 860
        //          default: 892
        //        }
        //   892: aload_0        
        //   893: getstatic       dev/nuker/pyro/fc.c:I
        //   896: ifne            905
        //   899: ldc_w           -1580525175
        //   902: goto            908
        //   905: ldc_w           945047385
        //   908: ldc_w           -1575702844
        //   911: ixor           
        //   912: lookupswitch {
        //          -204241399: 905
        //          64993101: 1135
        //          default: 940
        //        }
        //   940: getfield        dev/nuker/pyro/f5H.c:[Ldev/nuker/pyro/f5h;
        //   943: iload           6
        //   945: goto            949
        //   948: athrow         
        //   949: invokestatic    dev/nuker/pyro/f5i.c:()Ldev/nuker/pyro/f5i;
        //   952: goto            956
        //   955: athrow         
        //   956: getstatic       dev/nuker/pyro/fc.c:I
        //   959: ifne            968
        //   962: ldc_w           -1519403339
        //   965: goto            971
        //   968: ldc_w           1390456710
        //   971: ldc_w           -2003830708
        //   974: ixor           
        //   975: lookupswitch {
        //          -630237238: 1000
        //          769672953: 968
        //          default: 1137
        //        }
        //  1000: getfield        dev/nuker/pyro/f5i.c:Ljava/util/List;
        //  1003: iload           6
        //  1005: getstatic       dev/nuker/pyro/fc.0:I
        //  1008: ifgt            1017
        //  1011: ldc_w           -5104277
        //  1014: goto            1020
        //  1017: ldc_w           -1423169398
        //  1020: ldc_w           1221509460
        //  1023: ixor           
        //  1024: lookupswitch {
        //          -1216553921: 1141
        //          -93164640: 1017
        //          default: 1052
        //        }
        //  1052: goto            1056
        //  1055: athrow         
        //  1056: invokeinterface java/util/List.get:(I)Ljava/lang/Object;
        //  1061: goto            1065
        //  1064: athrow         
        //  1065: checkcast       Ldev/nuker/pyro/f5h;
        //  1068: aastore        
        //  1069: aload_0        
        //  1070: goto            1074
        //  1073: athrow         
        //  1074: invokevirtual   dev/nuker/pyro/f5H.0:()F
        //  1077: goto            1081
        //  1080: athrow         
        //  1081: iload           6
        //  1083: i2f            
        //  1084: fmul           
        //  1085: bipush          6
        //  1087: iload           6
        //  1089: imul           
        //  1090: i2f            
        //  1091: fadd           
        //  1092: f2i            
        //  1093: istore          8
        //  1095: aload_0        
        //  1096: getfield        dev/nuker/pyro/f5H.c:[Ldev/nuker/pyro/f5h;
        //  1099: iload           6
        //  1101: aaload         
        //  1102: ifnull          1126
        //  1105: aload_0        
        //  1106: aload_0        
        //  1107: getfield        dev/nuker/pyro/f5H.c:[Ldev/nuker/pyro/f5h;
        //  1110: iload           6
        //  1112: aaload         
        //  1113: iload           8
        //  1115: goto            1119
        //  1118: athrow         
        //  1119: invokespecial   dev/nuker/pyro/f5H.c:(Ldev/nuker/pyro/f5h;I)V
        //  1122: goto            1126
        //  1125: athrow         
        //  1126: iinc            6, 1
        //  1129: goto            562
        //  1132: return         
        //  1133: aconst_null    
        //  1134: athrow         
        //  1135: aconst_null    
        //  1136: athrow         
        //  1137: aconst_null    
        //  1138: athrow         
        //  1139: aconst_null    
        //  1140: athrow         
        //  1141: aconst_null    
        //  1142: athrow         
        //  1143: aconst_null    
        //  1144: athrow         
        //  1145: aconst_null    
        //  1146: athrow         
        //  1147: aconst_null    
        //  1148: athrow         
        //  1149: aconst_null    
        //  1150: athrow         
        //  1151: aconst_null    
        //  1152: athrow         
        //  1153: aconst_null    
        //  1154: athrow         
        //  1155: aconst_null    
        //  1156: athrow         
        //  1157: aconst_null    
        //  1158: athrow         
        //  1159: pop            
        //  1160: goto            24
        //  1163: pop            
        //  1164: aconst_null    
        //  1165: goto            1159
        //  1168: dup            
        //  1169: ifnull          1159
        //  1172: checkcast       Ljava/lang/Throwable;
        //  1175: athrow         
        //  1176: dup            
        //  1177: ifnull          1163
        //  1180: checkcast       Ljava/lang/Throwable;
        //  1183: athrow         
        //  1184: aconst_null    
        //  1185: athrow         
        //    StackMapTable: 00 A8 43 07 00 15 04 FF 00 0B 00 00 00 01 07 00 15 FF 00 03 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 00 11 0A 41 01 1C 42 07 00 61 00 45 07 00 15 40 07 00 90 45 07 00 5D 40 07 00 98 47 07 00 15 00 00 0B 04 41 01 18 45 07 00 5F FF 00 00 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 03 02 02 07 00 03 45 07 00 15 FF 00 00 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 03 02 02 02 FF 00 0A 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 03 02 02 02 FF 00 01 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 04 02 02 02 01 FF 00 1C 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 03 02 02 02 FF 00 0B 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 04 02 02 02 07 00 03 FF 00 01 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 05 02 02 02 07 00 03 01 FF 00 1D 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 04 02 02 02 07 00 03 42 07 00 15 FF 00 00 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 04 02 02 02 07 00 03 45 07 00 15 FF 00 00 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 04 02 02 02 02 FF 00 04 00 00 00 01 07 00 15 FF 00 00 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 05 02 02 02 02 01 45 07 00 15 00 47 07 00 67 FF 00 00 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 04 02 02 02 07 00 03 45 07 00 15 FF 00 00 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 04 02 02 02 02 FF 00 0D 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 05 02 02 02 02 01 FF 00 02 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 06 02 02 02 02 01 01 FF 00 1E 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 05 02 02 02 02 01 42 07 00 15 FF 00 00 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 05 02 02 02 02 01 45 07 00 15 00 42 07 00 63 00 45 07 00 15 00 FF 00 0B 00 00 00 01 07 00 15 FF 00 00 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 03 03 03 03 45 07 00 15 00 45 07 00 15 40 07 00 38 45 07 00 15 40 07 00 38 48 07 00 5F FF 00 00 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 04 07 00 38 02 02 01 45 07 00 15 00 0B 42 01 1F 42 07 00 4B 00 45 07 00 15 00 45 07 00 15 40 07 00 38 45 07 00 15 40 07 00 38 FF 00 11 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 04 07 00 38 02 02 01 FF 00 02 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 05 07 00 38 02 02 01 01 FF 00 1D 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 04 07 00 38 02 02 01 42 07 00 15 FF 00 00 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 04 07 00 38 02 02 01 45 07 00 15 00 00 FD 00 09 01 01 4D 01 FF 00 02 00 08 07 00 03 07 01 34 01 07 01 36 02 02 01 01 00 02 01 01 5C 01 04 05 42 01 19 42 07 00 15 00 45 07 00 15 40 07 00 90 45 07 00 15 40 07 00 98 47 07 00 15 40 01 09 0B 42 01 1F 42 07 00 5B 00 45 07 00 15 40 07 00 90 4B 07 00 90 FF 00 02 00 08 07 00 03 07 01 34 01 07 01 36 02 02 01 01 00 02 07 00 90 01 5D 07 00 90 45 07 00 15 40 07 00 98 47 07 00 15 40 01 06 05 42 01 1B 0B 42 01 1C 4C 07 00 03 FF 00 02 00 08 07 00 03 07 01 34 01 07 01 36 02 02 01 01 00 02 07 00 03 01 5F 07 00 03 47 07 00 15 FF 00 00 00 08 07 00 03 07 01 34 01 07 01 36 02 02 01 01 00 02 07 00 39 01 45 07 00 15 FF 00 00 00 08 07 00 03 07 01 34 01 07 01 36 02 02 01 01 00 03 07 00 39 01 07 00 90 FF 00 0B 00 08 07 00 03 07 01 34 01 07 01 36 02 02 01 01 00 03 07 00 39 01 07 00 90 FF 00 02 00 08 07 00 03 07 01 34 01 07 01 36 02 02 01 01 00 04 07 00 39 01 07 00 90 01 FF 00 1C 00 08 07 00 03 07 01 34 01 07 01 36 02 02 01 01 00 03 07 00 39 01 07 00 90 FF 00 10 00 08 07 00 03 07 01 34 01 07 01 36 02 02 01 01 00 04 07 00 39 01 07 00 98 01 FF 00 02 00 08 07 00 03 07 01 34 01 07 01 36 02 02 01 01 00 05 07 00 39 01 07 00 98 01 01 FF 00 1F 00 08 07 00 03 07 01 34 01 07 01 36 02 02 01 01 00 04 07 00 39 01 07 00 98 01 42 07 00 15 FF 00 00 00 08 07 00 03 07 01 34 01 07 01 36 02 02 01 01 00 04 07 00 39 01 07 00 98 01 47 07 00 15 FF 00 00 00 08 07 00 03 07 01 34 01 07 01 36 02 02 01 01 00 03 07 00 39 01 07 01 38 03 43 07 00 61 40 07 00 03 45 07 00 15 40 02 FF 00 24 00 09 07 00 03 07 01 34 01 07 01 36 02 02 01 01 01 00 01 07 00 49 FF 00 00 00 09 07 00 03 07 01 34 01 07 01 36 02 02 01 01 01 00 03 07 00 03 07 00 33 01 45 07 00 15 FA 00 00 05 FF 00 00 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 05 02 02 02 02 01 FF 00 01 00 08 07 00 03 07 01 34 01 07 01 36 02 02 01 01 00 01 07 00 03 FF 00 01 00 08 07 00 03 07 01 34 01 07 01 36 02 02 01 01 00 03 07 00 39 01 07 00 90 FF 00 01 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 04 07 00 38 02 02 01 FF 00 01 00 08 07 00 03 07 01 34 01 07 01 36 02 02 01 01 00 04 07 00 39 01 07 00 98 01 01 F9 00 01 FF 00 01 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 04 02 02 02 07 00 03 FF 00 01 00 08 07 00 03 07 01 34 01 07 01 36 02 02 01 01 00 01 01 F9 00 01 FF 00 01 00 08 07 00 03 07 01 34 01 07 01 36 02 02 01 01 00 01 07 00 90 FF 00 01 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 03 02 02 02 FD 00 01 01 01 FF 00 01 00 06 07 00 03 07 01 34 01 07 01 36 02 02 00 01 07 00 52 43 05 44 07 00 52 47 05 47 07 00 15
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     1168   1176   Ljava/util/NoSuchElementException;
        //  1168   1176   1168   1176   Ljava/lang/NegativeArraySizeException;
        //  1184   1186   3      8      Ljava/lang/ArithmeticException;
        //  87     94     94     95     Any
        //  88     94     94     95     Any
        //  88     94     87     88     Ljava/lang/IndexOutOfBoundsException;
        //  87     94     94     95     Ljava/lang/NegativeArraySizeException;
        //  87     94     94     95     Any
        //  101    110    110    111    Any
        //  102    110    110    111    Any
        //  101    110    3      8      Any
        //  101    110    3      8      Ljava/lang/NullPointerException;
        //  101    110    101    102    Ljava/lang/NumberFormatException;
        //  162    169    169    170    Any
        //  162    169    3      8      Ljava/lang/NullPointerException;
        //  163    169    162    163    Ljava/lang/UnsupportedOperationException;
        //  163    169    169    170    Ljava/lang/EnumConstantNotPresentException;
        //  162    169    169    170    Any
        //  259    266    266    267    Any
        //  259    266    3      8      Ljava/lang/AssertionError;
        //  260    266    259    260    Any
        //  259    266    259    260    Ljava/lang/EnumConstantNotPresentException;
        //  260    266    3      8      Any
        //  273    279    279    280    Any
        //  273    279    279    280    Any
        //  273    279    3      8      Ljava/lang/NegativeArraySizeException;
        //  273    279    279    280    Ljava/lang/AssertionError;
        //  273    279    279    280    Ljava/lang/RuntimeException;
        //  288    295    295    296    Any
        //  288    295    295    296    Any
        //  288    295    3      8      Ljava/lang/RuntimeException;
        //  288    295    3      8      Any
        //  288    295    288    289    Ljava/lang/IllegalStateException;
        //  347    354    354    355    Any
        //  347    354    354    355    Ljava/lang/ClassCastException;
        //  348    354    354    355    Any
        //  348    354    347    348    Any
        //  348    354    354    355    Any
        //  358    365    365    366    Any
        //  358    365    3      8      Any
        //  358    365    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  359    365    365    366    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  358    365    358    359    Ljava/lang/NullPointerException;
        //  379    385    385    386    Any
        //  379    385    3      8      Any
        //  379    385    385    386    Ljava/lang/RuntimeException;
        //  379    385    3      8      Any
        //  379    385    385    386    Any
        //  392    399    399    400    Any
        //  393    399    399    400    Ljava/lang/ArithmeticException;
        //  392    399    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  392    399    392    393    Any
        //  392    399    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  409    416    416    417    Any
        //  410    416    416    417    Any
        //  410    416    416    417    Any
        //  410    416    409    410    Ljava/lang/UnsupportedOperationException;
        //  410    416    3      8      Ljava/lang/ClassCastException;
        //  467    474    474    475    Any
        //  468    474    467    468    Ljava/lang/NegativeArraySizeException;
        //  467    474    3      8      Ljava/lang/ClassCastException;
        //  468    474    3      8      Any
        //  467    474    3      8      Ljava/lang/NullPointerException;
        //  481    488    488    489    Any
        //  481    488    3      8      Any
        //  481    488    481    482    Any
        //  482    488    481    482    Any
        //  482    488    488    489    Any
        //  543    550    550    551    Any
        //  543    550    543    544    Ljava/lang/NegativeArraySizeException;
        //  543    550    543    544    Any
        //  543    550    543    544    Ljava/lang/IllegalStateException;
        //  544    550    550    551    Any
        //  651    658    658    659    Any
        //  652    658    651    652    Ljava/util/NoSuchElementException;
        //  652    658    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  651    658    651    652    Any
        //  652    658    658    659    Any
        //  665    674    674    675    Any
        //  666    674    665    666    Any
        //  666    674    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  665    674    3      8      Ljava/util/ConcurrentModificationException;
        //  666    674    3      8      Any
        //  735    742    742    743    Any
        //  735    742    735    736    Ljava/lang/ClassCastException;
        //  736    742    3      8      Any
        //  735    742    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  736    742    742    743    Any
        //  794    803    803    804    Any
        //  794    803    803    804    Ljava/lang/NullPointerException;
        //  795    803    794    795    Ljava/lang/NullPointerException;
        //  794    803    803    804    Any
        //  795    803    794    795    Any
        //  948    955    955    956    Any
        //  949    955    948    949    Any
        //  949    955    955    956    Ljava/lang/NumberFormatException;
        //  948    955    955    956    Any
        //  949    955    948    949    Any
        //  1055   1064   1064   1065   Any
        //  1056   1064   1055   1056   Ljava/lang/IllegalArgumentException;
        //  1056   1064   1055   1056   Any
        //  1055   1064   1064   1065   Any
        //  1056   1064   3      8      Any
        //  1073   1080   1080   1081   Any
        //  1074   1080   1080   1081   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1074   1080   1073   1074   Ljava/lang/IndexOutOfBoundsException;
        //  1073   1080   3      8      Any
        //  1074   1080   1080   1081   Ljava/lang/RuntimeException;
        //  1118   1125   1125   1126   Any
        //  1119   1125   1125   1126   Ljava/lang/StringIndexOutOfBoundsException;
        //  1119   1125   3      8      Any
        //  1119   1125   1118   1119   Ljava/lang/EnumConstantNotPresentException;
        //  1118   1125   1125   1126   Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:600)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
