// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

public class fel
{
    public int c;
    public long c;
    public boolean c;
    
    public void finalize() {
        fez.gE(this, 670380562);
    }
    
    static {
        throw t;
    }
    
    public void c(final boolean b) {
        fez.36(this, 1574756022, b);
    }
    
    public void c(final long n) {
        fez.3N(this, 673323046, n);
    }
    
    public fel(final int c, final long c2, final boolean c3) {
        this.c = false;
        while (true) {
            int n = 0;
            Label_0022: {
                if (fc.1 == 0) {
                    n = -1055742886;
                    break Label_0022;
                }
                n = 1724755843;
            }
            switch (n ^ 0x91B9CCAB) {
                case 591876899: {
                    continue;
                }
                default: {
                    while (true) {
                        int n2 = 0;
                        Label_0067: {
                            if (fc.1 == 0) {
                                n2 = 1198867008;
                                break Label_0067;
                            }
                            n2 = 111188850;
                        }
                        switch (n2 ^ 0x3221F849) {
                            case -505072257: {
                                continue;
                            }
                            default: {
                                this.c = c;
                                while (true) {
                                    int n3 = 0;
                                    Label_0114: {
                                        if (fc.c == 0) {
                                            n3 = 11169453;
                                            break Label_0114;
                                        }
                                        n3 = 304645467;
                                    }
                                    switch (n3 ^ 0xFF30B78E) {
                                        case -210051401: {
                                            continue;
                                        }
                                        default: {
                                            this.c = c2;
                                            while (true) {
                                                int n4 = 0;
                                                Label_0160: {
                                                    if (fc.1 == 0) {
                                                        n4 = 581996502;
                                                        break Label_0160;
                                                    }
                                                    n4 = -1801882048;
                                                }
                                                switch (n4 ^ 0xA90E5EB5) {
                                                    case -1152768388: {
                                                        continue;
                                                    }
                                                    default: {
                                                        this.c = c3;
                                                        return;
                                                    }
                                                    case -1950428829: {
                                                        throw null;
                                                    }
                                                }
                                                break;
                                            }
                                            break;
                                        }
                                        case -6629085: {
                                            throw null;
                                        }
                                    }
                                    break;
                                }
                                break;
                            }
                            case 1968486921: {
                                throw null;
                            }
                        }
                        break;
                    }
                    break;
                }
                case 1353410801: {
                    throw null;
                }
            }
            break;
        }
    }
    
    public int c() {
        return fez.fB(this, 364788486);
    }
    
    public fel(final int c, final long c2) {
        while (true) {
            int n = 0;
            Label_0013: {
                if (fc.0 <= 0) {
                    n = -2028744779;
                    break Label_0013;
                }
                n = 233974645;
            }
            switch (n ^ 0x28F64C77) {
                case -1343913022: {
                    continue;
                }
                case 621045506: {
                    while (true) {
                        int n2 = 0;
                        Label_0061: {
                            if (fc.c == 0) {
                                n2 = -615325369;
                                break Label_0061;
                            }
                            n2 = -1147274726;
                        }
                        switch (n2 ^ 0x805F4D7C) {
                            case 1527622715: {
                                continue;
                            }
                            case 1002616678: {
                                this.c = false;
                                while (true) {
                                    int n3 = 0;
                                    Label_0111: {
                                        if (fc.0 <= 0) {
                                            n3 = -1802333705;
                                            break Label_0111;
                                        }
                                        n3 = 689680044;
                                    }
                                    switch (n3 ^ 0xC1334F4) {
                                        case -1881953018: {
                                            continue;
                                        }
                                        default: {
                                            this.c = c;
                                            this.c = c2;
                                            return;
                                        }
                                        case -1736334077: {
                                            throw null;
                                        }
                                    }
                                    break;
                                }
                                break;
                            }
                            default: {
                                throw null;
                            }
                        }
                        break;
                    }
                    break;
                }
                default: {
                    throw null;
                }
            }
            break;
        }
    }
    
    public boolean 0() {
        return fez.hO(this, 2033356237);
    }
    
    public long 1() {
        return fez.fO(this, 2105821221);
    }
}
