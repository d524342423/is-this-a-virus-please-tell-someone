// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

public class f52 extends f58
{
    public boolean 1;
    public float 4;
    public float 5;
    
    @Override
    public void c(final int p0, final int p1, final int p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          162
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            154
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            146
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: getstatic       dev/nuker/pyro/fc.c:I
        //    27: ifne            35
        //    30: ldc             -843474270
        //    32: goto            37
        //    35: ldc             -1402122541
        //    37: ldc             1938476101
        //    39: ixor           
        //    40: lookupswitch {
        //          -1157247249: 35
        //          -1103931673: 135
        //          default: 68
        //        }
        //    68: aload_0        
        //    69: iload_1        
        //    70: iload_2        
        //    71: iload_3        
        //    72: getstatic       dev/nuker/pyro/fc.0:I
        //    75: ifgt            83
        //    78: ldc             1275071654
        //    80: goto            85
        //    83: ldc             -2027503151
        //    85: ldc             672654036
        //    87: ixor           
        //    88: lookupswitch {
        //          -802874834: 83
        //          1679289970: 133
        //          default: 116
        //        }
        //   116: goto            120
        //   119: athrow         
        //   120: invokespecial   dev/nuker/pyro/f58.c:(III)V
        //   123: goto            127
        //   126: athrow         
        //   127: aload_0        
        //   128: iconst_0       
        //   129: putfield        dev/nuker/pyro/f52.1:Z
        //   132: return         
        //   133: aconst_null    
        //   134: athrow         
        //   135: aconst_null    
        //   136: athrow         
        //   137: pop            
        //   138: goto            24
        //   141: pop            
        //   142: aconst_null    
        //   143: goto            137
        //   146: dup            
        //   147: ifnull          137
        //   150: checkcast       Ljava/lang/Throwable;
        //   153: athrow         
        //   154: dup            
        //   155: ifnull          141
        //   158: checkcast       Ljava/lang/Throwable;
        //   161: athrow         
        //   162: aconst_null    
        //   163: athrow         
        //    StackMapTable: 00 15 43 07 00 1C 04 FF 00 0B 00 00 00 01 07 00 1C FF 00 03 00 04 07 00 03 01 01 01 00 00 0A 41 01 1E FF 00 0E 00 04 07 00 03 01 01 01 00 04 07 00 03 01 01 01 FF 00 01 00 04 07 00 03 01 01 01 00 05 07 00 03 01 01 01 01 FF 00 1E 00 04 07 00 03 01 01 01 00 04 07 00 03 01 01 01 42 07 00 1C FF 00 00 00 04 07 00 03 01 01 01 00 04 07 00 03 01 01 01 45 07 00 1C 00 FF 00 05 00 04 07 00 03 01 01 01 00 04 07 00 03 01 01 01 01 41 07 00 1C 43 05 44 07 00 1C 47 05 47 07 00 1C
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     146    154    Any
        //  146    154    146    154    Ljava/lang/UnsupportedOperationException;
        //  162    164    3      8      Any
        //  119    126    126    127    Any
        //  120    126    119    120    Any
        //  120    126    126    127    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  119    126    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  119    126    126    127    Ljava/lang/NegativeArraySizeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 51 out of bounds for length 51
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void 0(final int p0, final int p1, final int p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          574
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            566
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            558
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: getstatic       dev/nuker/pyro/fc.0:I
        //    27: ifgt            35
        //    30: ldc             718037506
        //    32: goto            37
        //    35: ldc             -682584575
        //    37: ldc             -1864927820
        //    39: ixor           
        //    40: lookupswitch {
        //          -1172629578: 533
        //          -14201846: 35
        //          default: 68
        //        }
        //    68: aload_0        
        //    69: iload_1        
        //    70: getstatic       dev/nuker/pyro/fc.0:I
        //    73: ifgt            81
        //    76: ldc             1518179319
        //    78: goto            83
        //    81: ldc             2136044154
        //    83: ldc             -1556790978
        //    85: ixor           
        //    86: lookupswitch {
        //          -112667959: 547
        //          171611887: 81
        //          default: 112
        //        }
        //   112: iload_2        
        //   113: iload_3        
        //   114: getstatic       dev/nuker/pyro/fc.1:I
        //   117: ifne            125
        //   120: ldc             -68965275
        //   122: goto            127
        //   125: ldc             -1812283582
        //   127: ldc             626688803
        //   129: ixor           
        //   130: lookupswitch {
        //          -2136818950: 125
        //          -558289082: 535
        //          default: 156
        //        }
        //   156: goto            160
        //   159: athrow         
        //   160: invokespecial   dev/nuker/pyro/f58.0:(III)V
        //   163: goto            167
        //   166: athrow         
        //   167: getstatic       dev/nuker/pyro/fc.0:I
        //   170: ifgt            178
        //   173: ldc             109310540
        //   175: goto            180
        //   178: ldc             571767569
        //   180: ldc             951413851
        //   182: ixor           
        //   183: lookupswitch {
        //          223549874: 178
        //          1043766807: 537
        //          default: 208
        //        }
        //   208: iload_3        
        //   209: ifne            392
        //   212: getstatic       dev/nuker/pyro/fc.1:I
        //   215: ifne            223
        //   218: ldc             -865647312
        //   220: goto            225
        //   223: ldc             -473301964
        //   225: ldc             -1342116196
        //   227: ixor           
        //   228: lookupswitch {
        //          -129363046: 223
        //          2087168940: 543
        //          default: 256
        //        }
        //   256: aload_0        
        //   257: iconst_1       
        //   258: putfield        dev/nuker/pyro/f52.1:Z
        //   261: aload_0        
        //   262: getstatic       dev/nuker/pyro/fc.c:I
        //   265: ifne            273
        //   268: ldc             -1860612567
        //   270: goto            275
        //   273: ldc             588568281
        //   275: ldc             1633835341
        //   277: ixor           
        //   278: lookupswitch {
        //          -260368540: 273
        //          1115066260: 304
        //          default: 539
        //        }
        //   304: iload_1        
        //   305: i2f            
        //   306: putfield        dev/nuker/pyro/f52.4:F
        //   309: getstatic       dev/nuker/pyro/fc.c:I
        //   312: ifne            320
        //   315: ldc             -1353284456
        //   317: goto            322
        //   320: ldc             1093660310
        //   322: ldc             977460947
        //   324: ixor           
        //   325: lookupswitch {
        //          -1793828277: 541
        //          619237903: 320
        //          default: 352
        //        }
        //   352: aload_0        
        //   353: aload_0        
        //   354: getfield        dev/nuker/pyro/f52.c:Ldev/nuker/pyro/f0w;
        //   357: checkcast       Ldev/nuker/pyro/f0m;
        //   360: goto            364
        //   363: athrow         
        //   364: invokevirtual   dev/nuker/pyro/f0m.c:()Ljava/lang/Object;
        //   367: goto            371
        //   370: athrow         
        //   371: checkcast       Ljava/lang/Double;
        //   374: goto            378
        //   377: athrow         
        //   378: invokevirtual   java/lang/Double.doubleValue:()D
        //   381: goto            385
        //   384: athrow         
        //   385: d2f            
        //   386: putfield        dev/nuker/pyro/f52.5:F
        //   389: goto            532
        //   392: iload_3        
        //   393: iconst_1       
        //   394: if_icmpne       532
        //   397: aload_0        
        //   398: goto            402
        //   401: athrow         
        //   402: invokevirtual   dev/nuker/pyro/f52.5:()Ljava/util/List;
        //   405: goto            409
        //   408: athrow         
        //   409: getstatic       dev/nuker/pyro/fc.1:I
        //   412: ifne            420
        //   415: ldc             -304587826
        //   417: goto            422
        //   420: ldc             1644286593
        //   422: ldc             -237546694
        //   424: ixor           
        //   425: lookupswitch {
        //          -1126769349: 420
        //          470747380: 545
        //          default: 452
        //        }
        //   452: goto            456
        //   455: athrow         
        //   456: invokeinterface java/util/List.isEmpty:()Z
        //   461: goto            465
        //   464: athrow         
        //   465: ifne            532
        //   468: aload_0        
        //   469: aload_0        
        //   470: goto            474
        //   473: athrow         
        //   474: invokevirtual   dev/nuker/pyro/f52.9:()Z
        //   477: goto            481
        //   480: athrow         
        //   481: ifne            489
        //   484: ldc             1622874146
        //   486: goto            491
        //   489: ldc             1622874147
        //   491: ldc             1195498040
        //   493: ixor           
        //   494: tableswitch {
        //          1341490228: 516
        //          1341490229: 520
        //          default: 484
        //        }
        //   516: iconst_1       
        //   517: goto            521
        //   520: iconst_0       
        //   521: goto            525
        //   524: athrow         
        //   525: invokevirtual   dev/nuker/pyro/f52.c:(Z)V
        //   528: goto            532
        //   531: athrow         
        //   532: return         
        //   533: aconst_null    
        //   534: athrow         
        //   535: aconst_null    
        //   536: athrow         
        //   537: aconst_null    
        //   538: athrow         
        //   539: aconst_null    
        //   540: athrow         
        //   541: aconst_null    
        //   542: athrow         
        //   543: aconst_null    
        //   544: athrow         
        //   545: aconst_null    
        //   546: athrow         
        //   547: aconst_null    
        //   548: athrow         
        //   549: pop            
        //   550: goto            24
        //   553: pop            
        //   554: aconst_null    
        //   555: goto            549
        //   558: dup            
        //   559: ifnull          549
        //   562: checkcast       Ljava/lang/Throwable;
        //   565: athrow         
        //   566: dup            
        //   567: ifnull          553
        //   570: checkcast       Ljava/lang/Throwable;
        //   573: athrow         
        //   574: aconst_null    
        //   575: athrow         
        //    StackMapTable: 00 4C 43 07 00 1C 04 FF 00 0B 00 00 00 01 07 00 1C FF 00 03 00 04 07 00 03 01 01 01 00 00 0A 41 01 1E FF 00 0C 00 04 07 00 03 01 01 01 00 02 07 00 03 01 FF 00 01 00 04 07 00 03 01 01 01 00 03 07 00 03 01 01 FF 00 1C 00 04 07 00 03 01 01 01 00 02 07 00 03 01 FF 00 0C 00 04 07 00 03 01 01 01 00 04 07 00 03 01 01 01 FF 00 01 00 04 07 00 03 01 01 01 00 05 07 00 03 01 01 01 01 FF 00 1C 00 04 07 00 03 01 01 01 00 04 07 00 03 01 01 01 42 07 00 12 FF 00 00 00 04 07 00 03 01 01 01 00 04 07 00 03 01 01 01 45 07 00 1C 00 0A 41 01 1B 0E 41 01 1E 50 07 00 03 FF 00 01 00 04 07 00 03 01 01 01 00 02 07 00 03 01 5C 07 00 03 0F 41 01 1D 4A 07 00 1C FF 00 00 00 04 07 00 03 01 01 01 00 02 07 00 03 07 00 5A 45 07 00 1C FF 00 00 00 04 07 00 03 01 01 01 00 02 07 00 03 07 00 7C FF 00 05 00 00 00 01 07 00 1C FF 00 00 00 04 07 00 03 01 01 01 00 02 07 00 03 07 00 5F 45 07 00 1C FF 00 00 00 04 07 00 03 01 01 01 00 02 07 00 03 03 06 FF 00 08 00 00 00 01 07 00 1C FF 00 00 00 04 07 00 03 01 01 01 00 01 07 00 03 45 07 00 1C 40 07 00 6D 4A 07 00 6D FF 00 01 00 04 07 00 03 01 01 01 00 02 07 00 6D 01 5D 07 00 6D FF 00 02 00 00 00 01 07 00 1C FF 00 00 00 04 07 00 03 01 01 01 00 01 07 00 6D 47 07 00 1C 40 01 47 07 00 1C FF 00 00 00 04 07 00 03 01 01 01 00 02 07 00 03 07 00 03 45 07 00 1C FF 00 00 00 04 07 00 03 01 01 01 00 02 07 00 03 01 42 07 00 03 44 07 00 03 FF 00 01 00 04 07 00 03 01 01 01 00 02 07 00 03 01 58 07 00 03 43 07 00 03 FF 00 00 00 04 07 00 03 01 01 01 00 02 07 00 03 01 42 07 00 30 FF 00 00 00 04 07 00 03 01 01 01 00 02 07 00 03 01 45 07 00 1C 00 00 FF 00 01 00 04 07 00 03 01 01 01 00 04 07 00 03 01 01 01 01 41 07 00 03 01 01 41 07 00 6D FF 00 01 00 04 07 00 03 01 01 01 00 02 07 00 03 01 41 07 00 1C 43 05 44 07 00 1C 47 05 47 07 00 1C
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     558    566    Any
        //  558    566    558    566    Any
        //  574    576    3      8      Ljava/util/NoSuchElementException;
        //  159    166    166    167    Any
        //  160    166    166    167    Ljava/lang/UnsupportedOperationException;
        //  159    166    3      8      Ljava/lang/IllegalArgumentException;
        //  160    166    166    167    Any
        //  159    166    159    160    Ljava/lang/EnumConstantNotPresentException;
        //  363    370    370    371    Any
        //  363    370    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  363    370    3      8      Ljava/lang/AssertionError;
        //  364    370    363    364    Any
        //  364    370    3      8      Any
        //  378    384    384    385    Any
        //  378    384    384    385    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  378    384    384    385    Ljava/util/ConcurrentModificationException;
        //  378    384    3      8      Any
        //  378    384    384    385    Ljava/util/ConcurrentModificationException;
        //  402    408    408    409    Any
        //  402    408    408    409    Ljava/lang/AssertionError;
        //  402    408    3      8      Ljava/lang/IllegalArgumentException;
        //  402    408    3      8      Any
        //  402    408    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  456    464    464    465    Any
        //  456    464    464    465    Any
        //  456    464    464    465    Any
        //  456    464    3      8      Any
        //  456    464    464    465    Ljava/lang/ArithmeticException;
        //  473    480    480    481    Any
        //  473    480    3      8      Any
        //  473    480    480    481    Any
        //  473    480    473    474    Any
        //  473    480    480    481    Ljava/lang/StringIndexOutOfBoundsException;
        //  524    531    531    532    Any
        //  525    531    524    525    Ljava/lang/AssertionError;
        //  525    531    531    532    Ljava/util/ConcurrentModificationException;
        //  525    531    3      8      Ljava/lang/NullPointerException;
        //  525    531    531    532    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:590)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public String 8() {
        return fez.4g(this, 597937028);
    }
    
    public f52(final f0w p0, final float p1, final float p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: aload_1        
        //     2: fload_2        
        //     3: fload_3        
        //     4: invokespecial   dev/nuker/pyro/f58.<init>:(Ldev/nuker/pyro/f0w;FF)V
        //     7: aload_0        
        //     8: iconst_0       
        //     9: putfield        dev/nuker/pyro/f52.1:Z
        //    12: getstatic       dev/nuker/pyro/fc.c:I
        //    15: ifne            23
        //    18: ldc             -1603730630
        //    20: goto            25
        //    23: ldc             658739533
        //    25: ldc             1789751320
        //    27: ixor           
        //    28: lookupswitch {
        //          -893095134: 652
        //          1372655421: 23
        //          default: 56
        //        }
        //    56: aload_0        
        //    57: fconst_0       
        //    58: putfield        dev/nuker/pyro/f52.4:F
        //    61: getstatic       dev/nuker/pyro/fc.c:I
        //    64: ifne            72
        //    67: ldc             1511651770
        //    69: goto            74
        //    72: ldc             -970872608
        //    74: ldc             246647472
        //    76: ixor           
        //    77: lookupswitch {
        //          -929947056: 104
        //          1420456714: 72
        //          default: 654
        //        }
        //   104: aload_0        
        //   105: fconst_0       
        //   106: putfield        dev/nuker/pyro/f52.5:F
        //   109: getstatic       dev/nuker/pyro/fc.c:I
        //   112: ifne            120
        //   115: ldc             -2087877278
        //   117: goto            122
        //   120: ldc             -2004181771
        //   122: ldc             1515555968
        //   124: ixor           
        //   125: lookupswitch {
        //          -640153118: 646
        //          450044430: 120
        //          default: 152
        //        }
        //   152: aload_1        
        //   153: checkcast       Ldev/nuker/pyro/f0m;
        //   156: getstatic       dev/nuker/pyro/fc.c:I
        //   159: ifne            167
        //   162: ldc             1604909240
        //   164: goto            169
        //   167: ldc             1572293944
        //   169: ldc             -871941223
        //   171: ixor           
        //   172: lookupswitch {
        //          -1850706271: 200
        //          -1817197791: 167
        //          default: 660
        //        }
        //   200: astore          4
        //   202: aload_0        
        //   203: invokevirtual   dev/nuker/pyro/f52.5:()Ljava/util/List;
        //   206: new             Ldev/nuker/pyro/f5d;
        //   209: dup            
        //   210: getstatic       dev/nuker/pyro/fc.1:I
        //   213: ifne            221
        //   216: ldc             -457785336
        //   218: goto            223
        //   221: ldc             1111013154
        //   223: ldc             -708249640
        //   225: ixor           
        //   226: lookupswitch {
        //          227685019: 221
        //          830355408: 642
        //          default: 252
        //        }
        //   252: aload_0        
        //   253: aload           4
        //   255: invokevirtual   dev/nuker/pyro/f0m.c:()Ljava/lang/String;
        //   258: getstatic       dev/nuker/pyro/fc.c:I
        //   261: ifne            269
        //   264: ldc             -2083159648
        //   266: goto            271
        //   269: ldc             -675507860
        //   271: ldc             2085265130
        //   273: ixor           
        //   274: lookupswitch {
        //          -1409937530: 300
        //          -6348982: 269
        //          default: 656
        //        }
        //   300: fload_2        
        //   301: getstatic       dev/nuker/pyro/fc.1:I
        //   304: ifne            312
        //   307: ldc             1703019987
        //   309: goto            314
        //   312: ldc             -1092224810
        //   314: ldc             393598229
        //   316: ixor           
        //   317: lookupswitch {
        //          -1450168893: 344
        //          1928843462: 312
        //          default: 640
        //        }
        //   344: fload_3        
        //   345: invokespecial   dev/nuker/pyro/f5d.<init>:(Ldev/nuker/pyro/f58;Ljava/lang/String;FF)V
        //   348: getstatic       dev/nuker/pyro/fc.c:I
        //   351: ifne            359
        //   354: ldc             -1527217588
        //   356: goto            361
        //   359: ldc             1021137568
        //   361: ldc             1528620054
        //   363: ixor           
        //   364: lookupswitch {
        //          -1808806: 359
        //          1740748470: 392
        //          default: 638
        //        }
        //   392: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //   397: pop            
        //   398: aload_0        
        //   399: invokevirtual   dev/nuker/pyro/f52.5:()Ljava/util/List;
        //   402: new             Ldev/nuker/pyro/f51;
        //   405: dup            
        //   406: aload_0        
        //   407: invokespecial   dev/nuker/pyro/f51.<init>:(Ldev/nuker/pyro/f58;)V
        //   410: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //   415: pop            
        //   416: aload_0        
        //   417: getstatic       dev/nuker/pyro/fc.1:I
        //   420: ifne            428
        //   423: ldc             802120305
        //   425: goto            430
        //   428: ldc             1680820132
        //   430: ldc             2032816971
        //   432: ixor           
        //   433: lookupswitch {
        //          486872303: 460
        //          1457860922: 428
        //          default: 644
        //        }
        //   460: invokevirtual   dev/nuker/pyro/f52.1:()Ljava/lang/String;
        //   463: astore          5
        //   465: aload           5
        //   467: ifnull          624
        //   470: new             Ljava/lang/StringBuilder;
        //   473: dup            
        //   474: getstatic       dev/nuker/pyro/fc.c:I
        //   477: ifne            485
        //   480: ldc             -778988550
        //   482: goto            487
        //   485: ldc             -975430652
        //   487: ldc             1486536477
        //   489: ixor           
        //   490: lookupswitch {
        //          -1995756313: 485
        //          -1656315111: 516
        //          default: 648
        //        }
        //   516: invokespecial   java/lang/StringBuilder.<init>:()V
        //   519: getstatic       dev/nuker/pyro/fc.1:I
        //   522: ifne            530
        //   525: ldc             1457986713
        //   527: goto            532
        //   530: ldc             1358925714
        //   532: ldc             -563940418
        //   534: ixor           
        //   535: lookupswitch {
        //          -2004488409: 530
        //          -1902281684: 560
        //          default: 658
        //        }
        //   560: aload           5
        //   562: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   565: ldc             "\u3d6e\ub271\u8e46\uadad\u6720\u59a1\u7e4f\u6949\uc2d7\ua3dc\u9bb2\u130a\uc178\u710d\u90e3\u4de7\ub251\u4cd0\u0147\u0740\u12e3\ufecd\u6a89\u885c\u3604\u3d2e\u7ff8\ua92a\ud1e9\u720c\u4421\u6bab\u744c\u9738\uc7e1\u4368\ufde3\u10da\u1842\u4a84\u6651\uac42\u8d6c\uf929\ubc98\ua478\u4c2a\u3f49\u4a2c\ua25d\u7819\u9122\u331c\u6fdc\uf6a2\u0eac\u7a1b\u0aed\u9f28\ud3b7\ue7c7\u4c7e\u4857\u1687\u318e\u51c3\u7985\ue7aa\u5fa4"
        //   567: invokestatic    invokestatic   !!! ERROR
        //   570: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   573: getstatic       dev/nuker/pyro/fc.c:I
        //   576: ifne            584
        //   579: ldc             1410028780
        //   581: goto            586
        //   584: ldc             -1391771839
        //   586: ldc             1886700312
        //   588: ixor           
        //   589: lookupswitch {
        //          612341748: 650
        //          927900265: 584
        //          default: 616
        //        }
        //   616: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   619: astore          5
        //   621: goto            631
        //   624: ldc             "\u3d30\ub24d\u8e47\uadb7\u6773\u59ee\u7e50\u694d\uc2ca\ua3da\u9bb3\u1344\uc13b\u710f\u90ec\u4da9\ub213\u4cd7\u0102\u0712\u12f8\ufec3\u6a86\u8840\u3650\u3d6d\u7ff7\ua92f\ud1e3\u7204\u442f\u6baa\u7408\u9771\uc7e6\u4369\ufdfe\u10cc\u1843\u4a93\u6603\uac16\u8d77\uf966\ubcdb\ua473\u4c23\u3f46\u4a25\ua25f\u785c\u916b\u3301\u6f8f\uf6f6\u0eff\u7a5e\u0af0\u9f31\ud3b5\ue7d0\u4c2a\u4801\u1690\u3183\u51da\u7995\ue7ee"
        //   626: invokestatic    invokestatic   !!! ERROR
        //   629: astore          5
        //   631: aload_0        
        //   632: aload           5
        //   634: invokevirtual   dev/nuker/pyro/f52.c:(Ljava/lang/String;)V
        //   637: return         
        //   638: aconst_null    
        //   639: athrow         
        //   640: aconst_null    
        //   641: athrow         
        //   642: aconst_null    
        //   643: athrow         
        //   644: aconst_null    
        //   645: athrow         
        //   646: aconst_null    
        //   647: athrow         
        //   648: aconst_null    
        //   649: athrow         
        //   650: aconst_null    
        //   651: athrow         
        //   652: aconst_null    
        //   653: athrow         
        //   654: aconst_null    
        //   655: athrow         
        //   656: aconst_null    
        //   657: athrow         
        //   658: aconst_null    
        //   659: athrow         
        //   660: aconst_null    
        //   661: athrow         
        //    StackMapTable: 00 32 FF 00 17 00 04 07 00 03 07 00 D9 02 02 00 00 41 01 1E 0F 41 01 1D 0F 41 01 1D 4E 07 00 5A FF 00 01 00 04 07 00 03 07 00 D9 02 02 00 02 07 00 5A 01 5E 07 00 5A FF 00 14 00 05 07 00 03 07 00 D9 02 02 07 00 5A 00 03 07 00 6D 08 00 CE 08 00 CE FF 00 01 00 05 07 00 03 07 00 D9 02 02 07 00 5A 00 04 07 00 6D 08 00 CE 08 00 CE 01 FF 00 1C 00 05 07 00 03 07 00 D9 02 02 07 00 5A 00 03 07 00 6D 08 00 CE 08 00 CE FF 00 10 00 05 07 00 03 07 00 D9 02 02 07 00 5A 00 05 07 00 6D 08 00 CE 08 00 CE 07 00 03 07 00 DB FF 00 01 00 05 07 00 03 07 00 D9 02 02 07 00 5A 00 06 07 00 6D 08 00 CE 08 00 CE 07 00 03 07 00 DB 01 FF 00 1C 00 05 07 00 03 07 00 D9 02 02 07 00 5A 00 05 07 00 6D 08 00 CE 08 00 CE 07 00 03 07 00 DB FF 00 0B 00 05 07 00 03 07 00 D9 02 02 07 00 5A 00 06 07 00 6D 08 00 CE 08 00 CE 07 00 03 07 00 DB 02 FF 00 01 00 05 07 00 03 07 00 D9 02 02 07 00 5A 00 07 07 00 6D 08 00 CE 08 00 CE 07 00 03 07 00 DB 02 01 FF 00 1D 00 05 07 00 03 07 00 D9 02 02 07 00 5A 00 06 07 00 6D 08 00 CE 08 00 CE 07 00 03 07 00 DB 02 FF 00 0E 00 05 07 00 03 07 00 D9 02 02 07 00 5A 00 02 07 00 6D 07 00 97 FF 00 01 00 05 07 00 03 07 00 D9 02 02 07 00 5A 00 03 07 00 6D 07 00 97 01 FF 00 1E 00 05 07 00 03 07 00 D9 02 02 07 00 5A 00 02 07 00 6D 07 00 97 63 07 00 03 FF 00 01 00 05 07 00 03 07 00 D9 02 02 07 00 5A 00 02 07 00 03 01 5D 07 00 03 FF 00 18 00 06 07 00 03 07 00 D9 02 02 07 00 5A 07 00 DB 00 02 08 01 D6 08 01 D6 FF 00 01 00 06 07 00 03 07 00 D9 02 02 07 00 5A 07 00 DB 00 03 08 01 D6 08 01 D6 01 FF 00 1C 00 06 07 00 03 07 00 D9 02 02 07 00 5A 07 00 DB 00 02 08 01 D6 08 01 D6 4D 07 00 B8 FF 00 01 00 06 07 00 03 07 00 D9 02 02 07 00 5A 07 00 DB 00 02 07 00 B8 01 5B 07 00 B8 57 07 00 B8 FF 00 01 00 06 07 00 03 07 00 D9 02 02 07 00 5A 07 00 DB 00 02 07 00 B8 01 5D 07 00 B8 07 06 FF 00 06 00 05 07 00 03 07 00 D9 02 02 07 00 5A 00 02 07 00 6D 07 00 97 FF 00 01 00 05 07 00 03 07 00 D9 02 02 07 00 5A 00 06 07 00 6D 08 00 CE 08 00 CE 07 00 03 07 00 DB 02 FF 00 01 00 05 07 00 03 07 00 D9 02 02 07 00 5A 00 03 07 00 6D 08 00 CE 08 00 CE 41 07 00 03 FA 00 01 FF 00 01 00 06 07 00 03 07 00 D9 02 02 07 00 5A 07 00 DB 00 02 08 01 D6 08 01 D6 41 07 00 B8 F9 00 01 01 FF 00 01 00 05 07 00 03 07 00 D9 02 02 07 00 5A 00 05 07 00 6D 08 00 CE 08 00 CE 07 00 03 07 00 DB FF 00 01 00 06 07 00 03 07 00 D9 02 02 07 00 5A 07 00 DB 00 01 07 00 B8 FF 00 01 00 04 07 00 03 07 00 D9 02 02 00 01 07 00 5A
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public boolean c(final float n, final float n2, final float n3) {
        return fez.b(this, 751937620, n, n2, n3);
    }
    
    static {
        throw t;
    }
}
