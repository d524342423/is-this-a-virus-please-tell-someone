// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

public enum f9b
{
    public static f9b c;
    public static f9b 0;
    public static f9b 1;
    public static f9b 2;
    public static f9b[] c;
    
    public f9b(final String name, final int ordinal) {
        while (true) {
            Label_0013: {
                if (fc.1 == 0) {
                    n = 725356130;
                    break Label_0013;
                }
                n = -996119009;
            }
            switch (n ^ 0x63C54F51) {
                case -1218611465: {
                    continue;
                }
                default: {
                    while (true) {
                        int n2 = 0;
                        Label_0060: {
                            if (fc.c == 0) {
                                n2 = -1334283183;
                                break Label_0060;
                            }
                            n2 = -1833187092;
                        }
                        switch (n2 ^ 0xD3FC223F) {
                            case 1669617262: {
                                continue;
                            }
                            case 1095232211: {
                                super(name, ordinal);
                                return;
                            }
                            default: {
                                throw null;
                            }
                        }
                        break;
                    }
                    break;
                }
                case 1224294707: {
                    throw null;
                }
            }
            break;
        }
    }
    
    public static f9b c(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          110
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            102
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            94
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: ldc             Ldev/nuker/pyro/f9b;.class
        //    26: aload_0        
        //    27: getstatic       dev/nuker/pyro/fc.1:I
        //    30: ifne            38
        //    33: ldc             496200479
        //    35: goto            40
        //    38: ldc             1339290159
        //    40: ldc             400137048
        //    42: ixor           
        //    43: lookupswitch {
        //          172683335: 38
        //          1477077367: 68
        //          default: 83
        //        }
        //    68: goto            72
        //    71: athrow         
        //    72: invokestatic    java/lang/Enum.valueOf:(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
        //    75: goto            79
        //    78: athrow         
        //    79: checkcast       Ldev/nuker/pyro/f9b;
        //    82: areturn        
        //    83: aconst_null    
        //    84: athrow         
        //    85: pop            
        //    86: goto            24
        //    89: pop            
        //    90: aconst_null    
        //    91: goto            85
        //    94: dup            
        //    95: ifnull          85
        //    98: checkcast       Ljava/lang/Throwable;
        //   101: athrow         
        //   102: dup            
        //   103: ifnull          89
        //   106: checkcast       Ljava/lang/Throwable;
        //   109: athrow         
        //   110: aconst_null    
        //   111: athrow         
        //    StackMapTable: 00 11 43 07 00 28 04 FF 00 0B 00 00 00 01 07 00 28 FC 00 03 07 00 1E FF 00 0D 00 01 07 00 1E 00 02 07 00 43 07 00 1E FF 00 01 00 01 07 00 1E 00 03 07 00 43 07 00 1E 01 FF 00 1B 00 01 07 00 1E 00 02 07 00 43 07 00 1E 42 07 00 28 FF 00 00 00 01 07 00 1E 00 02 07 00 43 07 00 1E 45 07 00 28 40 07 00 05 FF 00 03 00 01 07 00 1E 00 02 07 00 43 07 00 1E 41 07 00 26 43 05 44 07 00 26 47 05 47 07 00 28
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     94     102    Ljava/lang/StringIndexOutOfBoundsException;
        //  94     102    94     102    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  110    112    3      8      Any
        //  71     78     78     79     Any
        //  72     78     3      8      Ljava/util/NoSuchElementException;
        //  71     78     71     72     Any
        //  72     78     78     79     Ljava/lang/RuntimeException;
        //  72     78     3      8      Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 44 out of bounds for length 44
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: anewarray       Ldev/nuker/pyro/f9b;
        //     4: dup            
        //     5: dup            
        //     6: iconst_0       
        //     7: new             Ldev/nuker/pyro/f9b;
        //    10: dup            
        //    11: ldc             "\u3cf9\ub242\u8fac\ua170\u5004\u5830"
        //    13: invokestatic    invokestatic   !!! ERROR
        //    16: iconst_0       
        //    17: getstatic       dev/nuker/pyro/fc.c:I
        //    20: ifne            28
        //    23: ldc             648118770
        //    25: goto            30
        //    28: ldc             975046640
        //    30: ldc             563929570
        //    32: ixor           
        //    33: lookupswitch {
        //          -1911107672: 28
        //          121462800: 270
        //          default: 60
        //        }
        //    60: invokespecial   dev/nuker/pyro/f9b.<init>:(Ljava/lang/String;I)V
        //    63: dup            
        //    64: getstatic       dev/nuker/pyro/fc.1:I
        //    67: ifne            75
        //    70: ldc             -1509537210
        //    72: goto            77
        //    75: ldc             883301423
        //    77: ldc             1742431042
        //    79: ixor           
        //    80: lookupswitch {
        //          -1042470652: 75
        //          1400733549: 108
        //          default: 268
        //        }
        //   108: putstatic       dev/nuker/pyro/f9b.c:Ldev/nuker/pyro/f9b;
        //   111: aastore        
        //   112: dup            
        //   113: iconst_1       
        //   114: new             Ldev/nuker/pyro/f9b;
        //   117: dup            
        //   118: ldc             "\u3cf6\ub257\u8fa7\ua16e\u5003\u5830\u7e4e\u68b6\uce01"
        //   120: invokestatic    invokestatic   !!! ERROR
        //   123: iconst_1       
        //   124: invokespecial   dev/nuker/pyro/f9b.<init>:(Ljava/lang/String;I)V
        //   127: dup            
        //   128: putstatic       dev/nuker/pyro/f9b.0:Ldev/nuker/pyro/f9b;
        //   131: aastore        
        //   132: dup            
        //   133: iconst_2       
        //   134: new             Ldev/nuker/pyro/f9b;
        //   137: dup            
        //   138: ldc             "\u3cf4\ub24c\u8fb1\ua16b\u5017\u583b\u7e43\u68b0"
        //   140: invokestatic    invokestatic   !!! ERROR
        //   143: iconst_2       
        //   144: invokespecial   dev/nuker/pyro/f9b.<init>:(Ljava/lang/String;I)V
        //   147: dup            
        //   148: getstatic       dev/nuker/pyro/fc.1:I
        //   151: ifne            159
        //   154: ldc             1595828619
        //   156: goto            161
        //   159: ldc             -553210991
        //   161: ldc             606019323
        //   163: ixor           
        //   164: lookupswitch {
        //          -82201238: 192
        //          2063693680: 159
        //          default: 266
        //        }
        //   192: putstatic       dev/nuker/pyro/f9b.1:Ldev/nuker/pyro/f9b;
        //   195: aastore        
        //   196: dup            
        //   197: iconst_3       
        //   198: new             Ldev/nuker/pyro/f9b;
        //   201: dup            
        //   202: ldc             "\u3cf2\ub24a\u8fb6\ua177"
        //   204: invokestatic    invokestatic   !!! ERROR
        //   207: iconst_3       
        //   208: invokespecial   dev/nuker/pyro/f9b.<init>:(Ljava/lang/String;I)V
        //   211: dup            
        //   212: getstatic       dev/nuker/pyro/fc.1:I
        //   215: ifne            223
        //   218: ldc             1182006599
        //   220: goto            225
        //   223: ldc             -1744812675
        //   225: ldc             527564407
        //   227: ixor           
        //   228: lookupswitch {
        //          -1869058286: 223
        //          1493304112: 264
        //          default: 256
        //        }
        //   256: putstatic       dev/nuker/pyro/f9b.2:Ldev/nuker/pyro/f9b;
        //   259: aastore        
        //   260: putstatic       dev/nuker/pyro/f9b.c:[Ldev/nuker/pyro/f9b;
        //   263: return         
        //   264: aconst_null    
        //   265: athrow         
        //   266: aconst_null    
        //   267: athrow         
        //   268: aconst_null    
        //   269: athrow         
        //   270: aconst_null    
        //   271: athrow         
        //    StackMapTable: 00 10 FF 00 1C 00 00 00 08 07 00 2B 07 00 2B 07 00 2B 01 08 00 07 08 00 07 07 00 1E 01 FF 00 01 00 00 00 09 07 00 2B 07 00 2B 07 00 2B 01 08 00 07 08 00 07 07 00 1E 01 01 FF 00 1D 00 00 00 08 07 00 2B 07 00 2B 07 00 2B 01 08 00 07 08 00 07 07 00 1E 01 FF 00 0E 00 00 00 06 07 00 2B 07 00 2B 07 00 2B 01 07 00 03 07 00 03 FF 00 01 00 00 00 07 07 00 2B 07 00 2B 07 00 2B 01 07 00 03 07 00 03 01 FF 00 1E 00 00 00 06 07 00 2B 07 00 2B 07 00 2B 01 07 00 03 07 00 03 FF 00 32 00 00 00 06 07 00 2B 07 00 2B 07 00 2B 01 07 00 03 07 00 03 FF 00 01 00 00 00 07 07 00 2B 07 00 2B 07 00 2B 01 07 00 03 07 00 03 01 FF 00 1E 00 00 00 06 07 00 2B 07 00 2B 07 00 2B 01 07 00 03 07 00 03 FF 00 1E 00 00 00 06 07 00 2B 07 00 2B 07 00 2B 01 07 00 03 07 00 03 FF 00 01 00 00 00 07 07 00 2B 07 00 2B 07 00 2B 01 07 00 03 07 00 03 01 FF 00 1E 00 00 00 06 07 00 2B 07 00 2B 07 00 2B 01 07 00 03 07 00 03 FF 00 07 00 00 00 06 07 00 2B 07 00 2B 07 00 2B 01 07 00 03 07 00 03 FF 00 01 00 00 00 06 07 00 2B 07 00 2B 07 00 2B 01 07 00 03 07 00 03 FF 00 01 00 00 00 06 07 00 2B 07 00 2B 07 00 2B 01 07 00 03 07 00 03 FF 00 01 00 00 00 08 07 00 2B 07 00 2B 07 00 2B 01 08 00 07 08 00 07 07 00 1E 01
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
