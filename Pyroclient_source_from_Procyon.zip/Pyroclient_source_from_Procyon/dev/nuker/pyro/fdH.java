// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import dev.nuker.pyro.security.inject.LauncherEventHide;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import net.minecraft.client.entity.EntityPlayerSP;
import org.jetbrains.annotations.NotNull;

public class fdH extends fQ
{
    @NotNull
    public f0m c;
    @NotNull
    public f0k c;
    
    static {
        throw t;
    }
    
    @Override
    public void c(final boolean p0, @Nullable final EntityPlayerSP p1, @Nullable final World p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          333
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            325
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            317
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_0        
        //    25: iload_1        
        //    26: aload_2        
        //    27: getstatic       dev/nuker/pyro/fc.1:I
        //    30: ifne            38
        //    33: ldc             -2098025322
        //    35: goto            40
        //    38: ldc             -1629169363
        //    40: ldc             -2048371102
        //    42: ixor           
        //    43: lookupswitch {
        //          119208692: 38
        //          453807951: 68
        //          default: 306
        //        }
        //    68: aload_3        
        //    69: getstatic       dev/nuker/pyro/fc.c:I
        //    72: ifne            80
        //    75: ldc             -564086736
        //    77: goto            82
        //    80: ldc             1097872128
        //    82: ldc             380542774
        //    84: ixor           
        //    85: lookupswitch {
        //          -926013690: 302
        //          959123962: 80
        //          default: 112
        //        }
        //   112: goto            116
        //   115: athrow         
        //   116: invokespecial   dev/nuker/pyro/fQ.c:(ZLnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/world/World;)V
        //   119: goto            123
        //   122: athrow         
        //   123: getstatic       dev/nuker/pyro/fc.0:I
        //   126: ifgt            134
        //   129: ldc             1225474328
        //   131: goto            136
        //   134: ldc             527075610
        //   136: ldc             205551079
        //   138: ixor           
        //   139: lookupswitch {
        //          967100401: 134
        //          1162556671: 304
        //          default: 164
        //        }
        //   164: getstatic       dev/nuker/pyro/f0b.c:Ldev/nuker/pyro/f0b;
        //   167: ldc             "\u37d9\ub24c\u848a\uafb0\u6ad9"
        //   169: goto            173
        //   172: athrow         
        //   173: invokestatic    invokestatic   !!! ERROR
        //   176: goto            180
        //   179: athrow         
        //   180: goto            184
        //   183: athrow         
        //   184: invokevirtual   dev/nuker/pyro/f0b.1:(Ljava/lang/String;)V
        //   187: goto            191
        //   190: athrow         
        //   191: iload_1        
        //   192: ifeq            299
        //   195: getstatic       dev/nuker/pyro/f0b.c:Ldev/nuker/pyro/f0b;
        //   198: ldc             "\u37d9\ub24c\u848a\uafb0\u6ad9"
        //   200: getstatic       dev/nuker/pyro/fc.1:I
        //   203: ifne            211
        //   206: ldc             354366736
        //   208: goto            213
        //   211: ldc             -1198413634
        //   213: ldc             217776478
        //   215: ixor           
        //   216: lookupswitch {
        //          434385998: 300
        //          1296295161: 211
        //          default: 244
        //        }
        //   244: goto            248
        //   247: athrow         
        //   248: invokestatic    invokestatic   !!! ERROR
        //   251: goto            255
        //   254: athrow         
        //   255: getstatic       dev/nuker/pyro/f07.0:Ldev/nuker/pyro/f07;
        //   258: aload_0        
        //   259: getfield        dev/nuker/pyro/fdH.c:Ldev/nuker/pyro/f0m;
        //   262: goto            266
        //   265: athrow         
        //   266: invokevirtual   dev/nuker/pyro/f0m.c:()Ljava/lang/Object;
        //   269: goto            273
        //   272: athrow         
        //   273: checkcast       Ljava/lang/Number;
        //   276: goto            280
        //   279: athrow         
        //   280: invokevirtual   java/lang/Number.doubleValue:()D
        //   283: goto            287
        //   286: athrow         
        //   287: d2f            
        //   288: goto            292
        //   291: athrow         
        //   292: invokevirtual   dev/nuker/pyro/f0b.c:(Ljava/lang/String;Ldev/nuker/pyro/f07;F)V
        //   295: goto            299
        //   298: athrow         
        //   299: return         
        //   300: aconst_null    
        //   301: athrow         
        //   302: aconst_null    
        //   303: athrow         
        //   304: aconst_null    
        //   305: athrow         
        //   306: aconst_null    
        //   307: athrow         
        //   308: pop            
        //   309: goto            24
        //   312: pop            
        //   313: aconst_null    
        //   314: goto            308
        //   317: dup            
        //   318: ifnull          308
        //   321: checkcast       Ljava/lang/Throwable;
        //   324: athrow         
        //   325: dup            
        //   326: ifnull          312
        //   329: checkcast       Ljava/lang/Throwable;
        //   332: athrow         
        //   333: aconst_null    
        //   334: athrow         
        //    StackMapTable: 00 35 43 07 00 32 04 FF 00 0B 00 00 00 01 07 00 32 FF 00 03 00 04 07 00 03 01 07 00 6C 07 00 6E 00 00 FF 00 0D 00 04 07 00 03 01 07 00 6C 07 00 6E 00 03 07 00 03 01 07 00 6C FF 00 01 00 04 07 00 03 01 07 00 6C 07 00 6E 00 04 07 00 03 01 07 00 6C 01 FF 00 1B 00 04 07 00 03 01 07 00 6C 07 00 6E 00 03 07 00 03 01 07 00 6C FF 00 0B 00 04 07 00 03 01 07 00 6C 07 00 6E 00 04 07 00 03 01 07 00 6C 07 00 6E FF 00 01 00 04 07 00 03 01 07 00 6C 07 00 6E 00 05 07 00 03 01 07 00 6C 07 00 6E 01 FF 00 1D 00 04 07 00 03 01 07 00 6C 07 00 6E 00 04 07 00 03 01 07 00 6C 07 00 6E 42 07 00 32 FF 00 00 00 04 07 00 03 01 07 00 6C 07 00 6E 00 04 07 00 03 01 07 00 6C 07 00 6E 45 07 00 32 00 0A 41 01 1B 47 07 00 15 FF 00 00 00 04 07 00 03 01 07 00 6C 07 00 6E 00 02 07 00 45 07 00 70 45 07 00 32 FF 00 00 00 04 07 00 03 01 07 00 6C 07 00 6E 00 02 07 00 45 07 00 70 42 07 00 1B FF 00 00 00 04 07 00 03 01 07 00 6C 07 00 6E 00 02 07 00 45 07 00 70 45 07 00 32 00 FF 00 13 00 04 07 00 03 01 07 00 6C 07 00 6E 00 02 07 00 45 07 00 70 FF 00 01 00 04 07 00 03 01 07 00 6C 07 00 6E 00 03 07 00 45 07 00 70 01 FF 00 1E 00 04 07 00 03 01 07 00 6C 07 00 6E 00 02 07 00 45 07 00 70 42 07 00 21 FF 00 00 00 04 07 00 03 01 07 00 6C 07 00 6E 00 02 07 00 45 07 00 70 45 07 00 32 FF 00 00 00 04 07 00 03 01 07 00 6C 07 00 6E 00 02 07 00 45 07 00 70 49 07 00 25 FF 00 00 00 04 07 00 03 01 07 00 6C 07 00 6E 00 04 07 00 45 07 00 70 07 00 57 07 00 5E 45 07 00 32 FF 00 00 00 04 07 00 03 01 07 00 6C 07 00 6E 00 04 07 00 45 07 00 70 07 00 57 07 00 72 45 07 00 32 FF 00 00 00 04 07 00 03 01 07 00 6C 07 00 6E 00 04 07 00 45 07 00 70 07 00 57 07 00 63 45 07 00 32 FF 00 00 00 04 07 00 03 01 07 00 6C 07 00 6E 00 04 07 00 45 07 00 70 07 00 57 03 43 07 00 32 FF 00 00 00 04 07 00 03 01 07 00 6C 07 00 6E 00 04 07 00 45 07 00 70 07 00 57 02 45 07 00 32 00 FF 00 00 00 04 07 00 03 01 07 00 6C 07 00 6E 00 02 07 00 45 07 00 70 FF 00 01 00 04 07 00 03 01 07 00 6C 07 00 6E 00 04 07 00 03 01 07 00 6C 07 00 6E 01 FF 00 01 00 04 07 00 03 01 07 00 6C 07 00 6E 00 03 07 00 03 01 07 00 6C 41 07 00 29 43 05 44 07 00 29 47 05 47 07 00 32
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     317    325    Ljava/lang/NegativeArraySizeException;
        //  317    325    317    325    Ljava/lang/IllegalArgumentException;
        //  333    335    3      8      Any
        //  115    122    122    123    Any
        //  115    122    122    123    Ljava/lang/IllegalStateException;
        //  116    122    3      8      Any
        //  115    122    115    116    Any
        //  115    122    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  172    179    179    180    Any
        //  172    179    3      8      Ljava/lang/IllegalArgumentException;
        //  172    179    172    173    Ljava/lang/IndexOutOfBoundsException;
        //  172    179    179    180    Any
        //  173    179    179    180    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  183    190    190    191    Any
        //  183    190    190    191    Ljava/util/ConcurrentModificationException;
        //  183    190    183    184    Ljava/lang/EnumConstantNotPresentException;
        //  183    190    190    191    Any
        //  183    190    3      8      Any
        //  247    254    254    255    Any
        //  247    254    3      8      Ljava/lang/NumberFormatException;
        //  248    254    254    255    Ljava/lang/AssertionError;
        //  247    254    3      8      Any
        //  248    254    247    248    Ljava/lang/NullPointerException;
        //  265    272    272    273    Any
        //  266    272    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  266    272    272    273    Any
        //  266    272    265    266    Ljava/util/NoSuchElementException;
        //  265    272    272    273    Ljava/lang/UnsupportedOperationException;
        //  279    286    286    287    Any
        //  280    286    279    280    Any
        //  279    286    286    287    Ljava/lang/RuntimeException;
        //  280    286    279    280    Ljava/lang/NullPointerException;
        //  280    286    279    280    Ljava/lang/ArithmeticException;
        //  291    298    298    299    Any
        //  291    298    298    299    Ljava/lang/EnumConstantNotPresentException;
        //  292    298    291    292    Any
        //  292    298    298    299    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  292    298    291    292    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:595)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @f0g
    @LauncherEventHide
    public void c(@NotNull final f4t p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          847
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            839
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            831
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: getstatic       dev/nuker/pyro/fc.1:I
        //    29: ifne            37
        //    32: ldc             -1408958077
        //    34: goto            39
        //    37: ldc             -121027310
        //    39: ldc             -224822178
        //    41: ixor           
        //    42: lookupswitch {
        //          173029708: 68
        //          1587314141: 37
        //          default: 804
        //        }
        //    68: aload_0        
        //    69: getstatic       kotlin/jvm/internal/StringCompanionObject.INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;
        //    72: astore_2       
        //    73: ldc             "\u3788\ub20b\u84d5\uafb3"
        //    75: getstatic       dev/nuker/pyro/fc.c:I
        //    78: ifne            86
        //    81: ldc             1193729782
        //    83: goto            88
        //    86: ldc             1611025683
        //    88: ldc             1651222702
        //    90: ixor           
        //    91: lookupswitch {
        //          40756669: 116
        //          625833560: 86
        //          default: 816
        //        }
        //   116: goto            120
        //   119: athrow         
        //   120: invokestatic    invokestatic   !!! ERROR
        //   123: goto            127
        //   126: athrow         
        //   127: astore_3       
        //   128: iconst_1       
        //   129: anewarray       Ljava/lang/Object;
        //   132: dup            
        //   133: iconst_0       
        //   134: bipush          50
        //   136: i2f            
        //   137: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //   140: dup            
        //   141: ifnonnull       149
        //   144: ldc             289691669
        //   146: goto            151
        //   149: ldc             289691670
        //   151: ldc             -1842879516
        //   153: ixor           
        //   154: tableswitch {
        //          113735650: 176
        //          113735651: 205
        //          default: 144
        //        }
        //   176: new             Lkotlin/TypeCastException;
        //   179: dup            
        //   180: ldc             "\u37c3\ub250\u848b\uafb9\u6a8b\u532b\u7e41\u639e\uc0dc\uae22\u9160\u1344\ucbf3\u731a\u9d5a\u4723\ub210\u4608\u0347\u0ab8\u182c\ufecb\u6007\u8a4b\u3be7\u37a9\u7fb6\ua3e1\ud3e4\u7ffb\u4eef\u6bee\u7e95\u9570\uca00\u49aa\ufdac\u1a05\u1a52\u476f\u6cc4\uac0c\u87a4\ufb3c\ub125\uaea0\u4c6c\u3591\u482a\uafb0\u72da\u912c\u39d1\u6dd0\ufb05\u047f\u7a55o\u9d0c\ude47\ued03\u4c6f\u42dd\u1492\u3c76\u5b00\u7984\ued47\u5df7\u861d\ue117\u1dd0\uf86b\ub463\ucd81"
        //   182: goto            186
        //   185: athrow         
        //   186: invokestatic    invokestatic   !!! ERROR
        //   189: goto            193
        //   192: athrow         
        //   193: goto            197
        //   196: athrow         
        //   197: invokespecial   kotlin/TypeCastException.<init>:(Ljava/lang/String;)V
        //   200: goto            204
        //   203: athrow         
        //   204: athrow         
        //   205: checkcast       Ldev/nuker/pyro/mixin/MinecraftAccessor;
        //   208: goto            212
        //   211: athrow         
        //   212: invokeinterface dev/nuker/pyro/mixin/MinecraftAccessor.getTimer:()Lnet/minecraft/util/Timer;
        //   217: goto            221
        //   220: athrow         
        //   221: dup            
        //   222: ifnonnull       254
        //   225: new             Lkotlin/TypeCastException;
        //   228: dup            
        //   229: ldc             "\u37c3\ub250\u848b\uafb9\u6a8b\u532b\u7e41\u639e\uc0dc\uae22\u9160\u1344\ucbf3\u731a\u9d5a\u4723\ub210\u4608\u0347\u0ab8\u182c\ufecb\u6007\u8a4b\u3be7\u37a9\u7fb6\ua3e1\ud3e4\u7ffb\u4eef\u6bee\u7e95\u9570\uca00\u49aa\ufdac\u1a05\u1a52\u476f\u6cc4\uac0c\u87a4\ufb3c\ub125\uaea0\u4c6c\u3591\u482a\uafb0\u72da\u912c\u39d1\u6dd0\ufb05\u047f\u7a55o\u9d15\ude47\ued00\u4c6f\u42cc\u14a1\u3c74\u5b05\u7995\ued75\u5de7\u8611\ue100"
        //   231: goto            235
        //   234: athrow         
        //   235: invokestatic    invokestatic   !!! ERROR
        //   238: goto            242
        //   241: athrow         
        //   242: goto            246
        //   245: athrow         
        //   246: invokespecial   kotlin/TypeCastException.<init>:(Ljava/lang/String;)V
        //   249: goto            253
        //   252: athrow         
        //   253: athrow         
        //   254: checkcast       Ldev/nuker/pyro/mixin/TimerAccessor;
        //   257: goto            261
        //   260: athrow         
        //   261: invokeinterface dev/nuker/pyro/mixin/TimerAccessor.getTickLength:()F
        //   266: goto            270
        //   269: athrow         
        //   270: fdiv           
        //   271: getstatic       dev/nuker/pyro/fc.1:I
        //   274: ifne            282
        //   277: ldc             1585410136
        //   279: goto            284
        //   282: ldc             976616820
        //   284: ldc             86307878
        //   286: ixor           
        //   287: lookupswitch {
        //          -2105672687: 282
        //          1532724350: 812
        //          default: 312
        //        }
        //   312: goto            316
        //   315: athrow         
        //   316: invokestatic    java/lang/Float.valueOf:(F)Ljava/lang/Float;
        //   319: goto            323
        //   322: athrow         
        //   323: aastore        
        //   324: getstatic       dev/nuker/pyro/fc.0:I
        //   327: ifgt            335
        //   330: ldc             1580990247
        //   332: goto            337
        //   335: ldc             -1294352919
        //   337: ldc             200562211
        //   339: ixor           
        //   340: lookupswitch {
        //          1121078435: 335
        //          1439672580: 820
        //          default: 368
        //        }
        //   368: astore          4
        //   370: astore          6
        //   372: iconst_0       
        //   373: istore          5
        //   375: aload_3        
        //   376: aload           4
        //   378: dup            
        //   379: arraylength    
        //   380: goto            384
        //   383: athrow         
        //   384: invokestatic    java/util/Arrays.copyOf:([Ljava/lang/Object;I)[Ljava/lang/Object;
        //   387: goto            391
        //   390: athrow         
        //   391: goto            395
        //   394: athrow         
        //   395: invokestatic    java/lang/String.format:(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
        //   398: goto            402
        //   401: athrow         
        //   402: dup            
        //   403: pop            
        //   404: getstatic       dev/nuker/pyro/fc.c:I
        //   407: ifne            415
        //   410: ldc             247760279
        //   412: goto            417
        //   415: ldc             1091715180
        //   417: ldc             -110878292
        //   419: ixor           
        //   420: lookupswitch {
        //          -1200201280: 448
        //          -140467141: 415
        //          default: 810
        //        }
        //   448: astore          7
        //   450: aload           6
        //   452: aload           7
        //   454: goto            458
        //   457: athrow         
        //   458: invokevirtual   dev/nuker/pyro/fdH.5:(Ljava/lang/String;)V
        //   461: goto            465
        //   464: athrow         
        //   465: aload_0        
        //   466: getfield        dev/nuker/pyro/fdH.c:Ldev/nuker/pyro/f0k;
        //   469: goto            473
        //   472: athrow         
        //   473: invokevirtual   dev/nuker/pyro/f0k.c:()Ljava/lang/Object;
        //   476: goto            480
        //   479: athrow         
        //   480: checkcast       Ljava/lang/Boolean;
        //   483: goto            487
        //   486: athrow         
        //   487: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   490: goto            494
        //   493: athrow         
        //   494: ifeq            656
        //   497: getstatic       dev/nuker/pyro/fc.1:I
        //   500: ifne            508
        //   503: ldc             516284949
        //   505: goto            510
        //   508: ldc             -1144895061
        //   510: ldc             -1667219512
        //   512: ixor           
        //   513: lookupswitch {
        //          -2107253283: 508
        //          660764259: 540
        //          default: 806
        //        }
        //   540: getstatic       dev/nuker/pyro/f0b.c:Ldev/nuker/pyro/f0b;
        //   543: ldc             "\u37d9\ub24c\u848a\uafb0\u6ad9"
        //   545: goto            549
        //   548: athrow         
        //   549: invokestatic    invokestatic   !!! ERROR
        //   552: goto            556
        //   555: athrow         
        //   556: getstatic       dev/nuker/pyro/f07.0:Ldev/nuker/pyro/f07;
        //   559: bipush          50
        //   561: i2f            
        //   562: ldc             500.0
        //   564: ldc             50.0
        //   566: bipush          20
        //   568: i2f            
        //   569: getstatic       dev/nuker/pyro/fc.c:I
        //   572: ifne            580
        //   575: ldc             1887182225
        //   577: goto            582
        //   580: ldc             -1711482220
        //   582: ldc             -1229231515
        //   584: ixor           
        //   585: lookupswitch {
        //          -960006156: 818
        //          564958736: 580
        //          default: 612
        //        }
        //   612: getstatic       dev/nuker/pyro/f04.c:Ldev/nuker/pyro/f04;
        //   615: dup            
        //   616: pop            
        //   617: goto            621
        //   620: athrow         
        //   621: invokevirtual   dev/nuker/pyro/f04.c:()F
        //   624: goto            628
        //   627: athrow         
        //   628: fdiv           
        //   629: fmul           
        //   630: goto            634
        //   633: athrow         
        //   634: invokestatic    kotlin/ranges/RangesKt.coerceAtMost:(FF)F
        //   637: goto            641
        //   640: athrow         
        //   641: fdiv           
        //   642: goto            646
        //   645: athrow         
        //   646: invokevirtual   dev/nuker/pyro/f0b.c:(Ljava/lang/String;Ldev/nuker/pyro/f07;F)V
        //   649: goto            653
        //   652: athrow         
        //   653: goto            803
        //   656: getstatic       dev/nuker/pyro/fc.0:I
        //   659: ifgt            667
        //   662: ldc             1324539464
        //   664: goto            669
        //   667: ldc             182407623
        //   669: ldc             1365444184
        //   671: ixor           
        //   672: lookupswitch {
        //          529651728: 814
        //          1360119260: 667
        //          default: 700
        //        }
        //   700: getstatic       dev/nuker/pyro/f0b.c:Ldev/nuker/pyro/f0b;
        //   703: ldc             "\u37d9\ub24c\u848a\uafb0\u6ad9"
        //   705: getstatic       dev/nuker/pyro/fc.0:I
        //   708: ifgt            716
        //   711: ldc             -102199419
        //   713: goto            718
        //   716: ldc             -1116882600
        //   718: ldc             -99180534
        //   720: ixor           
        //   721: lookupswitch {
        //          37589870: 716
        //          66989967: 808
        //          default: 748
        //        }
        //   748: goto            752
        //   751: athrow         
        //   752: invokestatic    invokestatic   !!! ERROR
        //   755: goto            759
        //   758: athrow         
        //   759: getstatic       dev/nuker/pyro/f07.0:Ldev/nuker/pyro/f07;
        //   762: aload_0        
        //   763: getfield        dev/nuker/pyro/fdH.c:Ldev/nuker/pyro/f0m;
        //   766: goto            770
        //   769: athrow         
        //   770: invokevirtual   dev/nuker/pyro/f0m.c:()Ljava/lang/Object;
        //   773: goto            777
        //   776: athrow         
        //   777: checkcast       Ljava/lang/Number;
        //   780: goto            784
        //   783: athrow         
        //   784: invokevirtual   java/lang/Number.doubleValue:()D
        //   787: goto            791
        //   790: athrow         
        //   791: d2f            
        //   792: goto            796
        //   795: athrow         
        //   796: invokevirtual   dev/nuker/pyro/f0b.c:(Ljava/lang/String;Ldev/nuker/pyro/f07;F)V
        //   799: goto            803
        //   802: athrow         
        //   803: return         
        //   804: aconst_null    
        //   805: athrow         
        //   806: aconst_null    
        //   807: athrow         
        //   808: aconst_null    
        //   809: athrow         
        //   810: aconst_null    
        //   811: athrow         
        //   812: aconst_null    
        //   813: athrow         
        //   814: aconst_null    
        //   815: athrow         
        //   816: aconst_null    
        //   817: athrow         
        //   818: aconst_null    
        //   819: athrow         
        //   820: aconst_null    
        //   821: athrow         
        //   822: pop            
        //   823: goto            24
        //   826: pop            
        //   827: aconst_null    
        //   828: goto            822
        //   831: dup            
        //   832: ifnull          822
        //   835: checkcast       Ljava/lang/Throwable;
        //   838: athrow         
        //   839: dup            
        //   840: ifnull          826
        //   843: checkcast       Ljava/lang/Throwable;
        //   846: athrow         
        //   847: aconst_null    
        //   848: athrow         
        //    StackMapTable: 00 88 FF 00 03 00 03 07 00 03 07 00 E6 07 00 7C 00 01 07 00 32 FA 00 04 FF 00 0B 00 00 00 01 07 00 32 FD 00 03 07 00 03 07 00 E6 0C 41 01 1C FF 00 11 00 03 07 00 03 07 00 E6 07 00 7C 00 02 07 00 03 07 00 70 FF 00 01 00 03 07 00 03 07 00 E6 07 00 7C 00 03 07 00 03 07 00 70 01 FF 00 1B 00 03 07 00 03 07 00 E6 07 00 7C 00 02 07 00 03 07 00 70 42 07 00 32 FF 00 00 00 03 07 00 03 07 00 E6 07 00 7C 00 02 07 00 03 07 00 70 45 07 00 32 FF 00 00 00 03 07 00 03 07 00 E6 07 00 7C 00 02 07 00 03 07 00 70 FF 00 10 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 06 07 00 03 07 00 E8 07 00 E8 01 02 07 00 EA FF 00 04 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 06 07 00 03 07 00 E8 07 00 E8 01 02 07 00 EA FF 00 01 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 07 07 00 03 07 00 E8 07 00 E8 01 02 07 00 EA 01 FF 00 18 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 06 07 00 03 07 00 E8 07 00 E8 01 02 07 00 EA 48 07 00 29 FF 00 00 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 09 07 00 03 07 00 E8 07 00 E8 01 02 07 00 EA 08 00 B0 08 00 B0 07 00 70 45 07 00 32 FF 00 00 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 09 07 00 03 07 00 E8 07 00 E8 01 02 07 00 EA 08 00 B0 08 00 B0 07 00 70 42 07 00 32 FF 00 00 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 09 07 00 03 07 00 E8 07 00 E8 01 02 07 00 EA 08 00 B0 08 00 B0 07 00 70 45 07 00 32 FF 00 00 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 07 07 00 03 07 00 E8 07 00 E8 01 02 07 00 EA 07 00 8F FF 00 00 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 06 07 00 03 07 00 E8 07 00 E8 01 02 07 00 EA 45 07 00 29 FF 00 00 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 06 07 00 03 07 00 E8 07 00 E8 01 02 07 00 96 47 07 00 32 FF 00 00 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 06 07 00 03 07 00 E8 07 00 E8 01 02 07 00 EC 4C 07 00 77 FF 00 00 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 09 07 00 03 07 00 E8 07 00 E8 01 02 07 00 EC 08 00 E1 08 00 E1 07 00 70 45 07 00 32 FF 00 00 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 09 07 00 03 07 00 E8 07 00 E8 01 02 07 00 EC 08 00 E1 08 00 E1 07 00 70 FF 00 02 00 00 00 01 07 00 32 FF 00 00 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 09 07 00 03 07 00 E8 07 00 E8 01 02 07 00 EC 08 00 E1 08 00 E1 07 00 70 45 07 00 32 FF 00 00 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 07 07 00 03 07 00 E8 07 00 E8 01 02 07 00 EC 07 00 8F FF 00 00 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 06 07 00 03 07 00 E8 07 00 E8 01 02 07 00 EC 45 07 00 0F FF 00 00 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 06 07 00 03 07 00 E8 07 00 E8 01 02 07 00 9E 47 07 00 32 FF 00 00 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 06 07 00 03 07 00 E8 07 00 E8 01 02 02 FF 00 0B 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 05 07 00 03 07 00 E8 07 00 E8 01 02 FF 00 01 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 06 07 00 03 07 00 E8 07 00 E8 01 02 01 FF 00 1B 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 05 07 00 03 07 00 E8 07 00 E8 01 02 FF 00 02 00 00 00 01 07 00 32 FF 00 00 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 05 07 00 03 07 00 E8 07 00 E8 01 02 45 07 00 32 FF 00 00 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 05 07 00 03 07 00 E8 07 00 E8 01 07 00 A7 FF 00 0B 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 02 07 00 03 07 00 E8 FF 00 01 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 03 07 00 03 07 00 E8 01 FF 00 1E 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 02 07 00 03 07 00 E8 FF 00 0E 00 07 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 00 01 07 00 32 FF 00 00 00 07 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 00 03 07 00 70 07 00 E8 01 45 07 00 32 FF 00 00 00 07 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 00 02 07 00 70 07 00 E8 42 07 00 32 FF 00 00 00 07 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 00 02 07 00 70 07 00 E8 45 07 00 32 40 07 00 70 4C 07 00 70 FF 00 01 00 07 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 00 02 07 00 70 01 5E 07 00 70 FF 00 08 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 01 07 00 32 FF 00 00 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 02 07 00 03 07 00 70 45 07 00 32 00 46 07 00 1D 40 07 00 C2 45 07 00 32 40 07 00 72 45 07 00 2B 40 07 00 C5 45 07 00 32 40 01 0D 41 01 1D 47 07 00 32 FF 00 00 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 02 07 00 45 07 00 70 45 07 00 32 FF 00 00 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 02 07 00 45 07 00 70 FF 00 17 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 07 07 00 45 07 00 70 07 00 57 02 02 02 02 FF 00 01 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 08 07 00 45 07 00 70 07 00 57 02 02 02 02 01 FF 00 1D 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 07 07 00 45 07 00 70 07 00 57 02 02 02 02 FF 00 07 00 00 00 01 07 00 32 FF 00 00 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 08 07 00 45 07 00 70 07 00 57 02 02 02 02 07 00 D3 45 07 00 32 FF 00 00 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 08 07 00 45 07 00 70 07 00 57 02 02 02 02 02 44 07 00 21 FF 00 00 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 06 07 00 45 07 00 70 07 00 57 02 02 02 45 07 00 32 FF 00 00 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 05 07 00 45 07 00 70 07 00 57 02 02 FF 00 03 00 00 00 01 07 00 32 FF 00 00 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 04 07 00 45 07 00 70 07 00 57 02 45 07 00 32 00 02 0A 41 01 1E FF 00 0F 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 02 07 00 45 07 00 70 FF 00 01 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 03 07 00 45 07 00 70 01 FF 00 1D 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 02 07 00 45 07 00 70 42 07 00 32 FF 00 00 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 02 07 00 45 07 00 70 45 07 00 32 FF 00 00 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 02 07 00 45 07 00 70 49 07 00 25 FF 00 00 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 04 07 00 45 07 00 70 07 00 57 07 00 5E 45 07 00 32 FF 00 00 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 04 07 00 45 07 00 70 07 00 57 07 00 72 45 07 00 32 FF 00 00 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 04 07 00 45 07 00 70 07 00 57 07 00 63 45 07 00 32 FF 00 00 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 04 07 00 45 07 00 70 07 00 57 03 43 07 00 32 FF 00 00 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 04 07 00 45 07 00 70 07 00 57 02 45 07 00 32 00 FF 00 00 00 02 07 00 03 07 00 E6 00 00 FF 00 01 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 00 FF 00 01 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 02 07 00 45 07 00 70 FF 00 01 00 07 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 00 01 07 00 70 FF 00 01 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 05 07 00 03 07 00 E8 07 00 E8 01 02 FF 00 01 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 00 FF 00 01 00 03 07 00 03 07 00 E6 07 00 7C 00 02 07 00 03 07 00 70 FF 00 01 00 08 07 00 03 07 00 E6 07 00 7C 07 00 70 07 00 E8 01 07 00 03 07 00 70 00 07 07 00 45 07 00 70 07 00 57 02 02 02 02 FF 00 01 00 04 07 00 03 07 00 E6 07 00 7C 07 00 70 00 02 07 00 03 07 00 E8 FF 00 01 00 02 07 00 03 07 00 E6 00 01 07 00 32 43 05 44 07 00 32 47 05 FF 00 07 00 03 07 00 03 07 00 E6 07 00 7C 00 01 07 00 32
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     831    839    Ljava/lang/ClassCastException;
        //  831    839    831    839    Any
        //  847    849    3      8      Any
        //  119    126    126    127    Any
        //  119    126    119    120    Ljava/lang/NumberFormatException;
        //  120    126    3      8      Any
        //  119    126    119    120    Ljava/lang/NegativeArraySizeException;
        //  120    126    119    120    Any
        //  185    192    192    193    Any
        //  185    192    185    186    Ljava/lang/IllegalArgumentException;
        //  185    192    3      8      Any
        //  186    192    185    186    Ljava/lang/ClassCastException;
        //  185    192    185    186    Ljava/lang/RuntimeException;
        //  196    203    203    204    Any
        //  196    203    3      8      Ljava/lang/AssertionError;
        //  197    203    3      8      Ljava/lang/IllegalArgumentException;
        //  197    203    203    204    Any
        //  197    203    196    197    Any
        //  211    220    220    221    Any
        //  211    220    211    212    Ljava/lang/UnsupportedOperationException;
        //  211    220    211    212    Ljava/util/ConcurrentModificationException;
        //  212    220    3      8      Any
        //  211    220    220    221    Any
        //  234    241    241    242    Any
        //  235    241    3      8      Ljava/lang/UnsupportedOperationException;
        //  234    241    234    235    Ljava/lang/ClassCastException;
        //  234    241    241    242    Any
        //  235    241    3      8      Any
        //  246    252    252    253    Any
        //  246    252    252    253    Ljava/lang/ArithmeticException;
        //  246    252    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  246    252    252    253    Ljava/lang/StringIndexOutOfBoundsException;
        //  246    252    3      8      Any
        //  260    269    269    270    Any
        //  261    269    260    261    Ljava/lang/NegativeArraySizeException;
        //  261    269    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  261    269    3      8      Ljava/lang/RuntimeException;
        //  261    269    3      8      Ljava/lang/ArithmeticException;
        //  316    322    322    323    Any
        //  316    322    322    323    Ljava/lang/NumberFormatException;
        //  316    322    322    323    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  316    322    322    323    Ljava/lang/NumberFormatException;
        //  316    322    322    323    Any
        //  383    390    390    391    Any
        //  383    390    383    384    Any
        //  384    390    3      8      Any
        //  384    390    383    384    Ljava/util/NoSuchElementException;
        //  383    390    3      8      Any
        //  394    401    401    402    Any
        //  394    401    3      8      Any
        //  394    401    401    402    Any
        //  395    401    394    395    Ljava/lang/ClassCastException;
        //  394    401    394    395    Any
        //  457    464    464    465    Any
        //  457    464    457    458    Any
        //  457    464    464    465    Ljava/lang/NullPointerException;
        //  457    464    3      8      Any
        //  457    464    457    458    Any
        //  472    479    479    480    Any
        //  473    479    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  472    479    3      8      Ljava/lang/AssertionError;
        //  473    479    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  472    479    472    473    Ljava/lang/NumberFormatException;
        //  486    493    493    494    Any
        //  487    493    493    494    Any
        //  486    493    493    494    Any
        //  487    493    493    494    Any
        //  487    493    486    487    Ljava/lang/ArithmeticException;
        //  548    555    555    556    Any
        //  549    555    555    556    Any
        //  548    555    3      8      Any
        //  548    555    548    549    Any
        //  549    555    555    556    Any
        //  621    627    627    628    Any
        //  621    627    627    628    Ljava/lang/RuntimeException;
        //  621    627    3      8      Any
        //  621    627    627    628    Any
        //  621    627    3      8      Ljava/lang/NegativeArraySizeException;
        //  633    640    640    641    Any
        //  634    640    3      8      Any
        //  634    640    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  634    640    633    634    Ljava/lang/NullPointerException;
        //  633    640    3      8      Any
        //  646    652    652    653    Any
        //  646    652    652    653    Any
        //  646    652    652    653    Any
        //  646    652    652    653    Ljava/lang/EnumConstantNotPresentException;
        //  646    652    652    653    Any
        //  751    758    758    759    Any
        //  752    758    751    752    Any
        //  751    758    3      8      Ljava/lang/RuntimeException;
        //  751    758    3      8      Any
        //  752    758    751    752    Any
        //  769    776    776    777    Any
        //  770    776    3      8      Ljava/lang/ArithmeticException;
        //  769    776    776    777    Ljava/lang/ArithmeticException;
        //  770    776    776    777    Any
        //  770    776    769    770    Ljava/util/NoSuchElementException;
        //  783    790    790    791    Any
        //  784    790    783    784    Ljava/lang/StringIndexOutOfBoundsException;
        //  783    790    783    784    Any
        //  783    790    790    791    Any
        //  783    790    3      8      Any
        //  795    802    802    803    Any
        //  795    802    802    803    Any
        //  795    802    795    796    Any
        //  795    802    3      8      Any
        //  795    802    802    803    Ljava/lang/ClassCastException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:617)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @NotNull
    public f0k c() {
        return fez.7p(this, 1491669916);
    }
    
    public fdH() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: ldc             "\u37d9\ub24c\u848a\uada1\u68e8"
        //     3: invokestatic    invokestatic   !!! ERROR
        //     6: ldc             "\u37f9\ub24c\u848a\uada1\u68e8"
        //     8: getstatic       dev/nuker/pyro/fc.1:I
        //    11: ifne            19
        //    14: ldc             429080470
        //    16: goto            21
        //    19: ldc             1651471591
        //    21: ldc             -1304909909
        //    23: ixor           
        //    24: lookupswitch {
        //          -1414817731: 19
        //          -799550644: 52
        //          default: 398
        //        }
        //    52: invokestatic    invokestatic   !!! ERROR
        //    55: ldc             "\u37ee\ub24d\u8486\uadaa\u68fd\u532d\u7e00\u6384\uc2cb\uac19\u9134\u1307\ucbfd\u7107\u9f2e\u472e\ub205\u4608\u014b\u08cd\u183d\ufe84\u6053\u885d\u39da\u37ac\u7fbb\ua3fc\ud1f0\u7dc3\u4ee6\u6baa"
        //    57: getstatic       dev/nuker/pyro/fc.1:I
        //    60: ifne            68
        //    63: ldc             -1422443520
        //    65: goto            71
        //    68: ldc_w           -646457174
        //    71: ldc_w           -1399406972
        //    74: ixor           
        //    75: lookupswitch {
        //          128025220: 68
        //          1977706030: 100
        //          default: 394
        //        }
        //   100: invokestatic    invokestatic   !!! ERROR
        //   103: invokespecial   dev/nuker/pyro/fQ.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   106: getstatic       dev/nuker/pyro/fc.c:I
        //   109: ifne            118
        //   112: ldc_w           981907344
        //   115: goto            121
        //   118: ldc_w           124563969
        //   121: ldc_w           836557164
        //   124: ixor           
        //   125: lookupswitch {
        //          -458473446: 118
        //          190476028: 388
        //          default: 152
        //        }
        //   152: aload_0        
        //   153: aload_0        
        //   154: new             Ldev/nuker/pyro/f0m;
        //   157: dup            
        //   158: ldc_w           "\u37c0\ub250\u848b\uadb0\u68f3\u5338\u7e4c\u6399\uc2c6\uac0e"
        //   161: invokestatic    invokestatic   !!! ERROR
        //   164: ldc_w           "\u37e0\ub250\u848b\uadb0\u68f3\u5338\u7e4c\u6399\uc2c6\uac0e"
        //   167: invokestatic    invokestatic   !!! ERROR
        //   170: aconst_null    
        //   171: ldc2_w          2.0
        //   174: ldc2_w          0.1
        //   177: ldc2_w          10.0
        //   180: dconst_0       
        //   181: bipush          64
        //   183: aconst_null    
        //   184: invokespecial   dev/nuker/pyro/f0m.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;DDDDILkotlin/jvm/internal/DefaultConstructorMarker;)V
        //   187: checkcast       Ldev/nuker/pyro/f0w;
        //   190: invokevirtual   dev/nuker/pyro/fdH.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   193: checkcast       Ldev/nuker/pyro/f0m;
        //   196: putfield        dev/nuker/pyro/fdH.c:Ldev/nuker/pyro/f0m;
        //   199: aload_0        
        //   200: aload_0        
        //   201: new             Ldev/nuker/pyro/f0k;
        //   204: dup            
        //   205: ldc_w           "\u37d9\ub255\u8494\uad97\u68e3\u5326\u7e43"
        //   208: getstatic       dev/nuker/pyro/fc.1:I
        //   211: ifne            220
        //   214: ldc_w           687867669
        //   217: goto            223
        //   220: ldc_w           -1819683526
        //   223: ldc_w           944598117
        //   226: ixor           
        //   227: lookupswitch {
        //          -1413170849: 252
        //          290286448: 220
        //          default: 390
        //        }
        //   252: invokestatic    invokestatic   !!! ERROR
        //   255: ldc_w           "\u37f9\ub275\u84b4\uad97\u68e3\u5326\u7e43"
        //   258: invokestatic    invokestatic   !!! ERROR
        //   261: aconst_null    
        //   262: iconst_0       
        //   263: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   266: checkcast       Ldev/nuker/pyro/f0w;
        //   269: getstatic       dev/nuker/pyro/fc.c:I
        //   272: ifne            281
        //   275: ldc_w           1011358335
        //   278: goto            284
        //   281: ldc_w           -1179598832
        //   284: ldc_w           -1298895030
        //   287: ixor           
        //   288: lookupswitch {
        //          -1898154699: 392
        //          1186509532: 281
        //          default: 316
        //        }
        //   316: invokevirtual   dev/nuker/pyro/fdH.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   319: checkcast       Ldev/nuker/pyro/f0k;
        //   322: putfield        dev/nuker/pyro/fdH.c:Ldev/nuker/pyro/f0k;
        //   325: aload_0        
        //   326: getfield        dev/nuker/pyro/fdH.c:Ldev/nuker/pyro/f0m;
        //   329: new             Ldev/nuker/pyro/fdG;
        //   332: dup            
        //   333: aload_0        
        //   334: invokespecial   dev/nuker/pyro/fdG.<init>:(Ldev/nuker/pyro/fdH;)V
        //   337: checkcast       Ljava/util/function/Consumer;
        //   340: getstatic       dev/nuker/pyro/fc.0:I
        //   343: ifgt            352
        //   346: ldc_w           1719443884
        //   349: goto            355
        //   352: ldc_w           83587158
        //   355: ldc_w           -190421638
        //   358: ixor           
        //   359: lookupswitch {
        //          -1831156522: 396
        //          -284614111: 352
        //          default: 384
        //        }
        //   384: invokevirtual   dev/nuker/pyro/f0m.c:(Ljava/util/function/Consumer;)V
        //   387: return         
        //   388: aconst_null    
        //   389: athrow         
        //   390: aconst_null    
        //   391: athrow         
        //   392: aconst_null    
        //   393: athrow         
        //   394: aconst_null    
        //   395: athrow         
        //   396: aconst_null    
        //   397: athrow         
        //   398: aconst_null    
        //   399: athrow         
        //    StackMapTable: 00 18 FF 00 13 00 01 06 00 03 06 07 00 70 07 00 70 FF 00 01 00 01 06 00 04 06 07 00 70 07 00 70 01 FF 00 1E 00 01 06 00 03 06 07 00 70 07 00 70 FF 00 0F 00 01 06 00 04 06 07 00 70 07 00 70 07 00 70 FF 00 02 00 01 06 00 05 06 07 00 70 07 00 70 07 00 70 01 FF 00 1C 00 01 06 00 04 06 07 00 70 07 00 70 07 00 70 FF 00 11 00 01 07 00 03 00 00 42 01 1E FF 00 43 00 01 07 00 03 00 05 07 00 03 07 00 03 08 00 C9 08 00 C9 07 00 70 FF 00 02 00 01 07 00 03 00 06 07 00 03 07 00 03 08 00 C9 08 00 C9 07 00 70 01 FF 00 1C 00 01 07 00 03 00 05 07 00 03 07 00 03 08 00 C9 08 00 C9 07 00 70 FF 00 1C 00 01 07 00 03 00 03 07 00 03 07 00 03 07 01 16 FF 00 02 00 01 07 00 03 00 04 07 00 03 07 00 03 07 01 16 01 FF 00 1F 00 01 07 00 03 00 03 07 00 03 07 00 03 07 01 16 FF 00 23 00 01 07 00 03 00 02 07 00 5E 07 01 2D FF 00 02 00 01 07 00 03 00 03 07 00 5E 07 01 2D 01 FF 00 1C 00 01 07 00 03 00 02 07 00 5E 07 01 2D 03 FF 00 01 00 01 07 00 03 00 05 07 00 03 07 00 03 08 00 C9 08 00 C9 07 00 70 FF 00 01 00 01 07 00 03 00 03 07 00 03 07 00 03 07 01 16 FF 00 01 00 01 06 00 04 06 07 00 70 07 00 70 07 00 70 FF 00 01 00 01 07 00 03 00 02 07 00 5E 07 01 2D FF 00 01 00 01 06 00 03 06 07 00 70 07 00 70
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @NotNull
    public f0m 0() {
        return fez.9g(this, 1398563413);
    }
}
