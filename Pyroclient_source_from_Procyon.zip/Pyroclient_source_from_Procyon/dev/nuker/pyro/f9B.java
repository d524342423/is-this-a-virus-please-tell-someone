// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

public enum f9B
{
    public static f9B c;
    public static f9B 0;
    public static f9B 1;
    public static f9B[] c;
    
    public f9B(final String name, final int ordinal) {
        while (true) {
            Label_0014: {
                if (fc.c == 0) {
                    n = 1357245178;
                    break Label_0014;
                }
                n = -233858478;
            }
            switch (n ^ 0x317F2326) {
                case 1637534172: {
                    continue;
                }
                case -1016022668: {
                    super(name, ordinal);
                }
                default: {
                    throw null;
                }
            }
            break;
        }
    }
    
    public static f9B c(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          67
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            59
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            51
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: ldc             Ldev/nuker/pyro/f9B;.class
        //    26: aload_0        
        //    27: goto            31
        //    30: athrow         
        //    31: invokestatic    java/lang/Enum.valueOf:(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
        //    34: goto            38
        //    37: athrow         
        //    38: checkcast       Ldev/nuker/pyro/f9B;
        //    41: areturn        
        //    42: pop            
        //    43: goto            24
        //    46: pop            
        //    47: aconst_null    
        //    48: goto            42
        //    51: dup            
        //    52: ifnull          42
        //    55: checkcast       Ljava/lang/Throwable;
        //    58: athrow         
        //    59: dup            
        //    60: ifnull          46
        //    63: checkcast       Ljava/lang/Throwable;
        //    66: athrow         
        //    67: aconst_null    
        //    68: athrow         
        //    StackMapTable: 00 0D 43 07 00 29 04 FF 00 0B 00 00 00 01 07 00 23 FC 00 03 07 00 18 45 07 00 23 FF 00 00 00 01 07 00 18 00 02 07 00 2B 07 00 18 45 07 00 23 40 07 00 05 43 07 00 23 43 05 44 07 00 23 47 05 47 07 00 29
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     51     59     Any
        //  51     59     51     59     Any
        //  67     69     3      8      Ljava/util/ConcurrentModificationException;
        //  30     37     37     38     Any
        //  30     37     3      8      Ljava/lang/UnsupportedOperationException;
        //  31     37     37     38     Any
        //  30     37     30     31     Any
        //  31     37     30     31     Ljava/lang/ArithmeticException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 27 out of bounds for length 27
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ldc             "\u3cc0\ub244\u8fc1\ua174\u53f3\u5801"
        //     6: invokestatic    invokestatic   !!! ERROR
        //     9: iconst_0       
        //    10: invokespecial   dev/nuker/pyro/f9B.<init>:(Ljava/lang/String;I)V
        //    13: getstatic       dev/nuker/pyro/fc.0:I
        //    16: ifgt            24
        //    19: ldc             -583163335
        //    21: goto            26
        //    24: ldc             1472295117
        //    26: ldc             -618995245
        //    28: ixor           
        //    29: lookupswitch {
        //          -234843737: 24
        //          103236586: 160
        //          default: 56
        //        }
        //    56: putstatic       dev/nuker/pyro/f9B.c:Ldev/nuker/pyro/f9B;
        //    59: new             Ldev/nuker/pyro/f9B;
        //    62: dup            
        //    63: ldc             "\u3cd1\ub24b\u8fd6\ua176"
        //    65: invokestatic    invokestatic   !!! ERROR
        //    68: iconst_1       
        //    69: invokespecial   dev/nuker/pyro/f9B.<init>:(Ljava/lang/String;I)V
        //    72: putstatic       dev/nuker/pyro/f9B.0:Ldev/nuker/pyro/f9B;
        //    75: new             Ldev/nuker/pyro/f9B;
        //    78: dup            
        //    79: ldc             "\u3cd1\ub264\u8fe1"
        //    81: invokestatic    invokestatic   !!! ERROR
        //    84: iconst_2       
        //    85: invokespecial   dev/nuker/pyro/f9B.<init>:(Ljava/lang/String;I)V
        //    88: putstatic       dev/nuker/pyro/f9B.1:Ldev/nuker/pyro/f9B;
        //    91: iconst_3       
        //    92: anewarray       Ldev/nuker/pyro/f9B;
        //    95: dup            
        //    96: iconst_0       
        //    97: getstatic       dev/nuker/pyro/f9B.c:Ldev/nuker/pyro/f9B;
        //   100: aastore        
        //   101: dup            
        //   102: iconst_1       
        //   103: getstatic       dev/nuker/pyro/fc.0:I
        //   106: ifgt            114
        //   109: ldc             -2017071736
        //   111: goto            116
        //   114: ldc             -1455767223
        //   116: ldc             384486741
        //   118: ixor           
        //   119: lookupswitch {
        //          -1859182371: 158
        //          1540622318: 114
        //          default: 144
        //        }
        //   144: getstatic       dev/nuker/pyro/f9B.0:Ldev/nuker/pyro/f9B;
        //   147: aastore        
        //   148: dup            
        //   149: iconst_2       
        //   150: getstatic       dev/nuker/pyro/f9B.1:Ldev/nuker/pyro/f9B;
        //   153: aastore        
        //   154: putstatic       dev/nuker/pyro/f9B.c:[Ldev/nuker/pyro/f9B;
        //   157: return         
        //   158: aconst_null    
        //   159: athrow         
        //   160: aconst_null    
        //   161: athrow         
        //    StackMapTable: 00 08 58 07 00 03 FF 00 01 00 00 00 02 07 00 03 01 5D 07 00 03 FF 00 39 00 00 00 03 07 00 4A 07 00 4A 01 FF 00 01 00 00 00 04 07 00 4A 07 00 4A 01 01 FF 00 1B 00 00 00 03 07 00 4A 07 00 4A 01 FF 00 0D 00 00 00 03 07 00 4A 07 00 4A 01 41 07 00 03
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2695)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
