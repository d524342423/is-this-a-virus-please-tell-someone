// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

public enum f87
{
    public static f87 c;
    public static f87 0;
    public static f87 1;
    public static f87 2;
    public static f87 3;
    public static f87 4;
    public static f87 5;
    public static f87 6;
    public static f87 7;
    public static f87 8;
    public static f87 9;
    public static f87 a;
    public static f87[] c;
    
    public f87(final String name, final int ordinal) {
        while (true) {
            Label_0014: {
                if (fc.0 <= 0) {
                    n = -2091408231;
                    break Label_0014;
                }
                n = -1735383330;
            }
            switch (n ^ 0x30EB434D) {
                case 888746376: {
                    continue;
                }
                default: {
                    super(name, ordinal);
                }
                case -1279465516: {
                    throw null;
                }
            }
            break;
        }
    }
    
    public static f87 c(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          111
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            103
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            95
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: ldc             Ldev/nuker/pyro/f87;.class
        //    26: getstatic       dev/nuker/pyro/fc.0:I
        //    29: ifgt            37
        //    32: ldc             -75534
        //    34: goto            39
        //    37: ldc             -2046927596
        //    39: ldc             1240417425
        //    41: ixor           
        //    42: lookupswitch {
        //          -1894892729: 37
        //          -1240359837: 84
        //          default: 68
        //        }
        //    68: aload_0        
        //    69: goto            73
        //    72: athrow         
        //    73: invokestatic    java/lang/Enum.valueOf:(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
        //    76: goto            80
        //    79: athrow         
        //    80: checkcast       Ldev/nuker/pyro/f87;
        //    83: areturn        
        //    84: aconst_null    
        //    85: athrow         
        //    86: pop            
        //    87: goto            24
        //    90: pop            
        //    91: aconst_null    
        //    92: goto            86
        //    95: dup            
        //    96: ifnull          86
        //    99: checkcast       Ljava/lang/Throwable;
        //   102: athrow         
        //   103: dup            
        //   104: ifnull          90
        //   107: checkcast       Ljava/lang/Throwable;
        //   110: athrow         
        //   111: aconst_null    
        //   112: athrow         
        //    StackMapTable: 00 11 43 07 00 22 04 FF 00 0B 00 00 00 01 07 00 22 FC 00 03 07 00 36 4C 07 00 44 FF 00 01 00 01 07 00 36 00 02 07 00 44 01 5C 07 00 44 FF 00 03 00 00 00 01 07 00 22 FF 00 00 00 01 07 00 36 00 02 07 00 44 07 00 36 45 07 00 22 40 07 00 05 43 07 00 44 41 07 00 46 43 05 44 07 00 46 47 05 47 07 00 22
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     95     103    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  95     103    95     103    Ljava/lang/ArithmeticException;
        //  111    113    3      8      Any
        //  73     79     79     80     Any
        //  73     79     3      8      Any
        //  73     79     79     80     Any
        //  73     79     79     80     Ljava/util/ConcurrentModificationException;
        //  73     79     79     80     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:595)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ldc             "\u3c91\ub24d\u8fe5\ua16b\u53a9"
        //     6: invokestatic    invokestatic   !!! ERROR
        //     9: iconst_0       
        //    10: invokespecial   dev/nuker/pyro/f87.<init>:(Ljava/lang/String;I)V
        //    13: putstatic       dev/nuker/pyro/f87.c:Ldev/nuker/pyro/f87;
        //    16: new             Ldev/nuker/pyro/f87;
        //    19: dup            
        //    20: ldc             "\u3c81\ub257\u8fed\ua166"
        //    22: invokestatic    invokestatic   !!! ERROR
        //    25: iconst_1       
        //    26: invokespecial   dev/nuker/pyro/f87.<init>:(Ljava/lang/String;I)V
        //    29: putstatic       dev/nuker/pyro/f87.0:Ldev/nuker/pyro/f87;
        //    32: new             Ldev/nuker/pyro/f87;
        //    35: dup            
        //    36: ldc             "\u3c82\ub244\u8ffe\ua174\u538b\u5851\u7e41\u68e2"
        //    38: invokestatic    invokestatic   !!! ERROR
        //    41: iconst_2       
        //    42: invokespecial   dev/nuker/pyro/f87.<init>:(Ljava/lang/String;I)V
        //    45: getstatic       dev/nuker/pyro/fc.0:I
        //    48: ifgt            56
        //    51: ldc             1850856981
        //    53: goto            58
        //    56: ldc             -791135648
        //    58: ldc             2140145511
        //    60: ixor           
        //    61: lookupswitch {
        //          297914738: 590
        //          1145123645: 56
        //          default: 88
        //        }
        //    88: putstatic       dev/nuker/pyro/f87.1:Ldev/nuker/pyro/f87;
        //    91: new             Ldev/nuker/pyro/f87;
        //    94: dup            
        //    95: ldc             "\u3c94\ub240\u8fe8"
        //    97: invokestatic    invokestatic   !!! ERROR
        //   100: iconst_3       
        //   101: invokespecial   dev/nuker/pyro/f87.<init>:(Ljava/lang/String;I)V
        //   104: putstatic       dev/nuker/pyro/f87.2:Ldev/nuker/pyro/f87;
        //   107: new             Ldev/nuker/pyro/f87;
        //   110: dup            
        //   111: ldc             "\u3c82\ub244\u8ffe\ua174\u539e\u5846\u7e44"
        //   113: invokestatic    invokestatic   !!! ERROR
        //   116: iconst_4       
        //   117: invokespecial   dev/nuker/pyro/f87.<init>:(Ljava/lang/String;I)V
        //   120: putstatic       dev/nuker/pyro/f87.3:Ldev/nuker/pyro/f87;
        //   123: new             Ldev/nuker/pyro/f87;
        //   126: dup            
        //   127: ldc             "\u3c81\ub257\u8fe9\ua17a\u53a2"
        //   129: invokestatic    invokestatic   !!! ERROR
        //   132: iconst_5       
        //   133: invokespecial   dev/nuker/pyro/f87.<init>:(Ljava/lang/String;I)V
        //   136: putstatic       dev/nuker/pyro/f87.4:Ldev/nuker/pyro/f87;
        //   139: new             Ldev/nuker/pyro/f87;
        //   142: dup            
        //   143: ldc             "\u3c82\ub244\u8ffe\ua174\u538b\u5851\u7e45\u68fe\uce16"
        //   145: invokestatic    invokestatic   !!! ERROR
        //   148: bipush          6
        //   150: invokespecial   dev/nuker/pyro/f87.<init>:(Ljava/lang/String;I)V
        //   153: getstatic       dev/nuker/pyro/fc.0:I
        //   156: ifgt            164
        //   159: ldc             1593900063
        //   161: goto            166
        //   164: ldc             -257043620
        //   166: ldc             -1124081391
        //   168: ixor           
        //   169: lookupswitch {
        //          -1072430569: 164
        //          -469820146: 592
        //          default: 196
        //        }
        //   196: putstatic       dev/nuker/pyro/f87.5:Ldev/nuker/pyro/f87;
        //   199: new             Ldev/nuker/pyro/f87;
        //   202: dup            
        //   203: ldc             "\u3c84\ub249\u8ff9\ua17a"
        //   205: getstatic       dev/nuker/pyro/fc.0:I
        //   208: ifgt            216
        //   211: ldc             -323507180
        //   213: goto            218
        //   216: ldc             1347316551
        //   218: ldc             -1449657008
        //   220: ixor           
        //   221: lookupswitch {
        //          1069743896: 216
        //          1159745860: 586
        //          default: 248
        //        }
        //   248: invokestatic    invokestatic   !!! ERROR
        //   251: bipush          7
        //   253: invokespecial   dev/nuker/pyro/f87.<init>:(Ljava/lang/String;I)V
        //   256: putstatic       dev/nuker/pyro/f87.6:Ldev/nuker/pyro/f87;
        //   259: new             Ldev/nuker/pyro/f87;
        //   262: dup            
        //   263: ldc             "\u3c82\ub244\u8ffe\ua174\u538e\u584f\u7e55\u68fe"
        //   265: invokestatic    invokestatic   !!! ERROR
        //   268: bipush          8
        //   270: invokespecial   dev/nuker/pyro/f87.<init>:(Ljava/lang/String;I)V
        //   273: putstatic       dev/nuker/pyro/f87.7:Ldev/nuker/pyro/f87;
        //   276: new             Ldev/nuker/pyro/f87;
        //   279: dup            
        //   280: ldc             "\u3c87\ub254\u8ff9\ua17e"
        //   282: getstatic       dev/nuker/pyro/fc.1:I
        //   285: ifne            293
        //   288: ldc             50718855
        //   290: goto            295
        //   293: ldc             1851753211
        //   295: ldc             1755213817
        //   297: ixor           
        //   298: lookupswitch {
        //          113372418: 324
        //          1805354878: 293
        //          default: 582
        //        }
        //   324: invokestatic    invokestatic   !!! ERROR
        //   327: bipush          9
        //   329: invokespecial   dev/nuker/pyro/f87.<init>:(Ljava/lang/String;I)V
        //   332: putstatic       dev/nuker/pyro/f87.8:Ldev/nuker/pyro/f87;
        //   335: new             Ldev/nuker/pyro/f87;
        //   338: dup            
        //   339: ldc             "\u3c9f\ub240\u8fe0\ua173\u53a3\u5854"
        //   341: invokestatic    invokestatic   !!! ERROR
        //   344: bipush          10
        //   346: invokespecial   dev/nuker/pyro/f87.<init>:(Ljava/lang/String;I)V
        //   349: getstatic       dev/nuker/pyro/fc.c:I
        //   352: ifne            360
        //   355: ldc             -382987248
        //   357: goto            362
        //   360: ldc             -1268439101
        //   362: ldc             1344838350
        //   364: ixor           
        //   365: lookupswitch {
        //          -1190883618: 360
        //          -464667379: 392
        //          default: 594
        //        }
        //   392: putstatic       dev/nuker/pyro/f87.9:Ldev/nuker/pyro/f87;
        //   395: new             Ldev/nuker/pyro/f87;
        //   398: dup            
        //   399: ldc             "\u3c81\ub24a\u8fe0\ua17b"
        //   401: invokestatic    invokestatic   !!! ERROR
        //   404: bipush          11
        //   406: getstatic       dev/nuker/pyro/fc.c:I
        //   409: ifne            417
        //   412: ldc             378755747
        //   414: goto            419
        //   417: ldc             1009954489
        //   419: ldc             -1362647367
        //   421: ixor           
        //   422: lookupswitch {
        //          -1829435392: 448
        //          -1202389990: 417
        //          default: 584
        //        }
        //   448: invokespecial   dev/nuker/pyro/f87.<init>:(Ljava/lang/String;I)V
        //   451: putstatic       dev/nuker/pyro/f87.a:Ldev/nuker/pyro/f87;
        //   454: bipush          12
        //   456: anewarray       Ldev/nuker/pyro/f87;
        //   459: dup            
        //   460: iconst_0       
        //   461: getstatic       dev/nuker/pyro/f87.c:Ldev/nuker/pyro/f87;
        //   464: aastore        
        //   465: dup            
        //   466: iconst_1       
        //   467: getstatic       dev/nuker/pyro/f87.0:Ldev/nuker/pyro/f87;
        //   470: aastore        
        //   471: dup            
        //   472: iconst_2       
        //   473: getstatic       dev/nuker/pyro/f87.1:Ldev/nuker/pyro/f87;
        //   476: aastore        
        //   477: dup            
        //   478: iconst_3       
        //   479: getstatic       dev/nuker/pyro/f87.2:Ldev/nuker/pyro/f87;
        //   482: aastore        
        //   483: dup            
        //   484: iconst_4       
        //   485: getstatic       dev/nuker/pyro/f87.3:Ldev/nuker/pyro/f87;
        //   488: aastore        
        //   489: dup            
        //   490: iconst_5       
        //   491: getstatic       dev/nuker/pyro/f87.4:Ldev/nuker/pyro/f87;
        //   494: aastore        
        //   495: dup            
        //   496: bipush          6
        //   498: getstatic       dev/nuker/pyro/f87.5:Ldev/nuker/pyro/f87;
        //   501: aastore        
        //   502: dup            
        //   503: bipush          7
        //   505: getstatic       dev/nuker/pyro/f87.6:Ldev/nuker/pyro/f87;
        //   508: aastore        
        //   509: dup            
        //   510: bipush          8
        //   512: getstatic       dev/nuker/pyro/f87.7:Ldev/nuker/pyro/f87;
        //   515: aastore        
        //   516: dup            
        //   517: bipush          9
        //   519: getstatic       dev/nuker/pyro/fc.1:I
        //   522: ifne            530
        //   525: ldc             -1017845906
        //   527: goto            532
        //   530: ldc             1247614143
        //   532: ldc             -247519944
        //   534: ixor           
        //   535: lookupswitch {
        //          -1151192697: 560
        //          845922902: 530
        //          default: 588
        //        }
        //   560: getstatic       dev/nuker/pyro/f87.8:Ldev/nuker/pyro/f87;
        //   563: aastore        
        //   564: dup            
        //   565: bipush          10
        //   567: getstatic       dev/nuker/pyro/f87.9:Ldev/nuker/pyro/f87;
        //   570: aastore        
        //   571: dup            
        //   572: bipush          11
        //   574: getstatic       dev/nuker/pyro/f87.a:Ldev/nuker/pyro/f87;
        //   577: aastore        
        //   578: putstatic       dev/nuker/pyro/f87.c:[Ldev/nuker/pyro/f87;
        //   581: return         
        //   582: aconst_null    
        //   583: athrow         
        //   584: aconst_null    
        //   585: athrow         
        //   586: aconst_null    
        //   587: athrow         
        //   588: aconst_null    
        //   589: athrow         
        //   590: aconst_null    
        //   591: athrow         
        //   592: aconst_null    
        //   593: athrow         
        //   594: aconst_null    
        //   595: athrow         
        //    StackMapTable: 00 1C 78 07 00 03 FF 00 01 00 00 00 02 07 00 03 01 5D 07 00 03 F7 00 4B 07 00 03 FF 00 01 00 00 00 02 07 00 03 01 5D 07 00 03 FF 00 13 00 00 00 03 08 00 C7 08 00 C7 07 00 36 FF 00 01 00 00 00 04 08 00 C7 08 00 C7 07 00 36 01 FF 00 1D 00 00 00 03 08 00 C7 08 00 C7 07 00 36 FF 00 2C 00 00 00 03 08 01 14 08 01 14 07 00 36 FF 00 01 00 00 00 04 08 01 14 08 01 14 07 00 36 01 FF 00 1C 00 00 00 03 08 01 14 08 01 14 07 00 36 63 07 00 03 FF 00 01 00 00 00 02 07 00 03 01 5D 07 00 03 FF 00 18 00 00 00 04 08 01 8B 08 01 8B 07 00 36 01 FF 00 01 00 00 00 05 08 01 8B 08 01 8B 07 00 36 01 01 FF 00 1C 00 00 00 04 08 01 8B 08 01 8B 07 00 36 01 FF 00 51 00 00 00 03 07 00 25 07 00 25 01 FF 00 01 00 00 00 04 07 00 25 07 00 25 01 01 FF 00 1B 00 00 00 03 07 00 25 07 00 25 01 FF 00 15 00 00 00 03 08 01 14 08 01 14 07 00 36 FF 00 01 00 00 00 04 08 01 8B 08 01 8B 07 00 36 01 FF 00 01 00 00 00 03 08 00 C7 08 00 C7 07 00 36 FF 00 01 00 00 00 03 07 00 25 07 00 25 01 41 07 00 03 41 07 00 03 41 07 00 03
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2695)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
