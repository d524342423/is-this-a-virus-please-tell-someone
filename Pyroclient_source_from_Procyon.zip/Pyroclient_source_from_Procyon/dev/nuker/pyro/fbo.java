// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import dev.nuker.pyro.security.inject.LauncherEventHide;

public class fbo extends fQ
{
    public f0k c;
    
    public fbo() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: ldc             "\u37da\ub244\u8493\uada1\u68d3\u5323\u7e4f\u639d\uc2c6\uac26\u9179"
        //     3: getstatic       dev/nuker/pyro/fc.0:I
        //     6: ifgt            14
        //     9: ldc             -594008738
        //    11: goto            16
        //    14: ldc             -1800042197
        //    16: ldc             1566182385
        //    18: ixor           
        //    19: lookupswitch {
        //          -2117980497: 181
        //          1794082796: 14
        //          default: 44
        //        }
        //    44: invokestatic    invokestatic   !!! ERROR
        //    47: ldc             "\u37fa\ub244\u8493\uada1\u68f3\u5323\u7e4f\u639d\uc2c6\uac26\u9179"
        //    49: invokestatic    invokestatic   !!! ERROR
        //    52: ldc             "\u37f0\ub24c\u848d\uadb4\u68cf\u5330\u7e59\u639a\uc283\uac23\u917f\u130d\ucbed\u7100\u9f16\u472a\ub251\u460c\u0143\u08fd\u1824\ufed7\u601e\u8843\u39e9\u37aa\u7ff3\ua3b6\ud1f4\u7df7\u4eff\u6ba7\u7e8a\u9738\uc819\u49ba\ufde5\u1a19\u1855\u4574\u6c80\uac42\u87a1\uf928\ub368\uaea5\u4c23\u3595\u4a27\uadbe\u72cd\u9165\u39d6\u6f88\uf914\u0461\u7a5fx\u9f33\udc4e\ued15\u4c7e"
        //    54: invokestatic    invokestatic   !!! ERROR
        //    57: iconst_1       
        //    58: invokespecial   dev/nuker/pyro/fQ.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //    61: aload_0        
        //    62: new             Ldev/nuker/pyro/f0k;
        //    65: dup            
        //    66: ldc             "\u37d7\ub24a\u8492\uadab\u68d1"
        //    68: invokestatic    invokestatic   !!! ERROR
        //    71: ldc             "\u37f7\ub24a\u8492\uadab\u68d1"
        //    73: invokestatic    invokestatic   !!! ERROR
        //    76: aconst_null    
        //    77: iconst_1       
        //    78: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //    81: putfield        dev/nuker/pyro/fbo.c:Ldev/nuker/pyro/f0k;
        //    84: getstatic       dev/nuker/pyro/fc.0:I
        //    87: ifgt            95
        //    90: ldc             -24656295
        //    92: goto            97
        //    95: ldc             1731720423
        //    97: ldc             -2126217407
        //    99: ixor           
        //   100: lookupswitch {
        //          -757628815: 95
        //          2143533336: 183
        //          default: 128
        //        }
        //   128: aload_0        
        //   129: getstatic       dev/nuker/pyro/fc.1:I
        //   132: ifne            140
        //   135: ldc             1710310259
        //   137: goto            142
        //   140: ldc             1538469535
        //   142: ldc             754512649
        //   144: ixor           
        //   145: lookupswitch {
        //          1225371770: 185
        //          1350743053: 140
        //          default: 172
        //        }
        //   172: aload_0        
        //   173: getfield        dev/nuker/pyro/fbo.c:Ldev/nuker/pyro/f0k;
        //   176: invokevirtual   dev/nuker/pyro/fbo.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   179: pop            
        //   180: return         
        //   181: aconst_null    
        //   182: athrow         
        //   183: aconst_null    
        //   184: athrow         
        //   185: aconst_null    
        //   186: athrow         
        //    StackMapTable: 00 0C FF 00 0E 00 01 06 00 02 06 07 00 37 FF 00 01 00 01 06 00 03 06 07 00 37 01 FF 00 1B 00 01 06 00 02 06 07 00 37 FF 00 32 00 01 07 00 03 00 00 41 01 1E 4B 07 00 03 FF 00 01 00 01 07 00 03 00 02 07 00 03 01 5D 07 00 03 FF 00 08 00 01 06 00 02 06 07 00 37 FF 00 01 00 01 07 00 03 00 00 41 07 00 03
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2695)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        throw t;
    }
    
    @f0g
    @LauncherEventHide
    public void c(final f4e p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          1430
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            1422
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            1414
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: goto            29
        //    28: athrow         
        //    29: invokevirtual   dev/nuker/pyro/f4e.c:()Ldev/nuker/pyro/f41;
        //    32: goto            36
        //    35: athrow         
        //    36: getstatic       dev/nuker/pyro/fc.0:I
        //    39: ifgt            47
        //    42: ldc             741068998
        //    44: goto            49
        //    47: ldc             1520009929
        //    49: ldc             -1379090152
        //    51: ixor           
        //    52: lookupswitch {
        //          -2115563042: 1373
        //          1183651681: 47
        //          default: 80
        //        }
        //    80: getstatic       dev/nuker/pyro/f41.c:Ldev/nuker/pyro/f41;
        //    83: if_acmpne       1366
        //    86: aload_1        
        //    87: goto            91
        //    90: athrow         
        //    91: invokevirtual   dev/nuker/pyro/f4e.c:()Lnet/minecraft/network/Packet;
        //    94: goto            98
        //    97: athrow         
        //    98: instanceof      Lnet/minecraft/network/play/server/SPacketChat;
        //   101: ifeq            1366
        //   104: getstatic       dev/nuker/pyro/fc.0:I
        //   107: ifgt            115
        //   110: ldc             1393565363
        //   112: goto            117
        //   115: ldc             -26116753
        //   117: ldc             -574754613
        //   119: ixor           
        //   120: lookupswitch {
        //          -1901203848: 1385
        //          757776902: 115
        //          default: 148
        //        }
        //   148: aload_1        
        //   149: goto            153
        //   152: athrow         
        //   153: invokevirtual   dev/nuker/pyro/f4e.c:()Lnet/minecraft/network/Packet;
        //   156: goto            160
        //   159: athrow         
        //   160: checkcast       Lnet/minecraft/network/play/server/SPacketChat;
        //   163: getstatic       dev/nuker/pyro/fc.0:I
        //   166: ifgt            174
        //   169: ldc             -2097412353
        //   171: goto            176
        //   174: ldc             -53409503
        //   176: ldc             1987420272
        //   178: ixor           
        //   179: lookupswitch {
        //          -1968920239: 204
        //          -192305521: 174
        //          default: 1383
        //        }
        //   204: astore_2       
        //   205: aload_2        
        //   206: goto            210
        //   209: athrow         
        //   210: invokevirtual   net/minecraft/network/play/server/SPacketChat.func_192590_c:()Lnet/minecraft/util/text/ChatType;
        //   213: goto            217
        //   216: athrow         
        //   217: getstatic       dev/nuker/pyro/fc.1:I
        //   220: ifne            228
        //   223: ldc             -555394025
        //   225: goto            230
        //   228: ldc             -1249354837
        //   230: ldc             2042096548
        //   232: ixor           
        //   233: lookupswitch {
        //          -1487751245: 1369
        //          1375546459: 228
        //          default: 260
        //        }
        //   260: getstatic       net/minecraft/util/text/ChatType.CHAT:Lnet/minecraft/util/text/ChatType;
        //   263: if_acmpne       1366
        //   266: getstatic       dev/nuker/pyro/fc.0:I
        //   269: ifgt            277
        //   272: ldc             1776968740
        //   274: goto            279
        //   277: ldc             1367113794
        //   279: ldc             1808699840
        //   281: ixor           
        //   282: lookupswitch {
        //          -2058683313: 277
        //          35976676: 1377
        //          default: 308
        //        }
        //   308: aload_2        
        //   309: goto            313
        //   312: athrow         
        //   313: invokevirtual   net/minecraft/network/play/server/SPacketChat.func_148915_c:()Lnet/minecraft/util/text/ITextComponent;
        //   316: goto            320
        //   319: athrow         
        //   320: astore_3       
        //   321: aload_3        
        //   322: instanceof      Lnet/minecraft/util/text/TextComponentTranslation;
        //   325: ifeq            1366
        //   328: getstatic       dev/nuker/pyro/fc.0:I
        //   331: ifgt            339
        //   334: ldc             781344029
        //   336: goto            341
        //   339: ldc             -702386890
        //   341: ldc             1710298256
        //   343: ixor           
        //   344: lookupswitch {
        //          -1131450524: 339
        //          1264798093: 1403
        //          default: 372
        //        }
        //   372: aload_3        
        //   373: checkcast       Lnet/minecraft/util/text/TextComponentTranslation;
        //   376: astore          4
        //   378: getstatic       dev/nuker/pyro/fc.0:I
        //   381: ifgt            389
        //   384: ldc             1212857604
        //   386: goto            391
        //   389: ldc             -517648400
        //   391: ldc             1743825624
        //   393: ixor           
        //   394: lookupswitch {
        //          313528771: 389
        //          800724956: 1367
        //          default: 420
        //        }
        //   420: aload           4
        //   422: goto            426
        //   425: athrow         
        //   426: invokevirtual   net/minecraft/util/text/TextComponentTranslation.func_150271_j:()[Ljava/lang/Object;
        //   429: goto            433
        //   432: athrow         
        //   433: arraylength    
        //   434: ifle            1366
        //   437: aload           4
        //   439: getstatic       dev/nuker/pyro/fc.c:I
        //   442: ifne            450
        //   445: ldc             11431964
        //   447: goto            452
        //   450: ldc             1029582037
        //   452: ldc             -767691680
        //   454: ixor           
        //   455: lookupswitch {
        //          -762084228: 450
        //          -278669131: 480
        //          default: 1397
        //        }
        //   480: goto            484
        //   483: athrow         
        //   484: invokevirtual   net/minecraft/util/text/TextComponentTranslation.func_150271_j:()[Ljava/lang/Object;
        //   487: goto            491
        //   490: athrow         
        //   491: iconst_0       
        //   492: aaload         
        //   493: instanceof      Lnet/minecraft/util/text/TextComponentString;
        //   496: ifeq            1366
        //   499: getstatic       dev/nuker/pyro/fc.0:I
        //   502: ifgt            510
        //   505: ldc             662986849
        //   507: goto            512
        //   510: ldc             -654389142
        //   512: ldc             1917760151
        //   514: ixor           
        //   515: lookupswitch {
        //          -1431280899: 540
        //          1439355638: 510
        //          default: 1379
        //        }
        //   540: aload           4
        //   542: goto            546
        //   545: athrow         
        //   546: invokevirtual   net/minecraft/util/text/TextComponentTranslation.func_150271_j:()[Ljava/lang/Object;
        //   549: goto            553
        //   552: athrow         
        //   553: iconst_0       
        //   554: aaload         
        //   555: checkcast       Lnet/minecraft/util/text/TextComponentString;
        //   558: astore          5
        //   560: aload           5
        //   562: goto            566
        //   565: athrow         
        //   566: invokevirtual   net/minecraft/util/text/TextComponentString.func_150253_a:()Ljava/util/List;
        //   569: goto            573
        //   572: athrow         
        //   573: goto            577
        //   576: athrow         
        //   577: invokeinterface java/util/List.isEmpty:()Z
        //   582: goto            586
        //   585: athrow         
        //   586: ifne            594
        //   589: ldc             -1386489045
        //   591: goto            596
        //   594: ldc             -1386489046
        //   596: ldc             -246929523
        //   598: ixor           
        //   599: tableswitch {
        //          -1205339828: 620
        //          -1205339827: 1366
        //          default: 589
        //        }
        //   620: getstatic       dev/nuker/pyro/fc.c:I
        //   623: ifne            631
        //   626: ldc             -1975318262
        //   628: goto            633
        //   631: ldc             -175979016
        //   633: ldc             2097102033
        //   635: ixor           
        //   636: lookupswitch {
        //          -155437605: 1387
        //          1214217260: 631
        //          default: 664
        //        }
        //   664: aload           5
        //   666: goto            670
        //   669: athrow         
        //   670: invokevirtual   net/minecraft/util/text/TextComponentString.func_150253_a:()Ljava/util/List;
        //   673: goto            677
        //   676: athrow         
        //   677: iconst_0       
        //   678: goto            682
        //   681: athrow         
        //   682: invokeinterface java/util/List.get:(I)Ljava/lang/Object;
        //   687: goto            691
        //   690: athrow         
        //   691: instanceof      Lnet/minecraft/util/text/TextComponentString;
        //   694: ifeq            1366
        //   697: aload           5
        //   699: goto            703
        //   702: athrow         
        //   703: invokevirtual   net/minecraft/util/text/TextComponentString.func_150253_a:()Ljava/util/List;
        //   706: goto            710
        //   709: athrow         
        //   710: iconst_0       
        //   711: goto            715
        //   714: athrow         
        //   715: invokeinterface java/util/List.get:(I)Ljava/lang/Object;
        //   720: goto            724
        //   723: athrow         
        //   724: checkcast       Lnet/minecraft/util/text/TextComponentString;
        //   727: getstatic       dev/nuker/pyro/fc.c:I
        //   730: ifne            738
        //   733: ldc             -659886213
        //   735: goto            740
        //   738: ldc             -1744338643
        //   740: ldc             -1071967855
        //   742: ixor           
        //   743: lookupswitch {
        //          -1268671082: 738
        //          414318314: 1391
        //          default: 768
        //        }
        //   768: astore          6
        //   770: getstatic       dev/nuker/pyro/fc.0:I
        //   773: ifgt            781
        //   776: ldc             -444811178
        //   778: goto            783
        //   781: ldc             1849444939
        //   783: ldc             2034179543
        //   785: ixor           
        //   786: lookupswitch {
        //          -1673288319: 1399
        //          703471504: 781
        //          default: 812
        //        }
        //   812: getstatic       dev/nuker/pyro/FriendManager.Companion:Ldev/nuker/pyro/FriendManager$Companion;
        //   815: getstatic       dev/nuker/pyro/fc.1:I
        //   818: ifne            826
        //   821: ldc             -1734079086
        //   823: goto            828
        //   826: ldc             1274275031
        //   828: ldc             833487236
        //   830: ixor           
        //   831: lookupswitch {
        //          -1458959338: 1381
        //          767747406: 826
        //          default: 856
        //        }
        //   856: aload           6
        //   858: goto            862
        //   861: athrow         
        //   862: invokevirtual   net/minecraft/util/text/TextComponentString.func_150265_g:()Ljava/lang/String;
        //   865: goto            869
        //   868: athrow         
        //   869: getstatic       dev/nuker/pyro/fc.1:I
        //   872: ifne            880
        //   875: ldc             -1969275136
        //   877: goto            882
        //   880: ldc             938680374
        //   882: ldc             -959368874
        //   884: ixor           
        //   885: lookupswitch {
        //          -249425568: 912
        //          1280183894: 880
        //          default: 1389
        //        }
        //   912: goto            916
        //   915: athrow         
        //   916: invokevirtual   dev/nuker/pyro/FriendManager$Companion.getFriend:(Ljava/lang/String;)Ldev/nuker/pyro/f8;
        //   919: goto            923
        //   922: athrow         
        //   923: astore          7
        //   925: aload           7
        //   927: ifnull          1366
        //   930: aload_0        
        //   931: getstatic       dev/nuker/pyro/fc.0:I
        //   934: ifgt            942
        //   937: ldc             -399320756
        //   939: goto            944
        //   942: ldc             -1410623930
        //   944: ldc             257038309
        //   946: ixor           
        //   947: lookupswitch {
        //          -413086039: 1393
        //          983159328: 942
        //          default: 972
        //        }
        //   972: getfield        dev/nuker/pyro/fbo.c:Ldev/nuker/pyro/f0k;
        //   975: goto            979
        //   978: athrow         
        //   979: invokevirtual   dev/nuker/pyro/f0k.c:()Ljava/lang/Object;
        //   982: goto            986
        //   985: athrow         
        //   986: checkcast       Ljava/lang/Boolean;
        //   989: getstatic       dev/nuker/pyro/fc.c:I
        //   992: ifne            1000
        //   995: ldc             616979098
        //   997: goto            1002
        //  1000: ldc             588689710
        //  1002: ldc             -837632573
        //  1004: ixor           
        //  1005: lookupswitch {
        //          -1042042002: 1000
        //          -355145895: 1371
        //          default: 1032
        //        }
        //  1032: goto            1036
        //  1035: athrow         
        //  1036: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //  1039: goto            1043
        //  1042: athrow         
        //  1043: ifeq            1051
        //  1046: ldc             -1133250915
        //  1048: goto            1053
        //  1051: ldc             -1133250916
        //  1053: ldc             -613504897
        //  1055: ixor           
        //  1056: tableswitch {
        //          -835011132: 1080
        //          -835011131: 1264
        //          default: 1046
        //        }
        //  1080: aload           5
        //  1082: getstatic       dev/nuker/pyro/fc.0:I
        //  1085: ifgt            1093
        //  1088: ldc             -1234023659
        //  1090: goto            1095
        //  1093: ldc             -2071974957
        //  1095: ldc             168628919
        //  1097: ixor           
        //  1098: lookupswitch {
        //          -1903347356: 1124
        //          -1132504670: 1093
        //          default: 1395
        //        }
        //  1124: goto            1128
        //  1127: athrow         
        //  1128: invokevirtual   net/minecraft/util/text/TextComponentString.func_150253_a:()Ljava/util/List;
        //  1131: goto            1135
        //  1134: athrow         
        //  1135: iconst_0       
        //  1136: new             Lnet/minecraft/util/text/TextComponentString;
        //  1139: dup            
        //  1140: aload           7
        //  1142: goto            1146
        //  1145: athrow         
        //  1146: invokevirtual   dev/nuker/pyro/f8.1:()Ljava/lang/String;
        //  1149: goto            1153
        //  1152: athrow         
        //  1153: getstatic       dev/nuker/pyro/fc.c:I
        //  1156: ifne            1164
        //  1159: ldc             1991709778
        //  1161: goto            1166
        //  1164: ldc             1158181069
        //  1166: ldc             277644923
        //  1168: ixor           
        //  1169: lookupswitch {
        //          1434777270: 1196
        //          1715180073: 1164
        //          default: 1401
        //        }
        //  1196: goto            1200
        //  1199: athrow         
        //  1200: invokespecial   net/minecraft/util/text/TextComponentString.<init>:(Ljava/lang/String;)V
        //  1203: goto            1207
        //  1206: athrow         
        //  1207: new             Lnet/minecraft/util/text/Style;
        //  1210: dup            
        //  1211: goto            1215
        //  1214: athrow         
        //  1215: invokespecial   net/minecraft/util/text/Style.<init>:()V
        //  1218: goto            1222
        //  1221: athrow         
        //  1222: getstatic       net/minecraft/util/text/TextFormatting.DARK_AQUA:Lnet/minecraft/util/text/TextFormatting;
        //  1225: goto            1229
        //  1228: athrow         
        //  1229: invokevirtual   net/minecraft/util/text/Style.func_150238_a:(Lnet/minecraft/util/text/TextFormatting;)Lnet/minecraft/util/text/Style;
        //  1232: goto            1236
        //  1235: athrow         
        //  1236: goto            1240
        //  1239: athrow         
        //  1240: invokevirtual   net/minecraft/util/text/TextComponentString.func_150255_a:(Lnet/minecraft/util/text/Style;)Lnet/minecraft/util/text/ITextComponent;
        //  1243: goto            1247
        //  1246: athrow         
        //  1247: goto            1251
        //  1250: athrow         
        //  1251: invokeinterface java/util/List.set:(ILjava/lang/Object;)Ljava/lang/Object;
        //  1256: goto            1260
        //  1259: athrow         
        //  1260: pop            
        //  1261: goto            1366
        //  1264: aload           5
        //  1266: goto            1270
        //  1269: athrow         
        //  1270: invokevirtual   net/minecraft/util/text/TextComponentString.func_150253_a:()Ljava/util/List;
        //  1273: goto            1277
        //  1276: athrow         
        //  1277: iconst_0       
        //  1278: new             Lnet/minecraft/util/text/TextComponentString;
        //  1281: dup            
        //  1282: getstatic       dev/nuker/pyro/fc.c:I
        //  1285: ifne            1294
        //  1288: ldc_w           -1516717263
        //  1291: goto            1297
        //  1294: ldc_w           43860947
        //  1297: ldc_w           1474864665
        //  1300: ixor           
        //  1301: lookupswitch {
        //          -443035521: 1294
        //          -227533528: 1375
        //          default: 1328
        //        }
        //  1328: aload           7
        //  1330: goto            1334
        //  1333: athrow         
        //  1334: invokevirtual   dev/nuker/pyro/f8.1:()Ljava/lang/String;
        //  1337: goto            1341
        //  1340: athrow         
        //  1341: goto            1345
        //  1344: athrow         
        //  1345: invokespecial   net/minecraft/util/text/TextComponentString.<init>:(Ljava/lang/String;)V
        //  1348: goto            1352
        //  1351: athrow         
        //  1352: goto            1356
        //  1355: athrow         
        //  1356: invokeinterface java/util/List.set:(ILjava/lang/Object;)Ljava/lang/Object;
        //  1361: goto            1365
        //  1364: athrow         
        //  1365: pop            
        //  1366: return         
        //  1367: aconst_null    
        //  1368: athrow         
        //  1369: aconst_null    
        //  1370: athrow         
        //  1371: aconst_null    
        //  1372: athrow         
        //  1373: aconst_null    
        //  1374: athrow         
        //  1375: aconst_null    
        //  1376: athrow         
        //  1377: aconst_null    
        //  1378: athrow         
        //  1379: aconst_null    
        //  1380: athrow         
        //  1381: aconst_null    
        //  1382: athrow         
        //  1383: aconst_null    
        //  1384: athrow         
        //  1385: aconst_null    
        //  1386: athrow         
        //  1387: aconst_null    
        //  1388: athrow         
        //  1389: aconst_null    
        //  1390: athrow         
        //  1391: aconst_null    
        //  1392: athrow         
        //  1393: aconst_null    
        //  1394: athrow         
        //  1395: aconst_null    
        //  1396: athrow         
        //  1397: aconst_null    
        //  1398: athrow         
        //  1399: aconst_null    
        //  1400: athrow         
        //  1401: aconst_null    
        //  1402: athrow         
        //  1403: aconst_null    
        //  1404: athrow         
        //  1405: pop            
        //  1406: goto            24
        //  1409: pop            
        //  1410: aconst_null    
        //  1411: goto            1405
        //  1414: dup            
        //  1415: ifnull          1405
        //  1418: checkcast       Ljava/lang/Throwable;
        //  1421: athrow         
        //  1422: dup            
        //  1423: ifnull          1409
        //  1426: checkcast       Ljava/lang/Throwable;
        //  1429: athrow         
        //  1430: aconst_null    
        //  1431: athrow         
        //    StackMapTable: 00 D3 43 07 00 5C 04 FF 00 0B 00 00 00 01 07 00 5C FD 00 03 07 00 03 07 00 5E 43 07 00 5C 40 07 00 5E 45 07 00 5C 40 07 00 66 4A 07 00 66 FF 00 01 00 02 07 00 03 07 00 5E 00 02 07 00 66 01 5E 07 00 66 49 07 00 5C 40 07 00 5E 45 07 00 5C 40 07 01 07 10 41 01 1E 43 07 00 46 40 07 00 5E 45 07 00 5C 40 07 01 07 4D 07 00 6E FF 00 01 00 02 07 00 03 07 00 5E 00 02 07 00 6E 01 5B 07 00 6E FF 00 04 00 00 00 01 07 00 5C FF 00 00 00 03 07 00 03 07 00 5E 07 00 6E 00 01 07 00 6E 45 07 00 5C 40 07 00 7D 4A 07 00 7D FF 00 01 00 03 07 00 03 07 00 5E 07 00 6E 00 02 07 00 7D 01 5D 07 00 7D 10 41 01 1C 43 07 00 5C 40 07 00 6E 45 07 00 5C 40 07 01 09 FC 00 12 07 01 09 41 01 1E FC 00 10 07 00 8A 41 01 1C 44 07 00 5C 40 07 00 8A 45 07 00 5C 40 07 01 0B 50 07 00 8A FF 00 01 00 05 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 00 02 07 00 8A 01 5B 07 00 8A 42 07 00 5C 40 07 00 8A 45 07 00 5C 40 07 01 0B 12 41 01 1B 44 07 00 5C 40 07 00 8A 45 07 00 5C 40 07 01 0B FF 00 0B 00 00 00 01 07 00 5C FF 00 00 00 06 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 00 01 07 00 9B 45 07 00 5C 40 07 00 A4 42 07 00 5C 40 07 00 A4 47 07 00 5C 40 01 02 04 41 01 17 0A 41 01 1E 44 07 00 5C 40 07 00 9B 45 07 00 5C 40 07 00 A4 FF 00 03 00 00 00 01 07 00 5C FF 00 00 00 06 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 00 02 07 00 A4 01 47 07 00 5C 40 07 01 0D FF 00 0A 00 00 00 01 07 00 5C FF 00 00 00 06 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 00 01 07 00 9B 45 07 00 5C 40 07 00 A4 43 07 00 5C FF 00 00 00 06 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 00 02 07 00 A4 01 47 07 00 5C 40 07 01 0D 4D 07 00 9B FF 00 01 00 06 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 00 02 07 00 9B 01 5B 07 00 9B FC 00 0C 07 00 9B 41 01 1C 4D 07 00 CA FF 00 01 00 07 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 00 02 07 00 CA 01 5B 07 00 CA 44 07 00 56 FF 00 00 00 07 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 00 02 07 00 CA 07 00 9B 45 07 00 5C FF 00 00 00 07 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 00 02 07 00 CA 07 00 37 FF 00 0A 00 07 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 00 02 07 00 CA 07 00 37 FF 00 01 00 07 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 00 03 07 00 CA 07 00 37 01 FF 00 1D 00 07 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 00 02 07 00 CA 07 00 37 42 07 00 5C FF 00 00 00 07 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 00 02 07 00 CA 07 00 37 45 07 00 5C 40 07 00 E4 FF 00 12 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 01 07 00 03 FF 00 01 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 02 07 00 03 01 5B 07 00 03 45 07 00 5C 40 07 00 22 45 07 00 5C 40 07 01 0D 4D 07 00 D6 FF 00 01 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 02 07 00 D6 01 5D 07 00 D6 42 07 00 5C 40 07 00 D6 45 07 00 5C 40 01 02 04 41 01 1A 4C 07 00 9B FF 00 01 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 02 07 00 9B 01 5C 07 00 9B 42 07 00 52 40 07 00 9B 45 07 00 5C 40 07 00 A4 49 07 00 5C FF 00 00 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 05 07 00 A4 01 08 04 70 08 04 70 07 00 E4 45 07 00 5C FF 00 00 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 05 07 00 A4 01 08 04 70 08 04 70 07 00 37 FF 00 0A 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 05 07 00 A4 01 08 04 70 08 04 70 07 00 37 FF 00 01 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 06 07 00 A4 01 08 04 70 08 04 70 07 00 37 01 FF 00 1D 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 05 07 00 A4 01 08 04 70 08 04 70 07 00 37 FF 00 02 00 00 00 01 07 00 5C FF 00 00 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 05 07 00 A4 01 08 04 70 08 04 70 07 00 37 45 07 00 5C FF 00 00 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 03 07 00 A4 01 07 00 9B 46 07 00 48 FF 00 00 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 05 07 00 A4 01 07 00 9B 08 04 B7 08 04 B7 45 07 00 5C FF 00 00 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 04 07 00 A4 01 07 00 9B 07 00 EE FF 00 05 00 00 00 01 07 00 5C FF 00 00 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 05 07 00 A4 01 07 00 9B 07 00 EE 07 00 F2 45 07 00 5C FF 00 00 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 04 07 00 A4 01 07 00 9B 07 00 EE 42 07 00 5C FF 00 00 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 04 07 00 A4 01 07 00 9B 07 00 EE 45 07 00 5C FF 00 00 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 03 07 00 A4 01 07 01 09 42 07 00 5C FF 00 00 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 03 07 00 A4 01 07 01 09 47 07 00 5C 40 07 01 0D 03 FF 00 04 00 00 00 01 07 00 5C FF 00 00 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 01 07 00 9B 45 07 00 5C 40 07 00 A4 FF 00 10 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 04 07 00 A4 01 08 04 FE 08 04 FE FF 00 02 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 05 07 00 A4 01 08 04 FE 08 04 FE 01 FF 00 1E 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 04 07 00 A4 01 08 04 FE 08 04 FE 44 07 00 40 FF 00 00 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 05 07 00 A4 01 08 04 FE 08 04 FE 07 00 E4 45 07 00 5C FF 00 00 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 05 07 00 A4 01 08 04 FE 08 04 FE 07 00 37 42 07 00 4C FF 00 00 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 05 07 00 A4 01 08 04 FE 08 04 FE 07 00 37 45 07 00 5C FF 00 00 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 03 07 00 A4 01 07 00 9B FF 00 02 00 00 00 01 07 00 5C FF 00 00 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 03 07 00 A4 01 07 00 9B 47 07 00 5C 40 07 01 0D FF 00 00 00 02 07 00 03 07 00 5E 00 00 FE 00 00 07 00 6E 07 01 09 07 00 8A FF 00 01 00 03 07 00 03 07 00 5E 07 00 6E 00 01 07 00 7D FF 00 01 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 01 07 00 D6 FF 00 01 00 02 07 00 03 07 00 5E 00 01 07 00 66 FF 00 01 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 04 07 00 A4 01 08 04 FE 08 04 FE FF 00 01 00 03 07 00 03 07 00 5E 07 00 6E 00 00 FD 00 01 07 01 09 07 00 8A FF 00 01 00 07 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 00 01 07 00 CA FF 00 01 00 02 07 00 03 07 00 5E 00 01 07 00 6E 01 FF 00 01 00 06 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 00 00 FF 00 01 00 07 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 00 02 07 00 CA 07 00 37 FF 00 01 00 06 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 00 01 07 00 9B FF 00 01 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 01 07 00 03 41 07 00 9B FF 00 01 00 05 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 00 01 07 00 8A FD 00 01 07 00 9B 07 00 9B FF 00 01 00 08 07 00 03 07 00 5E 07 00 6E 07 01 09 07 00 8A 07 00 9B 07 00 9B 07 00 E4 00 05 07 00 A4 01 08 04 70 08 04 70 07 00 37 FF 00 01 00 04 07 00 03 07 00 5E 07 00 6E 07 01 09 00 00 FF 00 01 00 02 07 00 03 07 00 5E 00 01 07 00 5C 43 05 44 07 00 5C 47 05 47 07 00 5C
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     1414   1422   Any
        //  1414   1422   1414   1422   Any
        //  1430   1432   3      8      Any
        //  28     35     35     36     Any
        //  28     35     28     29     Ljava/lang/ClassCastException;
        //  28     35     28     29     Ljava/lang/ClassCastException;
        //  29     35     28     29     Any
        //  29     35     28     29     Any
        //  90     97     97     98     Any
        //  90     97     90     91     Any
        //  91     97     97     98     Any
        //  90     97     90     91     Ljava/lang/ArrayIndexOutOfBoundsException;
        //  91     97     3      8      Ljava/lang/ArithmeticException;
        //  152    159    159    160    Any
        //  152    159    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  153    159    159    160    Any
        //  153    159    152    153    Ljava/util/NoSuchElementException;
        //  153    159    3      8      Ljava/lang/UnsupportedOperationException;
        //  210    216    216    217    Any
        //  210    216    216    217    Any
        //  210    216    3      8      Ljava/lang/IllegalArgumentException;
        //  210    216    216    217    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  210    216    3      8      Any
        //  312    319    319    320    Any
        //  313    319    312    313    Ljava/lang/RuntimeException;
        //  313    319    3      8      Any
        //  313    319    312    313    Any
        //  313    319    3      8      Any
        //  425    432    432    433    Any
        //  426    432    432    433    Any
        //  425    432    425    426    Any
        //  425    432    432    433    Ljava/lang/NegativeArraySizeException;
        //  425    432    3      8      Any
        //  483    490    490    491    Any
        //  483    490    483    484    Ljava/lang/IndexOutOfBoundsException;
        //  483    490    3      8      Ljava/lang/NegativeArraySizeException;
        //  484    490    490    491    Ljava/lang/AssertionError;
        //  483    490    483    484    Any
        //  545    552    552    553    Any
        //  545    552    545    546    Any
        //  546    552    545    546    Any
        //  545    552    3      8      Ljava/lang/RuntimeException;
        //  545    552    552    553    Ljava/lang/StringIndexOutOfBoundsException;
        //  566    572    572    573    Any
        //  566    572    3      8      Ljava/lang/ClassCastException;
        //  566    572    572    573    Any
        //  566    572    572    573    Ljava/util/NoSuchElementException;
        //  566    572    572    573    Ljava/lang/NegativeArraySizeException;
        //  576    585    585    586    Any
        //  576    585    3      8      Any
        //  576    585    576    577    Any
        //  576    585    585    586    Any
        //  576    585    3      8      Ljava/lang/ClassCastException;
        //  669    676    676    677    Any
        //  670    676    669    670    Any
        //  669    676    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  669    676    669    670    Any
        //  669    676    3      8      Any
        //  682    690    690    691    Any
        //  682    690    3      8      Ljava/lang/ClassCastException;
        //  682    690    690    691    Ljava/lang/EnumConstantNotPresentException;
        //  682    690    690    691    Any
        //  682    690    3      8      Any
        //  703    709    709    710    Any
        //  703    709    3      8      Any
        //  703    709    709    710    Any
        //  703    709    3      8      Any
        //  703    709    709    710    Any
        //  714    723    723    724    Any
        //  714    723    3      8      Ljava/lang/IllegalStateException;
        //  714    723    714    715    Any
        //  714    723    3      8      Ljava/lang/IllegalArgumentException;
        //  715    723    723    724    Ljava/lang/EnumConstantNotPresentException;
        //  861    868    868    869    Any
        //  862    868    3      8      Ljava/lang/AssertionError;
        //  861    868    861    862    Ljava/lang/IllegalStateException;
        //  862    868    868    869    Any
        //  862    868    3      8      Any
        //  915    922    922    923    Any
        //  915    922    915    916    Any
        //  915    922    915    916    Ljava/lang/ArithmeticException;
        //  916    922    3      8      Any
        //  915    922    915    916    Any
        //  978    985    985    986    Any
        //  978    985    978    979    Ljava/lang/IndexOutOfBoundsException;
        //  979    985    3      8      Ljava/util/NoSuchElementException;
        //  979    985    978    979    Ljava/lang/AssertionError;
        //  979    985    985    986    Any
        //  1035   1042   1042   1043   Any
        //  1036   1042   3      8      Any
        //  1035   1042   1035   1036   Any
        //  1036   1042   1035   1036   Ljava/lang/AssertionError;
        //  1036   1042   3      8      Ljava/lang/IndexOutOfBoundsException;
        //  1127   1134   1134   1135   Any
        //  1127   1134   3      8      Ljava/lang/RuntimeException;
        //  1127   1134   1134   1135   Any
        //  1128   1134   3      8      Ljava/lang/ClassCastException;
        //  1128   1134   1127   1128   Ljava/lang/AssertionError;
        //  1145   1152   1152   1153   Any
        //  1146   1152   3      8      Any
        //  1146   1152   1145   1146   Any
        //  1145   1152   1152   1153   Any
        //  1146   1152   1152   1153   Any
        //  1200   1206   1206   1207   Any
        //  1200   1206   3      8      Ljava/util/ConcurrentModificationException;
        //  1200   1206   1206   1207   Any
        //  1200   1206   1206   1207   Any
        //  1200   1206   3      8      Ljava/lang/RuntimeException;
        //  1214   1221   1221   1222   Any
        //  1214   1221   1214   1215   Ljava/lang/UnsupportedOperationException;
        //  1215   1221   3      8      Ljava/lang/EnumConstantNotPresentException;
        //  1214   1221   1221   1222   Any
        //  1215   1221   1221   1222   Ljava/lang/IllegalArgumentException;
        //  1229   1235   1235   1236   Any
        //  1229   1235   3      8      Ljava/lang/EnumConstantNotPresentException;
        //  1229   1235   1235   1236   Any
        //  1229   1235   1235   1236   Any
        //  1229   1235   1235   1236   Any
        //  1239   1246   1246   1247   Any
        //  1240   1246   1246   1247   Any
        //  1239   1246   1239   1240   Ljava/lang/NumberFormatException;
        //  1240   1246   1246   1247   Ljava/lang/StringIndexOutOfBoundsException;
        //  1240   1246   1239   1240   Any
        //  1250   1259   1259   1260   Any
        //  1251   1259   1259   1260   Any
        //  1250   1259   1259   1260   Ljava/lang/ArithmeticException;
        //  1251   1259   1250   1251   Any
        //  1251   1259   3      8      Any
        //  1270   1276   1276   1277   Any
        //  1270   1276   1276   1277   Any
        //  1270   1276   3      8      Ljava/lang/RuntimeException;
        //  1270   1276   3      8      Any
        //  1270   1276   3      8      Any
        //  1333   1340   1340   1341   Any
        //  1333   1340   1340   1341   Any
        //  1333   1340   3      8      Ljava/lang/RuntimeException;
        //  1334   1340   1333   1334   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1334   1340   3      8      Ljava/lang/AssertionError;
        //  1344   1351   1351   1352   Any
        //  1345   1351   1351   1352   Ljava/lang/IllegalArgumentException;
        //  1344   1351   1344   1345   Ljava/lang/NegativeArraySizeException;
        //  1345   1351   3      8      Ljava/lang/ClassCastException;
        //  1344   1351   1344   1345   Ljava/lang/NumberFormatException;
        //  1356   1364   1364   1365   Any
        //  1356   1364   1364   1365   Ljava/lang/ArithmeticException;
        //  1356   1364   1364   1365   Any
        //  1356   1364   1364   1365   Ljava/lang/AssertionError;
        //  1356   1364   1364   1365   Ljava/lang/UnsupportedOperationException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:595)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
