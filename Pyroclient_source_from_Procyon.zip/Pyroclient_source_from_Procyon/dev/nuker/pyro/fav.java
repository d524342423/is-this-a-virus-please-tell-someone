// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

public class fav extends far
{
    public double c;
    public double 0;
    public int c;
    public int 0;
    
    public fav() {
        while (true) {
            int n = 0;
            Label_0013: {
                if (fc.0 <= 0) {
                    n = 1434297569;
                    break Label_0013;
                }
                n = 503774686;
            }
            switch (n ^ 0xD2431075) {
                case -2025933676: {
                    continue;
                }
                case -867832405: {
                    this.0 = 0;
                    while (true) {
                        int n2 = 0;
                        Label_0067: {
                            if (fc.c == 0) {
                                n2 = 1390553011;
                                break Label_0067;
                            }
                            n2 = 1482519037;
                        }
                        switch (n2 ^ 0x29625E52) {
                            case 808389761: {
                                continue;
                            }
                            default: {
                                while (true) {
                                    int n3 = 0;
                                    Label_0111: {
                                        if (fc.0 <= 0) {
                                            n3 = 1712316497;
                                            break Label_0111;
                                        }
                                        n3 = -1059894637;
                                    }
                                    switch (n3 ^ 0xC266B821) {
                                        case 1685108417: {
                                            continue;
                                        }
                                        default: {
                                            this.c = far.1();
                                            return;
                                        }
                                        case -1536599952: {
                                            throw null;
                                        }
                                    }
                                    break;
                                }
                                break;
                            }
                            case 2072017377: {
                                throw null;
                            }
                        }
                        break;
                    }
                    break;
                }
                default: {
                    throw null;
                }
            }
            break;
        }
    }
    
    @Override
    public void c(final f4u f4u) {
        fez.il(this, 1311184139, f4u);
    }
    
    static {
        throw t;
    }
    
    @Override
    public void c(final f4p f4p) {
        fez.6n(this, 885754848, f4p);
    }
    
    @Override
    public void 0() {
        fez.g1(this, 28050106);
    }
    
    @Override
    public void c() {
        fez.gC(this, 595860458);
    }
}
