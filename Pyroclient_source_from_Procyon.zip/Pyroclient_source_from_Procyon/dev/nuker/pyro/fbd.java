// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import net.minecraft.client.entity.EntityPlayerSP;
import org.jetbrains.annotations.NotNull;

public class fbd extends fQ
{
    @NotNull
    public f0k c;
    @NotNull
    public f0k 0;
    public f0l c;
    public f0l 0;
    public f0l 1;
    public f0l 2;
    public f0l 3;
    public f0l 4;
    public f0m c;
    
    @NotNull
    public f0k c() {
        return fez.7U(this, 1138356770);
    }
    
    @NotNull
    public f0k 0() {
        return fez.6V(this, 1681138095);
    }
    
    static {
        throw t;
    }
    
    public fbd() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: ldc             "\u37e8\ub249\u84a0\uada7\u68d3\u5309\u7e55\u63b7"
        //     3: invokestatic    invokestatic   !!! ERROR
        //     6: ldc             "\u37c8\ub249\u84a0\uada7\u68d3\u5329\u7e75\u6397"
        //     8: getstatic       dev/nuker/pyro/fc.0:I
        //    11: ifgt            19
        //    14: ldc             1970366894
        //    16: goto            21
        //    19: ldc             406007889
        //    21: ldc             -1502616590
        //    23: ixor           
        //    24: lookupswitch {
        //          -1101212765: 52
        //          -752973220: 19
        //          default: 1434
        //        }
        //    52: invokestatic    invokestatic   !!! ERROR
        //    55: aconst_null    
        //    56: invokespecial   dev/nuker/pyro/fQ.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //    59: aload_0        
        //    60: aload_0        
        //    61: new             Ldev/nuker/pyro/f0k;
        //    64: dup            
        //    65: ldc             "\u37e8\ub250\u84ba\uadb0\u68d7\u5303\u7e66\u63b1\uc2cd\uac2a"
        //    67: invokestatic    invokestatic   !!! ERROR
        //    70: ldc             "\u37c8\ub250\u84ba\uadb0\u68d7\u5303\u7e00\u6398\uc2cc\uac30\u9146"
        //    72: invokestatic    invokestatic   !!! ERROR
        //    75: aconst_null    
        //    76: iconst_1       
        //    77: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //    80: checkcast       Ldev/nuker/pyro/f0w;
        //    83: invokevirtual   dev/nuker/pyro/fbd.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //    86: checkcast       Ldev/nuker/pyro/f0k;
        //    89: putfield        dev/nuker/pyro/fbd.c:Ldev/nuker/pyro/f0k;
        //    92: aload_0        
        //    93: aload_0        
        //    94: new             Ldev/nuker/pyro/f0k;
        //    97: dup            
        //    98: ldc             "\u37e3\ub250\u84ad\uad86\u68d9\u530d\u7e4b\u63b9\uc2d1\uac31\u9147\u130a\ucbdb"
        //   100: getstatic       dev/nuker/pyro/fc.c:I
        //   103: ifne            111
        //   106: ldc             463534650
        //   108: goto            113
        //   111: ldc             1672008915
        //   113: ldc             -1934457722
        //   115: ixor           
        //   116: lookupswitch {
        //          -1760395588: 111
        //          -283488171: 144
        //          default: 1414
        //        }
        //   144: invokestatic    invokestatic   !!! ERROR
        //   147: ldc             "\u37c3\ub270\u848d\uade4\u68fa\u530f\u7e43\u63b5\uc2c4\uac2c\u915d\u1311\ucbd1\u710a"
        //   149: invokestatic    invokestatic   !!! ERROR
        //   152: aconst_null    
        //   153: iconst_1       
        //   154: getstatic       dev/nuker/pyro/fc.1:I
        //   157: ifne            165
        //   160: ldc             -1084518641
        //   162: goto            167
        //   165: ldc             -1991200896
        //   167: ldc             -52231347
        //   169: ixor           
        //   170: lookupswitch {
        //          -1733730480: 165
        //          1136168002: 1418
        //          default: 196
        //        }
        //   196: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   199: checkcast       Ldev/nuker/pyro/f0w;
        //   202: invokevirtual   dev/nuker/pyro/fbd.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   205: checkcast       Ldev/nuker/pyro/f0k;
        //   208: putfield        dev/nuker/pyro/fbd.0:Ldev/nuker/pyro/f0k;
        //   211: aload_0        
        //   212: getstatic       dev/nuker/pyro/fc.1:I
        //   215: ifne            223
        //   218: ldc             -465352501
        //   220: goto            225
        //   223: ldc             1926480745
        //   225: ldc             -492334697
        //   227: ixor           
        //   228: lookupswitch {
        //          -1335398339: 223
        //          115661148: 1416
        //          default: 256
        //        }
        //   256: aload_0        
        //   257: new             Ldev/nuker/pyro/f0l;
        //   260: dup            
        //   261: ldc             "\u37fb\ub257\u84a0\uada9\u68d9\u531c\u7e59\u6381\uc2c0\uac31\u915e\u130b\ucbcd"
        //   263: invokestatic    invokestatic   !!! ERROR
        //   266: ldc             "\u37db\ub257\u84a0\uada9\u68d9\u531c\u7e59\u63fe\uc2e0\uac31\u915e\u130b\ucbcd"
        //   268: invokestatic    invokestatic   !!! ERROR
        //   271: aconst_null    
        //   272: getstatic       dev/nuker/pyro/gui/ClickGui.Companion:Ldev/nuker/pyro/gui/ClickGui$Companion;
        //   275: getstatic       dev/nuker/pyro/fc.c:I
        //   278: ifne            286
        //   281: ldc             1441530824
        //   283: goto            288
        //   286: ldc             976780763
        //   288: ldc             -300095504
        //   290: ixor           
        //   291: lookupswitch {
        //          -1141840840: 286
        //          -735798741: 316
        //          default: 1440
        //        }
        //   316: invokevirtual   dev/nuker/pyro/gui/ClickGui$Companion.getSettings:()Ldev/nuker/pyro/f0H;
        //   319: invokevirtual   dev/nuker/pyro/f0H.7:()Ldev/nuker/pyro/f00;
        //   322: invokespecial   dev/nuker/pyro/f0l.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ldev/nuker/pyro/f00;)V
        //   325: checkcast       Ldev/nuker/pyro/f0w;
        //   328: invokevirtual   dev/nuker/pyro/fbd.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   331: checkcast       Ldev/nuker/pyro/f0l;
        //   334: putfield        dev/nuker/pyro/fbd.c:Ldev/nuker/pyro/f0l;
        //   337: aload_0        
        //   338: aload_0        
        //   339: new             Ldev/nuker/pyro/f0l;
        //   342: dup            
        //   343: ldc             "\u37ea\ub246\u84aa\uada1\u68d6\u531a\u7e7f\u63bd\uc2cc\uac32\u915d\u1316"
        //   345: invokestatic    invokestatic   !!! ERROR
        //   348: ldc             "\u37ca\ub246\u84aa\uada1\u68d6\u531a\u7e00\u639d\uc2cc\uac32\u915d\u1316"
        //   350: invokestatic    invokestatic   !!! ERROR
        //   353: aconst_null    
        //   354: getstatic       dev/nuker/pyro/gui/ClickGui.Companion:Ldev/nuker/pyro/gui/ClickGui$Companion;
        //   357: invokevirtual   dev/nuker/pyro/gui/ClickGui$Companion.getSettings:()Ldev/nuker/pyro/f0H;
        //   360: getstatic       dev/nuker/pyro/fc.1:I
        //   363: ifne            371
        //   366: ldc             502585464
        //   368: goto            373
        //   371: ldc             -833979641
        //   373: ldc             -1425687196
        //   375: ixor           
        //   376: lookupswitch {
        //          -1225693924: 1448
        //          -5523929: 371
        //          default: 404
        //        }
        //   404: invokevirtual   dev/nuker/pyro/f0H.1:()Ldev/nuker/pyro/f00;
        //   407: invokespecial   dev/nuker/pyro/f0l.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ldev/nuker/pyro/f00;)V
        //   410: checkcast       Ldev/nuker/pyro/f0w;
        //   413: getstatic       dev/nuker/pyro/fc.1:I
        //   416: ifne            424
        //   419: ldc             1103728863
        //   421: goto            426
        //   424: ldc             -1131499214
        //   426: ldc             376914007
        //   428: ixor           
        //   429: lookupswitch {
        //          -376759906: 424
        //          1472123016: 1442
        //          default: 456
        //        }
        //   456: invokevirtual   dev/nuker/pyro/fbd.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   459: checkcast       Ldev/nuker/pyro/f0l;
        //   462: getstatic       dev/nuker/pyro/fc.0:I
        //   465: ifgt            473
        //   468: ldc             625792409
        //   470: goto            475
        //   473: ldc             -2001977455
        //   475: ldc             1567498783
        //   477: ixor           
        //   478: lookupswitch {
        //          1148238703: 473
        //          2015557510: 1426
        //          default: 504
        //        }
        //   504: putfield        dev/nuker/pyro/fbd.0:Ldev/nuker/pyro/f0l;
        //   507: aload_0        
        //   508: aload_0        
        //   509: new             Ldev/nuker/pyro/f0l;
        //   512: dup            
        //   513: ldc             "\u37ea\ub246\u84bd\uadad\u68ce\u530b\u7e7f\u63bd\uc2cc\uac32\u915d\u1316"
        //   515: invokestatic    invokestatic   !!! ERROR
        //   518: ldc             "\u37ca\ub246\u84bd\uadad\u68ce\u530b\u7e00\u639d\uc2cc\uac32\u915d\u1316"
        //   520: invokestatic    invokestatic   !!! ERROR
        //   523: aconst_null    
        //   524: getstatic       dev/nuker/pyro/gui/ClickGui.Companion:Ldev/nuker/pyro/gui/ClickGui$Companion;
        //   527: invokevirtual   dev/nuker/pyro/gui/ClickGui$Companion.getSettings:()Ldev/nuker/pyro/f0H;
        //   530: getstatic       dev/nuker/pyro/fc.0:I
        //   533: ifgt            541
        //   536: ldc             -1998323491
        //   538: goto            543
        //   541: ldc             -1612506582
        //   543: ldc             -1915266278
        //   545: ixor           
        //   546: lookupswitch {
        //          -735842519: 541
        //          87251911: 1432
        //          default: 572
        //        }
        //   572: invokevirtual   dev/nuker/pyro/f0H.6:()Ldev/nuker/pyro/f00;
        //   575: invokespecial   dev/nuker/pyro/f0l.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ldev/nuker/pyro/f00;)V
        //   578: checkcast       Ldev/nuker/pyro/f0w;
        //   581: getstatic       dev/nuker/pyro/fc.1:I
        //   584: ifne            592
        //   587: ldc             -1464875523
        //   589: goto            594
        //   592: ldc             1056043934
        //   594: ldc             -1362195913
        //   596: ixor           
        //   597: lookupswitch {
        //          -1874888279: 624
        //          107040714: 592
        //          default: 1422
        //        }
        //   624: invokevirtual   dev/nuker/pyro/fbd.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   627: checkcast       Ldev/nuker/pyro/f0l;
        //   630: putfield        dev/nuker/pyro/fbd.1:Ldev/nuker/pyro/f0l;
        //   633: aload_0        
        //   634: getstatic       dev/nuker/pyro/fc.1:I
        //   637: ifne            645
        //   640: ldc             -533729691
        //   642: goto            647
        //   645: ldc             1476433017
        //   647: ldc             -1791345174
        //   649: ixor           
        //   650: lookupswitch {
        //          1180356439: 645
        //          1964364687: 1424
        //          default: 676
        //        }
        //   676: aload_0        
        //   677: new             Ldev/nuker/pyro/f0l;
        //   680: dup            
        //   681: ldc             "\u37e2\ub24b\u84a8\uada7\u68cc\u5307\u7e56\u63bb\uc2fc\uac3d\u915d\u1308\ucbd0\u711c"
        //   683: invokestatic    invokestatic   !!! ERROR
        //   686: ldc             "\u37c2\ub24b\u84aa\uadb0\u68d1\u5318\u7e45\u63fe\uc2e0\uac31\u915e\u130b\ucbcd"
        //   688: invokestatic    invokestatic   !!! ERROR
        //   691: aconst_null    
        //   692: getstatic       dev/nuker/pyro/gui/ClickGui.Companion:Ldev/nuker/pyro/gui/ClickGui$Companion;
        //   695: invokevirtual   dev/nuker/pyro/gui/ClickGui$Companion.getSettings:()Ldev/nuker/pyro/f0H;
        //   698: invokevirtual   dev/nuker/pyro/f0H.3:()Ldev/nuker/pyro/f00;
        //   701: getstatic       dev/nuker/pyro/fc.1:I
        //   704: ifne            712
        //   707: ldc             1984991855
        //   709: goto            714
        //   712: ldc             -50957798
        //   714: ldc             -2144151137
        //   716: ixor           
        //   717: lookupswitch {
        //          -161330192: 712
        //          2093263749: 744
        //          default: 1420
        //        }
        //   744: invokespecial   dev/nuker/pyro/f0l.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ldev/nuker/pyro/f00;)V
        //   747: checkcast       Ldev/nuker/pyro/f0w;
        //   750: invokevirtual   dev/nuker/pyro/fbd.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   753: checkcast       Ldev/nuker/pyro/f0l;
        //   756: putfield        dev/nuker/pyro/fbd.2:Ldev/nuker/pyro/f0l;
        //   759: aload_0        
        //   760: aload_0        
        //   761: new             Ldev/nuker/pyro/f0l;
        //   764: dup            
        //   765: ldc             "\u37e9\ub244\u84aa\uadaf\u68df\u531c\u7e4f\u63ab\uc2cd\uac3a\u916d\u1307\ucbd0\u7102\u9f06\u4714"
        //   767: getstatic       dev/nuker/pyro/fc.1:I
        //   770: ifne            778
        //   773: ldc             1233506189
        //   775: goto            780
        //   778: ldc             -1796028732
        //   780: ldc             -615021980
        //   782: ixor           
        //   783: lookupswitch {
        //          -1831711255: 778
        //          1336231072: 808
        //          default: 1444
        //        }
        //   808: invokestatic    invokestatic   !!! ERROR
        //   811: ldc             "\u37c9\ub244\u84aa\uadaf\u68df\u531c\u7e4f\u63ab\uc2cd\uac3a\u9112\u1327\ucbd0\u7102\u9f06\u4714"
        //   813: invokestatic    invokestatic   !!! ERROR
        //   816: aconst_null    
        //   817: getstatic       dev/nuker/pyro/gui/ClickGui.Companion:Ldev/nuker/pyro/gui/ClickGui$Companion;
        //   820: invokevirtual   dev/nuker/pyro/gui/ClickGui$Companion.getSettings:()Ldev/nuker/pyro/f0H;
        //   823: invokevirtual   dev/nuker/pyro/f0H.0:()Ldev/nuker/pyro/f00;
        //   826: getstatic       dev/nuker/pyro/fc.0:I
        //   829: ifgt            837
        //   832: ldc             -1105609841
        //   834: goto            839
        //   837: ldc             1455219619
        //   839: ldc             -881685507
        //   841: ixor           
        //   842: lookupswitch {
        //          -1647417250: 868
        //          1969959026: 837
        //          default: 1406
        //        }
        //   868: invokespecial   dev/nuker/pyro/f0l.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ldev/nuker/pyro/f00;)V
        //   871: checkcast       Ldev/nuker/pyro/f0w;
        //   874: getstatic       dev/nuker/pyro/fc.1:I
        //   877: ifne            885
        //   880: ldc             -1386941862
        //   882: goto            887
        //   885: ldc             -1492243837
        //   887: ldc             -1653735714
        //   889: ixor           
        //   890: lookupswitch {
        //          178975231: 885
        //          809045124: 1412
        //          default: 916
        //        }
        //   916: invokevirtual   dev/nuker/pyro/fbd.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   919: checkcast       Ldev/nuker/pyro/f0l;
        //   922: putfield        dev/nuker/pyro/fbd.3:Ldev/nuker/pyro/f0l;
        //   925: aload_0        
        //   926: aload_0        
        //   927: new             Ldev/nuker/pyro/f0l;
        //   930: dup            
        //   931: ldc             "\u37e9\ub244\u84aa\uadaf\u68df\u531c\u7e4f\u63ab\uc2cd\uac3a\u916d\u1307\ucbd0\u7102\u9f06\u4714\ub22e\u463d\u014d\u08fd\u181b\ufed6\u606c\u8850"
        //   933: invokestatic    invokestatic   !!! ERROR
        //   936: ldc             "\u37c3\ub24a\u84bf\uadea\u6898\u532c\u7e41\u63bd\uc2c8\uac39\u9140\u130b\ucbca\u7100\u9f0d\u4746\ub232\u463a\u014e\u08e4\u180c"
        //   938: invokestatic    invokestatic   !!! ERROR
        //   941: aconst_null    
        //   942: getstatic       dev/nuker/pyro/gui/ClickGui.Companion:Ldev/nuker/pyro/gui/ClickGui$Companion;
        //   945: invokevirtual   dev/nuker/pyro/gui/ClickGui$Companion.getSettings:()Ldev/nuker/pyro/f0H;
        //   948: invokevirtual   dev/nuker/pyro/f0H.2:()Ldev/nuker/pyro/f00;
        //   951: getstatic       dev/nuker/pyro/fc.0:I
        //   954: ifgt            962
        //   957: ldc             -227955838
        //   959: goto            964
        //   962: ldc             1605873233
        //   964: ldc             160119666
        //   966: ixor           
        //   967: lookupswitch {
        //          -1723754608: 962
        //          -69037840: 1428
        //          default: 992
        //        }
        //   992: invokespecial   dev/nuker/pyro/f0l.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ldev/nuker/pyro/f00;)V
        //   995: checkcast       Ldev/nuker/pyro/f0w;
        //   998: invokevirtual   dev/nuker/pyro/fbd.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //  1001: checkcast       Ldev/nuker/pyro/f0l;
        //  1004: putfield        dev/nuker/pyro/fbd.4:Ldev/nuker/pyro/f0l;
        //  1007: aload_0        
        //  1008: aload_0        
        //  1009: new             Ldev/nuker/pyro/f0m;
        //  1012: dup            
        //  1013: ldc             "\u37f8\ub246\u84a8\uada8\u68dd"
        //  1015: invokestatic    invokestatic   !!! ERROR
        //  1018: ldc             "\u37d8\ub246\u84a8\uada8\u68dd"
        //  1020: invokestatic    invokestatic   !!! ERROR
        //  1023: aconst_null    
        //  1024: dconst_1       
        //  1025: ldc2_w          0.1
        //  1028: ldc2_w          2.0
        //  1031: dconst_0       
        //  1032: bipush          64
        //  1034: aconst_null    
        //  1035: invokespecial   dev/nuker/pyro/f0m.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;DDDDILkotlin/jvm/internal/DefaultConstructorMarker;)V
        //  1038: checkcast       Ldev/nuker/pyro/f0w;
        //  1041: getstatic       dev/nuker/pyro/fc.0:I
        //  1044: ifgt            1052
        //  1047: ldc             -2094399727
        //  1049: goto            1054
        //  1052: ldc             541344428
        //  1054: ldc             -2093096045
        //  1056: ixor           
        //  1057: lookupswitch {
        //          1318018: 1436
        //          1068587196: 1052
        //          default: 1084
        //        }
        //  1084: invokevirtual   dev/nuker/pyro/fbd.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //  1087: checkcast       Ldev/nuker/pyro/f0m;
        //  1090: putfield        dev/nuker/pyro/fbd.c:Ldev/nuker/pyro/f0m;
        //  1093: aload_0        
        //  1094: getfield        dev/nuker/pyro/fbd.c:Ldev/nuker/pyro/f0l;
        //  1097: getstatic       dev/nuker/pyro/fb5.c:Ldev/nuker/pyro/fb5;
        //  1100: checkcast       Ljava/util/function/Consumer;
        //  1103: invokevirtual   dev/nuker/pyro/f0l.c:(Ljava/util/function/Consumer;)V
        //  1106: getstatic       dev/nuker/pyro/fc.c:I
        //  1109: ifne            1117
        //  1112: ldc             -1289011873
        //  1114: goto            1119
        //  1117: ldc             -340175004
        //  1119: ldc             -610126603
        //  1121: ixor           
        //  1122: lookupswitch {
        //          807101329: 1148
        //          1753811370: 1117
        //          default: 1430
        //        }
        //  1148: aload_0        
        //  1149: getfield        dev/nuker/pyro/fbd.0:Ldev/nuker/pyro/f0l;
        //  1152: getstatic       dev/nuker/pyro/fc.c:I
        //  1155: ifne            1163
        //  1158: ldc             -692249219
        //  1160: goto            1165
        //  1163: ldc             384072837
        //  1165: ldc             -1085914014
        //  1167: ixor           
        //  1168: lookupswitch {
        //          1076743351: 1163
        //          1778080031: 1446
        //          default: 1196
        //        }
        //  1196: getstatic       dev/nuker/pyro/fb6.c:Ldev/nuker/pyro/fb6;
        //  1199: checkcast       Ljava/util/function/Consumer;
        //  1202: invokevirtual   dev/nuker/pyro/f0l.c:(Ljava/util/function/Consumer;)V
        //  1205: aload_0        
        //  1206: getfield        dev/nuker/pyro/fbd.1:Ldev/nuker/pyro/f0l;
        //  1209: getstatic       dev/nuker/pyro/fb7.c:Ldev/nuker/pyro/fb7;
        //  1212: checkcast       Ljava/util/function/Consumer;
        //  1215: invokevirtual   dev/nuker/pyro/f0l.c:(Ljava/util/function/Consumer;)V
        //  1218: aload_0        
        //  1219: getfield        dev/nuker/pyro/fbd.2:Ldev/nuker/pyro/f0l;
        //  1222: getstatic       dev/nuker/pyro/fb8.c:Ldev/nuker/pyro/fb8;
        //  1225: checkcast       Ljava/util/function/Consumer;
        //  1228: invokevirtual   dev/nuker/pyro/f0l.c:(Ljava/util/function/Consumer;)V
        //  1231: aload_0        
        //  1232: getfield        dev/nuker/pyro/fbd.3:Ldev/nuker/pyro/f0l;
        //  1235: getstatic       dev/nuker/pyro/fb9.c:Ldev/nuker/pyro/fb9;
        //  1238: checkcast       Ljava/util/function/Consumer;
        //  1241: invokevirtual   dev/nuker/pyro/f0l.c:(Ljava/util/function/Consumer;)V
        //  1244: aload_0        
        //  1245: getfield        dev/nuker/pyro/fbd.4:Ldev/nuker/pyro/f0l;
        //  1248: getstatic       dev/nuker/pyro/fc.c:I
        //  1251: ifne            1259
        //  1254: ldc             1168210600
        //  1256: goto            1261
        //  1259: ldc             1571119451
        //  1261: ldc             803050087
        //  1263: ixor           
        //  1264: lookupswitch {
        //          1786570959: 1438
        //          2002526034: 1259
        //          default: 1292
        //        }
        //  1292: getstatic       dev/nuker/pyro/fba.c:Ldev/nuker/pyro/fba;
        //  1295: checkcast       Ljava/util/function/Consumer;
        //  1298: invokevirtual   dev/nuker/pyro/f0l.c:(Ljava/util/function/Consumer;)V
        //  1301: aload_0        
        //  1302: getstatic       dev/nuker/pyro/fc.1:I
        //  1305: ifne            1313
        //  1308: ldc             783521460
        //  1310: goto            1316
        //  1313: ldc_w           167207114
        //  1316: ldc_w           177460258
        //  1319: ixor           
        //  1320: lookupswitch {
        //          -1286244975: 1313
        //          606093974: 1408
        //          default: 1348
        //        }
        //  1348: getfield        dev/nuker/pyro/fbd.c:Ldev/nuker/pyro/f0m;
        //  1351: getstatic       dev/nuker/pyro/fc.1:I
        //  1354: ifne            1363
        //  1357: ldc_w           1261040111
        //  1360: goto            1366
        //  1363: ldc_w           803530771
        //  1366: ldc_w           -1493206415
        //  1369: ixor           
        //  1370: lookupswitch {
        //          -1994681758: 1396
        //          -304706658: 1363
        //          default: 1410
        //        }
        //  1396: getstatic       dev/nuker/pyro/fbb.c:Ldev/nuker/pyro/fbb;
        //  1399: checkcast       Ljava/util/function/Consumer;
        //  1402: invokevirtual   dev/nuker/pyro/f0m.c:(Ljava/util/function/Consumer;)V
        //  1405: return         
        //  1406: aconst_null    
        //  1407: athrow         
        //  1408: aconst_null    
        //  1409: athrow         
        //  1410: aconst_null    
        //  1411: athrow         
        //  1412: aconst_null    
        //  1413: athrow         
        //  1414: aconst_null    
        //  1415: athrow         
        //  1416: aconst_null    
        //  1417: athrow         
        //  1418: aconst_null    
        //  1419: athrow         
        //  1420: aconst_null    
        //  1421: athrow         
        //  1422: aconst_null    
        //  1423: athrow         
        //  1424: aconst_null    
        //  1425: athrow         
        //  1426: aconst_null    
        //  1427: athrow         
        //  1428: aconst_null    
        //  1429: athrow         
        //  1430: aconst_null    
        //  1431: athrow         
        //  1432: aconst_null    
        //  1433: athrow         
        //  1434: aconst_null    
        //  1435: athrow         
        //  1436: aconst_null    
        //  1437: athrow         
        //  1438: aconst_null    
        //  1439: athrow         
        //  1440: aconst_null    
        //  1441: athrow         
        //  1442: aconst_null    
        //  1443: athrow         
        //  1444: aconst_null    
        //  1445: athrow         
        //  1446: aconst_null    
        //  1447: athrow         
        //  1448: aconst_null    
        //  1449: athrow         
        //    StackMapTable: 00 58 FF 00 13 00 01 06 00 03 06 07 01 0C 07 01 0C FF 00 01 00 01 06 00 04 06 07 01 0C 07 01 0C 01 FF 00 1E 00 01 06 00 03 06 07 01 0C 07 01 0C FF 00 3A 00 01 07 00 03 00 05 07 00 03 07 00 03 08 00 5E 08 00 5E 07 01 0C FF 00 01 00 01 07 00 03 00 06 07 00 03 07 00 03 08 00 5E 08 00 5E 07 01 0C 01 FF 00 1E 00 01 07 00 03 00 05 07 00 03 07 00 03 08 00 5E 08 00 5E 07 01 0C FF 00 14 00 01 07 00 03 00 08 07 00 03 07 00 03 08 00 5E 08 00 5E 07 01 0C 07 01 0C 05 01 FF 00 01 00 01 07 00 03 00 09 07 00 03 07 00 03 08 00 5E 08 00 5E 07 01 0C 07 01 0C 05 01 01 FF 00 1C 00 01 07 00 03 00 08 07 00 03 07 00 03 08 00 5E 08 00 5E 07 01 0C 07 01 0C 05 01 5A 07 00 03 FF 00 01 00 01 07 00 03 00 02 07 00 03 01 5E 07 00 03 FF 00 1D 00 01 07 00 03 00 08 07 00 03 07 00 03 08 01 01 08 01 01 07 01 0C 07 01 0C 05 07 00 67 FF 00 01 00 01 07 00 03 00 09 07 00 03 07 00 03 08 01 01 08 01 01 07 01 0C 07 01 0C 05 07 00 67 01 FF 00 1B 00 01 07 00 03 00 08 07 00 03 07 00 03 08 01 01 08 01 01 07 01 0C 07 01 0C 05 07 00 67 FF 00 36 00 01 07 00 03 00 08 07 00 03 07 00 03 08 01 53 08 01 53 07 01 0C 07 01 0C 05 07 00 6D FF 00 01 00 01 07 00 03 00 09 07 00 03 07 00 03 08 01 53 08 01 53 07 01 0C 07 01 0C 05 07 00 6D 01 FF 00 1E 00 01 07 00 03 00 08 07 00 03 07 00 03 08 01 53 08 01 53 07 01 0C 07 01 0C 05 07 00 6D FF 00 13 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 3E FF 00 01 00 01 07 00 03 00 04 07 00 03 07 00 03 07 00 3E 01 FF 00 1D 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 3E FF 00 10 00 01 07 00 03 00 02 07 00 03 07 00 58 FF 00 01 00 01 07 00 03 00 03 07 00 03 07 00 58 01 FF 00 1C 00 01 07 00 03 00 02 07 00 03 07 00 58 FF 00 24 00 01 07 00 03 00 08 07 00 03 07 00 03 08 01 FD 08 01 FD 07 01 0C 07 01 0C 05 07 00 6D FF 00 01 00 01 07 00 03 00 09 07 00 03 07 00 03 08 01 FD 08 01 FD 07 01 0C 07 01 0C 05 07 00 6D 01 FF 00 1C 00 01 07 00 03 00 08 07 00 03 07 00 03 08 01 FD 08 01 FD 07 01 0C 07 01 0C 05 07 00 6D FF 00 13 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 3E FF 00 01 00 01 07 00 03 00 04 07 00 03 07 00 03 07 00 3E 01 FF 00 1D 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 3E 54 07 00 03 FF 00 01 00 01 07 00 03 00 02 07 00 03 01 5C 07 00 03 FF 00 23 00 01 07 00 03 00 08 07 00 03 07 00 03 08 02 A5 08 02 A5 07 01 0C 07 01 0C 05 07 01 0E FF 00 01 00 01 07 00 03 00 09 07 00 03 07 00 03 08 02 A5 08 02 A5 07 01 0C 07 01 0C 05 07 01 0E 01 FF 00 1D 00 01 07 00 03 00 08 07 00 03 07 00 03 08 02 A5 08 02 A5 07 01 0C 07 01 0C 05 07 01 0E FF 00 21 00 01 07 00 03 00 05 07 00 03 07 00 03 08 02 F9 08 02 F9 07 01 0C FF 00 01 00 01 07 00 03 00 06 07 00 03 07 00 03 08 02 F9 08 02 F9 07 01 0C 01 FF 00 1B 00 01 07 00 03 00 05 07 00 03 07 00 03 08 02 F9 08 02 F9 07 01 0C FF 00 1C 00 01 07 00 03 00 08 07 00 03 07 00 03 08 02 F9 08 02 F9 07 01 0C 07 01 0C 05 07 01 0E FF 00 01 00 01 07 00 03 00 09 07 00 03 07 00 03 08 02 F9 08 02 F9 07 01 0C 07 01 0C 05 07 01 0E 01 FF 00 1C 00 01 07 00 03 00 08 07 00 03 07 00 03 08 02 F9 08 02 F9 07 01 0C 07 01 0C 05 07 01 0E FF 00 10 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 3E FF 00 01 00 01 07 00 03 00 04 07 00 03 07 00 03 07 00 3E 01 FF 00 1C 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 3E FF 00 2D 00 01 07 00 03 00 08 07 00 03 07 00 03 08 03 9F 08 03 9F 07 01 0C 07 01 0C 05 07 01 0E FF 00 01 00 01 07 00 03 00 09 07 00 03 07 00 03 08 03 9F 08 03 9F 07 01 0C 07 01 0C 05 07 01 0E 01 FF 00 1B 00 01 07 00 03 00 08 07 00 03 07 00 03 08 03 9F 08 03 9F 07 01 0C 07 01 0C 05 07 01 0E FF 00 3B 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 3E FF 00 01 00 01 07 00 03 00 04 07 00 03 07 00 03 07 00 3E 01 FF 00 1D 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 3E 20 41 01 1C 4E 07 00 58 FF 00 01 00 01 07 00 03 00 02 07 00 58 01 5E 07 00 58 7E 07 00 58 FF 00 01 00 01 07 00 03 00 02 07 00 58 01 5E 07 00 58 54 07 00 03 FF 00 02 00 01 07 00 03 00 02 07 00 03 01 5F 07 00 03 4E 07 00 C2 FF 00 02 00 01 07 00 03 00 02 07 00 C2 01 5D 07 00 C2 FF 00 09 00 01 07 00 03 00 08 07 00 03 07 00 03 08 02 F9 08 02 F9 07 01 0C 07 01 0C 05 07 01 0E 41 07 00 03 41 07 00 C2 FF 00 01 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 3E FF 00 01 00 01 07 00 03 00 05 07 00 03 07 00 03 08 00 5E 08 00 5E 07 01 0C 41 07 00 03 FF 00 01 00 01 07 00 03 00 08 07 00 03 07 00 03 08 00 5E 08 00 5E 07 01 0C 07 01 0C 05 01 FF 00 01 00 01 07 00 03 00 08 07 00 03 07 00 03 08 02 A5 08 02 A5 07 01 0C 07 01 0C 05 07 01 0E FF 00 01 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 3E 41 07 00 03 FF 00 01 00 01 07 00 03 00 02 07 00 03 07 00 58 FF 00 01 00 01 07 00 03 00 08 07 00 03 07 00 03 08 03 9F 08 03 9F 07 01 0C 07 01 0C 05 07 01 0E 01 FF 00 01 00 01 07 00 03 00 08 07 00 03 07 00 03 08 01 FD 08 01 FD 07 01 0C 07 01 0C 05 07 00 6D FF 00 01 00 01 06 00 03 06 07 01 0C 07 01 0C FF 00 01 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 3E 41 07 00 58 FF 00 01 00 01 07 00 03 00 08 07 00 03 07 00 03 08 01 01 08 01 01 07 01 0C 07 01 0C 05 07 00 67 FF 00 01 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 3E FF 00 01 00 01 07 00 03 00 05 07 00 03 07 00 03 08 02 F9 08 02 F9 07 01 0C 41 07 00 58 FF 00 01 00 01 07 00 03 00 08 07 00 03 07 00 03 08 01 53 08 01 53 07 01 0C 07 01 0C 05 07 00 6D
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void c(final boolean b, @Nullable final EntityPlayerSP entityPlayerSP, @Nullable final World world) {
        fez.55(this, 1757575315, b, entityPlayerSP, world);
    }
}
