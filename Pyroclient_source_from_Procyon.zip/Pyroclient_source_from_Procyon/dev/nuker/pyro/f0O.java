// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import org.jetbrains.annotations.NotNull;
import kotlin.jvm.JvmField;

public class f0O extends f0Y
{
    @JvmField
    @NotNull
    public fw<Object> c;
    public String c;
    public Enum[] c;
    public String 0;
    public double c;
    public boolean c;
    
    @Override
    public int 0(@NotNull final f0F f0F, @NotNull final f0H f0H) {
        return fez.jg(this, 1266024855, f0F, f0H);
    }
    
    static {
        throw t;
    }
    
    @Override
    public void 0(@NotNull final f0F f0F, @NotNull final f0H f0H, @NotNull final f17 f17) {
        fez.0t(this, 1295552384, f0F, f0H, f17);
    }
    
    public f0O(@NotNull final f0o p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: ifne            11
        //     6: ldc             964077626
        //     8: goto            13
        //    11: ldc             939958136
        //    13: ldc             -564809156
        //    15: ixor           
        //    16: lookupswitch {
        //          -1525583649: 11
        //          -417129978: 675
        //          default: 44
        //        }
        //    44: aload_1        
        //    45: pop            
        //    46: aload_0        
        //    47: aload_1        
        //    48: checkcast       Ldev/nuker/pyro/f0w;
        //    51: invokespecial   dev/nuker/pyro/f0Y.<init>:(Ldev/nuker/pyro/f0w;)V
        //    54: aload_0        
        //    55: aload_1        
        //    56: getstatic       dev/nuker/pyro/fc.c:I
        //    59: ifne            67
        //    62: ldc             -774392380
        //    64: goto            69
        //    67: ldc             -1001431464
        //    69: ldc             -654113768
        //    71: ixor           
        //    72: lookupswitch {
        //          148156892: 67
        //          491543104: 100
        //          default: 691
        //        }
        //   100: invokevirtual   dev/nuker/pyro/f0o.c:()Ljava/lang/String;
        //   103: putfield        dev/nuker/pyro/f0O.c:Ljava/lang/String;
        //   106: aload_0        
        //   107: ldc             ""
        //   109: putfield        dev/nuker/pyro/f0O.0:Ljava/lang/String;
        //   112: aload_0        
        //   113: getstatic       dev/nuker/pyro/fc.1:I
        //   116: ifne            124
        //   119: ldc             896964987
        //   121: goto            126
        //   124: ldc             1552738434
        //   126: ldc             -1147760895
        //   128: ixor           
        //   129: lookupswitch {
        //          -1897916806: 124
        //          -417699965: 156
        //          default: 687
        //        }
        //   156: aload_1        
        //   157: getstatic       dev/nuker/pyro/fc.1:I
        //   160: ifne            168
        //   163: ldc             -1669367195
        //   165: goto            170
        //   168: ldc             -1943740910
        //   170: ldc             1166347179
        //   172: ixor           
        //   173: lookupswitch {
        //          -637898290: 693
        //          767120906: 168
        //          default: 200
        //        }
        //   200: invokevirtual   dev/nuker/pyro/f0o.5:()Ldev/nuker/pyro/fw;
        //   203: putfield        dev/nuker/pyro/f0O.c:Ldev/nuker/pyro/fw;
        //   206: getstatic       dev/nuker/pyro/fc.0:I
        //   209: ifgt            217
        //   212: ldc             2118274113
        //   214: goto            219
        //   217: ldc             -1540533992
        //   219: ldc             818869404
        //   221: ixor           
        //   222: lookupswitch {
        //          -1797020284: 248
        //          1317845213: 217
        //          default: 683
        //        }
        //   248: aload_0        
        //   249: getstatic       dev/nuker/pyro/fc.0:I
        //   252: ifgt            260
        //   255: ldc             268180971
        //   257: goto            262
        //   260: ldc             250823482
        //   262: ldc             -1915925799
        //   264: ixor           
        //   265: lookupswitch {
        //          -2110695630: 260
        //          -2093086237: 292
        //          default: 695
        //        }
        //   292: aload_0        
        //   293: getfield        dev/nuker/pyro/f0O.c:Ldev/nuker/pyro/fw;
        //   296: invokevirtual   dev/nuker/pyro/fw.0:()Ljava/lang/Object;
        //   299: dup            
        //   300: ifnonnull       308
        //   303: ldc             1974986197
        //   305: goto            310
        //   308: ldc             1974986196
        //   310: ldc             -1021452223
        //   312: ixor           
        //   313: tableswitch {
        //          1834224424: 336
        //          1834224425: 339
        //          default: 303
        //        }
        //   336: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //   339: checkcast       Ljava/lang/Enum;
        //   342: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //   345: invokevirtual   java/lang/Class.getEnumConstants:()[Ljava/lang/Object;
        //   348: dup            
        //   349: ifnonnull       357
        //   352: ldc             -923800233
        //   354: goto            359
        //   357: ldc             -923800248
        //   359: ldc             -1554074344
        //   361: ixor           
        //   362: tableswitch {
        //          -681398114: 384
        //          -681398113: 480
        //          default: 352
        //        }
        //   384: new             Lkotlin/TypeCastException;
        //   387: dup            
        //   388: ldc             "\u3d88\ub250\u8ec0\uada8\u66f5\u5960\u7e41\u69d5\uc2cd\ua25c\u9b2b\u1344\uc1b8\u710b\u9124\u4d68\ub210\u4c43\u0156\u06c6\u1267\ufecb\u6a4c\u885a\u3799\u3de2\u7fb6\ua9aa\ud1f5\u7385\u44a4\u6bee\u74de\u9761\uc67e\u43e1\ufdac\u1041\u1849\u4b13\u66cd\uac0b\u8df4\uf968\ubd7f\ua4eb\u4c30\u3fcb\u4a3b\ua380\u78aa\u913c"
        //   390: getstatic       dev/nuker/pyro/fc.1:I
        //   393: ifne            401
        //   396: ldc             -1467444650
        //   398: goto            403
        //   401: ldc             600305437
        //   403: ldc             1835892880
        //   405: ixor           
        //   406: lookupswitch {
        //          -974843194: 401
        //          1319792525: 432
        //          default: 681
        //        }
        //   432: invokestatic    invokestatic   !!! ERROR
        //   435: getstatic       dev/nuker/pyro/fc.1:I
        //   438: ifne            446
        //   441: ldc             -1938414591
        //   443: goto            448
        //   446: ldc             1395541453
        //   448: ldc             2029850292
        //   450: ixor           
        //   451: lookupswitch {
        //          -192206155: 446
        //          735267705: 476
        //          default: 677
        //        }
        //   476: invokespecial   kotlin/TypeCastException.<init>:(Ljava/lang/String;)V
        //   479: athrow         
        //   480: checkcast       [Ljava/lang/Enum;
        //   483: putfield        dev/nuker/pyro/f0O.c:[Ljava/lang/Enum;
        //   486: getstatic       dev/nuker/pyro/fc.0:I
        //   489: ifgt            497
        //   492: ldc             -450917689
        //   494: goto            499
        //   497: ldc             1340074829
        //   499: ldc             663062346
        //   501: ixor           
        //   502: lookupswitch {
        //          -1030091379: 689
        //          1891855306: 497
        //          default: 528
        //        }
        //   528: aload_0        
        //   529: getfield        dev/nuker/pyro/f0O.c:[Ljava/lang/Enum;
        //   532: astore          4
        //   534: aload           4
        //   536: arraylength    
        //   537: getstatic       dev/nuker/pyro/fc.c:I
        //   540: ifne            548
        //   543: ldc             -708098215
        //   545: goto            550
        //   548: ldc             1573710853
        //   550: ldc             679708209
        //   552: ixor           
        //   553: lookupswitch {
        //          -45563544: 685
        //          1548379522: 548
        //          default: 580
        //        }
        //   580: istore          5
        //   582: iconst_0       
        //   583: istore_3       
        //   584: iload_3        
        //   585: iload           5
        //   587: if_icmpge       674
        //   590: aload           4
        //   592: iload_3        
        //   593: aaload         
        //   594: astore_2       
        //   595: getstatic       dev/nuker/pyro/fc.1:I
        //   598: ifne            606
        //   601: ldc             420220512
        //   603: goto            608
        //   606: ldc             758899155
        //   608: ldc             1078726087
        //   610: ixor           
        //   611: lookupswitch {
        //          1497367463: 606
        //          1836575764: 636
        //          default: 679
        //        }
        //   636: aload_2        
        //   637: dup            
        //   638: ifnonnull       644
        //   641: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //   644: invokevirtual   java/lang/Enum.name:()Ljava/lang/String;
        //   647: invokevirtual   java/lang/String.length:()I
        //   650: aload_0        
        //   651: getfield        dev/nuker/pyro/f0O.0:Ljava/lang/String;
        //   654: invokevirtual   java/lang/String.length:()I
        //   657: if_icmple       668
        //   660: aload_0        
        //   661: aload_2        
        //   662: invokevirtual   java/lang/Enum.name:()Ljava/lang/String;
        //   665: putfield        dev/nuker/pyro/f0O.0:Ljava/lang/String;
        //   668: iinc            3, 1
        //   671: goto            584
        //   674: return         
        //   675: aconst_null    
        //   676: athrow         
        //   677: aconst_null    
        //   678: athrow         
        //   679: aconst_null    
        //   680: athrow         
        //   681: aconst_null    
        //   682: athrow         
        //   683: aconst_null    
        //   684: athrow         
        //   685: aconst_null    
        //   686: athrow         
        //   687: aconst_null    
        //   688: athrow         
        //   689: aconst_null    
        //   690: athrow         
        //   691: aconst_null    
        //   692: athrow         
        //   693: aconst_null    
        //   694: athrow         
        //   695: aconst_null    
        //   696: athrow         
        //    StackMapTable: 00 3A 0B 41 01 1E FF 00 16 00 02 07 00 03 07 00 34 00 02 07 00 03 07 00 34 FF 00 01 00 02 07 00 03 07 00 34 00 03 07 00 03 07 00 34 01 FF 00 1E 00 02 07 00 03 07 00 34 00 02 07 00 03 07 00 34 57 07 00 03 FF 00 01 00 02 07 00 03 07 00 34 00 02 07 00 03 01 5D 07 00 03 FF 00 0B 00 02 07 00 03 07 00 34 00 02 07 00 03 07 00 34 FF 00 01 00 02 07 00 03 07 00 34 00 03 07 00 03 07 00 34 01 FF 00 1D 00 02 07 00 03 07 00 34 00 02 07 00 03 07 00 34 10 41 01 1C 4B 07 00 03 FF 00 01 00 02 07 00 03 07 00 34 00 02 07 00 03 01 5D 07 00 03 FF 00 0A 00 02 07 00 03 07 00 34 00 02 07 00 03 07 00 66 FF 00 04 00 02 07 00 03 07 00 34 00 02 07 00 03 07 00 66 FF 00 01 00 02 07 00 03 07 00 34 00 03 07 00 03 07 00 66 01 FF 00 19 00 02 07 00 03 07 00 34 00 02 07 00 03 07 00 66 FF 00 02 00 02 07 00 03 07 00 34 00 02 07 00 03 07 00 66 FF 00 0C 00 02 07 00 03 07 00 34 00 02 07 00 03 07 00 9C FF 00 04 00 02 07 00 03 07 00 34 00 02 07 00 03 07 00 9C FF 00 01 00 02 07 00 03 07 00 34 00 03 07 00 03 07 00 9C 01 FF 00 18 00 02 07 00 03 07 00 34 00 02 07 00 03 07 00 9C FF 00 10 00 02 07 00 03 07 00 34 00 05 07 00 03 07 00 9C 08 01 80 08 01 80 07 00 96 FF 00 01 00 02 07 00 03 07 00 34 00 06 07 00 03 07 00 9C 08 01 80 08 01 80 07 00 96 01 FF 00 1C 00 02 07 00 03 07 00 34 00 05 07 00 03 07 00 9C 08 01 80 08 01 80 07 00 96 FF 00 0D 00 02 07 00 03 07 00 34 00 05 07 00 03 07 00 9C 08 01 80 08 01 80 07 00 96 FF 00 01 00 02 07 00 03 07 00 34 00 06 07 00 03 07 00 9C 08 01 80 08 01 80 07 00 96 01 FF 00 1B 00 02 07 00 03 07 00 34 00 05 07 00 03 07 00 9C 08 01 80 08 01 80 07 00 96 FF 00 03 00 02 07 00 03 07 00 34 00 02 07 00 03 07 00 9C 10 41 01 1C FF 00 13 00 05 07 00 03 07 00 34 00 00 07 00 86 00 01 01 FF 00 01 00 05 07 00 03 07 00 34 00 00 07 00 86 00 02 01 01 5D 01 FF 00 03 00 06 07 00 03 07 00 34 00 01 07 00 86 01 00 00 FF 00 15 00 06 07 00 03 07 00 34 07 00 64 01 07 00 86 01 00 00 41 01 1B 47 07 00 64 17 FF 00 05 00 06 07 00 03 07 00 34 00 01 07 00 86 01 00 00 FF 00 00 00 02 06 07 00 34 00 00 FF 00 01 00 02 07 00 03 07 00 34 00 05 07 00 03 07 00 9C 08 01 80 08 01 80 07 00 96 FF 00 01 00 06 07 00 03 07 00 34 07 00 64 01 07 00 86 01 00 00 FF 00 01 00 02 07 00 03 07 00 34 00 05 07 00 03 07 00 9C 08 01 80 08 01 80 07 00 96 01 FF 00 01 00 05 07 00 03 07 00 34 00 00 07 00 86 00 01 01 FF 00 01 00 02 07 00 03 07 00 34 00 01 07 00 03 01 FF 00 01 00 02 07 00 03 07 00 34 00 02 07 00 03 07 00 34 FF 00 01 00 02 07 00 03 07 00 34 00 02 07 00 03 07 00 34 41 07 00 03
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void 0(@NotNull final f0F p0, final double p1, final double p2, @NotNull final f0H p3) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          1858
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            1850
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            1842
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: aload           6
        //    28: pop            
        //    29: aload_0        
        //    30: getstatic       dev/nuker/pyro/fc.0:I
        //    33: ifgt            41
        //    36: ldc             1030670603
        //    38: goto            43
        //    41: ldc             1509381372
        //    43: ldc             -414990626
        //    45: ixor           
        //    46: lookupswitch {
        //          -634554411: 1797
        //          1988452233: 41
        //          default: 72
        //        }
        //    72: aload_1        
        //    73: dload_2        
        //    74: getstatic       dev/nuker/pyro/fc.c:I
        //    77: ifne            85
        //    80: ldc             574915126
        //    82: goto            87
        //    85: ldc             1515545735
        //    87: ldc             116387942
        //    89: ixor           
        //    90: lookupswitch {
        //          615215696: 85
        //          1555731681: 116
        //          default: 1805
        //        }
        //   116: dload           4
        //   118: getstatic       dev/nuker/pyro/fc.0:I
        //   121: ifgt            129
        //   124: ldc             -1236782870
        //   126: goto            131
        //   129: ldc             964064528
        //   131: ldc             1283490386
        //   133: ixor           
        //   134: lookupswitch {
        //          -87510344: 1827
        //          1821047589: 129
        //          default: 160
        //        }
        //   160: aload           6
        //   162: goto            166
        //   165: athrow         
        //   166: invokespecial   dev/nuker/pyro/f0Y.0:(Ldev/nuker/pyro/f0F;DDLdev/nuker/pyro/f0H;)V
        //   169: goto            173
        //   172: athrow         
        //   173: getstatic       dev/nuker/pyro/fc.0:I
        //   176: ifgt            184
        //   179: ldc             411877972
        //   181: goto            186
        //   184: ldc             -90181920
        //   186: ldc             -85663602
        //   188: ixor           
        //   189: lookupswitch {
        //          -496491814: 1807
        //          -65668076: 184
        //          default: 216
        //        }
        //   216: getstatic       dev/nuker/pyro/f0J.c:Ldev/nuker/pyro/f0J;
        //   219: getstatic       dev/nuker/pyro/fc.c:I
        //   222: ifne            230
        //   225: ldc             807983852
        //   227: goto            232
        //   230: ldc             -1724791859
        //   232: ldc             423240936
        //   234: ixor           
        //   235: lookupswitch {
        //          -1073059185: 230
        //          689110532: 1813
        //          default: 260
        //        }
        //   260: aload_1        
        //   261: goto            265
        //   264: athrow         
        //   265: invokevirtual   dev/nuker/pyro/f0F.0:()Lnet/minecraft/client/gui/FontRenderer;
        //   268: goto            272
        //   271: athrow         
        //   272: getstatic       dev/nuker/pyro/fc.0:I
        //   275: ifgt            283
        //   278: ldc             -913572675
        //   280: goto            285
        //   283: ldc             47077126
        //   285: ldc             -825209659
        //   287: ixor           
        //   288: lookupswitch {
        //          123449464: 1817
        //          908052443: 283
        //          default: 316
        //        }
        //   316: aload_0        
        //   317: getfield        dev/nuker/pyro/f0O.c:Ljava/lang/String;
        //   320: iconst_0       
        //   321: getstatic       dev/nuker/pyro/f0H.c:I
        //   324: aload_1        
        //   325: goto            329
        //   328: athrow         
        //   329: invokevirtual   dev/nuker/pyro/f0F.1:()I
        //   332: goto            336
        //   335: athrow         
        //   336: iconst_4       
        //   337: isub           
        //   338: aload_1        
        //   339: goto            343
        //   342: athrow         
        //   343: invokevirtual   dev/nuker/pyro/f0F.3:()I
        //   346: goto            350
        //   349: athrow         
        //   350: getstatic       dev/nuker/pyro/f0H.c:I
        //   353: iconst_2       
        //   354: imul           
        //   355: isub           
        //   356: iconst_4       
        //   357: isub           
        //   358: getstatic       dev/nuker/pyro/f0G.c:Ldev/nuker/pyro/f0G;
        //   361: getstatic       dev/nuker/pyro/f0H.c:I
        //   364: getstatic       dev/nuker/pyro/fc.c:I
        //   367: ifne            375
        //   370: ldc             1255647437
        //   372: goto            377
        //   375: ldc             1975210080
        //   377: ldc             583607079
        //   379: ixor           
        //   380: lookupswitch {
        //          1746832362: 1829
        //          1834055237: 375
        //          default: 408
        //        }
        //   408: aload           6
        //   410: getstatic       dev/nuker/pyro/fc.c:I
        //   413: ifne            421
        //   416: ldc             -1796381558
        //   418: goto            423
        //   421: ldc             220932037
        //   423: ldc             -137878667
        //   425: ixor           
        //   426: lookupswitch {
        //          -85785424: 452
        //          1663387647: 421
        //          default: 1819
        //        }
        //   452: goto            456
        //   455: athrow         
        //   456: invokevirtual   dev/nuker/pyro/f0H.b:()I
        //   459: goto            463
        //   462: athrow         
        //   463: iconst_0       
        //   464: sipush          512
        //   467: aconst_null    
        //   468: getstatic       dev/nuker/pyro/fc.c:I
        //   471: ifne            479
        //   474: ldc             172864347
        //   476: goto            481
        //   479: ldc             -1983129795
        //   481: ldc             -1314948613
        //   483: ixor           
        //   484: lookupswitch {
        //          -1143813472: 1823
        //          1362456287: 479
        //          default: 512
        //        }
        //   512: goto            516
        //   515: athrow         
        //   516: invokestatic    dev/nuker/pyro/f0J.c:(Ldev/nuker/pyro/f0J;Lnet/minecraft/client/gui/FontRenderer;Ljava/lang/String;IIIILdev/nuker/pyro/f0G;IIZILjava/lang/Object;)V
        //   519: goto            523
        //   522: athrow         
        //   523: getstatic       dev/nuker/pyro/fc.c:I
        //   526: ifne            534
        //   529: ldc             -1905569962
        //   531: goto            536
        //   534: ldc             -426662417
        //   536: ldc             698002748
        //   538: ixor           
        //   539: lookupswitch {
        //          -1477320086: 534
        //          -821360429: 564
        //          default: 1795
        //        }
        //   564: getstatic       dev/nuker/pyro/f0J.c:Ldev/nuker/pyro/f0J;
        //   567: aload_1        
        //   568: getstatic       dev/nuker/pyro/fc.c:I
        //   571: ifne            579
        //   574: ldc             682705945
        //   576: goto            581
        //   579: ldc             1559637645
        //   581: ldc             1200757576
        //   583: ixor           
        //   584: lookupswitch {
        //          459552197: 612
        //          1864589137: 579
        //          default: 1789
        //        }
        //   612: goto            616
        //   615: athrow         
        //   616: invokevirtual   dev/nuker/pyro/f0F.0:()Lnet/minecraft/client/gui/FontRenderer;
        //   619: goto            623
        //   622: athrow         
        //   623: aload_0        
        //   624: getfield        dev/nuker/pyro/f0O.c:Ldev/nuker/pyro/fw;
        //   627: goto            631
        //   630: athrow         
        //   631: invokevirtual   dev/nuker/pyro/fw.0:()Ljava/lang/Object;
        //   634: goto            638
        //   637: athrow         
        //   638: dup            
        //   639: ifnonnull       648
        //   642: ldc_w           -1339777695
        //   645: goto            651
        //   648: ldc_w           -1339777696
        //   651: ldc_w           1317489075
        //   654: ixor           
        //   655: tableswitch {
        //          -45635164: 676
        //          -45635163: 687
        //          default: 642
        //        }
        //   676: goto            680
        //   679: athrow         
        //   680: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //   683: goto            687
        //   686: athrow         
        //   687: checkcast       Ljava/lang/Enum;
        //   690: goto            694
        //   693: athrow         
        //   694: invokevirtual   java/lang/Enum.name:()Ljava/lang/String;
        //   697: goto            701
        //   700: athrow         
        //   701: iconst_0       
        //   702: getstatic       dev/nuker/pyro/f0H.c:I
        //   705: aload_1        
        //   706: getstatic       dev/nuker/pyro/fc.c:I
        //   709: ifne            718
        //   712: ldc_w           -187366977
        //   715: goto            721
        //   718: ldc_w           1901612015
        //   721: ldc_w           991417509
        //   724: ixor           
        //   725: lookupswitch {
        //          -809315046: 718
        //          1246732106: 752
        //          default: 1785
        //        }
        //   752: goto            756
        //   755: athrow         
        //   756: invokevirtual   dev/nuker/pyro/f0F.1:()I
        //   759: goto            763
        //   762: athrow         
        //   763: iconst_4       
        //   764: isub           
        //   765: aload_1        
        //   766: goto            770
        //   769: athrow         
        //   770: invokevirtual   dev/nuker/pyro/f0F.3:()I
        //   773: goto            777
        //   776: athrow         
        //   777: getstatic       dev/nuker/pyro/fc.c:I
        //   780: ifne            789
        //   783: ldc_w           691704397
        //   786: goto            792
        //   789: ldc_w           -471547958
        //   792: ldc_w           994905077
        //   795: ixor           
        //   796: lookupswitch {
        //          -1719339439: 789
        //          309828024: 1803
        //          default: 824
        //        }
        //   824: getstatic       dev/nuker/pyro/f0H.c:I
        //   827: iconst_2       
        //   828: imul           
        //   829: isub           
        //   830: iconst_4       
        //   831: isub           
        //   832: getstatic       dev/nuker/pyro/f0G.0:Ldev/nuker/pyro/f0G;
        //   835: getstatic       dev/nuker/pyro/f0H.c:I
        //   838: aload           6
        //   840: goto            844
        //   843: athrow         
        //   844: invokevirtual   dev/nuker/pyro/f0H.b:()I
        //   847: goto            851
        //   850: athrow         
        //   851: iconst_0       
        //   852: sipush          512
        //   855: aconst_null    
        //   856: getstatic       dev/nuker/pyro/fc.1:I
        //   859: ifne            868
        //   862: ldc_w           -1514459860
        //   865: goto            871
        //   868: ldc_w           -593075967
        //   871: ldc_w           -2087560171
        //   874: ixor           
        //   875: lookupswitch {
        //          640250169: 1809
        //          993915711: 868
        //          default: 900
        //        }
        //   900: goto            904
        //   903: athrow         
        //   904: invokestatic    dev/nuker/pyro/f0J.c:(Ldev/nuker/pyro/f0J;Lnet/minecraft/client/gui/FontRenderer;Ljava/lang/String;IIIILdev/nuker/pyro/f0G;IIZILjava/lang/Object;)V
        //   907: goto            911
        //   910: athrow         
        //   911: aload_1        
        //   912: goto            916
        //   915: athrow         
        //   916: invokevirtual   dev/nuker/pyro/f0F.1:()I
        //   919: goto            923
        //   922: athrow         
        //   923: getstatic       dev/nuker/pyro/f0H.c:I
        //   926: iconst_2       
        //   927: imul           
        //   928: isub           
        //   929: aload_0        
        //   930: getfield        dev/nuker/pyro/f0O.c:[Ljava/lang/Enum;
        //   933: arraylength    
        //   934: idiv           
        //   935: istore          7
        //   937: iload           7
        //   939: aload_0        
        //   940: getstatic       dev/nuker/pyro/fc.c:I
        //   943: ifne            952
        //   946: ldc_w           413315681
        //   949: goto            955
        //   952: ldc_w           570599895
        //   955: ldc_w           139290221
        //   958: ixor           
        //   959: lookupswitch {
        //          284152844: 952
        //          709873594: 984
        //          default: 1825
        //        }
        //   984: getfield        dev/nuker/pyro/f0O.c:Ldev/nuker/pyro/fw;
        //   987: goto            991
        //   990: athrow         
        //   991: invokevirtual   dev/nuker/pyro/fw.0:()Ljava/lang/Object;
        //   994: goto            998
        //   997: athrow         
        //   998: dup            
        //   999: ifnonnull       1013
        //  1002: goto            1006
        //  1005: athrow         
        //  1006: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //  1009: goto            1013
        //  1012: athrow         
        //  1013: checkcast       Ljava/lang/Enum;
        //  1016: goto            1020
        //  1019: athrow         
        //  1020: invokevirtual   java/lang/Enum.ordinal:()I
        //  1023: goto            1027
        //  1026: athrow         
        //  1027: imul           
        //  1028: istore          8
        //  1030: getstatic       dev/nuker/pyro/fc.0:I
        //  1033: ifgt            1042
        //  1036: ldc_w           -1097795438
        //  1039: goto            1045
        //  1042: ldc_w           1379960397
        //  1045: ldc_w           1501782228
        //  1048: ixor           
        //  1049: lookupswitch {
        //          -418146234: 1821
        //          173082991: 1042
        //          default: 1076
        //        }
        //  1076: aload_0        
        //  1077: getstatic       dev/nuker/pyro/fc.0:I
        //  1080: ifgt            1089
        //  1083: ldc_w           -1014774565
        //  1086: goto            1092
        //  1089: ldc_w           -54007140
        //  1092: ldc_w           1026803108
        //  1095: ixor           
        //  1096: lookupswitch {
        //          -22019713: 1787
        //          1423723195: 1089
        //          default: 1124
        //        }
        //  1124: getfield        dev/nuker/pyro/f0O.c:Ldev/nuker/pyro/fw;
        //  1127: goto            1131
        //  1130: athrow         
        //  1131: invokevirtual   dev/nuker/pyro/fw.0:()Ljava/lang/Object;
        //  1134: goto            1138
        //  1137: athrow         
        //  1138: dup            
        //  1139: ifnonnull       1148
        //  1142: ldc_w           915798620
        //  1145: goto            1151
        //  1148: ldc_w           915798621
        //  1151: ldc_w           84995078
        //  1154: ixor           
        //  1155: tableswitch {
        //          1728720052: 1176
        //          1728720053: 1187
        //          default: 1142
        //        }
        //  1176: goto            1180
        //  1179: athrow         
        //  1180: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //  1183: goto            1187
        //  1186: athrow         
        //  1187: checkcast       Ljava/lang/Enum;
        //  1190: goto            1194
        //  1193: athrow         
        //  1194: invokevirtual   java/lang/Enum.ordinal:()I
        //  1197: goto            1201
        //  1200: athrow         
        //  1201: getstatic       dev/nuker/pyro/fc.c:I
        //  1204: ifne            1213
        //  1207: ldc_w           1256446409
        //  1210: goto            1216
        //  1213: ldc_w           -393944598
        //  1216: ldc_w           -667944273
        //  1219: ixor           
        //  1220: lookupswitch {
        //          -1832115354: 1213
        //          816520005: 1248
        //          default: 1811
        //        }
        //  1248: aload_0        
        //  1249: getstatic       dev/nuker/pyro/fc.c:I
        //  1252: ifne            1261
        //  1255: ldc_w           501768499
        //  1258: goto            1264
        //  1261: ldc_w           1833988096
        //  1264: ldc_w           233097566
        //  1267: ixor           
        //  1268: lookupswitch {
        //          269265005: 1261
        //          1622456670: 1296
        //          default: 1791
        //        }
        //  1296: getfield        dev/nuker/pyro/f0O.c:[Ljava/lang/Enum;
        //  1299: arraylength    
        //  1300: iconst_1       
        //  1301: isub           
        //  1302: if_icmpne       1311
        //  1305: ldc_w           -1678543118
        //  1308: goto            1314
        //  1311: ldc_w           -1678543117
        //  1314: ldc_w           -477563890
        //  1317: ixor           
        //  1318: tableswitch {
        //          -252246536: 1340
        //          -252246535: 1405
        //          default: 1305
        //        }
        //  1340: getstatic       dev/nuker/pyro/fc.1:I
        //  1343: ifne            1352
        //  1346: ldc_w           -2047004976
        //  1349: goto            1355
        //  1352: ldc_w           -1579763215
        //  1355: ldc_w           595525168
        //  1358: ixor           
        //  1359: lookupswitch {
        //          -2102900799: 1384
        //          -1501310752: 1352
        //          default: 1793
        //        }
        //  1384: aload_1        
        //  1385: goto            1389
        //  1388: athrow         
        //  1389: invokevirtual   dev/nuker/pyro/f0F.1:()I
        //  1392: goto            1396
        //  1395: athrow         
        //  1396: getstatic       dev/nuker/pyro/f0H.c:I
        //  1399: iconst_2       
        //  1400: imul           
        //  1401: isub           
        //  1402: goto            1499
        //  1405: iload           7
        //  1407: aload_0        
        //  1408: getfield        dev/nuker/pyro/f0O.c:Ldev/nuker/pyro/fw;
        //  1411: getstatic       dev/nuker/pyro/fc.1:I
        //  1414: ifne            1423
        //  1417: ldc_w           156315604
        //  1420: goto            1426
        //  1423: ldc_w           81558144
        //  1426: ldc_w           669425562
        //  1429: ixor           
        //  1430: lookupswitch {
        //          591062298: 1456
        //          783790158: 1423
        //          default: 1815
        //        }
        //  1456: goto            1460
        //  1459: athrow         
        //  1460: invokevirtual   dev/nuker/pyro/fw.0:()Ljava/lang/Object;
        //  1463: goto            1467
        //  1466: athrow         
        //  1467: dup            
        //  1468: ifnonnull       1482
        //  1471: goto            1475
        //  1474: athrow         
        //  1475: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //  1478: goto            1482
        //  1481: athrow         
        //  1482: checkcast       Ljava/lang/Enum;
        //  1485: goto            1489
        //  1488: athrow         
        //  1489: invokevirtual   java/lang/Enum.ordinal:()I
        //  1492: goto            1496
        //  1495: athrow         
        //  1496: iconst_1       
        //  1497: iadd           
        //  1498: imul           
        //  1499: istore          9
        //  1501: getstatic       dev/nuker/pyro/f0H.c:I
        //  1504: aload_1        
        //  1505: goto            1509
        //  1508: athrow         
        //  1509: invokevirtual   dev/nuker/pyro/f0F.3:()I
        //  1512: goto            1516
        //  1515: athrow         
        //  1516: getstatic       dev/nuker/pyro/f0H.c:I
        //  1519: isub           
        //  1520: aload_1        
        //  1521: goto            1525
        //  1524: athrow         
        //  1525: invokevirtual   dev/nuker/pyro/f0F.1:()I
        //  1528: goto            1532
        //  1531: athrow         
        //  1532: getstatic       dev/nuker/pyro/f0H.c:I
        //  1535: isub           
        //  1536: aload_1        
        //  1537: goto            1541
        //  1540: athrow         
        //  1541: invokevirtual   dev/nuker/pyro/f0F.3:()I
        //  1544: goto            1548
        //  1547: athrow         
        //  1548: getstatic       dev/nuker/pyro/f0H.c:I
        //  1551: isub           
        //  1552: iconst_1       
        //  1553: isub           
        //  1554: aload           6
        //  1556: goto            1560
        //  1559: athrow         
        //  1560: invokevirtual   dev/nuker/pyro/f0H.b:()I
        //  1563: goto            1567
        //  1566: athrow         
        //  1567: getstatic       dev/nuker/pyro/fc.0:I
        //  1570: ifgt            1579
        //  1573: ldc_w           -882636536
        //  1576: goto            1582
        //  1579: ldc_w           -791779960
        //  1582: ldc_w           -2131364192
        //  1585: ixor           
        //  1586: lookupswitch {
        //          -1337748458: 1579
        //          1267859368: 1831
        //          default: 1612
        //        }
        //  1612: goto            1616
        //  1615: athrow         
        //  1616: invokestatic    net/minecraft/client/gui/Gui.func_73734_a:(IIIII)V
        //  1619: goto            1623
        //  1622: athrow         
        //  1623: getstatic       dev/nuker/pyro/f0H.c:I
        //  1626: iload           8
        //  1628: iadd           
        //  1629: aload_1        
        //  1630: goto            1634
        //  1633: athrow         
        //  1634: invokevirtual   dev/nuker/pyro/f0F.3:()I
        //  1637: goto            1641
        //  1640: athrow         
        //  1641: getstatic       dev/nuker/pyro/f0H.c:I
        //  1644: isub           
        //  1645: getstatic       dev/nuker/pyro/f0H.c:I
        //  1648: iload           9
        //  1650: iadd           
        //  1651: aload_1        
        //  1652: getstatic       dev/nuker/pyro/fc.1:I
        //  1655: ifne            1664
        //  1658: ldc_w           1303231683
        //  1661: goto            1667
        //  1664: ldc_w           -1094593165
        //  1667: ldc_w           1450132159
        //  1670: ixor           
        //  1671: lookupswitch {
        //          -391211060: 1696
        //          465763964: 1664
        //          default: 1801
        //        }
        //  1696: goto            1700
        //  1699: athrow         
        //  1700: invokevirtual   dev/nuker/pyro/f0F.3:()I
        //  1703: goto            1707
        //  1706: athrow         
        //  1707: getstatic       dev/nuker/pyro/f0H.c:I
        //  1710: isub           
        //  1711: iconst_1       
        //  1712: isub           
        //  1713: getstatic       dev/nuker/pyro/fc.0:I
        //  1716: ifgt            1725
        //  1719: ldc_w           1817407447
        //  1722: goto            1728
        //  1725: ldc_w           -643418044
        //  1728: ldc_w           904982244
        //  1731: ixor           
        //  1732: lookupswitch {
        //          1413219590: 1725
        //          1503887667: 1799
        //          default: 1760
        //        }
        //  1760: aload           6
        //  1762: goto            1766
        //  1765: athrow         
        //  1766: invokevirtual   dev/nuker/pyro/f0H.8:()I
        //  1769: goto            1773
        //  1772: athrow         
        //  1773: goto            1777
        //  1776: athrow         
        //  1777: invokestatic    net/minecraft/client/gui/Gui.func_73734_a:(IIIII)V
        //  1780: goto            1784
        //  1783: athrow         
        //  1784: return         
        //  1785: aconst_null    
        //  1786: athrow         
        //  1787: aconst_null    
        //  1788: athrow         
        //  1789: aconst_null    
        //  1790: athrow         
        //  1791: aconst_null    
        //  1792: athrow         
        //  1793: aconst_null    
        //  1794: athrow         
        //  1795: aconst_null    
        //  1796: athrow         
        //  1797: aconst_null    
        //  1798: athrow         
        //  1799: aconst_null    
        //  1800: athrow         
        //  1801: aconst_null    
        //  1802: athrow         
        //  1803: aconst_null    
        //  1804: athrow         
        //  1805: aconst_null    
        //  1806: athrow         
        //  1807: aconst_null    
        //  1808: athrow         
        //  1809: aconst_null    
        //  1810: athrow         
        //  1811: aconst_null    
        //  1812: athrow         
        //  1813: aconst_null    
        //  1814: athrow         
        //  1815: aconst_null    
        //  1816: athrow         
        //  1817: aconst_null    
        //  1818: athrow         
        //  1819: aconst_null    
        //  1820: athrow         
        //  1821: aconst_null    
        //  1822: athrow         
        //  1823: aconst_null    
        //  1824: athrow         
        //  1825: aconst_null    
        //  1826: athrow         
        //  1827: aconst_null    
        //  1828: athrow         
        //  1829: aconst_null    
        //  1830: athrow         
        //  1831: aconst_null    
        //  1832: athrow         
        //  1833: pop            
        //  1834: goto            24
        //  1837: pop            
        //  1838: aconst_null    
        //  1839: goto            1833
        //  1842: dup            
        //  1843: ifnull          1833
        //  1846: checkcast       Ljava/lang/Throwable;
        //  1849: athrow         
        //  1850: dup            
        //  1851: ifnull          1837
        //  1854: checkcast       Ljava/lang/Throwable;
        //  1857: athrow         
        //  1858: aconst_null    
        //  1859: athrow         
        //    StackMapTable: 00 FF 43 07 00 BF 04 FF 00 0B 00 00 00 01 07 00 BF FF 00 03 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 00 50 07 00 03 FF 00 01 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 02 07 00 03 01 5C 07 00 03 FF 00 0C 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 03 07 00 03 07 00 D7 03 FF 00 01 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 04 07 00 03 07 00 D7 03 01 FF 00 1C 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 03 07 00 03 07 00 D7 03 FF 00 0C 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 04 07 00 03 07 00 D7 03 03 FF 00 01 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 05 07 00 03 07 00 D7 03 03 01 FF 00 1C 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 04 07 00 03 07 00 D7 03 03 44 07 00 A3 FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 05 07 00 03 07 00 D7 03 03 07 00 DF 45 07 00 BF 00 0A 41 01 1D 4D 07 00 CF FF 00 01 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 02 07 00 CF 01 5B 07 00 CF 43 07 00 A3 FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 02 07 00 CF 07 00 D7 45 07 00 BF FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 02 07 00 CF 07 01 3F FF 00 0A 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 02 07 00 CF 07 01 3F FF 00 01 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 03 07 00 CF 07 01 3F 01 FF 00 1E 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 02 07 00 CF 07 01 3F 4B 07 00 BF FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 06 07 00 CF 07 01 3F 07 00 96 01 01 07 00 D7 45 07 00 BF FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 06 07 00 CF 07 01 3F 07 00 96 01 01 01 45 07 00 BF FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 07 07 00 CF 07 01 3F 07 00 96 01 01 01 07 00 D7 45 07 00 BF FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 07 07 00 CF 07 01 3F 07 00 96 01 01 01 01 FF 00 18 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 09 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 FF 00 01 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 0A 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 01 FF 00 1E 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 09 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 FF 00 0C 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 0A 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 07 00 DF FF 00 01 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 0B 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 07 00 DF 01 FF 00 1C 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 0A 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 07 00 DF 42 07 00 BF FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 0A 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 07 00 DF 45 07 00 BF FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 0A 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 01 FF 00 0F 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 0D 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 01 01 01 05 FF 00 01 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 0E 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 01 01 01 05 01 FF 00 1E 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 0D 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 01 01 01 05 42 07 00 AB FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 0D 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 01 01 01 05 45 07 00 BF 00 0A 41 01 1B FF 00 0E 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 02 07 00 CF 07 00 D7 FF 00 01 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 03 07 00 CF 07 00 D7 01 FF 00 1E 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 02 07 00 CF 07 00 D7 42 07 00 BF FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 02 07 00 CF 07 00 D7 45 07 00 BF FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 02 07 00 CF 07 01 3F 46 07 00 BF FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 03 07 00 CF 07 01 3F 07 00 56 45 07 00 BF FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 03 07 00 CF 07 01 3F 07 00 66 FF 00 03 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 03 07 00 CF 07 01 3F 07 00 66 FF 00 05 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 03 07 00 CF 07 01 3F 07 00 66 FF 00 02 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 04 07 00 CF 07 01 3F 07 00 66 01 FF 00 18 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 03 07 00 CF 07 01 3F 07 00 66 42 07 00 BF FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 03 07 00 CF 07 01 3F 07 00 66 45 07 00 BF FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 03 07 00 CF 07 01 3F 07 00 66 FF 00 05 00 00 00 01 07 00 BF FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 03 07 00 CF 07 01 3F 07 00 64 45 07 00 BF FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 03 07 00 CF 07 01 3F 07 00 96 FF 00 10 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 06 07 00 CF 07 01 3F 07 00 96 01 01 07 00 D7 FF 00 02 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 07 07 00 CF 07 01 3F 07 00 96 01 01 07 00 D7 01 FF 00 1E 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 06 07 00 CF 07 01 3F 07 00 96 01 01 07 00 D7 42 07 00 A9 FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 06 07 00 CF 07 01 3F 07 00 96 01 01 07 00 D7 45 07 00 BF FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 06 07 00 CF 07 01 3F 07 00 96 01 01 01 45 07 00 BF FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 07 07 00 CF 07 01 3F 07 00 96 01 01 01 07 00 D7 45 07 00 BF FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 07 07 00 CF 07 01 3F 07 00 96 01 01 01 01 FF 00 0B 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 07 07 00 CF 07 01 3F 07 00 96 01 01 01 01 FF 00 02 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 08 07 00 CF 07 01 3F 07 00 96 01 01 01 01 01 FF 00 1F 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 07 07 00 CF 07 01 3F 07 00 96 01 01 01 01 52 07 00 AB FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 0A 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 07 00 DF 45 07 00 BF FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 0A 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 01 FF 00 10 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 0D 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 01 01 01 05 FF 00 02 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 0E 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 01 01 01 05 01 FF 00 1C 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 0D 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 01 01 01 05 42 07 00 BF FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 0D 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 01 01 01 05 45 07 00 BF 00 43 07 00 BF 40 07 00 D7 45 07 00 BF 40 01 FF 00 1C 00 06 07 00 03 07 00 D7 03 03 07 00 DF 01 00 02 01 07 00 03 FF 00 02 00 06 07 00 03 07 00 D7 03 03 07 00 DF 01 00 03 01 07 00 03 01 FF 00 1C 00 06 07 00 03 07 00 D7 03 03 07 00 DF 01 00 02 01 07 00 03 45 07 00 AF FF 00 00 00 06 07 00 03 07 00 D7 03 03 07 00 DF 01 00 02 01 07 00 56 45 07 00 BF FF 00 00 00 06 07 00 03 07 00 D7 03 03 07 00 DF 01 00 02 01 07 00 66 46 07 00 AB FF 00 00 00 06 07 00 03 07 00 D7 03 03 07 00 DF 01 00 02 01 07 00 66 45 07 00 BF FF 00 00 00 06 07 00 03 07 00 D7 03 03 07 00 DF 01 00 02 01 07 00 66 45 07 00 BF FF 00 00 00 06 07 00 03 07 00 D7 03 03 07 00 DF 01 00 02 01 07 00 64 45 07 00 BF FF 00 00 00 06 07 00 03 07 00 D7 03 03 07 00 DF 01 00 02 01 01 FC 00 0E 01 42 01 1E 4C 07 00 03 FF 00 02 00 07 07 00 03 07 00 D7 03 03 07 00 DF 01 01 00 02 07 00 03 01 5F 07 00 03 45 07 00 BF 40 07 00 56 45 07 00 BF 40 07 00 66 43 07 00 66 45 07 00 66 FF 00 02 00 07 07 00 03 07 00 D7 03 03 07 00 DF 01 01 00 02 07 00 66 01 58 07 00 66 42 07 00 B5 40 07 00 66 45 07 00 BF 40 07 00 66 45 07 00 BF 40 07 00 64 45 07 00 BF 40 01 4B 01 FF 00 02 00 07 07 00 03 07 00 D7 03 03 07 00 DF 01 01 00 02 01 01 5F 01 FF 00 0C 00 07 07 00 03 07 00 D7 03 03 07 00 DF 01 01 00 02 01 07 00 03 FF 00 02 00 07 07 00 03 07 00 D7 03 03 07 00 DF 01 01 00 03 01 07 00 03 01 FF 00 1F 00 07 07 00 03 07 00 D7 03 03 07 00 DF 01 01 00 02 01 07 00 03 08 05 42 01 19 0B 42 01 1C 43 07 00 BF 40 07 00 D7 45 07 00 BF 40 01 08 FF 00 11 00 07 07 00 03 07 00 D7 03 03 07 00 DF 01 01 00 02 01 07 00 56 FF 00 02 00 07 07 00 03 07 00 D7 03 03 07 00 DF 01 01 00 03 01 07 00 56 01 FF 00 1D 00 07 07 00 03 07 00 D7 03 03 07 00 DF 01 01 00 02 01 07 00 56 42 07 00 A5 FF 00 00 00 07 07 00 03 07 00 D7 03 03 07 00 DF 01 01 00 02 01 07 00 56 45 07 00 BF FF 00 00 00 07 07 00 03 07 00 D7 03 03 07 00 DF 01 01 00 02 01 07 00 66 FF 00 06 00 00 00 01 07 00 BF FF 00 00 00 07 07 00 03 07 00 D7 03 03 07 00 DF 01 01 00 02 01 07 00 66 45 07 00 BF FF 00 00 00 07 07 00 03 07 00 D7 03 03 07 00 DF 01 01 00 02 01 07 00 66 45 07 00 BF FF 00 00 00 07 07 00 03 07 00 D7 03 03 07 00 DF 01 01 00 02 01 07 00 64 45 07 00 BF FF 00 00 00 07 07 00 03 07 00 D7 03 03 07 00 DF 01 01 00 02 01 01 42 01 FF 00 08 00 00 00 01 07 00 BF FF 00 00 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 02 01 07 00 D7 45 07 00 BF FF 00 00 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 02 01 01 47 07 00 BF FF 00 00 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 03 01 01 07 00 D7 45 07 00 BF FF 00 00 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 03 01 01 01 47 07 00 A9 FF 00 00 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 04 01 01 01 07 00 D7 45 07 00 BF FF 00 00 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 04 01 01 01 01 4A 07 00 BF FF 00 00 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 05 01 01 01 01 07 00 DF 45 07 00 BF FF 00 00 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 05 01 01 01 01 01 FF 00 0B 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 05 01 01 01 01 01 FF 00 02 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 06 01 01 01 01 01 01 FF 00 1D 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 05 01 01 01 01 01 42 07 00 BF FF 00 00 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 05 01 01 01 01 01 45 07 00 BF 00 49 07 00 BF FF 00 00 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 02 01 07 00 D7 45 07 00 BF FF 00 00 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 02 01 01 FF 00 16 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 04 01 01 01 07 00 D7 FF 00 02 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 05 01 01 01 07 00 D7 01 FF 00 1C 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 04 01 01 01 07 00 D7 42 07 00 BF FF 00 00 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 04 01 01 01 07 00 D7 45 07 00 BF FF 00 00 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 04 01 01 01 01 FF 00 11 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 04 01 01 01 01 FF 00 02 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 05 01 01 01 01 01 FF 00 1F 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 04 01 01 01 01 44 07 00 BF FF 00 00 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 05 01 01 01 01 07 00 DF 45 07 00 BF FF 00 00 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 05 01 01 01 01 01 FF 00 02 00 00 00 01 07 00 BF FF 00 00 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 05 01 01 01 01 01 45 07 00 BF 00 FF 00 00 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 06 07 00 CF 07 01 3F 07 00 96 01 01 07 00 D7 FF 00 01 00 07 07 00 03 07 00 D7 03 03 07 00 DF 01 01 00 01 07 00 03 FF 00 01 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 02 07 00 CF 07 00 D7 FF 00 01 00 07 07 00 03 07 00 D7 03 03 07 00 DF 01 01 00 02 01 07 00 03 01 F9 00 01 41 07 00 03 FF 00 01 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 04 01 01 01 01 FF 00 01 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 04 01 01 01 07 00 D7 FF 00 01 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 07 07 00 CF 07 01 3F 07 00 96 01 01 01 01 FF 00 01 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 03 07 00 03 07 00 D7 03 01 FF 00 01 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 0D 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 01 01 01 05 FF 00 01 00 07 07 00 03 07 00 D7 03 03 07 00 DF 01 01 00 01 01 FF 00 01 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 01 07 00 CF FF 00 01 00 07 07 00 03 07 00 D7 03 03 07 00 DF 01 01 00 02 01 07 00 56 FF 00 01 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 02 07 00 CF 07 01 3F FF 00 01 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 0A 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 07 00 DF FD 00 01 01 01 FF 00 01 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 0D 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 01 01 01 05 FF 00 01 00 06 07 00 03 07 00 D7 03 03 07 00 DF 01 00 02 01 07 00 03 FF 00 01 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 04 07 00 03 07 00 D7 03 03 FF 00 01 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 09 07 00 CF 07 01 3F 07 00 96 01 01 01 01 07 00 E7 01 FF 00 01 00 08 07 00 03 07 00 D7 03 03 07 00 DF 01 01 01 00 05 01 01 01 01 01 FF 00 01 00 05 07 00 03 07 00 D7 03 03 07 00 DF 00 01 07 00 BF 43 05 44 07 00 BF 47 05 47 07 00 BF
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     1842   1850   Any
        //  1842   1850   1842   1850   Ljava/lang/StringIndexOutOfBoundsException;
        //  1858   1860   3      8      Ljava/lang/UnsupportedOperationException;
        //  165    172    172    173    Any
        //  166    172    3      8      Any
        //  165    172    165    166    Ljava/util/ConcurrentModificationException;
        //  165    172    3      8      Any
        //  166    172    3      8      Ljava/lang/NumberFormatException;
        //  264    271    271    272    Any
        //  265    271    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  265    271    271    272    Ljava/lang/NumberFormatException;
        //  264    271    264    265    Ljava/util/ConcurrentModificationException;
        //  265    271    3      8      Any
        //  328    335    335    336    Any
        //  328    335    3      8      Any
        //  329    335    328    329    Any
        //  329    335    3      8      Any
        //  328    335    3      8      Any
        //  342    349    349    350    Any
        //  342    349    349    350    Ljava/lang/EnumConstantNotPresentException;
        //  343    349    342    343    Any
        //  342    349    3      8      Any
        //  343    349    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  455    462    462    463    Any
        //  456    462    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  456    462    462    463    Ljava/lang/StringIndexOutOfBoundsException;
        //  455    462    462    463    Any
        //  455    462    455    456    Any
        //  515    522    522    523    Any
        //  515    522    515    516    Ljava/lang/IndexOutOfBoundsException;
        //  516    522    3      8      Any
        //  515    522    3      8      Any
        //  516    522    3      8      Any
        //  615    622    622    623    Any
        //  616    622    615    616    Any
        //  615    622    615    616    Any
        //  615    622    622    623    Ljava/lang/NullPointerException;
        //  615    622    3      8      Ljava/lang/ClassCastException;
        //  630    637    637    638    Any
        //  631    637    630    631    Any
        //  631    637    3      8      Ljava/lang/NegativeArraySizeException;
        //  630    637    630    631    Any
        //  631    637    3      8      Any
        //  679    686    686    687    Any
        //  680    686    686    687    Ljava/lang/EnumConstantNotPresentException;
        //  679    686    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  680    686    679    680    Any
        //  680    686    686    687    Any
        //  694    700    700    701    Any
        //  694    700    3      8      Any
        //  694    700    3      8      Ljava/lang/IllegalArgumentException;
        //  694    700    3      8      Any
        //  694    700    700    701    Ljava/lang/IllegalStateException;
        //  755    762    762    763    Any
        //  756    762    762    763    Any
        //  756    762    3      8      Any
        //  755    762    762    763    Ljava/lang/IllegalArgumentException;
        //  755    762    755    756    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  769    776    776    777    Any
        //  770    776    776    777    Ljava/lang/NegativeArraySizeException;
        //  769    776    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  770    776    769    770    Any
        //  769    776    776    777    Ljava/lang/ArithmeticException;
        //  843    850    850    851    Any
        //  843    850    850    851    Ljava/lang/NullPointerException;
        //  844    850    843    844    Ljava/lang/IndexOutOfBoundsException;
        //  844    850    850    851    Ljava/lang/RuntimeException;
        //  843    850    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  903    910    910    911    Any
        //  903    910    910    911    Ljava/lang/EnumConstantNotPresentException;
        //  904    910    910    911    Ljava/util/ConcurrentModificationException;
        //  903    910    903    904    Any
        //  903    910    903    904    Any
        //  915    922    922    923    Any
        //  916    922    915    916    Ljava/lang/NegativeArraySizeException;
        //  916    922    922    923    Ljava/lang/NegativeArraySizeException;
        //  915    922    915    916    Any
        //  915    922    915    916    Any
        //  990    997    997    998    Any
        //  991    997    3      8      Any
        //  990    997    990    991    Ljava/lang/ClassCastException;
        //  990    997    3      8      Ljava/lang/NegativeArraySizeException;
        //  990    997    3      8      Ljava/util/ConcurrentModificationException;
        //  1005   1012   1012   1013   Any
        //  1005   1012   1012   1013   Ljava/lang/IllegalArgumentException;
        //  1005   1012   1012   1013   Any
        //  1005   1012   1005   1006   Ljava/lang/IndexOutOfBoundsException;
        //  1006   1012   3      8      Any
        //  1019   1026   1026   1027   Any
        //  1020   1026   1019   1020   Any
        //  1020   1026   1019   1020   Ljava/lang/AssertionError;
        //  1020   1026   1026   1027   Ljava/lang/AssertionError;
        //  1019   1026   1019   1020   Any
        //  1130   1137   1137   1138   Any
        //  1130   1137   1137   1138   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1130   1137   3      8      Any
        //  1130   1137   1130   1131   Any
        //  1130   1137   1137   1138   Ljava/lang/IndexOutOfBoundsException;
        //  1179   1186   1186   1187   Any
        //  1179   1186   3      8      Ljava/lang/IllegalStateException;
        //  1179   1186   3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1180   1186   1179   1180   Ljava/lang/IllegalStateException;
        //  1180   1186   1186   1187   Any
        //  1193   1200   1200   1201   Any
        //  1193   1200   3      8      Ljava/lang/NegativeArraySizeException;
        //  1194   1200   3      8      Ljava/lang/NumberFormatException;
        //  1193   1200   1193   1194   Ljava/util/NoSuchElementException;
        //  1194   1200   1193   1194   Any
        //  1388   1395   1395   1396   Any
        //  1389   1395   1395   1396   Ljava/lang/EnumConstantNotPresentException;
        //  1389   1395   1395   1396   Any
        //  1388   1395   1388   1389   Any
        //  1388   1395   1388   1389   Ljava/util/NoSuchElementException;
        //  1459   1466   1466   1467   Any
        //  1460   1466   3      8      Any
        //  1460   1466   1466   1467   Any
        //  1460   1466   1466   1467   Any
        //  1460   1466   1459   1460   Ljava/lang/NumberFormatException;
        //  1475   1481   1481   1482   Any
        //  1475   1481   1481   1482   Ljava/lang/IllegalStateException;
        //  1475   1481   3      8      Ljava/lang/UnsupportedOperationException;
        //  1475   1481   3      8      Ljava/util/NoSuchElementException;
        //  1475   1481   3      8      Ljava/lang/IllegalStateException;
        //  1488   1495   1495   1496   Any
        //  1488   1495   1488   1489   Any
        //  1489   1495   3      8      Any
        //  1488   1495   1488   1489   Any
        //  1489   1495   1488   1489   Any
        //  1509   1515   1515   1516   Any
        //  1509   1515   1515   1516   Ljava/lang/RuntimeException;
        //  1509   1515   1515   1516   Ljava/lang/NegativeArraySizeException;
        //  1509   1515   1515   1516   Any
        //  1509   1515   3      8      Any
        //  1524   1531   1531   1532   Any
        //  1525   1531   3      8      Ljava/lang/NumberFormatException;
        //  1525   1531   1531   1532   Ljava/lang/NegativeArraySizeException;
        //  1525   1531   1524   1525   Any
        //  1525   1531   1524   1525   Any
        //  1540   1547   1547   1548   Any
        //  1541   1547   1547   1548   Any
        //  1541   1547   1540   1541   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1541   1547   3      8      Ljava/lang/IllegalArgumentException;
        //  1541   1547   1547   1548   Any
        //  1559   1566   1566   1567   Any
        //  1559   1566   3      8      Ljava/lang/EnumConstantNotPresentException;
        //  1559   1566   1566   1567   Any
        //  1560   1566   1559   1560   Any
        //  1560   1566   3      8      Ljava/lang/NumberFormatException;
        //  1615   1622   1622   1623   Any
        //  1616   1622   1615   1616   Any
        //  1616   1622   1622   1623   Ljava/lang/ArithmeticException;
        //  1616   1622   3      8      Any
        //  1615   1622   3      8      Any
        //  1633   1640   1640   1641   Any
        //  1633   1640   1633   1634   Any
        //  1633   1640   1640   1641   Any
        //  1633   1640   3      8      Ljava/lang/NegativeArraySizeException;
        //  1633   1640   1640   1641   Ljava/lang/IllegalArgumentException;
        //  1699   1706   1706   1707   Any
        //  1700   1706   1699   1700   Any
        //  1700   1706   1706   1707   Any
        //  1700   1706   3      8      Ljava/lang/RuntimeException;
        //  1699   1706   3      8      Any
        //  1765   1772   1772   1773   Any
        //  1766   1772   1765   1766   Any
        //  1765   1772   1765   1766   Any
        //  1765   1772   1765   1766   Ljava/lang/NegativeArraySizeException;
        //  1766   1772   1765   1766   Any
        //  1777   1783   1783   1784   Any
        //  1777   1783   3      8      Ljava/lang/NullPointerException;
        //  1777   1783   1783   1784   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1777   1783   3      8      Ljava/lang/AssertionError;
        //  1777   1783   1783   1784   Ljava/lang/IllegalStateException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:600)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public int c(@NotNull final f0F p0, @NotNull final f0H p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          404
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            396
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            388
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: getstatic       dev/nuker/pyro/fc.1:I
        //    29: ifne            38
        //    32: ldc_w           2052210787
        //    35: goto            41
        //    38: ldc_w           645068868
        //    41: ldc_w           -1529865826
        //    44: ixor           
        //    45: lookupswitch {
        //          -2103254566: 72
        //          -561882627: 38
        //          default: 371
        //        }
        //    72: aload_2        
        //    73: pop            
        //    74: aload_1        
        //    75: getstatic       dev/nuker/pyro/fc.0:I
        //    78: ifgt            87
        //    81: ldc_w           1886082351
        //    84: goto            90
        //    87: ldc_w           -2086773614
        //    90: ldc_w           298581759
        //    93: ixor           
        //    94: lookupswitch {
        //          -469574520: 87
        //          1637919696: 373
        //          default: 120
        //        }
        //   120: goto            124
        //   123: athrow         
        //   124: invokevirtual   dev/nuker/pyro/f0F.0:()Lnet/minecraft/client/gui/FontRenderer;
        //   127: goto            131
        //   130: athrow         
        //   131: new             Ljava/lang/StringBuilder;
        //   134: dup            
        //   135: goto            139
        //   138: athrow         
        //   139: invokespecial   java/lang/StringBuilder.<init>:()V
        //   142: goto            146
        //   145: athrow         
        //   146: aload_0        
        //   147: getstatic       dev/nuker/pyro/fc.0:I
        //   150: ifgt            159
        //   153: ldc_w           -144449295
        //   156: goto            162
        //   159: ldc_w           277897848
        //   162: ldc_w           -1438625384
        //   165: ixor           
        //   166: lookupswitch {
        //          -604949812: 159
        //          1562620265: 369
        //          default: 192
        //        }
        //   192: getfield        dev/nuker/pyro/f0O.c:Ljava/lang/String;
        //   195: goto            199
        //   198: athrow         
        //   199: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   202: goto            206
        //   205: athrow         
        //   206: ldc_w           "\u3dc6\ub205"
        //   209: getstatic       dev/nuker/pyro/fc.c:I
        //   212: ifne            221
        //   215: ldc_w           1931585226
        //   218: goto            224
        //   221: ldc_w           229730325
        //   224: ldc_w           -142963231
        //   227: ixor           
        //   228: lookupswitch {
        //          -2074399957: 221
        //          -87300620: 256
        //          default: 377
        //        }
        //   256: goto            260
        //   259: athrow         
        //   260: invokestatic    invokestatic   !!! ERROR
        //   263: goto            267
        //   266: athrow         
        //   267: goto            271
        //   270: athrow         
        //   271: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   274: goto            278
        //   277: athrow         
        //   278: aload_0        
        //   279: getfield        dev/nuker/pyro/f0O.0:Ljava/lang/String;
        //   282: goto            286
        //   285: athrow         
        //   286: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   289: goto            293
        //   292: athrow         
        //   293: getstatic       dev/nuker/pyro/fc.0:I
        //   296: ifgt            305
        //   299: ldc_w           1937454916
        //   302: goto            308
        //   305: ldc_w           1794821544
        //   308: ldc_w           -147443471
        //   311: ixor           
        //   312: lookupswitch {
        //          -2075326539: 375
        //          1108879671: 305
        //          default: 340
        //        }
        //   340: goto            344
        //   343: athrow         
        //   344: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   347: goto            351
        //   350: athrow         
        //   351: goto            355
        //   354: athrow         
        //   355: invokevirtual   net/minecraft/client/gui/FontRenderer.func_78256_a:(Ljava/lang/String;)I
        //   358: goto            362
        //   361: athrow         
        //   362: getstatic       dev/nuker/pyro/f0H.c:I
        //   365: iconst_2       
        //   366: imul           
        //   367: iadd           
        //   368: ireturn        
        //   369: aconst_null    
        //   370: athrow         
        //   371: aconst_null    
        //   372: athrow         
        //   373: aconst_null    
        //   374: athrow         
        //   375: aconst_null    
        //   376: athrow         
        //   377: aconst_null    
        //   378: athrow         
        //   379: pop            
        //   380: goto            24
        //   383: pop            
        //   384: aconst_null    
        //   385: goto            379
        //   388: dup            
        //   389: ifnull          379
        //   392: checkcast       Ljava/lang/Throwable;
        //   395: athrow         
        //   396: dup            
        //   397: ifnull          383
        //   400: checkcast       Ljava/lang/Throwable;
        //   403: athrow         
        //   404: aconst_null    
        //   405: athrow         
        //    StackMapTable: 00 3D 43 07 00 BF 04 FF 00 0B 00 00 00 01 07 00 BF FE 00 03 07 00 03 07 00 D7 07 00 DF 0D 42 01 1E 4E 07 00 D7 FF 00 02 00 03 07 00 03 07 00 D7 07 00 DF 00 02 07 00 D7 01 5D 07 00 D7 FF 00 02 00 00 00 01 07 00 BF FF 00 00 00 03 07 00 03 07 00 D7 07 00 DF 00 01 07 00 D7 45 07 00 BF 40 07 01 3F 46 07 00 B9 FF 00 00 00 03 07 00 03 07 00 D7 07 00 DF 00 03 07 01 3F 08 00 83 08 00 83 45 07 00 BF FF 00 00 00 03 07 00 03 07 00 D7 07 00 DF 00 02 07 01 3F 07 01 47 FF 00 0C 00 03 07 00 03 07 00 D7 07 00 DF 00 03 07 01 3F 07 01 47 07 00 03 FF 00 02 00 03 07 00 03 07 00 D7 07 00 DF 00 04 07 01 3F 07 01 47 07 00 03 01 FF 00 1D 00 03 07 00 03 07 00 D7 07 00 DF 00 03 07 01 3F 07 01 47 07 00 03 45 07 00 B9 FF 00 00 00 03 07 00 03 07 00 D7 07 00 DF 00 03 07 01 3F 07 01 47 07 00 96 45 07 00 BF FF 00 00 00 03 07 00 03 07 00 D7 07 00 DF 00 02 07 01 3F 07 01 47 FF 00 0E 00 03 07 00 03 07 00 D7 07 00 DF 00 03 07 01 3F 07 01 47 07 00 96 FF 00 02 00 03 07 00 03 07 00 D7 07 00 DF 00 04 07 01 3F 07 01 47 07 00 96 01 FF 00 1F 00 03 07 00 03 07 00 D7 07 00 DF 00 03 07 01 3F 07 01 47 07 00 96 42 07 00 B9 FF 00 00 00 03 07 00 03 07 00 D7 07 00 DF 00 03 07 01 3F 07 01 47 07 00 96 45 07 00 BF FF 00 00 00 03 07 00 03 07 00 D7 07 00 DF 00 03 07 01 3F 07 01 47 07 00 96 42 07 00 BF FF 00 00 00 03 07 00 03 07 00 D7 07 00 DF 00 03 07 01 3F 07 01 47 07 00 96 45 07 00 BF FF 00 00 00 03 07 00 03 07 00 D7 07 00 DF 00 02 07 01 3F 07 01 47 FF 00 06 00 00 00 01 07 00 BF FF 00 00 00 03 07 00 03 07 00 D7 07 00 DF 00 03 07 01 3F 07 01 47 07 00 96 45 07 00 BF FF 00 00 00 03 07 00 03 07 00 D7 07 00 DF 00 02 07 01 3F 07 01 47 FF 00 0B 00 03 07 00 03 07 00 D7 07 00 DF 00 02 07 01 3F 07 01 47 FF 00 02 00 03 07 00 03 07 00 D7 07 00 DF 00 03 07 01 3F 07 01 47 01 FF 00 1F 00 03 07 00 03 07 00 D7 07 00 DF 00 02 07 01 3F 07 01 47 42 07 00 BF FF 00 00 00 03 07 00 03 07 00 D7 07 00 DF 00 02 07 01 3F 07 01 47 45 07 00 BF FF 00 00 00 03 07 00 03 07 00 D7 07 00 DF 00 02 07 01 3F 07 00 96 42 07 00 BF FF 00 00 00 03 07 00 03 07 00 D7 07 00 DF 00 02 07 01 3F 07 00 96 45 07 00 BF 40 01 FF 00 06 00 03 07 00 03 07 00 D7 07 00 DF 00 03 07 01 3F 07 01 47 07 00 03 01 41 07 00 D7 FF 00 01 00 03 07 00 03 07 00 D7 07 00 DF 00 02 07 01 3F 07 01 47 FF 00 01 00 03 07 00 03 07 00 D7 07 00 DF 00 03 07 01 3F 07 01 47 07 00 96 41 07 00 BF 43 05 44 07 00 BF 47 05 47 07 00 BF
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     388    396    Any
        //  388    396    388    396    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  404    406    3      8      Any
        //  124    130    130    131    Any
        //  124    130    130    131    Any
        //  124    130    3      8      Any
        //  124    130    130    131    Ljava/lang/NegativeArraySizeException;
        //  124    130    3      8      Ljava/util/ConcurrentModificationException;
        //  138    145    145    146    Any
        //  138    145    3      8      Any
        //  139    145    138    139    Ljava/lang/UnsupportedOperationException;
        //  138    145    3      8      Any
        //  138    145    138    139    Ljava/util/ConcurrentModificationException;
        //  198    205    205    206    Any
        //  199    205    205    206    Any
        //  198    205    205    206    Ljava/lang/IndexOutOfBoundsException;
        //  198    205    198    199    Ljava/lang/NullPointerException;
        //  199    205    198    199    Ljava/util/ConcurrentModificationException;
        //  259    266    266    267    Any
        //  260    266    259    260    Ljava/lang/NullPointerException;
        //  260    266    3      8      Any
        //  259    266    259    260    Ljava/lang/ClassCastException;
        //  259    266    3      8      Any
        //  270    277    277    278    Any
        //  271    277    270    271    Ljava/lang/IndexOutOfBoundsException;
        //  271    277    270    271    Any
        //  270    277    270    271    Ljava/lang/NullPointerException;
        //  270    277    277    278    Ljava/lang/NullPointerException;
        //  286    292    292    293    Any
        //  286    292    3      8      Any
        //  286    292    292    293    Ljava/lang/StringIndexOutOfBoundsException;
        //  286    292    292    293    Ljava/lang/StringIndexOutOfBoundsException;
        //  286    292    3      8      Any
        //  343    350    350    351    Any
        //  343    350    343    344    Any
        //  343    350    343    344    Ljava/lang/NegativeArraySizeException;
        //  343    350    3      8      Ljava/lang/ArithmeticException;
        //  343    350    343    344    Any
        //  354    361    361    362    Any
        //  355    361    354    355    Any
        //  354    361    3      8      Ljava/lang/ArithmeticException;
        //  354    361    361    362    Any
        //  354    361    3      8      Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:776)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void c(final int n) {
        fez.5w(this, 1702071336, n);
    }
}
