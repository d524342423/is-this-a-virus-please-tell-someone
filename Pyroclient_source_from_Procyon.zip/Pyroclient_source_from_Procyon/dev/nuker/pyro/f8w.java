// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

public enum f8w
{
    public static f8w c;
    public static f8w 0;
    public static f8w 1;
    public static f8w 2;
    public static f8w[] c;
    
    static {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: anewarray       Ldev/nuker/pyro/f8w;
        //     4: dup            
        //     5: dup            
        //     6: iconst_0       
        //     7: new             Ldev/nuker/pyro/f8w;
        //    10: dup            
        //    11: ldc             "\u3cd3\ub26b\u8f8f\ua157\u53cd\u582d\u7e67\u689e\uce3c"
        //    13: invokestatic    invokestatic   !!! ERROR
        //    16: iconst_0       
        //    17: getstatic       dev/nuker/pyro/fc.1:I
        //    20: ifne            28
        //    23: ldc             1073543182
        //    25: goto            30
        //    28: ldc             -128088616
        //    30: ldc             1831841736
        //    32: ixor           
        //    33: lookupswitch {
        //          -1787680240: 60
        //          1389582278: 28
        //          default: 312
        //        }
        //    60: invokespecial   dev/nuker/pyro/f8w.<init>:(Ljava/lang/String;I)V
        //    63: dup            
        //    64: putstatic       dev/nuker/pyro/f8w.c:Ldev/nuker/pyro/f8w;
        //    67: aastore        
        //    68: dup            
        //    69: iconst_1       
        //    70: new             Ldev/nuker/pyro/f8w;
        //    73: dup            
        //    74: ldc             "\u3cc7\ub261\u8f88\ua15a\u53c8"
        //    76: getstatic       dev/nuker/pyro/fc.1:I
        //    79: ifne            87
        //    82: ldc             -2098897090
        //    84: goto            89
        //    87: ldc             1664744777
        //    89: ldc             19151325
        //    91: ixor           
        //    92: lookupswitch {
        //          -2084477213: 87
        //          1646118036: 120
        //          default: 316
        //        }
        //   120: invokestatic    invokestatic   !!! ERROR
        //   123: iconst_1       
        //   124: getstatic       dev/nuker/pyro/fc.0:I
        //   127: ifgt            135
        //   130: ldc             1034263735
        //   132: goto            137
        //   135: ldc             1145664550
        //   137: ldc             -2135599921
        //   139: ixor           
        //   140: lookupswitch {
        //          -1122973576: 308
        //          593583669: 135
        //          default: 168
        //        }
        //   168: invokespecial   dev/nuker/pyro/f8w.<init>:(Ljava/lang/String;I)V
        //   171: dup            
        //   172: getstatic       dev/nuker/pyro/fc.1:I
        //   175: ifne            183
        //   178: ldc             776529594
        //   180: goto            185
        //   183: ldc             -1563967021
        //   185: ldc             259153888
        //   187: ixor           
        //   188: lookupswitch {
        //          -1380606413: 216
        //          557496666: 183
        //          default: 310
        //        }
        //   216: putstatic       dev/nuker/pyro/f8w.0:Ldev/nuker/pyro/f8w;
        //   219: aastore        
        //   220: dup            
        //   221: iconst_2       
        //   222: new             Ldev/nuker/pyro/f8w;
        //   225: dup            
        //   226: ldc             "\u3cd4\ub260\u8f81\ua150\u53da\u5826\u7e64"
        //   228: getstatic       dev/nuker/pyro/fc.c:I
        //   231: ifne            239
        //   234: ldc             -116510989
        //   236: goto            241
        //   239: ldc             -834630512
        //   241: ldc             -1910954178
        //   243: ixor           
        //   244: lookupswitch {
        //          1079618478: 272
        //          1997998541: 239
        //          default: 314
        //        }
        //   272: invokestatic    invokestatic   !!! ERROR
        //   275: iconst_2       
        //   276: invokespecial   dev/nuker/pyro/f8w.<init>:(Ljava/lang/String;I)V
        //   279: dup            
        //   280: putstatic       dev/nuker/pyro/f8w.1:Ldev/nuker/pyro/f8w;
        //   283: aastore        
        //   284: dup            
        //   285: iconst_3       
        //   286: new             Ldev/nuker/pyro/f8w;
        //   289: dup            
        //   290: ldc             "\u3ccb\ub26a\u8f88\ua156\u53ca\u582a\u7e65\u689f"
        //   292: invokestatic    invokestatic   !!! ERROR
        //   295: iconst_3       
        //   296: invokespecial   dev/nuker/pyro/f8w.<init>:(Ljava/lang/String;I)V
        //   299: dup            
        //   300: putstatic       dev/nuker/pyro/f8w.2:Ldev/nuker/pyro/f8w;
        //   303: aastore        
        //   304: putstatic       dev/nuker/pyro/f8w.c:[Ldev/nuker/pyro/f8w;
        //   307: return         
        //   308: aconst_null    
        //   309: athrow         
        //   310: aconst_null    
        //   311: athrow         
        //   312: aconst_null    
        //   313: athrow         
        //   314: aconst_null    
        //   315: athrow         
        //   316: aconst_null    
        //   317: athrow         
        //    StackMapTable: 00 14 FF 00 1C 00 00 00 08 07 00 41 07 00 41 07 00 41 01 08 00 07 08 00 07 07 00 43 01 FF 00 01 00 00 00 09 07 00 41 07 00 41 07 00 41 01 08 00 07 08 00 07 07 00 43 01 01 FF 00 1D 00 00 00 08 07 00 41 07 00 41 07 00 41 01 08 00 07 08 00 07 07 00 43 01 FF 00 1A 00 00 00 07 07 00 41 07 00 41 07 00 41 01 08 00 46 08 00 46 07 00 43 FF 00 01 00 00 00 08 07 00 41 07 00 41 07 00 41 01 08 00 46 08 00 46 07 00 43 01 FF 00 1E 00 00 00 07 07 00 41 07 00 41 07 00 41 01 08 00 46 08 00 46 07 00 43 FF 00 0E 00 00 00 08 07 00 41 07 00 41 07 00 41 01 08 00 46 08 00 46 07 00 43 01 FF 00 01 00 00 00 09 07 00 41 07 00 41 07 00 41 01 08 00 46 08 00 46 07 00 43 01 01 FF 00 1E 00 00 00 08 07 00 41 07 00 41 07 00 41 01 08 00 46 08 00 46 07 00 43 01 FF 00 0E 00 00 00 06 07 00 41 07 00 41 07 00 41 01 07 00 03 07 00 03 FF 00 01 00 00 00 07 07 00 41 07 00 41 07 00 41 01 07 00 03 07 00 03 01 FF 00 1E 00 00 00 06 07 00 41 07 00 41 07 00 41 01 07 00 03 07 00 03 FF 00 16 00 00 00 07 07 00 41 07 00 41 07 00 41 01 08 00 DE 08 00 DE 07 00 43 FF 00 01 00 00 00 08 07 00 41 07 00 41 07 00 41 01 08 00 DE 08 00 DE 07 00 43 01 FF 00 1E 00 00 00 07 07 00 41 07 00 41 07 00 41 01 08 00 DE 08 00 DE 07 00 43 FF 00 23 00 00 00 08 07 00 41 07 00 41 07 00 41 01 08 00 46 08 00 46 07 00 43 01 FF 00 01 00 00 00 06 07 00 41 07 00 41 07 00 41 01 07 00 03 07 00 03 FF 00 01 00 00 00 08 07 00 41 07 00 41 07 00 41 01 08 00 07 08 00 07 07 00 43 01 FF 00 01 00 00 00 07 07 00 41 07 00 41 07 00 41 01 08 00 DE 08 00 DE 07 00 43 FF 00 01 00 00 00 07 07 00 41 07 00 41 07 00 41 01 08 00 46 08 00 46 07 00 43
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static f8w c(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          110
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            102
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            94
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: ldc             Ldev/nuker/pyro/f8w;.class
        //    26: aload_0        
        //    27: getstatic       dev/nuker/pyro/fc.1:I
        //    30: ifne            38
        //    33: ldc             -887840225
        //    35: goto            40
        //    38: ldc             -695139896
        //    40: ldc             -737025269
        //    42: ixor           
        //    43: lookupswitch {
        //          -2015910451: 38
        //          520438036: 83
        //          default: 68
        //        }
        //    68: goto            72
        //    71: athrow         
        //    72: invokestatic    java/lang/Enum.valueOf:(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
        //    75: goto            79
        //    78: athrow         
        //    79: checkcast       Ldev/nuker/pyro/f8w;
        //    82: areturn        
        //    83: aconst_null    
        //    84: athrow         
        //    85: pop            
        //    86: goto            24
        //    89: pop            
        //    90: aconst_null    
        //    91: goto            85
        //    94: dup            
        //    95: ifnull          85
        //    98: checkcast       Ljava/lang/Throwable;
        //   101: athrow         
        //   102: dup            
        //   103: ifnull          89
        //   106: checkcast       Ljava/lang/Throwable;
        //   109: athrow         
        //   110: aconst_null    
        //   111: athrow         
        //    StackMapTable: 00 11 43 07 00 57 04 FF 00 0B 00 00 00 01 07 00 4E FC 00 03 07 00 43 FF 00 0D 00 01 07 00 43 00 02 07 00 59 07 00 43 FF 00 01 00 01 07 00 43 00 03 07 00 59 07 00 43 01 FF 00 1B 00 01 07 00 43 00 02 07 00 59 07 00 43 FF 00 02 00 00 00 01 07 00 4E FF 00 00 00 01 07 00 43 00 02 07 00 59 07 00 43 45 07 00 4E 40 07 00 05 FF 00 03 00 01 07 00 43 00 02 07 00 59 07 00 43 41 07 00 4E 43 05 44 07 00 4E 47 05 47 07 00 57
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     94     102    Ljava/util/ConcurrentModificationException;
        //  94     102    94     102    Any
        //  110    112    3      8      Ljava/lang/IllegalArgumentException;
        //  72     78     78     79     Any
        //  72     78     3      8      Ljava/util/ConcurrentModificationException;
        //  72     78     78     79     Any
        //  72     78     78     79     Ljava/lang/NullPointerException;
        //  72     78     78     79     Ljava/util/NoSuchElementException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 43 out of bounds for length 43
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public f8w(final String name, final int ordinal) {
        while (true) {
            Label_0013: {
                if (fc.1 == 0) {
                    n = 92425142;
                    break Label_0013;
                }
                n = 1770122616;
            }
            switch (n ^ 0x7D96A9E2) {
                case -1175060146: {
                    continue;
                }
                default: {
                    while (true) {
                        int n2 = 0;
                        Label_0060: {
                            if (fc.1 == 0) {
                                n2 = 2076458045;
                                break Label_0060;
                            }
                            n2 = -803536037;
                        }
                        switch (n2 ^ 0x78BD19A3) {
                            case 318675807: {
                                continue;
                            }
                            default: {
                                super(name, ordinal);
                                return;
                            }
                            case 58271134: {
                                throw null;
                            }
                        }
                        break;
                    }
                    break;
                }
                case 2014634580: {
                    throw null;
                }
            }
            break;
        }
    }
}
