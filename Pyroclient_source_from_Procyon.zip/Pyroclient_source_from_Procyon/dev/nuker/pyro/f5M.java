// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import net.minecraft.client.gui.ScaledResolution;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;
import net.minecraft.potion.PotionEffect;

public class f5M extends f5q
{
    @NotNull
    public PotionEffect c;
    
    @Override
    public float 0() {
        return fez.dS(this, 1257841011);
    }
    
    @Override
    public void c(@Nullable final f5t p0, final int p1, @Nullable final ScaledResolution p2, final float p3, final float p4) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          2389
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            2381
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            2373
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: goto            28
        //    27: athrow         
        //    28: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179094_E:()V
        //    31: goto            35
        //    34: athrow         
        //    35: iload_2        
        //    36: iconst_2       
        //    37: if_icmpge       45
        //    40: ldc             -552248175
        //    42: goto            47
        //    45: ldc             -552248174
        //    47: ldc             -190899140
        //    49: ixor           
        //    50: tableswitch {
        //          1460961626: 72
        //          1460961627: 76
        //          default: 40
        //        }
        //    72: iconst_1       
        //    73: goto            77
        //    76: iconst_0       
        //    77: istore          6
        //    79: fconst_1       
        //    80: fconst_1       
        //    81: fconst_1       
        //    82: fconst_1       
        //    83: goto            87
        //    86: athrow         
        //    87: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179131_c:(FFFF)V
        //    90: goto            94
        //    93: athrow         
        //    94: getstatic       dev/nuker/pyro/fc.c:I
        //    97: ifne            105
        //   100: ldc             1525756740
        //   102: goto            107
        //   105: ldc             -1235873515
        //   107: ldc             166267515
        //   109: ixor           
        //   110: lookupswitch {
        //          -1077994642: 136
        //          1394096447: 105
        //          default: 2318
        //        }
        //   136: goto            140
        //   139: athrow         
        //   140: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179140_f:()V
        //   143: goto            147
        //   146: athrow         
        //   147: aload_0        
        //   148: getfield        dev/nuker/pyro/f5M.c:Lnet/minecraft/potion/PotionEffect;
        //   151: getstatic       dev/nuker/pyro/fc.0:I
        //   154: ifgt            162
        //   157: ldc             2047177807
        //   159: goto            164
        //   162: ldc             844586767
        //   164: ldc             -1578387618
        //   166: ixor           
        //   167: lookupswitch {
        //          -1816336303: 192
        //          -605109487: 162
        //          default: 2320
        //        }
        //   192: goto            196
        //   195: athrow         
        //   196: invokevirtual   net/minecraft/potion/PotionEffect.func_188419_a:()Lnet/minecraft/potion/Potion;
        //   199: goto            203
        //   202: athrow         
        //   203: getstatic       dev/nuker/pyro/fc.c:I
        //   206: ifne            214
        //   209: ldc             -153383118
        //   211: goto            216
        //   214: ldc             1932022599
        //   216: ldc             1088716775
        //   218: ixor           
        //   219: lookupswitch {
        //          -1237323563: 214
        //          869018784: 244
        //          default: 2356
        //        }
        //   244: astore          7
        //   246: fconst_1       
        //   247: fconst_1       
        //   248: fconst_1       
        //   249: fconst_1       
        //   250: goto            254
        //   253: athrow         
        //   254: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179131_c:(FFFF)V
        //   257: goto            261
        //   260: athrow         
        //   261: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //   264: dup            
        //   265: pop            
        //   266: goto            270
        //   269: athrow         
        //   270: invokevirtual   net/minecraft/client/Minecraft.func_110434_K:()Lnet/minecraft/client/renderer/texture/TextureManager;
        //   273: goto            277
        //   276: athrow         
        //   277: getstatic       net/minecraft/client/gui/inventory/GuiContainer.field_147001_a:Lnet/minecraft/util/ResourceLocation;
        //   280: goto            284
        //   283: athrow         
        //   284: invokevirtual   net/minecraft/client/renderer/texture/TextureManager.func_110577_a:(Lnet/minecraft/util/ResourceLocation;)V
        //   287: goto            291
        //   290: athrow         
        //   291: aload           7
        //   293: getstatic       dev/nuker/pyro/fc.0:I
        //   296: ifgt            304
        //   299: ldc             -1869637110
        //   301: goto            306
        //   304: ldc             426537083
        //   306: ldc             -2006561625
        //   308: ixor           
        //   309: lookupswitch {
        //          -1654553931: 304
        //          417978029: 2324
        //          default: 336
        //        }
        //   336: goto            340
        //   339: athrow         
        //   340: invokevirtual   net/minecraft/potion/Potion.func_76400_d:()Z
        //   343: goto            347
        //   346: athrow         
        //   347: ifeq            955
        //   350: aload           7
        //   352: dup            
        //   353: pop            
        //   354: goto            358
        //   357: athrow         
        //   358: invokevirtual   net/minecraft/potion/Potion.func_76392_e:()I
        //   361: goto            365
        //   364: athrow         
        //   365: istore          8
        //   367: ldc             0.7
        //   369: fstore          9
        //   371: goto            375
        //   374: athrow         
        //   375: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179141_d:()V
        //   378: goto            382
        //   381: athrow         
        //   382: goto            386
        //   385: athrow         
        //   386: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179097_i:()V
        //   389: goto            393
        //   392: athrow         
        //   393: goto            397
        //   396: athrow         
        //   397: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179094_E:()V
        //   400: goto            404
        //   403: athrow         
        //   404: getstatic       dev/nuker/pyro/fc.c:I
        //   407: ifne            415
        //   410: ldc             287177758
        //   412: goto            417
        //   415: ldc             -1763661411
        //   417: ldc             932113513
        //   419: ixor           
        //   420: lookupswitch {
        //          647172215: 2340
        //          1427328705: 415
        //          default: 448
        //        }
        //   448: iload           6
        //   450: ifeq            473
        //   453: aload_0        
        //   454: goto            458
        //   457: athrow         
        //   458: invokevirtual   dev/nuker/pyro/f5M.5:()F
        //   461: goto            465
        //   464: athrow         
        //   465: bipush          13
        //   467: i2f            
        //   468: fsub           
        //   469: f2d            
        //   470: goto            474
        //   473: dconst_0       
        //   474: dconst_0       
        //   475: dconst_0       
        //   476: goto            480
        //   479: athrow         
        //   480: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179137_b:(DDD)V
        //   483: goto            487
        //   486: athrow         
        //   487: getstatic       dev/nuker/pyro/fc.c:I
        //   490: ifne            498
        //   493: ldc             -983540347
        //   495: goto            500
        //   498: ldc             -426078434
        //   500: ldc             -1522777067
        //   502: ixor           
        //   503: lookupswitch {
        //          1135004427: 528
        //          1616648592: 498
        //          default: 2342
        //        }
        //   528: fload           9
        //   530: fload           9
        //   532: getstatic       dev/nuker/pyro/fc.1:I
        //   535: ifne            543
        //   538: ldc             1964783176
        //   540: goto            545
        //   543: ldc             -731966300
        //   545: ldc             1861591921
        //   547: ixor           
        //   548: lookupswitch {
        //          -1163216939: 576
        //          468292921: 543
        //          default: 2308
        //        }
        //   576: fload           9
        //   578: getstatic       dev/nuker/pyro/fc.1:I
        //   581: ifne            589
        //   584: ldc             489013537
        //   586: goto            591
        //   589: ldc             -787189836
        //   591: ldc             -695245626
        //   593: ixor           
        //   594: lookupswitch {
        //          -878008857: 2310
        //          1038129881: 589
        //          default: 620
        //        }
        //   620: goto            624
        //   623: athrow         
        //   624: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179152_a:(FFF)V
        //   627: goto            631
        //   630: athrow         
        //   631: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //   634: getstatic       dev/nuker/pyro/fc.0:I
        //   637: ifgt            645
        //   640: ldc             138243814
        //   642: goto            647
        //   645: ldc             1633647746
        //   647: ldc             -1767337910
        //   649: ixor           
        //   650: lookupswitch {
        //          -1634337108: 2322
        //          1687806849: 645
        //          default: 676
        //        }
        //   676: getfield        net/minecraft/client/Minecraft.field_71462_r:Lnet/minecraft/client/gui/GuiScreen;
        //   679: ifnull          694
        //   682: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //   685: getfield        net/minecraft/client/Minecraft.field_71462_r:Lnet/minecraft/client/gui/GuiScreen;
        //   688: checkcast       Lnet/minecraft/client/gui/Gui;
        //   691: goto            703
        //   694: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //   697: getfield        net/minecraft/client/Minecraft.field_71456_v:Lnet/minecraft/client/gui/GuiIngame;
        //   700: checkcast       Lnet/minecraft/client/gui/Gui;
        //   703: dup            
        //   704: ifnonnull       759
        //   707: getstatic       dev/nuker/pyro/fc.1:I
        //   710: ifne            718
        //   713: ldc             -939349107
        //   715: goto            720
        //   718: ldc             1665760736
        //   720: ldc             -631180883
        //   722: ixor           
        //   723: lookupswitch {
        //          -1188459443: 748
        //          308435488: 718
        //          default: 2350
        //        }
        //   748: goto            752
        //   751: athrow         
        //   752: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //   755: goto            759
        //   758: athrow         
        //   759: iconst_0       
        //   760: iconst_0       
        //   761: iload           8
        //   763: bipush          8
        //   765: irem           
        //   766: bipush          18
        //   768: imul           
        //   769: sipush          198
        //   772: iload           8
        //   774: bipush          8
        //   776: idiv           
        //   777: bipush          18
        //   779: imul           
        //   780: iadd           
        //   781: bipush          18
        //   783: bipush          18
        //   785: getstatic       dev/nuker/pyro/fc.0:I
        //   788: ifgt            796
        //   791: ldc             1353389438
        //   793: goto            798
        //   796: ldc             -883304473
        //   798: ldc             -200940024
        //   800: ixor           
        //   801: lookupswitch {
        //          -1532038282: 2328
        //          -929020522: 796
        //          default: 828
        //        }
        //   828: goto            832
        //   831: athrow         
        //   832: invokevirtual   net/minecraft/client/gui/Gui.func_73729_b:(IIIIII)V
        //   835: goto            839
        //   838: athrow         
        //   839: getstatic       dev/nuker/pyro/fc.1:I
        //   842: ifne            850
        //   845: ldc             1462860013
        //   847: goto            852
        //   850: ldc             1161377162
        //   852: ldc             826947306
        //   854: ixor           
        //   855: lookupswitch {
        //          1719356935: 850
        //          1953694560: 880
        //          default: 2334
        //        }
        //   880: goto            884
        //   883: athrow         
        //   884: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179121_F:()V
        //   887: goto            891
        //   890: athrow         
        //   891: goto            895
        //   894: athrow         
        //   895: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179118_c:()V
        //   898: goto            902
        //   901: athrow         
        //   902: getstatic       dev/nuker/pyro/fc.0:I
        //   905: ifgt            913
        //   908: ldc             1095169730
        //   910: goto            915
        //   913: ldc             -51043393
        //   915: ldc             -1412580287
        //   917: ixor           
        //   918: lookupswitch {
        //          -359970173: 2316
        //          -164609925: 913
        //          default: 944
        //        }
        //   944: goto            948
        //   947: athrow         
        //   948: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179126_j:()V
        //   951: goto            955
        //   954: athrow         
        //   955: aload           7
        //   957: iconst_0       
        //   958: iconst_0       
        //   959: aload_0        
        //   960: getfield        dev/nuker/pyro/f5M.c:Lnet/minecraft/potion/PotionEffect;
        //   963: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //   966: goto            970
        //   969: athrow         
        //   970: invokevirtual   net/minecraft/potion/Potion.renderInventoryEffect:(IILnet/minecraft/potion/PotionEffect;Lnet/minecraft/client/Minecraft;)V
        //   973: goto            977
        //   976: athrow         
        //   977: getstatic       dev/nuker/pyro/fc.c:I
        //   980: ifne            988
        //   983: ldc             -1808933146
        //   985: goto            990
        //   988: ldc             -755154505
        //   990: ldc             1604539326
        //   992: ixor           
        //   993: lookupswitch {
        //          -879850152: 2336
        //          766017220: 988
        //          default: 1020
        //        }
        //  1020: aload           7
        //  1022: dup            
        //  1023: pop            
        //  1024: goto            1028
        //  1027: athrow         
        //  1028: invokevirtual   net/minecraft/potion/Potion.func_76393_a:()Ljava/lang/String;
        //  1031: goto            1035
        //  1034: athrow         
        //  1035: iconst_0       
        //  1036: anewarray       Ljava/lang/Object;
        //  1039: goto            1043
        //  1042: athrow         
        //  1043: invokestatic    net/minecraft/client/resources/I18n.func_135052_a:(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
        //  1046: goto            1050
        //  1049: athrow         
        //  1050: astore          8
        //  1052: getstatic       dev/nuker/pyro/fc.0:I
        //  1055: ifgt            1063
        //  1058: ldc             -118391234
        //  1060: goto            1065
        //  1063: ldc             2122222434
        //  1065: ldc             -2144782164
        //  1067: ixor           
        //  1068: lookupswitch {
        //          -147742583: 1063
        //          2027439762: 2358
        //          default: 1096
        //        }
        //  1096: aload_0        
        //  1097: getfield        dev/nuker/pyro/f5M.c:Lnet/minecraft/potion/PotionEffect;
        //  1100: getstatic       dev/nuker/pyro/fc.1:I
        //  1103: ifne            1111
        //  1106: ldc             -146538254
        //  1108: goto            1113
        //  1111: ldc             -1151075061
        //  1113: ldc             1322627939
        //  1115: ixor           
        //  1116: lookupswitch {
        //          -1181633647: 2362
        //          -913901263: 1111
        //          default: 1144
        //        }
        //  1144: goto            1148
        //  1147: athrow         
        //  1148: invokevirtual   net/minecraft/potion/PotionEffect.func_76458_c:()I
        //  1151: goto            1155
        //  1154: athrow         
        //  1155: ifle            1163
        //  1158: ldc             -38280854
        //  1160: goto            1165
        //  1163: ldc             -38280939
        //  1165: ldc             -366255019
        //  1167: ixor           
        //  1168: tableswitch {
        //          792267390: 1192
        //          792267391: 1616
        //          default: 1158
        //        }
        //  1192: getstatic       dev/nuker/pyro/fc.1:I
        //  1195: ifne            1203
        //  1198: ldc             -375240691
        //  1200: goto            1205
        //  1203: ldc             1978082804
        //  1205: ldc             -653561079
        //  1207: ixor           
        //  1208: lookupswitch {
        //          816397060: 2360
        //          1118110446: 1203
        //          default: 1236
        //        }
        //  1236: aload           8
        //  1238: new             Ljava/lang/StringBuilder;
        //  1241: dup            
        //  1242: goto            1246
        //  1245: athrow         
        //  1246: invokespecial   java/lang/StringBuilder.<init>:()V
        //  1249: goto            1253
        //  1252: athrow         
        //  1253: swap           
        //  1254: goto            1258
        //  1257: athrow         
        //  1258: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1261: goto            1265
        //  1264: athrow         
        //  1265: ldc             " "
        //  1267: goto            1271
        //  1270: athrow         
        //  1271: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1274: goto            1278
        //  1277: athrow         
        //  1278: new             Ljava/lang/StringBuilder;
        //  1281: dup            
        //  1282: goto            1286
        //  1285: athrow         
        //  1286: invokespecial   java/lang/StringBuilder.<init>:()V
        //  1289: goto            1293
        //  1292: athrow         
        //  1293: ldc             "\u3d64\ub24b\u8e30\uafbd\u613e\u598a\u7e54\u6929\uc0d7\ua5d7\u9bcc\u134a\uc149\u731a\u96f8\u4d89\ub21d\u4ce1"
        //  1295: getstatic       dev/nuker/pyro/fc.c:I
        //  1298: ifne            1306
        //  1301: ldc             -299680096
        //  1303: goto            1308
        //  1306: ldc             2081652811
        //  1308: ldc             1139351173
        //  1310: ixor           
        //  1311: lookupswitch {
        //          -1379262427: 1306
        //          1073389262: 1336
        //          default: 2332
        //        }
        //  1336: goto            1340
        //  1339: athrow         
        //  1340: invokestatic    invokestatic   !!! ERROR
        //  1343: goto            1347
        //  1346: athrow         
        //  1347: goto            1351
        //  1350: athrow         
        //  1351: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1354: goto            1358
        //  1357: athrow         
        //  1358: getstatic       dev/nuker/pyro/fc.0:I
        //  1361: ifgt            1370
        //  1364: ldc_w           401262412
        //  1367: goto            1373
        //  1370: ldc_w           1779558273
        //  1373: ldc_w           809572646
        //  1376: ixor           
        //  1377: lookupswitch {
        //          665575018: 1370
        //          1515257511: 1404
        //          default: 2312
        //        }
        //  1404: aload_0        
        //  1405: getfield        dev/nuker/pyro/f5M.c:Lnet/minecraft/potion/PotionEffect;
        //  1408: getstatic       dev/nuker/pyro/fc.c:I
        //  1411: ifne            1420
        //  1414: ldc_w           -1647993599
        //  1417: goto            1423
        //  1420: ldc_w           -1491287049
        //  1423: ldc_w           1285974921
        //  1426: ixor           
        //  1427: lookupswitch {
        //          -781977976: 1420
        //          -340088706: 1452
        //          default: 2314
        //        }
        //  1452: goto            1456
        //  1455: athrow         
        //  1456: invokevirtual   net/minecraft/potion/PotionEffect.func_76458_c:()I
        //  1459: goto            1463
        //  1462: athrow         
        //  1463: iconst_1       
        //  1464: iadd           
        //  1465: goto            1469
        //  1468: athrow         
        //  1469: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //  1472: goto            1476
        //  1475: athrow         
        //  1476: getstatic       dev/nuker/pyro/fc.0:I
        //  1479: ifgt            1488
        //  1482: ldc_w           762848727
        //  1485: goto            1491
        //  1488: ldc_w           407639882
        //  1491: ldc_w           2050065104
        //  1494: ixor           
        //  1495: lookupswitch {
        //          1464444679: 1488
        //          1652397466: 1520
        //          default: 2346
        //        }
        //  1520: goto            1524
        //  1523: athrow         
        //  1524: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1527: goto            1531
        //  1530: athrow         
        //  1531: iconst_0       
        //  1532: anewarray       Ljava/lang/Object;
        //  1535: goto            1539
        //  1538: athrow         
        //  1539: invokestatic    net/minecraft/client/resources/I18n.func_135052_a:(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
        //  1542: goto            1546
        //  1545: athrow         
        //  1546: getstatic       dev/nuker/pyro/fc.1:I
        //  1549: ifne            1558
        //  1552: ldc_w           -811463825
        //  1555: goto            1561
        //  1558: ldc_w           459891105
        //  1561: ldc_w           849862003
        //  1564: ixor           
        //  1565: lookupswitch {
        //          -49949156: 1558
        //          701414610: 1592
        //          default: 2330
        //        }
        //  1592: goto            1596
        //  1595: athrow         
        //  1596: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1599: goto            1603
        //  1602: athrow         
        //  1603: goto            1607
        //  1606: athrow         
        //  1607: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1610: goto            1614
        //  1613: athrow         
        //  1614: astore          8
        //  1616: aload_0        
        //  1617: getstatic       dev/nuker/pyro/fc.c:I
        //  1620: ifne            1629
        //  1623: ldc_w           -1723442658
        //  1626: goto            1632
        //  1629: ldc_w           1427272771
        //  1632: ldc_w           1015891436
        //  1635: ixor           
        //  1636: lookupswitch {
        //          -1513414670: 1629
        //          1772040623: 1664
        //          default: 2306
        //        }
        //  1664: getfield        dev/nuker/pyro/f5M.c:Lnet/minecraft/potion/PotionEffect;
        //  1667: fconst_1       
        //  1668: getstatic       dev/nuker/pyro/fc.1:I
        //  1671: ifne            1680
        //  1674: ldc_w           1344580594
        //  1677: goto            1683
        //  1680: ldc_w           581176145
        //  1683: ldc_w           -1864866050
        //  1686: ixor           
        //  1687: lookupswitch {
        //          -1300468305: 1712
        //          -1057174260: 1680
        //          default: 2326
        //        }
        //  1712: goto            1716
        //  1715: athrow         
        //  1716: invokestatic    net/minecraft/potion/Potion.func_188410_a:(Lnet/minecraft/potion/PotionEffect;F)Ljava/lang/String;
        //  1719: goto            1723
        //  1722: athrow         
        //  1723: astore          9
        //  1725: new             Ljava/lang/StringBuilder;
        //  1728: dup            
        //  1729: goto            1733
        //  1732: athrow         
        //  1733: invokespecial   java/lang/StringBuilder.<init>:()V
        //  1736: goto            1740
        //  1739: athrow         
        //  1740: aload           9
        //  1742: goto            1746
        //  1745: athrow         
        //  1746: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1749: goto            1753
        //  1752: athrow         
        //  1753: bipush          32
        //  1755: getstatic       dev/nuker/pyro/fc.1:I
        //  1758: ifne            1767
        //  1761: ldc_w           196945399
        //  1764: goto            1770
        //  1767: ldc_w           1045342066
        //  1770: ldc_w           118702250
        //  1773: ixor           
        //  1774: lookupswitch {
        //          212755805: 1767
        //          962455512: 1800
        //          default: 2354
        //        }
        //  1800: goto            1804
        //  1803: athrow         
        //  1804: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //  1807: goto            1811
        //  1810: athrow         
        //  1811: getstatic       dev/nuker/pyro/fc.c:I
        //  1814: ifne            1823
        //  1817: ldc_w           -1069441695
        //  1820: goto            1826
        //  1823: ldc_w           138874997
        //  1826: ldc_w           -460759977
        //  1829: ixor           
        //  1830: lookupswitch {
        //          -322024414: 1856
        //          617136438: 1823
        //          default: 2304
        //        }
        //  1856: aload           8
        //  1858: goto            1862
        //  1861: athrow         
        //  1862: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1865: goto            1869
        //  1868: athrow         
        //  1869: goto            1873
        //  1872: athrow         
        //  1873: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1876: goto            1880
        //  1879: athrow         
        //  1880: astore          10
        //  1882: getstatic       dev/nuker/pyro/fc.1:I
        //  1885: ifne            1894
        //  1888: ldc_w           786208231
        //  1891: goto            1897
        //  1894: ldc_w           -991544954
        //  1897: ldc_w           847473616
        //  1900: ixor           
        //  1901: lookupswitch {
        //          -161131946: 1928
        //          476053047: 1894
        //          default: 2348
        //        }
        //  1928: aload           10
        //  1930: goto            1934
        //  1933: athrow         
        //  1934: invokestatic    dev/nuker/pyro/fe6.0:(Ljava/lang/String;)F
        //  1937: goto            1941
        //  1940: athrow         
        //  1941: fstore          11
        //  1943: new             Ljava/lang/StringBuilder;
        //  1946: dup            
        //  1947: goto            1951
        //  1950: athrow         
        //  1951: invokespecial   java/lang/StringBuilder.<init>:()V
        //  1954: goto            1958
        //  1957: athrow         
        //  1958: aload           8
        //  1960: goto            1964
        //  1963: athrow         
        //  1964: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1967: goto            1971
        //  1970: athrow         
        //  1971: bipush          32
        //  1973: goto            1977
        //  1976: athrow         
        //  1977: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //  1980: goto            1984
        //  1983: athrow         
        //  1984: aload           9
        //  1986: goto            1990
        //  1989: athrow         
        //  1990: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1993: goto            1997
        //  1996: athrow         
        //  1997: goto            2001
        //  2000: athrow         
        //  2001: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  2004: goto            2008
        //  2007: athrow         
        //  2008: astore          10
        //  2010: aload           10
        //  2012: getstatic       dev/nuker/pyro/fc.0:I
        //  2015: ifgt            2024
        //  2018: ldc_w           1761372686
        //  2021: goto            2027
        //  2024: ldc_w           -2047807432
        //  2027: ldc_w           553358309
        //  2030: ixor           
        //  2031: lookupswitch {
        //          182742561: 2024
        //          1208482283: 2344
        //          default: 2056
        //        }
        //  2056: goto            2060
        //  2059: athrow         
        //  2060: invokestatic    dev/nuker/pyro/fe6.0:(Ljava/lang/String;)F
        //  2063: goto            2067
        //  2066: athrow         
        //  2067: iconst_2       
        //  2068: i2f            
        //  2069: fadd           
        //  2070: fstore          11
        //  2072: new             Ljava/lang/StringBuilder;
        //  2075: dup            
        //  2076: goto            2080
        //  2079: athrow         
        //  2080: invokespecial   java/lang/StringBuilder.<init>:()V
        //  2083: goto            2087
        //  2086: athrow         
        //  2087: aload           8
        //  2089: goto            2093
        //  2092: athrow         
        //  2093: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  2096: goto            2100
        //  2099: athrow         
        //  2100: bipush          32
        //  2102: getstatic       dev/nuker/pyro/fc.1:I
        //  2105: ifne            2114
        //  2108: ldc_w           -1988687744
        //  2111: goto            2117
        //  2114: ldc_w           1768859469
        //  2117: ldc_w           -1833760662
        //  2120: ixor           
        //  2121: lookupswitch {
        //          -813358525: 2114
        //          465830122: 2352
        //          default: 2148
        //        }
        //  2148: goto            2152
        //  2151: athrow         
        //  2152: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //  2155: goto            2159
        //  2158: athrow         
        //  2159: aload           9
        //  2161: goto            2165
        //  2164: athrow         
        //  2165: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  2168: goto            2172
        //  2171: athrow         
        //  2172: goto            2176
        //  2175: athrow         
        //  2176: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  2179: goto            2183
        //  2182: athrow         
        //  2183: iload           6
        //  2185: ifeq            2194
        //  2188: ldc_w           -278916748
        //  2191: goto            2197
        //  2194: ldc_w           -278916741
        //  2197: ldc_w           -991502237
        //  2200: ixor           
        //  2201: tableswitch {
        //          1460527662: 2224
        //          1460527663: 2228
        //          default: 2188
        //        }
        //  2224: fconst_0       
        //  2225: goto            2231
        //  2228: ldc_w           15.0
        //  2231: ldc_w           3.0
        //  2234: iconst_m1      
        //  2235: goto            2239
        //  2238: athrow         
        //  2239: invokestatic    dev/nuker/pyro/fe6.1:(Ljava/lang/String;FFI)V
        //  2242: goto            2246
        //  2245: athrow         
        //  2246: getstatic       dev/nuker/pyro/fc.c:I
        //  2249: ifne            2258
        //  2252: ldc_w           -1320103569
        //  2255: goto            2261
        //  2258: ldc_w           1694009502
        //  2261: ldc_w           -1821084866
        //  2264: ixor           
        //  2265: lookupswitch {
        //          563581815: 2258
        //          572826193: 2338
        //          default: 2292
        //        }
        //  2292: goto            2296
        //  2295: athrow         
        //  2296: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179121_F:()V
        //  2299: goto            2303
        //  2302: athrow         
        //  2303: return         
        //  2304: aconst_null    
        //  2305: athrow         
        //  2306: aconst_null    
        //  2307: athrow         
        //  2308: aconst_null    
        //  2309: athrow         
        //  2310: aconst_null    
        //  2311: athrow         
        //  2312: aconst_null    
        //  2313: athrow         
        //  2314: aconst_null    
        //  2315: athrow         
        //  2316: aconst_null    
        //  2317: athrow         
        //  2318: aconst_null    
        //  2319: athrow         
        //  2320: aconst_null    
        //  2321: athrow         
        //  2322: aconst_null    
        //  2323: athrow         
        //  2324: aconst_null    
        //  2325: athrow         
        //  2326: aconst_null    
        //  2327: athrow         
        //  2328: aconst_null    
        //  2329: athrow         
        //  2330: aconst_null    
        //  2331: athrow         
        //  2332: aconst_null    
        //  2333: athrow         
        //  2334: aconst_null    
        //  2335: athrow         
        //  2336: aconst_null    
        //  2337: athrow         
        //  2338: aconst_null    
        //  2339: athrow         
        //  2340: aconst_null    
        //  2341: athrow         
        //  2342: aconst_null    
        //  2343: athrow         
        //  2344: aconst_null    
        //  2345: athrow         
        //  2346: aconst_null    
        //  2347: athrow         
        //  2348: aconst_null    
        //  2349: athrow         
        //  2350: aconst_null    
        //  2351: athrow         
        //  2352: aconst_null    
        //  2353: athrow         
        //  2354: aconst_null    
        //  2355: athrow         
        //  2356: aconst_null    
        //  2357: athrow         
        //  2358: aconst_null    
        //  2359: athrow         
        //  2360: aconst_null    
        //  2361: athrow         
        //  2362: aconst_null    
        //  2363: athrow         
        //  2364: pop            
        //  2365: goto            24
        //  2368: pop            
        //  2369: aconst_null    
        //  2370: goto            2364
        //  2373: dup            
        //  2374: ifnull          2364
        //  2377: checkcast       Ljava/lang/Throwable;
        //  2380: athrow         
        //  2381: dup            
        //  2382: ifnull          2368
        //  2385: checkcast       Ljava/lang/Throwable;
        //  2388: athrow         
        //  2389: aconst_null    
        //  2390: athrow         
        //    StackMapTable: 01 76 43 07 00 3B 04 FF 00 0B 00 00 00 01 07 00 3B FF 00 03 00 06 07 00 03 07 01 44 01 07 01 46 02 02 00 00 42 07 00 1B 00 45 07 00 3B 00 04 04 41 01 18 03 40 01 FF 00 08 00 07 07 00 03 07 01 44 01 07 01 46 02 02 01 00 01 07 00 2F FF 00 00 00 07 07 00 03 07 01 44 01 07 01 46 02 02 01 00 04 02 02 02 02 45 07 00 3B 00 0A 41 01 1C 42 07 00 3B 00 45 07 00 3B 00 4E 07 00 59 FF 00 01 00 07 07 00 03 07 01 44 01 07 01 46 02 02 01 00 02 07 00 59 01 5B 07 00 59 42 07 00 19 40 07 00 59 45 07 00 3B 40 07 00 7C 4A 07 00 7C FF 00 01 00 07 07 00 03 07 01 44 01 07 01 46 02 02 01 00 02 07 00 7C 01 5B 07 00 7C FF 00 08 00 08 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 00 01 07 00 3B FF 00 00 00 08 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 00 04 02 02 02 02 45 07 00 3B 00 FF 00 07 00 00 00 01 07 00 3B FF 00 00 00 08 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 00 01 07 00 67 45 07 00 3B 40 07 00 73 45 07 00 3B FF 00 00 00 08 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 00 02 07 00 73 07 01 48 45 07 00 3B 00 4C 07 00 7C FF 00 01 00 08 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 00 02 07 00 7C 01 5D 07 00 7C 42 07 00 3B 40 07 00 7C 45 07 00 3B 40 01 49 07 00 3B 40 07 00 7C 45 07 00 3B 40 01 FF 00 08 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 01 07 00 3B 00 45 07 00 3B 00 42 07 00 2F 00 45 07 00 3B 00 FF 00 02 00 00 00 01 07 00 3B FF 00 00 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 00 45 07 00 3B 00 0A 41 01 1E 48 07 00 3B 40 07 00 03 45 07 00 3B 40 02 07 40 03 44 07 00 3B FF 00 00 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 03 03 03 03 45 07 00 3B 00 0A 41 01 1B FF 00 0E 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 02 02 02 FF 00 01 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 03 02 02 01 FF 00 1E 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 02 02 02 FF 00 0C 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 03 02 02 02 FF 00 01 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 04 02 02 02 01 FF 00 1C 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 03 02 02 02 42 07 00 3B FF 00 00 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 03 02 02 02 45 07 00 3B 00 4D 07 00 67 FF 00 01 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 02 07 00 67 01 5C 07 00 67 11 48 07 00 AB 4E 07 00 AB FF 00 01 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 02 07 00 AB 01 5B 07 00 AB 42 07 00 3B 40 07 00 AB 45 07 00 3B 40 07 00 AB FF 00 24 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 07 07 00 AB 01 01 01 01 01 01 FF 00 01 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 08 07 00 AB 01 01 01 01 01 01 01 FF 00 1D 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 07 07 00 AB 01 01 01 01 01 01 42 07 00 27 FF 00 00 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 07 07 00 AB 01 01 01 01 01 01 45 07 00 3B 00 0A 41 01 1B 42 07 00 3B 00 45 07 00 3B 00 42 07 00 2B 00 45 07 00 3B 00 0A 41 01 1C 42 07 00 3B 00 45 07 00 3B F9 00 00 4D 07 00 3B FF 00 00 00 08 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 00 05 07 00 7C 01 01 07 00 59 07 00 67 45 07 00 3B 00 0A 41 01 1D 46 07 00 3B 40 07 00 7C 45 07 00 3B 40 07 01 4A 46 07 00 3B FF 00 00 00 08 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 00 02 07 01 4A 07 01 4C 45 07 00 3B 40 07 01 4A FC 00 0C 07 01 4A 41 01 1E 4E 07 00 59 FF 00 01 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 59 01 5E 07 00 59 42 07 00 2F 40 07 00 59 45 07 00 3B 40 01 02 04 41 01 1A 0A 41 01 1E FF 00 08 00 00 00 01 07 00 3B FF 00 00 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 03 07 01 4A 08 04 D6 08 04 D6 45 07 00 3B FF 00 00 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 01 4A 07 00 F1 43 07 00 25 FF 00 00 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 F1 07 01 4A 45 07 00 3B 40 07 00 F1 44 07 00 3B FF 00 00 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 F1 07 01 4A 45 07 00 3B 40 07 00 F1 46 07 00 1D FF 00 00 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 03 07 00 F1 08 04 FE 08 04 FE 45 07 00 3B FF 00 00 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 F1 07 00 F1 FF 00 0C 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 03 07 00 F1 07 00 F1 07 01 4A FF 00 01 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 04 07 00 F1 07 00 F1 07 01 4A 01 FF 00 1B 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 03 07 00 F1 07 00 F1 07 01 4A 42 07 00 2F FF 00 00 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 03 07 00 F1 07 00 F1 07 01 4A 45 07 00 3B FF 00 00 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 03 07 00 F1 07 00 F1 07 01 4A 42 07 00 3B FF 00 00 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 03 07 00 F1 07 00 F1 07 01 4A 45 07 00 3B FF 00 00 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 F1 07 00 F1 FF 00 0B 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 F1 07 00 F1 FF 00 02 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 03 07 00 F1 07 00 F1 01 FF 00 1E 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 F1 07 00 F1 FF 00 0F 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 03 07 00 F1 07 00 F1 07 00 59 FF 00 02 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 04 07 00 F1 07 00 F1 07 00 59 01 FF 00 1C 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 03 07 00 F1 07 00 F1 07 00 59 42 07 00 3B FF 00 00 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 03 07 00 F1 07 00 F1 07 00 59 45 07 00 3B FF 00 00 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 03 07 00 F1 07 00 F1 01 44 07 00 3B FF 00 00 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 03 07 00 F1 07 00 F1 01 45 07 00 3B FF 00 00 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 F1 07 00 F1 FF 00 0B 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 F1 07 00 F1 FF 00 02 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 03 07 00 F1 07 00 F1 01 FF 00 1C 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 F1 07 00 F1 42 07 00 2F FF 00 00 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 F1 07 00 F1 45 07 00 3B FF 00 00 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 F1 07 01 4A 46 07 00 21 FF 00 00 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 03 07 00 F1 07 01 4A 07 01 4C 45 07 00 3B FF 00 00 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 F1 07 01 4A FF 00 0B 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 F1 07 01 4A FF 00 02 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 03 07 00 F1 07 01 4A 01 FF 00 1E 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 F1 07 01 4A 42 07 00 1F FF 00 00 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 F1 07 01 4A 45 07 00 3B 40 07 00 F1 42 07 00 1B 40 07 00 F1 45 07 00 3B 40 07 01 4A 01 4C 07 00 03 FF 00 02 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 03 01 5F 07 00 03 FF 00 0F 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 59 02 FF 00 02 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 03 07 00 59 02 01 FF 00 1C 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 59 02 42 07 00 3B FF 00 00 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 59 02 45 07 00 3B 40 07 01 4A FF 00 08 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 00 01 07 00 27 FF 00 00 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 00 02 08 06 BD 08 06 BD 45 07 00 3B 40 07 00 F1 44 07 00 3B FF 00 00 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 00 02 07 00 F1 07 01 4A 45 07 00 3B 40 07 00 F1 FF 00 0D 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 00 02 07 00 F1 01 FF 00 02 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 00 03 07 00 F1 01 01 FF 00 1D 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 00 02 07 00 F1 01 42 07 00 3B FF 00 00 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 00 02 07 00 F1 01 45 07 00 3B 40 07 00 F1 4B 07 00 F1 FF 00 02 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 00 02 07 00 F1 01 5D 07 00 F1 44 07 00 27 FF 00 00 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 00 02 07 00 F1 07 01 4A 45 07 00 3B 40 07 00 F1 42 07 00 3B 40 07 00 F1 45 07 00 3B 40 07 01 4A FC 00 0D 07 01 4A 42 01 1E 44 07 00 3B 40 07 01 4A 45 07 00 3B 40 02 FF 00 08 00 0C 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 07 01 4A 02 00 01 07 00 29 FF 00 00 00 0C 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 07 01 4A 02 00 02 08 07 97 08 07 97 45 07 00 3B 40 07 00 F1 FF 00 04 00 00 00 01 07 00 3B FF 00 00 00 0C 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 07 01 4A 02 00 02 07 00 F1 07 01 4A 45 07 00 3B 40 07 00 F1 44 07 00 3B FF 00 00 00 0C 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 07 01 4A 02 00 02 07 00 F1 01 45 07 00 3B 40 07 00 F1 44 07 00 3B FF 00 00 00 0C 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 07 01 4A 02 00 02 07 00 F1 07 01 4A 45 07 00 3B 40 07 00 F1 42 07 00 3B 40 07 00 F1 45 07 00 3B 40 07 01 4A 4F 07 01 4A FF 00 02 00 0C 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 07 01 4A 02 00 02 07 01 4A 01 5C 07 01 4A FF 00 02 00 00 00 01 07 00 3B FF 00 00 00 0C 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 07 01 4A 02 00 01 07 01 4A 45 07 00 3B 40 02 4B 07 00 27 FF 00 00 00 0C 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 07 01 4A 02 00 02 08 08 18 08 08 18 45 07 00 3B 40 07 00 F1 44 07 00 19 FF 00 00 00 0C 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 07 01 4A 02 00 02 07 00 F1 07 01 4A 45 07 00 3B 40 07 00 F1 FF 00 0D 00 0C 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 07 01 4A 02 00 02 07 00 F1 01 FF 00 02 00 0C 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 07 01 4A 02 00 03 07 00 F1 01 01 FF 00 1E 00 0C 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 07 01 4A 02 00 02 07 00 F1 01 42 07 00 19 FF 00 00 00 0C 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 07 01 4A 02 00 02 07 00 F1 01 45 07 00 3B 40 07 00 F1 FF 00 04 00 00 00 01 07 00 3B FF 00 00 00 0C 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 07 01 4A 02 00 02 07 00 F1 07 01 4A 45 07 00 3B 40 07 00 F1 FF 00 02 00 00 00 01 07 00 3B FF 00 00 00 0C 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 07 01 4A 02 00 01 07 00 F1 45 07 00 3B 40 07 01 4A 44 07 01 4A 45 07 01 4A FF 00 02 00 0C 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 07 01 4A 02 00 02 07 01 4A 01 5A 07 01 4A 43 07 01 4A FF 00 02 00 0C 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 07 01 4A 02 00 02 07 01 4A 02 FF 00 06 00 00 00 01 07 00 3B FF 00 00 00 0C 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 07 01 4A 02 00 04 07 01 4A 02 02 01 45 07 00 3B 00 0B 42 01 1E 42 07 00 3B 00 45 07 00 3B 00 FF 00 00 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 00 01 07 00 F1 FF 00 01 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 01 07 00 03 FF 00 01 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 02 02 02 FF 00 01 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 03 02 02 02 FF 00 01 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 F1 07 00 F1 FF 00 01 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 03 07 00 F1 07 00 F1 07 00 59 FF 00 01 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 00 F8 00 01 41 07 00 59 FF 00 01 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 01 07 00 67 FF 00 01 00 08 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 00 01 07 00 7C FF 00 01 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 59 02 FF 00 01 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 07 07 00 AB 01 01 01 01 01 01 FF 00 01 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 F1 07 01 4A FF 00 01 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 03 07 00 F1 07 00 F1 07 01 4A FF 00 01 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 00 F9 00 01 FF 00 01 00 0C 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 07 01 4A 02 00 00 FF 00 01 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 00 01 FF 00 01 00 0C 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 07 01 4A 02 00 01 07 01 4A FF 00 01 00 09 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 00 02 07 00 F1 07 00 F1 FD 00 01 07 01 4A 07 01 4A FF 00 01 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 01 02 00 01 07 00 AB FF 00 01 00 0C 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 07 01 4A 02 00 02 07 00 F1 01 FF 00 01 00 0A 07 00 03 07 01 44 01 07 01 46 02 02 01 07 00 7C 07 01 4A 07 01 4A 00 02 07 00 F1 01 FF 00 01 00 07 07 00 03 07 01 44 01 07 01 46 02 02 01 00 01 07 00 7C FD 00 01 07 00 7C 07 01 4A 01 41 07 00 59 FF 00 01 00 06 07 00 03 07 01 44 01 07 01 46 02 02 00 01 07 00 2F 43 05 44 07 00 2F 47 05 47 07 00 3B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     2373   2381   Ljava/lang/EnumConstantNotPresentException;
        //  2373   2381   2373   2381   Ljava/util/NoSuchElementException;
        //  2389   2391   3      8      Ljava/lang/IllegalStateException;
        //  27     34     34     35     Any
        //  27     34     27     28     Ljava/lang/UnsupportedOperationException;
        //  28     34     3      8      Ljava/lang/NegativeArraySizeException;
        //  27     34     34     35     Any
        //  27     34     3      8      Any
        //  86     93     93     94     Any
        //  86     93     86     87     Ljava/lang/StringIndexOutOfBoundsException;
        //  87     93     93     94     Any
        //  86     93     93     94     Any
        //  86     93     86     87     Ljava/util/ConcurrentModificationException;
        //  139    146    146    147    Any
        //  139    146    139    140    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  139    146    3      8      Any
        //  139    146    139    140    Any
        //  140    146    139    140    Ljava/lang/ArithmeticException;
        //  195    202    202    203    Any
        //  196    202    3      8      Ljava/util/NoSuchElementException;
        //  196    202    195    196    Ljava/lang/IllegalStateException;
        //  196    202    3      8      Any
        //  195    202    202    203    Ljava/util/NoSuchElementException;
        //  253    260    260    261    Any
        //  253    260    260    261    Ljava/lang/IndexOutOfBoundsException;
        //  254    260    253    254    Any
        //  254    260    260    261    Any
        //  254    260    253    254    Ljava/util/NoSuchElementException;
        //  270    276    276    277    Any
        //  270    276    276    277    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  270    276    276    277    Ljava/lang/IllegalStateException;
        //  270    276    276    277    Any
        //  270    276    276    277    Any
        //  283    290    290    291    Any
        //  283    290    283    284    Any
        //  283    290    290    291    Ljava/lang/StringIndexOutOfBoundsException;
        //  284    290    3      8      Any
        //  283    290    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  339    346    346    347    Any
        //  339    346    3      8      Ljava/lang/NegativeArraySizeException;
        //  339    346    346    347    Any
        //  339    346    339    340    Any
        //  339    346    346    347    Ljava/lang/EnumConstantNotPresentException;
        //  357    364    364    365    Any
        //  357    364    357    358    Any
        //  357    364    3      8      Any
        //  358    364    357    358    Any
        //  357    364    3      8      Any
        //  374    381    381    382    Any
        //  375    381    3      8      Ljava/util/ConcurrentModificationException;
        //  374    381    374    375    Any
        //  375    381    3      8      Ljava/lang/IllegalArgumentException;
        //  374    381    374    375    Ljava/lang/StringIndexOutOfBoundsException;
        //  385    392    392    393    Any
        //  386    392    385    386    Ljava/lang/NullPointerException;
        //  386    392    385    386    Ljava/lang/ClassCastException;
        //  386    392    3      8      Ljava/util/ConcurrentModificationException;
        //  385    392    392    393    Any
        //  397    403    403    404    Any
        //  397    403    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  397    403    403    404    Any
        //  397    403    403    404    Ljava/util/NoSuchElementException;
        //  397    403    403    404    Any
        //  457    464    464    465    Any
        //  458    464    457    458    Any
        //  458    464    457    458    Ljava/lang/EnumConstantNotPresentException;
        //  458    464    457    458    Ljava/lang/IllegalStateException;
        //  458    464    457    458    Ljava/lang/EnumConstantNotPresentException;
        //  479    486    486    487    Any
        //  480    486    3      8      Any
        //  479    486    479    480    Ljava/util/NoSuchElementException;
        //  480    486    479    480    Any
        //  480    486    486    487    Any
        //  623    630    630    631    Any
        //  623    630    630    631    Any
        //  623    630    630    631    Ljava/lang/RuntimeException;
        //  624    630    623    624    Any
        //  623    630    630    631    Any
        //  751    758    758    759    Any
        //  752    758    751    752    Any
        //  752    758    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  752    758    3      8      Any
        //  752    758    3      8      Any
        //  831    838    838    839    Any
        //  832    838    838    839    Ljava/lang/UnsupportedOperationException;
        //  832    838    831    832    Ljava/lang/IndexOutOfBoundsException;
        //  832    838    831    832    Ljava/lang/IndexOutOfBoundsException;
        //  831    838    3      8      Ljava/lang/ArithmeticException;
        //  883    890    890    891    Any
        //  883    890    883    884    Any
        //  884    890    3      8      Ljava/lang/IllegalStateException;
        //  884    890    3      8      Any
        //  883    890    890    891    Any
        //  894    901    901    902    Any
        //  894    901    894    895    Ljava/lang/NullPointerException;
        //  894    901    3      8      Any
        //  894    901    3      8      Any
        //  894    901    3      8      Any
        //  947    954    954    955    Any
        //  948    954    954    955    Any
        //  948    954    947    948    Any
        //  948    954    947    948    Ljava/lang/IllegalArgumentException;
        //  947    954    3      8      Ljava/lang/NullPointerException;
        //  969    976    976    977    Any
        //  969    976    3      8      Ljava/lang/AssertionError;
        //  969    976    969    970    Any
        //  969    976    969    970    Any
        //  970    976    3      8      Any
        //  1027   1034   1034   1035   Any
        //  1028   1034   1034   1035   Any
        //  1027   1034   1027   1028   Any
        //  1028   1034   3      8      Any
        //  1027   1034   3      8      Any
        //  1042   1049   1049   1050   Any
        //  1043   1049   1049   1050   Any
        //  1043   1049   3      8      Ljava/lang/NegativeArraySizeException;
        //  1042   1049   1042   1043   Any
        //  1043   1049   1042   1043   Ljava/util/NoSuchElementException;
        //  1147   1154   1154   1155   Any
        //  1148   1154   1154   1155   Ljava/lang/IllegalStateException;
        //  1148   1154   1147   1148   Ljava/util/NoSuchElementException;
        //  1147   1154   1147   1148   Ljava/lang/IndexOutOfBoundsException;
        //  1147   1154   3      8      Any
        //  1246   1252   1252   1253   Any
        //  1246   1252   1252   1253   Ljava/lang/UnsupportedOperationException;
        //  1246   1252   3      8      Any
        //  1246   1252   3      8      Any
        //  1246   1252   1252   1253   Ljava/lang/IllegalArgumentException;
        //  1257   1264   1264   1265   Any
        //  1258   1264   1257   1258   Ljava/lang/ArithmeticException;
        //  1258   1264   3      8      Ljava/lang/UnsupportedOperationException;
        //  1257   1264   3      8      Ljava/lang/IllegalStateException;
        //  1257   1264   1264   1265   Ljava/lang/ArithmeticException;
        //  1270   1277   1277   1278   Any
        //  1271   1277   1270   1271   Any
        //  1271   1277   1277   1278   Ljava/lang/NullPointerException;
        //  1270   1277   1270   1271   Ljava/lang/IndexOutOfBoundsException;
        //  1271   1277   3      8      Ljava/lang/AssertionError;
        //  1285   1292   1292   1293   Any
        //  1286   1292   1292   1293   Any
        //  1286   1292   1292   1293   Any
        //  1285   1292   1285   1286   Ljava/lang/NegativeArraySizeException;
        //  1285   1292   3      8      Ljava/lang/ArithmeticException;
        //  1339   1346   1346   1347   Any
        //  1340   1346   1339   1340   Ljava/lang/UnsupportedOperationException;
        //  1340   1346   1339   1340   Ljava/lang/EnumConstantNotPresentException;
        //  1340   1346   1346   1347   Ljava/lang/IllegalStateException;
        //  1339   1346   1339   1340   Ljava/util/ConcurrentModificationException;
        //  1350   1357   1357   1358   Any
        //  1350   1357   1350   1351   Any
        //  1350   1357   1357   1358   Any
        //  1351   1357   1350   1351   Any
        //  1350   1357   1350   1351   Ljava/util/ConcurrentModificationException;
        //  1455   1462   1462   1463   Any
        //  1455   1462   1455   1456   Any
        //  1456   1462   1455   1456   Ljava/lang/IllegalArgumentException;
        //  1455   1462   3      8      Ljava/lang/ArithmeticException;
        //  1456   1462   3      8      Any
        //  1468   1475   1475   1476   Any
        //  1469   1475   1468   1469   Any
        //  1469   1475   1475   1476   Ljava/lang/EnumConstantNotPresentException;
        //  1468   1475   1468   1469   Any
        //  1469   1475   1468   1469   Ljava/lang/StringIndexOutOfBoundsException;
        //  1523   1530   1530   1531   Any
        //  1523   1530   3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  1523   1530   1523   1524   Ljava/lang/NegativeArraySizeException;
        //  1523   1530   1523   1524   Ljava/lang/UnsupportedOperationException;
        //  1523   1530   1523   1524   Ljava/lang/UnsupportedOperationException;
        //  1538   1545   1545   1546   Any
        //  1538   1545   3      8      Any
        //  1539   1545   3      8      Ljava/lang/NegativeArraySizeException;
        //  1539   1545   1538   1539   Ljava/util/ConcurrentModificationException;
        //  1539   1545   1545   1546   Ljava/lang/IllegalStateException;
        //  1595   1602   1602   1603   Any
        //  1596   1602   1602   1603   Ljava/lang/IllegalArgumentException;
        //  1596   1602   1595   1596   Ljava/lang/StringIndexOutOfBoundsException;
        //  1596   1602   1602   1603   Any
        //  1596   1602   3      8      Ljava/lang/NegativeArraySizeException;
        //  1606   1613   1613   1614   Any
        //  1607   1613   3      8      Any
        //  1606   1613   1613   1614   Ljava/lang/EnumConstantNotPresentException;
        //  1607   1613   1613   1614   Ljava/lang/NegativeArraySizeException;
        //  1607   1613   1606   1607   Ljava/lang/UnsupportedOperationException;
        //  1715   1722   1722   1723   Any
        //  1716   1722   1715   1716   Ljava/lang/ArithmeticException;
        //  1715   1722   3      8      Any
        //  1716   1722   1715   1716   Any
        //  1715   1722   3      8      Any
        //  1732   1739   1739   1740   Any
        //  1732   1739   1739   1740   Ljava/util/ConcurrentModificationException;
        //  1732   1739   3      8      Ljava/lang/NegativeArraySizeException;
        //  1732   1739   1739   1740   Any
        //  1732   1739   1732   1733   Ljava/lang/IndexOutOfBoundsException;
        //  1745   1752   1752   1753   Any
        //  1745   1752   1752   1753   Any
        //  1745   1752   3      8      Ljava/lang/ClassCastException;
        //  1745   1752   1745   1746   Any
        //  1745   1752   1745   1746   Ljava/lang/NumberFormatException;
        //  1803   1810   1810   1811   Any
        //  1803   1810   1810   1811   Ljava/lang/IllegalStateException;
        //  1803   1810   1803   1804   Ljava/lang/NegativeArraySizeException;
        //  1804   1810   1803   1804   Any
        //  1804   1810   3      8      Any
        //  1861   1868   1868   1869   Any
        //  1861   1868   1861   1862   Ljava/lang/IndexOutOfBoundsException;
        //  1862   1868   3      8      Any
        //  1861   1868   3      8      Ljava/lang/IndexOutOfBoundsException;
        //  1862   1868   1868   1869   Any
        //  1872   1879   1879   1880   Any
        //  1872   1879   1872   1873   Any
        //  1872   1879   3      8      Any
        //  1873   1879   1872   1873   Any
        //  1873   1879   3      8      Ljava/lang/ArithmeticException;
        //  1933   1940   1940   1941   Any
        //  1933   1940   3      8      Any
        //  1934   1940   1940   1941   Any
        //  1933   1940   1933   1934   Any
        //  1934   1940   3      8      Any
        //  1950   1957   1957   1958   Any
        //  1950   1957   3      8      Any
        //  1950   1957   1950   1951   Ljava/lang/IllegalArgumentException;
        //  1950   1957   3      8      Ljava/lang/RuntimeException;
        //  1950   1957   1957   1958   Ljava/lang/AssertionError;
        //  1964   1970   1970   1971   Any
        //  1964   1970   1970   1971   Any
        //  1964   1970   1970   1971   Ljava/lang/EnumConstantNotPresentException;
        //  1964   1970   1970   1971   Any
        //  1964   1970   3      8      Ljava/lang/EnumConstantNotPresentException;
        //  1976   1983   1983   1984   Any
        //  1977   1983   1976   1977   Ljava/lang/NullPointerException;
        //  1976   1983   1976   1977   Any
        //  1976   1983   3      8      Any
        //  1977   1983   1976   1977   Any
        //  1989   1996   1996   1997   Any
        //  1989   1996   1996   1997   Any
        //  1989   1996   1989   1990   Any
        //  1989   1996   1996   1997   Any
        //  1990   1996   3      8      Ljava/util/ConcurrentModificationException;
        //  2000   2007   2007   2008   Any
        //  2000   2007   2000   2001   Ljava/lang/IllegalStateException;
        //  2000   2007   2007   2008   Any
        //  2001   2007   2000   2001   Any
        //  2001   2007   2000   2001   Ljava/lang/RuntimeException;
        //  2060   2066   2066   2067   Any
        //  2060   2066   2066   2067   Any
        //  2060   2066   3      8      Ljava/lang/IllegalStateException;
        //  2060   2066   2066   2067   Ljava/lang/RuntimeException;
        //  2060   2066   2066   2067   Ljava/lang/UnsupportedOperationException;
        //  2079   2086   2086   2087   Any
        //  2080   2086   2086   2087   Ljava/util/ConcurrentModificationException;
        //  2079   2086   2086   2087   Any
        //  2079   2086   2086   2087   Any
        //  2079   2086   2079   2080   Ljava/lang/IndexOutOfBoundsException;
        //  2092   2099   2099   2100   Any
        //  2093   2099   3      8      Ljava/lang/NumberFormatException;
        //  2092   2099   2099   2100   Any
        //  2093   2099   3      8      Any
        //  2092   2099   2092   2093   Ljava/lang/IllegalStateException;
        //  2151   2158   2158   2159   Any
        //  2152   2158   3      8      Ljava/lang/UnsupportedOperationException;
        //  2151   2158   2158   2159   Ljava/lang/NegativeArraySizeException;
        //  2152   2158   2151   2152   Ljava/lang/IllegalStateException;
        //  2152   2158   3      8      Any
        //  2165   2171   2171   2172   Any
        //  2165   2171   3      8      Ljava/lang/NumberFormatException;
        //  2165   2171   3      8      Any
        //  2165   2171   3      8      Ljava/lang/UnsupportedOperationException;
        //  2165   2171   3      8      Any
        //  2176   2182   2182   2183   Any
        //  2176   2182   3      8      Ljava/lang/RuntimeException;
        //  2176   2182   3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  2176   2182   2182   2183   Any
        //  2176   2182   3      8      Any
        //  2239   2245   2245   2246   Any
        //  2239   2245   2245   2246   Ljava/lang/UnsupportedOperationException;
        //  2239   2245   2245   2246   Ljava/lang/StringIndexOutOfBoundsException;
        //  2239   2245   2245   2246   Any
        //  2239   2245   2245   2246   Ljava/lang/IllegalStateException;
        //  2295   2302   2302   2303   Any
        //  2295   2302   2302   2303   Any
        //  2295   2302   3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  2296   2302   2295   2296   Any
        //  2296   2302   3      8      Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visitVariable(StackMappingVisitor.java:470)
        //     at com.strobel.assembler.ir.Instruction.accept(Instruction.java:556)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:403)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @NotNull
    public PotionEffect c() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getstatic       dev/nuker/pyro/fc.0:I
        //     4: ifeq            87
        //     7: pop            
        //     8: aconst_null    
        //     9: goto            79
        //    12: nop            
        //    13: nop            
        //    14: nop            
        //    15: athrow         
        //    16: aload_0        
        //    17: getstatic       dev/nuker/pyro/fc.1:I
        //    20: ifne            29
        //    23: ldc_w           -438459543
        //    26: goto            32
        //    29: ldc_w           692839555
        //    32: ldc_w           322842483
        //    35: ixor           
        //    36: lookupswitch {
        //          -152859622: 29
        //          980798448: 64
        //          default: 68
        //        }
        //    64: getfield        dev/nuker/pyro/f5M.c:Lnet/minecraft/potion/PotionEffect;
        //    67: areturn        
        //    68: aconst_null    
        //    69: athrow         
        //    70: pop            
        //    71: goto            16
        //    74: pop            
        //    75: aconst_null    
        //    76: goto            70
        //    79: dup            
        //    80: ifnull          70
        //    83: checkcast       Ljava/lang/Throwable;
        //    86: athrow         
        //    87: dup            
        //    88: ifnull          74
        //    91: checkcast       Ljava/lang/Throwable;
        //    94: athrow         
        //    StackMapTable: 00 0A FF 00 0C 00 00 00 01 07 00 3B FC 00 03 07 00 03 4C 07 00 03 FF 00 02 00 01 07 00 03 00 02 07 00 03 01 5F 07 00 03 43 07 00 03 41 07 00 3B 43 05 44 07 00 3B 47 05
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type
        //  -----  -----  -----  -----  ----
        //  0      12     79     87     Any
        //  79     87     79     87     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:543)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public float 5() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          902
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            894
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            886
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_0        
        //    25: getfield        dev/nuker/pyro/f5M.c:Lnet/minecraft/potion/PotionEffect;
        //    28: goto            32
        //    31: athrow         
        //    32: invokevirtual   net/minecraft/potion/PotionEffect.func_188419_a:()Lnet/minecraft/potion/Potion;
        //    35: goto            39
        //    38: athrow         
        //    39: dup            
        //    40: pop            
        //    41: goto            45
        //    44: athrow         
        //    45: invokevirtual   net/minecraft/potion/Potion.func_76393_a:()Ljava/lang/String;
        //    48: goto            52
        //    51: athrow         
        //    52: iconst_0       
        //    53: anewarray       Ljava/lang/Object;
        //    56: goto            60
        //    59: athrow         
        //    60: invokestatic    net/minecraft/client/resources/I18n.func_135052_a:(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
        //    63: goto            67
        //    66: athrow         
        //    67: getstatic       dev/nuker/pyro/fc.1:I
        //    70: ifne            79
        //    73: ldc_w           529392139
        //    76: goto            82
        //    79: ldc_w           1080918049
        //    82: ldc_w           -1834545864
        //    85: ixor           
        //    86: lookupswitch {
        //          -1926566093: 79
        //          -758477543: 112
        //          default: 871
        //        }
        //   112: astore_1       
        //   113: aload_0        
        //   114: getfield        dev/nuker/pyro/f5M.c:Lnet/minecraft/potion/PotionEffect;
        //   117: goto            121
        //   120: athrow         
        //   121: invokevirtual   net/minecraft/potion/PotionEffect.func_76458_c:()I
        //   124: goto            128
        //   127: athrow         
        //   128: ifle            137
        //   131: ldc_w           -1475158926
        //   134: goto            140
        //   137: ldc_w           -1475159027
        //   140: ldc_w           -190721971
        //   143: ixor           
        //   144: tableswitch {
        //          -1184491394: 168
        //          -1184491393: 464
        //          default: 131
        //        }
        //   168: aload_1        
        //   169: new             Ljava/lang/StringBuilder;
        //   172: dup            
        //   173: getstatic       dev/nuker/pyro/fc.0:I
        //   176: ifgt            185
        //   179: ldc_w           1929887106
        //   182: goto            188
        //   185: ldc_w           -2146369975
        //   188: ldc_w           -2068814460
        //   191: ixor           
        //   192: lookupswitch {
        //          -138946554: 857
        //          1011776320: 185
        //          default: 220
        //        }
        //   220: goto            224
        //   223: athrow         
        //   224: invokespecial   java/lang/StringBuilder.<init>:()V
        //   227: goto            231
        //   230: athrow         
        //   231: swap           
        //   232: goto            236
        //   235: athrow         
        //   236: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   239: goto            243
        //   242: athrow         
        //   243: ldc             " "
        //   245: goto            249
        //   248: athrow         
        //   249: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   252: goto            256
        //   255: athrow         
        //   256: new             Ljava/lang/StringBuilder;
        //   259: dup            
        //   260: goto            264
        //   263: athrow         
        //   264: invokespecial   java/lang/StringBuilder.<init>:()V
        //   267: goto            271
        //   270: athrow         
        //   271: ldc_w           "\u3d64\ub24b\u8e30\uafeb\u6110\u598a\u7e54\u6929\uc081\ua5f9\u9bcc\u134a\uc149\u734c\u96d6\u4d89\ub21d\u4ce1"
        //   274: goto            278
        //   277: athrow         
        //   278: invokestatic    invokestatic   !!! ERROR
        //   281: goto            285
        //   284: athrow         
        //   285: goto            289
        //   288: athrow         
        //   289: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   292: goto            296
        //   295: athrow         
        //   296: aload_0        
        //   297: getfield        dev/nuker/pyro/f5M.c:Lnet/minecraft/potion/PotionEffect;
        //   300: getstatic       dev/nuker/pyro/fc.0:I
        //   303: ifgt            312
        //   306: ldc_w           -541428173
        //   309: goto            315
        //   312: ldc_w           -1810001870
        //   315: ldc_w           81960733
        //   318: ixor           
        //   319: lookupswitch {
        //          -1153149208: 312
        //          -614930130: 869
        //          default: 344
        //        }
        //   344: goto            348
        //   347: athrow         
        //   348: invokevirtual   net/minecraft/potion/PotionEffect.func_76458_c:()I
        //   351: goto            355
        //   354: athrow         
        //   355: iconst_1       
        //   356: iadd           
        //   357: getstatic       dev/nuker/pyro/fc.c:I
        //   360: ifne            369
        //   363: ldc_w           -1697799086
        //   366: goto            372
        //   369: ldc_w           -1307470988
        //   372: ldc_w           -555729207
        //   375: ixor           
        //   376: lookupswitch {
        //          -1864732149: 369
        //          1143839387: 867
        //          default: 404
        //        }
        //   404: goto            408
        //   407: athrow         
        //   408: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //   411: goto            415
        //   414: athrow         
        //   415: goto            419
        //   418: athrow         
        //   419: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   422: goto            426
        //   425: athrow         
        //   426: iconst_0       
        //   427: anewarray       Ljava/lang/Object;
        //   430: goto            434
        //   433: athrow         
        //   434: invokestatic    net/minecraft/client/resources/I18n.func_135052_a:(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
        //   437: goto            441
        //   440: athrow         
        //   441: goto            445
        //   444: athrow         
        //   445: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   448: goto            452
        //   451: athrow         
        //   452: goto            456
        //   455: athrow         
        //   456: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   459: goto            463
        //   462: athrow         
        //   463: astore_1       
        //   464: getstatic       dev/nuker/pyro/fc.0:I
        //   467: ifgt            476
        //   470: ldc_w           -2085630764
        //   473: goto            479
        //   476: ldc_w           35281776
        //   479: ldc_w           77571465
        //   482: ixor           
        //   483: lookupswitch {
        //          -2026870435: 476
        //          109444857: 508
        //          default: 863
        //        }
        //   508: aload_0        
        //   509: getstatic       dev/nuker/pyro/fc.0:I
        //   512: ifgt            521
        //   515: ldc_w           1858148964
        //   518: goto            524
        //   521: ldc_w           1473881927
        //   524: ldc_w           -989825131
        //   527: ixor           
        //   528: lookupswitch {
        //          -1831218990: 556
        //          -1413386767: 521
        //          default: 873
        //        }
        //   556: getfield        dev/nuker/pyro/f5M.c:Lnet/minecraft/potion/PotionEffect;
        //   559: fconst_1       
        //   560: goto            564
        //   563: athrow         
        //   564: invokestatic    net/minecraft/potion/Potion.func_188410_a:(Lnet/minecraft/potion/PotionEffect;F)Ljava/lang/String;
        //   567: goto            571
        //   570: athrow         
        //   571: getstatic       dev/nuker/pyro/fc.c:I
        //   574: ifne            583
        //   577: ldc_w           89800077
        //   580: goto            586
        //   583: ldc_w           438014671
        //   586: ldc_w           1559389127
        //   589: ixor           
        //   590: lookupswitch {
        //          -593774889: 583
        //          1504206410: 865
        //          default: 616
        //        }
        //   616: astore_2       
        //   617: new             Ljava/lang/StringBuilder;
        //   620: dup            
        //   621: goto            625
        //   624: athrow         
        //   625: invokespecial   java/lang/StringBuilder.<init>:()V
        //   628: goto            632
        //   631: athrow         
        //   632: aload_2        
        //   633: goto            637
        //   636: athrow         
        //   637: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   640: goto            644
        //   643: athrow         
        //   644: bipush          32
        //   646: goto            650
        //   649: athrow         
        //   650: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   653: goto            657
        //   656: athrow         
        //   657: aload_1        
        //   658: getstatic       dev/nuker/pyro/fc.c:I
        //   661: ifne            670
        //   664: ldc_w           471393937
        //   667: goto            673
        //   670: ldc_w           378280429
        //   673: ldc_w           -352552705
        //   676: ixor           
        //   677: lookupswitch {
        //          -1368041416: 670
        //          -152789394: 859
        //          default: 704
        //        }
        //   704: goto            708
        //   707: athrow         
        //   708: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   711: goto            715
        //   714: athrow         
        //   715: bipush          32
        //   717: getstatic       dev/nuker/pyro/fc.1:I
        //   720: ifne            729
        //   723: ldc_w           -2131853028
        //   726: goto            732
        //   729: ldc_w           -610530812
        //   732: ldc_w           -287117589
        //   735: ixor           
        //   736: lookupswitch {
        //          897508591: 764
        //          1846308855: 729
        //          default: 875
        //        }
        //   764: goto            768
        //   767: athrow         
        //   768: invokevirtual   java/lang/StringBuilder.append:(C)Ljava/lang/StringBuilder;
        //   771: goto            775
        //   774: athrow         
        //   775: goto            779
        //   778: athrow         
        //   779: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   782: goto            786
        //   785: athrow         
        //   786: astore_3       
        //   787: aload_3        
        //   788: goto            792
        //   791: athrow         
        //   792: invokestatic    dev/nuker/pyro/fe6.0:(Ljava/lang/String;)F
        //   795: goto            799
        //   798: athrow         
        //   799: aload_0        
        //   800: getstatic       dev/nuker/pyro/fc.c:I
        //   803: ifne            812
        //   806: ldc_w           1960509736
        //   809: goto            815
        //   812: ldc_w           -1591927117
        //   815: ldc_w           -285600387
        //   818: ixor           
        //   819: lookupswitch {
        //          -1709108139: 861
        //          962737651: 812
        //          default: 844
        //        }
        //   844: goto            848
        //   847: athrow         
        //   848: invokevirtual   dev/nuker/pyro/f5M.0:()F
        //   851: goto            855
        //   854: athrow         
        //   855: fadd           
        //   856: freturn        
        //   857: aconst_null    
        //   858: athrow         
        //   859: aconst_null    
        //   860: athrow         
        //   861: aconst_null    
        //   862: athrow         
        //   863: aconst_null    
        //   864: athrow         
        //   865: aconst_null    
        //   866: athrow         
        //   867: aconst_null    
        //   868: athrow         
        //   869: aconst_null    
        //   870: athrow         
        //   871: aconst_null    
        //   872: athrow         
        //   873: aconst_null    
        //   874: athrow         
        //   875: aconst_null    
        //   876: athrow         
        //   877: pop            
        //   878: goto            24
        //   881: pop            
        //   882: aconst_null    
        //   883: goto            877
        //   886: dup            
        //   887: ifnull          877
        //   890: checkcast       Ljava/lang/Throwable;
        //   893: athrow         
        //   894: dup            
        //   895: ifnull          881
        //   898: checkcast       Ljava/lang/Throwable;
        //   901: athrow         
        //   902: aconst_null    
        //   903: athrow         
        //    StackMapTable: 00 9A 43 07 00 3B 04 FF 00 0B 00 00 00 01 07 00 3B FC 00 03 07 00 03 46 07 00 3B 40 07 00 59 45 07 00 3B 40 07 00 7C 44 07 00 3B 40 07 00 7C 45 07 00 3B 40 07 01 4A 46 07 00 3B FF 00 00 00 01 07 00 03 00 02 07 01 4A 07 01 4C 45 07 00 3B 40 07 01 4A 4B 07 01 4A FF 00 02 00 01 07 00 03 00 02 07 01 4A 01 5D 07 01 4A FF 00 07 00 02 07 00 03 07 01 4A 00 01 07 00 25 40 07 00 59 45 07 00 3B 40 01 02 05 42 01 1B FF 00 10 00 02 07 00 03 07 01 4A 00 03 07 01 4A 08 00 A9 08 00 A9 FF 00 02 00 02 07 00 03 07 01 4A 00 04 07 01 4A 08 00 A9 08 00 A9 01 FF 00 1F 00 02 07 00 03 07 01 4A 00 03 07 01 4A 08 00 A9 08 00 A9 42 07 00 3B FF 00 00 00 02 07 00 03 07 01 4A 00 03 07 01 4A 08 00 A9 08 00 A9 45 07 00 3B FF 00 00 00 02 07 00 03 07 01 4A 00 02 07 01 4A 07 00 F1 43 07 00 3B FF 00 00 00 02 07 00 03 07 01 4A 00 02 07 00 F1 07 01 4A 45 07 00 3B 40 07 00 F1 44 07 00 3B FF 00 00 00 02 07 00 03 07 01 4A 00 02 07 00 F1 07 01 4A 45 07 00 3B 40 07 00 F1 46 07 00 3B FF 00 00 00 02 07 00 03 07 01 4A 00 03 07 00 F1 08 01 00 08 01 00 45 07 00 3B FF 00 00 00 02 07 00 03 07 01 4A 00 02 07 00 F1 07 00 F1 45 07 00 31 FF 00 00 00 02 07 00 03 07 01 4A 00 03 07 00 F1 07 00 F1 07 01 4A 45 07 00 3B FF 00 00 00 02 07 00 03 07 01 4A 00 03 07 00 F1 07 00 F1 07 01 4A 42 07 00 27 FF 00 00 00 02 07 00 03 07 01 4A 00 03 07 00 F1 07 00 F1 07 01 4A 45 07 00 3B FF 00 00 00 02 07 00 03 07 01 4A 00 02 07 00 F1 07 00 F1 FF 00 0F 00 02 07 00 03 07 01 4A 00 03 07 00 F1 07 00 F1 07 00 59 FF 00 02 00 02 07 00 03 07 01 4A 00 04 07 00 F1 07 00 F1 07 00 59 01 FF 00 1C 00 02 07 00 03 07 01 4A 00 03 07 00 F1 07 00 F1 07 00 59 42 07 00 3B FF 00 00 00 02 07 00 03 07 01 4A 00 03 07 00 F1 07 00 F1 07 00 59 45 07 00 3B FF 00 00 00 02 07 00 03 07 01 4A 00 03 07 00 F1 07 00 F1 01 FF 00 0D 00 02 07 00 03 07 01 4A 00 03 07 00 F1 07 00 F1 01 FF 00 02 00 02 07 00 03 07 01 4A 00 04 07 00 F1 07 00 F1 01 01 FF 00 1F 00 02 07 00 03 07 01 4A 00 03 07 00 F1 07 00 F1 01 42 07 00 15 FF 00 00 00 02 07 00 03 07 01 4A 00 03 07 00 F1 07 00 F1 01 45 07 00 3B FF 00 00 00 02 07 00 03 07 01 4A 00 02 07 00 F1 07 00 F1 42 07 00 3B FF 00 00 00 02 07 00 03 07 01 4A 00 02 07 00 F1 07 00 F1 45 07 00 3B FF 00 00 00 02 07 00 03 07 01 4A 00 02 07 00 F1 07 01 4A 46 07 00 3B FF 00 00 00 02 07 00 03 07 01 4A 00 03 07 00 F1 07 01 4A 07 01 4C 45 07 00 3B FF 00 00 00 02 07 00 03 07 01 4A 00 02 07 00 F1 07 01 4A 42 07 00 3B FF 00 00 00 02 07 00 03 07 01 4A 00 02 07 00 F1 07 01 4A 45 07 00 3B 40 07 00 F1 42 07 00 2F 40 07 00 F1 45 07 00 3B 40 07 01 4A 00 0B 42 01 1C 4C 07 00 03 FF 00 02 00 02 07 00 03 07 01 4A 00 02 07 00 03 01 5F 07 00 03 46 07 00 27 FF 00 00 00 02 07 00 03 07 01 4A 00 02 07 00 59 02 45 07 00 3B 40 07 01 4A 4B 07 01 4A FF 00 02 00 02 07 00 03 07 01 4A 00 02 07 01 4A 01 5D 07 01 4A FF 00 07 00 03 07 00 03 07 01 4A 07 01 4A 00 01 07 00 2F FF 00 00 00 03 07 00 03 07 01 4A 07 01 4A 00 02 08 02 69 08 02 69 45 07 00 3B 40 07 00 F1 43 07 00 3B FF 00 00 00 03 07 00 03 07 01 4A 07 01 4A 00 02 07 00 F1 07 01 4A 45 07 00 3B 40 07 00 F1 44 07 00 3B FF 00 00 00 03 07 00 03 07 01 4A 07 01 4A 00 02 07 00 F1 01 45 07 00 3B 40 07 00 F1 FF 00 0C 00 03 07 00 03 07 01 4A 07 01 4A 00 02 07 00 F1 07 01 4A FF 00 02 00 03 07 00 03 07 01 4A 07 01 4A 00 03 07 00 F1 07 01 4A 01 FF 00 1E 00 03 07 00 03 07 01 4A 07 01 4A 00 02 07 00 F1 07 01 4A 42 07 00 2F FF 00 00 00 03 07 00 03 07 01 4A 07 01 4A 00 02 07 00 F1 07 01 4A 45 07 00 3B 40 07 00 F1 FF 00 0D 00 03 07 00 03 07 01 4A 07 01 4A 00 02 07 00 F1 01 FF 00 02 00 03 07 00 03 07 01 4A 07 01 4A 00 03 07 00 F1 01 01 FF 00 1F 00 03 07 00 03 07 01 4A 07 01 4A 00 02 07 00 F1 01 42 07 00 2F FF 00 00 00 03 07 00 03 07 01 4A 07 01 4A 00 02 07 00 F1 01 45 07 00 3B 40 07 00 F1 FF 00 02 00 00 00 01 07 00 3B FF 00 00 00 03 07 00 03 07 01 4A 07 01 4A 00 01 07 00 F1 45 07 00 3B 40 07 01 4A FF 00 04 00 00 00 01 07 00 3B FF 00 00 00 04 07 00 03 07 01 4A 07 01 4A 07 01 4A 00 01 07 01 4A 45 07 00 3B 40 02 FF 00 0C 00 04 07 00 03 07 01 4A 07 01 4A 07 01 4A 00 02 02 07 00 03 FF 00 02 00 04 07 00 03 07 01 4A 07 01 4A 07 01 4A 00 03 02 07 00 03 01 FF 00 1C 00 04 07 00 03 07 01 4A 07 01 4A 07 01 4A 00 02 02 07 00 03 42 07 00 3B FF 00 00 00 04 07 00 03 07 01 4A 07 01 4A 07 01 4A 00 02 02 07 00 03 45 07 00 3B FF 00 00 00 04 07 00 03 07 01 4A 07 01 4A 07 01 4A 00 02 02 02 FF 00 01 00 02 07 00 03 07 01 4A 00 03 07 01 4A 08 00 A9 08 00 A9 FF 00 01 00 03 07 00 03 07 01 4A 07 01 4A 00 02 07 00 F1 07 01 4A FF 00 01 00 04 07 00 03 07 01 4A 07 01 4A 07 01 4A 00 02 02 07 00 03 F9 00 01 41 07 01 4A FF 00 01 00 02 07 00 03 07 01 4A 00 03 07 00 F1 07 00 F1 01 FF 00 01 00 02 07 00 03 07 01 4A 00 03 07 00 F1 07 00 F1 07 00 59 FF 00 01 00 01 07 00 03 00 01 07 01 4A FF 00 01 00 02 07 00 03 07 01 4A 00 01 07 00 03 FF 00 01 00 03 07 00 03 07 01 4A 07 01 4A 00 02 07 00 F1 01 FF 00 01 00 01 07 00 03 00 01 07 00 3B 43 05 44 07 00 3B 47 05 47 07 00 3B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     886    894    Any
        //  886    894    886    894    Any
        //  902    904    3      8      Any
        //  31     38     38     39     Any
        //  32     38     38     39     Ljava/lang/NegativeArraySizeException;
        //  31     38     38     39     Any
        //  31     38     3      8      Any
        //  31     38     31     32     Any
        //  44     51     51     52     Any
        //  45     51     3      8      Any
        //  44     51     3      8      Ljava/lang/IndexOutOfBoundsException;
        //  44     51     44     45     Any
        //  45     51     44     45     Ljava/lang/StringIndexOutOfBoundsException;
        //  59     66     66     67     Any
        //  60     66     3      8      Ljava/lang/EnumConstantNotPresentException;
        //  60     66     59     60     Any
        //  60     66     59     60     Ljava/lang/UnsupportedOperationException;
        //  60     66     3      8      Any
        //  120    127    127    128    Any
        //  121    127    3      8      Ljava/util/NoSuchElementException;
        //  121    127    3      8      Any
        //  121    127    120    121    Ljava/lang/ArithmeticException;
        //  120    127    3      8      Any
        //  223    230    230    231    Any
        //  223    230    230    231    Ljava/lang/ClassCastException;
        //  224    230    223    224    Any
        //  223    230    230    231    Ljava/lang/RuntimeException;
        //  224    230    223    224    Ljava/lang/IllegalArgumentException;
        //  235    242    242    243    Any
        //  236    242    3      8      Any
        //  236    242    242    243    Ljava/lang/UnsupportedOperationException;
        //  235    242    235    236    Any
        //  235    242    235    236    Any
        //  248    255    255    256    Any
        //  249    255    248    249    Ljava/lang/IllegalArgumentException;
        //  249    255    255    256    Any
        //  249    255    248    249    Any
        //  249    255    255    256    Ljava/lang/NegativeArraySizeException;
        //  263    270    270    271    Any
        //  264    270    3      8      Any
        //  263    270    270    271    Any
        //  264    270    3      8      Any
        //  263    270    263    264    Any
        //  277    284    284    285    Any
        //  277    284    3      8      Any
        //  278    284    284    285    Ljava/lang/NegativeArraySizeException;
        //  278    284    284    285    Any
        //  278    284    277    278    Ljava/lang/AssertionError;
        //  288    295    295    296    Any
        //  289    295    288    289    Ljava/lang/IndexOutOfBoundsException;
        //  288    295    3      8      Ljava/lang/AssertionError;
        //  289    295    295    296    Any
        //  288    295    3      8      Any
        //  347    354    354    355    Any
        //  348    354    354    355    Ljava/lang/NegativeArraySizeException;
        //  348    354    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  347    354    347    348    Any
        //  347    354    354    355    Ljava/lang/EnumConstantNotPresentException;
        //  407    414    414    415    Any
        //  408    414    3      8      Any
        //  408    414    3      8      Ljava/lang/NegativeArraySizeException;
        //  407    414    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  408    414    407    408    Ljava/lang/EnumConstantNotPresentException;
        //  418    425    425    426    Any
        //  419    425    3      8      Any
        //  418    425    425    426    Ljava/lang/ArithmeticException;
        //  419    425    3      8      Any
        //  418    425    418    419    Any
        //  433    440    440    441    Any
        //  433    440    433    434    Any
        //  433    440    3      8      Ljava/lang/IllegalStateException;
        //  433    440    3      8      Ljava/lang/RuntimeException;
        //  434    440    440    441    Ljava/lang/StringIndexOutOfBoundsException;
        //  444    451    451    452    Any
        //  444    451    444    445    Ljava/lang/ClassCastException;
        //  444    451    3      8      Any
        //  445    451    451    452    Ljava/lang/IllegalArgumentException;
        //  444    451    444    445    Any
        //  455    462    462    463    Any
        //  455    462    462    463    Any
        //  455    462    3      8      Any
        //  455    462    455    456    Ljava/util/NoSuchElementException;
        //  456    462    455    456    Ljava/lang/UnsupportedOperationException;
        //  563    570    570    571    Any
        //  563    570    3      8      Ljava/lang/IllegalArgumentException;
        //  563    570    3      8      Ljava/lang/AssertionError;
        //  563    570    563    564    Ljava/lang/IndexOutOfBoundsException;
        //  564    570    563    564    Ljava/lang/IndexOutOfBoundsException;
        //  624    631    631    632    Any
        //  624    631    624    625    Ljava/lang/ArithmeticException;
        //  624    631    624    625    Ljava/lang/StringIndexOutOfBoundsException;
        //  625    631    624    625    Ljava/lang/UnsupportedOperationException;
        //  624    631    3      8      Ljava/lang/IllegalStateException;
        //  636    643    643    644    Any
        //  637    643    636    637    Any
        //  636    643    643    644    Ljava/lang/IllegalStateException;
        //  637    643    636    637    Ljava/util/ConcurrentModificationException;
        //  637    643    636    637    Any
        //  649    656    656    657    Any
        //  650    656    3      8      Any
        //  649    656    649    650    Any
        //  649    656    3      8      Ljava/lang/UnsupportedOperationException;
        //  650    656    3      8      Any
        //  707    714    714    715    Any
        //  708    714    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  707    714    707    708    Ljava/lang/EnumConstantNotPresentException;
        //  707    714    707    708    Ljava/util/ConcurrentModificationException;
        //  708    714    707    708    Ljava/lang/ArithmeticException;
        //  767    774    774    775    Any
        //  767    774    774    775    Any
        //  768    774    767    768    Ljava/lang/UnsupportedOperationException;
        //  768    774    767    768    Ljava/lang/EnumConstantNotPresentException;
        //  768    774    774    775    Ljava/lang/ArithmeticException;
        //  779    785    785    786    Any
        //  779    785    3      8      Any
        //  779    785    785    786    Any
        //  779    785    3      8      Ljava/lang/RuntimeException;
        //  779    785    785    786    Ljava/lang/ClassCastException;
        //  792    798    798    799    Any
        //  792    798    798    799    Any
        //  792    798    798    799    Ljava/lang/RuntimeException;
        //  792    798    798    799    Any
        //  792    798    3      8      Any
        //  847    854    854    855    Any
        //  848    854    847    848    Any
        //  847    854    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  848    854    847    848    Any
        //  848    854    3      8      Ljava/lang/NegativeArraySizeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:414)
        //     at com.strobel.assembler.ir.Instruction.accept(Instruction.java:490)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:403)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public boolean 1() {
        return fez.h0(this, 2096953129);
    }
    
    public f5M(@NotNull final PotionEffect c) {
        super("", null, 2, null);
        this.c = c;
    }
    
    static {
        throw t;
    }
    
    public void c(@NotNull final PotionEffect c) {
        Object o = null;
        Block_0: {
            break Block_0;
        Label_0087:
            while (true) {
            Label_0070_Outer:
                do {
                    Label_0074: {
                        break Label_0074;
                    Label_0070:
                        while (true) {
                            try {
                                o = null;
                                if (fc.0 == 0) {
                                    continue Label_0087;
                                }
                                null;
                                Label_0060: {
                                    this.c = c;
                                }
                                return;
                                Label_0068:
                                throw null;
                                Label_0028:
                                int n = 1119693192;
                                while (true) {
                                    break Label_0031;
                                    Block_4: {
                                        break Block_4;
                                        continue Label_0070;
                                    }
                                    n = 1053190782;
                                    continue Label_0070_Outer;
                                }
                            }
                            // iftrue(Label_0028:, fc.1 != 0)
                            // switch([Lcom.strobel.decompiler.ast.Label;@429e142f, n ^ 0xDA37170A)
                            catch (IndexOutOfBoundsException ex) {
                                if (ex != null) {
                                    throw ex;
                                }
                                continue Label_0070;
                            }
                            break;
                        }
                    }
                    continue Label_0087;
                } while (o == null);
                break;
            }
        }
        throw (Throwable)o;
    }
}
