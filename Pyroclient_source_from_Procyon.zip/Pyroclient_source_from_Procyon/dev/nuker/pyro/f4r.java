// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import org.jetbrains.annotations.NotNull;
import net.minecraft.entity.Entity;

public class f4r
{
    @NotNull
    public Entity c;
    
    public void c(@NotNull final Entity entity) {
        fez.j8(this, 2044418080, entity);
    }
    
    public f4r(@NotNull final Entity c) {
        while (true) {
            int n = 0;
            Label_0013: {
                if (fc.0 <= 0) {
                    n = 2051561840;
                    break Label_0013;
                }
                n = -127286238;
            }
            switch (n ^ 0x5B678378) {
                case 556784136: {
                    continue;
                }
                case -1559345318: {
                    while (true) {
                        int n2 = 0;
                        Label_0059: {
                            if (fc.1 == 0) {
                                n2 = -683321448;
                                break Label_0059;
                            }
                            n2 = -1286500344;
                        }
                        switch (n2 ^ 0xC8538B9C) {
                            case 521591812: {
                                continue;
                            }
                            case 2063735700: {
                                while (true) {
                                    int n3 = 0;
                                    Label_0105: {
                                        if (fc.0 <= 0) {
                                            n3 = 387947376;
                                            break Label_0105;
                                        }
                                        n3 = -52582096;
                                    }
                                    switch (n3 ^ 0x3E19BA6) {
                                        case 352190678: {
                                            continue;
                                        }
                                        case -12832106: {
                                            this.c = c;
                                            return;
                                        }
                                        default: {
                                            throw null;
                                        }
                                    }
                                    break;
                                }
                                break;
                            }
                            default: {
                                throw null;
                            }
                        }
                        break;
                    }
                    break;
                }
                default: {
                    throw null;
                }
            }
            break;
        }
    }
    
    @NotNull
    public Entity c() {
        return fez.j7(this, 1777232729);
    }
    
    static {
        throw t;
    }
}
