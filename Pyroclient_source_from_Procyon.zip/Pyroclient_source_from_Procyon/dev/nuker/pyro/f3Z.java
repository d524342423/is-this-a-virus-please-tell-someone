// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import org.jetbrains.annotations.NotNull;

public class f3Z
{
    public static f3Z c;
    
    public void c(@NotNull final Object p0, @NotNull final DataOutputStream p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          663
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            655
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            647
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: getstatic       dev/nuker/pyro/fc.1:I
        //    27: ifne            35
        //    30: ldc             -427955362
        //    32: goto            37
        //    35: ldc             1679347500
        //    37: ldc             1765455839
        //    39: ixor           
        //    40: lookupswitch {
        //          -1891148671: 35
        //          220362995: 68
        //          default: 632
        //        }
        //    68: aload_1        
        //    69: pop            
        //    70: aload_2        
        //    71: pop            
        //    72: getstatic       dev/nuker/pyro/f3X.c:Ldev/nuker/pyro/f3T;
        //    75: goto            79
        //    78: athrow         
        //    79: invokevirtual   dev/nuker/pyro/f3T.c:()Ljava/util/List;
        //    82: goto            86
        //    85: athrow         
        //    86: astore          4
        //    88: iconst_0       
        //    89: istore          5
        //    91: iconst_0       
        //    92: istore          6
        //    94: getstatic       dev/nuker/pyro/fc.1:I
        //    97: ifne            105
        //   100: ldc             921835359
        //   102: goto            107
        //   105: ldc             411182692
        //   107: ldc             -1724401858
        //   109: ixor           
        //   110: lookupswitch {
        //          -2118807206: 136
        //          -1346002847: 105
        //          default: 634
        //        }
        //   136: aload           4
        //   138: goto            142
        //   141: athrow         
        //   142: invokeinterface java/util/List.iterator:()Ljava/util/Iterator;
        //   147: goto            151
        //   150: athrow         
        //   151: astore          7
        //   153: aload           7
        //   155: getstatic       dev/nuker/pyro/fc.0:I
        //   158: ifgt            166
        //   161: ldc             -1985641073
        //   163: goto            168
        //   166: ldc             -1404126260
        //   168: ldc             1079130983
        //   170: ixor           
        //   171: lookupswitch {
        //          -906510616: 166
        //          -333676373: 196
        //          default: 624
        //        }
        //   196: goto            200
        //   199: athrow         
        //   200: invokeinterface java/util/Iterator.hasNext:()Z
        //   205: goto            209
        //   208: athrow         
        //   209: ifeq            336
        //   212: getstatic       dev/nuker/pyro/fc.0:I
        //   215: ifgt            223
        //   218: ldc             1233771163
        //   220: goto            225
        //   223: ldc             1248477060
        //   225: ldc             -1951228313
        //   227: ixor           
        //   228: lookupswitch {
        //          -1042767389: 256
        //          -1036303108: 223
        //          default: 636
        //        }
        //   256: aload           7
        //   258: goto            262
        //   261: athrow         
        //   262: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   267: goto            271
        //   270: athrow         
        //   271: astore          8
        //   273: aload           8
        //   275: checkcast       Lkotlin/Pair;
        //   278: astore          9
        //   280: iconst_0       
        //   281: istore          10
        //   283: aload           9
        //   285: goto            289
        //   288: athrow         
        //   289: invokevirtual   kotlin/Pair.getFirst:()Ljava/lang/Object;
        //   292: goto            296
        //   295: athrow         
        //   296: checkcast       Ljava/lang/Class;
        //   299: aload_1        
        //   300: goto            304
        //   303: athrow         
        //   304: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //   307: goto            311
        //   310: athrow         
        //   311: goto            315
        //   314: athrow         
        //   315: invokestatic    kotlin/jvm/internal/Intrinsics.areEqual:(Ljava/lang/Object;Ljava/lang/Object;)Z
        //   318: goto            322
        //   321: athrow         
        //   322: ifeq            330
        //   325: iload           6
        //   327: goto            337
        //   330: iinc            6, 1
        //   333: goto            153
        //   336: iconst_m1      
        //   337: istore_3       
        //   338: iload_3        
        //   339: iconst_m1      
        //   340: if_icmpne       375
        //   343: new             Ljava/lang/IllegalArgumentException;
        //   346: dup            
        //   347: ldc             "\u3d07\ub24b\u8e72\uafb4\u60e2\u59c2\u7e44\u6933\uc0d6\ua409\u9b83\u1305\uc152\u730b\u9726\u4dd3\ub214"
        //   349: goto            353
        //   352: athrow         
        //   353: invokestatic    invokestatic   !!! ERROR
        //   356: goto            360
        //   359: athrow         
        //   360: goto            364
        //   363: athrow         
        //   364: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //   367: goto            371
        //   370: athrow         
        //   371: checkcast       Ljava/lang/Throwable;
        //   374: athrow         
        //   375: getstatic       dev/nuker/pyro/fc.0:I
        //   378: ifgt            386
        //   381: ldc             -1346842654
        //   383: goto            388
        //   386: ldc             169268866
        //   388: ldc             996686795
        //   390: ixor           
        //   391: lookupswitch {
        //          -1798245335: 626
        //          -1646680296: 386
        //          default: 416
        //        }
        //   416: aload_2        
        //   417: iload_3        
        //   418: goto            422
        //   421: athrow         
        //   422: invokevirtual   java/io/DataOutputStream.writeInt:(I)V
        //   425: goto            429
        //   428: athrow         
        //   429: getstatic       dev/nuker/pyro/fc.0:I
        //   432: ifgt            440
        //   435: ldc             -1720065384
        //   437: goto            442
        //   440: ldc             1493460689
        //   442: ldc             719601643
        //   444: ixor           
        //   445: lookupswitch {
        //          -1281499789: 440
        //          1944082746: 472
        //          default: 628
        //        }
        //   472: getstatic       dev/nuker/pyro/f3X.c:Ldev/nuker/pyro/f3T;
        //   475: goto            479
        //   478: athrow         
        //   479: invokevirtual   dev/nuker/pyro/f3T.c:()Ljava/util/List;
        //   482: goto            486
        //   485: athrow         
        //   486: iload_3        
        //   487: goto            491
        //   490: athrow         
        //   491: invokeinterface java/util/List.get:(I)Ljava/lang/Object;
        //   496: goto            500
        //   499: athrow         
        //   500: checkcast       Lkotlin/Pair;
        //   503: astore          4
        //   505: getstatic       dev/nuker/pyro/fc.0:I
        //   508: ifgt            516
        //   511: ldc             -188589810
        //   513: goto            518
        //   516: ldc             -464776656
        //   518: ldc             963350982
        //   520: ixor           
        //   521: lookupswitch {
        //          -844511032: 516
        //          -584612874: 548
        //          default: 630
        //        }
        //   548: aload           4
        //   550: goto            554
        //   553: athrow         
        //   554: invokevirtual   kotlin/Pair.getSecond:()Ljava/lang/Object;
        //   557: goto            561
        //   560: athrow         
        //   561: checkcast       Ldev/nuker/pyro/f3X;
        //   564: aload_1        
        //   565: aload_2        
        //   566: getstatic       dev/nuker/pyro/fc.0:I
        //   569: ifgt            577
        //   572: ldc             872110663
        //   574: goto            579
        //   577: ldc             -580721550
        //   579: ldc             1735122667
        //   581: ixor           
        //   582: lookupswitch {
        //          252583897: 577
        //          1418757292: 622
        //          default: 608
        //        }
        //   608: goto            612
        //   611: athrow         
        //   612: invokeinterface dev/nuker/pyro/f3X.c:(Ljava/lang/Object;Ljava/io/DataOutputStream;)V
        //   617: goto            621
        //   620: athrow         
        //   621: return         
        //   622: aconst_null    
        //   623: athrow         
        //   624: aconst_null    
        //   625: athrow         
        //   626: aconst_null    
        //   627: athrow         
        //   628: aconst_null    
        //   629: athrow         
        //   630: aconst_null    
        //   631: athrow         
        //   632: aconst_null    
        //   633: athrow         
        //   634: aconst_null    
        //   635: athrow         
        //   636: aconst_null    
        //   637: athrow         
        //   638: pop            
        //   639: goto            24
        //   642: pop            
        //   643: aconst_null    
        //   644: goto            638
        //   647: dup            
        //   648: ifnull          638
        //   651: checkcast       Ljava/lang/Throwable;
        //   654: athrow         
        //   655: dup            
        //   656: ifnull          642
        //   659: checkcast       Ljava/lang/Throwable;
        //   662: athrow         
        //   663: aconst_null    
        //   664: athrow         
        //    StackMapTable: 00 66 43 07 00 2A 04 FF 00 0B 00 00 00 01 07 00 2A FE 00 03 07 00 03 07 00 05 07 00 77 0A 41 01 1E FF 00 09 00 00 00 01 07 00 2A FF 00 00 00 03 07 00 03 07 00 05 07 00 77 00 01 07 00 37 45 07 00 2A 40 07 00 3F FF 00 12 00 07 07 00 03 07 00 05 07 00 77 00 07 00 3F 01 01 00 00 41 01 1C 44 07 00 2A 40 07 00 3F 47 07 00 2A 40 07 00 4B FC 00 01 07 00 4B 4C 07 00 4B FF 00 01 00 08 07 00 03 07 00 05 07 00 77 00 07 00 3F 01 01 07 00 4B 00 02 07 00 4B 01 5B 07 00 4B 42 07 00 17 40 07 00 4B 47 07 00 2A 40 01 0D 41 01 1E 44 07 00 2A 40 07 00 4B 47 07 00 2A 40 07 00 05 FF 00 10 00 0B 07 00 03 07 00 05 07 00 77 00 07 00 3F 01 01 07 00 4B 07 00 05 07 00 58 01 00 01 07 00 2A 40 07 00 58 45 07 00 2A 40 07 00 05 46 07 00 2A FF 00 00 00 0B 07 00 03 07 00 05 07 00 77 00 07 00 3F 01 01 07 00 4B 07 00 05 07 00 58 01 00 02 07 00 5D 07 00 05 45 07 00 2A FF 00 00 00 0B 07 00 03 07 00 05 07 00 77 00 07 00 3F 01 01 07 00 4B 07 00 05 07 00 58 01 00 02 07 00 5D 07 00 5D FF 00 02 00 00 00 01 07 00 2A FF 00 00 00 0B 07 00 03 07 00 05 07 00 77 00 07 00 3F 01 01 07 00 4B 07 00 05 07 00 58 01 00 02 07 00 5D 07 00 5D 45 07 00 2A 40 01 07 F8 00 05 40 01 FF 00 0E 00 08 07 00 03 07 00 05 07 00 77 01 07 00 3F 01 01 07 00 4B 00 01 07 00 2A FF 00 00 00 08 07 00 03 07 00 05 07 00 77 01 07 00 3F 01 01 07 00 4B 00 03 08 01 57 08 01 57 07 00 8F 45 07 00 2A FF 00 00 00 08 07 00 03 07 00 05 07 00 77 01 07 00 3F 01 01 07 00 4B 00 03 08 01 57 08 01 57 07 00 8F 42 07 00 2A FF 00 00 00 08 07 00 03 07 00 05 07 00 77 01 07 00 3F 01 01 07 00 4B 00 03 08 01 57 08 01 57 07 00 8F 45 07 00 2A 40 07 00 19 03 0A 41 01 1B 44 07 00 2A FF 00 00 00 08 07 00 03 07 00 05 07 00 77 01 07 00 3F 01 01 07 00 4B 00 02 07 00 77 01 45 07 00 2A 00 0A 41 01 1D 45 07 00 11 40 07 00 37 45 07 00 2A 40 07 00 3F FF 00 03 00 00 00 01 07 00 2A FF 00 00 00 08 07 00 03 07 00 05 07 00 77 01 07 00 3F 01 01 07 00 4B 00 02 07 00 3F 01 47 07 00 2A 40 07 00 05 FF 00 0F 00 08 07 00 03 07 00 05 07 00 77 01 07 00 58 01 01 07 00 4B 00 00 41 01 1D 44 07 00 2A 40 07 00 58 45 07 00 2A 40 07 00 05 FF 00 0F 00 08 07 00 03 07 00 05 07 00 77 01 07 00 58 01 01 07 00 4B 00 03 07 00 32 07 00 05 07 00 77 FF 00 01 00 08 07 00 03 07 00 05 07 00 77 01 07 00 58 01 01 07 00 4B 00 04 07 00 32 07 00 05 07 00 77 01 FF 00 1C 00 08 07 00 03 07 00 05 07 00 77 01 07 00 58 01 01 07 00 4B 00 03 07 00 32 07 00 05 07 00 77 42 07 00 2A FF 00 00 00 08 07 00 03 07 00 05 07 00 77 01 07 00 58 01 01 07 00 4B 00 03 07 00 32 07 00 05 07 00 77 47 07 00 2A 00 FF 00 00 00 08 07 00 03 07 00 05 07 00 77 01 07 00 58 01 01 07 00 4B 00 03 07 00 32 07 00 05 07 00 77 FF 00 01 00 08 07 00 03 07 00 05 07 00 77 00 07 00 3F 01 01 07 00 4B 00 01 07 00 4B FF 00 01 00 08 07 00 03 07 00 05 07 00 77 01 07 00 3F 01 01 07 00 4B 00 00 01 FF 00 01 00 08 07 00 03 07 00 05 07 00 77 01 07 00 58 01 01 07 00 4B 00 00 FF 00 01 00 03 07 00 03 07 00 05 07 00 77 00 00 FF 00 01 00 07 07 00 03 07 00 05 07 00 77 00 07 00 3F 01 01 00 00 FC 00 01 07 00 4B FF 00 01 00 03 07 00 03 07 00 05 07 00 77 00 01 07 00 2A 43 05 44 07 00 2A 47 05 47 07 00 2A
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     647    655    Ljava/lang/AssertionError;
        //  647    655    647    655    Any
        //  663    665    3      8      Any
        //  79     85     85     86     Any
        //  79     85     3      8      Ljava/lang/EnumConstantNotPresentException;
        //  79     85     85     86     Any
        //  79     85     3      8      Any
        //  79     85     85     86     Any
        //  141    150    150    151    Any
        //  141    150    141    142    Ljava/lang/UnsupportedOperationException;
        //  142    150    141    142    Any
        //  141    150    141    142    Ljava/lang/RuntimeException;
        //  141    150    141    142    Ljava/lang/IllegalStateException;
        //  199    208    208    209    Any
        //  199    208    3      8      Ljava/lang/AssertionError;
        //  199    208    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  199    208    199    200    Ljava/util/ConcurrentModificationException;
        //  199    208    208    209    Any
        //  261    270    270    271    Any
        //  261    270    261    262    Any
        //  261    270    261    262    Ljava/util/ConcurrentModificationException;
        //  262    270    261    262    Ljava/lang/IllegalArgumentException;
        //  261    270    3      8      Any
        //  288    295    295    296    Any
        //  289    295    288    289    Ljava/util/ConcurrentModificationException;
        //  288    295    295    296    Any
        //  288    295    295    296    Any
        //  288    295    288    289    Any
        //  303    310    310    311    Any
        //  303    310    310    311    Ljava/lang/ClassCastException;
        //  304    310    3      8      Ljava/lang/NullPointerException;
        //  303    310    303    304    Any
        //  303    310    310    311    Ljava/lang/NumberFormatException;
        //  315    321    321    322    Any
        //  315    321    321    322    Ljava/lang/NegativeArraySizeException;
        //  315    321    3      8      Ljava/lang/IllegalArgumentException;
        //  315    321    321    322    Any
        //  315    321    3      8      Any
        //  352    359    359    360    Any
        //  352    359    3      8      Any
        //  352    359    352    353    Ljava/lang/IndexOutOfBoundsException;
        //  352    359    359    360    Ljava/lang/NullPointerException;
        //  352    359    352    353    Any
        //  363    370    370    371    Any
        //  363    370    363    364    Any
        //  363    370    363    364    Any
        //  364    370    370    371    Ljava/lang/EnumConstantNotPresentException;
        //  364    370    370    371    Any
        //  421    428    428    429    Any
        //  422    428    3      8      Any
        //  422    428    428    429    Any
        //  421    428    421    422    Any
        //  421    428    428    429    Ljava/lang/NegativeArraySizeException;
        //  478    485    485    486    Any
        //  478    485    485    486    Ljava/lang/NullPointerException;
        //  478    485    478    479    Ljava/lang/NumberFormatException;
        //  478    485    478    479    Ljava/lang/NullPointerException;
        //  479    485    485    486    Ljava/lang/NegativeArraySizeException;
        //  491    499    499    500    Any
        //  491    499    499    500    Ljava/util/ConcurrentModificationException;
        //  491    499    499    500    Ljava/lang/ClassCastException;
        //  491    499    3      8      Any
        //  491    499    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  553    560    560    561    Any
        //  554    560    553    554    Ljava/lang/NullPointerException;
        //  554    560    553    554    Any
        //  553    560    3      8      Ljava/lang/IllegalArgumentException;
        //  553    560    560    561    Any
        //  611    620    620    621    Any
        //  612    620    3      8      Any
        //  611    620    611    612    Any
        //  612    620    3      8      Any
        //  611    620    3      8      Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:595)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @NotNull
    public Object c(@NotNull final DataInputStream dataInputStream) {
        return fez.aj(this, 567421647, dataInputStream);
    }
    
    @NotNull
    public f3Y c(@NotNull final DataInputStream p0, @NotNull final f4c p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          658
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            650
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            642
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: aload_2        
        //    27: pop            
        //    28: getstatic       dev/nuker/pyro/fc.1:I
        //    31: ifne            39
        //    34: ldc             1543417292
        //    36: goto            41
        //    39: ldc             -85515852
        //    41: ldc             -1985927676
        //    43: ixor           
        //    44: lookupswitch {
        //          -765490232: 39
        //          1933969328: 72
        //          default: 621
        //        }
        //    72: aload_1        
        //    73: goto            77
        //    76: athrow         
        //    77: invokevirtual   java/io/DataInputStream.readInt:()I
        //    80: goto            84
        //    83: athrow         
        //    84: istore_3       
        //    85: aload_2        
        //    86: iload_3        
        //    87: getstatic       dev/nuker/pyro/fc.1:I
        //    90: ifne            98
        //    93: ldc             1716822846
        //    95: goto            100
        //    98: ldc             -84366987
        //   100: ldc             -1677773303
        //   102: ixor           
        //   103: lookupswitch {
        //          -39086793: 98
        //          1627889532: 128
        //          default: 613
        //        }
        //   128: goto            132
        //   131: athrow         
        //   132: invokevirtual   dev/nuker/pyro/f4c.c:(I)Ldev/nuker/pyro/f3Y;
        //   135: goto            139
        //   138: athrow         
        //   139: astore          4
        //   141: aload_1        
        //   142: getstatic       dev/nuker/pyro/fc.1:I
        //   145: ifne            153
        //   148: ldc             1052074811
        //   150: goto            155
        //   153: ldc             -184576655
        //   155: ldc             1438306795
        //   157: ixor           
        //   158: lookupswitch {
        //          -1238358040: 153
        //          1796190928: 623
        //          default: 184
        //        }
        //   184: goto            188
        //   187: athrow         
        //   188: invokevirtual   java/io/DataInputStream.readInt:()I
        //   191: goto            195
        //   194: athrow         
        //   195: getstatic       dev/nuker/pyro/fc.1:I
        //   198: ifne            206
        //   201: ldc             -1288520664
        //   203: goto            208
        //   206: ldc             -661434576
        //   208: ldc             1287761437
        //   210: ixor           
        //   211: lookupswitch {
        //          -1806507731: 236
        //          -847307: 206
        //          default: 617
        //        }
        //   236: istore          5
        //   238: iconst_0       
        //   239: getstatic       dev/nuker/pyro/fc.c:I
        //   242: ifne            250
        //   245: ldc             386345925
        //   247: goto            252
        //   250: ldc             92997551
        //   252: ldc             -936068147
        //   254: ixor           
        //   255: lookupswitch {
        //          -550268920: 615
        //          -37212256: 250
        //          default: 280
        //        }
        //   280: istore          7
        //   282: new             Ljava/util/ArrayList;
        //   285: dup            
        //   286: goto            290
        //   289: athrow         
        //   290: invokespecial   java/util/ArrayList.<init>:()V
        //   293: goto            297
        //   296: athrow         
        //   297: checkcast       Ljava/util/List;
        //   300: astore          6
        //   302: iconst_0       
        //   303: getstatic       dev/nuker/pyro/fc.c:I
        //   306: ifne            314
        //   309: ldc             1211994301
        //   311: goto            316
        //   314: ldc             -1101671419
        //   316: ldc             1376163492
        //   318: ixor           
        //   319: lookupswitch {
        //          -330087775: 344
        //          440075801: 314
        //          default: 625
        //        }
        //   344: istore          7
        //   346: iload           5
        //   348: getstatic       dev/nuker/pyro/fc.1:I
        //   351: ifne            359
        //   354: ldc             432566949
        //   356: goto            361
        //   359: ldc             65187313
        //   361: ldc             -1379810249
        //   363: ixor           
        //   364: lookupswitch {
        //          -1274431854: 631
        //          1732299901: 359
        //          default: 392
        //        }
        //   392: istore          8
        //   394: iload           7
        //   396: getstatic       dev/nuker/pyro/fc.c:I
        //   399: ifne            407
        //   402: ldc             1041003500
        //   404: goto            409
        //   407: ldc             814241074
        //   409: ldc             -35019133
        //   411: ixor           
        //   412: lookupswitch {
        //          -1008347793: 619
        //          1477239071: 407
        //          default: 440
        //        }
        //   440: iload           8
        //   442: if_icmpge       450
        //   445: ldc             -598443454
        //   447: goto            452
        //   450: ldc             -598443453
        //   452: ldc             201231276
        //   454: ixor           
        //   455: tableswitch {
        //          -1353325604: 476
        //          -1353325603: 595
        //          default: 445
        //        }
        //   476: aload           6
        //   478: aload_0        
        //   479: getstatic       dev/nuker/pyro/fc.1:I
        //   482: ifne            490
        //   485: ldc             -1945170462
        //   487: goto            492
        //   490: ldc             -810281173
        //   492: ldc             -1252665110
        //   494: ixor           
        //   495: lookupswitch {
        //          962254088: 490
        //          2061619137: 520
        //          default: 627
        //        }
        //   520: aload_1        
        //   521: getstatic       dev/nuker/pyro/fc.0:I
        //   524: ifgt            532
        //   527: ldc             -1068585814
        //   529: goto            534
        //   532: ldc             -1810095314
        //   534: ldc             1526041267
        //   536: ixor           
        //   537: lookupswitch {
        //          -1699011047: 629
        //          1969607568: 532
        //          default: 564
        //        }
        //   564: goto            568
        //   567: athrow         
        //   568: invokevirtual   dev/nuker/pyro/f3Z.c:(Ljava/io/DataInputStream;)Ljava/lang/Object;
        //   571: goto            575
        //   574: athrow         
        //   575: goto            579
        //   578: athrow         
        //   579: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //   584: goto            588
        //   587: athrow         
        //   588: pop            
        //   589: iinc            7, 1
        //   592: goto            394
        //   595: aload           4
        //   597: aload           6
        //   599: goto            603
        //   602: athrow         
        //   603: invokevirtual   dev/nuker/pyro/f3Y.c:(Ljava/util/List;)V
        //   606: goto            610
        //   609: athrow         
        //   610: aload           4
        //   612: areturn        
        //   613: aconst_null    
        //   614: athrow         
        //   615: aconst_null    
        //   616: athrow         
        //   617: aconst_null    
        //   618: athrow         
        //   619: aconst_null    
        //   620: athrow         
        //   621: aconst_null    
        //   622: athrow         
        //   623: aconst_null    
        //   624: athrow         
        //   625: aconst_null    
        //   626: athrow         
        //   627: aconst_null    
        //   628: athrow         
        //   629: aconst_null    
        //   630: athrow         
        //   631: aconst_null    
        //   632: athrow         
        //   633: pop            
        //   634: goto            24
        //   637: pop            
        //   638: aconst_null    
        //   639: goto            633
        //   642: dup            
        //   643: ifnull          633
        //   646: checkcast       Ljava/lang/Throwable;
        //   649: athrow         
        //   650: dup            
        //   651: ifnull          637
        //   654: checkcast       Ljava/lang/Throwable;
        //   657: athrow         
        //   658: aconst_null    
        //   659: athrow         
        //    StackMapTable: 00 53 43 07 00 2A 04 FF 00 0B 00 00 00 01 07 00 2A FE 00 03 07 00 03 07 00 9F 07 00 A8 0E 41 01 1E 43 07 00 2A 40 07 00 9F 45 07 00 2A 40 01 FF 00 0D 00 04 07 00 03 07 00 9F 07 00 A8 01 00 02 07 00 A8 01 FF 00 01 00 04 07 00 03 07 00 9F 07 00 A8 01 00 03 07 00 A8 01 01 FF 00 1B 00 04 07 00 03 07 00 9F 07 00 A8 01 00 02 07 00 A8 01 42 07 00 2A FF 00 00 00 04 07 00 03 07 00 9F 07 00 A8 01 00 02 07 00 A8 01 45 07 00 2A 40 07 00 D3 FF 00 0D 00 05 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 00 01 07 00 9F FF 00 01 00 05 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 00 02 07 00 9F 01 5C 07 00 9F 42 07 00 2A 40 07 00 9F 45 07 00 2A 40 01 4A 01 FF 00 01 00 05 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 00 02 01 01 5B 01 FF 00 0D 00 06 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 00 01 01 FF 00 01 00 06 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 00 02 01 01 5B 01 FF 00 08 00 08 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 00 01 00 01 07 00 15 FF 00 00 00 08 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 00 01 00 02 08 01 1A 08 01 1A 45 07 00 2A 40 07 00 B6 FF 00 10 00 08 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 07 00 3F 01 00 01 01 FF 00 01 00 08 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 07 00 3F 01 00 02 01 01 5B 01 4E 01 FF 00 01 00 08 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 07 00 3F 01 00 02 01 01 5E 01 FC 00 01 01 4C 01 FF 00 01 00 09 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 07 00 3F 01 01 00 02 01 01 5E 01 04 04 41 01 17 FF 00 0D 00 09 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 07 00 3F 01 01 00 02 07 00 3F 07 00 03 FF 00 01 00 09 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 07 00 3F 01 01 00 03 07 00 3F 07 00 03 01 FF 00 1B 00 09 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 07 00 3F 01 01 00 02 07 00 3F 07 00 03 FF 00 0B 00 09 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 07 00 3F 01 01 00 03 07 00 3F 07 00 03 07 00 9F FF 00 01 00 09 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 07 00 3F 01 01 00 04 07 00 3F 07 00 03 07 00 9F 01 FF 00 1D 00 09 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 07 00 3F 01 01 00 03 07 00 3F 07 00 03 07 00 9F 42 07 00 2A FF 00 00 00 09 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 07 00 3F 01 01 00 03 07 00 3F 07 00 03 07 00 9F 45 07 00 2A FF 00 00 00 09 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 07 00 3F 01 01 00 02 07 00 3F 07 00 05 42 07 00 13 FF 00 00 00 09 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 07 00 3F 01 01 00 02 07 00 3F 07 00 05 47 07 00 2A 40 01 06 46 07 00 13 FF 00 00 00 09 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 07 00 3F 01 01 00 02 07 00 D3 07 00 3F 45 07 00 2A 00 FF 00 02 00 04 07 00 03 07 00 9F 07 00 A8 01 00 02 07 00 A8 01 FF 00 01 00 06 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 00 01 01 FF 00 01 00 05 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 00 01 01 FF 00 01 00 09 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 07 00 3F 01 01 00 01 01 FF 00 01 00 03 07 00 03 07 00 9F 07 00 A8 00 00 FF 00 01 00 05 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 00 01 07 00 9F FF 00 01 00 08 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 07 00 3F 01 00 01 01 FF 00 01 00 09 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 07 00 3F 01 01 00 02 07 00 3F 07 00 03 FF 00 01 00 09 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 07 00 3F 01 01 00 03 07 00 3F 07 00 03 07 00 9F FF 00 01 00 08 07 00 03 07 00 9F 07 00 A8 01 07 00 D3 01 07 00 3F 01 00 01 01 FF 00 01 00 03 07 00 03 07 00 9F 07 00 A8 00 01 07 00 2A 43 05 44 07 00 2A 47 05 47 07 00 2A
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     642    650    Any
        //  642    650    642    650    Any
        //  658    660    3      8      Any
        //  76     83     83     84     Any
        //  77     83     83     84     Any
        //  76     83     3      8      Ljava/lang/AssertionError;
        //  77     83     3      8      Any
        //  77     83     76     77     Any
        //  131    138    138    139    Any
        //  132    138    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  131    138    131    132    Any
        //  131    138    131    132    Any
        //  132    138    3      8      Ljava/lang/NullPointerException;
        //  187    194    194    195    Any
        //  188    194    187    188    Any
        //  187    194    187    188    Any
        //  187    194    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  187    194    194    195    Any
        //  289    296    296    297    Any
        //  289    296    296    297    Ljava/lang/EnumConstantNotPresentException;
        //  289    296    296    297    Ljava/lang/EnumConstantNotPresentException;
        //  289    296    3      8      Any
        //  290    296    289    290    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  567    574    574    575    Any
        //  568    574    567    568    Any
        //  567    574    574    575    Ljava/lang/RuntimeException;
        //  567    574    574    575    Ljava/lang/EnumConstantNotPresentException;
        //  568    574    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  578    587    587    588    Any
        //  578    587    587    588    Any
        //  579    587    587    588    Any
        //  579    587    578    579    Ljava/lang/IllegalStateException;
        //  578    587    3      8      Ljava/lang/NumberFormatException;
        //  602    609    609    610    Any
        //  602    609    609    610    Ljava/lang/UnsupportedOperationException;
        //  603    609    609    610    Ljava/lang/ClassCastException;
        //  602    609    3      8      Any
        //  603    609    602    603    Ljava/lang/IllegalStateException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:595)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void c(@NotNull final f3Y p0, @NotNull final f4c p1, @NotNull final DataOutputStream p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          907
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            899
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            891
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: aload_2        
        //    27: pop            
        //    28: aload_3        
        //    29: pop            
        //    30: aload_2        
        //    31: goto            35
        //    34: athrow         
        //    35: invokevirtual   dev/nuker/pyro/f4c.c:()Ljava/util/List;
        //    38: goto            42
        //    41: athrow         
        //    42: aload_1        
        //    43: goto            47
        //    46: athrow         
        //    47: invokevirtual   java/lang/Object.getClass:()Ljava/lang/Class;
        //    50: goto            54
        //    53: athrow         
        //    54: goto            58
        //    57: athrow         
        //    58: invokeinterface java/util/List.indexOf:(Ljava/lang/Object;)I
        //    63: goto            67
        //    66: athrow         
        //    67: getstatic       dev/nuker/pyro/fc.1:I
        //    70: ifne            78
        //    73: ldc             1117549355
        //    75: goto            80
        //    78: ldc             2141369173
        //    80: ldc             2106756927
        //    82: ixor           
        //    83: lookupswitch {
        //          36715626: 108
        //          1057946644: 78
        //          default: 864
        //        }
        //   108: istore          4
        //   110: getstatic       dev/nuker/pyro/fc.0:I
        //   113: ifgt            121
        //   116: ldc             1608473642
        //   118: goto            123
        //   121: ldc             -357624441
        //   123: ldc             -740771888
        //   125: ixor           
        //   126: lookupswitch {
        //          -1945637894: 866
        //          1407322038: 121
        //          default: 152
        //        }
        //   152: iload           4
        //   154: iconst_m1      
        //   155: if_icmpne       190
        //   158: new             Ljava/lang/IllegalArgumentException;
        //   161: dup            
        //   162: ldc             "\u3d07\ub24b\u8e72\uafb4\u60e2\u59c2\u7e44\u6933\uc0c2\ua409\u9b94\u130f\uc117\u730b"
        //   164: goto            168
        //   167: athrow         
        //   168: invokestatic    invokestatic   !!! ERROR
        //   171: goto            175
        //   174: athrow         
        //   175: goto            179
        //   178: athrow         
        //   179: invokespecial   java/lang/IllegalArgumentException.<init>:(Ljava/lang/String;)V
        //   182: goto            186
        //   185: athrow         
        //   186: checkcast       Ljava/lang/Throwable;
        //   189: athrow         
        //   190: aload_3        
        //   191: getstatic       dev/nuker/pyro/fc.c:I
        //   194: ifne            202
        //   197: ldc             1105800785
        //   199: goto            204
        //   202: ldc             -1461113106
        //   204: ldc             733021764
        //   206: ixor           
        //   207: lookupswitch {
        //          -2091374422: 232
        //          1784162325: 202
        //          default: 870
        //        }
        //   232: iload           4
        //   234: goto            238
        //   237: athrow         
        //   238: invokevirtual   java/io/DataOutputStream.writeInt:(I)V
        //   241: goto            245
        //   244: athrow         
        //   245: aload_1        
        //   246: goto            250
        //   249: athrow         
        //   250: invokevirtual   dev/nuker/pyro/f3Y.c:()Ljava/util/List;
        //   253: goto            257
        //   256: athrow         
        //   257: astore          5
        //   259: getstatic       dev/nuker/pyro/fc.1:I
        //   262: ifne            270
        //   265: ldc             1585171524
        //   267: goto            272
        //   270: ldc             1307183937
        //   272: ldc             -1412507083
        //   274: ixor           
        //   275: lookupswitch {
        //          -433794700: 300
        //          -172681615: 270
        //          default: 862
        //        }
        //   300: aload_3        
        //   301: getstatic       dev/nuker/pyro/fc.0:I
        //   304: ifgt            312
        //   307: ldc             -120167345
        //   309: goto            314
        //   312: ldc             366271066
        //   314: ldc             -1286519952
        //   316: ixor           
        //   317: lookupswitch {
        //          -1501193942: 344
        //          1267148607: 312
        //          default: 878
        //        }
        //   344: aload           5
        //   346: goto            350
        //   349: athrow         
        //   350: invokeinterface java/util/List.size:()I
        //   355: goto            359
        //   358: athrow         
        //   359: goto            363
        //   362: athrow         
        //   363: invokevirtual   java/io/DataOutputStream.writeInt:(I)V
        //   366: goto            370
        //   369: athrow         
        //   370: getstatic       dev/nuker/pyro/fc.c:I
        //   373: ifne            381
        //   376: ldc             -784703058
        //   378: goto            383
        //   381: ldc             -44188153
        //   383: ldc             -1801518067
        //   385: ixor           
        //   386: lookupswitch {
        //          1168467363: 381
        //          1774369290: 412
        //          default: 860
        //        }
        //   412: aload           5
        //   414: checkcast       Ljava/lang/Iterable;
        //   417: astore          6
        //   419: iconst_0       
        //   420: istore          7
        //   422: aload           6
        //   424: getstatic       dev/nuker/pyro/fc.1:I
        //   427: ifne            435
        //   430: ldc             -559367178
        //   432: goto            437
        //   435: ldc             1074836418
        //   437: ldc             1246699504
        //   439: ixor           
        //   440: lookupswitch {
        //          -1796758522: 435
        //          174042162: 468
        //          default: 856
        //        }
        //   468: goto            472
        //   471: athrow         
        //   472: invokeinterface java/lang/Iterable.iterator:()Ljava/util/Iterator;
        //   477: goto            481
        //   480: athrow         
        //   481: astore          8
        //   483: aload           8
        //   485: getstatic       dev/nuker/pyro/fc.1:I
        //   488: ifne            496
        //   491: ldc             -238190937
        //   493: goto            499
        //   496: ldc_w           -2124045214
        //   499: ldc_w           -1155979835
        //   502: ixor           
        //   503: lookupswitch {
        //          -1291441993: 496
        //          1255431010: 880
        //          default: 528
        //        }
        //   528: goto            532
        //   531: athrow         
        //   532: invokeinterface java/util/Iterator.hasNext:()Z
        //   537: goto            541
        //   540: athrow         
        //   541: ifeq            550
        //   544: ldc_w           1907812212
        //   547: goto            553
        //   550: ldc_w           1907812213
        //   553: ldc_w           -128680514
        //   556: ixor           
        //   557: tableswitch {
        //          331691412: 580
        //          331691413: 854
        //          default: 544
        //        }
        //   580: aload           8
        //   582: goto            586
        //   585: athrow         
        //   586: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   591: goto            595
        //   594: athrow         
        //   595: astore          9
        //   597: getstatic       dev/nuker/pyro/fc.0:I
        //   600: ifgt            609
        //   603: ldc_w           -1148804924
        //   606: goto            612
        //   609: ldc_w           949325622
        //   612: ldc_w           1744649496
        //   615: ixor           
        //   616: lookupswitch {
        //          -595878436: 609
        //          1600696878: 644
        //          default: 858
        //        }
        //   644: aload           9
        //   646: getstatic       dev/nuker/pyro/fc.1:I
        //   649: ifne            658
        //   652: ldc_w           1544225119
        //   655: goto            661
        //   658: ldc_w           -1035121534
        //   661: ldc_w           -948078858
        //   664: ixor           
        //   665: lookupswitch {
        //          -1686734935: 658
        //          87046772: 692
        //          default: 876
        //        }
        //   692: astore          10
        //   694: iconst_0       
        //   695: getstatic       dev/nuker/pyro/fc.0:I
        //   698: ifgt            707
        //   701: ldc_w           827104185
        //   704: goto            710
        //   707: ldc_w           1977024214
        //   710: ldc_w           -1018635361
        //   713: ixor           
        //   714: lookupswitch {
        //          -1231149751: 740
        //          -234602458: 707
        //          default: 874
        //        }
        //   740: istore          11
        //   742: getstatic       dev/nuker/pyro/fc.1:I
        //   745: ifne            754
        //   748: ldc_w           502392784
        //   751: goto            757
        //   754: ldc_w           -213252121
        //   757: ldc_w           1713548279
        //   760: ixor           
        //   761: lookupswitch {
        //          -1409464896: 754
        //          2077445159: 868
        //          default: 788
        //        }
        //   788: getstatic       dev/nuker/pyro/f3Z.c:Ldev/nuker/pyro/f3Z;
        //   791: getstatic       dev/nuker/pyro/fc.0:I
        //   794: ifgt            803
        //   797: ldc_w           156923864
        //   800: goto            806
        //   803: ldc_w           409190269
        //   806: ldc_w           -79667648
        //   809: ixor           
        //   810: lookupswitch {
        //          -787580595: 803
        //          -233166440: 872
        //          default: 836
        //        }
        //   836: aload           10
        //   838: aload_3        
        //   839: goto            843
        //   842: athrow         
        //   843: invokevirtual   dev/nuker/pyro/f3Z.c:(Ljava/lang/Object;Ljava/io/DataOutputStream;)V
        //   846: goto            850
        //   849: athrow         
        //   850: nop            
        //   851: goto            483
        //   854: nop            
        //   855: return         
        //   856: aconst_null    
        //   857: athrow         
        //   858: aconst_null    
        //   859: athrow         
        //   860: aconst_null    
        //   861: athrow         
        //   862: aconst_null    
        //   863: athrow         
        //   864: aconst_null    
        //   865: athrow         
        //   866: aconst_null    
        //   867: athrow         
        //   868: aconst_null    
        //   869: athrow         
        //   870: aconst_null    
        //   871: athrow         
        //   872: aconst_null    
        //   873: athrow         
        //   874: aconst_null    
        //   875: athrow         
        //   876: aconst_null    
        //   877: athrow         
        //   878: aconst_null    
        //   879: athrow         
        //   880: aconst_null    
        //   881: athrow         
        //   882: pop            
        //   883: goto            24
        //   886: pop            
        //   887: aconst_null    
        //   888: goto            882
        //   891: dup            
        //   892: ifnull          882
        //   895: checkcast       Ljava/lang/Throwable;
        //   898: athrow         
        //   899: dup            
        //   900: ifnull          886
        //   903: checkcast       Ljava/lang/Throwable;
        //   906: athrow         
        //   907: aconst_null    
        //   908: athrow         
        //    StackMapTable: 00 78 43 07 00 2A 04 FF 00 0B 00 00 00 01 07 00 2A FF 00 03 00 04 07 00 03 07 00 D3 07 00 A8 07 00 77 00 00 49 07 00 11 40 07 00 A8 45 07 00 2A 40 07 00 3F 43 07 00 11 FF 00 00 00 04 07 00 03 07 00 D3 07 00 A8 07 00 77 00 02 07 00 3F 07 00 D3 45 07 00 2A FF 00 00 00 04 07 00 03 07 00 D3 07 00 A8 07 00 77 00 02 07 00 3F 07 00 5D 42 07 00 1F FF 00 00 00 04 07 00 03 07 00 D3 07 00 A8 07 00 77 00 02 07 00 3F 07 00 5D 47 07 00 2A 40 01 4A 01 FF 00 01 00 04 07 00 03 07 00 D3 07 00 A8 07 00 77 00 02 01 01 5B 01 FC 00 0C 01 41 01 1C 4E 07 00 2A FF 00 00 00 05 07 00 03 07 00 D3 07 00 A8 07 00 77 01 00 03 08 00 9E 08 00 9E 07 00 8F 45 07 00 2A FF 00 00 00 05 07 00 03 07 00 D3 07 00 A8 07 00 77 01 00 03 08 00 9E 08 00 9E 07 00 8F 42 07 00 11 FF 00 00 00 05 07 00 03 07 00 D3 07 00 A8 07 00 77 01 00 03 08 00 9E 08 00 9E 07 00 8F 45 07 00 2A 40 07 00 19 03 4B 07 00 77 FF 00 01 00 05 07 00 03 07 00 D3 07 00 A8 07 00 77 01 00 02 07 00 77 01 5B 07 00 77 44 07 00 2A FF 00 00 00 05 07 00 03 07 00 D3 07 00 A8 07 00 77 01 00 02 07 00 77 01 45 07 00 2A 00 FF 00 03 00 00 00 01 07 00 2A FF 00 00 00 05 07 00 03 07 00 D3 07 00 A8 07 00 77 01 00 01 07 00 D3 45 07 00 2A 40 07 00 3F FC 00 0C 07 00 3F 41 01 1B 4B 07 00 77 FF 00 01 00 06 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 00 02 07 00 77 01 5D 07 00 77 44 07 00 2A FF 00 00 00 06 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 00 02 07 00 77 07 00 3F 47 07 00 2A FF 00 00 00 06 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 00 02 07 00 77 01 42 07 00 11 FF 00 00 00 06 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 00 02 07 00 77 01 45 07 00 2A 00 0A 41 01 1C FF 00 16 00 08 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 07 00 FA 01 00 01 07 00 FA FF 00 01 00 08 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 07 00 FA 01 00 02 07 00 FA 01 5E 07 00 FA FF 00 02 00 00 00 01 07 00 2A FF 00 00 00 08 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 07 00 FA 01 00 01 07 00 FA 47 07 00 2A 40 07 00 4B FC 00 01 07 00 4B 4C 07 00 4B FF 00 02 00 09 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 07 00 FA 01 07 00 4B 00 02 07 00 4B 01 5C 07 00 4B 42 07 00 9A 40 07 00 4B 47 07 00 2A 40 01 02 05 42 01 1A FF 00 04 00 00 00 01 07 00 2A FF 00 00 00 09 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 07 00 FA 01 07 00 4B 00 01 07 00 4B 47 07 00 2A 40 07 00 05 FC 00 0D 07 00 05 42 01 1F 4D 07 00 05 FF 00 02 00 0A 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 07 00 FA 01 07 00 4B 07 00 05 00 02 07 00 05 01 5E 07 00 05 FF 00 0E 00 0B 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 07 00 FA 01 07 00 4B 07 00 05 07 00 05 00 01 01 FF 00 02 00 0B 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 07 00 FA 01 07 00 4B 07 00 05 07 00 05 00 02 01 01 5D 01 FC 00 0D 01 42 01 1E 4E 07 00 03 FF 00 02 00 0C 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 07 00 FA 01 07 00 4B 07 00 05 07 00 05 01 00 02 07 00 03 01 5D 07 00 03 FF 00 05 00 00 00 01 07 00 2A FF 00 00 00 0C 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 07 00 FA 01 07 00 4B 07 00 05 07 00 05 01 00 03 07 00 03 07 00 05 07 00 77 45 07 00 2A 00 F8 00 03 FF 00 01 00 08 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 07 00 FA 01 00 01 07 00 FA FD 00 01 07 00 4B 07 00 05 FF 00 01 00 06 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 00 00 01 FF 00 01 00 04 07 00 03 07 00 D3 07 00 A8 07 00 77 00 01 01 FC 00 01 01 FF 00 01 00 0C 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 07 00 FA 01 07 00 4B 07 00 05 07 00 05 01 00 00 FF 00 01 00 05 07 00 03 07 00 D3 07 00 A8 07 00 77 01 00 01 07 00 77 FF 00 01 00 0C 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 07 00 FA 01 07 00 4B 07 00 05 07 00 05 01 00 01 07 00 03 FF 00 01 00 0B 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 07 00 FA 01 07 00 4B 07 00 05 07 00 05 00 01 01 FF 00 01 00 0A 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 07 00 FA 01 07 00 4B 07 00 05 00 01 07 00 05 FF 00 01 00 06 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 00 01 07 00 77 FF 00 01 00 09 07 00 03 07 00 D3 07 00 A8 07 00 77 01 07 00 3F 07 00 FA 01 07 00 4B 00 01 07 00 4B FF 00 01 00 04 07 00 03 07 00 D3 07 00 A8 07 00 77 00 01 07 00 2A 43 05 44 07 00 2A 47 05 47 07 00 2A
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     891    899    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  891    899    891    899    Ljava/lang/AssertionError;
        //  907    909    3      8      Any
        //  34     41     41     42     Any
        //  34     41     34     35     Ljava/lang/UnsupportedOperationException;
        //  34     41     34     35     Ljava/util/ConcurrentModificationException;
        //  35     41     41     42     Ljava/util/NoSuchElementException;
        //  34     41     3      8      Ljava/lang/IndexOutOfBoundsException;
        //  46     53     53     54     Any
        //  46     53     53     54     Ljava/lang/StringIndexOutOfBoundsException;
        //  47     53     46     47     Ljava/lang/ClassCastException;
        //  46     53     3      8      Ljava/lang/IllegalArgumentException;
        //  46     53     46     47     Ljava/lang/NullPointerException;
        //  57     66     66     67     Any
        //  57     66     57     58     Ljava/lang/NumberFormatException;
        //  57     66     66     67     Ljava/lang/IllegalStateException;
        //  57     66     66     67     Any
        //  58     66     3      8      Ljava/lang/NegativeArraySizeException;
        //  167    174    174    175    Any
        //  167    174    167    168    Ljava/lang/NumberFormatException;
        //  167    174    167    168    Any
        //  168    174    174    175    Any
        //  168    174    3      8      Any
        //  178    185    185    186    Any
        //  178    185    178    179    Ljava/lang/IllegalStateException;
        //  178    185    185    186    Ljava/lang/StringIndexOutOfBoundsException;
        //  179    185    178    179    Ljava/lang/IllegalArgumentException;
        //  178    185    185    186    Ljava/lang/StringIndexOutOfBoundsException;
        //  237    244    244    245    Any
        //  238    244    237    238    Any
        //  237    244    244    245    Any
        //  237    244    237    238    Any
        //  238    244    244    245    Ljava/lang/ClassCastException;
        //  250    256    256    257    Any
        //  250    256    256    257    Ljava/lang/NullPointerException;
        //  250    256    256    257    Any
        //  250    256    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  250    256    3      8      Any
        //  349    358    358    359    Any
        //  350    358    349    350    Any
        //  350    358    3      8      Ljava/lang/UnsupportedOperationException;
        //  350    358    349    350    Ljava/lang/StringIndexOutOfBoundsException;
        //  350    358    349    350    Ljava/util/NoSuchElementException;
        //  362    369    369    370    Any
        //  362    369    369    370    Ljava/lang/ArithmeticException;
        //  362    369    362    363    Ljava/lang/ArithmeticException;
        //  362    369    362    363    Ljava/lang/UnsupportedOperationException;
        //  363    369    3      8      Any
        //  472    480    480    481    Any
        //  472    480    480    481    Ljava/lang/IndexOutOfBoundsException;
        //  472    480    3      8      Any
        //  472    480    480    481    Ljava/util/ConcurrentModificationException;
        //  472    480    480    481    Any
        //  531    540    540    541    Any
        //  532    540    3      8      Any
        //  531    540    540    541    Ljava/lang/ClassCastException;
        //  532    540    531    532    Ljava/lang/StringIndexOutOfBoundsException;
        //  532    540    3      8      Any
        //  586    594    594    595    Any
        //  586    594    3      8      Ljava/lang/ArithmeticException;
        //  586    594    594    595    Ljava/util/ConcurrentModificationException;
        //  586    594    3      8      Any
        //  586    594    3      8      Any
        //  843    849    849    850    Any
        //  843    849    849    850    Any
        //  843    849    849    850    Any
        //  843    849    849    850    Ljava/lang/RuntimeException;
        //  843    849    3      8      Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:738)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public f3Z() {
        while (true) {
            int n = 0;
            Label_0015: {
                if (fc.c == 0) {
                    n = 2041652826;
                    break Label_0015;
                }
                n = -1799318217;
            }
            switch (n ^ 0xE85343FF) {
                case -1847433819: {
                    continue;
                }
                case 2090063560: {
                    while (true) {
                        int n2 = 0;
                        Label_0060: {
                            if (fc.0 <= 0) {
                                n2 = -1146487828;
                                break Label_0060;
                            }
                            n2 = 671472539;
                        }
                        switch (n2 ^ 0x47EF5DAF) {
                            case -62478781: {
                                continue;
                            }
                            case 1877640756: {
                                return;
                            }
                            default: {
                                throw null;
                            }
                        }
                        break;
                    }
                    break;
                }
                default: {
                    throw null;
                }
            }
            break;
        }
    }
    
    static {
        f3Z.c = new f3Z();
    }
}
