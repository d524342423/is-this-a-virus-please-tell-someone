// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import java.util.function.Consumer;
import dev.nuker.pyro.security.inject.LauncherEventHide;
import net.minecraft.network.play.server.SPacketChunkData;
import java.util.function.Predicate;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.Minecraft;
import java.util.List;
import org.jetbrains.annotations.NotNull;

public class f7b extends fQ
{
    @NotNull
    public f0l c;
    @NotNull
    public List<fe3<Integer, Integer>> c;
    
    public static Minecraft c(final f7b p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getstatic       dev/nuker/pyro/fc.0:I
        //     4: ifeq            84
        //     7: pop            
        //     8: aconst_null    
        //     9: goto            76
        //    12: nop            
        //    13: nop            
        //    14: nop            
        //    15: athrow         
        //    16: getstatic       dev/nuker/pyro/fc.0:I
        //    19: ifgt            27
        //    22: ldc             -183509577
        //    24: goto            29
        //    27: ldc             527521744
        //    29: ldc             445160731
        //    31: ixor           
        //    32: lookupswitch {
        //          -276348756: 27
        //          100256459: 60
        //          default: 65
        //        }
        //    60: aload_0        
        //    61: getfield        dev/nuker/pyro/f7b.c:Lnet/minecraft/client/Minecraft;
        //    64: areturn        
        //    65: aconst_null    
        //    66: athrow         
        //    67: pop            
        //    68: goto            16
        //    71: pop            
        //    72: aconst_null    
        //    73: goto            67
        //    76: dup            
        //    77: ifnull          67
        //    80: checkcast       Ljava/lang/Throwable;
        //    83: athrow         
        //    84: dup            
        //    85: ifnull          71
        //    88: checkcast       Ljava/lang/Throwable;
        //    91: athrow         
        //    StackMapTable: 00 0A FF 00 0C 00 00 00 01 07 00 13 FC 00 03 07 00 03 0A 41 01 1E 04 41 07 00 13 43 05 44 07 00 13 47 05
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type
        //  -----  -----  -----  -----  ----
        //  0      12     76     84     Any
        //  76     84     76     84     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:543)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void c(final boolean p0, @Nullable final EntityPlayerSP p1, @Nullable final World p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          111
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            103
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            95
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_0        
        //    25: iload_1        
        //    26: aload_2        
        //    27: aload_3        
        //    28: getstatic       dev/nuker/pyro/fc.c:I
        //    31: ifne            39
        //    34: ldc             -450689250
        //    36: goto            41
        //    39: ldc             142878861
        //    41: ldc             -1318937984
        //    43: ixor           
        //    44: lookupswitch {
        //          699750176: 39
        //          1413586334: 84
        //          default: 72
        //        }
        //    72: goto            76
        //    75: athrow         
        //    76: invokespecial   dev/nuker/pyro/fQ.c:(ZLnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/world/World;)V
        //    79: goto            83
        //    82: athrow         
        //    83: return         
        //    84: aconst_null    
        //    85: athrow         
        //    86: pop            
        //    87: goto            24
        //    90: pop            
        //    91: aconst_null    
        //    92: goto            86
        //    95: dup            
        //    96: ifnull          86
        //    99: checkcast       Ljava/lang/Throwable;
        //   102: athrow         
        //   103: dup            
        //   104: ifnull          90
        //   107: checkcast       Ljava/lang/Throwable;
        //   110: athrow         
        //   111: aconst_null    
        //   112: athrow         
        //    StackMapTable: 00 11 43 07 00 13 04 FF 00 0B 00 00 00 01 07 00 13 FF 00 03 00 04 07 00 03 01 07 00 2A 07 00 2C 00 00 FF 00 0E 00 04 07 00 03 01 07 00 2A 07 00 2C 00 04 07 00 03 01 07 00 2A 07 00 2C FF 00 01 00 04 07 00 03 01 07 00 2A 07 00 2C 00 05 07 00 03 01 07 00 2A 07 00 2C 01 FF 00 1E 00 04 07 00 03 01 07 00 2A 07 00 2C 00 04 07 00 03 01 07 00 2A 07 00 2C FF 00 02 00 00 00 01 07 00 13 FF 00 00 00 04 07 00 03 01 07 00 2A 07 00 2C 00 04 07 00 03 01 07 00 2A 07 00 2C 45 07 00 13 00 FF 00 00 00 04 07 00 03 01 07 00 2A 07 00 2C 00 04 07 00 03 01 07 00 2A 07 00 2C 41 07 00 1F 43 05 44 07 00 1F 47 05 47 07 00 13
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                     
        //  -----  -----  -----  -----  -----------------------------------------
        //  8      20     95     103    Ljava/lang/ClassCastException;
        //  95     103    95     103    Ljava/lang/RuntimeException;
        //  111    113    3      8      Any
        //  76     82     82     83     Any
        //  76     82     82     83     Any
        //  76     82     3      8      Ljava/lang/UnsupportedOperationException;
        //  76     82     3      8      Any
        //  76     82     82     83     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 44 out of bounds for length 44
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @f0g
    @LauncherEventHide
    public void c(@NotNull final f4e p0) {
        public class f7a implements Predicate
        {
            public SPacketChunkData c;
            
            public f7a(final SPacketChunkData c) {
                while (true) {
                    int n = 0;
                    Label_0015: {
                        if (fc.0 <= 0) {
                            n = -1627603359;
                            break Label_0015;
                        }
                        n = 175704009;
                    }
                    switch (n ^ 0x9A9C67E4) {
                        case -1484491444: {
                            continue;
                        }
                        default: {
                            this.c = c;
                            while (true) {
                                int n2 = 0;
                                Label_0060: {
                                    if (fc.0 <= 0) {
                                        n2 = 1336094188;
                                        break Label_0060;
                                    }
                                    n2 = -914178027;
                                }
                                switch (n2 ^ 0xFBFE6D1E) {
                                    case 1089626613: {
                                        continue;
                                    }
                                    default: {
                                        while (true) {
                                            int n3 = 0;
                                            Label_0102: {
                                                if (fc.1 == 0) {
                                                    n3 = 926723166;
                                                    break Label_0102;
                                                }
                                                n3 = 1380984256;
                                            }
                                            switch (n3 ^ 0x710D7667) {
                                                case -800774414: {
                                                    continue;
                                                }
                                                default: {
                                                    return;
                                                }
                                                case 1177672249: {
                                                    throw null;
                                                }
                                            }
                                            break;
                                        }
                                        break;
                                    }
                                    case -1268956942: {
                                        throw null;
                                    }
                                }
                                break;
                            }
                            break;
                        }
                        case 73456005: {
                            throw null;
                        }
                    }
                    break;
                }
            }
            
            @Override
            public boolean test(final Object o) {
                return fez.1D(this, 850955407, o);
            }
            
            static {
                throw t;
            }
            
            public boolean c(@NotNull final fe3 p0) {
                // 
                // This method could not be decompiled.
                // 
                // Original Bytecode:
                // 
                //     3: dup            
                //     4: ifnull          639
                //     7: athrow         
                //     8: aconst_null    
                //     9: getstatic       dev/nuker/pyro/fc.0:I
                //    12: ifeq            631
                //    15: pop            
                //    16: aconst_null    
                //    17: goto            623
                //    20: nop            
                //    21: nop            
                //    22: nop            
                //    23: athrow         
                //    24: aload_1        
                //    25: pop            
                //    26: getstatic       dev/nuker/pyro/fc.0:I
                //    29: ifgt            37
                //    32: ldc             -37775109
                //    34: goto            39
                //    37: ldc             1368080738
                //    39: ldc             1695792986
                //    41: ixor           
                //    42: lookupswitch {
                //          -1733548127: 596
                //          80075808: 37
                //          default: 68
                //        }
                //    68: aload_1        
                //    69: getstatic       dev/nuker/pyro/fc.c:I
                //    72: ifne            80
                //    75: ldc             710516919
                //    77: goto            82
                //    80: ldc             -284120610
                //    82: ldc             1581261735
                //    84: ixor           
                //    85: lookupswitch {
                //          387317611: 80
                //          1947829008: 594
                //          default: 112
                //        }
                //   112: goto            116
                //   115: athrow         
                //   116: invokevirtual   dev/nuker/pyro/fe3.0:()Ljava/lang/Object;
                //   119: goto            123
                //   122: athrow         
                //   123: checkcast       Ljava/lang/Integer;
                //   126: getstatic       dev/nuker/pyro/fc.1:I
                //   129: ifne            137
                //   132: ldc             2124218728
                //   134: goto            139
                //   137: ldc             -1017509544
                //   139: ldc             -653023080
                //   141: ixor           
                //   142: lookupswitch {
                //          -1483822608: 137
                //          441033152: 168
                //          default: 602
                //        }
                //   168: aload_0        
                //   169: getstatic       dev/nuker/pyro/fc.1:I
                //   172: ifne            180
                //   175: ldc             -714398924
                //   177: goto            182
                //   180: ldc             -512524249
                //   182: ldc             -1212088219
                //   184: ixor           
                //   185: lookupswitch {
                //          1454538818: 212
                //          1655317329: 180
                //          default: 604
                //        }
                //   212: getfield        dev/nuker/pyro/f7a.c:Lnet/minecraft/network/play/server/SPacketChunkData;
                //   215: getstatic       dev/nuker/pyro/fc.0:I
                //   218: ifgt            226
                //   221: ldc             1986823833
                //   223: goto            228
                //   226: ldc             1455845761
                //   228: ldc             498647788
                //   230: ixor           
                //   231: lookupswitch {
                //          1266594669: 256
                //          1809073269: 226
                //          default: 598
                //        }
                //   256: goto            260
                //   259: athrow         
                //   260: invokevirtual   net/minecraft/network/play/server/SPacketChunkData.func_149273_e:()I
                //   263: goto            267
                //   266: athrow         
                //   267: istore_2       
                //   268: dup            
                //   269: ifnonnull       276
                //   272: pop            
                //   273: goto            592
                //   276: getstatic       dev/nuker/pyro/fc.c:I
                //   279: ifne            287
                //   282: ldc             -1522361396
                //   284: goto            289
                //   287: ldc             -137289133
                //   289: ldc             262822041
                //   291: ixor           
                //   292: lookupswitch {
                //          -1427586219: 606
                //          599137110: 287
                //          default: 320
                //        }
                //   320: goto            324
                //   323: athrow         
                //   324: invokevirtual   java/lang/Integer.intValue:()I
                //   327: goto            331
                //   330: athrow         
                //   331: getstatic       dev/nuker/pyro/fc.0:I
                //   334: ifgt            342
                //   337: ldc             -1888426707
                //   339: goto            344
                //   342: ldc             -1810499553
                //   344: ldc             2144124475
                //   346: ixor           
                //   347: lookupswitch {
                //          -256091370: 612
                //          975869500: 342
                //          default: 372
                //        }
                //   372: iload_2        
                //   373: if_icmpne       592
                //   376: aload_1        
                //   377: getstatic       dev/nuker/pyro/fc.c:I
                //   380: ifne            388
                //   383: ldc             483089414
                //   385: goto            390
                //   388: ldc             -271653631
                //   390: ldc             -1590383185
                //   392: ixor           
                //   393: lookupswitch {
                //          -1107299927: 608
                //          -321773972: 388
                //          default: 420
                //        }
                //   420: goto            424
                //   423: athrow         
                //   424: invokevirtual   dev/nuker/pyro/fe3.c:()Ljava/lang/Object;
                //   427: goto            431
                //   430: athrow         
                //   431: checkcast       Ljava/lang/Integer;
                //   434: aload_0        
                //   435: getstatic       dev/nuker/pyro/fc.0:I
                //   438: ifgt            446
                //   441: ldc             73439922
                //   443: goto            448
                //   446: ldc             -1305966534
                //   448: ldc             -682264206
                //   450: ixor           
                //   451: lookupswitch {
                //          -751443008: 610
                //          1048769997: 446
                //          default: 476
                //        }
                //   476: getfield        dev/nuker/pyro/f7a.c:Lnet/minecraft/network/play/server/SPacketChunkData;
                //   479: goto            483
                //   482: athrow         
                //   483: invokevirtual   net/minecraft/network/play/server/SPacketChunkData.func_149271_f:()I
                //   486: goto            490
                //   489: athrow         
                //   490: istore_2       
                //   491: dup            
                //   492: ifnonnull       499
                //   495: pop            
                //   496: goto            592
                //   499: getstatic       dev/nuker/pyro/fc.1:I
                //   502: ifne            510
                //   505: ldc             313103827
                //   507: goto            512
                //   510: ldc             -1567015739
                //   512: ldc             -166212264
                //   514: ixor           
                //   515: lookupswitch {
                //          -457287541: 600
                //          1369953119: 510
                //          default: 540
                //        }
                //   540: goto            544
                //   543: athrow         
                //   544: invokevirtual   java/lang/Integer.intValue:()I
                //   547: goto            551
                //   550: athrow         
                //   551: iload_2        
                //   552: if_icmpne       560
                //   555: ldc             -1855272834
                //   557: goto            562
                //   560: ldc             -1855272835
                //   562: ldc             -1042560349
                //   564: ixor           
                //   565: tableswitch {
                //          -1587411526: 588
                //          -1587411525: 592
                //          default: 555
                //        }
                //   588: iconst_1       
                //   589: goto            593
                //   592: iconst_0       
                //   593: ireturn        
                //   594: aconst_null    
                //   595: athrow         
                //   596: aconst_null    
                //   597: athrow         
                //   598: aconst_null    
                //   599: athrow         
                //   600: aconst_null    
                //   601: athrow         
                //   602: aconst_null    
                //   603: athrow         
                //   604: aconst_null    
                //   605: athrow         
                //   606: aconst_null    
                //   607: athrow         
                //   608: aconst_null    
                //   609: athrow         
                //   610: aconst_null    
                //   611: athrow         
                //   612: aconst_null    
                //   613: athrow         
                //   614: pop            
                //   615: goto            24
                //   618: pop            
                //   619: aconst_null    
                //   620: goto            614
                //   623: dup            
                //   624: ifnull          614
                //   627: checkcast       Ljava/lang/Throwable;
                //   630: athrow         
                //   631: dup            
                //   632: ifnull          618
                //   635: checkcast       Ljava/lang/Throwable;
                //   638: athrow         
                //   639: aconst_null    
                //   640: athrow         
                //    StackMapTable: 00 51 43 07 00 4B 04 FF 00 0B 00 00 00 01 07 00 4B FD 00 03 07 00 03 07 00 55 0C 41 01 1C 4B 07 00 55 FF 00 01 00 02 07 00 03 07 00 55 00 02 07 00 55 01 5D 07 00 55 42 07 00 4B 40 07 00 55 45 07 00 4B 40 07 00 05 4D 07 00 5A FF 00 01 00 02 07 00 03 07 00 55 00 02 07 00 5A 01 5C 07 00 5A FF 00 0B 00 02 07 00 03 07 00 55 00 02 07 00 5A 07 00 03 FF 00 01 00 02 07 00 03 07 00 55 00 03 07 00 5A 07 00 03 01 FF 00 1D 00 02 07 00 03 07 00 55 00 02 07 00 5A 07 00 03 FF 00 0D 00 02 07 00 03 07 00 55 00 02 07 00 5A 07 00 28 FF 00 01 00 02 07 00 03 07 00 55 00 03 07 00 5A 07 00 28 01 FF 00 1B 00 02 07 00 03 07 00 55 00 02 07 00 5A 07 00 28 42 07 00 4B FF 00 00 00 02 07 00 03 07 00 55 00 02 07 00 5A 07 00 28 45 07 00 4B FF 00 00 00 02 07 00 03 07 00 55 00 02 07 00 5A 01 FF 00 08 00 03 07 00 03 07 00 55 01 00 01 07 00 5A 4A 07 00 5A FF 00 01 00 03 07 00 03 07 00 55 01 00 02 07 00 5A 01 5E 07 00 5A FF 00 02 00 00 00 01 07 00 4B FF 00 00 00 03 07 00 03 07 00 55 01 00 01 07 00 5A 45 07 00 4B 40 01 4A 01 FF 00 01 00 03 07 00 03 07 00 55 01 00 02 01 01 5B 01 4F 07 00 55 FF 00 01 00 03 07 00 03 07 00 55 01 00 02 07 00 55 01 5D 07 00 55 FF 00 02 00 00 00 01 07 00 4B FF 00 00 00 03 07 00 03 07 00 55 01 00 01 07 00 55 45 07 00 4B 40 07 00 05 FF 00 0E 00 03 07 00 03 07 00 55 01 00 02 07 00 5A 07 00 03 FF 00 01 00 03 07 00 03 07 00 55 01 00 03 07 00 5A 07 00 03 01 FF 00 1B 00 03 07 00 03 07 00 55 01 00 02 07 00 5A 07 00 03 45 07 00 4B FF 00 00 00 03 07 00 03 07 00 55 01 00 02 07 00 5A 07 00 28 45 07 00 4B FF 00 00 00 03 07 00 03 07 00 55 01 00 02 07 00 5A 01 48 07 00 5A 4A 07 00 5A FF 00 01 00 03 07 00 03 07 00 55 01 00 02 07 00 5A 01 5B 07 00 5A 42 07 00 4B 40 07 00 5A 45 07 00 4B 40 01 03 04 41 01 19 03 40 01 FF 00 00 00 02 07 00 03 07 00 55 00 01 07 00 55 01 FF 00 01 00 02 07 00 03 07 00 55 00 02 07 00 5A 07 00 28 FF 00 01 00 03 07 00 03 07 00 55 01 00 01 07 00 5A FF 00 01 00 02 07 00 03 07 00 55 00 01 07 00 5A FF 00 01 00 02 07 00 03 07 00 55 00 02 07 00 5A 07 00 03 FF 00 01 00 03 07 00 03 07 00 55 01 00 01 07 00 5A 41 07 00 55 FF 00 01 00 03 07 00 03 07 00 55 01 00 02 07 00 5A 07 00 03 41 01 FF 00 01 00 02 07 00 03 07 00 55 00 01 07 00 4B 43 05 44 07 00 4B 47 05 47 07 00 4B
                //    Exceptions:
                //  Try           Handler
                //  Start  End    Start  End    Type                                       
                //  -----  -----  -----  -----  -------------------------------------------
                //  8      20     623    631    Ljava/lang/IllegalArgumentException;
                //  623    631    623    631    Any
                //  639    641    3      8      Ljava/lang/IllegalStateException;
                //  115    122    122    123    Any
                //  116    122    3      8      Ljava/lang/NegativeArraySizeException;
                //  115    122    115    116    Any
                //  115    122    122    123    Any
                //  115    122    3      8      Any
                //  259    266    266    267    Any
                //  260    266    3      8      Ljava/lang/UnsupportedOperationException;
                //  259    266    259    260    Any
                //  259    266    266    267    Ljava/lang/ArrayIndexOutOfBoundsException;
                //  260    266    266    267    Ljava/lang/IllegalArgumentException;
                //  324    330    330    331    Any
                //  324    330    3      8      Any
                //  324    330    3      8      Any
                //  324    330    330    331    Ljava/lang/UnsupportedOperationException;
                //  324    330    3      8      Ljava/lang/ClassCastException;
                //  424    430    430    431    Any
                //  424    430    430    431    Ljava/lang/ArithmeticException;
                //  424    430    3      8      Ljava/lang/EnumConstantNotPresentException;
                //  424    430    430    431    Ljava/lang/ClassCastException;
                //  424    430    430    431    Ljava/lang/EnumConstantNotPresentException;
                //  482    489    489    490    Any
                //  483    489    482    483    Any
                //  482    489    482    483    Ljava/lang/UnsupportedOperationException;
                //  482    489    482    483    Ljava/lang/IndexOutOfBoundsException;
                //  482    489    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
                //  543    550    550    551    Any
                //  543    550    3      8      Any
                //  544    550    550    551    Ljava/lang/StringIndexOutOfBoundsException;
                //  543    550    543    544    Any
                //  544    550    550    551    Any
                // 
                // The error that occurred was:
                // 
                // java.lang.IndexOutOfBoundsException: Index 187 out of bounds for length 187
                //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
                //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
                //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
                //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
                //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
                //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
                //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
                //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
                //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
                //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
                //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
                //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
                //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
                //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
                //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:670)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
                //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
                //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
                //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
                //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
                //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
                // 
                throw new IllegalStateException("An error occurred while decompiling this method.");
            }
        }
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          856
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            848
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            840
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: aload_1        
        //    27: getstatic       dev/nuker/pyro/fc.1:I
        //    30: ifne            38
        //    33: ldc             1418447820
        //    35: goto            40
        //    38: ldc             1642155110
        //    40: ldc             1732130915
        //    42: ixor           
        //    43: lookupswitch {
        //          -2015353478: 38
        //          867562415: 807
        //          default: 68
        //        }
        //    68: goto            72
        //    71: athrow         
        //    72: invokevirtual   dev/nuker/pyro/f4e.c:()Ldev/nuker/pyro/f41;
        //    75: goto            79
        //    78: athrow         
        //    79: getstatic       dev/nuker/pyro/fc.1:I
        //    82: ifne            90
        //    85: ldc             -1710327213
        //    87: goto            92
        //    90: ldc             1748054020
        //    92: ldc             -1721976755
        //    94: ixor           
        //    95: lookupswitch {
        //          -244479927: 120
        //          55755294: 90
        //          default: 815
        //        }
        //   120: getstatic       dev/nuker/pyro/f41.c:Ldev/nuker/pyro/f41;
        //   123: if_acmpeq       127
        //   126: return         
        //   127: getstatic       dev/nuker/pyro/fc.0:I
        //   130: ifgt            138
        //   133: ldc             -655301191
        //   135: goto            140
        //   138: ldc             1277305700
        //   140: ldc             1548413353
        //   142: ixor           
        //   143: lookupswitch {
        //          -2068182000: 138
        //          275303117: 168
        //          default: 813
        //        }
        //   168: aload_1        
        //   169: goto            173
        //   172: athrow         
        //   173: invokevirtual   dev/nuker/pyro/f4e.c:()Lnet/minecraft/network/Packet;
        //   176: goto            180
        //   179: athrow         
        //   180: instanceof      Lnet/minecraft/network/play/server/SPacketChunkData;
        //   183: ifeq            806
        //   186: aload_1        
        //   187: goto            191
        //   190: athrow         
        //   191: invokevirtual   dev/nuker/pyro/f4e.c:()Lnet/minecraft/network/Packet;
        //   194: goto            198
        //   197: athrow         
        //   198: dup            
        //   199: ifnonnull       275
        //   202: new             Lkotlin/TypeCastException;
        //   205: dup            
        //   206: ldc             "\u3c9c\ub250\u8fec\uafb9\u61d2\u5874\u7e41\u68f9\uc0dc\ua57b\u9a3f\u1344\uc094\u731a\u9603\u4c7c\ub210\u4d6f\u0347\u01e1\u1373\ufecb\u6b60\u8a4b\u30be\u3cf6\u7fb6\ua886\ud3e4\u74a2\u45b0\u6bee\u75f2\u9570\uc159\u42f5\ufdac\u1168\u1a52\u4c34\u679b\uac0f\u8cdf\ufb39\uba7c\ua5ee\u4c30\u3ee7\u4835\ua4ef\u79c4\u916c\u32be\u6dcd\uf053\u0f26\u7a49\u0b4d\u9d6f\ud507\ue65e\u4c6b\u49a0\u14ce\u373d\u505c\u7982\ue617\u5df1\u8d55\uea03\u1df0\uf32f\ub46d\uc6c9\u16ba\u2aee\u67b9\u467a\u7a8b\ucbf9\u1729\u2aa2\u8dec\ud6ce\u3995\u9b9a"
        //   208: getstatic       dev/nuker/pyro/fc.1:I
        //   211: ifne            219
        //   214: ldc             835374437
        //   216: goto            221
        //   219: ldc             -496418490
        //   221: ldc             1326251066
        //   223: ixor           
        //   224: lookupswitch {
        //          -1385841284: 252
        //          2126917983: 219
        //          default: 811
        //        }
        //   252: goto            256
        //   255: athrow         
        //   256: invokestatic    invokestatic   !!! ERROR
        //   259: goto            263
        //   262: athrow         
        //   263: goto            267
        //   266: athrow         
        //   267: invokespecial   kotlin/TypeCastException.<init>:(Ljava/lang/String;)V
        //   270: goto            274
        //   273: athrow         
        //   274: athrow         
        //   275: checkcast       Lnet/minecraft/network/play/server/SPacketChunkData;
        //   278: astore_2       
        //   279: aload_2        
        //   280: goto            284
        //   283: athrow         
        //   284: invokevirtual   net/minecraft/network/play/server/SPacketChunkData.func_149274_i:()Z
        //   287: goto            291
        //   290: athrow         
        //   291: ifne            299
        //   294: ldc             1586157796
        //   296: goto            301
        //   299: ldc             1586157803
        //   301: ldc             1402250739
        //   303: ixor           
        //   304: tableswitch {
        //          440203822: 328
        //          440203823: 806
        //          default: 294
        //        }
        //   328: aload_0        
        //   329: getstatic       dev/nuker/pyro/fc.c:I
        //   332: ifne            340
        //   335: ldc             533759285
        //   337: goto            342
        //   340: ldc             2048330378
        //   342: ldc             -1111833819
        //   344: ixor           
        //   345: lookupswitch {
        //          -1570093552: 821
        //          1494012647: 340
        //          default: 372
        //        }
        //   372: getfield        dev/nuker/pyro/f7b.c:Ljava/util/List;
        //   375: new             Ldev/nuker/pyro/f7a;
        //   378: dup            
        //   379: getstatic       dev/nuker/pyro/fc.0:I
        //   382: ifgt            390
        //   385: ldc             -2033016122
        //   387: goto            392
        //   390: ldc             108233189
        //   392: ldc             1094937283
        //   394: ixor           
        //   395: lookupswitch {
        //          -1301580860: 390
        //          -946747387: 825
        //          default: 420
        //        }
        //   420: aload_2        
        //   421: goto            425
        //   424: athrow         
        //   425: invokespecial   dev/nuker/pyro/f7a.<init>:(Lnet/minecraft/network/play/server/SPacketChunkData;)V
        //   428: goto            432
        //   431: athrow         
        //   432: checkcast       Ljava/util/function/Predicate;
        //   435: goto            439
        //   438: athrow         
        //   439: invokeinterface java/util/List.removeIf:(Ljava/util/function/Predicate;)Z
        //   444: goto            448
        //   447: athrow         
        //   448: pop            
        //   449: new             Ldev/nuker/pyro/fe3;
        //   452: dup            
        //   453: aload_2        
        //   454: getstatic       dev/nuker/pyro/fc.1:I
        //   457: ifne            465
        //   460: ldc             -454861330
        //   462: goto            467
        //   465: ldc             -1691588681
        //   467: ldc             -1435095113
        //   469: ixor           
        //   470: lookupswitch {
        //          828000256: 496
        //          1318416985: 465
        //          default: 809
        //        }
        //   496: goto            500
        //   499: athrow         
        //   500: invokevirtual   net/minecraft/network/play/server/SPacketChunkData.func_149273_e:()I
        //   503: goto            507
        //   506: athrow         
        //   507: goto            511
        //   510: athrow         
        //   511: invokestatic    java/lang/Integer.valueOf:(I)Ljava/lang/Integer;
        //   514: goto            518
        //   517: athrow         
        //   518: aload_2        
        //   519: goto            523
        //   522: athrow         
        //   523: invokevirtual   net/minecraft/network/play/server/SPacketChunkData.func_149271_f:()I
        //   526: goto            530
        //   529: athrow         
        //   530: goto            534
        //   533: athrow         
        //   534: invokestatic    java/lang/Integer.valueOf:(I)Ljava/lang/Integer;
        //   537: goto            541
        //   540: athrow         
        //   541: getstatic       dev/nuker/pyro/fc.c:I
        //   544: ifne            552
        //   547: ldc             1819915568
        //   549: goto            554
        //   552: ldc             1346454952
        //   554: ldc             172394985
        //   556: ixor           
        //   557: lookupswitch {
        //          -399366268: 552
        //          1715420377: 829
        //          default: 584
        //        }
        //   584: goto            588
        //   587: athrow         
        //   588: invokespecial   dev/nuker/pyro/fe3.<init>:(Ljava/lang/Object;Ljava/lang/Object;)V
        //   591: goto            595
        //   594: athrow         
        //   595: getstatic       dev/nuker/pyro/fc.0:I
        //   598: ifgt            606
        //   601: ldc             -846741113
        //   603: goto            608
        //   606: ldc             -692985353
        //   608: ldc             1433564417
        //   610: ixor           
        //   611: lookupswitch {
        //          -1728727930: 827
        //          1756894155: 606
        //          default: 636
        //        }
        //   636: astore_3       
        //   637: getstatic       dev/nuker/pyro/fc.1:I
        //   640: ifne            648
        //   643: ldc             -297414961
        //   645: goto            650
        //   648: ldc             1901106930
        //   650: ldc             1313446638
        //   652: ixor           
        //   653: lookupswitch {
        //          -1609804767: 817
        //          -398253158: 648
        //          default: 680
        //        }
        //   680: aload_0        
        //   681: getfield        dev/nuker/pyro/f7b.c:Ljava/util/List;
        //   684: getstatic       dev/nuker/pyro/fc.c:I
        //   687: ifne            695
        //   690: ldc             -648302660
        //   692: goto            697
        //   695: ldc             -1436888082
        //   697: ldc             1085926360
        //   699: ixor           
        //   700: lookupswitch {
        //          -1985415606: 695
        //          -1713224604: 823
        //          default: 728
        //        }
        //   728: aload_3        
        //   729: goto            733
        //   732: athrow         
        //   733: invokeinterface java/util/List.contains:(Ljava/lang/Object;)Z
        //   738: goto            742
        //   741: athrow         
        //   742: ifne            806
        //   745: aload_0        
        //   746: getstatic       dev/nuker/pyro/fc.1:I
        //   749: ifne            757
        //   752: ldc             2071061764
        //   754: goto            759
        //   757: ldc             1191291812
        //   759: ldc             490774293
        //   761: ixor           
        //   762: lookupswitch {
        //          -1162126415: 757
        //          1714518545: 819
        //          default: 788
        //        }
        //   788: getfield        dev/nuker/pyro/f7b.c:Ljava/util/List;
        //   791: aload_3        
        //   792: goto            796
        //   795: athrow         
        //   796: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //   801: goto            805
        //   804: athrow         
        //   805: pop            
        //   806: return         
        //   807: aconst_null    
        //   808: athrow         
        //   809: aconst_null    
        //   810: athrow         
        //   811: aconst_null    
        //   812: athrow         
        //   813: aconst_null    
        //   814: athrow         
        //   815: aconst_null    
        //   816: athrow         
        //   817: aconst_null    
        //   818: athrow         
        //   819: aconst_null    
        //   820: athrow         
        //   821: aconst_null    
        //   822: athrow         
        //   823: aconst_null    
        //   824: athrow         
        //   825: aconst_null    
        //   826: athrow         
        //   827: aconst_null    
        //   828: athrow         
        //   829: aconst_null    
        //   830: athrow         
        //   831: pop            
        //   832: goto            24
        //   835: pop            
        //   836: aconst_null    
        //   837: goto            831
        //   840: dup            
        //   841: ifnull          831
        //   844: checkcast       Ljava/lang/Throwable;
        //   847: athrow         
        //   848: dup            
        //   849: ifnull          835
        //   852: checkcast       Ljava/lang/Throwable;
        //   855: athrow         
        //   856: aconst_null    
        //   857: athrow         
        //    StackMapTable: 00 7C 43 07 00 13 04 FF 00 0B 00 00 00 01 07 00 13 FD 00 03 07 00 03 07 00 4F 4D 07 00 4F FF 00 01 00 02 07 00 03 07 00 4F 00 02 07 00 4F 01 5B 07 00 4F 42 07 00 37 40 07 00 4F 45 07 00 13 40 07 00 57 4A 07 00 57 FF 00 01 00 02 07 00 03 07 00 4F 00 02 07 00 57 01 5B 07 00 57 06 0A 41 01 1B 43 07 00 3B 40 07 00 4F 45 07 00 13 40 07 00 BB 49 07 00 13 40 07 00 4F 45 07 00 13 40 07 00 BB FF 00 14 00 02 07 00 03 07 00 4F 00 04 07 00 BB 08 00 CA 08 00 CA 07 00 BD FF 00 01 00 02 07 00 03 07 00 4F 00 05 07 00 BB 08 00 CA 08 00 CA 07 00 BD 01 FF 00 1E 00 02 07 00 03 07 00 4F 00 04 07 00 BB 08 00 CA 08 00 CA 07 00 BD 42 07 00 13 FF 00 00 00 02 07 00 03 07 00 4F 00 04 07 00 BB 08 00 CA 08 00 CA 07 00 BD 45 07 00 13 FF 00 00 00 02 07 00 03 07 00 4F 00 04 07 00 BB 08 00 CA 08 00 CA 07 00 BD 42 07 00 13 FF 00 00 00 02 07 00 03 07 00 4F 00 04 07 00 BB 08 00 CA 08 00 CA 07 00 BD 45 07 00 13 FF 00 00 00 02 07 00 03 07 00 4F 00 02 07 00 BB 07 00 64 40 07 00 BB FF 00 07 00 03 07 00 03 07 00 4F 07 00 62 00 01 07 00 13 40 07 00 62 45 07 00 13 40 01 02 04 41 01 1A 4B 07 00 03 FF 00 01 00 03 07 00 03 07 00 4F 07 00 62 00 02 07 00 03 01 5D 07 00 03 FF 00 11 00 03 07 00 03 07 00 4F 07 00 62 00 03 07 00 8A 08 01 77 08 01 77 FF 00 01 00 03 07 00 03 07 00 4F 07 00 62 00 04 07 00 8A 08 01 77 08 01 77 01 FF 00 1B 00 03 07 00 03 07 00 4F 07 00 62 00 03 07 00 8A 08 01 77 08 01 77 43 07 00 3F FF 00 00 00 03 07 00 03 07 00 4F 07 00 62 00 04 07 00 8A 08 01 77 08 01 77 07 00 62 45 07 00 13 FF 00 00 00 03 07 00 03 07 00 4F 07 00 62 00 02 07 00 8A 07 00 80 45 07 00 3D FF 00 00 00 03 07 00 03 07 00 4F 07 00 62 00 02 07 00 8A 07 00 88 47 07 00 13 40 01 FF 00 10 00 03 07 00 03 07 00 4F 07 00 62 00 03 08 01 C1 08 01 C1 07 00 62 FF 00 01 00 03 07 00 03 07 00 4F 07 00 62 00 04 08 01 C1 08 01 C1 07 00 62 01 FF 00 1C 00 03 07 00 03 07 00 4F 07 00 62 00 03 08 01 C1 08 01 C1 07 00 62 42 07 00 13 FF 00 00 00 03 07 00 03 07 00 4F 07 00 62 00 03 08 01 C1 08 01 C1 07 00 62 45 07 00 13 FF 00 00 00 03 07 00 03 07 00 4F 07 00 62 00 03 08 01 C1 08 01 C1 01 FF 00 02 00 00 00 01 07 00 13 FF 00 00 00 03 07 00 03 07 00 4F 07 00 62 00 03 08 01 C1 08 01 C1 01 45 07 00 13 FF 00 00 00 03 07 00 03 07 00 4F 07 00 62 00 03 08 01 C1 08 01 C1 07 00 99 43 07 00 13 FF 00 00 00 03 07 00 03 07 00 4F 07 00 62 00 04 08 01 C1 08 01 C1 07 00 99 07 00 62 45 07 00 13 FF 00 00 00 03 07 00 03 07 00 4F 07 00 62 00 04 08 01 C1 08 01 C1 07 00 99 01 42 07 00 43 FF 00 00 00 03 07 00 03 07 00 4F 07 00 62 00 04 08 01 C1 08 01 C1 07 00 99 01 45 07 00 13 FF 00 00 00 03 07 00 03 07 00 4F 07 00 62 00 04 08 01 C1 08 01 C1 07 00 99 07 00 99 FF 00 0A 00 03 07 00 03 07 00 4F 07 00 62 00 04 08 01 C1 08 01 C1 07 00 99 07 00 99 FF 00 01 00 03 07 00 03 07 00 4F 07 00 62 00 05 08 01 C1 08 01 C1 07 00 99 07 00 99 01 FF 00 1D 00 03 07 00 03 07 00 4F 07 00 62 00 04 08 01 C1 08 01 C1 07 00 99 07 00 99 42 07 00 13 FF 00 00 00 03 07 00 03 07 00 4F 07 00 62 00 04 08 01 C1 08 01 C1 07 00 99 07 00 99 45 07 00 13 40 07 00 90 4A 07 00 90 FF 00 01 00 03 07 00 03 07 00 4F 07 00 62 00 02 07 00 90 01 5B 07 00 90 FC 00 0B 07 00 90 41 01 1D 4E 07 00 8A FF 00 01 00 04 07 00 03 07 00 4F 07 00 62 07 00 90 00 02 07 00 8A 01 5E 07 00 8A 43 07 00 13 FF 00 00 00 04 07 00 03 07 00 4F 07 00 62 07 00 90 00 02 07 00 8A 07 00 90 47 07 00 13 40 01 4E 07 00 03 FF 00 01 00 04 07 00 03 07 00 4F 07 00 62 07 00 90 00 02 07 00 03 01 5C 07 00 03 46 07 00 13 FF 00 00 00 04 07 00 03 07 00 4F 07 00 62 07 00 90 00 02 07 00 8A 07 00 90 47 07 00 13 40 01 F9 00 00 40 07 00 4F FF 00 01 00 03 07 00 03 07 00 4F 07 00 62 00 03 08 01 C1 08 01 C1 07 00 62 FF 00 01 00 02 07 00 03 07 00 4F 00 04 07 00 BB 08 00 CA 08 00 CA 07 00 BD 01 41 07 00 57 FD 00 01 07 00 62 07 00 90 41 07 00 03 FF 00 01 00 03 07 00 03 07 00 4F 07 00 62 00 01 07 00 03 FF 00 01 00 04 07 00 03 07 00 4F 07 00 62 07 00 90 00 01 07 00 8A FF 00 01 00 03 07 00 03 07 00 4F 07 00 62 00 03 07 00 8A 08 01 77 08 01 77 41 07 00 90 FF 00 01 00 03 07 00 03 07 00 4F 07 00 62 00 04 08 01 C1 08 01 C1 07 00 99 07 00 99 FF 00 01 00 02 07 00 03 07 00 4F 00 01 07 00 13 43 05 44 07 00 13 47 05 47 07 00 13
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     840    848    Ljava/util/ConcurrentModificationException;
        //  840    848    840    848    Any
        //  856    858    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  71     78     78     79     Any
        //  72     78     3      8      Any
        //  71     78     3      8      Any
        //  72     78     3      8      Ljava/lang/AssertionError;
        //  71     78     71     72     Ljava/lang/EnumConstantNotPresentException;
        //  172    179    179    180    Any
        //  173    179    3      8      Any
        //  173    179    179    180    Any
        //  172    179    3      8      Ljava/util/NoSuchElementException;
        //  172    179    172    173    Ljava/lang/IllegalArgumentException;
        //  190    197    197    198    Any
        //  190    197    3      8      Any
        //  190    197    197    198    Any
        //  190    197    190    191    Any
        //  191    197    3      8      Ljava/lang/ClassCastException;
        //  255    262    262    263    Any
        //  256    262    255    256    Any
        //  256    262    255    256    Ljava/lang/RuntimeException;
        //  256    262    262    263    Any
        //  255    262    3      8      Any
        //  266    273    273    274    Any
        //  266    273    266    267    Any
        //  266    273    266    267    Any
        //  267    273    266    267    Any
        //  267    273    3      8      Any
        //  283    290    290    291    Any
        //  283    290    290    291    Ljava/lang/IllegalArgumentException;
        //  283    290    283    284    Ljava/lang/IllegalStateException;
        //  283    290    283    284    Any
        //  283    290    3      8      Any
        //  424    431    431    432    Any
        //  424    431    424    425    Ljava/lang/StringIndexOutOfBoundsException;
        //  424    431    3      8      Ljava/lang/ArithmeticException;
        //  424    431    424    425    Ljava/lang/StringIndexOutOfBoundsException;
        //  425    431    3      8      Ljava/lang/IllegalStateException;
        //  438    447    447    448    Any
        //  439    447    447    448    Any
        //  439    447    447    448    Ljava/lang/StringIndexOutOfBoundsException;
        //  438    447    3      8      Any
        //  438    447    438    439    Ljava/lang/IllegalStateException;
        //  499    506    506    507    Any
        //  500    506    499    500    Any
        //  499    506    499    500    Any
        //  499    506    506    507    Ljava/lang/NumberFormatException;
        //  500    506    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  511    517    517    518    Any
        //  511    517    3      8      Any
        //  511    517    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  511    517    517    518    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  511    517    517    518    Any
        //  522    529    529    530    Any
        //  523    529    529    530    Ljava/lang/NegativeArraySizeException;
        //  523    529    529    530    Any
        //  523    529    529    530    Any
        //  522    529    522    523    Any
        //  533    540    540    541    Any
        //  533    540    3      8      Any
        //  534    540    533    534    Ljava/lang/NumberFormatException;
        //  534    540    3      8      Any
        //  534    540    540    541    Ljava/lang/EnumConstantNotPresentException;
        //  587    594    594    595    Any
        //  588    594    587    588    Any
        //  588    594    594    595    Ljava/lang/UnsupportedOperationException;
        //  588    594    594    595    Any
        //  587    594    587    588    Ljava/lang/AssertionError;
        //  732    741    741    742    Any
        //  732    741    741    742    Any
        //  733    741    3      8      Any
        //  733    741    732    733    Ljava/lang/ClassCastException;
        //  732    741    732    733    Any
        //  795    804    804    805    Any
        //  796    804    795    796    Any
        //  796    804    804    805    Ljava/util/NoSuchElementException;
        //  796    804    804    805    Ljava/lang/IndexOutOfBoundsException;
        //  795    804    804    805    Ljava/util/NoSuchElementException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalArgumentException: Argument 'offset' must be in the range [0, 0], but value was: 2.
        //     at com.strobel.core.VerifyArgument.inRange(VerifyArgument.java:347)
        //     at com.strobel.assembler.ir.StackMappingVisitor.getStackValue(StackMappingVisitor.java:67)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:691)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @NotNull
    public List 0() {
        return fez.iL(this, 180888852);
    }
    
    public f7b() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: ldc             "\u3c9c\ub240\u8ff7\uada7\u6789\u5862\u7e4e\u68fc\uc2d0"
        //     3: invokestatic    invokestatic   !!! ERROR
        //     6: ldc             "\u3cbc\ub240\u8ff7\uad87\u6789\u5862\u7e4e\u68fc\uc2d0"
        //     8: getstatic       dev/nuker/pyro/fc.c:I
        //    11: ifne            19
        //    14: ldc             2112167029
        //    16: goto            21
        //    19: ldc             1636047528
        //    21: ldc             -282328516
        //    23: ixor           
        //    24: lookupswitch {
        //          -1832313271: 340
        //          1831781712: 19
        //          default: 52
        //        }
        //    52: invokestatic    invokestatic   !!! ERROR
        //    55: ldc             "\u3ca0\ub240\u8fee\uada0\u6784\u5865\u7e53\u68b7\uc2c0\ua36f\u9a3e\u130a\uc09d\u711d\u9010\u4c6b\ub219\u4d7d\u0156\u07f2\u1366\ufed6\u6b25\u8814\u36a1\u3cf4\u7ffa\ua89b\ud1f3\u72b4\u45ba\u6ba7\u75e3\u977c\uc71a\u42f1\ufdff\u1126\u1848\u4a36\u67c2\uac42\u8cd9\uf928\ubc2a\ua5de\u4c32\u3eef\u4a25\ua2e7\u799e\u9122\u32a8\u6fcd\uf645\u0f3f\u7a5e\u0b54\u9f23"
        //    57: invokestatic    invokestatic   !!! ERROR
        //    60: invokespecial   dev/nuker/pyro/fQ.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //    63: aload_0        
        //    64: getstatic       dev/nuker/pyro/fc.1:I
        //    67: ifne            75
        //    70: ldc             1835362657
        //    72: goto            77
        //    75: ldc             -1106635210
        //    77: ldc             1655809685
        //    79: ixor           
        //    80: lookupswitch {
        //          265605108: 342
        //          1823250886: 75
        //          default: 108
        //        }
        //   108: aload_0        
        //   109: new             Ldev/nuker/pyro/f0l;
        //   112: dup            
        //   113: ldc             "\u3c91\ub24a\u8fec\uadab\u6793"
        //   115: getstatic       dev/nuker/pyro/fc.0:I
        //   118: ifgt            126
        //   121: ldc             618436447
        //   123: goto            128
        //   126: ldc             -914449363
        //   128: ldc             409847502
        //   130: ixor           
        //   131: lookupswitch {
        //          1018253713: 338
        //          1669533513: 126
        //          default: 156
        //        }
        //   156: invokestatic    invokestatic   !!! ERROR
        //   159: ldc             "\u3cb1\ub24a\u8fec\uadab\u6793"
        //   161: invokestatic    invokestatic   !!! ERROR
        //   164: aconst_null    
        //   165: getstatic       dev/nuker/pyro/f00.c:Ldev/nuker/pyro/f0c;
        //   168: ldc             0.6
        //   170: fconst_0       
        //   171: ldc             0.9333333
        //   173: ldc             0.5
        //   175: getstatic       dev/nuker/pyro/fc.1:I
        //   178: ifne            186
        //   181: ldc             443384621
        //   183: goto            188
        //   186: ldc             -655682549
        //   188: ldc             1297892715
        //   190: ixor           
        //   191: lookupswitch {
        //          149922094: 186
        //          1462879814: 334
        //          default: 216
        //        }
        //   216: invokevirtual   dev/nuker/pyro/f0c.0:(FFFF)Ldev/nuker/pyro/f00;
        //   219: getstatic       dev/nuker/pyro/fc.0:I
        //   222: ifgt            230
        //   225: ldc             -1998225868
        //   227: goto            232
        //   230: ldc             1169655162
        //   232: ldc             713558322
        //   234: ixor           
        //   235: lookupswitch {
        //          -1569884410: 344
        //          1094330582: 230
        //          default: 260
        //        }
        //   260: invokespecial   dev/nuker/pyro/f0l.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ldev/nuker/pyro/f00;)V
        //   263: checkcast       Ldev/nuker/pyro/f0w;
        //   266: invokevirtual   dev/nuker/pyro/f7b.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   269: checkcast       Ldev/nuker/pyro/f0l;
        //   272: putfield        dev/nuker/pyro/f7b.c:Ldev/nuker/pyro/f0l;
        //   275: aload_0        
        //   276: new             Ljava/util/concurrent/CopyOnWriteArrayList;
        //   279: dup            
        //   280: getstatic       dev/nuker/pyro/fc.1:I
        //   283: ifne            291
        //   286: ldc             1399317729
        //   288: goto            293
        //   291: ldc             1275134993
        //   293: ldc_w           2143541665
        //   296: ixor           
        //   297: lookupswitch {
        //          -1859417205: 291
        //          748961088: 336
        //          default: 324
        //        }
        //   324: invokespecial   java/util/concurrent/CopyOnWriteArrayList.<init>:()V
        //   327: checkcast       Ljava/util/List;
        //   330: putfield        dev/nuker/pyro/f7b.c:Ljava/util/List;
        //   333: return         
        //   334: aconst_null    
        //   335: athrow         
        //   336: aconst_null    
        //   337: athrow         
        //   338: aconst_null    
        //   339: athrow         
        //   340: aconst_null    
        //   341: athrow         
        //   342: aconst_null    
        //   343: athrow         
        //   344: aconst_null    
        //   345: athrow         
        //    StackMapTable: 00 18 FF 00 13 00 01 06 00 03 06 07 00 BD 07 00 BD FF 00 01 00 01 06 00 04 06 07 00 BD 07 00 BD 01 FF 00 1E 00 01 06 00 03 06 07 00 BD 07 00 BD FF 00 16 00 01 07 00 03 00 01 07 00 03 FF 00 01 00 01 07 00 03 00 02 07 00 03 01 5E 07 00 03 FF 00 11 00 01 07 00 03 00 05 07 00 03 07 00 03 08 00 6D 08 00 6D 07 00 BD FF 00 01 00 01 07 00 03 00 06 07 00 03 07 00 03 08 00 6D 08 00 6D 07 00 BD 01 FF 00 1B 00 01 07 00 03 00 05 07 00 03 07 00 03 08 00 6D 08 00 6D 07 00 BD FF 00 1D 00 01 07 00 03 00 0C 07 00 03 07 00 03 08 00 6D 08 00 6D 07 00 BD 07 00 BD 05 07 00 EB 02 02 02 02 FF 00 01 00 01 07 00 03 00 0D 07 00 03 07 00 03 08 00 6D 08 00 6D 07 00 BD 07 00 BD 05 07 00 EB 02 02 02 02 01 FF 00 1B 00 01 07 00 03 00 0C 07 00 03 07 00 03 08 00 6D 08 00 6D 07 00 BD 07 00 BD 05 07 00 EB 02 02 02 02 FF 00 0D 00 01 07 00 03 00 08 07 00 03 07 00 03 08 00 6D 08 00 6D 07 00 BD 07 00 BD 05 07 00 E0 FF 00 01 00 01 07 00 03 00 09 07 00 03 07 00 03 08 00 6D 08 00 6D 07 00 BD 07 00 BD 05 07 00 E0 01 FF 00 1B 00 01 07 00 03 00 08 07 00 03 07 00 03 08 00 6D 08 00 6D 07 00 BD 07 00 BD 05 07 00 E0 FF 00 1E 00 01 07 00 03 00 03 07 00 03 08 01 14 08 01 14 FF 00 01 00 01 07 00 03 00 04 07 00 03 08 01 14 08 01 14 01 FF 00 1E 00 01 07 00 03 00 03 07 00 03 08 01 14 08 01 14 FF 00 09 00 01 07 00 03 00 0C 07 00 03 07 00 03 08 00 6D 08 00 6D 07 00 BD 07 00 BD 05 07 00 EB 02 02 02 02 FF 00 01 00 01 07 00 03 00 03 07 00 03 08 01 14 08 01 14 FF 00 01 00 01 07 00 03 00 05 07 00 03 07 00 03 08 00 6D 08 00 6D 07 00 BD FF 00 01 00 01 06 00 03 06 07 00 BD 07 00 BD FF 00 01 00 01 07 00 03 00 01 07 00 03 FF 00 01 00 01 07 00 03 00 08 07 00 03 07 00 03 08 00 6D 08 00 6D 07 00 BD 07 00 BD 05 07 00 E0
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @f0g
    @LauncherEventHide
    public void c(@Nullable final f4B p0) {
        public class f79 implements Consumer
        {
            public f7b c;
            
            @Override
            public void accept(final Object o) {
                fez.1x(this, 1004122135, o);
            }
            
            public void c(@NotNull final fe3 p0) {
                // 
                // This method could not be decompiled.
                // 
                // Original Bytecode:
                // 
                //     3: dup            
                //     4: ifnull          2523
                //     7: athrow         
                //     8: aconst_null    
                //     9: getstatic       dev/nuker/pyro/fc.c:I
                //    12: ifeq            2515
                //    15: pop            
                //    16: aconst_null    
                //    17: goto            2507
                //    20: nop            
                //    21: nop            
                //    22: nop            
                //    23: athrow         
                //    24: aload_1        
                //    25: pop            
                //    26: getstatic       dev/nuker/pyro/fc.1:I
                //    29: ifne            37
                //    32: ldc             757913397
                //    34: goto            39
                //    37: ldc             -530129119
                //    39: ldc             -1052915976
                //    41: ixor           
                //    42: lookupswitch {
                //          -334425651: 37
                //          559618521: 68
                //          default: 2444
                //        }
                //    68: aload_1        
                //    69: goto            73
                //    72: athrow         
                //    73: invokevirtual   dev/nuker/pyro/fe3.0:()Ljava/lang/Object;
                //    76: goto            80
                //    79: athrow         
                //    80: checkcast       Ljava/lang/Number;
                //    83: goto            87
                //    86: athrow         
                //    87: invokevirtual   java/lang/Number.floatValue:()F
                //    90: goto            94
                //    93: athrow         
                //    94: bipush          16
                //    96: i2f            
                //    97: fmul           
                //    98: fstore_2       
                //    99: aload_1        
                //   100: getstatic       dev/nuker/pyro/fc.0:I
                //   103: ifgt            111
                //   106: ldc             -1190016710
                //   108: goto            113
                //   111: ldc             985769188
                //   113: ldc             102751895
                //   115: ixor           
                //   116: lookupswitch {
                //          -1089595475: 2474
                //          1578956955: 111
                //          default: 144
                //        }
                //   144: goto            148
                //   147: athrow         
                //   148: invokevirtual   dev/nuker/pyro/fe3.c:()Ljava/lang/Object;
                //   151: goto            155
                //   154: athrow         
                //   155: checkcast       Ljava/lang/Number;
                //   158: getstatic       dev/nuker/pyro/fc.c:I
                //   161: ifne            169
                //   164: ldc             802243722
                //   166: goto            171
                //   169: ldc             1287354865
                //   171: ldc             -817590960
                //   173: ixor           
                //   174: lookupswitch {
                //          -2080377695: 200
                //          -527054374: 169
                //          default: 2472
                //        }
                //   200: goto            204
                //   203: athrow         
                //   204: invokevirtual   java/lang/Number.floatValue:()F
                //   207: goto            211
                //   210: athrow         
                //   211: bipush          16
                //   213: i2f            
                //   214: fmul           
                //   215: getstatic       dev/nuker/pyro/fc.0:I
                //   218: ifgt            226
                //   221: ldc             -1312261042
                //   223: goto            228
                //   226: ldc             1020070071
                //   228: ldc             682947717
                //   230: ixor           
                //   231: lookupswitch {
                //          -1719891765: 2476
                //          1453835410: 226
                //          default: 256
                //        }
                //   256: fstore_3       
                //   257: getstatic       dev/nuker/pyro/fe6.c:Lnet/minecraft/client/renderer/culling/ICamera;
                //   260: getstatic       dev/nuker/pyro/fc.c:I
                //   263: ifne            271
                //   266: ldc             -1420144476
                //   268: goto            273
                //   271: ldc             1640178196
                //   273: ldc             1371058337
                //   275: ixor           
                //   276: lookupswitch {
                //          -85794811: 271
                //          813404853: 304
                //          default: 2492
                //        }
                //   304: aload_0        
                //   305: getstatic       dev/nuker/pyro/fc.0:I
                //   308: ifgt            316
                //   311: ldc             122798570
                //   313: goto            318
                //   316: ldc             36273626
                //   318: ldc             1376685728
                //   320: ixor           
                //   321: lookupswitch {
                //          -215682484: 316
                //          1432309578: 2432
                //          default: 348
                //        }
                //   348: getfield        dev/nuker/pyro/f79.c:Ldev/nuker/pyro/f7b;
                //   351: getstatic       dev/nuker/pyro/fc.c:I
                //   354: ifne            362
                //   357: ldc             1496094753
                //   359: goto            364
                //   362: ldc             1740559264
                //   364: ldc             -533620849
                //   366: ixor           
                //   367: lookupswitch {
                //          -1189277778: 2456
                //          1801950438: 362
                //          default: 392
                //        }
                //   392: goto            396
                //   395: athrow         
                //   396: invokestatic    dev/nuker/pyro/f7b.c:(Ldev/nuker/pyro/f7b;)Lnet/minecraft/client/Minecraft;
                //   399: goto            403
                //   402: athrow         
                //   403: dup            
                //   404: pop            
                //   405: goto            409
                //   408: athrow         
                //   409: invokevirtual   net/minecraft/client/Minecraft.func_175606_aa:()Lnet/minecraft/entity/Entity;
                //   412: goto            416
                //   415: athrow         
                //   416: dup            
                //   417: ifnonnull       431
                //   420: goto            424
                //   423: athrow         
                //   424: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
                //   427: goto            431
                //   430: athrow         
                //   431: getfield        net/minecraft/entity/Entity.field_70165_t:D
                //   434: aload_0        
                //   435: getfield        dev/nuker/pyro/f79.c:Ldev/nuker/pyro/f7b;
                //   438: getstatic       dev/nuker/pyro/fc.c:I
                //   441: ifne            449
                //   444: ldc             -72352005
                //   446: goto            451
                //   449: ldc             682597598
                //   451: ldc             347471677
                //   453: ixor           
                //   454: lookupswitch {
                //          -283508282: 2428
                //          -109848609: 449
                //          default: 480
                //        }
                //   480: goto            484
                //   483: athrow         
                //   484: invokestatic    dev/nuker/pyro/f7b.c:(Ldev/nuker/pyro/f7b;)Lnet/minecraft/client/Minecraft;
                //   487: goto            491
                //   490: athrow         
                //   491: dup            
                //   492: pop            
                //   493: getstatic       dev/nuker/pyro/fc.c:I
                //   496: ifne            504
                //   499: ldc             430894090
                //   501: goto            506
                //   504: ldc             -2127415906
                //   506: ldc             -944854211
                //   508: ixor           
                //   509: lookupswitch {
                //          -570407113: 504
                //          1184669347: 536
                //          default: 2458
                //        }
                //   536: goto            540
                //   539: athrow         
                //   540: invokevirtual   net/minecraft/client/Minecraft.func_175606_aa:()Lnet/minecraft/entity/Entity;
                //   543: goto            547
                //   546: athrow         
                //   547: dup            
                //   548: ifnonnull       603
                //   551: getstatic       dev/nuker/pyro/fc.0:I
                //   554: ifgt            562
                //   557: ldc             -1193515126
                //   559: goto            564
                //   562: ldc             -206494040
                //   564: ldc             -445889545
                //   566: ixor           
                //   567: lookupswitch {
                //          383608159: 592
                //          1571824765: 562
                //          default: 2470
                //        }
                //   592: goto            596
                //   595: athrow         
                //   596: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
                //   599: goto            603
                //   602: athrow         
                //   603: getfield        net/minecraft/entity/Entity.field_70163_u:D
                //   606: getstatic       dev/nuker/pyro/fc.0:I
                //   609: ifgt            617
                //   612: ldc             168259990
                //   614: goto            619
                //   617: ldc             806057864
                //   619: ldc             -1802458745
                //   621: ixor           
                //   622: lookupswitch {
                //          -1634215919: 2482
                //          1975664931: 617
                //          default: 648
                //        }
                //   648: aload_0        
                //   649: getfield        dev/nuker/pyro/f79.c:Ldev/nuker/pyro/f7b;
                //   652: goto            656
                //   655: athrow         
                //   656: invokestatic    dev/nuker/pyro/f7b.c:(Ldev/nuker/pyro/f7b;)Lnet/minecraft/client/Minecraft;
                //   659: goto            663
                //   662: athrow         
                //   663: dup            
                //   664: pop            
                //   665: goto            669
                //   668: athrow         
                //   669: invokevirtual   net/minecraft/client/Minecraft.func_175606_aa:()Lnet/minecraft/entity/Entity;
                //   672: goto            676
                //   675: athrow         
                //   676: dup            
                //   677: ifnonnull       735
                //   680: getstatic       dev/nuker/pyro/fc.1:I
                //   683: ifne            691
                //   686: ldc             2056719050
                //   688: goto            693
                //   691: ldc             -501708879
                //   693: ldc             1636087536
                //   695: ixor           
                //   696: lookupswitch {
                //          -2086915775: 724
                //          454278202: 691
                //          default: 2452
                //        }
                //   724: goto            728
                //   727: athrow         
                //   728: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
                //   731: goto            735
                //   734: athrow         
                //   735: getfield        net/minecraft/entity/Entity.field_70161_v:D
                //   738: goto            742
                //   741: athrow         
                //   742: invokeinterface net/minecraft/client/renderer/culling/ICamera.func_78547_a:(DDD)V
                //   747: goto            751
                //   750: athrow         
                //   751: new             Lnet/minecraft/util/math/AxisAlignedBB;
                //   754: dup            
                //   755: fload_2        
                //   756: f2d            
                //   757: aload_0        
                //   758: getfield        dev/nuker/pyro/f79.c:Ldev/nuker/pyro/f7b;
                //   761: goto            765
                //   764: athrow         
                //   765: invokestatic    dev/nuker/pyro/f7b.c:(Ldev/nuker/pyro/f7b;)Lnet/minecraft/client/Minecraft;
                //   768: goto            772
                //   771: athrow         
                //   772: dup            
                //   773: pop            
                //   774: goto            778
                //   777: athrow         
                //   778: invokevirtual   net/minecraft/client/Minecraft.func_175598_ae:()Lnet/minecraft/client/renderer/entity/RenderManager;
                //   781: goto            785
                //   784: athrow         
                //   785: getfield        net/minecraft/client/renderer/entity/RenderManager.field_78730_l:D
                //   788: dsub           
                //   789: iconst_0       
                //   790: i2d            
                //   791: getstatic       dev/nuker/pyro/fc.0:I
                //   794: ifgt            802
                //   797: ldc             1705523640
                //   799: goto            804
                //   802: ldc             1145330058
                //   804: ldc             -927481120
                //   806: ixor           
                //   807: lookupswitch {
                //          -1930192022: 832
                //          -1390412968: 802
                //          default: 2462
                //        }
                //   832: aload_0        
                //   833: getfield        dev/nuker/pyro/f79.c:Ldev/nuker/pyro/f7b;
                //   836: goto            840
                //   839: athrow         
                //   840: invokestatic    dev/nuker/pyro/f7b.c:(Ldev/nuker/pyro/f7b;)Lnet/minecraft/client/Minecraft;
                //   843: goto            847
                //   846: athrow         
                //   847: dup            
                //   848: pop            
                //   849: goto            853
                //   852: athrow         
                //   853: invokevirtual   net/minecraft/client/Minecraft.func_175598_ae:()Lnet/minecraft/client/renderer/entity/RenderManager;
                //   856: goto            860
                //   859: athrow         
                //   860: getfield        net/minecraft/client/renderer/entity/RenderManager.field_78731_m:D
                //   863: dsub           
                //   864: fload_3        
                //   865: f2d            
                //   866: aload_0        
                //   867: getfield        dev/nuker/pyro/f79.c:Ldev/nuker/pyro/f7b;
                //   870: goto            874
                //   873: athrow         
                //   874: invokestatic    dev/nuker/pyro/f7b.c:(Ldev/nuker/pyro/f7b;)Lnet/minecraft/client/Minecraft;
                //   877: goto            881
                //   880: athrow         
                //   881: dup            
                //   882: pop            
                //   883: getstatic       dev/nuker/pyro/fc.1:I
                //   886: ifne            894
                //   889: ldc             1285133864
                //   891: goto            896
                //   894: ldc             -1722953271
                //   896: ldc             942511901
                //   898: ixor           
                //   899: lookupswitch {
                //          1957953845: 2490
                //          2028271609: 894
                //          default: 924
                //        }
                //   924: goto            928
                //   927: athrow         
                //   928: invokevirtual   net/minecraft/client/Minecraft.func_175598_ae:()Lnet/minecraft/client/renderer/entity/RenderManager;
                //   931: goto            935
                //   934: athrow         
                //   935: getstatic       dev/nuker/pyro/fc.1:I
                //   938: ifne            946
                //   941: ldc             1360910179
                //   943: goto            948
                //   946: ldc             767417340
                //   948: ldc             -221556101
                //   950: ixor           
                //   951: lookupswitch {
                //          -1546222312: 2494
                //          -98273457: 946
                //          default: 976
                //        }
                //   976: getfield        net/minecraft/client/renderer/entity/RenderManager.field_78728_n:D
                //   979: dsub           
                //   980: getstatic       dev/nuker/pyro/fc.0:I
                //   983: ifgt            991
                //   986: ldc             1942614605
                //   988: goto            993
                //   991: ldc             -1128682551
                //   993: ldc             1507763456
                //   995: ixor           
                //   996: lookupswitch {
                //          -446230839: 1024
                //          706172749: 991
                //          default: 2430
                //        }
                //  1024: fload_2        
                //  1025: bipush          16
                //  1027: i2f            
                //  1028: fadd           
                //  1029: f2d            
                //  1030: getstatic       dev/nuker/pyro/fc.0:I
                //  1033: ifgt            1041
                //  1036: ldc             -1261709149
                //  1038: goto            1043
                //  1041: ldc             -1575175954
                //  1043: ldc             524993479
                //  1045: ixor           
                //  1046: lookupswitch {
                //          -1417602204: 1041
                //          -1118405847: 1072
                //          default: 2484
                //        }
                //  1072: aload_0        
                //  1073: getfield        dev/nuker/pyro/f79.c:Ldev/nuker/pyro/f7b;
                //  1076: goto            1080
                //  1079: athrow         
                //  1080: invokestatic    dev/nuker/pyro/f7b.c:(Ldev/nuker/pyro/f7b;)Lnet/minecraft/client/Minecraft;
                //  1083: goto            1087
                //  1086: athrow         
                //  1087: dup            
                //  1088: pop            
                //  1089: goto            1093
                //  1092: athrow         
                //  1093: invokevirtual   net/minecraft/client/Minecraft.func_175598_ae:()Lnet/minecraft/client/renderer/entity/RenderManager;
                //  1096: goto            1100
                //  1099: athrow         
                //  1100: getfield        net/minecraft/client/renderer/entity/RenderManager.field_78730_l:D
                //  1103: dsub           
                //  1104: iconst_1       
                //  1105: i2d            
                //  1106: getstatic       dev/nuker/pyro/fc.c:I
                //  1109: ifne            1117
                //  1112: ldc             -1408763229
                //  1114: goto            1119
                //  1117: ldc             488317791
                //  1119: ldc             -1684152690
                //  1121: ixor           
                //  1122: lookupswitch {
                //          -2037973551: 1148
                //          932848685: 1117
                //          default: 2450
                //        }
                //  1148: aload_0        
                //  1149: getfield        dev/nuker/pyro/f79.c:Ldev/nuker/pyro/f7b;
                //  1152: goto            1156
                //  1155: athrow         
                //  1156: invokestatic    dev/nuker/pyro/f7b.c:(Ldev/nuker/pyro/f7b;)Lnet/minecraft/client/Minecraft;
                //  1159: goto            1163
                //  1162: athrow         
                //  1163: dup            
                //  1164: pop            
                //  1165: goto            1169
                //  1168: athrow         
                //  1169: invokevirtual   net/minecraft/client/Minecraft.func_175598_ae:()Lnet/minecraft/client/renderer/entity/RenderManager;
                //  1172: goto            1176
                //  1175: athrow         
                //  1176: getfield        net/minecraft/client/renderer/entity/RenderManager.field_78731_m:D
                //  1179: dsub           
                //  1180: getstatic       dev/nuker/pyro/fc.c:I
                //  1183: ifne            1191
                //  1186: ldc             1348536303
                //  1188: goto            1193
                //  1191: ldc             -1194514244
                //  1193: ldc             1878169594
                //  1195: ixor           
                //  1196: lookupswitch {
                //          9764712: 1191
                //          1066635285: 2436
                //          default: 1224
                //        }
                //  1224: fload_3        
                //  1225: bipush          16
                //  1227: i2f            
                //  1228: fadd           
                //  1229: f2d            
                //  1230: aload_0        
                //  1231: getfield        dev/nuker/pyro/f79.c:Ldev/nuker/pyro/f7b;
                //  1234: goto            1238
                //  1237: athrow         
                //  1238: invokestatic    dev/nuker/pyro/f7b.c:(Ldev/nuker/pyro/f7b;)Lnet/minecraft/client/Minecraft;
                //  1241: goto            1245
                //  1244: athrow         
                //  1245: dup            
                //  1246: pop            
                //  1247: getstatic       dev/nuker/pyro/fc.1:I
                //  1250: ifne            1258
                //  1253: ldc             340009414
                //  1255: goto            1260
                //  1258: ldc             1678141861
                //  1260: ldc             1801311713
                //  1262: ixor           
                //  1263: lookupswitch {
                //          -1915077644: 1258
                //          2132407335: 2480
                //          default: 1288
                //        }
                //  1288: goto            1292
                //  1291: athrow         
                //  1292: invokevirtual   net/minecraft/client/Minecraft.func_175598_ae:()Lnet/minecraft/client/renderer/entity/RenderManager;
                //  1295: goto            1299
                //  1298: athrow         
                //  1299: getfield        net/minecraft/client/renderer/entity/RenderManager.field_78728_n:D
                //  1302: dsub           
                //  1303: getstatic       dev/nuker/pyro/fc.1:I
                //  1306: ifne            1314
                //  1309: ldc             -878401188
                //  1311: goto            1316
                //  1314: ldc             -1650322284
                //  1316: ldc             -2028035529
                //  1318: ixor           
                //  1319: lookupswitch {
                //          -1862517418: 1314
                //          1287261035: 2440
                //          default: 1344
                //        }
                //  1344: goto            1348
                //  1347: athrow         
                //  1348: invokespecial   net/minecraft/util/math/AxisAlignedBB.<init>:(DDDDDD)V
                //  1351: goto            1355
                //  1354: athrow         
                //  1355: astore          4
                //  1357: new             Lnet/minecraft/util/math/AxisAlignedBB;
                //  1360: dup            
                //  1361: getstatic       dev/nuker/pyro/fc.1:I
                //  1364: ifne            1372
                //  1367: ldc             1578295970
                //  1369: goto            1374
                //  1372: ldc             816988524
                //  1374: ldc             1752018461
                //  1376: ixor           
                //  1377: lookupswitch {
                //          113691873: 1372
                //          914312383: 2442
                //          default: 1404
                //        }
                //  1404: fload_2        
                //  1405: f2d            
                //  1406: dconst_0       
                //  1407: getstatic       dev/nuker/pyro/fc.c:I
                //  1410: ifne            1418
                //  1413: ldc             1978837563
                //  1415: goto            1420
                //  1418: ldc             -233492664
                //  1420: ldc             1477050034
                //  1422: ixor           
                //  1423: lookupswitch {
                //          -1440951814: 1448
                //          771445897: 1418
                //          default: 2464
                //        }
                //  1448: fload_3        
                //  1449: f2d            
                //  1450: fload_2        
                //  1451: bipush          16
                //  1453: i2f            
                //  1454: fadd           
                //  1455: f2d            
                //  1456: dconst_1       
                //  1457: fload_3        
                //  1458: bipush          16
                //  1460: i2f            
                //  1461: fadd           
                //  1462: f2d            
                //  1463: goto            1467
                //  1466: athrow         
                //  1467: invokespecial   net/minecraft/util/math/AxisAlignedBB.<init>:(DDDDDD)V
                //  1470: goto            1474
                //  1473: athrow         
                //  1474: astore          5
                //  1476: getstatic       dev/nuker/pyro/fe6.c:Lnet/minecraft/client/renderer/culling/ICamera;
                //  1479: aload           5
                //  1481: goto            1485
                //  1484: athrow         
                //  1485: invokeinterface net/minecraft/client/renderer/culling/ICamera.func_78546_a:(Lnet/minecraft/util/math/AxisAlignedBB;)Z
                //  1490: goto            1494
                //  1493: athrow         
                //  1494: ifeq            2427
                //  1497: goto            1501
                //  1500: athrow         
                //  1501: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179094_E:()V
                //  1504: goto            1508
                //  1507: athrow         
                //  1508: getstatic       dev/nuker/pyro/fc.c:I
                //  1511: ifne            1519
                //  1514: ldc             921034100
                //  1516: goto            1521
                //  1519: ldc             -1237431320
                //  1521: ldc             20370147
                //  1523: ixor           
                //  1524: lookupswitch {
                //          -1224173301: 1552
                //          936578967: 1519
                //          default: 2454
                //        }
                //  1552: goto            1556
                //  1555: athrow         
                //  1556: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179147_l:()V
                //  1559: goto            1563
                //  1562: athrow         
                //  1563: goto            1567
                //  1566: athrow         
                //  1567: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179097_i:()V
                //  1570: goto            1574
                //  1573: athrow         
                //  1574: sipush          770
                //  1577: sipush          771
                //  1580: iconst_0       
                //  1581: iconst_1       
                //  1582: goto            1586
                //  1585: athrow         
                //  1586: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179120_a:(IIII)V
                //  1589: goto            1593
                //  1592: athrow         
                //  1593: getstatic       dev/nuker/pyro/fc.0:I
                //  1596: ifgt            1604
                //  1599: ldc             -1668117682
                //  1601: goto            1606
                //  1604: ldc             415755808
                //  1606: ldc             120003753
                //  1608: ixor           
                //  1609: lookupswitch {
                //          -1788206025: 1604
                //          -1682597913: 2486
                //          default: 1636
                //        }
                //  1636: goto            1640
                //  1639: athrow         
                //  1640: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179090_x:()V
                //  1643: goto            1647
                //  1646: athrow         
                //  1647: iconst_0       
                //  1648: goto            1652
                //  1651: athrow         
                //  1652: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179132_a:(Z)V
                //  1655: goto            1659
                //  1658: athrow         
                //  1659: sipush          2848
                //  1662: goto            1666
                //  1665: athrow         
                //  1666: invokestatic    org/lwjgl/opengl/GL11.glEnable:(I)V
                //  1669: goto            1673
                //  1672: athrow         
                //  1673: sipush          3154
                //  1676: sipush          4354
                //  1679: getstatic       dev/nuker/pyro/fc.0:I
                //  1682: ifgt            1690
                //  1685: ldc             -294333964
                //  1687: goto            1692
                //  1690: ldc             703628804
                //  1692: ldc             832413253
                //  1694: ixor           
                //  1695: lookupswitch {
                //          -538357839: 1690
                //          409802817: 1720
                //          default: 2434
                //        }
                //  1720: goto            1724
                //  1723: athrow         
                //  1724: invokestatic    org/lwjgl/opengl/GL11.glHint:(II)V
                //  1727: goto            1731
                //  1730: athrow         
                //  1731: ldc_w           1.5
                //  1734: goto            1738
                //  1737: athrow         
                //  1738: invokestatic    org/lwjgl/opengl/GL11.glLineWidth:(F)V
                //  1741: goto            1745
                //  1744: athrow         
                //  1745: aload           4
                //  1747: getstatic       dev/nuker/pyro/fc.c:I
                //  1750: ifne            1759
                //  1753: ldc_w           1667711075
                //  1756: goto            1762
                //  1759: ldc_w           -1195029794
                //  1762: ldc_w           55314381
                //  1765: ixor           
                //  1766: lookupswitch {
                //          231382492: 1759
                //          1613449134: 2496
                //          default: 1792
                //        }
                //  1792: getfield        net/minecraft/util/math/AxisAlignedBB.field_72340_a:D
                //  1795: aload           4
                //  1797: getfield        net/minecraft/util/math/AxisAlignedBB.field_72338_b:D
                //  1800: getstatic       dev/nuker/pyro/fc.1:I
                //  1803: ifne            1812
                //  1806: ldc_w           226871009
                //  1809: goto            1815
                //  1812: ldc_w           19033488
                //  1815: ldc_w           -1952287331
                //  1818: ixor           
                //  1819: lookupswitch {
                //          -2044218500: 2460
                //          -1389844729: 1812
                //          default: 1844
                //        }
                //  1844: aload           4
                //  1846: getstatic       dev/nuker/pyro/fc.1:I
                //  1849: ifne            1858
                //  1852: ldc_w           1527471489
                //  1855: goto            1861
                //  1858: ldc_w           -130946761
                //  1861: ldc_w           -1903587329
                //  1864: ixor           
                //  1865: lookupswitch {
                //          -712846722: 1858
                //          1991796424: 1892
                //          default: 2438
                //        }
                //  1892: getfield        net/minecraft/util/math/AxisAlignedBB.field_72339_c:D
                //  1895: getstatic       dev/nuker/pyro/fc.1:I
                //  1898: ifne            1907
                //  1901: ldc_w           -2108277807
                //  1904: goto            1910
                //  1907: ldc_w           1803528451
                //  1910: ldc_w           436812958
                //  1913: ixor           
                //  1914: lookupswitch {
                //          -1738602673: 2468
                //          432442735: 1907
                //          default: 1940
                //        }
                //  1940: aload           4
                //  1942: getstatic       dev/nuker/pyro/fc.c:I
                //  1945: ifne            1954
                //  1948: ldc_w           -1905302290
                //  1951: goto            1957
                //  1954: ldc_w           -178259331
                //  1957: ldc_w           1800869217
                //  1960: ixor           
                //  1961: lookupswitch {
                //          -449285745: 2478
                //          221921555: 1954
                //          default: 1988
                //        }
                //  1988: getfield        net/minecraft/util/math/AxisAlignedBB.field_72336_d:D
                //  1991: aload           4
                //  1993: getfield        net/minecraft/util/math/AxisAlignedBB.field_72338_b:D
                //  1996: aload           4
                //  1998: getfield        net/minecraft/util/math/AxisAlignedBB.field_72334_f:D
                //  2001: aload_0        
                //  2002: getfield        dev/nuker/pyro/f79.c:Ldev/nuker/pyro/f7b;
                //  2005: goto            2009
                //  2008: athrow         
                //  2009: invokevirtual   dev/nuker/pyro/f7b.c:()Ldev/nuker/pyro/f0l;
                //  2012: goto            2016
                //  2015: athrow         
                //  2016: goto            2020
                //  2019: athrow         
                //  2020: invokevirtual   dev/nuker/pyro/f0l.c:()Ljava/lang/Object;
                //  2023: goto            2027
                //  2026: athrow         
                //  2027: checkcast       Ldev/nuker/pyro/f00;
                //  2030: goto            2034
                //  2033: athrow         
                //  2034: invokevirtual   dev/nuker/pyro/f00.7:()F
                //  2037: goto            2041
                //  2040: athrow         
                //  2041: aload_0        
                //  2042: getfield        dev/nuker/pyro/f79.c:Ldev/nuker/pyro/f7b;
                //  2045: goto            2049
                //  2048: athrow         
                //  2049: invokevirtual   dev/nuker/pyro/f7b.c:()Ldev/nuker/pyro/f0l;
                //  2052: goto            2056
                //  2055: athrow         
                //  2056: goto            2060
                //  2059: athrow         
                //  2060: invokevirtual   dev/nuker/pyro/f0l.c:()Ljava/lang/Object;
                //  2063: goto            2067
                //  2066: athrow         
                //  2067: checkcast       Ldev/nuker/pyro/f00;
                //  2070: goto            2074
                //  2073: athrow         
                //  2074: invokevirtual   dev/nuker/pyro/f00.g:()F
                //  2077: goto            2081
                //  2080: athrow         
                //  2081: aload_0        
                //  2082: getfield        dev/nuker/pyro/f79.c:Ldev/nuker/pyro/f7b;
                //  2085: goto            2089
                //  2088: athrow         
                //  2089: invokevirtual   dev/nuker/pyro/f7b.c:()Ldev/nuker/pyro/f0l;
                //  2092: goto            2096
                //  2095: athrow         
                //  2096: goto            2100
                //  2099: athrow         
                //  2100: invokevirtual   dev/nuker/pyro/f0l.c:()Ljava/lang/Object;
                //  2103: goto            2107
                //  2106: athrow         
                //  2107: checkcast       Ldev/nuker/pyro/f00;
                //  2110: goto            2114
                //  2113: athrow         
                //  2114: invokevirtual   dev/nuker/pyro/f00.2:()F
                //  2117: goto            2121
                //  2120: athrow         
                //  2121: getstatic       dev/nuker/pyro/fc.0:I
                //  2124: ifgt            2133
                //  2127: ldc_w           -1409763072
                //  2130: goto            2136
                //  2133: ldc_w           269885120
                //  2136: ldc_w           -364840763
                //  2139: ixor           
                //  2140: lookupswitch {
                //          -94968315: 2168
                //          1102594501: 2133
                //          default: 2466
                //        }
                //  2168: aload_0        
                //  2169: getfield        dev/nuker/pyro/f79.c:Ldev/nuker/pyro/f7b;
                //  2172: goto            2176
                //  2175: athrow         
                //  2176: invokevirtual   dev/nuker/pyro/f7b.c:()Ldev/nuker/pyro/f0l;
                //  2179: goto            2183
                //  2182: athrow         
                //  2183: getstatic       dev/nuker/pyro/fc.0:I
                //  2186: ifgt            2195
                //  2189: ldc_w           -436097815
                //  2192: goto            2198
                //  2195: ldc_w           1276137317
                //  2198: ldc_w           -1663160964
                //  2201: ixor           
                //  2202: lookupswitch {
                //          -1842066412: 2195
                //          2061468053: 2448
                //          default: 2228
                //        }
                //  2228: goto            2232
                //  2231: athrow         
                //  2232: invokevirtual   dev/nuker/pyro/f0l.c:()Ljava/lang/Object;
                //  2235: goto            2239
                //  2238: athrow         
                //  2239: checkcast       Ldev/nuker/pyro/f00;
                //  2242: getstatic       dev/nuker/pyro/fc.1:I
                //  2245: ifne            2254
                //  2248: ldc_w           338188709
                //  2251: goto            2257
                //  2254: ldc_w           -506068552
                //  2257: ldc_w           -669949820
                //  2260: ixor           
                //  2261: lookupswitch {
                //          -868665055: 2254
                //          969367868: 2288
                //          default: 2488
                //        }
                //  2288: goto            2292
                //  2291: athrow         
                //  2292: invokevirtual   dev/nuker/pyro/f00.9:()F
                //  2295: goto            2299
                //  2298: athrow         
                //  2299: goto            2303
                //  2302: athrow         
                //  2303: invokestatic    net/minecraft/client/renderer/RenderGlobal.func_189695_b:(DDDDDDFFFF)V
                //  2306: goto            2310
                //  2309: athrow         
                //  2310: sipush          2848
                //  2313: goto            2317
                //  2316: athrow         
                //  2317: invokestatic    org/lwjgl/opengl/GL11.glDisable:(I)V
                //  2320: goto            2324
                //  2323: athrow         
                //  2324: iconst_1       
                //  2325: goto            2329
                //  2328: athrow         
                //  2329: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179132_a:(Z)V
                //  2332: goto            2336
                //  2335: athrow         
                //  2336: goto            2340
                //  2339: athrow         
                //  2340: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179126_j:()V
                //  2343: goto            2347
                //  2346: athrow         
                //  2347: goto            2351
                //  2350: athrow         
                //  2351: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179098_w:()V
                //  2354: goto            2358
                //  2357: athrow         
                //  2358: goto            2362
                //  2361: athrow         
                //  2362: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179084_k:()V
                //  2365: goto            2369
                //  2368: athrow         
                //  2369: getstatic       dev/nuker/pyro/fc.c:I
                //  2372: ifne            2381
                //  2375: ldc_w           1165757120
                //  2378: goto            2384
                //  2381: ldc_w           1681085388
                //  2384: ldc_w           -390082971
                //  2387: ixor           
                //  2388: lookupswitch {
                //          -1936941655: 2416
                //          -1379679067: 2381
                //          default: 2446
                //        }
                //  2416: goto            2420
                //  2419: athrow         
                //  2420: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179121_F:()V
                //  2423: goto            2427
                //  2426: athrow         
                //  2427: return         
                //  2428: aconst_null    
                //  2429: athrow         
                //  2430: aconst_null    
                //  2431: athrow         
                //  2432: aconst_null    
                //  2433: athrow         
                //  2434: aconst_null    
                //  2435: athrow         
                //  2436: aconst_null    
                //  2437: athrow         
                //  2438: aconst_null    
                //  2439: athrow         
                //  2440: aconst_null    
                //  2441: athrow         
                //  2442: aconst_null    
                //  2443: athrow         
                //  2444: aconst_null    
                //  2445: athrow         
                //  2446: aconst_null    
                //  2447: athrow         
                //  2448: aconst_null    
                //  2449: athrow         
                //  2450: aconst_null    
                //  2451: athrow         
                //  2452: aconst_null    
                //  2453: athrow         
                //  2454: aconst_null    
                //  2455: athrow         
                //  2456: aconst_null    
                //  2457: athrow         
                //  2458: aconst_null    
                //  2459: athrow         
                //  2460: aconst_null    
                //  2461: athrow         
                //  2462: aconst_null    
                //  2463: athrow         
                //  2464: aconst_null    
                //  2465: athrow         
                //  2466: aconst_null    
                //  2467: athrow         
                //  2468: aconst_null    
                //  2469: athrow         
                //  2470: aconst_null    
                //  2471: athrow         
                //  2472: aconst_null    
                //  2473: athrow         
                //  2474: aconst_null    
                //  2475: athrow         
                //  2476: aconst_null    
                //  2477: athrow         
                //  2478: aconst_null    
                //  2479: athrow         
                //  2480: aconst_null    
                //  2481: athrow         
                //  2482: aconst_null    
                //  2483: athrow         
                //  2484: aconst_null    
                //  2485: athrow         
                //  2486: aconst_null    
                //  2487: athrow         
                //  2488: aconst_null    
                //  2489: athrow         
                //  2490: aconst_null    
                //  2491: athrow         
                //  2492: aconst_null    
                //  2493: athrow         
                //  2494: aconst_null    
                //  2495: athrow         
                //  2496: aconst_null    
                //  2497: athrow         
                //  2498: pop            
                //  2499: goto            24
                //  2502: pop            
                //  2503: aconst_null    
                //  2504: goto            2498
                //  2507: dup            
                //  2508: ifnull          2498
                //  2511: checkcast       Ljava/lang/Throwable;
                //  2514: athrow         
                //  2515: dup            
                //  2516: ifnull          2502
                //  2519: checkcast       Ljava/lang/Throwable;
                //  2522: athrow         
                //  2523: aconst_null    
                //  2524: athrow         
                //    StackMapTable: 01 79 43 07 00 3F 04 FF 00 0B 00 00 00 01 07 00 3F FD 00 03 07 00 03 07 00 47 0C 41 01 1C 43 07 00 3F 40 07 00 47 45 07 00 3F 40 07 00 05 45 07 00 22 40 07 00 4D 45 07 00 3F 40 02 FF 00 10 00 03 07 00 03 07 00 47 02 00 01 07 00 47 FF 00 01 00 03 07 00 03 07 00 47 02 00 02 07 00 47 01 5E 07 00 47 42 07 00 3F 40 07 00 47 45 07 00 3F 40 07 00 05 4D 07 00 4D FF 00 01 00 03 07 00 03 07 00 47 02 00 02 07 00 4D 01 5C 07 00 4D FF 00 02 00 00 00 01 07 00 3F FF 00 00 00 03 07 00 03 07 00 47 02 00 01 07 00 4D 45 07 00 3F 40 02 4E 02 FF 00 01 00 03 07 00 03 07 00 47 02 00 02 02 01 5B 02 FF 00 0E 00 04 07 00 03 07 00 47 02 02 00 01 07 00 9A FF 00 01 00 04 07 00 03 07 00 47 02 02 00 02 07 00 9A 01 5E 07 00 9A FF 00 0B 00 04 07 00 03 07 00 47 02 02 00 02 07 00 9A 07 00 03 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 03 07 00 9A 07 00 03 01 FF 00 1D 00 04 07 00 03 07 00 47 02 02 00 02 07 00 9A 07 00 03 FF 00 0D 00 04 07 00 03 07 00 47 02 02 00 02 07 00 9A 07 00 09 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 03 07 00 9A 07 00 09 01 FF 00 1B 00 04 07 00 03 07 00 47 02 02 00 02 07 00 9A 07 00 09 42 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 02 07 00 9A 07 00 09 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 02 07 00 9A 07 00 73 44 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 02 07 00 9A 07 00 73 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 02 07 00 9A 07 00 7F 46 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 02 07 00 9A 07 00 7F 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 02 07 00 9A 07 00 7F FF 00 11 00 04 07 00 03 07 00 47 02 02 00 03 07 00 9A 03 07 00 09 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 04 07 00 9A 03 07 00 09 01 FF 00 1C 00 04 07 00 03 07 00 47 02 02 00 03 07 00 9A 03 07 00 09 42 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 03 07 00 9A 03 07 00 09 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 03 07 00 9A 03 07 00 73 FF 00 0C 00 04 07 00 03 07 00 47 02 02 00 03 07 00 9A 03 07 00 73 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 04 07 00 9A 03 07 00 73 01 FF 00 1D 00 04 07 00 03 07 00 47 02 02 00 03 07 00 9A 03 07 00 73 42 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 03 07 00 9A 03 07 00 73 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 03 07 00 9A 03 07 00 7F FF 00 0E 00 04 07 00 03 07 00 47 02 02 00 03 07 00 9A 03 07 00 7F FF 00 01 00 04 07 00 03 07 00 47 02 02 00 04 07 00 9A 03 07 00 7F 01 FF 00 1B 00 04 07 00 03 07 00 47 02 02 00 03 07 00 9A 03 07 00 7F FF 00 02 00 00 00 01 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 03 07 00 9A 03 07 00 7F 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 03 07 00 9A 03 07 00 7F FF 00 0D 00 04 07 00 03 07 00 47 02 02 00 03 07 00 9A 03 03 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 04 07 00 9A 03 03 01 FF 00 1C 00 04 07 00 03 07 00 47 02 02 00 03 07 00 9A 03 03 46 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 04 07 00 9A 03 03 07 00 09 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 04 07 00 9A 03 03 07 00 73 44 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 04 07 00 9A 03 03 07 00 73 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 04 07 00 9A 03 03 07 00 7F FF 00 0E 00 04 07 00 03 07 00 47 02 02 00 04 07 00 9A 03 03 07 00 7F FF 00 01 00 04 07 00 03 07 00 47 02 02 00 05 07 00 9A 03 03 07 00 7F 01 FF 00 1E 00 04 07 00 03 07 00 47 02 02 00 04 07 00 9A 03 03 07 00 7F 42 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 04 07 00 9A 03 03 07 00 7F 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 04 07 00 9A 03 03 07 00 7F 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 04 07 00 9A 03 03 03 47 07 00 3F 00 4C 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 04 08 02 EF 08 02 EF 03 07 00 09 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 04 08 02 EF 08 02 EF 03 07 00 73 44 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 04 08 02 EF 08 02 EF 03 07 00 73 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 04 08 02 EF 08 02 EF 03 07 00 A6 FF 00 10 00 04 07 00 03 07 00 47 02 02 00 04 08 02 EF 08 02 EF 03 03 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 05 08 02 EF 08 02 EF 03 03 01 FF 00 1B 00 04 07 00 03 07 00 47 02 02 00 04 08 02 EF 08 02 EF 03 03 FF 00 06 00 00 00 01 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 05 08 02 EF 08 02 EF 03 03 07 00 09 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 05 08 02 EF 08 02 EF 03 03 07 00 73 44 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 05 08 02 EF 08 02 EF 03 03 07 00 73 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 05 08 02 EF 08 02 EF 03 03 07 00 A6 FF 00 0C 00 00 00 01 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 06 08 02 EF 08 02 EF 03 03 03 07 00 09 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 06 08 02 EF 08 02 EF 03 03 03 07 00 73 FF 00 0C 00 04 07 00 03 07 00 47 02 02 00 06 08 02 EF 08 02 EF 03 03 03 07 00 73 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 07 08 02 EF 08 02 EF 03 03 03 07 00 73 01 FF 00 1B 00 04 07 00 03 07 00 47 02 02 00 06 08 02 EF 08 02 EF 03 03 03 07 00 73 42 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 06 08 02 EF 08 02 EF 03 03 03 07 00 73 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 06 08 02 EF 08 02 EF 03 03 03 07 00 A6 FF 00 0A 00 04 07 00 03 07 00 47 02 02 00 06 08 02 EF 08 02 EF 03 03 03 07 00 A6 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 07 08 02 EF 08 02 EF 03 03 03 07 00 A6 01 FF 00 1B 00 04 07 00 03 07 00 47 02 02 00 06 08 02 EF 08 02 EF 03 03 03 07 00 A6 FF 00 0E 00 04 07 00 03 07 00 47 02 02 00 05 08 02 EF 08 02 EF 03 03 03 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 06 08 02 EF 08 02 EF 03 03 03 01 FF 00 1E 00 04 07 00 03 07 00 47 02 02 00 05 08 02 EF 08 02 EF 03 03 03 FF 00 10 00 04 07 00 03 07 00 47 02 02 00 06 08 02 EF 08 02 EF 03 03 03 03 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 07 08 02 EF 08 02 EF 03 03 03 03 01 FF 00 1C 00 04 07 00 03 07 00 47 02 02 00 06 08 02 EF 08 02 EF 03 03 03 03 46 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 07 08 02 EF 08 02 EF 03 03 03 03 07 00 09 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 07 08 02 EF 08 02 EF 03 03 03 03 07 00 73 44 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 07 08 02 EF 08 02 EF 03 03 03 03 07 00 73 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 07 08 02 EF 08 02 EF 03 03 03 03 07 00 A6 FF 00 10 00 04 07 00 03 07 00 47 02 02 00 07 08 02 EF 08 02 EF 03 03 03 03 03 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 08 08 02 EF 08 02 EF 03 03 03 03 03 01 FF 00 1C 00 04 07 00 03 07 00 47 02 02 00 07 08 02 EF 08 02 EF 03 03 03 03 03 FF 00 06 00 00 00 01 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 08 08 02 EF 08 02 EF 03 03 03 03 03 07 00 09 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 08 08 02 EF 08 02 EF 03 03 03 03 03 07 00 73 44 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 08 08 02 EF 08 02 EF 03 03 03 03 03 07 00 73 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 08 08 02 EF 08 02 EF 03 03 03 03 03 07 00 A6 FF 00 0E 00 04 07 00 03 07 00 47 02 02 00 07 08 02 EF 08 02 EF 03 03 03 03 03 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 08 08 02 EF 08 02 EF 03 03 03 03 03 01 FF 00 1E 00 04 07 00 03 07 00 47 02 02 00 07 08 02 EF 08 02 EF 03 03 03 03 03 4C 07 00 2A FF 00 00 00 04 07 00 03 07 00 47 02 02 00 09 08 02 EF 08 02 EF 03 03 03 03 03 03 07 00 09 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 09 08 02 EF 08 02 EF 03 03 03 03 03 03 07 00 73 FF 00 0C 00 04 07 00 03 07 00 47 02 02 00 09 08 02 EF 08 02 EF 03 03 03 03 03 03 07 00 73 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 0A 08 02 EF 08 02 EF 03 03 03 03 03 03 07 00 73 01 FF 00 1B 00 04 07 00 03 07 00 47 02 02 00 09 08 02 EF 08 02 EF 03 03 03 03 03 03 07 00 73 FF 00 02 00 00 00 01 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 09 08 02 EF 08 02 EF 03 03 03 03 03 03 07 00 73 45 07 00 3F FF 00 00 00 04 07 00 03 07 00 47 02 02 00 09 08 02 EF 08 02 EF 03 03 03 03 03 03 07 00 A6 FF 00 0E 00 04 07 00 03 07 00 47 02 02 00 08 08 02 EF 08 02 EF 03 03 03 03 03 03 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 09 08 02 EF 08 02 EF 03 03 03 03 03 03 01 FF 00 1B 00 04 07 00 03 07 00 47 02 02 00 08 08 02 EF 08 02 EF 03 03 03 03 03 03 42 07 00 20 FF 00 00 00 04 07 00 03 07 00 47 02 02 00 08 08 02 EF 08 02 EF 03 03 03 03 03 03 45 07 00 3F 40 07 00 A0 FF 00 10 00 05 07 00 03 07 00 47 02 02 07 00 A0 00 02 08 05 4D 08 05 4D FF 00 01 00 05 07 00 03 07 00 47 02 02 07 00 A0 00 03 08 05 4D 08 05 4D 01 FF 00 1D 00 05 07 00 03 07 00 47 02 02 07 00 A0 00 02 08 05 4D 08 05 4D FF 00 0D 00 05 07 00 03 07 00 47 02 02 07 00 A0 00 04 08 05 4D 08 05 4D 03 03 FF 00 01 00 05 07 00 03 07 00 47 02 02 07 00 A0 00 05 08 05 4D 08 05 4D 03 03 01 FF 00 1B 00 05 07 00 03 07 00 47 02 02 07 00 A0 00 04 08 05 4D 08 05 4D 03 03 51 07 00 3F FF 00 00 00 05 07 00 03 07 00 47 02 02 07 00 A0 00 08 08 05 4D 08 05 4D 03 03 03 03 03 03 45 07 00 3F 40 07 00 A0 FF 00 09 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 01 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 02 07 00 9A 07 00 A0 47 07 00 3F 40 01 45 07 00 3F 00 45 07 00 3F 00 0A 41 01 1E 42 07 00 3F 00 45 07 00 3F 00 FF 00 02 00 00 00 01 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 00 45 07 00 3F 00 4A 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 04 01 01 01 01 45 07 00 3F 00 0A 41 01 1D 42 07 00 3F 00 45 07 00 3F 00 FF 00 03 00 00 00 01 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 01 01 45 07 00 3F 00 45 07 00 22 40 01 45 07 00 3F 00 FF 00 10 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 02 01 01 FF 00 01 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 03 01 01 01 FF 00 1B 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 02 01 01 42 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 02 01 01 45 07 00 3F 00 FF 00 05 00 00 00 01 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 01 02 45 07 00 3F 00 4D 07 00 A0 FF 00 02 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 02 07 00 A0 01 5D 07 00 A0 FF 00 13 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 02 03 03 FF 00 02 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 03 03 03 01 FF 00 1C 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 02 03 03 FF 00 0D 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 03 03 03 07 00 A0 FF 00 02 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 04 03 03 07 00 A0 01 FF 00 1E 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 03 03 03 07 00 A0 FF 00 0E 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 03 03 03 03 FF 00 02 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 04 03 03 03 01 FF 00 1D 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 03 03 03 03 FF 00 0D 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 04 03 03 03 07 00 A0 FF 00 02 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 05 03 03 03 07 00 A0 01 FF 00 1E 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 04 03 03 03 07 00 A0 53 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 07 03 03 03 03 03 03 07 00 09 45 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 07 03 03 03 03 03 03 07 01 29 42 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 07 03 03 03 03 03 03 07 01 29 45 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 07 03 03 03 03 03 03 07 00 05 45 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 07 03 03 03 03 03 03 07 01 2C 45 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 07 03 03 03 03 03 03 02 FF 00 06 00 00 00 01 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 08 03 03 03 03 03 03 02 07 00 09 45 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 08 03 03 03 03 03 03 02 07 01 29 FF 00 02 00 00 00 01 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 08 03 03 03 03 03 03 02 07 01 29 45 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 08 03 03 03 03 03 03 02 07 00 05 45 07 00 26 FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 08 03 03 03 03 03 03 02 07 01 2C 45 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 08 03 03 03 03 03 03 02 02 46 07 00 2A FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 09 03 03 03 03 03 03 02 02 07 00 09 45 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 09 03 03 03 03 03 03 02 02 07 01 29 42 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 09 03 03 03 03 03 03 02 02 07 01 29 45 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 09 03 03 03 03 03 03 02 02 07 00 05 45 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 09 03 03 03 03 03 03 02 02 07 01 2C 45 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 09 03 03 03 03 03 03 02 02 02 FF 00 0B 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 09 03 03 03 03 03 03 02 02 02 FF 00 02 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 0A 03 03 03 03 03 03 02 02 02 01 FF 00 1F 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 09 03 03 03 03 03 03 02 02 02 46 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 0A 03 03 03 03 03 03 02 02 02 07 00 09 45 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 0A 03 03 03 03 03 03 02 02 02 07 01 29 FF 00 0B 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 0A 03 03 03 03 03 03 02 02 02 07 01 29 FF 00 02 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 0B 03 03 03 03 03 03 02 02 02 07 01 29 01 FF 00 1D 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 0A 03 03 03 03 03 03 02 02 02 07 01 29 42 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 0A 03 03 03 03 03 03 02 02 02 07 01 29 45 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 0A 03 03 03 03 03 03 02 02 02 07 00 05 FF 00 0E 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 0A 03 03 03 03 03 03 02 02 02 07 01 2C FF 00 02 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 0B 03 03 03 03 03 03 02 02 02 07 01 2C 01 FF 00 1E 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 0A 03 03 03 03 03 03 02 02 02 07 01 2C 42 07 00 32 FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 0A 03 03 03 03 03 03 02 02 02 07 01 2C 45 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 0A 03 03 03 03 03 03 02 02 02 02 42 07 00 20 FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 0A 03 03 03 03 03 03 02 02 02 02 45 07 00 3F 00 45 07 00 3F 40 01 45 07 00 3F 00 43 07 00 20 40 01 45 07 00 3F 00 42 07 00 3F 00 45 07 00 3F 00 42 07 00 3F 00 45 07 00 3F 00 42 07 00 3F 00 45 07 00 3F 00 0B 42 01 1F FF 00 02 00 00 00 01 07 00 3F FF 00 00 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 00 45 07 00 3F 00 FF 00 00 00 04 07 00 03 07 00 47 02 02 00 03 07 00 9A 03 07 00 09 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 05 08 02 EF 08 02 EF 03 03 03 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 02 07 00 9A 07 00 03 FF 00 01 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 02 01 01 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 07 08 02 EF 08 02 EF 03 03 03 03 03 FF 00 01 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 03 03 03 07 00 A0 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 08 08 02 EF 08 02 EF 03 03 03 03 03 03 FF 00 01 00 05 07 00 03 07 00 47 02 02 07 00 A0 00 02 08 05 4D 08 05 4D F8 00 01 FF 00 01 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 00 FF 00 01 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 0A 03 03 03 03 03 03 02 02 02 07 01 29 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 07 08 02 EF 08 02 EF 03 03 03 03 03 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 04 07 00 9A 03 03 07 00 7F FD 00 01 07 00 A0 07 00 A0 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 02 07 00 9A 07 00 09 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 03 07 00 9A 03 07 00 73 FF 00 01 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 02 03 03 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 04 08 02 EF 08 02 EF 03 03 FF 00 01 00 05 07 00 03 07 00 47 02 02 07 00 A0 00 04 08 05 4D 08 05 4D 03 03 FF 00 01 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 09 03 03 03 03 03 03 02 02 02 FF 00 01 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 03 03 03 03 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 03 07 00 9A 03 07 00 7F FF 00 01 00 03 07 00 03 07 00 47 02 00 01 07 00 4D 41 07 00 47 41 02 FF 00 01 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 04 03 03 03 07 00 A0 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 09 08 02 EF 08 02 EF 03 03 03 03 03 03 07 00 73 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 03 07 00 9A 03 03 FF 00 01 00 04 07 00 03 07 00 47 02 02 00 06 08 02 EF 08 02 EF 03 03 03 03 FD 00 01 07 00 A0 07 00 A0 FF 00 01 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 0A 03 03 03 03 03 03 02 02 02 07 01 2C FF 00 01 00 04 07 00 03 07 00 47 02 02 00 06 08 02 EF 08 02 EF 03 03 03 07 00 73 41 07 00 9A FF 00 01 00 04 07 00 03 07 00 47 02 02 00 06 08 02 EF 08 02 EF 03 03 03 07 00 A6 FF 00 01 00 06 07 00 03 07 00 47 02 02 07 00 A0 07 00 A0 00 01 07 00 A0 FF 00 01 00 02 07 00 03 07 00 47 00 01 07 00 20 43 05 44 07 00 20 47 05 47 07 00 3F
                //    Exceptions:
                //  Try           Handler
                //  Start  End    Start  End    Type                                       
                //  -----  -----  -----  -----  -------------------------------------------
                //  8      20     2507   2515   Ljava/lang/ClassCastException;
                //  2507   2515   2507   2515   Ljava/lang/ArrayIndexOutOfBoundsException;
                //  2523   2525   3      8      Ljava/lang/AssertionError;
                //  72     79     79     80     Any
                //  73     79     79     80     Ljava/lang/RuntimeException;
                //  72     79     72     73     Ljava/lang/ArrayIndexOutOfBoundsException;
                //  72     79     3      8      Any
                //  72     79     72     73     Any
                //  86     93     93     94     Any
                //  86     93     3      8      Any
                //  87     93     86     87     Ljava/lang/IndexOutOfBoundsException;
                //  87     93     3      8      Ljava/util/ConcurrentModificationException;
                //  86     93     3      8      Any
                //  147    154    154    155    Any
                //  147    154    147    148    Any
                //  148    154    3      8      Any
                //  147    154    154    155    Any
                //  147    154    3      8      Any
                //  204    210    210    211    Any
                //  204    210    3      8      Any
                //  204    210    3      8      Ljava/lang/IndexOutOfBoundsException;
                //  204    210    210    211    Any
                //  204    210    3      8      Any
                //  395    402    402    403    Any
                //  396    402    395    396    Ljava/lang/IllegalArgumentException;
                //  396    402    402    403    Ljava/lang/NegativeArraySizeException;
                //  395    402    395    396    Any
                //  396    402    395    396    Any
                //  408    415    415    416    Any
                //  408    415    3      8      Any
                //  409    415    408    409    Ljava/lang/IllegalStateException;
                //  408    415    3      8      Ljava/lang/UnsupportedOperationException;
                //  408    415    408    409    Any
                //  423    430    430    431    Any
                //  423    430    430    431    Any
                //  424    430    423    424    Any
                //  423    430    430    431    Ljava/lang/ArrayIndexOutOfBoundsException;
                //  424    430    3      8      Any
                //  483    490    490    491    Any
                //  483    490    3      8      Any
                //  483    490    3      8      Any
                //  483    490    483    484    Any
                //  483    490    483    484    Any
                //  539    546    546    547    Any
                //  539    546    3      8      Ljava/util/NoSuchElementException;
                //  540    546    539    540    Any
                //  539    546    546    547    Any
                //  540    546    546    547    Any
                //  596    602    602    603    Any
                //  596    602    602    603    Ljava/lang/RuntimeException;
                //  596    602    602    603    Any
                //  596    602    3      8      Ljava/lang/AssertionError;
                //  596    602    602    603    Any
                //  655    662    662    663    Any
                //  656    662    655    656    Any
                //  656    662    662    663    Any
                //  656    662    655    656    Ljava/lang/AssertionError;
                //  655    662    662    663    Ljava/lang/EnumConstantNotPresentException;
                //  668    675    675    676    Any
                //  669    675    668    669    Ljava/lang/ClassCastException;
                //  669    675    675    676    Any
                //  669    675    3      8      Ljava/lang/StringIndexOutOfBoundsException;
                //  668    675    668    669    Any
                //  727    734    734    735    Any
                //  727    734    727    728    Any
                //  727    734    727    728    Ljava/lang/ClassCastException;
                //  728    734    734    735    Any
                //  727    734    727    728    Any
                //  741    750    750    751    Any
                //  742    750    741    742    Ljava/lang/NullPointerException;
                //  741    750    741    742    Any
                //  742    750    3      8      Ljava/lang/IndexOutOfBoundsException;
                //  741    750    750    751    Any
                //  764    771    771    772    Any
                //  764    771    771    772    Ljava/lang/NegativeArraySizeException;
                //  765    771    771    772    Any
                //  764    771    771    772    Any
                //  765    771    764    765    Any
                //  777    784    784    785    Any
                //  777    784    784    785    Ljava/lang/ArithmeticException;
                //  777    784    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
                //  778    784    3      8      Any
                //  778    784    777    778    Any
                //  840    846    846    847    Any
                //  840    846    3      8      Ljava/util/NoSuchElementException;
                //  840    846    846    847    Ljava/lang/NumberFormatException;
                //  840    846    846    847    Any
                //  840    846    3      8      Any
                //  852    859    859    860    Any
                //  853    859    3      8      Ljava/lang/NegativeArraySizeException;
                //  853    859    852    853    Ljava/lang/EnumConstantNotPresentException;
                //  852    859    852    853    Any
                //  852    859    852    853    Any
                //  874    880    880    881    Any
                //  874    880    880    881    Any
                //  874    880    880    881    Ljava/lang/IllegalStateException;
                //  874    880    880    881    Ljava/lang/AssertionError;
                //  874    880    880    881    Ljava/lang/NullPointerException;
                //  927    934    934    935    Any
                //  927    934    927    928    Any
                //  928    934    934    935    Ljava/util/ConcurrentModificationException;
                //  927    934    3      8      Ljava/util/NoSuchElementException;
                //  928    934    3      8      Any
                //  1079   1086   1086   1087   Any
                //  1079   1086   1086   1087   Any
                //  1079   1086   1079   1080   Any
                //  1080   1086   1086   1087   Ljava/lang/UnsupportedOperationException;
                //  1080   1086   1079   1080   Any
                //  1092   1099   1099   1100   Any
                //  1092   1099   1092   1093   Any
                //  1093   1099   3      8      Any
                //  1092   1099   1099   1100   Ljava/lang/UnsupportedOperationException;
                //  1092   1099   3      8      Any
                //  1156   1162   1162   1163   Any
                //  1156   1162   1162   1163   Ljava/lang/EnumConstantNotPresentException;
                //  1156   1162   3      8      Any
                //  1156   1162   1162   1163   Any
                //  1156   1162   3      8      Any
                //  1168   1175   1175   1176   Any
                //  1168   1175   1168   1169   Any
                //  1168   1175   1175   1176   Ljava/lang/UnsupportedOperationException;
                //  1168   1175   1168   1169   Ljava/lang/ClassCastException;
                //  1168   1175   1168   1169   Ljava/lang/IndexOutOfBoundsException;
                //  1237   1244   1244   1245   Any
                //  1238   1244   1244   1245   Any
                //  1237   1244   3      8      Any
                //  1237   1244   3      8      Ljava/lang/StringIndexOutOfBoundsException;
                //  1237   1244   1237   1238   Ljava/lang/IllegalStateException;
                //  1292   1298   1298   1299   Any
                //  1292   1298   1298   1299   Any
                //  1292   1298   3      8      Ljava/lang/NumberFormatException;
                //  1292   1298   3      8      Ljava/lang/ClassCastException;
                //  1292   1298   1298   1299   Any
                //  1347   1354   1354   1355   Any
                //  1348   1354   1347   1348   Ljava/lang/IndexOutOfBoundsException;
                //  1347   1354   1347   1348   Ljava/lang/IllegalStateException;
                //  1347   1354   3      8      Ljava/lang/NullPointerException;
                //  1347   1354   1354   1355   Any
                //  1466   1473   1473   1474   Any
                //  1467   1473   3      8      Ljava/lang/AssertionError;
                //  1467   1473   1466   1467   Any
                //  1466   1473   1466   1467   Ljava/lang/NegativeArraySizeException;
                //  1467   1473   1466   1467   Ljava/lang/IllegalStateException;
                //  1484   1493   1493   1494   Any
                //  1485   1493   3      8      Ljava/lang/IllegalArgumentException;
                //  1484   1493   3      8      Any
                //  1485   1493   1484   1485   Any
                //  1484   1493   3      8      Ljava/lang/NullPointerException;
                //  1500   1507   1507   1508   Any
                //  1501   1507   1507   1508   Ljava/util/ConcurrentModificationException;
                //  1500   1507   1507   1508   Ljava/lang/IllegalStateException;
                //  1501   1507   1500   1501   Any
                //  1501   1507   1500   1501   Any
                //  1555   1562   1562   1563   Any
                //  1555   1562   1562   1563   Ljava/lang/UnsupportedOperationException;
                //  1556   1562   1555   1556   Ljava/lang/IllegalArgumentException;
                //  1555   1562   1555   1556   Any
                //  1556   1562   1555   1556   Ljava/lang/ArithmeticException;
                //  1567   1573   1573   1574   Any
                //  1567   1573   1573   1574   Ljava/lang/StringIndexOutOfBoundsException;
                //  1567   1573   3      8      Any
                //  1567   1573   1573   1574   Ljava/lang/NullPointerException;
                //  1567   1573   1573   1574   Any
                //  1585   1592   1592   1593   Any
                //  1586   1592   1592   1593   Any
                //  1585   1592   1585   1586   Any
                //  1586   1592   3      8      Any
                //  1586   1592   1592   1593   Ljava/lang/ClassCastException;
                //  1639   1646   1646   1647   Any
                //  1639   1646   3      8      Any
                //  1639   1646   1646   1647   Ljava/lang/ArithmeticException;
                //  1639   1646   3      8      Any
                //  1640   1646   1639   1640   Any
                //  1652   1658   1658   1659   Any
                //  1652   1658   3      8      Ljava/lang/StringIndexOutOfBoundsException;
                //  1652   1658   1658   1659   Ljava/lang/NegativeArraySizeException;
                //  1652   1658   3      8      Any
                //  1652   1658   1658   1659   Any
                //  1665   1672   1672   1673   Any
                //  1666   1672   3      8      Any
                //  1666   1672   1672   1673   Ljava/lang/ArithmeticException;
                //  1665   1672   1665   1666   Ljava/lang/IndexOutOfBoundsException;
                //  1666   1672   1672   1673   Ljava/lang/StringIndexOutOfBoundsException;
                //  1723   1730   1730   1731   Any
                //  1724   1730   1723   1724   Any
                //  1723   1730   3      8      Any
                //  1723   1730   3      8      Ljava/lang/StringIndexOutOfBoundsException;
                //  1724   1730   3      8      Any
                //  1738   1744   1744   1745   Any
                //  1738   1744   1744   1745   Ljava/lang/NullPointerException;
                //  1738   1744   1744   1745   Any
                //  1738   1744   1744   1745   Any
                //  1738   1744   3      8      Any
                //  2008   2015   2015   2016   Any
                //  2009   2015   2008   2009   Any
                //  2009   2015   2008   2009   Any
                //  2009   2015   2015   2016   Any
                //  2009   2015   2008   2009   Any
                //  2019   2026   2026   2027   Any
                //  2019   2026   2026   2027   Any
                //  2020   2026   3      8      Ljava/lang/IllegalArgumentException;
                //  2020   2026   2019   2020   Any
                //  2020   2026   2026   2027   Ljava/lang/ClassCastException;
                //  2033   2040   2040   2041   Any
                //  2033   2040   2033   2034   Any
                //  2034   2040   2040   2041   Any
                //  2034   2040   2033   2034   Ljava/lang/IllegalArgumentException;
                //  2034   2040   3      8      Any
                //  2049   2055   2055   2056   Any
                //  2049   2055   3      8      Ljava/lang/StringIndexOutOfBoundsException;
                //  2049   2055   2055   2056   Any
                //  2049   2055   3      8      Any
                //  2049   2055   2055   2056   Ljava/lang/NullPointerException;
                //  2060   2066   2066   2067   Any
                //  2060   2066   2066   2067   Any
                //  2060   2066   2066   2067   Ljava/util/NoSuchElementException;
                //  2060   2066   2066   2067   Any
                //  2060   2066   3      8      Ljava/lang/NullPointerException;
                //  2073   2080   2080   2081   Any
                //  2073   2080   2080   2081   Any
                //  2074   2080   2080   2081   Ljava/lang/NullPointerException;
                //  2074   2080   3      8      Ljava/lang/NullPointerException;
                //  2073   2080   2073   2074   Ljava/lang/IllegalArgumentException;
                //  2088   2095   2095   2096   Any
                //  2088   2095   3      8      Any
                //  2089   2095   2095   2096   Any
                //  2089   2095   2088   2089   Ljava/lang/IllegalStateException;
                //  2088   2095   2095   2096   Ljava/lang/NumberFormatException;
                //  2099   2106   2106   2107   Any
                //  2099   2106   3      8      Ljava/lang/NullPointerException;
                //  2099   2106   3      8      Any
                //  2100   2106   2099   2100   Any
                //  2100   2106   2099   2100   Ljava/lang/NegativeArraySizeException;
                //  2113   2120   2120   2121   Any
                //  2113   2120   2113   2114   Any
                //  2114   2120   3      8      Any
                //  2114   2120   3      8      Any
                //  2113   2120   2113   2114   Any
                //  2175   2182   2182   2183   Any
                //  2175   2182   2175   2176   Any
                //  2176   2182   2182   2183   Ljava/lang/ArithmeticException;
                //  2175   2182   2175   2176   Ljava/lang/IndexOutOfBoundsException;
                //  2176   2182   2182   2183   Any
                //  2231   2238   2238   2239   Any
                //  2231   2238   2231   2232   Any
                //  2232   2238   2238   2239   Any
                //  2231   2238   2231   2232   Ljava/lang/RuntimeException;
                //  2231   2238   3      8      Ljava/lang/ArithmeticException;
                //  2291   2298   2298   2299   Any
                //  2292   2298   2291   2292   Ljava/lang/StringIndexOutOfBoundsException;
                //  2292   2298   2298   2299   Ljava/lang/AssertionError;
                //  2291   2298   3      8      Any
                //  2291   2298   2298   2299   Any
                //  2302   2309   2309   2310   Any
                //  2303   2309   2302   2303   Ljava/util/ConcurrentModificationException;
                //  2303   2309   2302   2303   Ljava/lang/IllegalStateException;
                //  2302   2309   2309   2310   Ljava/lang/ArithmeticException;
                //  2302   2309   3      8      Any
                //  2316   2323   2323   2324   Any
                //  2316   2323   2316   2317   Ljava/lang/ClassCastException;
                //  2317   2323   2316   2317   Any
                //  2317   2323   2323   2324   Ljava/lang/IndexOutOfBoundsException;
                //  2316   2323   3      8      Any
                //  2328   2335   2335   2336   Any
                //  2328   2335   2328   2329   Ljava/lang/IllegalStateException;
                //  2329   2335   2335   2336   Any
                //  2329   2335   2328   2329   Ljava/lang/ArrayIndexOutOfBoundsException;
                //  2328   2335   2335   2336   Ljava/lang/AssertionError;
                //  2339   2346   2346   2347   Any
                //  2340   2346   2346   2347   Any
                //  2339   2346   3      8      Ljava/lang/NegativeArraySizeException;
                //  2339   2346   2339   2340   Any
                //  2339   2346   3      8      Any
                //  2350   2357   2357   2358   Any
                //  2350   2357   2357   2358   Any
                //  2350   2357   2350   2351   Any
                //  2350   2357   2350   2351   Any
                //  2350   2357   2357   2358   Any
                //  2361   2368   2368   2369   Any
                //  2361   2368   2361   2362   Any
                //  2362   2368   2361   2362   Any
                //  2362   2368   3      8      Ljava/lang/StringIndexOutOfBoundsException;
                //  2361   2368   2368   2369   Ljava/lang/ClassCastException;
                //  2420   2426   2426   2427   Any
                //  2420   2426   3      8      Any
                //  2420   2426   3      8      Any
                //  2420   2426   2426   2427   Any
                //  2420   2426   3      8      Any
                // 
                // The error that occurred was:
                // 
                // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
                //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
                //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
                //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
                //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
                //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
                //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
                //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:618)
                //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
                //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
                //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:670)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
                //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
                //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
                //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
                //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
                //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
                // 
                throw new IllegalStateException("An error occurred while decompiling this method.");
            }
            
            static {
                throw t;
            }
            
            public f79(final f7b c) {
                while (true) {
                    int n = 0;
                    Label_0015: {
                        if (fc.0 <= 0) {
                            n = -517812238;
                            break Label_0015;
                        }
                        n = -193560071;
                    }
                    switch (n ^ 0xA80AD1F0) {
                        case 1227365890: {
                            continue;
                        }
                        case 1551650825: {
                            this.c = c;
                        }
                        default: {
                            throw null;
                        }
                    }
                    break;
                }
            }
        }
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          135
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            127
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            119
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_0        
        //    25: getstatic       dev/nuker/pyro/fc.1:I
        //    28: ifne            37
        //    31: ldc_w           1065415590
        //    34: goto            40
        //    37: ldc_w           -1791834678
        //    40: ldc_w           -1933150569
        //    43: ixor           
        //    44: lookupswitch {
        //          -1287224015: 37
        //          435467101: 72
        //          default: 108
        //        }
        //    72: getfield        dev/nuker/pyro/f7b.c:Ljava/util/List;
        //    75: new             Ldev/nuker/pyro/f79;
        //    78: dup            
        //    79: aload_0        
        //    80: goto            84
        //    83: athrow         
        //    84: invokespecial   dev/nuker/pyro/f79.<init>:(Ldev/nuker/pyro/f7b;)V
        //    87: goto            91
        //    90: athrow         
        //    91: checkcast       Ljava/util/function/Consumer;
        //    94: goto            98
        //    97: athrow         
        //    98: invokeinterface java/util/List.forEach:(Ljava/util/function/Consumer;)V
        //   103: goto            107
        //   106: athrow         
        //   107: return         
        //   108: aconst_null    
        //   109: athrow         
        //   110: pop            
        //   111: goto            24
        //   114: pop            
        //   115: aconst_null    
        //   116: goto            110
        //   119: dup            
        //   120: ifnull          110
        //   123: checkcast       Ljava/lang/Throwable;
        //   126: athrow         
        //   127: dup            
        //   128: ifnull          114
        //   131: checkcast       Ljava/lang/Throwable;
        //   134: athrow         
        //   135: aconst_null    
        //   136: athrow         
        //    StackMapTable: 00 15 43 07 00 13 04 FF 00 0B 00 00 00 01 07 00 13 FD 00 03 07 00 03 07 01 15 4C 07 00 03 FF 00 02 00 02 07 00 03 07 01 15 00 02 07 00 03 01 5F 07 00 03 4A 07 00 13 FF 00 00 00 02 07 00 03 07 01 15 00 04 07 00 8A 08 00 4B 08 00 4B 07 00 03 45 07 00 13 FF 00 00 00 02 07 00 03 07 01 15 00 02 07 00 8A 07 01 0A 45 07 00 13 FF 00 00 00 02 07 00 03 07 01 15 00 02 07 00 8A 07 01 0F 47 07 00 13 00 40 07 00 03 41 07 00 1F 43 05 44 07 00 1F 47 05 47 07 00 13
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     119    127    Ljava/lang/UnsupportedOperationException;
        //  119    127    119    127    Ljava/lang/NegativeArraySizeException;
        //  135    137    3      8      Ljava/lang/NullPointerException;
        //  83     90     90     91     Any
        //  84     90     83     84     Any
        //  83     90     3      8      Ljava/lang/EnumConstantNotPresentException;
        //  83     90     3      8      Ljava/lang/IllegalStateException;
        //  83     90     90     91     Any
        //  97     106    106    107    Any
        //  97     106    97     98     Any
        //  97     106    97     98     Ljava/lang/IndexOutOfBoundsException;
        //  97     106    3      8      Any
        //  97     106    3      8      Ljava/lang/IllegalArgumentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 52 out of bounds for length 52
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void c(final f7b p0, final Minecraft p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getstatic       dev/nuker/pyro/fc.c:I
        //     4: ifeq            88
        //     7: pop            
        //     8: aconst_null    
        //     9: goto            80
        //    12: nop            
        //    13: nop            
        //    14: nop            
        //    15: athrow         
        //    16: aload_0        
        //    17: getstatic       dev/nuker/pyro/fc.c:I
        //    20: ifne            29
        //    23: ldc_w           -351334279
        //    26: goto            32
        //    29: ldc_w           1211028989
        //    32: ldc_w           -2004883439
        //    35: ixor           
        //    36: lookupswitch {
        //          -1068417556: 64
        //          1668348008: 29
        //          default: 69
        //        }
        //    64: aload_1        
        //    65: putfield        dev/nuker/pyro/f7b.c:Lnet/minecraft/client/Minecraft;
        //    68: return         
        //    69: aconst_null    
        //    70: athrow         
        //    71: pop            
        //    72: goto            16
        //    75: pop            
        //    76: aconst_null    
        //    77: goto            71
        //    80: dup            
        //    81: ifnull          71
        //    84: checkcast       Ljava/lang/Throwable;
        //    87: athrow         
        //    88: dup            
        //    89: ifnull          75
        //    92: checkcast       Ljava/lang/Throwable;
        //    95: athrow         
        //    StackMapTable: 00 0A FF 00 0C 00 00 00 01 07 00 13 FD 00 03 07 00 03 07 01 1B 4C 07 00 03 FF 00 02 00 02 07 00 03 07 01 1B 00 02 07 00 03 01 5F 07 00 03 44 07 00 03 41 07 00 13 43 05 44 07 00 13 47 05
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  0      12     80     88     Any
        //  80     88     80     88     Ljava/util/ConcurrentModificationException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:543)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        throw t;
    }
    
    public void c(@NotNull final List list) {
        fez.iD(this, 1704899578, list);
    }
    
    @NotNull
    public f0l c() {
        return fez.8q(this, 1859464344);
    }
}
