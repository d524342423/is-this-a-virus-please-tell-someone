// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import net.minecraft.world.EnumDifficulty;

public class fdL
{
    public static int[] c;
    
    static {
        fdL.c = new int[EnumDifficulty.values().length];
        try {
            fdL.c[EnumDifficulty.PEACEFUL.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        Label_0124: {
            try {
                while (true) {
                    int n = 0;
                    Label_0037: {
                        if (fc.0 <= 0) {
                            n = 2000496945;
                            break Label_0037;
                        }
                        n = 701709205;
                    }
                    switch (n ^ 0x93F09685) {
                        case -456278092: {
                            continue;
                        }
                        case -1172067056: {
                            final int[] c = fdL.c;
                            while (true) {
                                int n2 = 0;
                                Label_0084: {
                                    if (fc.0 <= 0) {
                                        n2 = 1253864075;
                                        break Label_0084;
                                    }
                                    n2 = 1826956664;
                                }
                                switch (n2 ^ 0xCE0F3A7F) {
                                    case -2068625164: {
                                        continue;
                                    }
                                    case -1561714937: {
                                        c[EnumDifficulty.EASY.ordinal()] = 2;
                                        break Label_0124;
                                    }
                                    default: {
                                        throw null;
                                    }
                                }
                                break;
                            }
                            break;
                        }
                        default: {
                            throw null;
                        }
                    }
                    break;
                }
            }
            catch (NoSuchFieldError noSuchFieldError2) {}
            try {
                final int[] c2 = fdL.c;
                final EnumDifficulty hard = EnumDifficulty.HARD;
                while (true) {
                    int n3 = 0;
                    Label_0143: {
                        if (fc.c == 0) {
                            n3 = -603686102;
                            break Label_0143;
                        }
                        n3 = 619830613;
                    }
                    switch (n3 ^ 0x10AB8A1D) {
                        case -860884681: {
                            continue;
                        }
                        case 878335816: {
                            c2[hard.ordinal()] = 3;
                            break;
                        }
                        default: {
                            throw null;
                        }
                    }
                    break;
                }
            }
            catch (NoSuchFieldError noSuchFieldError3) {
                while (true) {
                    int n4 = 0;
                    Label_0193: {
                        if (fc.0 <= 0) {
                            n4 = 555546929;
                            break Label_0193;
                        }
                        n4 = 258949960;
                    }
                    switch (n4 ^ 0xE63D36BB) {
                        case -954085494: {
                            continue;
                        }
                        case -380471821: {
                            break;
                        }
                        default: {
                            throw null;
                        }
                    }
                    break;
                }
            }
        }
    }
}
