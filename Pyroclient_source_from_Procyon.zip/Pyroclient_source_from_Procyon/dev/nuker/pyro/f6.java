// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import dev.nuker.pyro.security.inject.LauncherEventHide;
import org.jetbrains.annotations.NotNull;
import kotlin.jvm.JvmField;
import org.jetbrains.annotations.Nullable;

public class f6 extends fdZ
{
    public boolean c;
    @Nullable
    public f4O c;
    @JvmField
    @NotNull
    public static f6 c;
    public static f5 c;
    
    @f0g
    @LauncherEventHide
    public void c(@NotNull final f46 p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          92
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            84
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            76
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: aload_1        
        //    27: goto            31
        //    30: athrow         
        //    31: invokevirtual   dev/nuker/pyro/f46.c:()Z
        //    34: goto            38
        //    37: athrow         
        //    38: ifeq            66
        //    41: getstatic       dev/nuker/pyro/fZ.c:Ldev/nuker/pyro/fZ;
        //    44: goto            48
        //    47: athrow         
        //    48: invokestatic    org/lwjgl/input/Mouse.getEventButton:()I
        //    51: goto            55
        //    54: athrow         
        //    55: goto            59
        //    58: athrow         
        //    59: invokevirtual   dev/nuker/pyro/fZ.c:(I)V
        //    62: goto            66
        //    65: athrow         
        //    66: return         
        //    67: pop            
        //    68: goto            24
        //    71: pop            
        //    72: aconst_null    
        //    73: goto            67
        //    76: dup            
        //    77: ifnull          67
        //    80: checkcast       Ljava/lang/Throwable;
        //    83: athrow         
        //    84: dup            
        //    85: ifnull          71
        //    88: checkcast       Ljava/lang/Throwable;
        //    91: athrow         
        //    92: aconst_null    
        //    93: athrow         
        //    StackMapTable: 00 15 43 07 00 24 04 FF 00 0B 00 00 00 01 07 00 24 FD 00 03 07 00 03 07 00 26 45 07 00 39 40 07 00 26 45 07 00 24 40 01 48 07 00 24 40 07 00 2B 45 07 00 24 FF 00 00 00 02 07 00 03 07 00 26 00 02 07 00 2B 01 42 07 00 24 FF 00 00 00 02 07 00 03 07 00 26 00 02 07 00 2B 01 45 07 00 24 00 40 07 00 24 43 05 44 07 00 24 47 05 47 07 00 24
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     76     84     Any
        //  76     84     76     84     Any
        //  92     94     3      8      Ljava/util/NoSuchElementException;
        //  30     37     37     38     Any
        //  30     37     30     31     Ljava/lang/IllegalStateException;
        //  30     37     37     38     Ljava/lang/UnsupportedOperationException;
        //  30     37     30     31     Ljava/lang/UnsupportedOperationException;
        //  30     37     37     38     Ljava/lang/IllegalArgumentException;
        //  47     54     54     55     Any
        //  48     54     54     55     Ljava/util/ConcurrentModificationException;
        //  47     54     54     55     Ljava/lang/StringIndexOutOfBoundsException;
        //  47     54     47     48     Any
        //  47     54     54     55     Any
        //  58     65     65     66     Any
        //  58     65     58     59     Any
        //  58     65     65     66     Any
        //  58     65     3      8      Any
        //  59     65     3      8      Ljava/lang/IllegalStateException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:543)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public f6() {
        this.c = true;
    }
    
    @Nullable
    public f4O 0() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getstatic       dev/nuker/pyro/fc.c:I
        //     4: ifeq            38
        //     7: pop            
        //     8: aconst_null    
        //     9: goto            30
        //    12: nop            
        //    13: nop            
        //    14: nop            
        //    15: athrow         
        //    16: aload_0        
        //    17: getfield        dev/nuker/pyro/f6.c:Ldev/nuker/pyro/f4O;
        //    20: areturn        
        //    21: pop            
        //    22: goto            16
        //    25: pop            
        //    26: aconst_null    
        //    27: goto            21
        //    30: dup            
        //    31: ifnull          21
        //    34: checkcast       Ljava/lang/Throwable;
        //    37: athrow         
        //    38: dup            
        //    39: ifnull          25
        //    42: checkcast       Ljava/lang/Throwable;
        //    45: athrow         
        //    StackMapTable: 00 06 FF 00 0C 00 00 00 01 07 00 24 FC 00 03 07 00 03 44 07 00 24 43 05 44 07 00 24 47 05
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type
        //  -----  -----  -----  -----  ----
        //  0      12     30     38     Any
        //  30     38     30     38     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:543)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void c() {
        fez.gl(this, 902594163);
    }
    
    @f0g
    @LauncherEventHide
    public void c(@NotNull final f45 p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          1111
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            1103
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            1095
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: aload_1        
        //    27: goto            31
        //    30: athrow         
        //    31: invokevirtual   dev/nuker/pyro/f45.c:()Z
        //    34: goto            38
        //    37: athrow         
        //    38: ifeq            1059
        //    41: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //    44: getfield        net/minecraft/client/Minecraft.field_71462_r:Lnet/minecraft/client/gui/GuiScreen;
        //    47: ifnonnull       1059
        //    50: goto            54
        //    53: athrow         
        //    54: invokestatic    org/lwjgl/input/Keyboard.getEventKey:()I
        //    57: goto            61
        //    60: athrow         
        //    61: getstatic       dev/nuker/pyro/fc.c:I
        //    64: ifne            72
        //    67: ldc             -1878920313
        //    69: goto            74
        //    72: ldc             -294140891
        //    74: ldc             311037018
        //    76: ixor           
        //    77: lookupswitch {
        //          -2104754211: 72
        //          -50476929: 104
        //          default: 1076
        //        }
        //   104: istore_2       
        //   105: getstatic       dev/nuker/pyro/fc.c:I
        //   108: ifne            116
        //   111: ldc             978831908
        //   113: goto            118
        //   116: ldc             1233013352
        //   118: ldc             364274055
        //   120: ixor           
        //   121: lookupswitch {
        //          -1798647691: 116
        //          803318691: 1072
        //          default: 148
        //        }
        //   148: iload_2        
        //   149: getstatic       dev/nuker/pyro/fc.c:I
        //   152: ifne            160
        //   155: ldc             986864046
        //   157: goto            162
        //   160: ldc             -484637636
        //   162: ldc             -10326539
        //   164: ixor           
        //   165: lookupswitch {
        //          -978308005: 1080
        //          1330249704: 160
        //          default: 192
        //        }
        //   192: getstatic       dev/nuker/pyro/Pyro.KEY:Lnet/minecraft/client/settings/KeyBinding;
        //   195: dup            
        //   196: pop            
        //   197: goto            201
        //   200: athrow         
        //   201: invokevirtual   net/minecraft/client/settings/KeyBinding.func_151463_i:()I
        //   204: goto            208
        //   207: athrow         
        //   208: if_icmpne       344
        //   211: getstatic       dev/nuker/pyro/fc.c:I
        //   214: ifne            222
        //   217: ldc             -363291383
        //   219: goto            224
        //   222: ldc             968167324
        //   224: ldc             -962773040
        //   226: ixor           
        //   227: lookupswitch {
        //          -14143412: 252
        //          751149785: 222
        //          default: 1084
        //        }
        //   252: aload_0        
        //   253: getfield        dev/nuker/pyro/f6.c:Ldev/nuker/pyro/f4O;
        //   256: ifnonnull       278
        //   259: aload_0        
        //   260: new             Ldev/nuker/pyro/f4O;
        //   263: dup            
        //   264: goto            268
        //   267: athrow         
        //   268: invokespecial   dev/nuker/pyro/f4O.<init>:()V
        //   271: goto            275
        //   274: athrow         
        //   275: putfield        dev/nuker/pyro/f6.c:Ldev/nuker/pyro/f4O;
        //   278: getstatic       dev/nuker/pyro/fc.c:I
        //   281: ifne            289
        //   284: ldc             -483458802
        //   286: goto            291
        //   289: ldc             -1939711597
        //   291: ldc             -1851960428
        //   293: ixor           
        //   294: lookupswitch {
        //          -101666474: 289
        //          1924289178: 1060
        //          default: 320
        //        }
        //   320: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //   323: aload_0        
        //   324: getfield        dev/nuker/pyro/f6.c:Ldev/nuker/pyro/f4O;
        //   327: checkcast       Lnet/minecraft/client/gui/GuiScreen;
        //   330: goto            334
        //   333: athrow         
        //   334: invokevirtual   net/minecraft/client/Minecraft.func_147108_a:(Lnet/minecraft/client/gui/GuiScreen;)V
        //   337: goto            341
        //   340: athrow         
        //   341: goto            385
        //   344: getstatic       dev/nuker/pyro/fF.c:Ldev/nuker/pyro/fD;
        //   347: goto            351
        //   350: athrow         
        //   351: invokevirtual   dev/nuker/pyro/fD.c:()Ldev/nuker/pyro/fF;
        //   354: goto            358
        //   357: athrow         
        //   358: iload_2        
        //   359: goto            363
        //   362: athrow         
        //   363: invokevirtual   dev/nuker/pyro/fF.0:(I)V
        //   366: goto            370
        //   369: athrow         
        //   370: getstatic       dev/nuker/pyro/fZ.c:Ldev/nuker/pyro/fZ;
        //   373: iload_2        
        //   374: goto            378
        //   377: athrow         
        //   378: invokevirtual   dev/nuker/pyro/fZ.0:(I)V
        //   381: goto            385
        //   384: athrow         
        //   385: iload_2        
        //   386: getstatic       dev/nuker/pyro/fc.0:I
        //   389: ifgt            397
        //   392: ldc             -263434914
        //   394: goto            399
        //   397: ldc             332729809
        //   399: ldc             -1999631653
        //   401: ixor           
        //   402: lookupswitch {
        //          -1694169334: 428
        //          2023507845: 397
        //          default: 1082
        //        }
        //   428: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //   431: getfield        net/minecraft/client/Minecraft.field_71474_y:Lnet/minecraft/client/settings/GameSettings;
        //   434: getfield        net/minecraft/client/settings/GameSettings.field_74311_E:Lnet/minecraft/client/settings/KeyBinding;
        //   437: dup            
        //   438: pop            
        //   439: goto            443
        //   442: athrow         
        //   443: invokevirtual   net/minecraft/client/settings/KeyBinding.func_151463_i:()I
        //   446: goto            450
        //   449: athrow         
        //   450: if_icmpne       458
        //   453: ldc             -1015260674
        //   455: goto            460
        //   458: ldc             -1015260687
        //   460: ldc             343648985
        //   462: ixor           
        //   463: tableswitch {
        //          -1374689714: 484
        //          -1374689713: 1059
        //          default: 453
        //        }
        //   484: getstatic       dev/nuker/pyro/f64.c:Ldev/nuker/pyro/f99;
        //   487: goto            491
        //   490: athrow         
        //   491: invokevirtual   dev/nuker/pyro/f99.c:()Z
        //   494: goto            498
        //   497: athrow         
        //   498: ifeq            1059
        //   501: getstatic       dev/nuker/pyro/f64.c:Ldev/nuker/pyro/f99;
        //   504: getstatic       dev/nuker/pyro/fc.1:I
        //   507: ifne            515
        //   510: ldc             370171672
        //   512: goto            517
        //   515: ldc             560806771
        //   517: ldc             612725446
        //   519: ixor           
        //   520: lookupswitch {
        //          48985457: 515
        //          848637406: 1074
        //          default: 548
        //        }
        //   548: goto            552
        //   551: athrow         
        //   552: invokevirtual   dev/nuker/pyro/f99.4:()Ldev/nuker/pyro/f0k;
        //   555: goto            559
        //   558: athrow         
        //   559: getstatic       dev/nuker/pyro/fc.c:I
        //   562: ifne            570
        //   565: ldc             2024568137
        //   567: goto            572
        //   570: ldc             1354817727
        //   572: ldc             723116965
        //   574: ixor           
        //   575: lookupswitch {
        //          350469714: 570
        //          1404409580: 1066
        //          default: 600
        //        }
        //   600: goto            604
        //   603: athrow         
        //   604: invokevirtual   dev/nuker/pyro/f0k.c:()Ljava/lang/Object;
        //   607: goto            611
        //   610: athrow         
        //   611: checkcast       Ljava/lang/Boolean;
        //   614: goto            618
        //   617: athrow         
        //   618: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   621: goto            625
        //   624: athrow         
        //   625: ifeq            633
        //   628: ldc             2062737932
        //   630: goto            635
        //   633: ldc             2062737935
        //   635: ldc             1180482701
        //   637: ixor           
        //   638: tableswitch {
        //          2036120834: 660
        //          2036120835: 1059
        //          default: 628
        //        }
        //   660: goto            664
        //   663: athrow         
        //   664: invokestatic    baritone/api/BaritoneAPI.getProvider:()Lbaritone/api/IBaritoneProvider;
        //   667: goto            671
        //   670: athrow         
        //   671: dup            
        //   672: pop            
        //   673: getstatic       dev/nuker/pyro/fc.c:I
        //   676: ifne            684
        //   679: ldc             -945785079
        //   681: goto            686
        //   684: ldc             -1832695855
        //   686: ldc             902550976
        //   688: ixor           
        //   689: lookupswitch {
        //          -1275418278: 684
        //          -227826999: 1062
        //          default: 716
        //        }
        //   716: goto            720
        //   719: athrow         
        //   720: invokeinterface baritone/api/IBaritoneProvider.getPrimaryBaritone:()Lbaritone/api/IBaritone;
        //   725: goto            729
        //   728: athrow         
        //   729: dup            
        //   730: pop            
        //   731: goto            735
        //   734: athrow         
        //   735: invokeinterface baritone/api/IBaritone.getPathingBehavior:()Lbaritone/api/behavior/IPathingBehavior;
        //   740: goto            744
        //   743: athrow         
        //   744: dup            
        //   745: pop            
        //   746: getstatic       dev/nuker/pyro/fc.c:I
        //   749: ifne            757
        //   752: ldc             -817531035
        //   754: goto            759
        //   757: ldc             801234669
        //   759: ldc             221611582
        //   761: ixor           
        //   762: lookupswitch {
        //          -1032785573: 757
        //          586438867: 788
        //          default: 1078
        //        }
        //   788: goto            792
        //   791: athrow         
        //   792: invokeinterface baritone/api/behavior/IPathingBehavior.isPathing:()Z
        //   797: goto            801
        //   800: athrow         
        //   801: ifeq            1059
        //   804: getstatic       dev/nuker/pyro/fc.c:I
        //   807: ifne            815
        //   810: ldc             458306437
        //   812: goto            817
        //   815: ldc             -363557889
        //   817: ldc             1122404847
        //   819: ixor           
        //   820: lookupswitch {
        //          -1464729072: 848
        //          1505213034: 815
        //          default: 1064
        //        }
        //   848: getstatic       dev/nuker/pyro/f64.c:Ldev/nuker/pyro/fb4;
        //   851: getfield        dev/nuker/pyro/fb4.c:Ldev/nuker/pyro/fw;
        //   854: getstatic       dev/nuker/pyro/fc.1:I
        //   857: ifne            865
        //   860: ldc             1596452790
        //   862: goto            867
        //   865: ldc             -836010256
        //   867: ldc             -933003865
        //   869: ixor           
        //   870: lookupswitch {
        //          -1757113839: 1070
        //          -154439052: 865
        //          default: 896
        //        }
        //   896: goto            900
        //   899: athrow         
        //   900: invokevirtual   dev/nuker/pyro/fw.0:()Ljava/lang/Object;
        //   903: goto            907
        //   906: athrow         
        //   907: checkcast       Ljava/lang/Boolean;
        //   910: getstatic       dev/nuker/pyro/fc.1:I
        //   913: ifne            922
        //   916: ldc_w           2051255259
        //   919: goto            925
        //   922: ldc_w           -1890767963
        //   925: ldc_w           -716333296
        //   928: ixor           
        //   929: lookupswitch {
        //          -1358023477: 922
        //          1509995701: 956
        //          default: 1068
        //        }
        //   956: goto            960
        //   959: athrow         
        //   960: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   963: goto            967
        //   966: athrow         
        //   967: ifne            976
        //   970: ldc_w           -1683388807
        //   973: goto            979
        //   976: ldc_w           -1683388808
        //   979: ldc_w           -731906701
        //   982: ixor           
        //   983: tableswitch {
        //          -1611860460: 1004
        //          -1611860459: 1059
        //          default: 970
        //        }
        //  1004: goto            1008
        //  1007: athrow         
        //  1008: invokestatic    baritone/api/BaritoneAPI.getProvider:()Lbaritone/api/IBaritoneProvider;
        //  1011: goto            1015
        //  1014: athrow         
        //  1015: dup            
        //  1016: pop            
        //  1017: goto            1021
        //  1020: athrow         
        //  1021: invokeinterface baritone/api/IBaritoneProvider.getPrimaryBaritone:()Lbaritone/api/IBaritone;
        //  1026: goto            1030
        //  1029: athrow         
        //  1030: dup            
        //  1031: pop            
        //  1032: goto            1036
        //  1035: athrow         
        //  1036: invokeinterface baritone/api/IBaritone.getPathingBehavior:()Lbaritone/api/behavior/IPathingBehavior;
        //  1041: goto            1045
        //  1044: athrow         
        //  1045: goto            1049
        //  1048: athrow         
        //  1049: invokeinterface baritone/api/behavior/IPathingBehavior.cancelEverything:()Z
        //  1054: goto            1058
        //  1057: athrow         
        //  1058: pop            
        //  1059: return         
        //  1060: aconst_null    
        //  1061: athrow         
        //  1062: aconst_null    
        //  1063: athrow         
        //  1064: aconst_null    
        //  1065: athrow         
        //  1066: aconst_null    
        //  1067: athrow         
        //  1068: aconst_null    
        //  1069: athrow         
        //  1070: aconst_null    
        //  1071: athrow         
        //  1072: aconst_null    
        //  1073: athrow         
        //  1074: aconst_null    
        //  1075: athrow         
        //  1076: aconst_null    
        //  1077: athrow         
        //  1078: aconst_null    
        //  1079: athrow         
        //  1080: aconst_null    
        //  1081: athrow         
        //  1082: aconst_null    
        //  1083: athrow         
        //  1084: aconst_null    
        //  1085: athrow         
        //  1086: pop            
        //  1087: goto            24
        //  1090: pop            
        //  1091: aconst_null    
        //  1092: goto            1086
        //  1095: dup            
        //  1096: ifnull          1086
        //  1099: checkcast       Ljava/lang/Throwable;
        //  1102: athrow         
        //  1103: dup            
        //  1104: ifnull          1090
        //  1107: checkcast       Ljava/lang/Throwable;
        //  1110: athrow         
        //  1111: aconst_null    
        //  1112: athrow         
        //    StackMapTable: 00 A8 43 07 00 24 04 FF 00 0B 00 00 00 01 07 00 24 FD 00 03 07 00 03 07 00 63 45 07 00 24 40 07 00 63 45 07 00 24 40 01 4E 07 00 24 00 45 07 00 24 40 01 4A 01 FF 00 01 00 02 07 00 03 07 00 63 00 02 01 01 5D 01 FC 00 0B 01 41 01 1D 4B 01 FF 00 01 00 03 07 00 03 07 00 63 01 00 02 01 01 5D 01 47 07 00 24 FF 00 00 00 03 07 00 03 07 00 63 01 00 02 01 07 00 83 45 07 00 24 FF 00 00 00 03 07 00 03 07 00 63 01 00 02 01 01 0D 41 01 1B FF 00 0E 00 00 00 01 07 00 24 FF 00 00 00 03 07 00 03 07 00 63 01 00 03 07 00 03 08 01 04 08 01 04 45 07 00 24 FF 00 00 00 03 07 00 03 07 00 63 01 00 02 07 00 03 07 00 8B 02 0A 41 01 1C 4C 07 00 24 FF 00 00 00 03 07 00 03 07 00 63 01 00 02 07 00 69 07 00 91 45 07 00 24 00 02 45 07 00 24 40 07 00 9C 45 07 00 24 40 07 00 97 43 07 00 24 FF 00 00 00 03 07 00 03 07 00 63 01 00 02 07 00 97 01 45 07 00 24 00 46 07 00 24 FF 00 00 00 03 07 00 03 07 00 63 01 00 02 07 00 2B 01 45 07 00 24 00 4B 01 FF 00 01 00 03 07 00 03 07 00 63 01 00 02 01 01 5C 01 FF 00 0D 00 00 00 01 07 00 24 FF 00 00 00 03 07 00 03 07 00 63 01 00 02 01 07 00 83 45 07 00 24 FF 00 00 00 03 07 00 03 07 00 63 01 00 02 01 01 02 04 41 01 17 45 07 00 24 40 07 00 B8 45 07 00 24 40 01 50 07 00 B8 FF 00 01 00 03 07 00 03 07 00 63 01 00 02 07 00 B8 01 5E 07 00 B8 42 07 00 4F 40 07 00 B8 45 07 00 24 40 07 00 C5 4A 07 00 C5 FF 00 01 00 03 07 00 03 07 00 63 01 00 02 07 00 C5 01 5B 07 00 C5 42 07 00 39 40 07 00 C5 45 07 00 24 40 07 01 0A 45 07 00 24 40 07 00 CA 45 07 00 24 40 01 02 04 41 01 18 FF 00 02 00 00 00 01 07 00 24 FE 00 00 07 00 03 07 00 63 01 45 07 00 24 40 07 00 DB 4C 07 00 DB FF 00 01 00 03 07 00 03 07 00 63 01 00 02 07 00 DB 01 5D 07 00 DB 42 07 00 39 40 07 00 DB 47 07 00 24 40 07 00 E1 44 07 00 24 40 07 00 E1 47 07 00 24 40 07 00 EA 4C 07 00 EA FF 00 01 00 03 07 00 03 07 00 63 01 00 02 07 00 EA 01 5C 07 00 EA 42 07 00 4F 40 07 00 EA 47 07 00 24 40 01 0D 41 01 1E 50 07 00 FD FF 00 01 00 03 07 00 03 07 00 63 01 00 02 07 00 FD 01 5C 07 00 FD 42 07 00 24 40 07 00 FD 45 07 00 24 40 07 01 0A 4E 07 00 CA FF 00 02 00 03 07 00 03 07 00 63 01 00 02 07 00 CA 01 5E 07 00 CA 42 07 00 51 40 07 00 CA 45 07 00 24 40 01 02 05 42 01 18 42 07 00 24 00 45 07 00 24 40 07 00 DB 44 07 00 24 40 07 00 DB 47 07 00 24 40 07 00 E1 44 07 00 39 40 07 00 E1 47 07 00 24 40 07 00 EA 42 07 00 24 40 07 00 EA 47 07 00 24 40 01 FA 00 00 FC 00 00 01 41 07 00 DB 01 41 07 00 C5 41 07 00 CA 41 07 00 FD 01 41 07 00 B8 FF 00 01 00 02 07 00 03 07 00 63 00 01 01 FF 00 01 00 03 07 00 03 07 00 63 01 00 01 07 00 EA 41 01 41 01 01 FF 00 01 00 02 07 00 03 07 00 63 00 01 07 00 24 43 05 44 07 00 24 47 05 47 07 00 24
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     1095   1103   Any
        //  1095   1103   1095   1103   Any
        //  1111   1113   3      8      Ljava/lang/RuntimeException;
        //  30     37     37     38     Any
        //  31     37     30     31     Any
        //  31     37     37     38     Any
        //  30     37     37     38     Ljava/util/ConcurrentModificationException;
        //  30     37     30     31     Ljava/lang/EnumConstantNotPresentException;
        //  53     60     60     61     Any
        //  54     60     53     54     Any
        //  53     60     60     61     Ljava/lang/ArithmeticException;
        //  54     60     60     61     Ljava/util/ConcurrentModificationException;
        //  53     60     3      8      Any
        //  200    207    207    208    Any
        //  200    207    3      8      Any
        //  201    207    207    208    Any
        //  200    207    200    201    Any
        //  200    207    3      8      Any
        //  268    274    274    275    Any
        //  268    274    3      8      Any
        //  268    274    3      8      Ljava/lang/IllegalArgumentException;
        //  268    274    3      8      Ljava/lang/NumberFormatException;
        //  268    274    3      8      Any
        //  333    340    340    341    Any
        //  334    340    340    341    Ljava/lang/AssertionError;
        //  333    340    340    341    Ljava/util/NoSuchElementException;
        //  333    340    333    334    Any
        //  333    340    333    334    Ljava/lang/AssertionError;
        //  350    357    357    358    Any
        //  351    357    350    351    Any
        //  350    357    350    351    Any
        //  350    357    350    351    Ljava/lang/StringIndexOutOfBoundsException;
        //  350    357    3      8      Any
        //  362    369    369    370    Any
        //  362    369    3      8      Ljava/lang/IllegalStateException;
        //  363    369    369    370    Ljava/lang/ClassCastException;
        //  363    369    3      8      Ljava/util/NoSuchElementException;
        //  362    369    362    363    Any
        //  377    384    384    385    Any
        //  378    384    377    378    Ljava/lang/EnumConstantNotPresentException;
        //  378    384    377    378    Any
        //  378    384    377    378    Ljava/lang/ArithmeticException;
        //  377    384    377    378    Any
        //  443    449    449    450    Any
        //  443    449    3      8      Ljava/util/NoSuchElementException;
        //  443    449    3      8      Any
        //  443    449    3      8      Any
        //  443    449    449    450    Ljava/lang/IndexOutOfBoundsException;
        //  490    497    497    498    Any
        //  490    497    3      8      Any
        //  491    497    497    498    Any
        //  491    497    490    491    Any
        //  491    497    3      8      Any
        //  551    558    558    559    Any
        //  552    558    551    552    Ljava/lang/EnumConstantNotPresentException;
        //  552    558    3      8      Ljava/util/ConcurrentModificationException;
        //  552    558    3      8      Any
        //  551    558    3      8      Ljava/lang/NegativeArraySizeException;
        //  603    610    610    611    Any
        //  604    610    610    611    Ljava/lang/IllegalStateException;
        //  603    610    610    611    Any
        //  604    610    603    604    Ljava/lang/RuntimeException;
        //  604    610    610    611    Ljava/lang/IndexOutOfBoundsException;
        //  617    624    624    625    Any
        //  618    624    3      8      Any
        //  617    624    617    618    Any
        //  618    624    3      8      Any
        //  617    624    3      8      Any
        //  664    670    670    671    Any
        //  664    670    3      8      Ljava/lang/UnsupportedOperationException;
        //  664    670    3      8      Any
        //  664    670    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  664    670    3      8      Any
        //  719    728    728    729    Any
        //  719    728    3      8      Any
        //  719    728    719    720    Ljava/lang/EnumConstantNotPresentException;
        //  719    728    719    720    Ljava/lang/UnsupportedOperationException;
        //  719    728    728    729    Any
        //  734    743    743    744    Any
        //  735    743    743    744    Any
        //  735    743    743    744    Any
        //  734    743    3      8      Any
        //  735    743    734    735    Any
        //  791    800    800    801    Any
        //  791    800    800    801    Ljava/lang/IllegalArgumentException;
        //  792    800    3      8      Any
        //  792    800    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  792    800    791    792    Ljava/lang/EnumConstantNotPresentException;
        //  899    906    906    907    Any
        //  899    906    3      8      Any
        //  899    906    3      8      Any
        //  900    906    3      8      Ljava/lang/IllegalStateException;
        //  899    906    899    900    Any
        //  959    966    966    967    Any
        //  960    966    3      8      Ljava/lang/NullPointerException;
        //  960    966    959    960    Ljava/lang/ArithmeticException;
        //  960    966    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  960    966    3      8      Any
        //  1007   1014   1014   1015   Any
        //  1007   1014   1014   1015   Any
        //  1007   1014   1007   1008   Any
        //  1007   1014   1014   1015   Ljava/lang/UnsupportedOperationException;
        //  1008   1014   3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  1020   1029   1029   1030   Any
        //  1021   1029   1020   1021   Any
        //  1020   1029   1020   1021   Ljava/lang/NumberFormatException;
        //  1021   1029   3      8      Any
        //  1021   1029   3      8      Any
        //  1035   1044   1044   1045   Any
        //  1036   1044   1044   1045   Ljava/lang/RuntimeException;
        //  1036   1044   1035   1036   Ljava/lang/RuntimeException;
        //  1036   1044   3      8      Ljava/lang/IndexOutOfBoundsException;
        //  1036   1044   3      8      Any
        //  1048   1057   1057   1058   Any
        //  1049   1057   1048   1049   Any
        //  1049   1057   1048   1049   Ljava/lang/IllegalArgumentException;
        //  1048   1057   3      8      Any
        //  1048   1057   1057   1058   Ljava/lang/UnsupportedOperationException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:414)
        //     at com.strobel.assembler.ir.Instruction.accept(Instruction.java:490)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:403)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @f0g
    @LauncherEventHide
    public void c(@NotNull final f4e p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          3319
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            3311
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            3303
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: getstatic       dev/nuker/pyro/fc.1:I
        //    27: ifne            36
        //    30: ldc_w           877283484
        //    33: goto            39
        //    36: ldc_w           2092754780
        //    39: ldc_w           35738181
        //    42: ixor           
        //    43: lookupswitch {
        //          912988889: 36
        //          2124264729: 68
        //          default: 3282
        //        }
        //    68: aload_1        
        //    69: pop            
        //    70: aload_1        
        //    71: goto            75
        //    74: athrow         
        //    75: invokevirtual   dev/nuker/pyro/f4e.c:()Ldev/nuker/pyro/f41;
        //    78: goto            82
        //    81: athrow         
        //    82: getstatic       dev/nuker/pyro/fc.0:I
        //    85: ifgt            94
        //    88: ldc_w           1785009956
        //    91: goto            97
        //    94: ldc_w           1488702788
        //    97: ldc_w           -341903519
        //   100: ixor           
        //   101: lookupswitch {
        //          -2114199483: 94
        //          -1289405915: 128
        //          default: 3230
        //        }
        //   128: getstatic       dev/nuker/pyro/f41.c:Ldev/nuker/pyro/f41;
        //   131: if_acmpne       140
        //   134: ldc_w           1240754442
        //   137: goto            143
        //   140: ldc_w           1240754441
        //   143: ldc_w           -66043117
        //   146: ixor           
        //   147: tableswitch {
        //          1808290866: 168
        //          1808290867: 3071
        //          default: 134
        //        }
        //   168: getstatic       dev/nuker/pyro/fc.c:I
        //   171: ifne            180
        //   174: ldc_w           -1942286846
        //   177: goto            183
        //   180: ldc_w           1465027140
        //   183: ldc_w           370386320
        //   186: ixor           
        //   187: lookupswitch {
        //          -1708610670: 3254
        //          -593621142: 180
        //          default: 212
        //        }
        //   212: aload_1        
        //   213: goto            217
        //   216: athrow         
        //   217: invokevirtual   dev/nuker/pyro/f4e.c:()Lnet/minecraft/network/Packet;
        //   220: goto            224
        //   223: athrow         
        //   224: instanceof      Lnet/minecraft/network/play/server/SPacketPlayerListItem;
        //   227: ifeq            1388
        //   230: getstatic       dev/nuker/pyro/fc.0:I
        //   233: ifgt            242
        //   236: ldc_w           1001908111
        //   239: goto            245
        //   242: ldc_w           221989357
        //   245: ldc_w           -834225542
        //   248: ixor           
        //   249: lookupswitch {
        //          -628184222: 242
        //          -168731147: 3248
        //          default: 276
        //        }
        //   276: aload_1        
        //   277: goto            281
        //   280: athrow         
        //   281: invokevirtual   dev/nuker/pyro/f4e.c:()Lnet/minecraft/network/Packet;
        //   284: goto            288
        //   287: athrow         
        //   288: dup            
        //   289: ifnonnull       298
        //   292: ldc_w           -871688609
        //   295: goto            301
        //   298: ldc_w           -871688610
        //   301: ldc_w           968529615
        //   304: ixor           
        //   305: tableswitch {
        //          -345833184: 328
        //          -345833183: 358
        //          default: 292
        //        }
        //   328: new             Lkotlin/TypeCastException;
        //   331: dup            
        //   332: ldc_w           "\u0e19\ub250\ubd51\uafb9\u5055\u6af1\u7e41\u5a44\uc0dc\u94fc\ua8ba\u1344\uf229\u731a\ua784\u7ef9\ub210\u7fd2\u0347\u3066\u21f6\ufecb\u59dd\u8a4b\u0139\u0e73\u7fb6\u9a3b\ud3e4\u4525\u7735\u6bee\u474f\u9570\uf0de\u7070\ufdac\u23d5\u1a52\u7db3\u551e\uac0f\ube62\ufb39\u8bfb\u976b\u4c30\u0c5a\u4835\u9568\u4b41\u916c\u0003\u6dcd\uc1d4\u3da3\u7a49\u39f0\u9d6f\ue480\ud4db\u4c6b\u7b1d\u14ce\u06ba\u62d9\u7982\ud4aa\u5df1\ubcd2\ud886\u1df0\uc192\ub46d\uf74e\u243f\u2aee\u5504\u4669\u4b08\uf968\u173e\u1811\u8dda\ue764\u0b0d\u9b88\ub0b4\ucaf4\ufa92\u9ce2\ueb08"
        //   335: goto            339
        //   338: athrow         
        //   339: invokestatic    invokestatic   !!! ERROR
        //   342: goto            346
        //   345: athrow         
        //   346: goto            350
        //   349: athrow         
        //   350: invokespecial   kotlin/TypeCastException.<init>:(Ljava/lang/String;)V
        //   353: goto            357
        //   356: athrow         
        //   357: athrow         
        //   358: checkcast       Lnet/minecraft/network/play/server/SPacketPlayerListItem;
        //   361: astore_2       
        //   362: nop            
        //   363: aload_2        
        //   364: getstatic       dev/nuker/pyro/fc.c:I
        //   367: ifne            376
        //   370: ldc_w           -1801220155
        //   373: goto            379
        //   376: ldc_w           772167048
        //   379: ldc_w           1676692794
        //   382: ixor           
        //   383: lookupswitch {
        //          -145505537: 376
        //          1307973810: 408
        //          default: 3228
        //        }
        //   408: goto            412
        //   411: athrow         
        //   412: invokevirtual   net/minecraft/network/play/server/SPacketPlayerListItem.func_179767_a:()Ljava/util/List;
        //   415: goto            419
        //   418: athrow         
        //   419: dup            
        //   420: pop            
        //   421: checkcast       Ljava/lang/Iterable;
        //   424: astore_3       
        //   425: iconst_0       
        //   426: istore          4
        //   428: aload_3        
        //   429: goto            433
        //   432: athrow         
        //   433: invokeinterface java/lang/Iterable.iterator:()Ljava/util/Iterator;
        //   438: goto            442
        //   441: athrow         
        //   442: astore          5
        //   444: aload           5
        //   446: getstatic       dev/nuker/pyro/fc.c:I
        //   449: ifne            458
        //   452: ldc_w           -1716526390
        //   455: goto            461
        //   458: ldc_w           -529801517
        //   461: ldc_w           -436058973
        //   464: ixor           
        //   465: lookupswitch {
        //          107584112: 492
        //          2142086761: 458
        //          default: 3220
        //        }
        //   492: goto            496
        //   495: athrow         
        //   496: invokeinterface java/util/Iterator.hasNext:()Z
        //   501: goto            505
        //   504: athrow         
        //   505: ifeq            1372
        //   508: aload           5
        //   510: getstatic       dev/nuker/pyro/fc.c:I
        //   513: ifne            522
        //   516: ldc_w           -2041554366
        //   519: goto            525
        //   522: ldc_w           -1656602487
        //   525: ldc_w           994474273
        //   528: ixor           
        //   529: lookupswitch {
        //          -1122622621: 3270
        //          -475569001: 522
        //          default: 556
        //        }
        //   556: goto            560
        //   559: athrow         
        //   560: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   565: goto            569
        //   568: athrow         
        //   569: astore          6
        //   571: aload           6
        //   573: checkcast       Lnet/minecraft/network/play/server/SPacketPlayerListItem$AddPlayerData;
        //   576: getstatic       dev/nuker/pyro/fc.1:I
        //   579: ifne            588
        //   582: ldc_w           973298994
        //   585: goto            591
        //   588: ldc_w           -132150412
        //   591: ldc_w           -1501540462
        //   594: ixor           
        //   595: lookupswitch {
        //          -1669131616: 588
        //          1587528934: 620
        //          default: 3236
        //        }
        //   620: astore          7
        //   622: iconst_0       
        //   623: getstatic       dev/nuker/pyro/fc.c:I
        //   626: ifne            635
        //   629: ldc_w           -426134242
        //   632: goto            638
        //   635: ldc_w           990996419
        //   638: ldc_w           2049722097
        //   641: ixor           
        //   642: lookupswitch {
        //          -1665797137: 635
        //          1094525234: 668
        //          default: 3278
        //        }
        //   668: istore          8
        //   670: aload           7
        //   672: ifnull          1368
        //   675: aload           7
        //   677: goto            681
        //   680: athrow         
        //   681: invokevirtual   net/minecraft/network/play/server/SPacketPlayerListItem$AddPlayerData.func_179962_a:()Lcom/mojang/authlib/GameProfile;
        //   684: goto            688
        //   687: athrow         
        //   688: ifnull          1368
        //   691: aload           7
        //   693: goto            697
        //   696: athrow         
        //   697: invokevirtual   net/minecraft/network/play/server/SPacketPlayerListItem$AddPlayerData.func_179962_a:()Lcom/mojang/authlib/GameProfile;
        //   700: goto            704
        //   703: athrow         
        //   704: dup            
        //   705: pop            
        //   706: goto            710
        //   709: athrow         
        //   710: invokevirtual   com/mojang/authlib/GameProfile.getName:()Ljava/lang/String;
        //   713: goto            717
        //   716: athrow         
        //   717: ifnull          1368
        //   720: aload_2        
        //   721: goto            725
        //   724: athrow         
        //   725: invokevirtual   net/minecraft/network/play/server/SPacketPlayerListItem.func_179768_b:()Lnet/minecraft/network/play/server/SPacketPlayerListItem$Action;
        //   728: goto            732
        //   731: athrow         
        //   732: getstatic       net/minecraft/network/play/server/SPacketPlayerListItem$Action.REMOVE_PLAYER:Lnet/minecraft/network/play/server/SPacketPlayerListItem$Action;
        //   735: if_acmpne       1191
        //   738: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //   741: dup            
        //   742: pop            
        //   743: goto            747
        //   746: athrow         
        //   747: invokevirtual   net/minecraft/client/Minecraft.func_147114_u:()Lnet/minecraft/client/network/NetHandlerPlayClient;
        //   750: goto            754
        //   753: athrow         
        //   754: dup            
        //   755: ifnonnull       764
        //   758: ldc_w           1272650282
        //   761: goto            767
        //   764: ldc_w           1272650283
        //   767: ldc_w           -1400469284
        //   770: ixor           
        //   771: tableswitch {
        //          -826595860: 792
        //          -826595859: 803
        //          default: 758
        //        }
        //   792: goto            796
        //   795: athrow         
        //   796: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //   799: goto            803
        //   802: athrow         
        //   803: dup            
        //   804: pop            
        //   805: goto            809
        //   808: athrow         
        //   809: invokevirtual   net/minecraft/client/network/NetHandlerPlayClient.func_175106_d:()Ljava/util/Collection;
        //   812: goto            816
        //   815: athrow         
        //   816: goto            820
        //   819: athrow         
        //   820: invokeinterface java/util/Collection.iterator:()Ljava/util/Iterator;
        //   825: goto            829
        //   828: athrow         
        //   829: astore          9
        //   831: aload           9
        //   833: goto            837
        //   836: athrow         
        //   837: invokeinterface java/util/Iterator.hasNext:()Z
        //   842: goto            846
        //   845: athrow         
        //   846: ifeq            1368
        //   849: aload           9
        //   851: goto            855
        //   854: athrow         
        //   855: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   860: goto            864
        //   863: athrow         
        //   864: checkcast       Lnet/minecraft/client/network/NetworkPlayerInfo;
        //   867: astore          10
        //   869: getstatic       dev/nuker/pyro/fc.0:I
        //   872: ifgt            881
        //   875: ldc_w           -1104256091
        //   878: goto            884
        //   881: ldc_w           -123146918
        //   884: ldc_w           -1819769515
        //   887: ixor           
        //   888: lookupswitch {
        //          765912816: 881
        //          1797285903: 916
        //          default: 3280
        //        }
        //   916: aload           10
        //   918: dup            
        //   919: pop            
        //   920: goto            924
        //   923: athrow         
        //   924: invokevirtual   net/minecraft/client/network/NetworkPlayerInfo.func_178845_a:()Lcom/mojang/authlib/GameProfile;
        //   927: goto            931
        //   930: athrow         
        //   931: dup            
        //   932: pop            
        //   933: goto            937
        //   936: athrow         
        //   937: invokevirtual   com/mojang/authlib/GameProfile.getId:()Ljava/util/UUID;
        //   940: goto            944
        //   943: athrow         
        //   944: aload           7
        //   946: goto            950
        //   949: athrow         
        //   950: invokevirtual   net/minecraft/network/play/server/SPacketPlayerListItem$AddPlayerData.func_179962_a:()Lcom/mojang/authlib/GameProfile;
        //   953: goto            957
        //   956: athrow         
        //   957: dup            
        //   958: pop            
        //   959: goto            963
        //   962: athrow         
        //   963: invokevirtual   com/mojang/authlib/GameProfile.getId:()Ljava/util/UUID;
        //   966: goto            970
        //   969: athrow         
        //   970: goto            974
        //   973: athrow         
        //   974: invokestatic    kotlin/jvm/internal/Intrinsics.areEqual:(Ljava/lang/Object;Ljava/lang/Object;)Z
        //   977: goto            981
        //   980: athrow         
        //   981: ifeq            1188
        //   984: goto            988
        //   987: athrow         
        //   988: invokestatic    dev/nuker/pyro/Pyro.getEventManager:()Ldev/nuker/pyro/f0f;
        //   991: goto            995
        //   994: athrow         
        //   995: new             Ldev/nuker/pyro/f4d;
        //   998: dup            
        //   999: getstatic       dev/nuker/pyro/fc.0:I
        //  1002: ifgt            1011
        //  1005: ldc_w           1434150398
        //  1008: goto            1014
        //  1011: ldc_w           -413550356
        //  1014: ldc_w           2060247449
        //  1017: ixor           
        //  1018: lookupswitch {
        //          -1658047525: 1011
        //          800556135: 3232
        //          default: 1044
        //        }
        //  1044: aload           7
        //  1046: goto            1050
        //  1049: athrow         
        //  1050: invokevirtual   net/minecraft/network/play/server/SPacketPlayerListItem$AddPlayerData.func_179962_a:()Lcom/mojang/authlib/GameProfile;
        //  1053: goto            1057
        //  1056: athrow         
        //  1057: dup            
        //  1058: pop            
        //  1059: getstatic       dev/nuker/pyro/fc.1:I
        //  1062: ifne            1071
        //  1065: ldc_w           -1084477588
        //  1068: goto            1074
        //  1071: ldc_w           -754917301
        //  1074: ldc_w           91204405
        //  1077: ixor           
        //  1078: lookupswitch {
        //          -1171028903: 1071
        //          -697349250: 1104
        //          default: 3252
        //        }
        //  1104: goto            1108
        //  1107: athrow         
        //  1108: invokevirtual   com/mojang/authlib/GameProfile.getName:()Ljava/lang/String;
        //  1111: goto            1115
        //  1114: athrow         
        //  1115: dup            
        //  1116: pop            
        //  1117: goto            1121
        //  1120: athrow         
        //  1121: invokespecial   dev/nuker/pyro/f4d.<init>:(Ljava/lang/String;)V
        //  1124: goto            1128
        //  1127: athrow         
        //  1128: getstatic       dev/nuker/pyro/fc.c:I
        //  1131: ifne            1140
        //  1134: ldc_w           982777152
        //  1137: goto            1143
        //  1140: ldc_w           -303845871
        //  1143: ldc_w           -100424368
        //  1146: ixor           
        //  1147: lookupswitch {
        //          -1064282096: 3246
        //          1917951834: 1140
        //          default: 1172
        //        }
        //  1172: goto            1176
        //  1175: athrow         
        //  1176: invokeinterface dev/nuker/pyro/f0f.0:(Ljava/lang/Object;)V
        //  1181: goto            1185
        //  1184: athrow         
        //  1185: goto            1368
        //  1188: goto            831
        //  1191: aload_2        
        //  1192: goto            1196
        //  1195: athrow         
        //  1196: invokevirtual   net/minecraft/network/play/server/SPacketPlayerListItem.func_179768_b:()Lnet/minecraft/network/play/server/SPacketPlayerListItem$Action;
        //  1199: goto            1203
        //  1202: athrow         
        //  1203: getstatic       net/minecraft/network/play/server/SPacketPlayerListItem$Action.ADD_PLAYER:Lnet/minecraft/network/play/server/SPacketPlayerListItem$Action;
        //  1206: if_acmpne       1368
        //  1209: getstatic       dev/nuker/pyro/fc.c:I
        //  1212: ifne            1221
        //  1215: ldc_w           -3246783
        //  1218: goto            1224
        //  1221: ldc_w           189371208
        //  1224: ldc_w           856353518
        //  1227: ixor           
        //  1228: lookupswitch {
        //          -859529297: 3272
        //          1239420884: 1221
        //          default: 1256
        //        }
        //  1256: goto            1260
        //  1259: athrow         
        //  1260: invokestatic    dev/nuker/pyro/Pyro.getEventManager:()Ldev/nuker/pyro/f0f;
        //  1263: goto            1267
        //  1266: athrow         
        //  1267: new             Ldev/nuker/pyro/f4b;
        //  1270: dup            
        //  1271: getstatic       dev/nuker/pyro/fc.0:I
        //  1274: ifgt            1283
        //  1277: ldc_w           260870646
        //  1280: goto            1286
        //  1283: ldc_w           278437749
        //  1286: ldc_w           -95030980
        //  1289: ixor           
        //  1290: lookupswitch {
        //          -170303286: 3224
        //          -80624847: 1283
        //          default: 1316
        //        }
        //  1316: aload           7
        //  1318: goto            1322
        //  1321: athrow         
        //  1322: invokevirtual   net/minecraft/network/play/server/SPacketPlayerListItem$AddPlayerData.func_179962_a:()Lcom/mojang/authlib/GameProfile;
        //  1325: goto            1329
        //  1328: athrow         
        //  1329: dup            
        //  1330: pop            
        //  1331: goto            1335
        //  1334: athrow         
        //  1335: invokevirtual   com/mojang/authlib/GameProfile.getName:()Ljava/lang/String;
        //  1338: goto            1342
        //  1341: athrow         
        //  1342: dup            
        //  1343: pop            
        //  1344: goto            1348
        //  1347: athrow         
        //  1348: invokespecial   dev/nuker/pyro/f4b.<init>:(Ljava/lang/String;)V
        //  1351: goto            1355
        //  1354: athrow         
        //  1355: goto            1359
        //  1358: athrow         
        //  1359: invokeinterface dev/nuker/pyro/f0f.0:(Ljava/lang/Object;)V
        //  1364: goto            1368
        //  1367: athrow         
        //  1368: nop            
        //  1369: goto            444
        //  1372: goto            1388
        //  1375: astore_3       
        //  1376: aload_3        
        //  1377: goto            1381
        //  1380: athrow         
        //  1381: invokevirtual   java/lang/Exception.printStackTrace:()V
        //  1384: goto            1388
        //  1387: athrow         
        //  1388: getstatic       dev/nuker/pyro/fc.c:I
        //  1391: ifne            1400
        //  1394: ldc_w           -937521269
        //  1397: goto            1403
        //  1400: ldc_w           -1089604968
        //  1403: ldc_w           1417963840
        //  1406: ixor           
        //  1407: lookupswitch {
        //          -1667569973: 3288
        //          -897742044: 1400
        //          default: 1432
        //        }
        //  1432: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //  1435: getstatic       dev/nuker/pyro/fc.0:I
        //  1438: ifgt            1447
        //  1441: ldc_w           -217295398
        //  1444: goto            1450
        //  1447: ldc_w           -2067076046
        //  1450: ldc_w           -1560608700
        //  1453: ixor           
        //  1454: lookupswitch {
        //          640806006: 1480
        //          1375163806: 1447
        //          default: 3244
        //        }
        //  1480: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1483: ifnull          3219
        //  1486: aload_0        
        //  1487: getfield        dev/nuker/pyro/f6.c:Z
        //  1490: ifeq            3219
        //  1493: getstatic       dev/nuker/pyro/f64.c:Ldev/nuker/pyro/f99;
        //  1496: getstatic       dev/nuker/pyro/fc.1:I
        //  1499: ifne            1508
        //  1502: ldc_w           1557821728
        //  1505: goto            1511
        //  1508: ldc_w           -1239878325
        //  1511: ldc_w           229009421
        //  1514: ixor           
        //  1515: lookupswitch {
        //          -1101166705: 1508
        //          1367085357: 3264
        //          default: 1540
        //        }
        //  1540: goto            1544
        //  1543: athrow         
        //  1544: invokevirtual   dev/nuker/pyro/f99.9:()V
        //  1547: goto            1551
        //  1550: athrow         
        //  1551: getstatic       dev/nuker/pyro/f64.c:Ldev/nuker/pyro/fb4;
        //  1554: getfield        dev/nuker/pyro/fb4.c:Ldev/nuker/pyro/fw;
        //  1557: iconst_0       
        //  1558: goto            1562
        //  1561: athrow         
        //  1562: invokestatic    java/lang/Boolean.valueOf:(Z)Ljava/lang/Boolean;
        //  1565: goto            1569
        //  1568: athrow         
        //  1569: goto            1573
        //  1572: athrow         
        //  1573: invokevirtual   dev/nuker/pyro/fw.c:(Ljava/lang/Object;)V
        //  1576: goto            1580
        //  1579: athrow         
        //  1580: getstatic       dev/nuker/pyro/f64.c:Ldev/nuker/pyro/f7p;
        //  1583: getfield        dev/nuker/pyro/f7p.c:Ldev/nuker/pyro/fw;
        //  1586: iconst_0       
        //  1587: getstatic       dev/nuker/pyro/fc.0:I
        //  1590: ifgt            1599
        //  1593: ldc_w           1366461173
        //  1596: goto            1602
        //  1599: ldc_w           1960379130
        //  1602: ldc_w           -1279576920
        //  1605: ixor           
        //  1606: lookupswitch {
        //          -490095011: 3290
        //          1039733918: 1599
        //          default: 1632
        //        }
        //  1632: goto            1636
        //  1635: athrow         
        //  1636: invokestatic    java/lang/Boolean.valueOf:(Z)Ljava/lang/Boolean;
        //  1639: goto            1643
        //  1642: athrow         
        //  1643: goto            1647
        //  1646: athrow         
        //  1647: invokevirtual   dev/nuker/pyro/fw.c:(Ljava/lang/Object;)V
        //  1650: goto            1654
        //  1653: athrow         
        //  1654: getstatic       dev/nuker/pyro/fe4.c:Ldev/nuker/pyro/fe4;
        //  1657: getstatic       dev/nuker/pyro/fc.1:I
        //  1660: ifne            1669
        //  1663: ldc_w           27188149
        //  1666: goto            1672
        //  1669: ldc_w           1928559072
        //  1672: ldc_w           1074912212
        //  1675: ixor           
        //  1676: lookupswitch {
        //          853713460: 1704
        //          1099890785: 1669
        //          default: 3284
        //        }
        //  1704: goto            1708
        //  1707: athrow         
        //  1708: invokevirtual   dev/nuker/pyro/fe4.c:()V
        //  1711: goto            1715
        //  1714: athrow         
        //  1715: getstatic       dev/nuker/pyro/fc.1:I
        //  1718: ifne            1727
        //  1721: ldc_w           1845066331
        //  1724: goto            1730
        //  1727: ldc_w           -1749655143
        //  1730: ldc_w           1221179018
        //  1733: ixor           
        //  1734: lookupswitch {
        //          -618459374: 1727
        //          623955153: 3262
        //          default: 1760
        //        }
        //  1760: getstatic       dev/nuker/pyro/f1R.c:Ldev/nuker/pyro/f1R;
        //  1763: goto            1767
        //  1766: athrow         
        //  1767: invokevirtual   dev/nuker/pyro/f1R.0:()V
        //  1770: goto            1774
        //  1773: athrow         
        //  1774: getstatic       dev/nuker/pyro/fc.c:I
        //  1777: ifne            1786
        //  1780: ldc_w           1115674085
        //  1783: goto            1789
        //  1786: ldc_w           -1533175737
        //  1789: ldc_w           373690121
        //  1792: ixor           
        //  1793: lookupswitch {
        //          -1294231730: 1820
        //          1413077740: 1786
        //          default: 3258
        //        }
        //  1820: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //  1823: dup            
        //  1824: pop            
        //  1825: goto            1829
        //  1828: athrow         
        //  1829: invokevirtual   net/minecraft/client/Minecraft.func_147104_D:()Lnet/minecraft/client/multiplayer/ServerData;
        //  1832: goto            1836
        //  1835: athrow         
        //  1836: ifnull          2599
        //  1839: new             Ljava/lang/StringBuilder;
        //  1842: dup            
        //  1843: goto            1847
        //  1846: athrow         
        //  1847: invokespecial   java/lang/StringBuilder.<init>:()V
        //  1850: goto            1854
        //  1853: athrow         
        //  1854: ldc_w           "\u0e04\ub240\ubd4f\uafa3\u5010\u6ae0\u7e0d"
        //  1857: goto            1861
        //  1860: athrow         
        //  1861: invokestatic    invokestatic   !!! ERROR
        //  1864: goto            1868
        //  1867: athrow         
        //  1868: goto            1872
        //  1871: athrow         
        //  1872: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1875: goto            1879
        //  1878: athrow         
        //  1879: goto            1883
        //  1882: athrow         
        //  1883: invokestatic    net/minecraft/client/Minecraft.func_71410_x:()Lnet/minecraft/client/Minecraft;
        //  1886: goto            1890
        //  1889: athrow         
        //  1890: dup            
        //  1891: pop            
        //  1892: getstatic       dev/nuker/pyro/fc.c:I
        //  1895: ifne            1904
        //  1898: ldc_w           -1901347604
        //  1901: goto            1907
        //  1904: ldc_w           -161253468
        //  1907: ldc_w           -274110148
        //  1910: ixor           
        //  1911: lookupswitch {
        //          432676504: 1936
        //          1627575760: 1904
        //          default: 3250
        //        }
        //  1936: goto            1940
        //  1939: athrow         
        //  1940: invokevirtual   net/minecraft/client/Minecraft.func_147104_D:()Lnet/minecraft/client/multiplayer/ServerData;
        //  1943: goto            1947
        //  1946: athrow         
        //  1947: dup            
        //  1948: ifnonnull       1957
        //  1951: ldc_w           -1897121419
        //  1954: goto            1960
        //  1957: ldc_w           -1897121420
        //  1960: ldc_w           595341447
        //  1963: ixor           
        //  1964: tableswitch {
        //          1528828900: 1988
        //          1528828901: 1999
        //          default: 1951
        //        }
        //  1988: goto            1992
        //  1991: athrow         
        //  1992: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //  1995: goto            1999
        //  1998: athrow         
        //  1999: getstatic       dev/nuker/pyro/fc.1:I
        //  2002: ifne            2011
        //  2005: ldc_w           1380934272
        //  2008: goto            2014
        //  2011: ldc_w           660551151
        //  2014: ldc_w           -1528976314
        //  2017: ixor           
        //  2018: lookupswitch {
        //          -2088592983: 2044
        //          -158150970: 2011
        //          default: 3260
        //        }
        //  2044: getfield        net/minecraft/client/multiplayer/ServerData.field_78845_b:Ljava/lang/String;
        //  2047: dup            
        //  2048: pop            
        //  2049: ldc_w           ":"
        //  2052: aconst_null    
        //  2053: iconst_2       
        //  2054: aconst_null    
        //  2055: goto            2059
        //  2058: athrow         
        //  2059: invokestatic    kotlin/text/StringsKt.substringBeforeLast$default:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Ljava/lang/String;
        //  2062: goto            2066
        //  2065: athrow         
        //  2066: getstatic       dev/nuker/pyro/fc.0:I
        //  2069: ifgt            2078
        //  2072: ldc_w           860242444
        //  2075: goto            2081
        //  2078: ldc_w           2109972771
        //  2081: ldc_w           -491270219
        //  2084: ixor           
        //  2085: lookupswitch {
        //          -1619759466: 2112
        //          -772698695: 2078
        //          default: 3226
        //        }
        //  2112: goto            2116
        //  2115: athrow         
        //  2116: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  2119: goto            2123
        //  2122: athrow         
        //  2123: goto            2127
        //  2126: athrow         
        //  2127: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  2130: goto            2134
        //  2133: athrow         
        //  2134: getstatic       dev/nuker/pyro/fc.1:I
        //  2137: ifne            2146
        //  2140: ldc_w           71050336
        //  2143: goto            2149
        //  2146: ldc_w           99888032
        //  2149: ldc_w           1230000949
        //  2152: ixor           
        //  2153: lookupswitch {
        //          1285847189: 2180
        //          1298954069: 2146
        //          default: 3292
        //        }
        //  2180: astore_2       
        //  2181: getstatic       dev/nuker/pyro/f67.c:Ldev/nuker/pyro/f67;
        //  2184: goto            2188
        //  2187: athrow         
        //  2188: invokevirtual   dev/nuker/pyro/f67.5:()Ljava/util/List;
        //  2191: goto            2195
        //  2194: athrow         
        //  2195: checkcast       Ljava/lang/Iterable;
        //  2198: astore          4
        //  2200: iconst_0       
        //  2201: istore          5
        //  2203: aload           4
        //  2205: getstatic       dev/nuker/pyro/fc.0:I
        //  2208: ifgt            2217
        //  2211: ldc_w           -1578382179
        //  2214: goto            2220
        //  2217: ldc_w           2120580154
        //  2220: ldc_w           -1911458103
        //  2223: ixor           
        //  2224: lookupswitch {
        //          548482995: 2217
        //          804960852: 3238
        //          default: 2252
        //        }
        //  2252: goto            2256
        //  2255: athrow         
        //  2256: invokeinterface java/lang/Iterable.iterator:()Ljava/util/Iterator;
        //  2261: goto            2265
        //  2264: athrow         
        //  2265: astore          6
        //  2267: aload           6
        //  2269: goto            2273
        //  2272: athrow         
        //  2273: invokeinterface java/util/Iterator.hasNext:()Z
        //  2278: goto            2282
        //  2281: athrow         
        //  2282: ifeq            2469
        //  2285: aload           6
        //  2287: goto            2291
        //  2290: athrow         
        //  2291: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //  2296: goto            2300
        //  2299: athrow         
        //  2300: astore          7
        //  2302: getstatic       dev/nuker/pyro/fc.1:I
        //  2305: ifne            2314
        //  2308: ldc_w           -653373338
        //  2311: goto            2317
        //  2314: ldc_w           701023502
        //  2317: ldc_w           -329611492
        //  2320: ixor           
        //  2321: lookupswitch {
        //          -980270574: 2348
        //          894752634: 2314
        //          default: 3222
        //        }
        //  2348: aload           7
        //  2350: checkcast       Ldev/nuker/pyro/f66;
        //  2353: astore          8
        //  2355: iconst_0       
        //  2356: istore          9
        //  2358: aload           8
        //  2360: getstatic       dev/nuker/pyro/fc.c:I
        //  2363: ifne            2372
        //  2366: ldc_w           1186130016
        //  2369: goto            2375
        //  2372: ldc_w           -893816906
        //  2375: ldc_w           -1940677062
        //  2378: ixor           
        //  2379: lookupswitch {
        //          -891193766: 2372
        //          1189802380: 2404
        //          default: 3256
        //        }
        //  2404: goto            2408
        //  2407: athrow         
        //  2408: invokevirtual   dev/nuker/pyro/f66.c:()Ljava/lang/String;
        //  2411: goto            2415
        //  2414: athrow         
        //  2415: aload_2        
        //  2416: goto            2420
        //  2419: athrow         
        //  2420: invokestatic    kotlin/jvm/internal/Intrinsics.areEqual:(Ljava/lang/Object;Ljava/lang/Object;)Z
        //  2423: goto            2427
        //  2426: athrow         
        //  2427: ifeq            2436
        //  2430: ldc_w           1798960268
        //  2433: goto            2439
        //  2436: ldc_w           1798960269
        //  2439: ldc_w           -1763725412
        //  2442: ixor           
        //  2443: tableswitch {
        //          -70470112: 2464
        //          -70470111: 2267
        //          default: 2430
        //        }
        //  2464: aload           7
        //  2466: goto            2470
        //  2469: aconst_null    
        //  2470: checkcast       Ldev/nuker/pyro/f66;
        //  2473: astore_3       
        //  2474: aload_3        
        //  2475: ifnull          2599
        //  2478: getstatic       dev/nuker/pyro/fc.0:I
        //  2481: ifgt            2490
        //  2484: ldc_w           -1613461185
        //  2487: goto            2493
        //  2490: ldc_w           1666783162
        //  2493: ldc_w           -800921012
        //  2496: ixor           
        //  2497: lookupswitch {
        //          -1290011146: 2524
        //          1335255923: 2490
        //          default: 3276
        //        }
        //  2524: getstatic       dev/nuker/pyro/f67.c:Ldev/nuker/pyro/f67;
        //  2527: aload_3        
        //  2528: goto            2532
        //  2531: athrow         
        //  2532: invokevirtual   dev/nuker/pyro/f67.c:(Ldev/nuker/pyro/f66;)V
        //  2535: goto            2539
        //  2538: athrow         
        //  2539: getstatic       dev/nuker/pyro/fZ.c:Ldev/nuker/pyro/fZ;
        //  2542: getstatic       dev/nuker/pyro/fc.1:I
        //  2545: ifne            2554
        //  2548: ldc_w           -2031794797
        //  2551: goto            2557
        //  2554: ldc_w           -512048522
        //  2557: ldc_w           1081809329
        //  2560: ixor           
        //  2561: lookupswitch {
        //          -1593713721: 2588
        //          -962700254: 2554
        //          default: 3266
        //        }
        //  2588: goto            2592
        //  2591: athrow         
        //  2592: invokevirtual   dev/nuker/pyro/fZ.0:()V
        //  2595: goto            2599
        //  2598: athrow         
        //  2599: getstatic       dev/nuker/pyro/WaypointManager.INSTANCE:Ldev/nuker/pyro/WaypointManager;
        //  2602: getstatic       dev/nuker/pyro/fc.c:I
        //  2605: ifne            2614
        //  2608: ldc_w           503276885
        //  2611: goto            2617
        //  2614: ldc_w           -1671888765
        //  2617: ldc_w           -1153486871
        //  2620: ixor           
        //  2621: lookupswitch {
        //          -1674760755: 2614
        //          -1497347396: 3268
        //          default: 2648
        //        }
        //  2648: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //  2651: dup            
        //  2652: pop            
        //  2653: goto            2657
        //  2656: athrow         
        //  2657: invokevirtual   net/minecraft/client/Minecraft.func_147104_D:()Lnet/minecraft/client/multiplayer/ServerData;
        //  2660: goto            2664
        //  2663: athrow         
        //  2664: ifnonnull       2673
        //  2667: ldc_w           -1467570486
        //  2670: goto            2676
        //  2673: ldc_w           -1467570491
        //  2676: ldc_w           814733213
        //  2679: ixor           
        //  2680: tableswitch {
        //          806544046: 2704
        //          806544047: 2954
        //          default: 2667
        //        }
        //  2704: new             Ljava/lang/StringBuilder;
        //  2707: dup            
        //  2708: goto            2712
        //  2711: athrow         
        //  2712: invokespecial   java/lang/StringBuilder.<init>:()V
        //  2715: goto            2719
        //  2718: athrow         
        //  2719: ldc_w           "\u0e04\ub24c\ubd53\uafb2\u5019\u6af7\u7e50\u5a46\uc0d3\u94ea\ua8ab\u1316\uf264"
        //  2722: goto            2726
        //  2725: athrow         
        //  2726: invokestatic    invokestatic   !!! ERROR
        //  2729: goto            2733
        //  2732: athrow         
        //  2733: goto            2737
        //  2736: athrow         
        //  2737: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  2740: goto            2744
        //  2743: athrow         
        //  2744: getstatic       dev/nuker/pyro/fc.0:I
        //  2747: ifgt            2756
        //  2750: ldc_w           -1514478147
        //  2753: goto            2759
        //  2756: ldc_w           -1741676858
        //  2759: ldc_w           312003409
        //  2762: ixor           
        //  2763: lookupswitch {
        //          -1968646761: 2788
        //          -1222496532: 2756
        //          default: 3274
        //        }
        //  2788: goto            2792
        //  2791: athrow         
        //  2792: invokestatic    net/minecraft/client/Minecraft.func_71410_x:()Lnet/minecraft/client/Minecraft;
        //  2795: goto            2799
        //  2798: athrow         
        //  2799: dup            
        //  2800: pop            
        //  2801: goto            2805
        //  2804: athrow         
        //  2805: invokevirtual   net/minecraft/client/Minecraft.func_71401_C:()Lnet/minecraft/server/integrated/IntegratedServer;
        //  2808: goto            2812
        //  2811: athrow         
        //  2812: dup            
        //  2813: ifnonnull       2827
        //  2816: goto            2820
        //  2819: athrow         
        //  2820: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //  2823: goto            2827
        //  2826: athrow         
        //  2827: dup            
        //  2828: pop            
        //  2829: goto            2833
        //  2832: athrow         
        //  2833: invokevirtual   net/minecraft/server/integrated/IntegratedServer.func_71270_I:()Ljava/lang/String;
        //  2836: goto            2840
        //  2839: athrow         
        //  2840: getstatic       dev/nuker/pyro/fc.c:I
        //  2843: ifne            2852
        //  2846: ldc_w           678622372
        //  2849: goto            2855
        //  2852: ldc_w           1023460266
        //  2855: ldc_w           -1693686540
        //  2858: ixor           
        //  2859: lookupswitch {
        //          -1509120162: 2884
        //          -1283551152: 2852
        //          default: 3234
        //        }
        //  2884: goto            2888
        //  2887: athrow         
        //  2888: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  2891: goto            2895
        //  2894: athrow         
        //  2895: getstatic       dev/nuker/pyro/fc.1:I
        //  2898: ifne            2907
        //  2901: ldc_w           -1840816988
        //  2904: goto            2910
        //  2907: ldc_w           1625607095
        //  2910: ldc_w           115490297
        //  2913: ixor           
        //  2914: lookupswitch {
        //          -1801100963: 3286
        //          -964882638: 2907
        //          default: 2940
        //        }
        //  2940: goto            2944
        //  2943: athrow         
        //  2944: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  2947: goto            2951
        //  2950: athrow         
        //  2951: goto            3052
        //  2954: goto            2958
        //  2957: athrow         
        //  2958: invokestatic    net/minecraft/client/Minecraft.func_71410_x:()Lnet/minecraft/client/Minecraft;
        //  2961: goto            2965
        //  2964: athrow         
        //  2965: dup            
        //  2966: pop            
        //  2967: goto            2971
        //  2970: athrow         
        //  2971: invokevirtual   net/minecraft/client/Minecraft.func_147104_D:()Lnet/minecraft/client/multiplayer/ServerData;
        //  2974: goto            2978
        //  2977: athrow         
        //  2978: dup            
        //  2979: ifnonnull       2988
        //  2982: ldc_w           -1333404815
        //  2985: goto            2991
        //  2988: ldc_w           -1333404816
        //  2991: ldc_w           -713238027
        //  2994: ixor           
        //  2995: tableswitch {
        //          -873331448: 3016
        //          -873331447: 3027
        //          default: 2982
        //        }
        //  3016: goto            3020
        //  3019: athrow         
        //  3020: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //  3023: goto            3027
        //  3026: athrow         
        //  3027: getfield        net/minecraft/client/multiplayer/ServerData.field_78845_b:Ljava/lang/String;
        //  3030: dup            
        //  3031: pop            
        //  3032: ldc_w           ":"
        //  3035: ldc_w           ""
        //  3038: iconst_0       
        //  3039: iconst_4       
        //  3040: aconst_null    
        //  3041: goto            3045
        //  3044: athrow         
        //  3045: invokestatic    kotlin/text/StringsKt.replace$default:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Ljava/lang/String;
        //  3048: goto            3052
        //  3051: athrow         
        //  3052: goto            3056
        //  3055: athrow         
        //  3056: invokevirtual   dev/nuker/pyro/WaypointManager.load:(Ljava/lang/String;)V
        //  3059: goto            3063
        //  3062: athrow         
        //  3063: aload_0        
        //  3064: iconst_0       
        //  3065: putfield        dev/nuker/pyro/f6.c:Z
        //  3068: goto            3219
        //  3071: aload_1        
        //  3072: getstatic       dev/nuker/pyro/fc.0:I
        //  3075: ifgt            3084
        //  3078: ldc_w           -481078307
        //  3081: goto            3087
        //  3084: ldc_w           1108447450
        //  3087: ldc_w           -974312277
        //  3090: ixor           
        //  3091: lookupswitch {
        //          -2013479823: 3116
        //          650018678: 3084
        //          default: 3242
        //        }
        //  3116: goto            3120
        //  3119: athrow         
        //  3120: invokevirtual   dev/nuker/pyro/f4e.c:()Lnet/minecraft/network/Packet;
        //  3123: goto            3127
        //  3126: athrow         
        //  3127: instanceof      Lnet/minecraft/network/play/server/SPacketDisconnect;
        //  3130: ifeq            3139
        //  3133: ldc_w           2103278940
        //  3136: goto            3142
        //  3139: ldc_w           2103278941
        //  3142: ldc_w           -991000634
        //  3145: ixor           
        //  3146: tableswitch {
        //          1936192820: 3168
        //          1936192821: 3219
        //          default: 3133
        //        }
        //  3168: aload_0        
        //  3169: iconst_1       
        //  3170: getstatic       dev/nuker/pyro/fc.0:I
        //  3173: ifgt            3182
        //  3176: ldc_w           1547395326
        //  3179: goto            3185
        //  3182: ldc_w           -1887574584
        //  3185: ldc_w           -1852177454
        //  3188: ixor           
        //  3189: lookupswitch {
        //          -1982911582: 3182
        //          -845061332: 3240
        //          default: 3216
        //        }
        //  3216: putfield        dev/nuker/pyro/f6.c:Z
        //  3219: return         
        //  3220: aconst_null    
        //  3221: athrow         
        //  3222: aconst_null    
        //  3223: athrow         
        //  3224: aconst_null    
        //  3225: athrow         
        //  3226: aconst_null    
        //  3227: athrow         
        //  3228: aconst_null    
        //  3229: athrow         
        //  3230: aconst_null    
        //  3231: athrow         
        //  3232: aconst_null    
        //  3233: athrow         
        //  3234: aconst_null    
        //  3235: athrow         
        //  3236: aconst_null    
        //  3237: athrow         
        //  3238: aconst_null    
        //  3239: athrow         
        //  3240: aconst_null    
        //  3241: athrow         
        //  3242: aconst_null    
        //  3243: athrow         
        //  3244: aconst_null    
        //  3245: athrow         
        //  3246: aconst_null    
        //  3247: athrow         
        //  3248: aconst_null    
        //  3249: athrow         
        //  3250: aconst_null    
        //  3251: athrow         
        //  3252: aconst_null    
        //  3253: athrow         
        //  3254: aconst_null    
        //  3255: athrow         
        //  3256: aconst_null    
        //  3257: athrow         
        //  3258: aconst_null    
        //  3259: athrow         
        //  3260: aconst_null    
        //  3261: athrow         
        //  3262: aconst_null    
        //  3263: athrow         
        //  3264: aconst_null    
        //  3265: athrow         
        //  3266: aconst_null    
        //  3267: athrow         
        //  3268: aconst_null    
        //  3269: athrow         
        //  3270: aconst_null    
        //  3271: athrow         
        //  3272: aconst_null    
        //  3273: athrow         
        //  3274: aconst_null    
        //  3275: athrow         
        //  3276: aconst_null    
        //  3277: athrow         
        //  3278: aconst_null    
        //  3279: athrow         
        //  3280: aconst_null    
        //  3281: athrow         
        //  3282: aconst_null    
        //  3283: athrow         
        //  3284: aconst_null    
        //  3285: athrow         
        //  3286: aconst_null    
        //  3287: athrow         
        //  3288: aconst_null    
        //  3289: athrow         
        //  3290: aconst_null    
        //  3291: athrow         
        //  3292: aconst_null    
        //  3293: athrow         
        //  3294: pop            
        //  3295: goto            24
        //  3298: pop            
        //  3299: aconst_null    
        //  3300: goto            3294
        //  3303: dup            
        //  3304: ifnull          3294
        //  3307: checkcast       Ljava/lang/Throwable;
        //  3310: athrow         
        //  3311: dup            
        //  3312: ifnull          3298
        //  3315: checkcast       Ljava/lang/Throwable;
        //  3318: athrow         
        //  3319: aconst_null    
        //  3320: athrow         
        //    StackMapTable: 01 FE 43 07 00 24 04 FF 00 0B 00 00 00 01 07 00 24 FD 00 03 07 00 03 07 01 12 0B 42 01 1C 45 07 00 59 40 07 01 12 45 07 00 24 40 07 01 1A 4B 07 01 1A FF 00 02 00 02 07 00 03 07 01 12 00 02 07 01 1A 01 5E 07 01 1A 05 05 42 01 18 0B 42 01 1C 43 07 00 24 40 07 01 12 45 07 00 24 40 07 02 7C 11 42 01 1E 43 07 00 18 40 07 01 12 45 07 00 24 40 07 02 7C 43 07 02 7C 45 07 02 7C FF 00 02 00 02 07 00 03 07 01 12 00 02 07 02 7C 01 5A 07 02 7C 49 07 00 39 FF 00 00 00 02 07 00 03 07 01 12 00 04 07 02 7C 08 01 48 08 01 48 07 02 7E 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 04 07 02 7C 08 01 48 08 01 48 07 02 7E 42 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 04 07 02 7C 08 01 48 08 01 48 07 02 7E 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 02 7C 07 01 30 40 07 02 7C FF 00 11 00 03 07 00 03 07 01 12 07 01 28 00 01 07 01 28 FF 00 02 00 03 07 00 03 07 01 12 07 01 28 00 02 07 01 28 01 5C 07 01 28 42 07 00 24 40 07 01 28 45 07 00 24 40 07 02 80 FF 00 0C 00 00 00 01 07 00 24 FF 00 00 00 05 07 00 03 07 01 12 07 01 28 07 01 43 01 00 01 07 01 43 47 07 00 24 40 07 01 4C FC 00 01 07 01 4C 4D 07 01 4C FF 00 02 00 06 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 00 02 07 01 4C 01 5E 07 01 4C FF 00 02 00 00 00 01 07 00 24 FF 00 00 00 06 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 00 01 07 01 4C 47 07 00 24 40 01 50 07 01 4C FF 00 02 00 06 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 00 02 07 01 4C 01 5E 07 01 4C 42 07 00 24 40 07 01 4C 47 07 00 24 40 07 01 0A FF 00 12 00 07 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 00 01 07 01 57 FF 00 02 00 07 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 00 02 07 01 57 01 5C 07 01 57 FF 00 0E 00 08 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 00 01 01 FF 00 02 00 08 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 00 02 01 01 5D 01 FF 00 0B 00 09 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 00 01 07 00 24 40 07 01 57 45 07 00 24 40 07 01 63 47 07 00 55 40 07 01 57 45 07 00 24 40 07 01 63 44 07 00 24 40 07 01 63 45 07 00 24 40 07 02 7E 46 07 00 24 40 07 01 28 45 07 00 24 40 07 01 6D 4D 07 00 24 40 07 00 69 45 07 00 24 40 07 01 7F 43 07 01 7F 45 07 01 7F FF 00 02 00 09 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 00 02 07 01 7F 01 58 07 01 7F 42 07 00 24 40 07 01 7F 45 07 00 24 40 07 01 7F 44 07 00 39 40 07 01 7F 45 07 00 24 40 07 01 85 42 07 00 57 40 07 01 85 47 07 00 24 40 07 01 4C FC 00 01 07 01 4C 44 07 00 5D 40 07 01 4C 47 07 00 24 40 01 47 07 00 24 40 07 01 4C 47 07 00 24 40 07 01 0A FC 00 10 07 01 88 42 01 1F FF 00 06 00 00 00 01 07 00 24 FF 00 00 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 01 07 01 88 45 07 00 24 40 07 01 63 44 07 00 12 40 07 01 63 45 07 00 24 40 07 02 82 44 07 00 24 FF 00 00 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 02 07 02 82 07 01 57 45 07 00 24 FF 00 00 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 02 07 02 82 07 01 63 44 07 00 24 FF 00 00 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 02 07 02 82 07 01 63 45 07 00 24 FF 00 00 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 02 07 02 82 07 02 82 42 07 00 24 FF 00 00 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 02 07 02 82 07 02 82 45 07 00 24 40 01 45 07 00 24 00 45 07 00 24 40 07 01 A8 FF 00 0F 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 03 07 01 A8 08 03 E3 08 03 E3 FF 00 02 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 04 07 01 A8 08 03 E3 08 03 E3 01 FF 00 1D 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 03 07 01 A8 08 03 E3 08 03 E3 FF 00 04 00 00 00 01 07 00 24 FF 00 00 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 04 07 01 A8 08 03 E3 08 03 E3 07 01 57 45 07 00 24 FF 00 00 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 04 07 01 A8 08 03 E3 08 03 E3 07 01 63 FF 00 0D 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 04 07 01 A8 08 03 E3 08 03 E3 07 01 63 FF 00 02 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 05 07 01 A8 08 03 E3 08 03 E3 07 01 63 01 FF 00 1D 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 04 07 01 A8 08 03 E3 08 03 E3 07 01 63 FF 00 02 00 00 00 01 07 00 24 FF 00 00 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 04 07 01 A8 08 03 E3 08 03 E3 07 01 63 45 07 00 24 FF 00 00 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 04 07 01 A8 08 03 E3 08 03 E3 07 02 7E 44 07 00 1C FF 00 00 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 04 07 01 A8 08 03 E3 08 03 E3 07 02 7E 45 07 00 24 FF 00 00 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 02 07 01 A8 07 01 9C FF 00 0B 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 02 07 01 A8 07 01 9C FF 00 02 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 03 07 01 A8 07 01 9C 01 FF 00 1C 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 02 07 01 A8 07 01 9C 42 07 00 5D FF 00 00 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 02 07 01 A8 07 01 9C 47 07 00 24 00 02 F9 00 02 43 07 00 24 40 07 01 28 45 07 00 24 40 07 01 6D 11 42 01 1F 42 07 00 24 00 45 07 00 24 40 07 01 A8 FF 00 0F 00 09 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 00 03 07 01 A8 08 04 F3 08 04 F3 FF 00 02 00 09 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 00 04 07 01 A8 08 04 F3 08 04 F3 01 FF 00 1D 00 09 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 00 03 07 01 A8 08 04 F3 08 04 F3 44 07 00 24 FF 00 00 00 09 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 00 04 07 01 A8 08 04 F3 08 04 F3 07 01 57 45 07 00 24 FF 00 00 00 09 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 00 04 07 01 A8 08 04 F3 08 04 F3 07 01 63 FF 00 04 00 00 00 01 07 00 24 FF 00 00 00 09 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 00 04 07 01 A8 08 04 F3 08 04 F3 07 01 63 45 07 00 24 FF 00 00 00 09 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 00 04 07 01 A8 08 04 F3 08 04 F3 07 02 7E 44 07 00 16 FF 00 00 00 09 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 00 04 07 01 A8 08 04 F3 08 04 F3 07 02 7E 45 07 00 24 FF 00 00 00 09 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 00 02 07 01 A8 07 01 B3 42 07 00 18 FF 00 00 00 09 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 00 02 07 01 A8 07 01 B3 47 07 00 24 00 F8 00 03 FF 00 02 00 03 07 00 03 07 01 12 07 01 28 00 01 07 01 0D FF 00 04 00 04 07 00 03 07 01 12 07 01 28 07 01 0D 00 01 07 00 24 40 07 01 0D 45 07 00 24 F9 00 00 0B 42 01 1C 4E 07 00 69 FF 00 02 00 02 07 00 03 07 01 12 00 02 07 00 69 01 5D 07 00 69 5B 07 00 B8 FF 00 02 00 02 07 00 03 07 01 12 00 02 07 00 B8 01 5C 07 00 B8 42 07 00 55 40 07 00 B8 45 07 00 24 00 49 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 00 FD 01 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 00 FD 07 00 CA 42 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 00 FD 07 00 CA 45 07 00 24 00 FF 00 12 00 02 07 00 03 07 01 12 00 02 07 00 FD 01 FF 00 02 00 02 07 00 03 07 01 12 00 03 07 00 FD 01 01 FF 00 1D 00 02 07 00 03 07 01 12 00 02 07 00 FD 01 FF 00 02 00 00 00 01 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 00 FD 01 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 00 FD 07 00 CA FF 00 02 00 00 00 01 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 00 FD 07 00 CA 45 07 00 24 00 4E 07 01 DB FF 00 02 00 02 07 00 03 07 01 12 00 02 07 01 DB 01 5F 07 01 DB 42 07 00 24 40 07 01 DB 45 07 00 24 00 0B 42 01 1D 45 07 00 24 40 07 01 E8 45 07 00 24 00 0B 42 01 1E 47 07 00 24 40 07 00 69 45 07 00 24 40 07 02 0C FF 00 09 00 00 00 01 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 08 07 2F 08 07 2F 45 07 00 24 40 07 01 F6 FF 00 05 00 00 00 01 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 02 7E 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 02 7E 42 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 02 7E 45 07 00 24 40 07 01 F6 42 07 00 24 40 07 01 F6 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 00 69 FF 00 0D 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 00 69 FF 00 02 00 02 07 00 03 07 01 12 00 03 07 01 F6 07 00 69 01 FF 00 1C 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 00 69 42 07 00 51 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 00 69 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 02 0C FF 00 03 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 02 0C FF 00 05 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 02 0C FF 00 02 00 02 07 00 03 07 01 12 00 03 07 01 F6 07 02 0C 01 FF 00 1B 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 02 0C 42 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 02 0C 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 02 0C FF 00 0B 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 02 0C FF 00 02 00 02 07 00 03 07 01 12 00 03 07 01 F6 07 02 0C 01 FF 00 1D 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 02 0C 4D 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 06 07 01 F6 07 02 7E 07 02 7E 05 01 05 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 02 7E FF 00 0B 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 02 7E FF 00 02 00 02 07 00 03 07 01 12 00 03 07 01 F6 07 02 7E 01 FF 00 1E 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 02 7E 42 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 02 7E 45 07 00 24 40 07 01 F6 FF 00 02 00 00 00 01 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 01 07 01 F6 45 07 00 24 40 07 02 7E 4B 07 02 7E FF 00 02 00 02 07 00 03 07 01 12 00 02 07 02 7E 01 5E 07 02 7E FF 00 06 00 00 00 01 07 00 24 FF 00 00 00 03 07 00 03 07 01 12 07 02 7E 00 01 07 02 23 45 07 00 24 40 07 02 80 FF 00 15 00 06 07 00 03 07 01 12 07 02 7E 00 07 01 43 01 00 01 07 01 43 FF 00 02 00 06 07 00 03 07 01 12 07 02 7E 00 07 01 43 01 00 02 07 01 43 01 5F 07 01 43 42 07 00 24 40 07 01 43 47 07 00 24 40 07 01 4C FC 00 01 07 01 4C 44 07 00 51 40 07 01 4C 47 07 00 24 40 01 FF 00 07 00 00 00 01 07 00 24 FF 00 00 00 07 07 00 03 07 01 12 07 02 7E 00 07 01 43 01 07 01 4C 00 01 07 01 4C 47 07 00 24 40 07 01 0A FC 00 0D 07 01 0A 42 01 1E FF 00 17 00 0A 07 00 03 07 01 12 07 02 7E 00 07 01 43 01 07 01 4C 07 01 0A 07 02 31 01 00 01 07 02 31 FF 00 02 00 0A 07 00 03 07 01 12 07 02 7E 00 07 01 43 01 07 01 4C 07 01 0A 07 02 31 01 00 02 07 02 31 01 5C 07 02 31 FF 00 02 00 00 00 01 07 00 24 FF 00 00 00 0A 07 00 03 07 01 12 07 02 7E 00 07 01 43 01 07 01 4C 07 01 0A 07 02 31 01 00 01 07 02 31 45 07 00 24 40 07 02 7E 43 07 00 55 FF 00 00 00 0A 07 00 03 07 01 12 07 02 7E 00 07 01 43 01 07 01 4C 07 01 0A 07 02 31 01 00 02 07 02 7E 07 02 7E 45 07 00 24 40 01 02 05 42 01 18 F8 00 04 40 07 01 0A FF 00 13 00 07 07 00 03 07 01 12 07 02 7E 07 02 31 07 01 43 01 07 01 4C 00 00 42 01 1E FF 00 06 00 00 00 01 07 00 24 FF 00 00 00 07 07 00 03 07 01 12 07 02 7E 07 02 31 07 01 43 01 07 01 4C 00 02 07 02 23 07 02 31 45 07 00 24 00 4E 07 00 2B FF 00 02 00 07 07 00 03 07 01 12 07 02 7E 07 02 31 07 01 43 01 07 01 4C 00 02 07 00 2B 01 5E 07 00 2B 42 07 00 24 40 07 00 2B 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 00 4E 07 02 45 FF 00 02 00 02 07 00 03 07 01 12 00 02 07 02 45 01 5E 07 02 45 47 07 00 39 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 02 45 07 00 69 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 02 45 07 02 0C 42 07 02 45 45 07 02 45 FF 00 02 00 02 07 00 03 07 01 12 00 02 07 02 45 01 5B 07 02 45 46 07 00 39 FF 00 00 00 02 07 00 03 07 01 12 00 03 07 02 45 08 0A 90 08 0A 90 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 02 45 07 01 F6 45 07 00 57 FF 00 00 00 02 07 00 03 07 01 12 00 03 07 02 45 07 01 F6 07 02 7E 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 03 07 02 45 07 01 F6 07 02 7E FF 00 02 00 00 00 01 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 03 07 02 45 07 01 F6 07 02 7E 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 02 45 07 01 F6 FF 00 0B 00 02 07 00 03 07 01 12 00 02 07 02 45 07 01 F6 FF 00 02 00 02 07 00 03 07 01 12 00 03 07 02 45 07 01 F6 01 FF 00 1C 00 02 07 00 03 07 01 12 00 02 07 02 45 07 01 F6 42 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 02 45 07 01 F6 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 03 07 02 45 07 01 F6 07 00 69 FF 00 04 00 00 00 01 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 03 07 02 45 07 01 F6 07 00 69 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 03 07 02 45 07 01 F6 07 02 5A 46 07 00 57 FF 00 00 00 02 07 00 03 07 01 12 00 03 07 02 45 07 01 F6 07 02 5A 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 03 07 02 45 07 01 F6 07 02 5A 44 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 03 07 02 45 07 01 F6 07 02 5A 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 03 07 02 45 07 01 F6 07 02 7E FF 00 0B 00 02 07 00 03 07 01 12 00 03 07 02 45 07 01 F6 07 02 7E FF 00 02 00 02 07 00 03 07 01 12 00 04 07 02 45 07 01 F6 07 02 7E 01 FF 00 1C 00 02 07 00 03 07 01 12 00 03 07 02 45 07 01 F6 07 02 7E 42 07 00 39 FF 00 00 00 02 07 00 03 07 01 12 00 03 07 02 45 07 01 F6 07 02 7E 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 02 45 07 01 F6 FF 00 0B 00 02 07 00 03 07 01 12 00 02 07 02 45 07 01 F6 FF 00 02 00 02 07 00 03 07 01 12 00 03 07 02 45 07 01 F6 01 FF 00 1D 00 02 07 00 03 07 01 12 00 02 07 02 45 07 01 F6 FF 00 02 00 00 00 01 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 02 45 07 01 F6 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 02 45 07 02 7E 42 07 02 45 FF 00 02 00 00 00 01 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 01 07 02 45 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 02 45 07 00 69 FF 00 04 00 00 00 01 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 02 45 07 00 69 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 02 45 07 02 0C FF 00 03 00 02 07 00 03 07 01 12 00 02 07 02 45 07 02 0C FF 00 05 00 02 07 00 03 07 01 12 00 02 07 02 45 07 02 0C FF 00 02 00 02 07 00 03 07 01 12 00 03 07 02 45 07 02 0C 01 FF 00 18 00 02 07 00 03 07 01 12 00 02 07 02 45 07 02 0C 42 07 00 16 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 02 45 07 02 0C 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 02 45 07 02 0C 50 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 07 07 02 45 07 02 7E 07 02 7E 07 02 7E 01 01 05 45 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 02 45 07 02 7E FF 00 02 00 00 00 01 07 00 24 FF 00 00 00 02 07 00 03 07 01 12 00 02 07 02 45 07 02 7E 45 07 00 24 00 07 4C 07 01 12 FF 00 02 00 02 07 00 03 07 01 12 00 02 07 01 12 01 5C 07 01 12 42 07 00 1A 40 07 01 12 45 07 00 24 40 07 02 7C 05 05 42 01 19 FF 00 0D 00 02 07 00 03 07 01 12 00 02 07 00 03 01 FF 00 02 00 02 07 00 03 07 01 12 00 03 07 00 03 01 01 FF 00 1E 00 02 07 00 03 07 01 12 00 02 07 00 03 01 02 FF 00 00 00 06 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 00 01 07 01 4C FF 00 01 00 08 07 00 03 07 01 12 07 02 7E 00 07 01 43 01 07 01 4C 07 01 0A 00 00 FF 00 01 00 09 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 00 03 07 01 A8 08 04 F3 08 04 F3 FF 00 01 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 02 7E FF 00 01 00 03 07 00 03 07 01 12 07 01 28 00 01 07 01 28 FF 00 01 00 02 07 00 03 07 01 12 00 01 07 01 1A FF 00 01 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 03 07 01 A8 08 03 E3 08 03 E3 FF 00 01 00 02 07 00 03 07 01 12 00 03 07 02 45 07 01 F6 07 02 7E FF 00 01 00 07 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 00 01 07 01 57 FF 00 01 00 06 07 00 03 07 01 12 07 02 7E 00 07 01 43 01 00 01 07 01 43 FF 00 01 00 02 07 00 03 07 01 12 00 02 07 00 03 01 41 07 01 12 41 07 00 69 FF 00 01 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 02 07 01 A8 07 01 9C FF 00 01 00 02 07 00 03 07 01 12 00 00 FF 00 01 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 00 69 FF 00 01 00 0B 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 01 07 01 4C 07 01 88 00 04 07 01 A8 08 03 E3 08 03 E3 07 01 63 FF 00 01 00 02 07 00 03 07 01 12 00 00 FF 00 01 00 0A 07 00 03 07 01 12 07 02 7E 00 07 01 43 01 07 01 4C 07 01 0A 07 02 31 01 00 01 07 02 31 FF 00 01 00 02 07 00 03 07 01 12 00 00 FF 00 01 00 02 07 00 03 07 01 12 00 02 07 01 F6 07 02 0C 01 41 07 00 B8 FF 00 01 00 07 07 00 03 07 01 12 07 02 7E 07 02 31 07 01 43 01 07 01 4C 00 01 07 00 2B FF 00 01 00 02 07 00 03 07 01 12 00 01 07 02 45 FF 00 01 00 06 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 00 01 07 01 4C FE 00 01 07 01 0A 07 01 57 01 FF 00 01 00 02 07 00 03 07 01 12 00 02 07 02 45 07 01 F6 FF 00 01 00 07 07 00 03 07 01 12 07 02 7E 07 02 31 07 01 43 01 07 01 4C 00 00 FF 00 01 00 08 07 00 03 07 01 12 07 01 28 07 01 43 01 07 01 4C 07 01 0A 07 01 57 00 01 01 FE 00 01 01 07 01 4C 07 01 88 FF 00 01 00 02 07 00 03 07 01 12 00 00 41 07 01 DB FF 00 01 00 02 07 00 03 07 01 12 00 02 07 02 45 07 01 F6 01 FF 00 01 00 02 07 00 03 07 01 12 00 02 07 00 FD 01 41 07 02 7E 41 07 00 39 43 05 44 07 00 39 47 05 47 07 00 24
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  362    432    1375   1388   Ljava/lang/Exception;
        //  433    495    1375   1388   Ljava/lang/Exception;
        //  496    923    1375   1388   Ljava/lang/Exception;
        //  924    1049   1375   1388   Ljava/lang/Exception;
        //  1050   1107   1375   1388   Ljava/lang/Exception;
        //  1108   1334   1375   1388   Ljava/lang/Exception;
        //  1335   1372   1375   1388   Ljava/lang/Exception;
        //  8      20     3303   3311   Ljava/lang/RuntimeException;
        //  3303   3311   3303   3311   Ljava/lang/IllegalStateException;
        //  3319   3321   3      8      Ljava/lang/IndexOutOfBoundsException;
        //  74     81     81     82     Any
        //  75     81     81     82     Ljava/lang/NullPointerException;
        //  74     81     81     82     Any
        //  74     81     81     82     Ljava/lang/IllegalArgumentException;
        //  74     81     74     75     Ljava/lang/IndexOutOfBoundsException;
        //  216    223    223    224    Any
        //  216    223    3      8      Any
        //  216    223    216    217    Ljava/lang/UnsupportedOperationException;
        //  216    223    3      8      Any
        //  216    223    216    217    Any
        //  280    287    287    288    Any
        //  281    287    287    288    Ljava/lang/IllegalStateException;
        //  280    287    280    281    Ljava/lang/IllegalArgumentException;
        //  280    287    287    288    Any
        //  281    287    287    288    Any
        //  338    345    345    346    Any
        //  338    345    338    339    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  339    345    3      8      Any
        //  338    345    3      8      Ljava/util/NoSuchElementException;
        //  339    345    338    339    Ljava/lang/IllegalArgumentException;
        //  349    356    356    357    Any
        //  349    356    356    357    Any
        //  350    356    3      8      Ljava/lang/NullPointerException;
        //  349    356    349    350    Any
        //  349    356    3      8      Any
        //  411    418    418    419    Any
        //  411    418    3      8      Any
        //  411    418    3      8      Any
        //  412    418    3      8      Any
        //  411    418    411    412    Any
        //  433    441    441    442    Any
        //  433    441    441    442    Ljava/lang/NumberFormatException;
        //  433    441    3      8      Any
        //  433    441    441    442    Any
        //  433    441    441    442    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  496    504    504    505    Any
        //  496    504    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  496    504    504    505    Any
        //  496    504    3      8      Ljava/lang/IllegalStateException;
        //  496    504    504    505    Ljava/lang/RuntimeException;
        //  559    568    568    569    Any
        //  559    568    568    569    Ljava/lang/IllegalArgumentException;
        //  560    568    559    560    Any
        //  560    568    3      8      Ljava/lang/UnsupportedOperationException;
        //  560    568    3      8      Ljava/lang/ClassCastException;
        //  680    687    687    688    Any
        //  680    687    680    681    Any
        //  681    687    687    688    Ljava/lang/NullPointerException;
        //  680    687    680    681    Any
        //  680    687    680    681    Any
        //  696    703    703    704    Any
        //  697    703    703    704    Ljava/lang/UnsupportedOperationException;
        //  696    703    696    697    Ljava/lang/AssertionError;
        //  697    703    703    704    Ljava/lang/RuntimeException;
        //  697    703    3      8      Any
        //  709    716    716    717    Any
        //  710    716    709    710    Ljava/lang/ClassCastException;
        //  709    716    709    710    Any
        //  709    716    3      8      Any
        //  709    716    716    717    Ljava/lang/IndexOutOfBoundsException;
        //  724    731    731    732    Any
        //  724    731    724    725    Any
        //  724    731    724    725    Any
        //  725    731    724    725    Ljava/lang/IllegalArgumentException;
        //  724    731    724    725    Any
        //  746    753    753    754    Any
        //  747    753    746    747    Any
        //  747    753    753    754    Ljava/lang/ClassCastException;
        //  747    753    746    747    Any
        //  747    753    753    754    Ljava/lang/ClassCastException;
        //  795    802    802    803    Any
        //  796    802    802    803    Ljava/lang/UnsupportedOperationException;
        //  795    802    795    796    Ljava/lang/ClassCastException;
        //  796    802    795    796    Any
        //  795    802    795    796    Ljava/lang/ClassCastException;
        //  808    815    815    816    Any
        //  808    815    808    809    Ljava/lang/EnumConstantNotPresentException;
        //  809    815    3      8      Any
        //  809    815    815    816    Any
        //  808    815    808    809    Ljava/lang/ArithmeticException;
        //  819    828    828    829    Any
        //  820    828    3      8      Any
        //  820    828    3      8      Any
        //  819    828    3      8      Ljava/lang/RuntimeException;
        //  820    828    819    820    Ljava/lang/ClassCastException;
        //  836    845    845    846    Any
        //  837    845    3      8      Ljava/lang/RuntimeException;
        //  837    845    845    846    Any
        //  837    845    836    837    Ljava/lang/NullPointerException;
        //  836    845    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  854    863    863    864    Any
        //  855    863    863    864    Any
        //  854    863    863    864    Any
        //  854    863    854    855    Any
        //  854    863    3      8      Any
        //  924    930    930    931    Any
        //  924    930    930    931    Ljava/lang/StringIndexOutOfBoundsException;
        //  924    930    930    931    Any
        //  924    930    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  924    930    930    931    Any
        //  936    943    943    944    Any
        //  936    943    943    944    Ljava/lang/AssertionError;
        //  936    943    936    937    Ljava/util/NoSuchElementException;
        //  936    943    3      8      Any
        //  936    943    3      8      Any
        //  949    956    956    957    Any
        //  950    956    949    950    Any
        //  949    956    3      8      Any
        //  949    956    949    950    Ljava/lang/UnsupportedOperationException;
        //  950    956    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  962    969    969    970    Any
        //  963    969    969    970    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  962    969    969    970    Ljava/lang/StringIndexOutOfBoundsException;
        //  962    969    962    963    Any
        //  962    969    969    970    Any
        //  973    980    980    981    Any
        //  974    980    973    974    Ljava/lang/UnsupportedOperationException;
        //  974    980    3      8      Any
        //  974    980    980    981    Ljava/lang/RuntimeException;
        //  974    980    973    974    Any
        //  987    994    994    995    Any
        //  988    994    3      8      Any
        //  988    994    3      8      Ljava/lang/NumberFormatException;
        //  987    994    987    988    Ljava/lang/UnsupportedOperationException;
        //  987    994    987    988    Any
        //  1050   1056   1056   1057   Any
        //  1050   1056   3      8      Ljava/lang/UnsupportedOperationException;
        //  1050   1056   1056   1057   Ljava/lang/ArithmeticException;
        //  1050   1056   1056   1057   Any
        //  1050   1056   1056   1057   Ljava/lang/NegativeArraySizeException;
        //  1108   1114   1114   1115   Any
        //  1108   1114   1114   1115   Ljava/lang/IndexOutOfBoundsException;
        //  1108   1114   3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  1108   1114   3      8      Any
        //  1108   1114   3      8      Ljava/lang/RuntimeException;
        //  1120   1127   1127   1128   Any
        //  1120   1127   1127   1128   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1121   1127   1120   1121   Ljava/lang/StringIndexOutOfBoundsException;
        //  1121   1127   1127   1128   Ljava/lang/AssertionError;
        //  1121   1127   3      8      Ljava/lang/RuntimeException;
        //  1175   1184   1184   1185   Any
        //  1175   1184   3      8      Any
        //  1176   1184   1184   1185   Any
        //  1175   1184   1175   1176   Ljava/lang/NullPointerException;
        //  1175   1184   3      8      Ljava/util/NoSuchElementException;
        //  1195   1202   1202   1203   Any
        //  1195   1202   1202   1203   Any
        //  1196   1202   1195   1196   Ljava/lang/IllegalArgumentException;
        //  1196   1202   1202   1203   Any
        //  1195   1202   1195   1196   Any
        //  1259   1266   1266   1267   Any
        //  1259   1266   3      8      Any
        //  1259   1266   1266   1267   Any
        //  1260   1266   1259   1260   Any
        //  1260   1266   1266   1267   Ljava/lang/IndexOutOfBoundsException;
        //  1321   1328   1328   1329   Any
        //  1321   1328   1321   1322   Any
        //  1321   1328   3      8      Ljava/lang/IndexOutOfBoundsException;
        //  1322   1328   3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  1321   1328   3      8      Any
        //  1335   1341   1341   1342   Any
        //  1335   1341   1341   1342   Ljava/lang/StringIndexOutOfBoundsException;
        //  1335   1341   1341   1342   Any
        //  1335   1341   3      8      Ljava/lang/ArithmeticException;
        //  1335   1341   1341   1342   Any
        //  1347   1354   1354   1355   Any
        //  1347   1354   1354   1355   Ljava/lang/AssertionError;
        //  1348   1354   1354   1355   Ljava/lang/RuntimeException;
        //  1348   1354   1354   1355   Any
        //  1347   1354   1347   1348   Ljava/lang/UnsupportedOperationException;
        //  1358   1367   1367   1368   Any
        //  1358   1367   1367   1368   Ljava/lang/IllegalArgumentException;
        //  1358   1367   3      8      Ljava/lang/UnsupportedOperationException;
        //  1358   1367   1367   1368   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1359   1367   1358   1359   Ljava/lang/IllegalArgumentException;
        //  1380   1387   1387   1388   Any
        //  1381   1387   1380   1381   Any
        //  1381   1387   3      8      Any
        //  1381   1387   1387   1388   Any
        //  1380   1387   3      8      Any
        //  1543   1550   1550   1551   Any
        //  1544   1550   3      8      Any
        //  1543   1550   1550   1551   Ljava/lang/NullPointerException;
        //  1543   1550   1550   1551   Any
        //  1544   1550   1543   1544   Ljava/lang/AssertionError;
        //  1561   1568   1568   1569   Any
        //  1562   1568   1568   1569   Any
        //  1561   1568   3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  1561   1568   1561   1562   Any
        //  1562   1568   1561   1562   Any
        //  1572   1579   1579   1580   Any
        //  1572   1579   1579   1580   Any
        //  1573   1579   3      8      Any
        //  1572   1579   1579   1580   Any
        //  1573   1579   1572   1573   Any
        //  1636   1642   1642   1643   Any
        //  1636   1642   3      8      Ljava/util/ConcurrentModificationException;
        //  1636   1642   1642   1643   Any
        //  1636   1642   3      8      Any
        //  1636   1642   1642   1643   Ljava/util/ConcurrentModificationException;
        //  1647   1653   1653   1654   Any
        //  1647   1653   1653   1654   Any
        //  1647   1653   1653   1654   Any
        //  1647   1653   1653   1654   Any
        //  1647   1653   1653   1654   Ljava/lang/NegativeArraySizeException;
        //  1707   1714   1714   1715   Any
        //  1707   1714   1714   1715   Any
        //  1708   1714   3      8      Ljava/lang/NullPointerException;
        //  1707   1714   1707   1708   Any
        //  1707   1714   1714   1715   Any
        //  1766   1773   1773   1774   Any
        //  1766   1773   1773   1774   Any
        //  1767   1773   1766   1767   Any
        //  1767   1773   1773   1774   Ljava/lang/ArithmeticException;
        //  1766   1773   1766   1767   Ljava/util/ConcurrentModificationException;
        //  1828   1835   1835   1836   Any
        //  1829   1835   3      8      Any
        //  1829   1835   1828   1829   Ljava/lang/StringIndexOutOfBoundsException;
        //  1828   1835   1835   1836   Ljava/lang/StringIndexOutOfBoundsException;
        //  1829   1835   1828   1829   Any
        //  1847   1853   1853   1854   Any
        //  1847   1853   3      8      Any
        //  1847   1853   3      8      Any
        //  1847   1853   3      8      Any
        //  1847   1853   1853   1854   Any
        //  1861   1867   1867   1868   Any
        //  1861   1867   1867   1868   Ljava/lang/EnumConstantNotPresentException;
        //  1861   1867   3      8      Ljava/lang/EnumConstantNotPresentException;
        //  1861   1867   3      8      Any
        //  1861   1867   3      8      Any
        //  1871   1878   1878   1879   Any
        //  1871   1878   3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  1871   1878   1871   1872   Any
        //  1872   1878   1878   1879   Any
        //  1872   1878   1878   1879   Ljava/lang/UnsupportedOperationException;
        //  1882   1889   1889   1890   Any
        //  1882   1889   1889   1890   Ljava/lang/ClassCastException;
        //  1883   1889   3      8      Any
        //  1883   1889   1882   1883   Any
        //  1883   1889   1889   1890   Ljava/lang/IllegalStateException;
        //  1939   1946   1946   1947   Any
        //  1939   1946   3      8      Any
        //  1940   1946   1946   1947   Any
        //  1940   1946   3      8      Any
        //  1940   1946   1939   1940   Ljava/lang/ArithmeticException;
        //  1991   1998   1998   1999   Any
        //  1992   1998   1991   1992   Any
        //  1992   1998   3      8      Ljava/lang/IllegalArgumentException;
        //  1992   1998   3      8      Ljava/lang/EnumConstantNotPresentException;
        //  1991   1998   1998   1999   Ljava/lang/StringIndexOutOfBoundsException;
        //  2058   2065   2065   2066   Any
        //  2058   2065   2065   2066   Ljava/lang/NullPointerException;
        //  2059   2065   2058   2059   Any
        //  2059   2065   2065   2066   Any
        //  2059   2065   3      8      Any
        //  2115   2122   2122   2123   Any
        //  2116   2122   3      8      Ljava/lang/ClassCastException;
        //  2115   2122   2122   2123   Any
        //  2115   2122   2115   2116   Any
        //  2115   2122   3      8      Any
        //  2127   2133   2133   2134   Any
        //  2127   2133   2133   2134   Any
        //  2127   2133   2133   2134   Ljava/lang/AssertionError;
        //  2127   2133   3      8      Ljava/lang/EnumConstantNotPresentException;
        //  2127   2133   2133   2134   Any
        //  2188   2194   2194   2195   Any
        //  2188   2194   3      8      Any
        //  2188   2194   3      8      Ljava/lang/RuntimeException;
        //  2188   2194   2194   2195   Any
        //  2188   2194   2194   2195   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  2255   2264   2264   2265   Any
        //  2256   2264   2255   2256   Ljava/util/ConcurrentModificationException;
        //  2255   2264   2255   2256   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  2255   2264   2255   2256   Any
        //  2255   2264   3      8      Ljava/lang/ClassCastException;
        //  2272   2281   2281   2282   Any
        //  2273   2281   2281   2282   Ljava/lang/NumberFormatException;
        //  2273   2281   3      8      Any
        //  2273   2281   2281   2282   Any
        //  2272   2281   2272   2273   Ljava/lang/ArithmeticException;
        //  2291   2299   2299   2300   Any
        //  2291   2299   3      8      Any
        //  2291   2299   2299   2300   Any
        //  2291   2299   3      8      Any
        //  2291   2299   2299   2300   Ljava/lang/AssertionError;
        //  2408   2414   2414   2415   Any
        //  2408   2414   2414   2415   Any
        //  2408   2414   2414   2415   Ljava/lang/RuntimeException;
        //  2408   2414   3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  2408   2414   3      8      Any
        //  2419   2426   2426   2427   Any
        //  2419   2426   2426   2427   Any
        //  2420   2426   2426   2427   Any
        //  2419   2426   2419   2420   Ljava/lang/AssertionError;
        //  2420   2426   3      8      Ljava/lang/UnsupportedOperationException;
        //  2532   2538   2538   2539   Any
        //  2532   2538   3      8      Any
        //  2532   2538   3      8      Ljava/lang/RuntimeException;
        //  2532   2538   3      8      Any
        //  2532   2538   3      8      Ljava/lang/EnumConstantNotPresentException;
        //  2591   2598   2598   2599   Any
        //  2592   2598   2591   2592   Any
        //  2592   2598   2591   2592   Any
        //  2592   2598   2598   2599   Ljava/lang/NumberFormatException;
        //  2592   2598   3      8      Ljava/lang/EnumConstantNotPresentException;
        //  2656   2663   2663   2664   Any
        //  2657   2663   3      8      Ljava/lang/IllegalStateException;
        //  2657   2663   3      8      Any
        //  2657   2663   2656   2657   Ljava/lang/EnumConstantNotPresentException;
        //  2657   2663   2656   2657   Ljava/lang/NumberFormatException;
        //  2711   2718   2718   2719   Any
        //  2712   2718   2711   2712   Ljava/lang/NullPointerException;
        //  2712   2718   3      8      Ljava/lang/AssertionError;
        //  2711   2718   2711   2712   Ljava/lang/EnumConstantNotPresentException;
        //  2711   2718   2718   2719   Any
        //  2725   2732   2732   2733   Any
        //  2726   2732   2732   2733   Any
        //  2726   2732   2725   2726   Ljava/lang/ClassCastException;
        //  2725   2732   2732   2733   Any
        //  2725   2732   2732   2733   Ljava/lang/ClassCastException;
        //  2737   2743   2743   2744   Any
        //  2737   2743   3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  2737   2743   2743   2744   Ljava/lang/RuntimeException;
        //  2737   2743   3      8      Any
        //  2737   2743   2743   2744   Any
        //  2791   2798   2798   2799   Any
        //  2792   2798   2798   2799   Any
        //  2792   2798   2791   2792   Any
        //  2791   2798   2791   2792   Any
        //  2792   2798   2798   2799   Ljava/lang/EnumConstantNotPresentException;
        //  2805   2811   2811   2812   Any
        //  2805   2811   2811   2812   Any
        //  2805   2811   2811   2812   Any
        //  2805   2811   3      8      Any
        //  2805   2811   3      8      Any
        //  2819   2826   2826   2827   Any
        //  2819   2826   2826   2827   Any
        //  2819   2826   2826   2827   Ljava/lang/ArithmeticException;
        //  2820   2826   2826   2827   Any
        //  2819   2826   2819   2820   Ljava/lang/ClassCastException;
        //  2832   2839   2839   2840   Any
        //  2833   2839   3      8      Ljava/lang/IllegalArgumentException;
        //  2833   2839   2832   2833   Any
        //  2833   2839   2832   2833   Ljava/lang/IllegalArgumentException;
        //  2832   2839   2832   2833   Ljava/lang/RuntimeException;
        //  2887   2894   2894   2895   Any
        //  2888   2894   3      8      Ljava/lang/EnumConstantNotPresentException;
        //  2888   2894   2887   2888   Ljava/lang/RuntimeException;
        //  2888   2894   2894   2895   Ljava/lang/UnsupportedOperationException;
        //  2887   2894   3      8      Any
        //  2944   2950   2950   2951   Any
        //  2944   2950   2950   2951   Ljava/lang/NumberFormatException;
        //  2944   2950   2950   2951   Ljava/lang/NegativeArraySizeException;
        //  2944   2950   3      8      Any
        //  2944   2950   2950   2951   Any
        //  2958   2964   2964   2965   Any
        //  2958   2964   3      8      Any
        //  2958   2964   3      8      Ljava/lang/NullPointerException;
        //  2958   2964   2964   2965   Any
        //  2958   2964   2964   2965   Any
        //  2971   2977   2977   2978   Any
        //  2971   2977   3      8      Any
        //  2971   2977   2977   2978   Ljava/lang/UnsupportedOperationException;
        //  2971   2977   3      8      Ljava/lang/NumberFormatException;
        //  2971   2977   2977   2978   Ljava/util/ConcurrentModificationException;
        //  3019   3026   3026   3027   Any
        //  3019   3026   3026   3027   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  3019   3026   3019   3020   Ljava/lang/UnsupportedOperationException;
        //  3020   3026   3026   3027   Any
        //  3020   3026   3026   3027   Ljava/lang/IllegalStateException;
        //  3044   3051   3051   3052   Any
        //  3045   3051   3044   3045   Any
        //  3044   3051   3044   3045   Any
        //  3044   3051   3      8      Any
        //  3045   3051   3051   3052   Ljava/lang/EnumConstantNotPresentException;
        //  3056   3062   3062   3063   Any
        //  3056   3062   3      8      Any
        //  3056   3062   3062   3063   Any
        //  3056   3062   3      8      Ljava/lang/NullPointerException;
        //  3056   3062   3062   3063   Ljava/lang/NumberFormatException;
        //  3119   3126   3126   3127   Any
        //  3119   3126   3126   3127   Any
        //  3120   3126   3126   3127   Any
        //  3119   3126   3119   3120   Ljava/util/ConcurrentModificationException;
        //  3120   3126   3      8      Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visitVariable(StackMappingVisitor.java:470)
        //     at com.strobel.assembler.ir.Instruction.accept(Instruction.java:556)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:403)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void c(@Nullable final f4O c) {
        Object o = null;
        Block_0: {
            break Block_0;
        Label_0087:
            while (true) {
                do {
                    Label_0074: {
                        break Label_0074;
                        try {
                            o = null;
                            if (fc.0 != 0) {
                                null;
                                goto Label_0079;
                            }
                            continue Label_0087;
                            Label_0064: {
                                this.c = c;
                            }
                            return;
                            // iftrue(Label_0030:, fc.1 != 0)
                        Label_0033:
                            while (true) {
                                int n = 1134570589;
                                break Label_0033;
                                Label_0030:
                                n = 1159556202;
                                break Label_0033;
                                Label_0068:
                                throw null;
                                continue;
                            }
                        }
                        // switch([Lcom.strobel.decompiler.ast.Label;@5456a619, n ^ 0xD4AD1A6)
                        catch (RuntimeException ex) {}
                    }
                    continue Label_0087;
                } while (o == null);
                break;
            }
        }
        throw (Throwable)o;
    }
    
    static {
        f6.c = new f5(null);
        while (true) {
            int n = 0;
            Label_0030: {
                if (fc.0 <= 0) {
                    n = 1436982520;
                    break Label_0030;
                }
                n = -209183322;
            }
            switch (n ^ 0x9B61408F) {
                case -208191020: {
                    continue;
                }
                default: {
                    f6.c = new f6();
                }
                case -825762697: {
                    throw null;
                }
            }
            break;
        }
    }
    
    @f0g
    @LauncherEventHide
    public void c(@NotNull final f43 p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          282
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            274
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            266
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: getstatic       dev/nuker/pyro/fc.0:I
        //    27: ifgt            36
        //    30: ldc_w           1406828529
        //    33: goto            39
        //    36: ldc_w           351983608
        //    39: ldc_w           492440301
        //    42: ixor           
        //    43: lookupswitch {
        //          161537301: 68
        //          1317041436: 36
        //          default: 255
        //        }
        //    68: aload_1        
        //    69: pop            
        //    70: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //    73: dup            
        //    74: pop            
        //    75: goto            79
        //    78: athrow         
        //    79: invokevirtual   net/minecraft/client/Minecraft.func_147104_D:()Lnet/minecraft/client/multiplayer/ServerData;
        //    82: goto            86
        //    85: athrow         
        //    86: ifnonnull       159
        //    89: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //    92: dup            
        //    93: pop            
        //    94: goto            98
        //    97: athrow         
        //    98: invokevirtual   net/minecraft/client/Minecraft.func_71401_C:()Lnet/minecraft/server/integrated/IntegratedServer;
        //   101: goto            105
        //   104: athrow         
        //   105: ifnonnull       159
        //   108: aload_0        
        //   109: iconst_1       
        //   110: getstatic       dev/nuker/pyro/fc.0:I
        //   113: ifgt            122
        //   116: ldc_w           -188875693
        //   119: goto            125
        //   122: ldc_w           -1636718319
        //   125: ldc_w           -647086710
        //   128: ixor           
        //   129: lookupswitch {
        //          768852441: 122
        //          1193251995: 156
        //          default: 251
        //        }
        //   156: putfield        dev/nuker/pyro/f6.c:Z
        //   159: getstatic       dev/nuker/pyro/fc.0:I
        //   162: ifgt            171
        //   165: ldc_w           -1820421564
        //   168: goto            174
        //   171: ldc_w           659935450
        //   174: ldc_w           1316554759
        //   177: ixor           
        //   178: lookupswitch {
        //          -586704317: 171
        //          1764546781: 204
        //          default: 253
        //        }
        //   204: getstatic       dev/nuker/pyro/f0b.c:Ldev/nuker/pyro/f0b;
        //   207: goto            211
        //   210: athrow         
        //   211: invokevirtual   dev/nuker/pyro/f0b.0:()V
        //   214: goto            218
        //   217: athrow         
        //   218: aload_1        
        //   219: goto            223
        //   222: athrow         
        //   223: invokevirtual   dev/nuker/pyro/f43.c:()Ldev/nuker/pyro/f41;
        //   226: goto            230
        //   229: athrow         
        //   230: getstatic       dev/nuker/pyro/f41.c:Ldev/nuker/pyro/f41;
        //   233: if_acmpne       250
        //   236: getstatic       dev/nuker/pyro/f03.c:Ldev/nuker/pyro/f03;
        //   239: goto            243
        //   242: athrow         
        //   243: invokevirtual   dev/nuker/pyro/f03.c:()V
        //   246: goto            250
        //   249: athrow         
        //   250: return         
        //   251: aconst_null    
        //   252: athrow         
        //   253: aconst_null    
        //   254: athrow         
        //   255: aconst_null    
        //   256: athrow         
        //   257: pop            
        //   258: goto            24
        //   261: pop            
        //   262: aconst_null    
        //   263: goto            257
        //   266: dup            
        //   267: ifnull          257
        //   270: checkcast       Ljava/lang/Throwable;
        //   273: athrow         
        //   274: dup            
        //   275: ifnull          261
        //   278: checkcast       Ljava/lang/Throwable;
        //   281: athrow         
        //   282: aconst_null    
        //   283: athrow         
        //    StackMapTable: 00 2A 43 07 00 24 04 FF 00 0B 00 00 00 01 07 00 24 FD 00 03 07 00 03 07 02 A6 0B 42 01 1C 49 07 00 51 40 07 00 69 45 07 00 24 40 07 02 0C 4A 07 00 24 40 07 00 69 45 07 00 24 40 07 02 5A FF 00 10 00 02 07 00 03 07 02 A6 00 02 07 00 03 01 FF 00 02 00 02 07 00 03 07 02 A6 00 03 07 00 03 01 01 FF 00 1E 00 02 07 00 03 07 02 A6 00 02 07 00 03 01 02 0B 42 01 1D 45 07 00 39 40 07 02 A0 45 07 00 24 00 FF 00 03 00 00 00 01 07 00 24 FF 00 00 00 02 07 00 03 07 02 A6 00 01 07 02 A6 45 07 00 24 40 07 01 1A 4B 07 00 24 40 07 02 A9 45 07 00 24 00 FF 00 00 00 02 07 00 03 07 02 A6 00 02 07 00 03 01 01 01 41 07 00 24 43 05 44 07 00 24 47 05 47 07 00 24
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     266    274    Ljava/lang/IllegalArgumentException;
        //  266    274    266    274    Any
        //  282    284    3      8      Any
        //  78     85     85     86     Any
        //  78     85     85     86     Ljava/lang/StringIndexOutOfBoundsException;
        //  78     85     78     79     Ljava/lang/ArithmeticException;
        //  78     85     3      8      Ljava/lang/NumberFormatException;
        //  79     85     3      8      Any
        //  97     104    104    105    Any
        //  98     104    104    105    Ljava/lang/NegativeArraySizeException;
        //  98     104    3      8      Any
        //  98     104    97     98     Any
        //  97     104    104    105    Ljava/lang/NullPointerException;
        //  210    217    217    218    Any
        //  211    217    210    211    Ljava/lang/RuntimeException;
        //  210    217    210    211    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  211    217    3      8      Ljava/util/ConcurrentModificationException;
        //  211    217    217    218    Ljava/lang/ArithmeticException;
        //  223    229    229    230    Any
        //  223    229    3      8      Any
        //  223    229    229    230    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  223    229    3      8      Ljava/util/ConcurrentModificationException;
        //  223    229    229    230    Ljava/lang/RuntimeException;
        //  242    249    249    250    Any
        //  242    249    3      8      Any
        //  242    249    242    243    Any
        //  242    249    3      8      Any
        //  242    249    249    250    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:595)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
