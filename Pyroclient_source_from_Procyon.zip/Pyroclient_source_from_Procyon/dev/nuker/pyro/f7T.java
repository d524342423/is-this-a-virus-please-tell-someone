// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import org.jetbrains.annotations.NotNull;
import kotlin.jvm.JvmField;

public class f7T extends fQ
{
    @JvmField
    @NotNull
    public f0k c;
    @JvmField
    @NotNull
    public f0k 0;
    
    public f7T() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: ldc             "\u3ca5\ub24b\u8ffa\uadad\u67ac\u5845\u7e49\u68ea\uc2c0\ua37a\u9a13\u130a\uc09d\u710d\u9056"
        //     3: invokestatic    invokestatic   !!! ERROR
        //     6: ldc             "\u3c85\ub24b\u8ffa\uadad\u67b7\u5848\u7e53\u68fa\uc2cc\ua37b\u9a13\u1301\uc09b\u711a"
        //     8: invokestatic    invokestatic   !!! ERROR
        //    11: ldc             "\u3c83\ub24c\u8ff8\uada1\u6780\u5801\u7e41\u68b9\uc2c0\ua37a\u9a13\u1302\uc091\u711c\u904f\u4c48\ub205\u4d7b\u014d\u07ae\u1311\ufed7\u6b2d\u8846\u36b5\u3ccb\u7ff5\ua8c6\ud1e2\u72aa\u458c\u6ba1\u75fa\u977d\uc708\u42df\ufde3\u117d\u1806\u4a25\u67ea\uac11\u8cdb\uf929\ubc76\ua5d5\u4c27\u3eeb\u4a36"
        //    13: invokestatic    invokestatic   !!! ERROR
        //    16: iconst_1       
        //    17: invokespecial   dev/nuker/pyro/fQ.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //    20: aload_0        
        //    21: getstatic       dev/nuker/pyro/fc.1:I
        //    24: ifne            32
        //    27: ldc             -2091679329
        //    29: goto            34
        //    32: ldc             1609175977
        //    34: ldc             -1497673634
        //    36: ixor           
        //    37: lookupswitch {
        //          -491294518: 32
        //          636015041: 226
        //          default: 64
        //        }
        //    64: aload_0        
        //    65: new             Ldev/nuker/pyro/f0k;
        //    68: dup            
        //    69: ldc             "\u3ca0\ub24c\u8ffd\uada7\u679c\u584f\u7e4e\u68fc\uc2c0\ua361"
        //    71: invokestatic    invokestatic   !!! ERROR
        //    74: ldc             "\u3c86\ub249\u8fe1\uada7\u6798\u5801\u7e64\u68f0\uc2d0\ua376\u9a12\u130a\uc096\u710b\u9041\u4c5d"
        //    76: invokestatic    invokestatic   !!! ERROR
        //    79: ldc             "\u3c85\ub241\u8fea\uade4\u6792\u5801\u7e43\u68f6\uc2cd\ua373\u9a14\u1316\uc095\u710f\u9056\u4c40\ub21e\u4d7c\u0102\u07b0\u135e\ufed4\u6b3b\u8844\u36f0\u3cc8\u7ff4\ua894\ud1a0\u72bb\u4582\u6bab\u75a8\u977c\uc741\u42d5\ufdef\u1167\u1848\u4a2f\u67e6\uac01\u8ccc\uf966\ubc7a\ua5ce\u4c36\u3efc\u4a2d\ua2f4"
        //    81: invokestatic    invokestatic   !!! ERROR
        //    84: iconst_1       
        //    85: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //    88: checkcast       Ldev/nuker/pyro/f0w;
        //    91: invokevirtual   dev/nuker/pyro/f7T.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //    94: checkcast       Ldev/nuker/pyro/f0k;
        //    97: putfield        dev/nuker/pyro/f7T.c:Ldev/nuker/pyro/f0k;
        //   100: aload_0        
        //   101: aload_0        
        //   102: new             Ldev/nuker/pyro/f0k;
        //   105: dup            
        //   106: ldc             "\u3ca7\ub249\u8fe1\uadb7\u6796\u587e\u7e57\u68f0\uc2cd\ua371\u9a12\u1313"
        //   108: getstatic       dev/nuker/pyro/fc.0:I
        //   111: ifgt            119
        //   114: ldc             847081707
        //   116: goto            121
        //   119: ldc             651732392
        //   121: ldc             694467988
        //   123: ixor           
        //   124: lookupswitch {
        //          -1473789117: 119
        //          454675839: 224
        //          default: 152
        //        }
        //   152: invokestatic    invokestatic   !!! ERROR
        //   155: ldc             "\u3c86\ub249\u8fe1\uada7\u6798\u5801\u7e77\u68f0\uc2cd\ua371\u9a12\u1313\uc0d8\u712d\u904e\u4c46\ub202\u4d77"
        //   157: invokestatic    invokestatic   !!! ERROR
        //   160: ldc             "\u3c85\ub241\u8fea\uade4\u6792\u5801\u7e43\u68f6\uc2cd\ua373\u9a14\u1316\uc095\u710f\u9056\u4c40\ub21e\u4d7c\u0102\u07b0\u135e\ufed4\u6b3b\u8844\u36f0\u3cc8\u7ff4\ua894\ud1a0\u72bb\u4582\u6bab\u75a8\u973f\uc770\u4281\ufdac\u116a\u1853\u4a35\u67f7\uac0d\u8cd6"
        //   162: invokestatic    invokestatic   !!! ERROR
        //   165: iconst_1       
        //   166: getstatic       dev/nuker/pyro/fc.1:I
        //   169: ifne            177
        //   172: ldc             -171985392
        //   174: goto            179
        //   177: ldc             -1913101586
        //   179: ldc             -1313864709
        //   181: ixor           
        //   182: lookupswitch {
        //          1011376405: 208
        //          1141880299: 177
        //          default: 228
        //        }
        //   208: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   211: checkcast       Ldev/nuker/pyro/f0w;
        //   214: invokevirtual   dev/nuker/pyro/f7T.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   217: checkcast       Ldev/nuker/pyro/f0k;
        //   220: putfield        dev/nuker/pyro/f7T.0:Ldev/nuker/pyro/f0k;
        //   223: return         
        //   224: aconst_null    
        //   225: athrow         
        //   226: aconst_null    
        //   227: athrow         
        //   228: aconst_null    
        //   229: athrow         
        //    StackMapTable: 00 0C FF 00 20 00 01 07 00 03 00 01 07 00 03 FF 00 01 00 01 07 00 03 00 02 07 00 03 01 5D 07 00 03 FF 00 36 00 01 07 00 03 00 05 07 00 03 07 00 03 08 00 66 08 00 66 07 00 45 FF 00 01 00 01 07 00 03 00 06 07 00 03 07 00 03 08 00 66 08 00 66 07 00 45 01 FF 00 1E 00 01 07 00 03 00 05 07 00 03 07 00 03 08 00 66 08 00 66 07 00 45 FF 00 18 00 01 07 00 03 00 08 07 00 03 07 00 03 08 00 66 08 00 66 07 00 45 07 00 45 07 00 45 01 FF 00 01 00 01 07 00 03 00 09 07 00 03 07 00 03 08 00 66 08 00 66 07 00 45 07 00 45 07 00 45 01 01 FF 00 1C 00 01 07 00 03 00 08 07 00 03 07 00 03 08 00 66 08 00 66 07 00 45 07 00 45 07 00 45 01 FF 00 0F 00 01 07 00 03 00 05 07 00 03 07 00 03 08 00 66 08 00 66 07 00 45 41 07 00 03 FF 00 01 00 01 07 00 03 00 08 07 00 03 07 00 03 08 00 66 08 00 66 07 00 45 07 00 45 07 00 45 01
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2695)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        throw t;
    }
}
