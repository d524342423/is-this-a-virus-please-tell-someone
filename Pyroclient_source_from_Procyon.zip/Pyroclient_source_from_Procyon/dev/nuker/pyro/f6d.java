// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

public enum f6d
{
    public static f6d c;
    public static f6d 0;
    public static f6d 1;
    public static f6d[] c;
    
    static {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ldc             "\u3c99\ub24a\u8ff3\ua17a"
        //     6: invokestatic    invokestatic   !!! ERROR
        //     9: iconst_0       
        //    10: invokespecial   dev/nuker/pyro/f6d.<init>:(Ljava/lang/String;I)V
        //    13: getstatic       dev/nuker/pyro/fc.0:I
        //    16: ifgt            24
        //    19: ldc             793475318
        //    21: goto            26
        //    24: ldc             2143412340
        //    26: ldc             -1856604619
        //    28: ixor           
        //    29: lookupswitch {
        //          -1678176523: 24
        //          -1105391933: 336
        //          default: 56
        //        }
        //    56: putstatic       dev/nuker/pyro/f6d.c:Ldev/nuker/pyro/f6d;
        //    59: new             Ldev/nuker/pyro/f6d;
        //    62: dup            
        //    63: ldc             "\u3c98\ub24b\u8ff1\ua166\u5388\u5845\u7e4f\u68f8\uce1c"
        //    65: getstatic       dev/nuker/pyro/fc.c:I
        //    68: ifne            76
        //    71: ldc             1762135984
        //    73: goto            78
        //    76: ldc             -1114944682
        //    78: ldc             352029751
        //    80: ixor           
        //    81: lookupswitch {
        //          -1452226719: 108
        //          2113110919: 76
        //          default: 328
        //        }
        //   108: invokestatic    invokestatic   !!! ERROR
        //   111: iconst_1       
        //   112: getstatic       dev/nuker/pyro/fc.1:I
        //   115: ifne            123
        //   118: ldc             1391915102
        //   120: goto            125
        //   123: ldc             -1876960984
        //   125: ldc             462509392
        //   127: ixor           
        //   128: lookupswitch {
        //          -1203514712: 123
        //          1231529230: 334
        //          default: 156
        //        }
        //   156: invokespecial   dev/nuker/pyro/f6d.<init>:(Ljava/lang/String;I)V
        //   159: getstatic       dev/nuker/pyro/fc.1:I
        //   162: ifne            170
        //   165: ldc             1833246924
        //   167: goto            172
        //   170: ldc             1910862497
        //   172: ldc             -77262249
        //   174: ixor           
        //   175: lookupswitch {
        //          -1776274789: 332
        //          -727236533: 170
        //          default: 200
        //        }
        //   200: putstatic       dev/nuker/pyro/f6d.0:Ldev/nuker/pyro/f6d;
        //   203: new             Ldev/nuker/pyro/f6d;
        //   206: dup            
        //   207: ldc             "\u3c95\ub240\u8fee\ua16b\u5388\u5845\u7e4f\u68f8\uce1c"
        //   209: invokestatic    invokestatic   !!! ERROR
        //   212: iconst_2       
        //   213: invokespecial   dev/nuker/pyro/f6d.<init>:(Ljava/lang/String;I)V
        //   216: putstatic       dev/nuker/pyro/f6d.1:Ldev/nuker/pyro/f6d;
        //   219: iconst_3       
        //   220: anewarray       Ldev/nuker/pyro/f6d;
        //   223: dup            
        //   224: iconst_0       
        //   225: getstatic       dev/nuker/pyro/f6d.c:Ldev/nuker/pyro/f6d;
        //   228: aastore        
        //   229: dup            
        //   230: iconst_1       
        //   231: getstatic       dev/nuker/pyro/fc.1:I
        //   234: ifne            242
        //   237: ldc             1479335107
        //   239: goto            244
        //   242: ldc             2068773239
        //   244: ldc             -737269305
        //   246: ixor           
        //   247: lookupswitch {
        //          -1943866108: 338
        //          1774727176: 242
        //          default: 272
        //        }
        //   272: getstatic       dev/nuker/pyro/f6d.0:Ldev/nuker/pyro/f6d;
        //   275: aastore        
        //   276: dup            
        //   277: iconst_2       
        //   278: getstatic       dev/nuker/pyro/f6d.1:Ldev/nuker/pyro/f6d;
        //   281: aastore        
        //   282: getstatic       dev/nuker/pyro/fc.1:I
        //   285: ifne            293
        //   288: ldc             -759985860
        //   290: goto            295
        //   293: ldc             -1619235125
        //   295: ldc             -873664013
        //   297: ixor           
        //   298: lookupswitch {
        //          425687247: 293
        //          1418764088: 324
        //          default: 330
        //        }
        //   324: putstatic       dev/nuker/pyro/f6d.c:[Ldev/nuker/pyro/f6d;
        //   327: return         
        //   328: aconst_null    
        //   329: athrow         
        //   330: aconst_null    
        //   331: athrow         
        //   332: aconst_null    
        //   333: athrow         
        //   334: aconst_null    
        //   335: athrow         
        //   336: aconst_null    
        //   337: athrow         
        //   338: aconst_null    
        //   339: athrow         
        //    StackMapTable: 00 18 58 07 00 03 FF 00 01 00 00 00 02 07 00 03 01 5D 07 00 03 FF 00 13 00 00 00 03 08 00 3B 08 00 3B 07 00 40 FF 00 01 00 00 00 04 08 00 3B 08 00 3B 07 00 40 01 FF 00 1D 00 00 00 03 08 00 3B 08 00 3B 07 00 40 FF 00 0E 00 00 00 04 08 00 3B 08 00 3B 07 00 40 01 FF 00 01 00 00 00 05 08 00 3B 08 00 3B 07 00 40 01 01 FF 00 1E 00 00 00 04 08 00 3B 08 00 3B 07 00 40 01 4D 07 00 03 FF 00 01 00 00 00 02 07 00 03 01 5B 07 00 03 FF 00 29 00 00 00 03 07 00 41 07 00 41 01 FF 00 01 00 00 00 04 07 00 41 07 00 41 01 01 FF 00 1B 00 00 00 03 07 00 41 07 00 41 01 54 07 00 41 FF 00 01 00 00 00 02 07 00 41 01 5C 07 00 41 FF 00 03 00 00 00 03 08 00 3B 08 00 3B 07 00 40 41 07 00 41 41 07 00 03 FF 00 01 00 00 00 04 08 00 3B 08 00 3B 07 00 40 01 41 07 00 03 FF 00 01 00 00 00 03 07 00 41 07 00 41 01
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2695)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public f6d(final String name, final int ordinal) {
        while (true) {
            Label_0014: {
                if (fc.1 == 0) {
                    n = 1349036047;
                    break Label_0014;
                }
                n = -71333361;
            }
            switch (n ^ 0x7F6E3E9D) {
                case -944805300: {
                    continue;
                }
                default: {
                    while (true) {
                        int n2 = 0;
                        Label_0058: {
                            if (fc.1 == 0) {
                                n2 = -1013332546;
                                break Label_0058;
                            }
                            n2 = -135236097;
                        }
                        switch (n2 ^ 0xB6F3A3B4) {
                            case 1969907210: {
                                continue;
                            }
                            case 1090770507: {
                                super(name, ordinal);
                                return;
                            }
                            default: {
                                throw null;
                            }
                        }
                        break;
                    }
                    break;
                }
                case 788960914: {
                    throw null;
                }
            }
            break;
        }
    }
    
    public static f6d c(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          111
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            103
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            95
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: ldc             Ldev/nuker/pyro/f6d;.class
        //    26: getstatic       dev/nuker/pyro/fc.1:I
        //    29: ifne            37
        //    32: ldc             -183728743
        //    34: goto            39
        //    37: ldc             1135165168
        //    39: ldc             1574031431
        //    41: ixor           
        //    42: lookupswitch {
        //          -1461889570: 84
        //          1394302546: 37
        //          default: 68
        //        }
        //    68: aload_0        
        //    69: goto            73
        //    72: athrow         
        //    73: invokestatic    java/lang/Enum.valueOf:(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
        //    76: goto            80
        //    79: athrow         
        //    80: checkcast       Ldev/nuker/pyro/f6d;
        //    83: areturn        
        //    84: aconst_null    
        //    85: athrow         
        //    86: pop            
        //    87: goto            24
        //    90: pop            
        //    91: aconst_null    
        //    92: goto            86
        //    95: dup            
        //    96: ifnull          86
        //    99: checkcast       Ljava/lang/Throwable;
        //   102: athrow         
        //   103: dup            
        //   104: ifnull          90
        //   107: checkcast       Ljava/lang/Throwable;
        //   110: athrow         
        //   111: aconst_null    
        //   112: athrow         
        //    StackMapTable: 00 11 43 07 00 52 04 FF 00 0B 00 00 00 01 07 00 52 FC 00 03 07 00 40 4C 07 00 6B FF 00 01 00 01 07 00 40 00 02 07 00 6B 01 5C 07 00 6B 43 07 00 52 FF 00 00 00 01 07 00 40 00 02 07 00 6B 07 00 40 45 07 00 52 40 07 00 05 43 07 00 6B 41 07 00 4E 43 05 44 07 00 4E 47 05 47 07 00 52
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     95     103    Ljava/lang/NullPointerException;
        //  95     103    95     103    Ljava/lang/ArithmeticException;
        //  111    113    3      8      Any
        //  72     79     79     80     Any
        //  72     79     79     80     Ljava/lang/ArithmeticException;
        //  72     79     72     73     Any
        //  72     79     3      8      Ljava/lang/ClassCastException;
        //  72     79     79     80     Ljava/util/ConcurrentModificationException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 44 out of bounds for length 44
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
