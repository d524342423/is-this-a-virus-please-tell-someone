// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import net.minecraft.client.Minecraft;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import net.minecraft.client.entity.EntityPlayerSP;
import dev.nuker.pyro.security.inject.LauncherEventHide;
import org.jetbrains.annotations.NotNull;

public class f9e extends fQ
{
    @NotNull
    public f0m c;
    @NotNull
    public f0m 0;
    @NotNull
    public f0m 1;
    @NotNull
    public f0k c;
    @NotNull
    public f0k 0;
    @NotNull
    public f0m 2;
    @NotNull
    public f0o<f9b> c;
    @NotNull
    public f0p c;
    @NotNull
    public f0p 0;
    public int 1;
    public boolean c;
    public int 2;
    public double c;
    public int 3;
    public long c;
    public float c;
    
    @NotNull
    public f0m 8() {
        return fez.8V(this, 859637588);
    }
    
    @f0g
    @LauncherEventHide
    public void c(@NotNull final f4e p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          4123
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            4115
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            4107
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: aload_1        
        //    27: goto            31
        //    30: athrow         
        //    31: invokevirtual   dev/nuker/pyro/f4e.c:()Ldev/nuker/pyro/f41;
        //    34: goto            38
        //    37: athrow         
        //    38: getstatic       dev/nuker/pyro/f41.c:Ldev/nuker/pyro/f41;
        //    41: if_acmpne       3989
        //    44: getstatic       dev/nuker/pyro/fc.0:I
        //    47: ifgt            55
        //    50: ldc             -899477665
        //    52: goto            57
        //    55: ldc             1536598735
        //    57: ldc             -1919147282
        //    59: ixor           
        //    60: lookupswitch {
        //          -1971652259: 55
        //          1207905713: 4040
        //          default: 88
        //        }
        //    88: aload_1        
        //    89: getstatic       dev/nuker/pyro/fc.c:I
        //    92: ifne            100
        //    95: ldc             -921999184
        //    97: goto            102
        //   100: ldc             -699330424
        //   102: ldc             -788716685
        //   104: ixor           
        //   105: lookupswitch {
        //          -1286125775: 100
        //          435571651: 4080
        //          default: 132
        //        }
        //   132: goto            136
        //   135: athrow         
        //   136: invokevirtual   dev/nuker/pyro/f4e.c:()Z
        //   139: goto            143
        //   142: athrow         
        //   143: ifne            3989
        //   146: getstatic       dev/nuker/pyro/fc.1:I
        //   149: ifne            157
        //   152: ldc             878306270
        //   154: goto            159
        //   157: ldc             -1997928900
        //   159: ldc             -1808004853
        //   161: ixor           
        //   162: lookupswitch {
        //          -1603933483: 157
        //          483790647: 188
        //          default: 3998
        //        }
        //   188: aload_1        
        //   189: goto            193
        //   192: athrow         
        //   193: invokevirtual   dev/nuker/pyro/f4e.c:()Lnet/minecraft/network/Packet;
        //   196: goto            200
        //   199: athrow         
        //   200: instanceof      Lnet/minecraft/network/play/server/SPacketPlayerPosLook;
        //   203: ifeq            511
        //   206: aload_1        
        //   207: goto            211
        //   210: athrow         
        //   211: invokevirtual   dev/nuker/pyro/f4e.c:()Lnet/minecraft/network/Packet;
        //   214: goto            218
        //   217: athrow         
        //   218: dup            
        //   219: ifnonnull       251
        //   222: new             Lkotlin/TypeCastException;
        //   225: dup            
        //   226: ldc             "\u3cdb\ub250\u8f93\uafb9\u6193\u5833\u7e41\u6886\uc0dc\ua53a\u9a78\u1344\uc0eb\u731a\u9642\u4c3b\ub210\u4d10\u0347\u01a0\u1334\ufecb\u6b1f\u8a4b\u30ff\u3cb1\u7fb6\ua8f9\ud3e4\u74e3\u45f7\u6bee\u758d\u9570\uc118\u42b2\ufdac\u1117\u1a52\u4c75\u67dc\uac0f\u8ca0\ufb39\uba3d\ua5a9\u4c30\u3e98\u4835\ua4ae\u7983\u916c\u32c1\u6dcd\uf012\u0f61\u7a49\u0b32\u9d6f\ud546\ue619\u4c6b\u49df\u14ce\u377c\u501b\u7982\ue668\u5df1\u8d14\uea44\u1df0\uf350\ub46d\uc688\u16fd\u2aee\u67c6\u4669\u7ace\ucbaa\u173e\u2ad3\u8dda\ud6be\u39c9\u9b88\u824e\ucad2\ucb4f\uae2e"
        //   228: goto            232
        //   231: athrow         
        //   232: invokestatic    invokestatic   !!! ERROR
        //   235: goto            239
        //   238: athrow         
        //   239: goto            243
        //   242: athrow         
        //   243: invokespecial   kotlin/TypeCastException.<init>:(Ljava/lang/String;)V
        //   246: goto            250
        //   249: athrow         
        //   250: athrow         
        //   251: checkcast       Lnet/minecraft/network/play/server/SPacketPlayerPosLook;
        //   254: astore_2       
        //   255: getstatic       dev/nuker/pyro/fc.1:I
        //   258: ifne            266
        //   261: ldc             -78391734
        //   263: goto            268
        //   266: ldc             1688814090
        //   268: ldc             1728208732
        //   270: ixor           
        //   271: lookupswitch {
        //          -1672378090: 4052
        //          -232241826: 266
        //          default: 296
        //        }
        //   296: aload_0        
        //   297: getstatic       dev/nuker/pyro/fc.c:I
        //   300: ifne            308
        //   303: ldc             79689390
        //   305: goto            310
        //   308: ldc             -806432953
        //   310: ldc             -1118246976
        //   312: ixor           
        //   313: lookupswitch {
        //          -1176039058: 308
        //          1924540551: 340
        //          default: 4004
        //        }
        //   340: aload_2        
        //   341: goto            345
        //   344: athrow         
        //   345: invokevirtual   net/minecraft/network/play/server/SPacketPlayerPosLook.func_186965_f:()I
        //   348: goto            352
        //   351: athrow         
        //   352: putfield        dev/nuker/pyro/f9e.2:I
        //   355: aload_0        
        //   356: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //   359: getstatic       dev/nuker/pyro/fc.1:I
        //   362: ifne            370
        //   365: ldc             1341394516
        //   367: goto            372
        //   370: ldc             -1399981550
        //   372: ldc             -563852817
        //   374: ixor           
        //   375: lookupswitch {
        //          -1852815429: 4022
        //          458508208: 370
        //          default: 400
        //        }
        //   400: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   403: dup            
        //   404: pop            
        //   405: getstatic       dev/nuker/pyro/fc.c:I
        //   408: ifne            416
        //   411: ldc             1116348471
        //   413: goto            418
        //   416: ldc             -889511524
        //   418: ldc             -1317077731
        //   420: ixor           
        //   421: lookupswitch {
        //          -202056406: 416
        //          2072370305: 448
        //          default: 4076
        //        }
        //   448: goto            452
        //   451: athrow         
        //   452: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_184218_aH:()Z
        //   455: goto            459
        //   458: athrow         
        //   459: ifeq            467
        //   462: ldc             -1224599094
        //   464: goto            469
        //   467: ldc             -1224599095
        //   469: ldc             1029561603
        //   471: ixor           
        //   472: tableswitch {
        //          348096914: 496
        //          348096915: 3989
        //          default: 462
        //        }
        //   496: aload_1        
        //   497: goto            501
        //   500: athrow         
        //   501: invokevirtual   dev/nuker/pyro/f4e.0:()V
        //   504: goto            508
        //   507: athrow         
        //   508: goto            3989
        //   511: aload_1        
        //   512: goto            516
        //   515: athrow         
        //   516: invokevirtual   dev/nuker/pyro/f4e.c:()Lnet/minecraft/network/Packet;
        //   519: goto            523
        //   522: athrow         
        //   523: instanceof      Lnet/minecraft/network/play/server/SPacketMoveVehicle;
        //   526: ifeq            3270
        //   529: aload_1        
        //   530: getstatic       dev/nuker/pyro/fc.1:I
        //   533: ifne            541
        //   536: ldc             122935307
        //   538: goto            543
        //   541: ldc             -396444556
        //   543: ldc             -579302934
        //   545: ixor           
        //   546: lookupswitch {
        //          -634695199: 541
        //          891696542: 572
        //          default: 4048
        //        }
        //   572: goto            576
        //   575: athrow         
        //   576: invokevirtual   dev/nuker/pyro/f4e.c:()Lnet/minecraft/network/Packet;
        //   579: goto            583
        //   582: athrow         
        //   583: dup            
        //   584: ifnonnull       592
        //   587: ldc             -994085565
        //   589: goto            594
        //   592: ldc             -994085566
        //   594: ldc             -1307066759
        //   596: ixor           
        //   597: tableswitch {
        //          -313420172: 620
        //          -313420171: 649
        //          default: 587
        //        }
        //   620: new             Lkotlin/TypeCastException;
        //   623: dup            
        //   624: ldc             "\u3cdb\ub250\u8f93\uafb9\u6193\u5833\u7e41\u6886\uc0dc\ua53a\u9a78\u1344\uc0eb\u731a\u9642\u4c3b\ub210\u4d10\u0347\u01a0\u1334\ufecb\u6b1f\u8a4b\u30ff\u3cb1\u7fb6\ua8f9\ud3e4\u74e3\u45f7\u6bee\u758d\u9570\uc118\u42b2\ufdac\u1117\u1a52\u4c75\u67dc\uac0f\u8ca0\ufb39\uba3d\ua5a9\u4c30\u3e98\u4835\ua4ae\u7983\u916c\u32c1\u6dcd\uf012\u0f61\u7a49\u0b32\u9d6f\ud546\ue619\u4c6b\u49df\u14ce\u377c\u501b\u7982\ue668\u5df1\u8d14\uea44\u1df0\uf350\ub46d\uc688\u16fd\u2aee\u67c6\u4674\u7acd\ucbbd\u1722\u2ae0\u8dcd\ud686\u39cf\u9b98\u826e\ucad8"
        //   626: goto            630
        //   629: athrow         
        //   630: invokestatic    invokestatic   !!! ERROR
        //   633: goto            637
        //   636: athrow         
        //   637: goto            641
        //   640: athrow         
        //   641: invokespecial   kotlin/TypeCastException.<init>:(Ljava/lang/String;)V
        //   644: goto            648
        //   647: athrow         
        //   648: athrow         
        //   649: checkcast       Lnet/minecraft/network/play/server/SPacketMoveVehicle;
        //   652: astore_2       
        //   653: getstatic       dev/nuker/pyro/fc.c:I
        //   656: ifne            664
        //   659: ldc             135511332
        //   661: goto            666
        //   664: ldc             -974532384
        //   666: ldc             -816996019
        //   668: ixor           
        //   669: lookupswitch {
        //          -950133655: 4090
        //          1891412709: 664
        //          default: 696
        //        }
        //   696: aload_0        
        //   697: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //   700: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   703: dup            
        //   704: pop            
        //   705: goto            709
        //   708: athrow         
        //   709: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_184218_aH:()Z
        //   712: goto            716
        //   715: athrow         
        //   716: ifeq            1157
        //   719: aload_0        
        //   720: getstatic       dev/nuker/pyro/fc.0:I
        //   723: ifgt            731
        //   726: ldc             884620192
        //   728: goto            733
        //   731: ldc             969676315
        //   733: ldc             -1589029500
        //   735: ixor           
        //   736: lookupswitch {
        //          -1779208668: 731
        //          -1736096865: 764
        //          default: 4046
        //        }
        //   764: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //   767: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //   770: aconst_null    
        //   771: aload_0        
        //   772: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //   775: getstatic       dev/nuker/pyro/fc.c:I
        //   778: ifne            786
        //   781: ldc             930323745
        //   783: goto            788
        //   786: ldc             356193596
        //   788: ldc             -1135909793
        //   790: ixor           
        //   791: lookupswitch {
        //          -1959200386: 786
        //          -1452248733: 816
        //          default: 4082
        //        }
        //   816: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   819: dup            
        //   820: pop            
        //   821: getstatic       dev/nuker/pyro/fc.c:I
        //   824: ifne            832
        //   827: ldc             -534867141
        //   829: goto            834
        //   832: ldc             -1345171883
        //   834: ldc             2097771622
        //   836: ixor           
        //   837: lookupswitch {
        //          -1659377827: 832
        //          -757384653: 864
        //          default: 4060
        //        }
        //   864: goto            868
        //   867: athrow         
        //   868: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_184187_bx:()Lnet/minecraft/entity/Entity;
        //   871: goto            875
        //   874: athrow         
        //   875: dup            
        //   876: ifnonnull       890
        //   879: goto            883
        //   882: athrow         
        //   883: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //   886: goto            890
        //   889: athrow         
        //   890: dup            
        //   891: pop            
        //   892: getstatic       dev/nuker/pyro/fc.c:I
        //   895: ifne            903
        //   898: ldc             671862985
        //   900: goto            905
        //   903: ldc             -472496197
        //   905: ldc             184830982
        //   907: ixor           
        //   908: lookupswitch {
        //          -778578722: 903
        //          588225743: 4072
        //          default: 936
        //        }
        //   936: goto            940
        //   939: athrow         
        //   940: invokevirtual   net/minecraft/entity/Entity.func_174813_aQ:()Lnet/minecraft/util/math/AxisAlignedBB;
        //   943: goto            947
        //   946: athrow         
        //   947: ldc2_w          0.0625
        //   950: goto            954
        //   953: athrow         
        //   954: invokevirtual   net/minecraft/util/math/AxisAlignedBB.func_186662_g:(D)Lnet/minecraft/util/math/AxisAlignedBB;
        //   957: goto            961
        //   960: athrow         
        //   961: goto            965
        //   964: athrow         
        //   965: invokevirtual   net/minecraft/client/multiplayer/WorldClient.func_184144_a:(Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/AxisAlignedBB;)Ljava/util/List;
        //   968: goto            972
        //   971: athrow         
        //   972: dup            
        //   973: pop            
        //   974: checkcast       Ljava/util/Collection;
        //   977: astore_3       
        //   978: iconst_0       
        //   979: istore          4
        //   981: getstatic       dev/nuker/pyro/fc.c:I
        //   984: ifne            992
        //   987: ldc             -515847125
        //   989: goto            994
        //   992: ldc             -690079803
        //   994: ldc             188670836
        //   996: ixor           
        //   997: lookupswitch {
        //          -572468047: 1024
        //          -360829089: 992
        //          default: 4000
        //        }
        //  1024: aload_3        
        //  1025: getstatic       dev/nuker/pyro/fc.0:I
        //  1028: ifgt            1036
        //  1031: ldc             -1775396337
        //  1033: goto            1038
        //  1036: ldc             -1365571929
        //  1038: ldc             -1099620065
        //  1040: ixor           
        //  1041: lookupswitch {
        //          284043192: 1068
        //          676903696: 1036
        //          default: 4058
        //        }
        //  1068: goto            1072
        //  1071: athrow         
        //  1072: invokeinterface java/util/Collection.isEmpty:()Z
        //  1077: goto            1081
        //  1080: athrow         
        //  1081: ifne            1089
        //  1084: ldc             -765414113
        //  1086: goto            1091
        //  1089: ldc             -765414114
        //  1091: ldc             232776047
        //  1093: ixor           
        //  1094: tableswitch {
        //          -1082218272: 1116
        //          -1082218271: 1120
        //          default: 1084
        //        }
        //  1116: iconst_1       
        //  1117: goto            1121
        //  1120: iconst_0       
        //  1121: ifeq            1129
        //  1124: ldc             -1975971016
        //  1126: goto            1131
        //  1129: ldc             -1975971015
        //  1131: ldc             -1401010702
        //  1133: ixor           
        //  1134: tableswitch {
        //          1284418964: 1156
        //          1284418965: 1157
        //          default: 1124
        //        }
        //  1156: return         
        //  1157: aload_0        
        //  1158: getfield        dev/nuker/pyro/f9e.c:Ldev/nuker/pyro/f0o;
        //  1161: goto            1165
        //  1164: athrow         
        //  1165: invokevirtual   dev/nuker/pyro/f0o.c:()Ljava/lang/Object;
        //  1168: goto            1172
        //  1171: athrow         
        //  1172: checkcast       Ldev/nuker/pyro/f9b;
        //  1175: getstatic       dev/nuker/pyro/fc.0:I
        //  1178: ifgt            1186
        //  1181: ldc             144483396
        //  1183: goto            1188
        //  1186: ldc             -360070656
        //  1188: ldc             1074463791
        //  1190: ixor           
        //  1191: lookupswitch {
        //          1217896555: 4094
        //          2070720807: 1186
        //          default: 1216
        //        }
        //  1216: getstatic       dev/nuker/pyro/f9d.c:[I
        //  1219: swap           
        //  1220: getstatic       dev/nuker/pyro/fc.0:I
        //  1223: ifgt            1231
        //  1226: ldc             -741123885
        //  1228: goto            1233
        //  1231: ldc             -839089036
        //  1233: ldc             -843879360
        //  1235: ixor           
        //  1236: lookupswitch {
        //          5236788: 1264
        //          509621395: 1231
        //          default: 4014
        //        }
        //  1264: goto            1268
        //  1267: athrow         
        //  1268: invokevirtual   dev/nuker/pyro/f9b.ordinal:()I
        //  1271: goto            1275
        //  1274: athrow         
        //  1275: iaload         
        //  1276: tableswitch {
        //                2: 1308
        //                3: 1312
        //                4: 1752
        //                5: 2075
        //          default: 2751
        //        }
        //  1308: iconst_1       
        //  1309: goto            2767
        //  1312: aload_0        
        //  1313: dup            
        //  1314: getstatic       dev/nuker/pyro/fc.c:I
        //  1317: ifne            1325
        //  1320: ldc             -1403945593
        //  1322: goto            1327
        //  1325: ldc             885185231
        //  1327: ldc             2067863630
        //  1329: ixor           
        //  1330: lookupswitch {
        //          -686791223: 1325
        //          1334035073: 1356
        //          default: 4096
        //        }
        //  1356: getfield        dev/nuker/pyro/f9e.3:I
        //  1359: dup            
        //  1360: istore_3       
        //  1361: iconst_1       
        //  1362: iadd           
        //  1363: putfield        dev/nuker/pyro/f9e.3:I
        //  1366: getstatic       dev/nuker/pyro/fc.c:I
        //  1369: ifne            1378
        //  1372: ldc_w           -1794858061
        //  1375: goto            1381
        //  1378: ldc_w           1079846868
        //  1381: ldc_w           21495193
        //  1384: ixor           
        //  1385: lookupswitch {
        //          -1807524310: 4054
        //          787652557: 1378
        //          default: 1412
        //        }
        //  1412: getstatic       dev/nuker/pyro/Pyro.INSTANCE:Ldev/nuker/pyro/Pyro;
        //  1415: new             Ljava/lang/StringBuilder;
        //  1418: dup            
        //  1419: goto            1423
        //  1422: athrow         
        //  1423: invokespecial   java/lang/StringBuilder.<init>:()V
        //  1426: goto            1430
        //  1429: athrow         
        //  1430: ldc_w           "\u3cf6\ub24a\u8f8a\uafbb\u61c7\u586a\u7e00"
        //  1433: goto            1437
        //  1436: athrow         
        //  1437: invokestatic    invokestatic   !!! ERROR
        //  1440: goto            1444
        //  1443: athrow         
        //  1444: goto            1448
        //  1447: athrow         
        //  1448: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  1451: goto            1455
        //  1454: athrow         
        //  1455: aload_0        
        //  1456: getfield        dev/nuker/pyro/f9e.3:I
        //  1459: goto            1463
        //  1462: athrow         
        //  1463: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //  1466: goto            1470
        //  1469: athrow         
        //  1470: getstatic       dev/nuker/pyro/fc.c:I
        //  1473: ifne            1482
        //  1476: ldc_w           1899971834
        //  1479: goto            1485
        //  1482: ldc_w           1541903638
        //  1485: ldc_w           299123763
        //  1488: ixor           
        //  1489: lookupswitch {
        //          1244909861: 1516
        //          1626013897: 1482
        //          default: 4066
        //        }
        //  1516: goto            1520
        //  1519: athrow         
        //  1520: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  1523: goto            1527
        //  1526: athrow         
        //  1527: getstatic       dev/nuker/pyro/fc.1:I
        //  1530: ifne            1539
        //  1533: ldc_w           1531845095
        //  1536: goto            1542
        //  1539: ldc_w           243966868
        //  1542: ldc_w           -797364582
        //  1545: ixor           
        //  1546: lookupswitch {
        //          -1959315587: 3992
        //          897407187: 1539
        //          default: 1572
        //        }
        //  1572: goto            1576
        //  1575: athrow         
        //  1576: invokevirtual   dev/nuker/pyro/Pyro.sendMessage:(Ljava/lang/String;)V
        //  1579: goto            1583
        //  1582: athrow         
        //  1583: aload_0        
        //  1584: getfield        dev/nuker/pyro/f9e.3:I
        //  1587: aload_0        
        //  1588: getstatic       dev/nuker/pyro/fc.1:I
        //  1591: ifne            1600
        //  1594: ldc_w           -1327700988
        //  1597: goto            1603
        //  1600: ldc_w           1578991831
        //  1603: ldc_w           536080887
        //  1606: ixor           
        //  1607: lookupswitch {
        //          -1355868685: 4016
        //          581856851: 1600
        //          default: 1632
        //        }
        //  1632: getfield        dev/nuker/pyro/f9e.c:Ldev/nuker/pyro/f0p;
        //  1635: goto            1639
        //  1638: athrow         
        //  1639: invokevirtual   dev/nuker/pyro/f0p.c:()Ljava/lang/Object;
        //  1642: goto            1646
        //  1645: athrow         
        //  1646: checkcast       Ljava/lang/Number;
        //  1649: getstatic       dev/nuker/pyro/fc.c:I
        //  1652: ifne            1661
        //  1655: ldc_w           -1501340192
        //  1658: goto            1664
        //  1661: ldc_w           -615044987
        //  1664: ldc_w           1144450208
        //  1667: ixor           
        //  1668: lookupswitch {
        //          -1620982747: 1696
        //          -491409088: 1661
        //          default: 4050
        //        }
        //  1696: goto            1700
        //  1699: athrow         
        //  1700: invokevirtual   java/lang/Number.intValue:()I
        //  1703: goto            1707
        //  1706: athrow         
        //  1707: if_icmpge       1716
        //  1710: ldc_w           -970451808
        //  1713: goto            1719
        //  1716: ldc_w           -970451807
        //  1719: ldc_w           -943476192
        //  1722: ixor           
        //  1723: tableswitch {
        //          64441600: 1744
        //          64441601: 1748
        //          default: 1710
        //        }
        //  1744: iconst_1       
        //  1745: goto            2767
        //  1748: iconst_0       
        //  1749: goto            2767
        //  1752: aload_0        
        //  1753: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //  1756: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1759: getstatic       dev/nuker/pyro/fc.0:I
        //  1762: ifgt            1771
        //  1765: ldc_w           827975248
        //  1768: goto            1774
        //  1771: ldc_w           -1123309588
        //  1774: ldc_w           -1052537456
        //  1777: ixor           
        //  1778: lookupswitch {
        //          -266703936: 4074
        //          1571599338: 1771
        //          default: 1804
        //        }
        //  1804: aload_2        
        //  1805: goto            1809
        //  1808: athrow         
        //  1809: invokevirtual   net/minecraft/network/play/server/SPacketMoveVehicle.func_186957_a:()D
        //  1812: goto            1816
        //  1815: athrow         
        //  1816: getstatic       dev/nuker/pyro/fc.c:I
        //  1819: ifne            1828
        //  1822: ldc_w           -1751101870
        //  1825: goto            1831
        //  1828: ldc_w           694757481
        //  1831: ldc_w           -704914603
        //  1834: ixor           
        //  1835: lookupswitch {
        //          -57478340: 1860
        //          1113298183: 1828
        //          default: 4064
        //        }
        //  1860: aload_2        
        //  1861: goto            1865
        //  1864: athrow         
        //  1865: invokevirtual   net/minecraft/network/play/server/SPacketMoveVehicle.func_186955_b:()D
        //  1868: goto            1872
        //  1871: athrow         
        //  1872: aload_2        
        //  1873: getstatic       dev/nuker/pyro/fc.1:I
        //  1876: ifne            1885
        //  1879: ldc_w           2123874441
        //  1882: goto            1888
        //  1885: ldc_w           1722707545
        //  1888: ldc_w           328840911
        //  1891: ixor           
        //  1892: lookupswitch {
        //          -1119362847: 1885
        //          1829664326: 4086
        //          default: 1920
        //        }
        //  1920: goto            1924
        //  1923: athrow         
        //  1924: invokevirtual   net/minecraft/network/play/server/SPacketMoveVehicle.func_186956_c:()D
        //  1927: goto            1931
        //  1930: athrow         
        //  1931: getstatic       dev/nuker/pyro/fc.0:I
        //  1934: ifgt            1943
        //  1937: ldc_w           493291954
        //  1940: goto            1946
        //  1943: ldc_w           1652335181
        //  1946: ldc_w           1565856688
        //  1949: ixor           
        //  1950: lookupswitch {
        //          1059697149: 1976
        //          1077025282: 1943
        //          default: 4088
        //        }
        //  1976: goto            1980
        //  1979: athrow         
        //  1980: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_70011_f:(DDD)D
        //  1983: goto            1987
        //  1986: athrow         
        //  1987: aload_0        
        //  1988: getfield        dev/nuker/pyro/f9e.0:Ldev/nuker/pyro/f0p;
        //  1991: goto            1995
        //  1994: athrow         
        //  1995: invokevirtual   dev/nuker/pyro/f0p.c:()Ljava/lang/Object;
        //  1998: goto            2002
        //  2001: athrow         
        //  2002: checkcast       Ljava/lang/Number;
        //  2005: getstatic       dev/nuker/pyro/fc.0:I
        //  2008: ifgt            2017
        //  2011: ldc_w           -713891127
        //  2014: goto            2020
        //  2017: ldc_w           1376859662
        //  2020: ldc_w           311941904
        //  2023: ixor           
        //  2024: lookupswitch {
        //          -941278759: 2017
        //          1082584350: 2052
        //          default: 4036
        //        }
        //  2052: goto            2056
        //  2055: athrow         
        //  2056: invokevirtual   java/lang/Number.doubleValue:()D
        //  2059: goto            2063
        //  2062: athrow         
        //  2063: dcmpg          
        //  2064: ifgt            2071
        //  2067: iconst_1       
        //  2068: goto            2767
        //  2071: iconst_0       
        //  2072: goto            2767
        //  2075: aload_0        
        //  2076: dup            
        //  2077: getstatic       dev/nuker/pyro/fc.0:I
        //  2080: ifgt            2089
        //  2083: ldc_w           1160719137
        //  2086: goto            2092
        //  2089: ldc_w           923652333
        //  2092: ldc_w           -35580179
        //  2095: ixor           
        //  2096: lookupswitch {
        //          -1194443316: 2089
        //          -890452480: 2124
        //          default: 4092
        //        }
        //  2124: getfield        dev/nuker/pyro/f9e.3:I
        //  2127: dup            
        //  2128: getstatic       dev/nuker/pyro/fc.c:I
        //  2131: ifne            2140
        //  2134: ldc_w           559086806
        //  2137: goto            2143
        //  2140: ldc_w           -2136726543
        //  2143: ldc_w           -1321594888
        //  2146: ixor           
        //  2147: lookupswitch {
        //          -1872170194: 2140
        //          832449545: 2172
        //          default: 4018
        //        }
        //  2172: istore_3       
        //  2173: iconst_1       
        //  2174: iadd           
        //  2175: putfield        dev/nuker/pyro/f9e.3:I
        //  2178: getstatic       dev/nuker/pyro/Pyro.INSTANCE:Ldev/nuker/pyro/Pyro;
        //  2181: new             Ljava/lang/StringBuilder;
        //  2184: dup            
        //  2185: goto            2189
        //  2188: athrow         
        //  2189: invokespecial   java/lang/StringBuilder.<init>:()V
        //  2192: goto            2196
        //  2195: athrow         
        //  2196: ldc_w           "\u3cf6\ub24a\u8f8a\uafbb\u61c7\u586a\u7e00"
        //  2199: getstatic       dev/nuker/pyro/fc.0:I
        //  2202: ifgt            2211
        //  2205: ldc_w           1207140778
        //  2208: goto            2214
        //  2211: ldc_w           -1902053803
        //  2214: ldc_w           625911806
        //  2217: ixor           
        //  2218: lookupswitch {
        //          -1410444885: 2244
        //          1656563284: 2211
        //          default: 4006
        //        }
        //  2244: goto            2248
        //  2247: athrow         
        //  2248: invokestatic    invokestatic   !!! ERROR
        //  2251: goto            2255
        //  2254: athrow         
        //  2255: goto            2259
        //  2258: athrow         
        //  2259: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //  2262: goto            2266
        //  2265: athrow         
        //  2266: aload_0        
        //  2267: getstatic       dev/nuker/pyro/fc.c:I
        //  2270: ifne            2279
        //  2273: ldc_w           -2131708827
        //  2276: goto            2282
        //  2279: ldc_w           117260186
        //  2282: ldc_w           1568708479
        //  2285: ixor           
        //  2286: lookupswitch {
        //          -579853542: 3990
        //          1846210336: 2279
        //          default: 2312
        //        }
        //  2312: getfield        dev/nuker/pyro/f9e.3:I
        //  2315: getstatic       dev/nuker/pyro/fc.0:I
        //  2318: ifgt            2327
        //  2321: ldc_w           -1872793892
        //  2324: goto            2330
        //  2327: ldc_w           -1781120780
        //  2330: ldc_w           830433672
        //  2333: ixor           
        //  2334: lookupswitch {
        //          -1591736492: 2327
        //          -1532417668: 2360
        //          default: 4012
        //        }
        //  2360: goto            2364
        //  2363: athrow         
        //  2364: invokevirtual   java/lang/StringBuilder.append:(I)Ljava/lang/StringBuilder;
        //  2367: goto            2371
        //  2370: athrow         
        //  2371: goto            2375
        //  2374: athrow         
        //  2375: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //  2378: goto            2382
        //  2381: athrow         
        //  2382: goto            2386
        //  2385: athrow         
        //  2386: invokevirtual   dev/nuker/pyro/Pyro.sendMessage:(Ljava/lang/String;)V
        //  2389: goto            2393
        //  2392: athrow         
        //  2393: aload_0        
        //  2394: getfield        dev/nuker/pyro/f9e.3:I
        //  2397: aload_0        
        //  2398: getstatic       dev/nuker/pyro/fc.c:I
        //  2401: ifne            2410
        //  2404: ldc_w           -1683253540
        //  2407: goto            2413
        //  2410: ldc_w           -1069314113
        //  2413: ldc_w           -738316489
        //  2416: ixor           
        //  2417: lookupswitch {
        //          331194504: 2444
        //          1213577707: 2410
        //          default: 4070
        //        }
        //  2444: getfield        dev/nuker/pyro/f9e.c:Ldev/nuker/pyro/f0p;
        //  2447: goto            2451
        //  2450: athrow         
        //  2451: invokevirtual   dev/nuker/pyro/f0p.c:()Ljava/lang/Object;
        //  2454: goto            2458
        //  2457: athrow         
        //  2458: checkcast       Ljava/lang/Number;
        //  2461: goto            2465
        //  2464: athrow         
        //  2465: invokevirtual   java/lang/Number.intValue:()I
        //  2468: goto            2472
        //  2471: athrow         
        //  2472: if_icmplt       2743
        //  2475: aload_0        
        //  2476: getstatic       dev/nuker/pyro/fc.c:I
        //  2479: ifne            2488
        //  2482: ldc_w           -566646789
        //  2485: goto            2491
        //  2488: ldc_w           -988013518
        //  2491: ldc_w           1326476769
        //  2494: ixor           
        //  2495: lookupswitch {
        //          -1859532262: 4044
        //          1930240711: 2488
        //          default: 2520
        //        }
        //  2520: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //  2523: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  2526: getstatic       dev/nuker/pyro/fc.0:I
        //  2529: ifgt            2538
        //  2532: ldc_w           1759606007
        //  2535: goto            2541
        //  2538: ldc_w           -1931637314
        //  2541: ldc_w           228683701
        //  2544: ixor           
        //  2545: lookupswitch {
        //          -2122522101: 2572
        //          1698700098: 2538
        //          default: 4034
        //        }
        //  2572: aload_2        
        //  2573: goto            2577
        //  2576: athrow         
        //  2577: invokevirtual   net/minecraft/network/play/server/SPacketMoveVehicle.func_186957_a:()D
        //  2580: goto            2584
        //  2583: athrow         
        //  2584: getstatic       dev/nuker/pyro/fc.0:I
        //  2587: ifgt            2596
        //  2590: ldc_w           -476659482
        //  2593: goto            2599
        //  2596: ldc_w           -541335253
        //  2599: ldc_w           -1007253458
        //  2602: ixor           
        //  2603: lookupswitch {
        //          543181000: 4008
        //          1946160490: 2596
        //          default: 2628
        //        }
        //  2628: aload_2        
        //  2629: goto            2633
        //  2632: athrow         
        //  2633: invokevirtual   net/minecraft/network/play/server/SPacketMoveVehicle.func_186955_b:()D
        //  2636: goto            2640
        //  2639: athrow         
        //  2640: aload_2        
        //  2641: getstatic       dev/nuker/pyro/fc.0:I
        //  2644: ifgt            2653
        //  2647: ldc_w           -847747511
        //  2650: goto            2656
        //  2653: ldc_w           1237636137
        //  2656: ldc_w           998616613
        //  2659: ixor           
        //  2660: lookupswitch {
        //          -151140244: 4068
        //          82384133: 2653
        //          default: 2688
        //        }
        //  2688: goto            2692
        //  2691: athrow         
        //  2692: invokevirtual   net/minecraft/network/play/server/SPacketMoveVehicle.func_186956_c:()D
        //  2695: goto            2699
        //  2698: athrow         
        //  2699: goto            2703
        //  2702: athrow         
        //  2703: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_70011_f:(DDD)D
        //  2706: goto            2710
        //  2709: athrow         
        //  2710: aload_0        
        //  2711: getfield        dev/nuker/pyro/f9e.0:Ldev/nuker/pyro/f0p;
        //  2714: goto            2718
        //  2717: athrow         
        //  2718: invokevirtual   dev/nuker/pyro/f0p.c:()Ljava/lang/Object;
        //  2721: goto            2725
        //  2724: athrow         
        //  2725: checkcast       Ljava/lang/Number;
        //  2728: goto            2732
        //  2731: athrow         
        //  2732: invokevirtual   java/lang/Number.doubleValue:()D
        //  2735: goto            2739
        //  2738: athrow         
        //  2739: dcmpg          
        //  2740: ifgt            2747
        //  2743: iconst_1       
        //  2744: goto            2767
        //  2747: iconst_0       
        //  2748: goto            2767
        //  2751: new             Lkotlin/NoWhenBranchMatchedException;
        //  2754: dup            
        //  2755: goto            2759
        //  2758: athrow         
        //  2759: invokespecial   kotlin/NoWhenBranchMatchedException.<init>:()V
        //  2762: goto            2766
        //  2765: athrow         
        //  2766: athrow         
        //  2767: ifeq            2785
        //  2770: aload_1        
        //  2771: goto            2775
        //  2774: athrow         
        //  2775: invokevirtual   dev/nuker/pyro/f4e.0:()V
        //  2778: goto            2782
        //  2781: athrow         
        //  2782: goto            3006
        //  2785: getstatic       dev/nuker/pyro/f64.c:Ldev/nuker/pyro/fa1;
        //  2788: getfield        dev/nuker/pyro/fa1.c:Ldev/nuker/pyro/fw;
        //  2791: goto            2795
        //  2794: athrow         
        //  2795: invokevirtual   dev/nuker/pyro/fw.0:()Ljava/lang/Object;
        //  2798: goto            2802
        //  2801: athrow         
        //  2802: dup            
        //  2803: pop            
        //  2804: checkcast       Ljava/lang/Boolean;
        //  2807: goto            2811
        //  2810: athrow         
        //  2811: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //  2814: goto            2818
        //  2817: athrow         
        //  2818: ifeq            3006
        //  2821: getstatic       dev/nuker/pyro/f64.c:Ldev/nuker/pyro/fa1;
        //  2824: aload_2        
        //  2825: goto            2829
        //  2828: athrow         
        //  2829: invokevirtual   net/minecraft/network/play/server/SPacketMoveVehicle.func_186957_a:()D
        //  2832: goto            2836
        //  2835: athrow         
        //  2836: getstatic       dev/nuker/pyro/fc.1:I
        //  2839: ifne            2848
        //  2842: ldc_w           -651965009
        //  2845: goto            2851
        //  2848: ldc_w           1558445621
        //  2851: ldc_w           -1266003989
        //  2854: ixor           
        //  2855: lookupswitch {
        //          -395726370: 2880
        //          1839825476: 2848
        //          default: 4030
        //        }
        //  2880: aload_2        
        //  2881: goto            2885
        //  2884: athrow         
        //  2885: invokevirtual   net/minecraft/network/play/server/SPacketMoveVehicle.func_186955_b:()D
        //  2888: goto            2892
        //  2891: athrow         
        //  2892: getstatic       dev/nuker/pyro/fc.c:I
        //  2895: ifne            2904
        //  2898: ldc_w           770507666
        //  2901: goto            2907
        //  2904: ldc_w           1350954353
        //  2907: ldc_w           1264030129
        //  2910: ixor           
        //  2911: lookupswitch {
        //          466779328: 2936
        //          1723503139: 2904
        //          default: 3994
        //        }
        //  2936: aload_2        
        //  2937: getstatic       dev/nuker/pyro/fc.1:I
        //  2940: ifne            2949
        //  2943: ldc_w           940997384
        //  2946: goto            2952
        //  2949: ldc_w           -667934551
        //  2952: ldc_w           -1409858607
        //  2955: ixor           
        //  2956: lookupswitch {
        //          -1813956391: 3996
        //          731617725: 2949
        //          default: 2984
        //        }
        //  2984: goto            2988
        //  2987: athrow         
        //  2988: invokevirtual   net/minecraft/network/play/server/SPacketMoveVehicle.func_186956_c:()D
        //  2991: goto            2995
        //  2994: athrow         
        //  2995: goto            2999
        //  2998: athrow         
        //  2999: invokevirtual   dev/nuker/pyro/fa1.c:(DDD)V
        //  3002: goto            3006
        //  3005: athrow         
        //  3006: getstatic       dev/nuker/pyro/Pyro.INSTANCE:Ldev/nuker/pyro/Pyro;
        //  3009: getstatic       dev/nuker/pyro/fc.c:I
        //  3012: ifne            3021
        //  3015: ldc_w           1044822178
        //  3018: goto            3024
        //  3021: ldc_w           -925826265
        //  3024: ldc_w           -1937049887
        //  3027: ixor           
        //  3028: lookupswitch {
        //          -1295233469: 4078
        //          624771817: 3021
        //          default: 3056
        //        }
        //  3056: aload_0        
        //  3057: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //  3060: getstatic       dev/nuker/pyro/fc.1:I
        //  3063: ifne            3072
        //  3066: ldc_w           2109268827
        //  3069: goto            3075
        //  3072: ldc_w           1366417129
        //  3075: ldc_w           1521299476
        //  3078: ixor           
        //  3079: lookupswitch {
        //          199028477: 3104
        //          655741775: 3072
        //          default: 4028
        //        }
        //  3104: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  3107: aload_2        
        //  3108: getstatic       dev/nuker/pyro/fc.1:I
        //  3111: ifne            3120
        //  3114: ldc_w           1021746907
        //  3117: goto            3123
        //  3120: ldc_w           -595381645
        //  3123: ldc_w           792279463
        //  3126: ixor           
        //  3127: lookupswitch {
        //          333424508: 4024
        //          1631188024: 3120
        //          default: 3152
        //        }
        //  3152: goto            3156
        //  3155: athrow         
        //  3156: invokevirtual   net/minecraft/network/play/server/SPacketMoveVehicle.func_186957_a:()D
        //  3159: goto            3163
        //  3162: athrow         
        //  3163: aload_2        
        //  3164: goto            3168
        //  3167: athrow         
        //  3168: invokevirtual   net/minecraft/network/play/server/SPacketMoveVehicle.func_186955_b:()D
        //  3171: goto            3175
        //  3174: athrow         
        //  3175: aload_2        
        //  3176: goto            3180
        //  3179: athrow         
        //  3180: invokevirtual   net/minecraft/network/play/server/SPacketMoveVehicle.func_186956_c:()D
        //  3183: goto            3187
        //  3186: athrow         
        //  3187: goto            3191
        //  3190: athrow         
        //  3191: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_70011_f:(DDD)D
        //  3194: goto            3198
        //  3197: athrow         
        //  3198: goto            3202
        //  3201: athrow         
        //  3202: invokestatic    java/lang/String.valueOf:(D)Ljava/lang/String;
        //  3205: goto            3209
        //  3208: athrow         
        //  3209: getstatic       dev/nuker/pyro/fc.c:I
        //  3212: ifne            3221
        //  3215: ldc_w           1742547969
        //  3218: goto            3224
        //  3221: ldc_w           -2115393733
        //  3224: ldc_w           1377077657
        //  3227: ixor           
        //  3228: lookupswitch {
        //          -738382174: 3256
        //          902407576: 3221
        //          default: 4056
        //        }
        //  3256: goto            3260
        //  3259: athrow         
        //  3260: invokevirtual   dev/nuker/pyro/Pyro.sendMessage:(Ljava/lang/String;)V
        //  3263: goto            3267
        //  3266: athrow         
        //  3267: goto            3989
        //  3270: aload_1        
        //  3271: goto            3275
        //  3274: athrow         
        //  3275: invokevirtual   dev/nuker/pyro/f4e.c:()Lnet/minecraft/network/Packet;
        //  3278: goto            3282
        //  3281: athrow         
        //  3282: instanceof      Lnet/minecraft/network/play/server/SPacketSetPassengers;
        //  3285: ifeq            3989
        //  3288: aload_0        
        //  3289: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //  3292: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  3295: dup            
        //  3296: pop            
        //  3297: goto            3301
        //  3300: athrow         
        //  3301: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_184218_aH:()Z
        //  3304: goto            3308
        //  3307: athrow         
        //  3308: ifeq            3317
        //  3311: ldc_w           -1260869368
        //  3314: goto            3320
        //  3317: ldc_w           -1260869367
        //  3320: ldc_w           402990070
        //  3323: ixor           
        //  3324: tableswitch {
        //          1505433084: 3348
        //          1505433085: 3989
        //          default: 3311
        //        }
        //  3348: getstatic       dev/nuker/pyro/fc.1:I
        //  3351: ifne            3360
        //  3354: ldc_w           -1276348490
        //  3357: goto            3363
        //  3360: ldc_w           751191448
        //  3363: ldc_w           -1126094230
        //  3366: ixor           
        //  3367: lookupswitch {
        //          -1602909305: 3360
        //          252534236: 4026
        //          default: 3392
        //        }
        //  3392: aload_1        
        //  3393: goto            3397
        //  3396: athrow         
        //  3397: invokevirtual   dev/nuker/pyro/f4e.c:()Lnet/minecraft/network/Packet;
        //  3400: goto            3404
        //  3403: athrow         
        //  3404: dup            
        //  3405: ifnonnull       3438
        //  3408: new             Lkotlin/TypeCastException;
        //  3411: dup            
        //  3412: ldc_w           "\u3cdb\ub250\u8f93\uafb9\u6193\u5833\u7e41\u6886\uc0dc\ua53a\u9a78\u1344\uc0eb\u731a\u9642\u4c3b\ub210\u4d10\u0347\u01a0\u1334\ufecb\u6b1f\u8a4b\u30ff\u3cb1\u7fb6\ua8f9\ud3e4\u74e3\u45f7\u6bee\u758d\u9570\uc118\u42b2\ufdac\u1117\u1a52\u4c75\u67dc\uac0f\u8ca0\ufb39\uba3d\ua5a9\u4c30\u3e98\u4835\ua4ae\u7983\u916c\u32c1\u6dcd\uf012\u0f61\u7a49\u0b32\u9d6f\ud546\ue619\u4c6b\u49df\u14ce\u377c\u501b\u7982\ue668\u5df1\u8d14\uea44\u1df0\uf350\ub46d\uc688\u16fd\u2aee\u67c6\u466a\u7ac7\ucbbf\u1717\u2ad7\u8ddb\ud69d\u39c3\u9b95\u8265\ucad8\ucb52\uae36"
        //  3415: goto            3419
        //  3418: athrow         
        //  3419: invokestatic    invokestatic   !!! ERROR
        //  3422: goto            3426
        //  3425: athrow         
        //  3426: goto            3430
        //  3429: athrow         
        //  3430: invokespecial   kotlin/TypeCastException.<init>:(Ljava/lang/String;)V
        //  3433: goto            3437
        //  3436: athrow         
        //  3437: athrow         
        //  3438: checkcast       Lnet/minecraft/network/play/server/SPacketSetPassengers;
        //  3441: getstatic       dev/nuker/pyro/fc.0:I
        //  3444: ifgt            3453
        //  3447: ldc_w           -1660498743
        //  3450: goto            3456
        //  3453: ldc_w           76113561
        //  3456: ldc_w           74303178
        //  3459: ixor           
        //  3460: lookupswitch {
        //          -1721038333: 3453
        //          14983251: 3488
        //          default: 4062
        //        }
        //  3488: astore_2       
        //  3489: aload_2        
        //  3490: getstatic       dev/nuker/pyro/fc.1:I
        //  3493: ifne            3502
        //  3496: ldc_w           -874657280
        //  3499: goto            3505
        //  3502: ldc_w           1081577748
        //  3505: ldc_w           -1034294738
        //  3508: ixor           
        //  3509: lookupswitch {
        //          -885206492: 3502
        //          159653934: 4010
        //          default: 3536
        //        }
        //  3536: goto            3540
        //  3539: athrow         
        //  3540: invokevirtual   net/minecraft/network/play/server/SPacketSetPassengers.func_186972_b:()I
        //  3543: goto            3547
        //  3546: athrow         
        //  3547: aload_0        
        //  3548: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //  3551: getstatic       dev/nuker/pyro/fc.0:I
        //  3554: ifgt            3563
        //  3557: ldc_w           695888960
        //  3560: goto            3566
        //  3563: ldc_w           -826791281
        //  3566: ldc_w           -754298615
        //  3569: ixor           
        //  3570: lookupswitch {
        //          -93307575: 3563
        //          498236294: 3596
        //          default: 4020
        //        }
        //  3596: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  3599: dup            
        //  3600: pop            
        //  3601: goto            3605
        //  3604: athrow         
        //  3605: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_184187_bx:()Lnet/minecraft/entity/Entity;
        //  3608: goto            3612
        //  3611: athrow         
        //  3612: dup            
        //  3613: ifnonnull       3627
        //  3616: goto            3620
        //  3619: athrow         
        //  3620: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //  3623: goto            3627
        //  3626: athrow         
        //  3627: dup            
        //  3628: pop            
        //  3629: goto            3633
        //  3632: athrow         
        //  3633: invokevirtual   net/minecraft/entity/Entity.func_145782_y:()I
        //  3636: goto            3640
        //  3639: athrow         
        //  3640: if_icmpne       3989
        //  3643: aload_2        
        //  3644: goto            3648
        //  3647: athrow         
        //  3648: invokevirtual   net/minecraft/network/play/server/SPacketSetPassengers.func_186971_a:()[I
        //  3651: goto            3655
        //  3654: athrow         
        //  3655: astore          5
        //  3657: aload           5
        //  3659: arraylength    
        //  3660: istore          6
        //  3662: iconst_0       
        //  3663: istore          4
        //  3665: getstatic       dev/nuker/pyro/fc.c:I
        //  3668: ifne            3677
        //  3671: ldc_w           -1121280284
        //  3674: goto            3680
        //  3677: ldc_w           -1613487358
        //  3680: ldc_w           1204246432
        //  3683: ixor           
        //  3684: lookupswitch {
        //          -669813598: 3712
        //          -85079740: 3677
        //          default: 4042
        //        }
        //  3712: iload           4
        //  3714: iload           6
        //  3716: if_icmpge       3725
        //  3719: ldc_w           -1621799586
        //  3722: goto            3728
        //  3725: ldc_w           -1621799587
        //  3728: ldc_w           1704104239
        //  3731: ixor           
        //  3732: tableswitch {
        //          -175130398: 3756
        //          -175130397: 3989
        //          default: 3719
        //        }
        //  3756: aload           5
        //  3758: iload           4
        //  3760: iaload         
        //  3761: getstatic       dev/nuker/pyro/fc.1:I
        //  3764: ifne            3773
        //  3767: ldc_w           1398285659
        //  3770: goto            3776
        //  3773: ldc_w           -1506147289
        //  3776: ldc_w           -1130351092
        //  3779: ixor           
        //  3780: lookupswitch {
        //          -268954793: 3773
        //          446313003: 3808
        //          default: 4084
        //        }
        //  3808: istore_3       
        //  3809: iload_3        
        //  3810: getstatic       dev/nuker/pyro/fc.c:I
        //  3813: ifne            3822
        //  3816: ldc_w           -621069058
        //  3819: goto            3825
        //  3822: ldc_w           -1845722484
        //  3825: ldc_w           -1494752259
        //  3828: ixor           
        //  3829: lookupswitch {
        //          -294160398: 3822
        //          2082266883: 4032
        //          default: 3856
        //        }
        //  3856: aload_0        
        //  3857: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //  3860: getstatic       dev/nuker/pyro/fc.c:I
        //  3863: ifne            3872
        //  3866: ldc_w           51860445
        //  3869: goto            3875
        //  3872: ldc_w           706112149
        //  3875: ldc_w           -464522747
        //  3878: ixor           
        //  3879: lookupswitch {
        //          -413621800: 4002
        //          1023634101: 3872
        //          default: 3904
        //        }
        //  3904: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  3907: dup            
        //  3908: pop            
        //  3909: getstatic       dev/nuker/pyro/fc.1:I
        //  3912: ifne            3921
        //  3915: ldc_w           320010466
        //  3918: goto            3924
        //  3921: ldc_w           632014473
        //  3924: ldc_w           -787813471
        //  3927: ixor           
        //  3928: lookupswitch {
        //          -1038609597: 3921
        //          -190763736: 3956
        //          default: 4038
        //        }
        //  3956: goto            3960
        //  3959: athrow         
        //  3960: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_145782_y:()I
        //  3963: goto            3967
        //  3966: athrow         
        //  3967: if_icmpne       3983
        //  3970: aload_1        
        //  3971: goto            3975
        //  3974: athrow         
        //  3975: invokevirtual   dev/nuker/pyro/f4e.0:()V
        //  3978: goto            3982
        //  3981: athrow         
        //  3982: return         
        //  3983: iinc            4, 1
        //  3986: goto            3665
        //  3989: return         
        //  3990: aconst_null    
        //  3991: athrow         
        //  3992: aconst_null    
        //  3993: athrow         
        //  3994: aconst_null    
        //  3995: athrow         
        //  3996: aconst_null    
        //  3997: athrow         
        //  3998: aconst_null    
        //  3999: athrow         
        //  4000: aconst_null    
        //  4001: athrow         
        //  4002: aconst_null    
        //  4003: athrow         
        //  4004: aconst_null    
        //  4005: athrow         
        //  4006: aconst_null    
        //  4007: athrow         
        //  4008: aconst_null    
        //  4009: athrow         
        //  4010: aconst_null    
        //  4011: athrow         
        //  4012: aconst_null    
        //  4013: athrow         
        //  4014: aconst_null    
        //  4015: athrow         
        //  4016: aconst_null    
        //  4017: athrow         
        //  4018: aconst_null    
        //  4019: athrow         
        //  4020: aconst_null    
        //  4021: athrow         
        //  4022: aconst_null    
        //  4023: athrow         
        //  4024: aconst_null    
        //  4025: athrow         
        //  4026: aconst_null    
        //  4027: athrow         
        //  4028: aconst_null    
        //  4029: athrow         
        //  4030: aconst_null    
        //  4031: athrow         
        //  4032: aconst_null    
        //  4033: athrow         
        //  4034: aconst_null    
        //  4035: athrow         
        //  4036: aconst_null    
        //  4037: athrow         
        //  4038: aconst_null    
        //  4039: athrow         
        //  4040: aconst_null    
        //  4041: athrow         
        //  4042: aconst_null    
        //  4043: athrow         
        //  4044: aconst_null    
        //  4045: athrow         
        //  4046: aconst_null    
        //  4047: athrow         
        //  4048: aconst_null    
        //  4049: athrow         
        //  4050: aconst_null    
        //  4051: athrow         
        //  4052: aconst_null    
        //  4053: athrow         
        //  4054: aconst_null    
        //  4055: athrow         
        //  4056: aconst_null    
        //  4057: athrow         
        //  4058: aconst_null    
        //  4059: athrow         
        //  4060: aconst_null    
        //  4061: athrow         
        //  4062: aconst_null    
        //  4063: athrow         
        //  4064: aconst_null    
        //  4065: athrow         
        //  4066: aconst_null    
        //  4067: athrow         
        //  4068: aconst_null    
        //  4069: athrow         
        //  4070: aconst_null    
        //  4071: athrow         
        //  4072: aconst_null    
        //  4073: athrow         
        //  4074: aconst_null    
        //  4075: athrow         
        //  4076: aconst_null    
        //  4077: athrow         
        //  4078: aconst_null    
        //  4079: athrow         
        //  4080: aconst_null    
        //  4081: athrow         
        //  4082: aconst_null    
        //  4083: athrow         
        //  4084: aconst_null    
        //  4085: athrow         
        //  4086: aconst_null    
        //  4087: athrow         
        //  4088: aconst_null    
        //  4089: athrow         
        //  4090: aconst_null    
        //  4091: athrow         
        //  4092: aconst_null    
        //  4093: athrow         
        //  4094: aconst_null    
        //  4095: athrow         
        //  4096: aconst_null    
        //  4097: athrow         
        //  4098: pop            
        //  4099: goto            24
        //  4102: pop            
        //  4103: aconst_null    
        //  4104: goto            4098
        //  4107: dup            
        //  4108: ifnull          4098
        //  4111: checkcast       Ljava/lang/Throwable;
        //  4114: athrow         
        //  4115: dup            
        //  4116: ifnull          4102
        //  4119: checkcast       Ljava/lang/Throwable;
        //  4122: athrow         
        //  4123: aconst_null    
        //  4124: athrow         
        //    StackMapTable: 02 43 43 07 00 47 04 FF 00 0B 00 00 00 01 07 00 47 FD 00 03 07 00 03 07 00 49 45 07 00 47 40 07 00 49 45 07 00 47 40 07 00 4E 10 41 01 1E 4B 07 00 49 FF 00 01 00 02 07 00 03 07 00 49 00 02 07 00 49 01 5D 07 00 49 FF 00 02 00 00 00 01 07 00 47 FF 00 00 00 02 07 00 03 07 00 49 00 01 07 00 49 45 07 00 47 40 01 0D 41 01 1C FF 00 03 00 00 00 01 07 00 47 FF 00 00 00 02 07 00 03 07 00 49 00 01 07 00 49 45 07 00 47 40 07 01 DC 49 07 00 31 40 07 00 49 45 07 00 47 40 07 01 DC FF 00 0C 00 00 00 01 07 00 47 FF 00 00 00 02 07 00 03 07 00 49 00 04 07 01 DC 08 00 DE 08 00 DE 07 01 A3 45 07 00 47 FF 00 00 00 02 07 00 03 07 00 49 00 04 07 01 DC 08 00 DE 08 00 DE 07 01 A3 FF 00 02 00 00 00 01 07 00 47 FF 00 00 00 02 07 00 03 07 00 49 00 04 07 01 DC 08 00 DE 08 00 DE 07 01 A3 45 07 00 47 FF 00 00 00 02 07 00 03 07 00 49 00 02 07 01 DC 07 00 68 40 07 01 DC FC 00 0E 07 00 66 41 01 1B 4B 07 00 03 FF 00 01 00 03 07 00 03 07 00 49 07 00 66 00 02 07 00 03 01 5D 07 00 03 43 07 00 27 FF 00 00 00 03 07 00 03 07 00 49 07 00 66 00 02 07 00 03 07 00 66 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 66 00 02 07 00 03 01 51 07 00 87 FF 00 01 00 03 07 00 03 07 00 49 07 00 66 00 02 07 00 87 01 5B 07 00 87 4F 07 00 90 FF 00 01 00 03 07 00 03 07 00 49 07 00 66 00 02 07 00 90 01 5D 07 00 90 FF 00 02 00 00 00 01 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 66 00 01 07 00 90 45 07 00 47 40 01 02 04 41 01 1A 43 07 00 2B 40 07 00 49 45 07 00 47 00 FA 00 02 43 07 00 47 40 07 00 49 45 07 00 47 40 07 01 DC 51 07 00 49 FF 00 01 00 02 07 00 03 07 00 49 00 02 07 00 49 01 5C 07 00 49 42 07 00 47 40 07 00 49 45 07 00 47 40 07 01 DC 43 07 01 DC 44 07 01 DC FF 00 01 00 02 07 00 03 07 00 49 00 02 07 01 DC 01 59 07 01 DC FF 00 08 00 00 00 01 07 00 47 FF 00 00 00 02 07 00 03 07 00 49 00 04 07 01 DC 08 02 6C 08 02 6C 07 01 A3 45 07 00 47 FF 00 00 00 02 07 00 03 07 00 49 00 04 07 01 DC 08 02 6C 08 02 6C 07 01 A3 42 07 00 47 FF 00 00 00 02 07 00 03 07 00 49 00 04 07 01 DC 08 02 6C 08 02 6C 07 01 A3 45 07 00 47 FF 00 00 00 02 07 00 03 07 00 49 00 02 07 01 DC 07 00 68 40 07 01 DC FC 00 0E 07 00 9B 41 01 1D 4B 07 00 2B 40 07 00 90 45 07 00 47 40 01 4E 07 00 03 FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 00 03 01 5E 07 00 03 FF 00 15 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 CF 05 07 00 87 FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 00 CF 05 07 00 87 01 FF 00 1B 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 CF 05 07 00 87 FF 00 0F 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 CF 05 07 00 90 FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 00 CF 05 07 00 90 01 FF 00 1D 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 CF 05 07 00 90 42 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 CF 05 07 00 90 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 CF 05 07 00 C1 46 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 CF 05 07 00 C1 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 CF 05 07 00 C1 FF 00 0C 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 CF 05 07 00 C1 FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 00 CF 05 07 00 C1 01 FF 00 1E 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 CF 05 07 00 C1 FF 00 02 00 00 00 01 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 CF 05 07 00 C1 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 CF 05 07 00 C9 FF 00 05 00 00 00 01 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 00 CF 05 07 00 C9 03 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 CF 05 07 00 C9 42 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 CF 05 07 00 C9 45 07 00 47 40 07 01 DE FD 00 13 07 00 D5 01 41 01 1D 4B 07 00 D5 FF 00 01 00 05 07 00 03 07 00 49 07 00 9B 07 00 D5 01 00 02 07 00 D5 01 5D 07 00 D5 42 07 00 47 40 07 00 D5 47 07 00 47 40 01 02 04 41 01 18 03 40 01 02 04 41 01 18 F9 00 00 46 07 00 47 40 07 00 E8 45 07 00 47 40 07 01 E0 4D 07 00 ED FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 00 ED 01 5B 07 00 ED FF 00 0E 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 01 E1 07 00 ED FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 01 E1 07 00 ED 01 FF 00 1E 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 01 E1 07 00 ED 42 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 01 E1 07 00 ED 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 01 E1 01 20 03 FF 00 0C 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 00 03 07 00 03 FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 03 07 00 03 01 FF 00 1C 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 00 03 07 00 03 FC 00 15 01 42 01 1E FF 00 09 00 00 00 01 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 01 05 08 05 87 08 05 87 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 01 05 07 01 0B 45 07 00 2B FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 01 05 07 01 0B 07 01 A3 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 01 05 07 01 0B 07 01 A3 42 07 00 35 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 01 05 07 01 0B 07 01 A3 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 01 05 07 01 0B 46 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 01 05 07 01 0B 01 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 01 05 07 01 0B FF 00 0B 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 01 05 07 01 0B FF 00 02 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 01 05 07 01 0B 01 FF 00 1E 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 01 05 07 01 0B FF 00 02 00 00 00 01 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 01 05 07 01 0B 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 01 05 07 01 A3 FF 00 0B 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 01 05 07 01 A3 FF 00 02 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 01 05 07 01 A3 01 FF 00 1D 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 01 05 07 01 A3 FF 00 02 00 00 00 01 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 01 05 07 01 A3 45 07 00 47 00 FF 00 10 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 01 07 00 03 FF 00 02 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 01 07 00 03 01 FF 00 1C 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 01 07 00 03 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 01 07 01 2A 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 01 07 01 E0 FF 00 0E 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 01 07 01 2D FF 00 02 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 01 07 01 2D 01 FF 00 1F 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 01 07 01 2D FF 00 02 00 00 00 01 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 01 07 01 2D 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 01 01 02 05 42 01 18 03 FA 00 03 52 07 00 90 FF 00 02 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 00 90 01 5D 07 00 90 43 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 00 90 07 00 9B 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 00 90 03 FF 00 0B 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 00 90 03 FF 00 02 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 90 03 01 FF 00 1C 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 00 90 03 43 07 00 3F FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 90 03 07 00 9B 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 90 03 03 FF 00 0C 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 00 90 03 03 07 00 9B FF 00 02 00 03 07 00 03 07 00 49 07 00 9B 00 05 07 00 90 03 03 07 00 9B 01 FF 00 1F 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 00 90 03 03 07 00 9B 42 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 00 90 03 03 07 00 9B 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 00 90 03 03 03 FF 00 0B 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 00 90 03 03 03 FF 00 02 00 03 07 00 03 07 00 49 07 00 9B 00 05 07 00 90 03 03 03 01 FF 00 1D 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 00 90 03 03 03 42 07 00 2B FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 00 90 03 03 03 45 07 00 47 40 03 FF 00 06 00 00 00 01 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 02 03 07 01 2A 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 02 03 07 01 E0 FF 00 0E 00 03 07 00 03 07 00 49 07 00 9B 00 02 03 07 01 2D FF 00 02 00 03 07 00 03 07 00 49 07 00 9B 00 03 03 07 01 2D 01 FF 00 1F 00 03 07 00 03 07 00 49 07 00 9B 00 02 03 07 01 2D 42 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 02 03 07 01 2D 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 02 03 03 07 03 FF 00 0D 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 00 03 07 00 03 FF 00 02 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 03 07 00 03 01 FF 00 1F 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 00 03 07 00 03 FF 00 0F 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 03 01 01 FF 00 02 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 00 03 01 01 01 FF 00 1C 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 03 01 01 FF 00 0F 00 04 07 00 03 07 00 49 07 00 9B 01 00 01 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 01 05 08 08 85 08 08 85 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 01 05 07 01 0B FF 00 0E 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 01 05 07 01 0B 07 01 A3 FF 00 02 00 04 07 00 03 07 00 49 07 00 9B 01 00 04 07 01 05 07 01 0B 07 01 A3 01 FF 00 1D 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 01 05 07 01 0B 07 01 A3 FF 00 02 00 00 00 01 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 01 05 07 01 0B 07 01 A3 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 01 05 07 01 0B 07 01 A3 42 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 01 05 07 01 0B 07 01 A3 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 01 05 07 01 0B FF 00 0C 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 01 05 07 01 0B 07 00 03 FF 00 02 00 04 07 00 03 07 00 49 07 00 9B 01 00 04 07 01 05 07 01 0B 07 00 03 01 FF 00 1D 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 01 05 07 01 0B 07 00 03 FF 00 0E 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 01 05 07 01 0B 01 FF 00 02 00 04 07 00 03 07 00 49 07 00 9B 01 00 04 07 01 05 07 01 0B 01 01 FF 00 1D 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 01 05 07 01 0B 01 42 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 01 05 07 01 0B 01 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 01 05 07 01 0B 42 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 01 05 07 01 0B 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 01 05 07 01 A3 42 07 00 35 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 01 05 07 01 A3 45 07 00 47 00 FF 00 10 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 01 07 00 03 FF 00 02 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 01 07 00 03 01 FF 00 1E 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 01 07 00 03 45 07 00 2F FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 01 07 01 2A 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 01 07 01 E0 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 01 07 01 2D 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 01 01 4F 07 00 03 FF 00 02 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 00 03 01 5C 07 00 03 51 07 00 90 FF 00 02 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 00 90 01 5E 07 00 90 FF 00 03 00 00 00 01 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 00 90 07 00 9B 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 00 90 03 FF 00 0B 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 00 90 03 FF 00 02 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 00 90 03 01 FF 00 1C 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 00 90 03 FF 00 03 00 00 00 01 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 00 90 03 07 00 9B 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 00 90 03 03 FF 00 0C 00 04 07 00 03 07 00 49 07 00 9B 01 00 04 07 00 90 03 03 07 00 9B FF 00 02 00 04 07 00 03 07 00 49 07 00 9B 01 00 05 07 00 90 03 03 07 00 9B 01 FF 00 1F 00 04 07 00 03 07 00 49 07 00 9B 01 00 04 07 00 90 03 03 07 00 9B FF 00 02 00 00 00 01 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 04 07 00 90 03 03 07 00 9B 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 04 07 00 90 03 03 03 42 07 00 3D FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 04 07 00 90 03 03 03 45 07 00 47 40 03 46 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 03 07 01 2A 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 03 07 01 E0 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 03 07 01 2D 45 07 00 47 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 03 03 03 03 FA 00 03 46 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 02 08 0A BF 08 0A BF 45 07 00 47 40 07 01 78 40 01 46 07 00 47 40 07 00 49 45 07 00 47 00 02 48 07 00 47 40 07 01 85 45 07 00 47 40 07 01 E0 47 07 00 47 40 07 01 89 45 07 00 47 40 01 49 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 01 80 07 00 9B 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 01 80 03 FF 00 0B 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 01 80 03 FF 00 02 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 01 80 03 01 FF 00 1C 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 01 80 03 43 07 00 25 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 01 80 03 07 00 9B 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 01 80 03 03 FF 00 0B 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 01 80 03 03 FF 00 02 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 01 80 03 03 01 FF 00 1C 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 01 80 03 03 FF 00 0C 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 01 80 03 03 07 00 9B FF 00 02 00 03 07 00 03 07 00 49 07 00 9B 00 05 07 01 80 03 03 07 00 9B 01 FF 00 1F 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 01 80 03 03 07 00 9B 42 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 01 80 03 03 07 00 9B 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 01 80 03 03 03 42 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 01 80 03 03 03 45 07 00 47 00 4E 07 01 05 FF 00 02 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 01 05 01 5F 07 01 05 FF 00 0F 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 01 05 07 00 87 FF 00 02 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 01 05 07 00 87 01 FF 00 1C 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 01 05 07 00 87 FF 00 0F 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 01 05 07 00 90 07 00 9B FF 00 02 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 01 05 07 00 90 07 00 9B 01 FF 00 1C 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 01 05 07 00 90 07 00 9B 42 07 00 23 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 01 05 07 00 90 07 00 9B 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 01 05 07 00 90 03 43 07 00 2B FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 01 05 07 00 90 03 07 00 9B 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 01 05 07 00 90 03 03 FF 00 03 00 00 00 01 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 05 07 01 05 07 00 90 03 03 07 00 9B 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 05 07 01 05 07 00 90 03 03 03 FF 00 02 00 00 00 01 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 05 07 01 05 07 00 90 03 03 03 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 01 05 03 42 07 00 29 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 01 05 03 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 01 05 07 01 A3 FF 00 0B 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 01 05 07 01 A3 FF 00 02 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 01 05 07 01 A3 01 FF 00 1F 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 01 05 07 01 A3 42 07 00 35 FF 00 00 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 01 05 07 01 A3 45 07 00 47 00 FA 00 02 43 07 00 47 40 07 00 49 45 07 00 47 40 07 01 DC 51 07 00 35 40 07 00 90 45 07 00 47 40 01 02 05 42 01 1B 0B 42 01 1C 43 07 00 47 40 07 00 49 45 07 00 47 40 07 01 DC 4D 07 00 47 FF 00 00 00 02 07 00 03 07 00 49 00 04 07 01 DC 08 0D 50 08 0D 50 07 01 A3 45 07 00 47 FF 00 00 00 02 07 00 03 07 00 49 00 04 07 01 DC 08 0D 50 08 0D 50 07 01 A3 42 07 00 2B FF 00 00 00 02 07 00 03 07 00 49 00 04 07 01 DC 08 0D 50 08 0D 50 07 01 A3 45 07 00 47 FF 00 00 00 02 07 00 03 07 00 49 00 02 07 01 DC 07 00 68 40 07 01 DC 4E 07 01 AC FF 00 02 00 02 07 00 03 07 00 49 00 02 07 01 AC 01 5F 07 01 AC FF 00 0D 00 03 07 00 03 07 00 49 07 01 AC 00 01 07 01 AC FF 00 02 00 03 07 00 03 07 00 49 07 01 AC 00 02 07 01 AC 01 5E 07 01 AC FF 00 02 00 00 00 01 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 01 AC 00 01 07 01 AC 45 07 00 47 40 01 FF 00 0F 00 03 07 00 03 07 00 49 07 01 AC 00 02 01 07 00 87 FF 00 02 00 03 07 00 03 07 00 49 07 01 AC 00 03 01 07 00 87 01 FF 00 1D 00 03 07 00 03 07 00 49 07 01 AC 00 02 01 07 00 87 47 07 00 2B FF 00 00 00 03 07 00 03 07 00 49 07 01 AC 00 02 01 07 00 90 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 01 AC 00 02 01 07 00 C1 46 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 01 AC 00 02 01 07 00 C1 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 01 AC 00 02 01 07 00 C1 44 07 00 2F FF 00 00 00 03 07 00 03 07 00 49 07 01 AC 00 02 01 07 00 C1 45 07 00 47 FF 00 00 00 03 07 00 03 07 00 49 07 01 AC 00 02 01 01 46 07 00 47 40 07 01 AC 45 07 00 47 40 07 01 E1 FF 00 09 00 07 07 00 03 07 00 49 07 01 AC 00 01 07 01 E1 01 00 00 0B 42 01 1F 06 05 42 01 1B 50 01 FF 00 02 00 07 07 00 03 07 00 49 07 01 AC 00 01 07 01 E1 01 00 02 01 01 5F 01 FF 00 0D 00 07 07 00 03 07 00 49 07 01 AC 01 01 07 01 E1 01 00 01 01 FF 00 02 00 07 07 00 03 07 00 49 07 01 AC 01 01 07 01 E1 01 00 02 01 01 5E 01 FF 00 0F 00 07 07 00 03 07 00 49 07 01 AC 01 01 07 01 E1 01 00 02 01 07 00 87 FF 00 02 00 07 07 00 03 07 00 49 07 01 AC 01 01 07 01 E1 01 00 03 01 07 00 87 01 FF 00 1C 00 07 07 00 03 07 00 49 07 01 AC 01 01 07 01 E1 01 00 02 01 07 00 87 FF 00 10 00 07 07 00 03 07 00 49 07 01 AC 01 01 07 01 E1 01 00 02 01 07 00 90 FF 00 02 00 07 07 00 03 07 00 49 07 01 AC 01 01 07 01 E1 01 00 03 01 07 00 90 01 FF 00 1F 00 07 07 00 03 07 00 49 07 01 AC 01 01 07 01 E1 01 00 02 01 07 00 90 FF 00 02 00 00 00 01 07 00 47 FF 00 00 00 07 07 00 03 07 00 49 07 01 AC 01 01 07 01 E1 01 00 02 01 07 00 90 45 07 00 47 FF 00 00 00 07 07 00 03 07 00 49 07 01 AC 01 01 07 01 E1 01 00 02 01 01 46 07 00 47 40 07 00 49 45 07 00 47 00 00 FF 00 05 00 02 07 00 03 07 00 49 00 00 FF 00 00 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 01 05 07 01 0B 07 00 03 FF 00 01 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 01 05 07 01 A3 FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 01 80 03 03 FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 01 80 03 03 07 00 9B FA 00 01 FE 00 01 07 00 9B 07 00 D5 01 FF 00 01 00 07 07 00 03 07 00 49 07 01 AC 01 01 07 01 E1 01 00 02 01 07 00 87 FF 00 01 00 03 07 00 03 07 00 49 07 00 66 00 01 07 00 03 FF 00 01 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 01 05 07 01 0B 07 01 A3 FF 00 01 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 00 90 03 FF 00 01 00 03 07 00 03 07 00 49 07 01 AC 00 01 07 01 AC FF 00 01 00 04 07 00 03 07 00 49 07 00 9B 01 00 03 07 01 05 07 01 0B 01 FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 01 E1 07 00 ED FF 00 01 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 01 07 00 03 FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 03 01 01 FF 00 01 00 03 07 00 03 07 00 49 07 01 AC 00 02 01 07 00 87 FF 00 01 00 03 07 00 03 07 00 49 07 00 66 00 01 07 00 87 FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 01 05 07 00 90 07 00 9B FA 00 01 FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 01 05 07 00 87 FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 01 80 03 FF 00 01 00 07 07 00 03 07 00 49 07 01 AC 01 01 07 01 E1 01 00 01 01 FF 00 01 00 04 07 00 03 07 00 49 07 00 9B 01 00 01 07 00 90 FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 02 03 07 01 2D FF 00 01 00 07 07 00 03 07 00 49 07 01 AC 01 01 07 01 E1 01 00 02 01 07 00 90 FF 00 01 00 02 07 00 03 07 00 49 00 00 FF 00 01 00 07 07 00 03 07 00 49 07 01 AC 00 01 07 01 E1 01 00 00 FF 00 01 00 04 07 00 03 07 00 49 07 00 9B 01 00 01 07 00 03 FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 01 07 00 03 FF 00 01 00 02 07 00 03 07 00 49 00 01 07 00 49 FF 00 01 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 01 07 01 2D FF 00 01 00 03 07 00 03 07 00 49 07 00 66 00 00 FF 00 01 00 04 07 00 03 07 00 49 07 00 9B 01 00 00 FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 01 05 07 01 A3 FF 00 01 00 05 07 00 03 07 00 49 07 00 9B 07 00 D5 01 00 01 07 00 D5 FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 CF 05 07 00 90 FF 00 01 00 02 07 00 03 07 00 49 00 01 07 01 AC FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 00 90 03 FF 00 01 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 07 01 05 07 01 0B FF 00 01 00 04 07 00 03 07 00 49 07 00 9B 01 00 04 07 00 90 03 03 07 00 9B FF 00 01 00 04 07 00 03 07 00 49 07 00 9B 01 00 02 01 07 00 03 FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 CF 05 07 00 C1 41 07 00 90 FF 00 01 00 03 07 00 03 07 00 49 07 00 66 00 01 07 00 90 FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 01 07 01 05 FF 00 01 00 02 07 00 03 07 00 49 00 01 07 00 49 FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 03 07 00 CF 05 07 00 87 FF 00 01 00 07 07 00 03 07 00 49 07 01 AC 00 01 07 01 E1 01 00 01 01 FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 00 90 03 03 07 00 9B FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 04 07 00 90 03 03 03 01 FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 00 03 07 00 03 41 07 00 ED FF 00 01 00 03 07 00 03 07 00 49 07 00 9B 00 02 07 00 03 07 00 03 FF 00 01 00 02 07 00 03 07 00 49 00 01 07 00 2B 43 05 44 07 00 2B 47 05 47 07 00 47
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     4107   4115   Ljava/lang/EnumConstantNotPresentException;
        //  4107   4115   4107   4115   Ljava/util/NoSuchElementException;
        //  4123   4125   3      8      Ljava/lang/NumberFormatException;
        //  30     37     37     38     Any
        //  31     37     3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  31     37     3      8      Ljava/lang/RuntimeException;
        //  31     37     3      8      Any
        //  30     37     30     31     Any
        //  136    142    142    143    Any
        //  136    142    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  136    142    142    143    Ljava/util/ConcurrentModificationException;
        //  136    142    3      8      Ljava/util/NoSuchElementException;
        //  136    142    3      8      Any
        //  193    199    199    200    Any
        //  193    199    199    200    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  193    199    3      8      Any
        //  193    199    3      8      Ljava/util/NoSuchElementException;
        //  193    199    3      8      Any
        //  210    217    217    218    Any
        //  211    217    210    211    Ljava/lang/AssertionError;
        //  210    217    3      8      Any
        //  211    217    217    218    Ljava/lang/ClassCastException;
        //  211    217    3      8      Ljava/lang/IllegalStateException;
        //  232    238    238    239    Any
        //  232    238    3      8      Ljava/lang/ArithmeticException;
        //  232    238    238    239    Any
        //  232    238    238    239    Ljava/lang/NumberFormatException;
        //  232    238    3      8      Any
        //  243    249    249    250    Any
        //  243    249    3      8      Any
        //  243    249    249    250    Ljava/lang/ArithmeticException;
        //  243    249    3      8      Any
        //  243    249    249    250    Any
        //  344    351    351    352    Any
        //  345    351    344    345    Ljava/lang/NumberFormatException;
        //  344    351    3      8      Ljava/lang/ClassCastException;
        //  344    351    3      8      Any
        //  345    351    3      8      Ljava/lang/NumberFormatException;
        //  452    458    458    459    Any
        //  452    458    458    459    Ljava/lang/ArithmeticException;
        //  452    458    458    459    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  452    458    3      8      Ljava/lang/NumberFormatException;
        //  452    458    458    459    Any
        //  500    507    507    508    Any
        //  501    507    500    501    Ljava/lang/IllegalArgumentException;
        //  501    507    500    501    Ljava/lang/IndexOutOfBoundsException;
        //  500    507    3      8      Ljava/lang/NegativeArraySizeException;
        //  501    507    507    508    Any
        //  515    522    522    523    Any
        //  515    522    522    523    Any
        //  516    522    515    516    Any
        //  516    522    522    523    Any
        //  515    522    522    523    Ljava/util/NoSuchElementException;
        //  575    582    582    583    Any
        //  575    582    575    576    Any
        //  575    582    3      8      Ljava/lang/ArithmeticException;
        //  575    582    575    576    Any
        //  575    582    575    576    Ljava/lang/IllegalStateException;
        //  630    636    636    637    Any
        //  630    636    636    637    Ljava/util/ConcurrentModificationException;
        //  630    636    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  630    636    636    637    Any
        //  630    636    636    637    Any
        //  640    647    647    648    Any
        //  640    647    647    648    Ljava/lang/NegativeArraySizeException;
        //  641    647    3      8      Ljava/lang/IllegalArgumentException;
        //  640    647    640    641    Any
        //  641    647    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  708    715    715    716    Any
        //  708    715    715    716    Any
        //  709    715    708    709    Ljava/lang/RuntimeException;
        //  708    715    3      8      Ljava/lang/NegativeArraySizeException;
        //  708    715    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  867    874    874    875    Any
        //  868    874    3      8      Any
        //  868    874    867    868    Any
        //  868    874    3      8      Any
        //  867    874    3      8      Any
        //  882    889    889    890    Any
        //  882    889    882    883    Any
        //  883    889    889    890    Ljava/lang/IllegalStateException;
        //  882    889    889    890    Ljava/lang/NumberFormatException;
        //  883    889    889    890    Any
        //  940    946    946    947    Any
        //  940    946    3      8      Ljava/lang/IllegalArgumentException;
        //  940    946    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  940    946    946    947    Any
        //  940    946    946    947    Any
        //  954    960    960    961    Any
        //  954    960    960    961    Ljava/lang/EnumConstantNotPresentException;
        //  954    960    3      8      Any
        //  954    960    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  954    960    3      8      Any
        //  964    971    971    972    Any
        //  965    971    964    965    Any
        //  965    971    971    972    Any
        //  964    971    3      8      Ljava/lang/ClassCastException;
        //  965    971    3      8      Ljava/lang/ArithmeticException;
        //  1071   1080   1080   1081   Any
        //  1072   1080   1080   1081   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1072   1080   1080   1081   Ljava/lang/IllegalStateException;
        //  1072   1080   1071   1072   Any
        //  1071   1080   1071   1072   Any
        //  1164   1171   1171   1172   Any
        //  1165   1171   1164   1165   Ljava/lang/AssertionError;
        //  1164   1171   3      8      Any
        //  1165   1171   1171   1172   Any
        //  1164   1171   1164   1165   Ljava/lang/NullPointerException;
        //  1267   1274   1274   1275   Any
        //  1267   1274   1267   1268   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1267   1274   1267   1268   Any
        //  1267   1274   1274   1275   Any
        //  1267   1274   1274   1275   Any
        //  1423   1429   1429   1430   Any
        //  1423   1429   3      8      Any
        //  1423   1429   1429   1430   Any
        //  1423   1429   1429   1430   Ljava/lang/UnsupportedOperationException;
        //  1423   1429   3      8      Any
        //  1436   1443   1443   1444   Any
        //  1437   1443   3      8      Any
        //  1436   1443   1436   1437   Ljava/lang/IndexOutOfBoundsException;
        //  1436   1443   1443   1444   Ljava/lang/IndexOutOfBoundsException;
        //  1437   1443   1436   1437   Ljava/lang/RuntimeException;
        //  1447   1454   1454   1455   Any
        //  1448   1454   1454   1455   Ljava/lang/StringIndexOutOfBoundsException;
        //  1447   1454   3      8      Ljava/lang/IllegalStateException;
        //  1447   1454   3      8      Any
        //  1447   1454   1447   1448   Ljava/lang/IllegalStateException;
        //  1462   1469   1469   1470   Any
        //  1463   1469   1469   1470   Any
        //  1462   1469   1462   1463   Any
        //  1462   1469   3      8      Ljava/lang/NumberFormatException;
        //  1462   1469   3      8      Ljava/lang/ClassCastException;
        //  1520   1526   1526   1527   Any
        //  1520   1526   1526   1527   Ljava/lang/UnsupportedOperationException;
        //  1520   1526   1526   1527   Any
        //  1520   1526   1526   1527   Any
        //  1520   1526   1526   1527   Ljava/lang/ArithmeticException;
        //  1576   1582   1582   1583   Any
        //  1576   1582   3      8      Ljava/lang/UnsupportedOperationException;
        //  1576   1582   1582   1583   Ljava/lang/IllegalStateException;
        //  1576   1582   3      8      Any
        //  1576   1582   3      8      Ljava/lang/RuntimeException;
        //  1638   1645   1645   1646   Any
        //  1639   1645   1638   1639   Any
        //  1639   1645   3      8      Ljava/util/ConcurrentModificationException;
        //  1639   1645   1645   1646   Ljava/lang/NegativeArraySizeException;
        //  1638   1645   1645   1646   Ljava/lang/IndexOutOfBoundsException;
        //  1700   1706   1706   1707   Any
        //  1700   1706   3      8      Any
        //  1700   1706   1706   1707   Any
        //  1700   1706   1706   1707   Any
        //  1700   1706   3      8      Any
        //  1808   1815   1815   1816   Any
        //  1809   1815   3      8      Any
        //  1809   1815   1808   1809   Any
        //  1808   1815   3      8      Any
        //  1808   1815   1815   1816   Ljava/lang/IllegalStateException;
        //  1864   1871   1871   1872   Any
        //  1865   1871   3      8      Any
        //  1865   1871   3      8      Any
        //  1864   1871   3      8      Any
        //  1865   1871   1864   1865   Ljava/lang/NullPointerException;
        //  1923   1930   1930   1931   Any
        //  1924   1930   1923   1924   Any
        //  1923   1930   1923   1924   Any
        //  1923   1930   1923   1924   Any
        //  1924   1930   1930   1931   Any
        //  1979   1986   1986   1987   Any
        //  1979   1986   3      8      Ljava/lang/NullPointerException;
        //  1979   1986   3      8      Ljava/lang/IndexOutOfBoundsException;
        //  1979   1986   1979   1980   Ljava/util/ConcurrentModificationException;
        //  1979   1986   1979   1980   Ljava/lang/UnsupportedOperationException;
        //  1995   2001   2001   2002   Any
        //  1995   2001   3      8      Any
        //  1995   2001   2001   2002   Ljava/lang/IndexOutOfBoundsException;
        //  1995   2001   3      8      Ljava/lang/IllegalArgumentException;
        //  1995   2001   3      8      Ljava/lang/NumberFormatException;
        //  2055   2062   2062   2063   Any
        //  2056   2062   2055   2056   Any
        //  2055   2062   2055   2056   Ljava/lang/RuntimeException;
        //  2056   2062   2055   2056   Any
        //  2055   2062   2062   2063   Any
        //  2188   2195   2195   2196   Any
        //  2189   2195   2188   2189   Any
        //  2188   2195   2195   2196   Any
        //  2189   2195   3      8      Any
        //  2188   2195   2195   2196   Ljava/lang/IllegalStateException;
        //  2248   2254   2254   2255   Any
        //  2248   2254   3      8      Any
        //  2248   2254   3      8      Any
        //  2248   2254   3      8      Ljava/lang/ArithmeticException;
        //  2248   2254   3      8      Any
        //  2258   2265   2265   2266   Any
        //  2258   2265   2258   2259   Any
        //  2258   2265   2265   2266   Any
        //  2259   2265   2258   2259   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  2259   2265   2265   2266   Any
        //  2363   2370   2370   2371   Any
        //  2364   2370   3      8      Any
        //  2364   2370   2363   2364   Ljava/lang/IllegalArgumentException;
        //  2364   2370   2363   2364   Any
        //  2364   2370   3      8      Any
        //  2374   2381   2381   2382   Any
        //  2375   2381   2381   2382   Any
        //  2374   2381   2381   2382   Ljava/lang/NumberFormatException;
        //  2374   2381   3      8      Ljava/lang/ClassCastException;
        //  2375   2381   2374   2375   Any
        //  2385   2392   2392   2393   Any
        //  2386   2392   3      8      Any
        //  2386   2392   3      8      Any
        //  2386   2392   3      8      Any
        //  2386   2392   2385   2386   Ljava/lang/IllegalStateException;
        //  2450   2457   2457   2458   Any
        //  2451   2457   2457   2458   Ljava/lang/NegativeArraySizeException;
        //  2451   2457   2450   2451   Ljava/util/ConcurrentModificationException;
        //  2451   2457   2457   2458   Any
        //  2450   2457   2457   2458   Ljava/lang/NegativeArraySizeException;
        //  2464   2471   2471   2472   Any
        //  2465   2471   2471   2472   Any
        //  2465   2471   2471   2472   Ljava/lang/ClassCastException;
        //  2464   2471   2464   2465   Any
        //  2465   2471   2471   2472   Any
        //  2577   2583   2583   2584   Any
        //  2577   2583   2583   2584   Ljava/lang/IllegalArgumentException;
        //  2577   2583   2583   2584   Ljava/util/ConcurrentModificationException;
        //  2577   2583   2583   2584   Any
        //  2577   2583   2583   2584   Ljava/lang/IndexOutOfBoundsException;
        //  2633   2639   2639   2640   Any
        //  2633   2639   2639   2640   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  2633   2639   2639   2640   Ljava/util/NoSuchElementException;
        //  2633   2639   2639   2640   Any
        //  2633   2639   3      8      Ljava/lang/EnumConstantNotPresentException;
        //  2692   2698   2698   2699   Any
        //  2692   2698   2698   2699   Any
        //  2692   2698   3      8      Any
        //  2692   2698   3      8      Any
        //  2692   2698   2698   2699   Any
        //  2702   2709   2709   2710   Any
        //  2702   2709   2702   2703   Ljava/lang/NegativeArraySizeException;
        //  2703   2709   2709   2710   Any
        //  2703   2709   3      8      Any
        //  2703   2709   3      8      Any
        //  2717   2724   2724   2725   Any
        //  2717   2724   2724   2725   Ljava/util/NoSuchElementException;
        //  2717   2724   2724   2725   Any
        //  2717   2724   2717   2718   Ljava/lang/EnumConstantNotPresentException;
        //  2717   2724   2717   2718   Any
        //  2731   2738   2738   2739   Any
        //  2731   2738   2738   2739   Ljava/lang/NullPointerException;
        //  2731   2738   2738   2739   Ljava/lang/UnsupportedOperationException;
        //  2732   2738   2731   2732   Any
        //  2731   2738   2738   2739   Any
        //  2758   2765   2765   2766   Any
        //  2759   2765   2758   2759   Any
        //  2758   2765   3      8      Ljava/util/NoSuchElementException;
        //  2758   2765   2765   2766   Ljava/lang/NegativeArraySizeException;
        //  2759   2765   2765   2766   Ljava/lang/IndexOutOfBoundsException;
        //  2774   2781   2781   2782   Any
        //  2775   2781   3      8      Any
        //  2775   2781   2774   2775   Ljava/lang/AssertionError;
        //  2775   2781   2774   2775   Ljava/lang/NullPointerException;
        //  2774   2781   3      8      Any
        //  2794   2801   2801   2802   Any
        //  2794   2801   2794   2795   Any
        //  2794   2801   2801   2802   Any
        //  2795   2801   2794   2795   Ljava/lang/EnumConstantNotPresentException;
        //  2795   2801   2794   2795   Ljava/lang/StringIndexOutOfBoundsException;
        //  2810   2817   2817   2818   Any
        //  2811   2817   2817   2818   Ljava/lang/NumberFormatException;
        //  2811   2817   2810   2811   Any
        //  2810   2817   2817   2818   Any
        //  2810   2817   2810   2811   Any
        //  2828   2835   2835   2836   Any
        //  2828   2835   3      8      Ljava/lang/NegativeArraySizeException;
        //  2829   2835   2835   2836   Any
        //  2828   2835   3      8      Any
        //  2829   2835   2828   2829   Any
        //  2884   2891   2891   2892   Any
        //  2884   2891   3      8      Ljava/lang/ClassCastException;
        //  2884   2891   2891   2892   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  2885   2891   2884   2885   Ljava/util/NoSuchElementException;
        //  2884   2891   3      8      Any
        //  2987   2994   2994   2995   Any
        //  2987   2994   3      8      Any
        //  2987   2994   2994   2995   Any
        //  2988   2994   2994   2995   Ljava/util/NoSuchElementException;
        //  2988   2994   2987   2988   Any
        //  2998   3005   3005   3006   Any
        //  2998   3005   2998   2999   Any
        //  2998   3005   3005   3006   Any
        //  2999   3005   3      8      Any
        //  2998   3005   3      8      Any
        //  3155   3162   3162   3163   Any
        //  3155   3162   3155   3156   Ljava/lang/EnumConstantNotPresentException;
        //  3155   3162   3      8      Ljava/lang/IllegalArgumentException;
        //  3155   3162   3      8      Any
        //  3156   3162   3162   3163   Any
        //  3167   3174   3174   3175   Any
        //  3168   3174   3167   3168   Ljava/lang/ArithmeticException;
        //  3167   3174   3174   3175   Ljava/lang/NegativeArraySizeException;
        //  3167   3174   3167   3168   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  3167   3174   3174   3175   Ljava/lang/NullPointerException;
        //  3180   3186   3186   3187   Any
        //  3180   3186   3186   3187   Ljava/lang/NumberFormatException;
        //  3180   3186   3186   3187   Ljava/lang/EnumConstantNotPresentException;
        //  3180   3186   3186   3187   Any
        //  3180   3186   3      8      Ljava/util/NoSuchElementException;
        //  3191   3197   3197   3198   Any
        //  3191   3197   3197   3198   Any
        //  3191   3197   3      8      Ljava/lang/RuntimeException;
        //  3191   3197   3197   3198   Ljava/lang/UnsupportedOperationException;
        //  3191   3197   3      8      Any
        //  3201   3208   3208   3209   Any
        //  3202   3208   3208   3209   Ljava/lang/EnumConstantNotPresentException;
        //  3202   3208   3201   3202   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  3201   3208   3208   3209   Any
        //  3201   3208   3208   3209   Ljava/lang/IllegalStateException;
        //  3259   3266   3266   3267   Any
        //  3260   3266   3      8      Ljava/lang/EnumConstantNotPresentException;
        //  3259   3266   3      8      Any
        //  3259   3266   3      8      Any
        //  3260   3266   3259   3260   Ljava/lang/IllegalStateException;
        //  3274   3281   3281   3282   Any
        //  3275   3281   3274   3275   Ljava/util/NoSuchElementException;
        //  3275   3281   3274   3275   Any
        //  3275   3281   3      8      Ljava/util/ConcurrentModificationException;
        //  3274   3281   3274   3275   Any
        //  3300   3307   3307   3308   Any
        //  3301   3307   3      8      Any
        //  3301   3307   3300   3301   Ljava/lang/IllegalStateException;
        //  3300   3307   3      8      Any
        //  3301   3307   3307   3308   Ljava/lang/NullPointerException;
        //  3396   3403   3403   3404   Any
        //  3396   3403   3396   3397   Ljava/lang/IllegalArgumentException;
        //  3396   3403   3396   3397   Any
        //  3396   3403   3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  3396   3403   3403   3404   Ljava/lang/NumberFormatException;
        //  3418   3425   3425   3426   Any
        //  3419   3425   3418   3419   Any
        //  3419   3425   3418   3419   Any
        //  3418   3425   3425   3426   Any
        //  3418   3425   3425   3426   Any
        //  3429   3436   3436   3437   Any
        //  3430   3436   3      8      Ljava/lang/RuntimeException;
        //  3429   3436   3429   3430   Ljava/lang/ArithmeticException;
        //  3430   3436   3      8      Any
        //  3429   3436   3429   3430   Ljava/lang/IndexOutOfBoundsException;
        //  3540   3546   3546   3547   Any
        //  3540   3546   3      8      Ljava/util/ConcurrentModificationException;
        //  3540   3546   3      8      Any
        //  3540   3546   3546   3547   Ljava/lang/ArithmeticException;
        //  3540   3546   3      8      Ljava/util/ConcurrentModificationException;
        //  3604   3611   3611   3612   Any
        //  3605   3611   3      8      Ljava/lang/RuntimeException;
        //  3605   3611   3604   3605   Ljava/lang/IllegalArgumentException;
        //  3604   3611   3604   3605   Ljava/lang/IllegalStateException;
        //  3605   3611   3604   3605   Ljava/lang/UnsupportedOperationException;
        //  3619   3626   3626   3627   Any
        //  3619   3626   3      8      Any
        //  3620   3626   3      8      Any
        //  3619   3626   3619   3620   Any
        //  3620   3626   3626   3627   Any
        //  3632   3639   3639   3640   Any
        //  3632   3639   3      8      Any
        //  3633   3639   3639   3640   Any
        //  3632   3639   3639   3640   Any
        //  3632   3639   3632   3633   Ljava/util/ConcurrentModificationException;
        //  3647   3654   3654   3655   Any
        //  3648   3654   3647   3648   Any
        //  3647   3654   3647   3648   Ljava/lang/EnumConstantNotPresentException;
        //  3647   3654   3647   3648   Any
        //  3648   3654   3654   3655   Any
        //  3960   3966   3966   3967   Any
        //  3960   3966   3966   3967   Ljava/lang/ClassCastException;
        //  3960   3966   3966   3967   Ljava/lang/RuntimeException;
        //  3960   3966   3966   3967   Any
        //  3960   3966   3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  3974   3981   3981   3982   Any
        //  3974   3981   3974   3975   Any
        //  3974   3981   3981   3982   Ljava/lang/NumberFormatException;
        //  3974   3981   3981   3982   Ljava/lang/ClassCastException;
        //  3974   3981   3      8      Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:577)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @f0g
    @LauncherEventHide
    public void c(@NotNull final f4t p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          1140
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            1132
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            1124
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: aload_0        
        //    27: getstatic       dev/nuker/pyro/fc.1:I
        //    30: ifne            39
        //    33: ldc_w           -1870759837
        //    36: goto            42
        //    39: ldc_w           1924078874
        //    42: ldc_w           232664419
        //    45: ixor           
        //    46: lookupswitch {
        //          -1650436864: 1087
        //          559936504: 39
        //          default: 72
        //        }
        //    72: getfield        dev/nuker/pyro/f9e.c:J
        //    75: sipush          1000
        //    78: i2l            
        //    79: ladd           
        //    80: goto            84
        //    83: athrow         
        //    84: invokestatic    java/lang/System.currentTimeMillis:()J
        //    87: goto            91
        //    90: athrow         
        //    91: lcmp           
        //    92: ifge            425
        //    95: getstatic       dev/nuker/pyro/fc.1:I
        //    98: ifne            107
        //   101: ldc_w           144999754
        //   104: goto            110
        //   107: ldc_w           1209185699
        //   110: ldc_w           1729182567
        //   113: ixor           
        //   114: lookupswitch {
        //          -1590485247: 107
        //          1874181677: 1101
        //          default: 140
        //        }
        //   140: aload_0        
        //   141: getstatic       dev/nuker/pyro/fc.0:I
        //   144: ifgt            153
        //   147: ldc_w           -2048909944
        //   150: goto            156
        //   153: ldc_w           1771216564
        //   156: ldc_w           -110040959
        //   159: ixor           
        //   160: lookupswitch {
        //          -1864206795: 188
        //          2089874697: 153
        //          default: 1093
        //        }
        //   188: goto            192
        //   191: athrow         
        //   192: invokestatic    java/lang/System.currentTimeMillis:()J
        //   195: goto            199
        //   198: athrow         
        //   199: putfield        dev/nuker/pyro/f9e.c:J
        //   202: getstatic       dev/nuker/pyro/fc.1:I
        //   205: ifne            214
        //   208: ldc_w           1484420330
        //   211: goto            217
        //   214: ldc_w           810270132
        //   217: ldc_w           -1574540708
        //   220: ixor           
        //   221: lookupswitch {
        //          -1838295064: 248
        //          -94626122: 214
        //          default: 1107
        //        }
        //   248: aload_0        
        //   249: dup            
        //   250: getstatic       dev/nuker/pyro/fc.0:I
        //   253: ifgt            262
        //   256: ldc_w           -1337428085
        //   259: goto            265
        //   262: ldc_w           -510914833
        //   265: ldc_w           -1853674924
        //   268: ixor           
        //   269: lookupswitch {
        //          -831335933: 262
        //          566975967: 1103
        //          default: 296
        //        }
        //   296: getfield        dev/nuker/pyro/f9e.3:I
        //   299: aload_0        
        //   300: getfield        dev/nuker/pyro/f9e.c:Ldev/nuker/pyro/f0p;
        //   303: getstatic       dev/nuker/pyro/fc.1:I
        //   306: ifne            315
        //   309: ldc_w           2065784041
        //   312: goto            318
        //   315: ldc_w           1746822585
        //   318: ldc_w           -1242925573
        //   321: ixor           
        //   322: lookupswitch {
        //          -825546478: 315
        //          -571207614: 348
        //          default: 1109
        //        }
        //   348: goto            352
        //   351: athrow         
        //   352: invokevirtual   dev/nuker/pyro/f0p.c:()Ljava/lang/Object;
        //   355: goto            359
        //   358: athrow         
        //   359: checkcast       Ljava/lang/Number;
        //   362: goto            366
        //   365: athrow         
        //   366: invokevirtual   java/lang/Number.intValue:()I
        //   369: goto            373
        //   372: athrow         
        //   373: isub           
        //   374: putfield        dev/nuker/pyro/f9e.3:I
        //   377: aload_0        
        //   378: getfield        dev/nuker/pyro/f9e.3:I
        //   381: ifge            390
        //   384: ldc_w           1105867791
        //   387: goto            393
        //   390: ldc_w           1105867790
        //   393: ldc_w           1058443103
        //   396: ixor           
        //   397: tableswitch {
        //          -33982816: 420
        //          -33982815: 425
        //          default: 384
        //        }
        //   420: aload_0        
        //   421: iconst_0       
        //   422: putfield        dev/nuker/pyro/f9e.3:I
        //   425: aload_0        
        //   426: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //   429: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   432: dup            
        //   433: pop            
        //   434: goto            438
        //   437: athrow         
        //   438: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_184218_aH:()Z
        //   441: goto            445
        //   444: athrow         
        //   445: ifeq            1084
        //   448: aload_0        
        //   449: getfield        dev/nuker/pyro/f9e.2:I
        //   452: ifle            1084
        //   455: aload_0        
        //   456: getfield        dev/nuker/pyro/f9e.c:Ldev/nuker/pyro/f0k;
        //   459: getstatic       dev/nuker/pyro/fc.1:I
        //   462: ifne            471
        //   465: ldc_w           -125962726
        //   468: goto            474
        //   471: ldc_w           287187439
        //   474: ldc_w           -1010208851
        //   477: ixor           
        //   478: lookupswitch {
        //          -1787139675: 471
        //          1001691575: 1113
        //          default: 504
        //        }
        //   504: goto            508
        //   507: athrow         
        //   508: invokevirtual   dev/nuker/pyro/f0k.c:()Ljava/lang/Object;
        //   511: goto            515
        //   514: athrow         
        //   515: checkcast       Ljava/lang/Boolean;
        //   518: goto            522
        //   521: athrow         
        //   522: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   525: goto            529
        //   528: athrow         
        //   529: ifeq            1084
        //   532: aload_0        
        //   533: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //   536: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   539: getstatic       dev/nuker/pyro/fc.0:I
        //   542: ifgt            551
        //   545: ldc_w           280019283
        //   548: goto            554
        //   551: ldc_w           777478743
        //   554: ldc_w           -2026370252
        //   557: ixor           
        //   558: lookupswitch {
        //          -1752642969: 551
        //          -1452316317: 584
        //          default: 1111
        //        }
        //   584: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70173_aa:I
        //   587: iconst_2       
        //   588: irem           
        //   589: ifne            1084
        //   592: aload_0        
        //   593: getstatic       dev/nuker/pyro/fc.1:I
        //   596: ifne            605
        //   599: ldc_w           822049653
        //   602: goto            608
        //   605: ldc_w           2117166250
        //   608: ldc_w           -2129460168
        //   611: ixor           
        //   612: lookupswitch {
        //          -1309900979: 605
        //          -14524270: 640
        //          default: 1091
        //        }
        //   640: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //   643: dup            
        //   644: pop            
        //   645: goto            649
        //   648: athrow         
        //   649: invokevirtual   net/minecraft/client/Minecraft.func_147114_u:()Lnet/minecraft/client/network/NetHandlerPlayClient;
        //   652: goto            656
        //   655: athrow         
        //   656: dup            
        //   657: ifnonnull       715
        //   660: getstatic       dev/nuker/pyro/fc.0:I
        //   663: ifgt            672
        //   666: ldc_w           -293492348
        //   669: goto            675
        //   672: ldc_w           792404910
        //   675: ldc_w           -586227301
        //   678: ixor           
        //   679: lookupswitch {
        //          -231357899: 704
        //          865028127: 672
        //          default: 1097
        //        }
        //   704: goto            708
        //   707: athrow         
        //   708: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //   711: goto            715
        //   714: athrow         
        //   715: new             Lnet/minecraft/network/play/client/CPacketUseEntity;
        //   718: dup            
        //   719: aload_0        
        //   720: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //   723: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   726: dup            
        //   727: pop            
        //   728: getstatic       dev/nuker/pyro/fc.1:I
        //   731: ifne            740
        //   734: ldc_w           -1444878150
        //   737: goto            743
        //   740: ldc_w           1327793270
        //   743: ldc_w           1529476136
        //   746: ixor           
        //   747: lookupswitch {
        //          -221700974: 740
        //          336425054: 772
        //          default: 1099
        //        }
        //   772: goto            776
        //   775: athrow         
        //   776: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_184187_bx:()Lnet/minecraft/entity/Entity;
        //   779: goto            783
        //   782: athrow         
        //   783: dup            
        //   784: ifnonnull       798
        //   787: goto            791
        //   790: athrow         
        //   791: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //   794: goto            798
        //   797: athrow         
        //   798: getstatic       net/minecraft/util/EnumHand.OFF_HAND:Lnet/minecraft/util/EnumHand;
        //   801: getstatic       dev/nuker/pyro/fc.1:I
        //   804: ifne            813
        //   807: ldc_w           1262741054
        //   810: goto            816
        //   813: ldc_w           -482103109
        //   816: ldc_w           -241581105
        //   819: ixor           
        //   820: lookupswitch {
        //          -1160108559: 1089
        //          -289368013: 813
        //          default: 848
        //        }
        //   848: goto            852
        //   851: athrow         
        //   852: invokespecial   net/minecraft/network/play/client/CPacketUseEntity.<init>:(Lnet/minecraft/entity/Entity;Lnet/minecraft/util/EnumHand;)V
        //   855: goto            859
        //   858: athrow         
        //   859: checkcast       Lnet/minecraft/network/Packet;
        //   862: getstatic       dev/nuker/pyro/fc.0:I
        //   865: ifgt            874
        //   868: ldc_w           1815224713
        //   871: goto            877
        //   874: ldc_w           -219349235
        //   877: ldc_w           527103201
        //   880: ixor           
        //   881: lookupswitch {
        //          1572218048: 874
        //          1935201640: 1085
        //          default: 908
        //        }
        //   908: goto            912
        //   911: athrow         
        //   912: invokevirtual   net/minecraft/client/network/NetHandlerPlayClient.func_147297_a:(Lnet/minecraft/network/Packet;)V
        //   915: goto            919
        //   918: athrow         
        //   919: aload_0        
        //   920: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //   923: dup            
        //   924: pop            
        //   925: goto            929
        //   928: athrow         
        //   929: invokevirtual   net/minecraft/client/Minecraft.func_147114_u:()Lnet/minecraft/client/network/NetHandlerPlayClient;
        //   932: goto            936
        //   935: athrow         
        //   936: dup            
        //   937: ifnonnull       951
        //   940: goto            944
        //   943: athrow         
        //   944: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //   947: goto            951
        //   950: athrow         
        //   951: new             Lnet/minecraft/network/play/client/CPacketConfirmTeleport;
        //   954: dup            
        //   955: getstatic       dev/nuker/pyro/fc.1:I
        //   958: ifne            967
        //   961: ldc_w           -541798350
        //   964: goto            970
        //   967: ldc_w           -332530660
        //   970: ldc_w           -944381636
        //   973: ixor           
        //   974: lookupswitch {
        //          402731278: 1105
        //          687765102: 967
        //          default: 1000
        //        }
        //  1000: aload_0        
        //  1001: dup            
        //  1002: getstatic       dev/nuker/pyro/fc.c:I
        //  1005: ifne            1014
        //  1008: ldc_w           1693528205
        //  1011: goto            1017
        //  1014: ldc_w           -1882559173
        //  1017: ldc_w           370813863
        //  1020: ixor           
        //  1021: lookupswitch {
        //          -1714403684: 1048
        //          1928010538: 1014
        //          default: 1095
        //        }
        //  1048: getfield        dev/nuker/pyro/f9e.2:I
        //  1051: dup            
        //  1052: istore_2       
        //  1053: iconst_1       
        //  1054: iadd           
        //  1055: putfield        dev/nuker/pyro/f9e.2:I
        //  1058: iload_2        
        //  1059: goto            1063
        //  1062: athrow         
        //  1063: invokespecial   net/minecraft/network/play/client/CPacketConfirmTeleport.<init>:(I)V
        //  1066: goto            1070
        //  1069: athrow         
        //  1070: checkcast       Lnet/minecraft/network/Packet;
        //  1073: goto            1077
        //  1076: athrow         
        //  1077: invokevirtual   net/minecraft/client/network/NetHandlerPlayClient.func_147297_a:(Lnet/minecraft/network/Packet;)V
        //  1080: goto            1084
        //  1083: athrow         
        //  1084: return         
        //  1085: aconst_null    
        //  1086: athrow         
        //  1087: aconst_null    
        //  1088: athrow         
        //  1089: aconst_null    
        //  1090: athrow         
        //  1091: aconst_null    
        //  1092: athrow         
        //  1093: aconst_null    
        //  1094: athrow         
        //  1095: aconst_null    
        //  1096: athrow         
        //  1097: aconst_null    
        //  1098: athrow         
        //  1099: aconst_null    
        //  1100: athrow         
        //  1101: aconst_null    
        //  1102: athrow         
        //  1103: aconst_null    
        //  1104: athrow         
        //  1105: aconst_null    
        //  1106: athrow         
        //  1107: aconst_null    
        //  1108: athrow         
        //  1109: aconst_null    
        //  1110: athrow         
        //  1111: aconst_null    
        //  1112: athrow         
        //  1113: aconst_null    
        //  1114: athrow         
        //  1115: pop            
        //  1116: goto            24
        //  1119: pop            
        //  1120: aconst_null    
        //  1121: goto            1115
        //  1124: dup            
        //  1125: ifnull          1115
        //  1128: checkcast       Ljava/lang/Throwable;
        //  1131: athrow         
        //  1132: dup            
        //  1133: ifnull          1119
        //  1136: checkcast       Ljava/lang/Throwable;
        //  1139: athrow         
        //  1140: aconst_null    
        //  1141: athrow         
        //    StackMapTable: 00 8E 43 07 00 47 04 FF 00 0B 00 00 00 01 07 00 47 FD 00 03 07 00 03 07 02 3E 4E 07 00 03 FF 00 02 00 02 07 00 03 07 02 3E 00 02 07 00 03 01 5D 07 00 03 4A 07 00 47 40 04 45 07 00 47 FF 00 00 00 02 07 00 03 07 02 3E 00 02 04 04 0F 42 01 1D 4C 07 00 03 FF 00 02 00 02 07 00 03 07 02 3E 00 02 07 00 03 01 5F 07 00 03 42 07 00 47 40 07 00 03 45 07 00 47 FF 00 00 00 02 07 00 03 07 02 3E 00 02 07 00 03 04 0E 42 01 1E FF 00 0D 00 02 07 00 03 07 02 3E 00 02 07 00 03 07 00 03 FF 00 02 00 02 07 00 03 07 02 3E 00 03 07 00 03 07 00 03 01 FF 00 1E 00 02 07 00 03 07 02 3E 00 02 07 00 03 07 00 03 FF 00 12 00 02 07 00 03 07 02 3E 00 03 07 00 03 01 07 01 2A FF 00 02 00 02 07 00 03 07 02 3E 00 04 07 00 03 01 07 01 2A 01 FF 00 1D 00 02 07 00 03 07 02 3E 00 03 07 00 03 01 07 01 2A 42 07 00 47 FF 00 00 00 02 07 00 03 07 02 3E 00 03 07 00 03 01 07 01 2A 45 07 00 47 FF 00 00 00 02 07 00 03 07 02 3E 00 03 07 00 03 01 07 01 E0 FF 00 05 00 00 00 01 07 00 47 FF 00 00 00 02 07 00 03 07 02 3E 00 03 07 00 03 01 07 01 2D 45 07 00 47 FF 00 00 00 02 07 00 03 07 02 3E 00 03 07 00 03 01 01 0A 05 42 01 1A 04 4B 07 00 47 40 07 00 90 45 07 00 47 40 01 59 07 02 06 FF 00 02 00 02 07 00 03 07 02 3E 00 02 07 02 06 01 5D 07 02 06 FF 00 02 00 00 00 01 07 00 47 FF 00 00 00 02 07 00 03 07 02 3E 00 01 07 02 06 45 07 00 47 40 07 01 E0 FF 00 05 00 00 00 01 07 00 47 FF 00 00 00 02 07 00 03 07 02 3E 00 01 07 01 89 45 07 00 47 40 01 55 07 00 90 FF 00 02 00 02 07 00 03 07 02 3E 00 02 07 00 90 01 5D 07 00 90 54 07 00 03 FF 00 02 00 02 07 00 03 07 02 3E 00 02 07 00 03 01 5F 07 00 03 47 07 00 47 40 07 00 87 45 07 00 47 40 07 02 2D 4F 07 02 2D FF 00 02 00 02 07 00 03 07 02 3E 00 02 07 02 2D 01 5C 07 02 2D 42 07 00 2B 40 07 02 2D 45 07 00 47 40 07 02 2D FF 00 18 00 02 07 00 03 07 02 3E 00 04 07 02 2D 08 02 CB 08 02 CB 07 00 90 FF 00 02 00 02 07 00 03 07 02 3E 00 05 07 02 2D 08 02 CB 08 02 CB 07 00 90 01 FF 00 1C 00 02 07 00 03 07 02 3E 00 04 07 02 2D 08 02 CB 08 02 CB 07 00 90 FF 00 02 00 00 00 01 07 00 47 FF 00 00 00 02 07 00 03 07 02 3E 00 04 07 02 2D 08 02 CB 08 02 CB 07 00 90 45 07 00 47 FF 00 00 00 02 07 00 03 07 02 3E 00 04 07 02 2D 08 02 CB 08 02 CB 07 00 C1 46 07 00 47 FF 00 00 00 02 07 00 03 07 02 3E 00 04 07 02 2D 08 02 CB 08 02 CB 07 00 C1 45 07 00 47 FF 00 00 00 02 07 00 03 07 02 3E 00 04 07 02 2D 08 02 CB 08 02 CB 07 00 C1 FF 00 0E 00 02 07 00 03 07 02 3E 00 05 07 02 2D 08 02 CB 08 02 CB 07 00 C1 07 02 1E FF 00 02 00 02 07 00 03 07 02 3E 00 06 07 02 2D 08 02 CB 08 02 CB 07 00 C1 07 02 1E 01 FF 00 1F 00 02 07 00 03 07 02 3E 00 05 07 02 2D 08 02 CB 08 02 CB 07 00 C1 07 02 1E 42 07 00 37 FF 00 00 00 02 07 00 03 07 02 3E 00 05 07 02 2D 08 02 CB 08 02 CB 07 00 C1 07 02 1E 45 07 00 47 FF 00 00 00 02 07 00 03 07 02 3E 00 02 07 02 2D 07 02 19 FF 00 0E 00 02 07 00 03 07 02 3E 00 02 07 02 2D 07 01 DC FF 00 02 00 02 07 00 03 07 02 3E 00 03 07 02 2D 07 01 DC 01 FF 00 1E 00 02 07 00 03 07 02 3E 00 02 07 02 2D 07 01 DC 42 07 00 27 FF 00 00 00 02 07 00 03 07 02 3E 00 02 07 02 2D 07 01 DC 45 07 00 47 00 48 07 00 47 40 07 00 87 45 07 00 47 40 07 02 2D 46 07 00 47 40 07 02 2D 45 07 00 47 40 07 02 2D FF 00 0F 00 02 07 00 03 07 02 3E 00 03 07 02 2D 08 03 B7 08 03 B7 FF 00 02 00 02 07 00 03 07 02 3E 00 04 07 02 2D 08 03 B7 08 03 B7 01 FF 00 1D 00 02 07 00 03 07 02 3E 00 03 07 02 2D 08 03 B7 08 03 B7 FF 00 0D 00 02 07 00 03 07 02 3E 00 05 07 02 2D 08 03 B7 08 03 B7 07 00 03 07 00 03 FF 00 02 00 02 07 00 03 07 02 3E 00 06 07 02 2D 08 03 B7 08 03 B7 07 00 03 07 00 03 01 FF 00 1E 00 02 07 00 03 07 02 3E 00 05 07 02 2D 08 03 B7 08 03 B7 07 00 03 07 00 03 FF 00 0D 00 03 07 00 03 07 02 3E 01 00 01 07 00 47 FF 00 00 00 03 07 00 03 07 02 3E 01 00 04 07 02 2D 08 03 B7 08 03 B7 01 45 07 00 47 FF 00 00 00 03 07 00 03 07 02 3E 01 00 02 07 02 2D 07 02 33 FF 00 05 00 00 00 01 07 00 47 FF 00 00 00 03 07 00 03 07 02 3E 01 00 02 07 02 2D 07 01 DC 45 07 00 47 FA 00 00 FF 00 00 00 02 07 00 03 07 02 3E 00 02 07 02 2D 07 01 DC 41 07 00 03 FF 00 01 00 02 07 00 03 07 02 3E 00 05 07 02 2D 08 02 CB 08 02 CB 07 00 C1 07 02 1E 41 07 00 03 41 07 00 03 FF 00 01 00 02 07 00 03 07 02 3E 00 05 07 02 2D 08 03 B7 08 03 B7 07 00 03 07 00 03 41 07 02 2D FF 00 01 00 02 07 00 03 07 02 3E 00 04 07 02 2D 08 02 CB 08 02 CB 07 00 90 01 FF 00 01 00 02 07 00 03 07 02 3E 00 02 07 00 03 07 00 03 FF 00 01 00 02 07 00 03 07 02 3E 00 03 07 02 2D 08 03 B7 08 03 B7 01 FF 00 01 00 02 07 00 03 07 02 3E 00 03 07 00 03 01 07 01 2A 41 07 00 90 41 07 02 06 41 07 00 47 43 05 44 07 00 47 47 05 47 07 00 47
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     1124   1132   Any
        //  1124   1132   1124   1132   Any
        //  1140   1142   3      8      Ljava/lang/AssertionError;
        //  83     90     90     91     Any
        //  83     90     90     91     Ljava/lang/ArrayIndexOutOfBoundsException;
        //  83     90     90     91     Any
        //  84     90     3      8      Any
        //  83     90     83     84     Any
        //  191    198    198    199    Any
        //  192    198    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  192    198    191    192    Any
        //  192    198    191    192    Ljava/lang/ArithmeticException;
        //  192    198    3      8      Any
        //  351    358    358    359    Any
        //  351    358    358    359    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  351    358    358    359    Ljava/lang/RuntimeException;
        //  351    358    358    359    Any
        //  352    358    351    352    Any
        //  366    372    372    373    Any
        //  366    372    372    373    Any
        //  366    372    372    373    Ljava/lang/RuntimeException;
        //  366    372    372    373    Any
        //  366    372    372    373    Any
        //  437    444    444    445    Any
        //  437    444    3      8      Ljava/lang/AssertionError;
        //  438    444    444    445    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  438    444    437    438    Any
        //  437    444    3      8      Any
        //  508    514    514    515    Any
        //  508    514    514    515    Ljava/lang/RuntimeException;
        //  508    514    3      8      Any
        //  508    514    514    515    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  508    514    514    515    Ljava/lang/ClassCastException;
        //  522    528    528    529    Any
        //  522    528    528    529    Ljava/lang/ArithmeticException;
        //  522    528    528    529    Ljava/lang/StringIndexOutOfBoundsException;
        //  522    528    3      8      Ljava/lang/UnsupportedOperationException;
        //  522    528    3      8      Ljava/lang/IllegalArgumentException;
        //  648    655    655    656    Any
        //  649    655    648    649    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  648    655    3      8      Any
        //  649    655    648    649    Any
        //  648    655    648    649    Any
        //  707    714    714    715    Any
        //  708    714    707    708    Ljava/lang/IndexOutOfBoundsException;
        //  708    714    707    708    Ljava/lang/IllegalArgumentException;
        //  708    714    707    708    Ljava/lang/NullPointerException;
        //  707    714    3      8      Ljava/lang/UnsupportedOperationException;
        //  776    782    782    783    Any
        //  776    782    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  776    782    782    783    Ljava/lang/StringIndexOutOfBoundsException;
        //  776    782    3      8      Ljava/lang/IllegalArgumentException;
        //  776    782    782    783    Any
        //  790    797    797    798    Any
        //  791    797    790    791    Any
        //  791    797    3      8      Any
        //  791    797    797    798    Any
        //  791    797    3      8      Any
        //  851    858    858    859    Any
        //  851    858    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  851    858    858    859    Any
        //  851    858    851    852    Ljava/lang/ArithmeticException;
        //  851    858    858    859    Ljava/lang/AssertionError;
        //  911    918    918    919    Any
        //  912    918    918    919    Ljava/lang/NullPointerException;
        //  912    918    911    912    Ljava/lang/NumberFormatException;
        //  912    918    3      8      Ljava/lang/NumberFormatException;
        //  912    918    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  928    935    935    936    Any
        //  928    935    3      8      Any
        //  929    935    928    929    Ljava/lang/ClassCastException;
        //  928    935    928    929    Any
        //  928    935    928    929    Ljava/lang/NegativeArraySizeException;
        //  943    950    950    951    Any
        //  944    950    943    944    Any
        //  943    950    950    951    Any
        //  943    950    950    951    Ljava/lang/AssertionError;
        //  944    950    3      8      Ljava/lang/ArithmeticException;
        //  1062   1069   1069   1070   Any
        //  1062   1069   1062   1063   Any
        //  1062   1069   1069   1070   Ljava/lang/ClassCastException;
        //  1063   1069   1069   1070   Ljava/util/NoSuchElementException;
        //  1062   1069   1069   1070   Ljava/lang/NullPointerException;
        //  1077   1083   1083   1084   Any
        //  1077   1083   1083   1084   Any
        //  1077   1083   1083   1084   Any
        //  1077   1083   3      8      Ljava/lang/IndexOutOfBoundsException;
        //  1077   1083   1083   1084   Ljava/lang/NegativeArraySizeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:559)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public f9e() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: ldc_w           "\u3cd7\ub24a\u8f9e\uadb0\u67c4\u583c\u7e59"
        //     4: getstatic       dev/nuker/pyro/fc.c:I
        //     7: ifne            16
        //    10: ldc_w           -1662587111
        //    13: goto            19
        //    16: ldc_w           580049239
        //    19: ldc_w           327571205
        //    22: ixor           
        //    23: lookupswitch {
        //          -1889486820: 16
        //          823430738: 48
        //          default: 1164
        //        }
        //    48: invokestatic    invokestatic   !!! ERROR
        //    51: ldc_w           "\u3cf7\ub24a\u8f9e\uadb0\u67e4\u583c\u7e59"
        //    54: invokestatic    invokestatic   !!! ERROR
        //    57: ldc_w           "\u3cf4\ub249\u8f93\uadab\u67d5\u5823\u7e00\u6891\uc2cc\ua331\u9a2c\u1310\uc0e6\u714e\u9015\u4c34\ub208\u4d43\u0155\u07f8\u1334\ufecc\u6b1f\u8856\u36ee\u3cbe\u7fef\ua8e4"
        //    60: invokestatic    invokestatic   !!! ERROR
        //    63: invokespecial   dev/nuker/pyro/fQ.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //    66: aload_0        
        //    67: aload_0        
        //    68: new             Ldev/nuker/pyro/f0m;
        //    71: dup            
        //    72: ldc_w           "\u3cc6\ub255\u8f9a\uada1\u67c6"
        //    75: invokestatic    invokestatic   !!! ERROR
        //    78: ldc_w           "\u3ce6\ub255\u8f9a\uada1\u67c6"
        //    81: invokestatic    invokestatic   !!! ERROR
        //    84: aconst_null    
        //    85: dconst_1       
        //    86: ldc2_w          0.1
        //    89: ldc2_w          10.0
        //    92: dconst_0       
        //    93: bipush          64
        //    95: aconst_null    
        //    96: getstatic       dev/nuker/pyro/fc.0:I
        //    99: ifgt            108
        //   102: ldc_w           1443569000
        //   105: goto            111
        //   108: ldc_w           3005807
        //   111: ldc_w           -760673012
        //   114: ixor           
        //   115: lookupswitch {
        //          -2069753756: 1166
        //          -1869317961: 108
        //          default: 140
        //        }
        //   140: invokespecial   dev/nuker/pyro/f0m.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;DDDDILkotlin/jvm/internal/DefaultConstructorMarker;)V
        //   143: checkcast       Ldev/nuker/pyro/f0w;
        //   146: invokevirtual   dev/nuker/pyro/f9e.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   149: checkcast       Ldev/nuker/pyro/f0m;
        //   152: putfield        dev/nuker/pyro/f9e.c:Ldev/nuker/pyro/f0m;
        //   155: getstatic       dev/nuker/pyro/fc.1:I
        //   158: ifne            167
        //   161: ldc_w           1014798403
        //   164: goto            170
        //   167: ldc_w           -860568594
        //   170: ldc_w           456635866
        //   173: ixor           
        //   174: lookupswitch {
        //          659238297: 1182
        //          1200738155: 167
        //          default: 200
        //        }
        //   200: aload_0        
        //   201: aload_0        
        //   202: new             Ldev/nuker/pyro/f0m;
        //   205: dup            
        //   206: ldc_w           "\u3cc0\ub255\u8fac\uadb4\u67c7\u5835\u7e44"
        //   209: invokestatic    invokestatic   !!! ERROR
        //   212: ldc_w           "\u3ce0\ub255\u8fac\uadb4\u67c7\u5835\u7e44"
        //   215: invokestatic    invokestatic   !!! ERROR
        //   218: aconst_null    
        //   219: dconst_1       
        //   220: ldc2_w          0.1
        //   223: ldc2_w          10.0
        //   226: dconst_0       
        //   227: bipush          64
        //   229: aconst_null    
        //   230: invokespecial   dev/nuker/pyro/f0m.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;DDDDILkotlin/jvm/internal/DefaultConstructorMarker;)V
        //   233: checkcast       Ldev/nuker/pyro/f0w;
        //   236: invokevirtual   dev/nuker/pyro/f9e.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   239: checkcast       Ldev/nuker/pyro/f0m;
        //   242: putfield        dev/nuker/pyro/f9e.0:Ldev/nuker/pyro/f0m;
        //   245: aload_0        
        //   246: getstatic       dev/nuker/pyro/fc.c:I
        //   249: ifne            258
        //   252: ldc_w           -1537935609
        //   255: goto            261
        //   258: ldc_w           -455754677
        //   261: ldc_w           1525724180
        //   264: ixor           
        //   265: lookupswitch {
        //          -1104869281: 292
        //          -22789357: 258
        //          default: 1152
        //        }
        //   292: aload_0        
        //   293: new             Ldev/nuker/pyro/f0m;
        //   296: dup            
        //   297: ldc_w           "\u3cd1\ub24a\u8f88\uadaa\u67f1\u5820\u7e45\u688d\uc2c7"
        //   300: invokestatic    invokestatic   !!! ERROR
        //   303: ldc_w           "\u3cf1\ub24a\u8f88\uadaa\u67f1\u5820\u7e45\u688d\uc2c7"
        //   306: getstatic       dev/nuker/pyro/fc.0:I
        //   309: ifgt            318
        //   312: ldc_w           547987849
        //   315: goto            321
        //   318: ldc_w           1824611571
        //   321: ldc_w           945779912
        //   324: ixor           
        //   325: lookupswitch {
        //          418829633: 318
        //          1419651131: 352
        //          default: 1172
        //        }
        //   352: invokestatic    invokestatic   !!! ERROR
        //   355: aconst_null    
        //   356: dconst_1       
        //   357: ldc2_w          0.1
        //   360: ldc2_w          10.0
        //   363: dconst_0       
        //   364: bipush          64
        //   366: aconst_null    
        //   367: invokespecial   dev/nuker/pyro/f0m.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;DDDDILkotlin/jvm/internal/DefaultConstructorMarker;)V
        //   370: checkcast       Ldev/nuker/pyro/f0w;
        //   373: invokevirtual   dev/nuker/pyro/f9e.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   376: checkcast       Ldev/nuker/pyro/f0m;
        //   379: putfield        dev/nuker/pyro/f9e.1:Ldev/nuker/pyro/f0m;
        //   382: aload_0        
        //   383: getstatic       dev/nuker/pyro/fc.c:I
        //   386: ifne            395
        //   389: ldc_w           412847881
        //   392: goto            398
        //   395: ldc_w           1318787718
        //   398: ldc_w           -1918444877
        //   401: ixor           
        //   402: lookupswitch {
        //          -1791142470: 1178
        //          830995237: 395
        //          default: 428
        //        }
        //   428: aload_0        
        //   429: new             Ldev/nuker/pyro/f0k;
        //   432: dup            
        //   433: ldc_w           "\u3cdb\ub246\u8f8f"
        //   436: getstatic       dev/nuker/pyro/fc.1:I
        //   439: ifne            448
        //   442: ldc_w           -398066697
        //   445: goto            451
        //   448: ldc_w           -776398306
        //   451: ldc_w           1107409532
        //   454: ixor           
        //   455: lookupswitch {
        //          -1816616862: 480
        //          -1438367349: 448
        //          default: 1158
        //        }
        //   480: invokestatic    invokestatic   !!! ERROR
        //   483: ldc_w           "\u3cfb\ub266\u8faf"
        //   486: invokestatic    invokestatic   !!! ERROR
        //   489: aconst_null    
        //   490: iconst_1       
        //   491: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   494: checkcast       Ldev/nuker/pyro/f0w;
        //   497: invokevirtual   dev/nuker/pyro/f9e.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   500: checkcast       Ldev/nuker/pyro/f0k;
        //   503: putfield        dev/nuker/pyro/f9e.c:Ldev/nuker/pyro/f0k;
        //   506: aload_0        
        //   507: aload_0        
        //   508: new             Ldev/nuker/pyro/f0k;
        //   511: dup            
        //   512: ldc_w           "\u3cd4\ub24b\u8f8b\uadad\u67e9\u5839\u7e43\u6883"
        //   515: invokestatic    invokestatic   !!! ERROR
        //   518: ldc_w           "\u3cf4\ub24b\u8f8b\uadad\u67e9\u5839\u7e43\u6883"
        //   521: invokestatic    invokestatic   !!! ERROR
        //   524: aconst_null    
        //   525: iconst_1       
        //   526: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   529: checkcast       Ldev/nuker/pyro/f0w;
        //   532: invokevirtual   dev/nuker/pyro/f9e.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   535: checkcast       Ldev/nuker/pyro/f0k;
        //   538: putfield        dev/nuker/pyro/f9e.0:Ldev/nuker/pyro/f0k;
        //   541: aload_0        
        //   542: aload_0        
        //   543: new             Ldev/nuker/pyro/f0m;
        //   546: dup            
        //   547: ldc_w           "\u3cc6\ub246\u8f9e\uada8\u67c7"
        //   550: invokestatic    invokestatic   !!! ERROR
        //   553: ldc_w           "\u3ce7\ub240\u8f91\uada0\u67c7\u5822\u7e73\u688b\uc2c2\ua328\u9a69"
        //   556: invokestatic    invokestatic   !!! ERROR
        //   559: ldc_w           "\u3cf8\ub244\u8f94\uada1\u6782\u5824\u7e48\u688d\uc283\ua322\u9a65\u1316\uc0fa\u711a\u9053\u4c28\ub214\u4d11\u0151\u07fe\u132e\ufe84\u6b5d\u885b\u36e0\u3cab\u7fbb\ua8e5\ud1e5\u72f0\u45ff\u6bab\u758b\u9738\uc70a\u42ba\ufded\u1115\u184a\u4a75\u6780"
        //   562: invokestatic    invokestatic   !!! ERROR
        //   565: ldc2_w          0.4
        //   568: dconst_0       
        //   569: dconst_1       
        //   570: dconst_0       
        //   571: bipush          64
        //   573: aconst_null    
        //   574: getstatic       dev/nuker/pyro/fc.0:I
        //   577: ifgt            586
        //   580: ldc_w           974233143
        //   583: goto            589
        //   586: ldc_w           -1099719604
        //   589: ldc_w           525739400
        //   592: ixor           
        //   593: lookupswitch {
        //          612531737: 586
        //          625458111: 1162
        //          default: 620
        //        }
        //   620: invokespecial   dev/nuker/pyro/f0m.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;DDDDILkotlin/jvm/internal/DefaultConstructorMarker;)V
        //   623: checkcast       Ldev/nuker/pyro/f0w;
        //   626: getstatic       dev/nuker/pyro/fc.c:I
        //   629: ifne            638
        //   632: ldc_w           341349014
        //   635: goto            641
        //   638: ldc_w           -420520042
        //   641: ldc_w           793934243
        //   644: ixor           
        //   645: lookupswitch {
        //          -910350795: 672
        //          990571317: 638
        //          default: 1154
        //        }
        //   672: invokevirtual   dev/nuker/pyro/f9e.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   675: checkcast       Ldev/nuker/pyro/f0m;
        //   678: putfield        dev/nuker/pyro/f9e.2:Ldev/nuker/pyro/f0m;
        //   681: getstatic       dev/nuker/pyro/fc.1:I
        //   684: ifne            693
        //   687: ldc_w           1910303220
        //   690: goto            696
        //   693: ldc_w           -637641317
        //   696: ldc_w           -1354673270
        //   699: ixor           
        //   700: lookupswitch {
        //          -560088450: 1168
        //          2094465095: 693
        //          default: 728
        //        }
        //   728: aload_0        
        //   729: aload_0        
        //   730: new             Ldev/nuker/pyro/f0o;
        //   733: dup            
        //   734: ldc_w           "\u3cc7\ub250\u8f9d\uada6\u67c7\u5822\u7e6d\u6887\uc2c7\ua321"
        //   737: invokestatic    invokestatic   !!! ERROR
        //   740: ldc_w           "\u3ce7\ub250\u8f9d\uada6\u67c7\u5822\u7e6d\u6887\uc2c7\ua321"
        //   743: getstatic       dev/nuker/pyro/fc.0:I
        //   746: ifgt            755
        //   749: ldc_w           1059285380
        //   752: goto            758
        //   755: ldc_w           1635442666
        //   758: ldc_w           -1059423680
        //   761: ixor           
        //   762: lookupswitch {
        //          -453692: 1176
        //          1218058301: 755
        //          default: 788
        //        }
        //   788: invokestatic    invokestatic   !!! ERROR
        //   791: ldc_w           "\u3cf3\ub24c\u8f98\uadb1\u67d0\u5835\u7e00\u6887\uc2d6\ua330\u9a2c\u1313\uc0e1\u7107\u9010\u4c30\ub251\u4d11\u0157\u07f3\u1322\ufec1\u6b4d\u8856\u36e0\u3cb1\u7fff\ua8b7\ud1f0\u72ff\u45f8\u6ba5\u759c\u976c\uc70a\u42f7\ufdf8\u1116\u1806\u4a71\u6791\uac01\u8cac\uf936\ubc3d"
        //   794: invokestatic    invokestatic   !!! ERROR
        //   797: getstatic       dev/nuker/pyro/f9b.2:Ldev/nuker/pyro/f9b;
        //   800: checkcast       Ljava/lang/Enum;
        //   803: invokespecial   dev/nuker/pyro/f0o.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Enum;)V
        //   806: checkcast       Ldev/nuker/pyro/f0w;
        //   809: getstatic       dev/nuker/pyro/fc.1:I
        //   812: ifne            821
        //   815: ldc_w           -2108184875
        //   818: goto            824
        //   821: ldc_w           -119482745
        //   824: ldc_w           1940461227
        //   827: ixor           
        //   828: lookupswitch {
        //          -234966914: 1174
        //          344352426: 821
        //          default: 856
        //        }
        //   856: invokevirtual   dev/nuker/pyro/f9e.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   859: checkcast       Ldev/nuker/pyro/f0o;
        //   862: putfield        dev/nuker/pyro/f9e.c:Ldev/nuker/pyro/f0o;
        //   865: aload_0        
        //   866: aload_0        
        //   867: new             Ldev/nuker/pyro/f0p;
        //   870: dup            
        //   871: ldc_w           "\u3cd3\ub257\u8f9a\uadb5\u67d7\u5835\u7e4e\u688b\uc2da"
        //   874: getstatic       dev/nuker/pyro/fc.c:I
        //   877: ifne            886
        //   880: ldc_w           1160426351
        //   883: goto            889
        //   886: ldc_w           -533516999
        //   889: ldc_w           707059676
        //   892: ixor           
        //   893: lookupswitch {
        //          -904400155: 920
        //          1863216307: 886
        //          default: 1170
        //        }
        //   920: invokestatic    invokestatic   !!! ERROR
        //   923: ldc_w           "\u3cf3\ub257\u8f9a\uadb5\u67d7\u5835\u7e4e\u688b\uc2da"
        //   926: getstatic       dev/nuker/pyro/fc.1:I
        //   929: ifne            938
        //   932: ldc_w           -533760831
        //   935: goto            941
        //   938: ldc_w           2087575091
        //   941: ldc_w           238857829
        //   944: ixor           
        //   945: lookupswitch {
        //          -300688732: 938
        //          1917939798: 972
        //          default: 1180
        //        }
        //   972: invokestatic    invokestatic   !!! ERROR
        //   975: ldc_w           "\u3cf4\ub248\u8f90\uadb1\u67cc\u5824\u7e00\u6887\uc2c5\ua364\u9a7e\u1311\uc0eb\u710c\u9016\u4c2a\ub213\u4d02\u014c\u07f5\u1360\ufed4\u6b5e\u8857\u36ea\u3cba\u7fef\ua8e4\ud1a0\u72ed\u45fe\u6ba0\u758d\u9738\uc710\u42b9\ufdac\u1116\u1848\u4a75\u67d2\uac11\u8cac\uf925\ubc26\ua5a4\u4c26\u3ed9\u4a36\ua2a4\u798d\u9163\u32c7\u6fdc\uf601\u0f6f\u7a57\u0b35\u9f29\ud307\ue607\u4c7f\u49c4\u1693\u317b\u500c\u7992\ue67f\u5feb\u8b13"
        //   978: invokestatic    invokestatic   !!! ERROR
        //   981: bipush          15
        //   983: iconst_1       
        //   984: bipush          20
        //   986: iconst_0       
        //   987: bipush          64
        //   989: aconst_null    
        //   990: invokespecial   dev/nuker/pyro/f0p.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILkotlin/jvm/internal/DefaultConstructorMarker;)V
        //   993: checkcast       Ldev/nuker/pyro/f0w;
        //   996: invokevirtual   dev/nuker/pyro/f9e.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   999: checkcast       Ldev/nuker/pyro/f0p;
        //  1002: putfield        dev/nuker/pyro/f9e.c:Ldev/nuker/pyro/f0p;
        //  1005: getstatic       dev/nuker/pyro/fc.1:I
        //  1008: ifne            1017
        //  1011: ldc_w           -169305380
        //  1014: goto            1020
        //  1017: ldc_w           -1296375408
        //  1020: ldc_w           -652636011
        //  1023: ixor           
        //  1024: lookupswitch {
        //          753994313: 1017
        //          1805873413: 1052
        //          default: 1156
        //        }
        //  1052: aload_0        
        //  1053: aload_0        
        //  1054: new             Ldev/nuker/pyro/f0p;
        //  1057: dup            
        //  1058: ldc_w           "\u3cd1\ub24c\u8f8c\uadb0\u67c3\u583e\u7e43\u688d"
        //  1061: invokestatic    invokestatic   !!! ERROR
        //  1064: ldc_w           "\u3cf1\ub24c\u8f8c\uadb0\u67c3\u583e\u7e43\u688d"
        //  1067: invokestatic    invokestatic   !!! ERROR
        //  1070: ldc_w           "\u3cf8\ub24c\u8f91\uadad\u67cf\u5825\u7e4d\u68c8\uc2c7\ua32d\u9a7f\u1310\uc0e8\u7100\u9010\u4c3d\ub251\u4d17\u014d\u07b1\u1323\ufecb\u6b4a\u885a\u36f5\u3cff\u7ffa\ua8b7\ud1f2\u72eb\u45f9\u6bac\u759c\u976a\uc71b\u42b6\ufde2\u111d\u1806\u4a60\u6793\uac01\u8ca2\uf923\ubc3d\ua5ea\u4c23\u3e8a\u4a62\ua2bd\u79cc\u916e\u32cd\u6fcc"
        //  1073: invokestatic    invokestatic   !!! ERROR
        //  1076: bipush          35
        //  1078: iconst_1       
        //  1079: bipush          100
        //  1081: iconst_0       
        //  1082: bipush          64
        //  1084: aconst_null    
        //  1085: invokespecial   dev/nuker/pyro/f0p.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILkotlin/jvm/internal/DefaultConstructorMarker;)V
        //  1088: checkcast       Ldev/nuker/pyro/f0w;
        //  1091: invokevirtual   dev/nuker/pyro/f9e.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //  1094: checkcast       Ldev/nuker/pyro/f0p;
        //  1097: putfield        dev/nuker/pyro/f9e.0:Ldev/nuker/pyro/f0p;
        //  1100: getstatic       dev/nuker/pyro/fc.1:I
        //  1103: ifne            1112
        //  1106: ldc_w           582016680
        //  1109: goto            1115
        //  1112: ldc_w           -1696348188
        //  1115: ldc_w           -24012406
        //  1118: ixor           
        //  1119: lookupswitch {
        //          -601798878: 1112
        //          1685216878: 1144
        //          default: 1160
        //        }
        //  1144: aload_0        
        //  1145: ldc2_w          -1.0
        //  1148: putfield        dev/nuker/pyro/f9e.c:D
        //  1151: return         
        //  1152: aconst_null    
        //  1153: athrow         
        //  1154: aconst_null    
        //  1155: athrow         
        //  1156: aconst_null    
        //  1157: athrow         
        //  1158: aconst_null    
        //  1159: athrow         
        //  1160: aconst_null    
        //  1161: athrow         
        //  1162: aconst_null    
        //  1163: athrow         
        //  1164: aconst_null    
        //  1165: athrow         
        //  1166: aconst_null    
        //  1167: athrow         
        //  1168: aconst_null    
        //  1169: athrow         
        //  1170: aconst_null    
        //  1171: athrow         
        //  1172: aconst_null    
        //  1173: athrow         
        //  1174: aconst_null    
        //  1175: athrow         
        //  1176: aconst_null    
        //  1177: athrow         
        //  1178: aconst_null    
        //  1179: athrow         
        //  1180: aconst_null    
        //  1181: athrow         
        //  1182: aconst_null    
        //  1183: athrow         
        //    StackMapTable: 00 40 FF 00 10 00 01 06 00 02 06 07 01 A3 FF 00 02 00 01 06 00 03 06 07 01 A3 01 FF 00 1C 00 01 06 00 02 06 07 01 A3 FF 00 3B 00 01 07 00 03 00 0D 07 00 03 07 00 03 08 00 44 08 00 44 07 01 A3 07 01 A3 05 03 03 03 03 01 05 FF 00 02 00 01 07 00 03 00 0E 07 00 03 07 00 03 08 00 44 08 00 44 07 01 A3 07 01 A3 05 03 03 03 03 01 05 01 FF 00 1C 00 01 07 00 03 00 0D 07 00 03 07 00 03 08 00 44 08 00 44 07 01 A3 07 01 A3 05 03 03 03 03 01 05 1A 42 01 1D 79 07 00 03 FF 00 02 00 01 07 00 03 00 02 07 00 03 01 5E 07 00 03 FF 00 19 00 01 07 00 03 00 06 07 00 03 07 00 03 08 01 25 08 01 25 07 01 A3 07 01 A3 FF 00 02 00 01 07 00 03 00 07 07 00 03 07 00 03 08 01 25 08 01 25 07 01 A3 07 01 A3 01 FF 00 1E 00 01 07 00 03 00 06 07 00 03 07 00 03 08 01 25 08 01 25 07 01 A3 07 01 A3 6A 07 00 03 FF 00 02 00 01 07 00 03 00 02 07 00 03 01 5D 07 00 03 FF 00 13 00 01 07 00 03 00 05 07 00 03 07 00 03 08 01 AD 08 01 AD 07 01 A3 FF 00 02 00 01 07 00 03 00 06 07 00 03 07 00 03 08 01 AD 08 01 AD 07 01 A3 01 FF 00 1C 00 01 07 00 03 00 05 07 00 03 07 00 03 08 01 AD 08 01 AD 07 01 A3 FF 00 69 00 01 07 00 03 00 0D 07 00 03 07 00 03 08 02 1F 08 02 1F 07 01 A3 07 01 A3 07 01 A3 03 03 03 03 01 05 FF 00 02 00 01 07 00 03 00 0E 07 00 03 07 00 03 08 02 1F 08 02 1F 07 01 A3 07 01 A3 07 01 A3 03 03 03 03 01 05 01 FF 00 1E 00 01 07 00 03 00 0D 07 00 03 07 00 03 08 02 1F 08 02 1F 07 01 A3 07 01 A3 07 01 A3 03 03 03 03 01 05 FF 00 11 00 01 07 00 03 00 03 07 00 03 07 00 03 07 02 5C FF 00 02 00 01 07 00 03 00 04 07 00 03 07 00 03 07 02 5C 01 FF 00 1E 00 01 07 00 03 00 03 07 00 03 07 00 03 07 02 5C 14 42 01 1F FF 00 1A 00 01 07 00 03 00 06 07 00 03 07 00 03 08 02 DA 08 02 DA 07 01 A3 07 01 A3 FF 00 02 00 01 07 00 03 00 07 07 00 03 07 00 03 08 02 DA 08 02 DA 07 01 A3 07 01 A3 01 FF 00 1D 00 01 07 00 03 00 06 07 00 03 07 00 03 08 02 DA 08 02 DA 07 01 A3 07 01 A3 FF 00 20 00 01 07 00 03 00 03 07 00 03 07 00 03 07 02 5C FF 00 02 00 01 07 00 03 00 04 07 00 03 07 00 03 07 02 5C 01 FF 00 1F 00 01 07 00 03 00 03 07 00 03 07 00 03 07 02 5C FF 00 1D 00 01 07 00 03 00 05 07 00 03 07 00 03 08 03 63 08 03 63 07 01 A3 FF 00 02 00 01 07 00 03 00 06 07 00 03 07 00 03 08 03 63 08 03 63 07 01 A3 01 FF 00 1E 00 01 07 00 03 00 05 07 00 03 07 00 03 08 03 63 08 03 63 07 01 A3 FF 00 11 00 01 07 00 03 00 06 07 00 03 07 00 03 08 03 63 08 03 63 07 01 A3 07 01 A3 FF 00 02 00 01 07 00 03 00 07 07 00 03 07 00 03 08 03 63 08 03 63 07 01 A3 07 01 A3 01 FF 00 1E 00 01 07 00 03 00 06 07 00 03 07 00 03 08 03 63 08 03 63 07 01 A3 07 01 A3 2C 42 01 1F 3B 42 01 1C 47 07 00 03 FF 00 01 00 01 07 00 03 00 03 07 00 03 07 00 03 07 02 5C 01 FF 00 01 00 01 07 00 03 00 05 07 00 03 07 00 03 08 01 AD 08 01 AD 07 01 A3 01 FF 00 01 00 01 07 00 03 00 0D 07 00 03 07 00 03 08 02 1F 08 02 1F 07 01 A3 07 01 A3 07 01 A3 03 03 03 03 01 05 FF 00 01 00 01 06 00 02 06 07 01 A3 FF 00 01 00 01 07 00 03 00 0D 07 00 03 07 00 03 08 00 44 08 00 44 07 01 A3 07 01 A3 05 03 03 03 03 01 05 01 FF 00 01 00 01 07 00 03 00 05 07 00 03 07 00 03 08 03 63 08 03 63 07 01 A3 FF 00 01 00 01 07 00 03 00 06 07 00 03 07 00 03 08 01 25 08 01 25 07 01 A3 07 01 A3 FF 00 01 00 01 07 00 03 00 03 07 00 03 07 00 03 07 02 5C FF 00 01 00 01 07 00 03 00 06 07 00 03 07 00 03 08 02 DA 08 02 DA 07 01 A3 07 01 A3 41 07 00 03 FF 00 01 00 01 07 00 03 00 06 07 00 03 07 00 03 08 03 63 08 03 63 07 01 A3 07 01 A3 01
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2695)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        throw t;
    }
    
    @NotNull
    public f0o c() {
        return fez.bk(this, 1809232004);
    }
    
    @NotNull
    public f0k 6() {
        return fez.85(this, 786376253);
    }
    
    @NotNull
    public f0p 7() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getstatic       dev/nuker/pyro/fc.1:I
        //     4: ifeq            38
        //     7: pop            
        //     8: aconst_null    
        //     9: goto            30
        //    12: nop            
        //    13: nop            
        //    14: nop            
        //    15: athrow         
        //    16: aload_0        
        //    17: getfield        dev/nuker/pyro/f9e.0:Ldev/nuker/pyro/f0p;
        //    20: areturn        
        //    21: pop            
        //    22: goto            16
        //    25: pop            
        //    26: aconst_null    
        //    27: goto            21
        //    30: dup            
        //    31: ifnull          21
        //    34: checkcast       Ljava/lang/Throwable;
        //    37: athrow         
        //    38: dup            
        //    39: ifnull          25
        //    42: checkcast       Ljava/lang/Throwable;
        //    45: athrow         
        //    StackMapTable: 00 06 FF 00 0C 00 00 00 01 07 00 47 FC 00 03 07 00 03 44 07 00 47 43 05 44 07 00 47 47 05
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                             
        //  -----  -----  -----  -----  ---------------------------------
        //  0      12     30     38     Any
        //  30     38     30     38     Ljava/lang/NumberFormatException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:543)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void c(final boolean b, @Nullable final EntityPlayerSP entityPlayerSP, @Nullable final World world) {
        Object o = null;
        Label_0008: {
            break Label_0008;
        Label_0179:
            while (true) {
            Block_8_Outer:
                do {
                    Label_0166: {
                        break Label_0166;
                        try {
                            o = null;
                            if (fc.c != 0) {
                                null;
                                goto Label_0171;
                            }
                            continue Label_0179;
                            Label_0113: {
                                final int n = 171463937;
                            }
                            // switch([Lcom.strobel.decompiler.ast.Label;@47d1a29c, n2 ^ 0x473C8D5E)
                            // iftrue(Label_0039:, fc.1 != 0)
                            // switch([Lcom.strobel.decompiler.ast.Label;@feaf1c2, n ^ 0x9C5D775E)
                            while (true) {
                                Label_0084: {
                                    while (true) {
                                        Block_6: {
                                            Label_0116: {
                                                break Label_0116;
                                                final Minecraft c;
                                                Label_0148:
                                                this.c = c.field_71439_g.field_70177_z;
                                                return;
                                                break Label_0084;
                                                Label_0072:
                                                goto Label_0077;
                                                Label_0158:
                                                throw null;
                                                Label_0039:
                                                final int n2 = 326995774;
                                                break Label_0042;
                                                Label_0160:
                                                throw null;
                                                break Block_6;
                                                final int n = 1621342002;
                                            }
                                        }
                                        final int n2 = 829125414;
                                        continue Block_8_Outer;
                                    }
                                }
                                this.2 = 0;
                                this.c = -1.0;
                                final Minecraft c = this.c;
                                continue;
                            }
                        }
                        // iftrue(Label_0113:, fc.0 > 0)
                        catch (IllegalArgumentException ex) {}
                    }
                    continue Label_0179;
                } while (o == null);
                break;
            }
        }
        throw (Throwable)o;
    }
    
    @NotNull
    public f0m 4() {
        return fez.9u(this, 824450699);
    }
    
    @f0g
    @LauncherEventHide
    public void c(@NotNull final f49 p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          1930
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            1922
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            1914
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: aload_1        
        //    27: getstatic       dev/nuker/pyro/fc.1:I
        //    30: ifne            39
        //    33: ldc_w           -1554109618
        //    36: goto            42
        //    39: ldc_w           -1897666745
        //    42: ldc_w           -1312053574
        //    45: ixor           
        //    46: lookupswitch {
        //          311791092: 39
        //          1059602941: 72
        //          default: 1867
        //        }
        //    72: goto            76
        //    75: athrow         
        //    76: invokevirtual   dev/nuker/pyro/f49.c:()Ldev/nuker/pyro/f41;
        //    79: goto            83
        //    82: athrow         
        //    83: getstatic       dev/nuker/pyro/f41.c:Ldev/nuker/pyro/f41;
        //    86: if_acmpne       95
        //    89: ldc_w           59383051
        //    92: goto            98
        //    95: ldc_w           59383050
        //    98: ldc_w           -806668293
        //   101: ixor           
        //   102: tableswitch {
        //          -1732094496: 124
        //          -1732094495: 1862
        //          default: 89
        //        }
        //   124: aload_1        
        //   125: goto            129
        //   128: athrow         
        //   129: invokevirtual   dev/nuker/pyro/f49.c:()Z
        //   132: goto            136
        //   135: athrow         
        //   136: ifne            1862
        //   139: aload_1        
        //   140: goto            144
        //   143: athrow         
        //   144: invokevirtual   dev/nuker/pyro/f49.c:()Lnet/minecraft/network/Packet;
        //   147: goto            151
        //   150: athrow         
        //   151: astore_2       
        //   152: aload_2        
        //   153: instanceof      Lnet/minecraft/network/play/client/CPacketVehicleMove;
        //   156: ifeq            165
        //   159: ldc_w           -702024090
        //   162: goto            168
        //   165: ldc_w           -702024089
        //   168: ldc_w           887557030
        //   171: ixor           
        //   172: tableswitch {
        //          -981337216: 196
        //          -981337215: 997
        //          default: 159
        //        }
        //   196: aload_1        
        //   197: goto            201
        //   200: athrow         
        //   201: invokevirtual   dev/nuker/pyro/f49.c:()Lnet/minecraft/network/Packet;
        //   204: goto            208
        //   207: athrow         
        //   208: dup            
        //   209: ifnonnull       287
        //   212: new             Lkotlin/TypeCastException;
        //   215: dup            
        //   216: ldc_w           "\u3cdb\ub250\u8f93\uafb9\u6193\u5833\u7e41\u6886\uc0dc\ua53a\u9a78\u1344\uc0eb\u731a\u9642\u4c3b\ub210\u4d10\u0347\u01a0\u1334\ufecb\u6b1f\u8a4b\u30ff\u3cb1\u7fb6\ua8f9\ud3e4\u74e3\u45f7\u6bee\u758d\u9570\uc118\u42b2\ufdac\u1117\u1a52\u4c75\u67dc\uac0f\u8ca0\ufb39\uba3d\ua5a9\u4c30\u3e98\u4835\ua4ae\u7983\u916c\u32c1\u6dcd\uf012\u0f61\u7a49\u0b32\u9d6f\ud546\ue619\u4c6b\u49df\u14ce\u376c\u5012\u7999\ue67b\u5dfa\u8d12\uea44\u1de0\uf350\ub46d\uc688\u16fd\u2aee\u67c6\u466f\u7ac7\ucba3\u172e\u2ad5\u8dc4\ud68b\u39eb\u9b94\u8274\ucad8"
        //   219: getstatic       dev/nuker/pyro/fc.0:I
        //   222: ifgt            231
        //   225: ldc_w           -1227785096
        //   228: goto            234
        //   231: ldc_w           -200472951
        //   234: ldc_w           1279082013
        //   237: ixor           
        //   238: lookupswitch {
        //          -1204799340: 264
        //          -85179803: 231
        //          default: 1899
        //        }
        //   264: goto            268
        //   267: athrow         
        //   268: invokestatic    invokestatic   !!! ERROR
        //   271: goto            275
        //   274: athrow         
        //   275: goto            279
        //   278: athrow         
        //   279: invokespecial   kotlin/TypeCastException.<init>:(Ljava/lang/String;)V
        //   282: goto            286
        //   285: athrow         
        //   286: athrow         
        //   287: checkcast       Lnet/minecraft/network/play/client/CPacketVehicleMove;
        //   290: getstatic       dev/nuker/pyro/fc.0:I
        //   293: ifgt            302
        //   296: ldc_w           -1005494206
        //   299: goto            305
        //   302: ldc_w           -1867809806
        //   305: ldc_w           -1363183917
        //   308: ixor           
        //   309: lookupswitch {
        //          1041501473: 336
        //          1789793937: 302
        //          default: 1873
        //        }
        //   336: astore_3       
        //   337: aload_0        
        //   338: getfield        dev/nuker/pyro/f9e.0:Ldev/nuker/pyro/f0k;
        //   341: goto            345
        //   344: athrow         
        //   345: invokevirtual   dev/nuker/pyro/f0k.c:()Ljava/lang/Object;
        //   348: goto            352
        //   351: athrow         
        //   352: checkcast       Ljava/lang/Boolean;
        //   355: getstatic       dev/nuker/pyro/fc.0:I
        //   358: ifgt            367
        //   361: ldc_w           292847148
        //   364: goto            370
        //   367: ldc_w           1123176886
        //   370: ldc_w           1399663461
        //   373: ixor           
        //   374: lookupswitch {
        //          295664339: 400
        //          1108956489: 367
        //          default: 1877
        //        }
        //   400: goto            404
        //   403: athrow         
        //   404: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   407: goto            411
        //   410: athrow         
        //   411: ifeq            1862
        //   414: getstatic       dev/nuker/pyro/fc.0:I
        //   417: ifgt            426
        //   420: ldc_w           678636344
        //   423: goto            429
        //   426: ldc_w           -61205608
        //   429: ldc_w           1858909864
        //   432: ixor           
        //   433: lookupswitch {
        //          559405864: 426
        //          1186962832: 1887
        //          default: 460
        //        }
        //   460: aload_0        
        //   461: getfield        dev/nuker/pyro/f9e.c:Z
        //   464: ifeq            1862
        //   467: aload_0        
        //   468: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //   471: getstatic       dev/nuker/pyro/fc.c:I
        //   474: ifne            483
        //   477: ldc_w           -602143159
        //   480: goto            486
        //   483: ldc_w           751732318
        //   486: ldc_w           -857033544
        //   489: ixor           
        //   490: lookupswitch {
        //          -534498586: 516
        //          284603121: 483
        //          default: 1893
        //        }
        //   516: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   519: dup            
        //   520: pop            
        //   521: getstatic       dev/nuker/pyro/fc.c:I
        //   524: ifne            533
        //   527: ldc_w           1027595914
        //   530: goto            536
        //   533: ldc_w           -1406157193
        //   536: ldc_w           1738202353
        //   539: ixor           
        //   540: lookupswitch {
        //          -877305210: 568
        //          1520763515: 533
        //          default: 1869
        //        }
        //   568: goto            572
        //   571: athrow         
        //   572: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_184187_bx:()Lnet/minecraft/entity/Entity;
        //   575: goto            579
        //   578: athrow         
        //   579: dup            
        //   580: ifnonnull       594
        //   583: goto            587
        //   586: athrow         
        //   587: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //   590: goto            594
        //   593: athrow         
        //   594: getfield        net/minecraft/entity/Entity.field_70122_E:Z
        //   597: ifne            606
        //   600: ldc_w           -222670059
        //   603: goto            609
        //   606: ldc_w           -222670060
        //   609: ldc_w           -1458085931
        //   612: ixor           
        //   613: tableswitch {
        //          -1218832000: 636
        //          -1218831999: 1862
        //          default: 600
        //        }
        //   636: aload_0        
        //   637: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //   640: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //   643: aconst_null    
        //   644: aload_0        
        //   645: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //   648: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   651: dup            
        //   652: pop            
        //   653: goto            657
        //   656: athrow         
        //   657: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_184187_bx:()Lnet/minecraft/entity/Entity;
        //   660: goto            664
        //   663: athrow         
        //   664: dup            
        //   665: ifnonnull       674
        //   668: ldc_w           99750629
        //   671: goto            677
        //   674: ldc_w           99750626
        //   677: ldc_w           -1337128770
        //   680: ixor           
        //   681: tableswitch {
        //          1803433142: 704
        //          1803433143: 715
        //          default: 668
        //        }
        //   704: goto            708
        //   707: athrow         
        //   708: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //   711: goto            715
        //   714: athrow         
        //   715: dup            
        //   716: pop            
        //   717: goto            721
        //   720: athrow         
        //   721: invokevirtual   net/minecraft/entity/Entity.func_174813_aQ:()Lnet/minecraft/util/math/AxisAlignedBB;
        //   724: goto            728
        //   727: athrow         
        //   728: ldc2_w          0.0625
        //   731: goto            735
        //   734: athrow         
        //   735: invokevirtual   net/minecraft/util/math/AxisAlignedBB.func_186662_g:(D)Lnet/minecraft/util/math/AxisAlignedBB;
        //   738: goto            742
        //   741: athrow         
        //   742: dconst_0       
        //   743: ldc2_w          -0.05
        //   746: dconst_0       
        //   747: getstatic       dev/nuker/pyro/fc.1:I
        //   750: ifne            759
        //   753: ldc_w           -1567742615
        //   756: goto            762
        //   759: ldc_w           -1642448863
        //   762: ldc_w           -1639072274
        //   765: ixor           
        //   766: lookupswitch {
        //          -1037976148: 759
        //          1019451527: 1901
        //          default: 792
        //        }
        //   792: goto            796
        //   795: athrow         
        //   796: invokevirtual   net/minecraft/util/math/AxisAlignedBB.func_72321_a:(DDD)Lnet/minecraft/util/math/AxisAlignedBB;
        //   799: goto            803
        //   802: athrow         
        //   803: goto            807
        //   806: athrow         
        //   807: invokevirtual   net/minecraft/client/multiplayer/WorldClient.func_184144_a:(Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/AxisAlignedBB;)Ljava/util/List;
        //   810: goto            814
        //   813: athrow         
        //   814: getstatic       dev/nuker/pyro/fc.c:I
        //   817: ifne            826
        //   820: ldc_w           1264793396
        //   823: goto            829
        //   826: ldc_w           591712719
        //   829: ldc_w           -893800705
        //   832: ixor           
        //   833: lookupswitch {
        //          -2116380213: 826
        //          -369262800: 860
        //          default: 1879
        //        }
        //   860: goto            864
        //   863: athrow         
        //   864: invokeinterface java/util/List.isEmpty:()Z
        //   869: goto            873
        //   872: athrow         
        //   873: ifeq            1862
        //   876: aload_0        
        //   877: iconst_0       
        //   878: putfield        dev/nuker/pyro/f9e.c:Z
        //   881: aload_1        
        //   882: goto            886
        //   885: athrow         
        //   886: invokevirtual   dev/nuker/pyro/f49.c:()Lnet/minecraft/network/Packet;
        //   889: goto            893
        //   892: athrow         
        //   893: dup            
        //   894: ifnonnull       903
        //   897: ldc_w           -86787667
        //   900: goto            906
        //   903: ldc_w           -86787666
        //   906: ldc_w           1431053392
        //   909: ixor           
        //   910: tableswitch {
        //          1597979642: 932
        //          1597979643: 962
        //          default: 897
        //        }
        //   932: new             Lkotlin/TypeCastException;
        //   935: dup            
        //   936: ldc_w           "\u3cdb\ub250\u8f93\uafb9\u6193\u5833\u7e41\u6886\uc0dc\ua53a\u9a78\u1344\uc0eb\u731a\u9642\u4c3b\ub210\u4d10\u0347\u01a0\u1334\ufecb\u6b1f\u8a4b\u30ff\u3cb1\u7fb6\ua8f9\ud3e4\u74e3\u45f7\u6bee\u758d\u9570\uc118\u42b2\ufdac\u111d\u1a52\u4c77\u67dc\uac0c\u8cbc\ufb3c\uba3d\ua5b8\u4c6c\u3e89\u482a\ua4a8\u79c2\u912c\u32c9\u6dd0\uf01d\u0f67\u7a55\u0b77\u9d02\ud566\ue614\u4c69\u49cd\u1485\u377b\u5028\u7995\ue676\u5dfd\u8d05\uea06\u1dc6\uf34d\ub463\uc69d\u16f3\u2aca\u67d1\u465a\u7ac7\ucbb8\u1734\u2ad9\u8dda"
        //   939: goto            943
        //   942: athrow         
        //   943: invokestatic    invokestatic   !!! ERROR
        //   946: goto            950
        //   949: athrow         
        //   950: goto            954
        //   953: athrow         
        //   954: invokespecial   kotlin/TypeCastException.<init>:(Ljava/lang/String;)V
        //   957: goto            961
        //   960: athrow         
        //   961: athrow         
        //   962: checkcast       Ldev/nuker/pyro/mixin/CPacketVehicleMoveAccessor;
        //   965: aload_3        
        //   966: goto            970
        //   969: athrow         
        //   970: invokevirtual   net/minecraft/network/play/client/CPacketVehicleMove.func_187002_b:()D
        //   973: goto            977
        //   976: athrow         
        //   977: ldc2_w          0.05
        //   980: dsub           
        //   981: goto            985
        //   984: athrow         
        //   985: invokeinterface dev/nuker/pyro/mixin/CPacketVehicleMoveAccessor.setY:(D)V
        //   990: goto            994
        //   993: athrow         
        //   994: goto            1862
        //   997: aload_2        
        //   998: instanceof      Lnet/minecraft/network/play/client/CPacketSteerBoat;
        //  1001: ifeq            1019
        //  1004: aload_1        
        //  1005: goto            1009
        //  1008: athrow         
        //  1009: invokevirtual   dev/nuker/pyro/f49.0:()V
        //  1012: goto            1016
        //  1015: athrow         
        //  1016: goto            1862
        //  1019: aload_2        
        //  1020: instanceof      Lnet/minecraft/network/play/client/CPacketInput;
        //  1023: ifeq            1484
        //  1026: aload_0        
        //  1027: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //  1030: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1033: dup            
        //  1034: pop            
        //  1035: getstatic       dev/nuker/pyro/fc.c:I
        //  1038: ifne            1047
        //  1041: ldc_w           1430467057
        //  1044: goto            1050
        //  1047: ldc_w           2069118248
        //  1050: ldc_w           -905094716
        //  1053: ixor           
        //  1054: lookupswitch {
        //          -1622251467: 1897
        //          2095246662: 1047
        //          default: 1080
        //        }
        //  1080: goto            1084
        //  1083: athrow         
        //  1084: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_184218_aH:()Z
        //  1087: goto            1091
        //  1090: athrow         
        //  1091: ifeq            1862
        //  1094: getstatic       dev/nuker/pyro/fc.0:I
        //  1097: ifgt            1106
        //  1100: ldc_w           1072856014
        //  1103: goto            1109
        //  1106: ldc_w           -1060051778
        //  1109: ldc_w           -196933336
        //  1112: ixor           
        //  1113: lookupswitch {
        //          -877563162: 1895
        //          -371597736: 1106
        //          default: 1140
        //        }
        //  1140: aload_1        
        //  1141: getstatic       dev/nuker/pyro/fc.0:I
        //  1144: ifgt            1153
        //  1147: ldc_w           -1715724187
        //  1150: goto            1156
        //  1153: ldc_w           1911459395
        //  1156: ldc_w           -2029049169
        //  1159: ixor           
        //  1160: lookupswitch {
        //          -152984340: 1188
        //          515050186: 1153
        //          default: 1891
        //        }
        //  1188: goto            1192
        //  1191: athrow         
        //  1192: invokevirtual   dev/nuker/pyro/f49.c:()Lnet/minecraft/network/Packet;
        //  1195: goto            1199
        //  1198: athrow         
        //  1199: dup            
        //  1200: ifnonnull       1233
        //  1203: new             Lkotlin/TypeCastException;
        //  1206: dup            
        //  1207: ldc_w           "\u3cdb\ub250\u8f93\uafb9\u6193\u5833\u7e41\u6886\uc0dc\ua53a\u9a78\u1344\uc0eb\u731a\u9642\u4c3b\ub210\u4d10\u0347\u01a0\u1334\ufecb\u6b1f\u8a4b\u30ff\u3cb1\u7fb6\ua8f9\ud3e4\u74e3\u45f7\u6bee\u758d\u9570\uc118\u42b2\ufdac\u1117\u1a52\u4c75\u67dc\uac0f\u8ca0\ufb39\uba3d\ua5a9\u4c30\u3e98\u4835\ua4ae\u7983\u916c\u32c1\u6dcd\uf012\u0f61\u7a49\u0b32\u9d6f\ud546\ue619\u4c6b\u49df\u14ce\u376c\u5012\u7999\ue67b\u5dfa\u8d12\uea44\u1de0\uf350\ub46d\uc688\u16fd\u2aee\u67c6\u4670\u7acc\ucbbb\u1732\u2ac2"
        //  1210: goto            1214
        //  1213: athrow         
        //  1214: invokestatic    invokestatic   !!! ERROR
        //  1217: goto            1221
        //  1220: athrow         
        //  1221: goto            1225
        //  1224: athrow         
        //  1225: invokespecial   kotlin/TypeCastException.<init>:(Ljava/lang/String;)V
        //  1228: goto            1232
        //  1231: athrow         
        //  1232: athrow         
        //  1233: checkcast       Lnet/minecraft/network/play/client/CPacketInput;
        //  1236: getstatic       dev/nuker/pyro/fc.1:I
        //  1239: ifne            1248
        //  1242: ldc_w           2079667783
        //  1245: goto            1251
        //  1248: ldc_w           272774116
        //  1251: ldc_w           1937318667
        //  1254: ixor           
        //  1255: lookupswitch {
        //          143398220: 1248
        //          1664815343: 1280
        //          default: 1903
        //        }
        //  1280: goto            1284
        //  1283: athrow         
        //  1284: invokevirtual   net/minecraft/network/play/client/CPacketInput.func_149617_f:()Z
        //  1287: goto            1291
        //  1290: athrow         
        //  1291: ifeq            1469
        //  1294: aload_0        
        //  1295: getstatic       dev/nuker/pyro/fc.1:I
        //  1298: ifne            1307
        //  1301: ldc_w           512111712
        //  1304: goto            1310
        //  1307: ldc_w           454008882
        //  1310: ldc_w           -1692272047
        //  1313: ixor           
        //  1314: lookupswitch {
        //          -2052600271: 1881
        //          -1117549562: 1307
        //          default: 1340
        //        }
        //  1340: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //  1343: getstatic       dev/nuker/pyro/fc.1:I
        //  1346: ifne            1355
        //  1349: ldc_w           -1481640206
        //  1352: goto            1358
        //  1355: ldc_w           -1252543577
        //  1358: ldc_w           -1401859661
        //  1361: ixor           
        //  1362: lookupswitch {
        //          199141185: 1355
        //          421978644: 1388
        //          default: 1871
        //        }
        //  1388: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1391: dup            
        //  1392: pop            
        //  1393: goto            1397
        //  1396: athrow         
        //  1397: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_184187_bx:()Lnet/minecraft/entity/Entity;
        //  1400: goto            1404
        //  1403: athrow         
        //  1404: dup            
        //  1405: ifnonnull       1463
        //  1408: getstatic       dev/nuker/pyro/fc.0:I
        //  1411: ifgt            1420
        //  1414: ldc_w           609422980
        //  1417: goto            1423
        //  1420: ldc_w           896431712
        //  1423: ldc_w           -827426664
        //  1426: ixor           
        //  1427: lookupswitch {
        //          -352487908: 1420
        //          -71299336: 1452
        //          default: 1865
        //        }
        //  1452: goto            1456
        //  1455: athrow         
        //  1456: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
        //  1459: goto            1463
        //  1462: athrow         
        //  1463: getfield        net/minecraft/entity/Entity.field_70122_E:Z
        //  1466: ifne            1862
        //  1469: aload_1        
        //  1470: goto            1474
        //  1473: athrow         
        //  1474: invokevirtual   dev/nuker/pyro/f49.0:()V
        //  1477: goto            1481
        //  1480: athrow         
        //  1481: goto            1862
        //  1484: getstatic       dev/nuker/pyro/fc.0:I
        //  1487: ifgt            1496
        //  1490: ldc_w           194860475
        //  1493: goto            1499
        //  1496: ldc_w           -400282240
        //  1499: ldc_w           1109257900
        //  1502: ixor           
        //  1503: lookupswitch {
        //          -1134845761: 1496
        //          1233173271: 1875
        //          default: 1528
        //        }
        //  1528: aload_2        
        //  1529: instanceof      Lnet/minecraft/network/play/client/CPacketPlayer;
        //  1532: ifeq            1663
        //  1535: aload_0        
        //  1536: getstatic       dev/nuker/pyro/fc.0:I
        //  1539: ifgt            1548
        //  1542: ldc_w           65794404
        //  1545: goto            1551
        //  1548: ldc_w           908970950
        //  1551: ldc_w           1205855314
        //  1554: ixor           
        //  1555: lookupswitch {
        //          -950565845: 1548
        //          1144263990: 1889
        //          default: 1580
        //        }
        //  1580: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //  1583: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1586: dup            
        //  1587: pop            
        //  1588: goto            1592
        //  1591: athrow         
        //  1592: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_184218_aH:()Z
        //  1595: goto            1599
        //  1598: athrow         
        //  1599: ifeq            1862
        //  1602: getstatic       dev/nuker/pyro/fc.c:I
        //  1605: ifne            1614
        //  1608: ldc_w           -1347634793
        //  1611: goto            1617
        //  1614: ldc_w           993022625
        //  1617: ldc_w           -1355350657
        //  1620: ixor           
        //  1621: lookupswitch {
        //          -459043523: 1614
        //          10110184: 1863
        //          default: 1648
        //        }
        //  1648: aload_1        
        //  1649: goto            1653
        //  1652: athrow         
        //  1653: invokevirtual   dev/nuker/pyro/f49.0:()V
        //  1656: goto            1660
        //  1659: athrow         
        //  1660: goto            1862
        //  1663: aload_2        
        //  1664: instanceof      Lnet/minecraft/network/play/client/CPacketEntityAction;
        //  1667: ifeq            1862
        //  1670: aload_0        
        //  1671: getstatic       dev/nuker/pyro/fc.1:I
        //  1674: ifne            1683
        //  1677: ldc_w           750498046
        //  1680: goto            1686
        //  1683: ldc_w           1980383975
        //  1686: ldc_w           635905354
        //  1689: ixor           
        //  1690: lookupswitch {
        //          157062580: 1683
        //          1408067501: 1716
        //          default: 1883
        //        }
        //  1716: getfield        dev/nuker/pyro/f9e.c:Lnet/minecraft/client/Minecraft;
        //  1719: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1722: dup            
        //  1723: pop            
        //  1724: goto            1728
        //  1727: athrow         
        //  1728: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_184218_aH:()Z
        //  1731: goto            1735
        //  1734: athrow         
        //  1735: ifeq            1862
        //  1738: getstatic       dev/nuker/pyro/fc.1:I
        //  1741: ifne            1750
        //  1744: ldc_w           1599115453
        //  1747: goto            1753
        //  1750: ldc_w           -1840313613
        //  1753: ldc_w           -1544375449
        //  1756: ixor           
        //  1757: lookupswitch {
        //          -56482854: 1750
        //          834517396: 1784
        //          default: 1885
        //        }
        //  1784: aload_1        
        //  1785: goto            1789
        //  1788: athrow         
        //  1789: invokevirtual   dev/nuker/pyro/f49.c:()Lnet/minecraft/network/Packet;
        //  1792: goto            1796
        //  1795: athrow         
        //  1796: dup            
        //  1797: ifnonnull       1830
        //  1800: new             Lkotlin/TypeCastException;
        //  1803: dup            
        //  1804: ldc_w           "\u3cdb\ub250\u8f93\uafb9\u6193\u5833\u7e41\u6886\uc0dc\ua53a\u9a78\u1344\uc0eb\u731a\u9642\u4c3b\ub210\u4d10\u0347\u01a0\u1334\ufecb\u6b1f\u8a4b\u30ff\u3cb1\u7fb6\ua8f9\ud3e4\u74e3\u45f7\u6bee\u758d\u9570\uc118\u42b2\ufdac\u1117\u1a52\u4c75\u67dc\uac0f\u8ca0\ufb39\uba3d\ua5a9\u4c30\u3e98\u4835\ua4ae\u7983\u916c\u32c1\u6dcd\uf012\u0f61\u7a49\u0b32\u9d6f\ud546\ue619\u4c6b\u49df\u14ce\u376c\u5012\u7999\ue67b\u5dfa\u8d12\uea44\u1de0\uf350\ub46d\uc688\u16fd\u2aee\u67c6\u467c\u7acc\ucbbf\u172e\u2ac2\u8dd1\ud6af\u39c5\u9b8f\u826b\ucad2\ucb4e"
        //  1807: goto            1811
        //  1810: athrow         
        //  1811: invokestatic    invokestatic   !!! ERROR
        //  1814: goto            1818
        //  1817: athrow         
        //  1818: goto            1822
        //  1821: athrow         
        //  1822: invokespecial   kotlin/TypeCastException.<init>:(Ljava/lang/String;)V
        //  1825: goto            1829
        //  1828: athrow         
        //  1829: athrow         
        //  1830: checkcast       Lnet/minecraft/network/play/client/CPacketEntityAction;
        //  1833: goto            1837
        //  1836: athrow         
        //  1837: invokevirtual   net/minecraft/network/play/client/CPacketEntityAction.func_180764_b:()Lnet/minecraft/network/play/client/CPacketEntityAction$Action;
        //  1840: goto            1844
        //  1843: athrow         
        //  1844: getstatic       net/minecraft/network/play/client/CPacketEntityAction$Action.OPEN_INVENTORY:Lnet/minecraft/network/play/client/CPacketEntityAction$Action;
        //  1847: if_acmpeq       1862
        //  1850: aload_1        
        //  1851: goto            1855
        //  1854: athrow         
        //  1855: invokevirtual   dev/nuker/pyro/f49.0:()V
        //  1858: goto            1862
        //  1861: athrow         
        //  1862: return         
        //  1863: aconst_null    
        //  1864: athrow         
        //  1865: aconst_null    
        //  1866: athrow         
        //  1867: aconst_null    
        //  1868: athrow         
        //  1869: aconst_null    
        //  1870: athrow         
        //  1871: aconst_null    
        //  1872: athrow         
        //  1873: aconst_null    
        //  1874: athrow         
        //  1875: aconst_null    
        //  1876: athrow         
        //  1877: aconst_null    
        //  1878: athrow         
        //  1879: aconst_null    
        //  1880: athrow         
        //  1881: aconst_null    
        //  1882: athrow         
        //  1883: aconst_null    
        //  1884: athrow         
        //  1885: aconst_null    
        //  1886: athrow         
        //  1887: aconst_null    
        //  1888: athrow         
        //  1889: aconst_null    
        //  1890: athrow         
        //  1891: aconst_null    
        //  1892: athrow         
        //  1893: aconst_null    
        //  1894: athrow         
        //  1895: aconst_null    
        //  1896: athrow         
        //  1897: aconst_null    
        //  1898: athrow         
        //  1899: aconst_null    
        //  1900: athrow         
        //  1901: aconst_null    
        //  1902: athrow         
        //  1903: aconst_null    
        //  1904: athrow         
        //  1905: pop            
        //  1906: goto            24
        //  1909: pop            
        //  1910: aconst_null    
        //  1911: goto            1905
        //  1914: dup            
        //  1915: ifnull          1905
        //  1918: checkcast       Ljava/lang/Throwable;
        //  1921: athrow         
        //  1922: dup            
        //  1923: ifnull          1909
        //  1926: checkcast       Ljava/lang/Throwable;
        //  1929: athrow         
        //  1930: aconst_null    
        //  1931: athrow         
        //    StackMapTable: 01 16 43 07 00 47 04 FF 00 0B 00 00 00 01 07 00 47 FD 00 03 07 00 03 07 02 FC 4E 07 02 FC FF 00 02 00 02 07 00 03 07 02 FC 00 02 07 02 FC 01 5D 07 02 FC 42 07 00 47 40 07 02 FC 45 07 00 47 40 07 00 4E 05 05 42 01 19 43 07 00 47 40 07 02 FC 45 07 00 47 40 01 46 07 00 47 40 07 02 FC 45 07 00 47 40 07 01 DC FC 00 07 07 01 DC 05 42 01 1B 43 07 00 47 40 07 02 FC 45 07 00 47 40 07 01 DC FF 00 16 00 03 07 00 03 07 02 FC 07 01 DC 00 04 07 01 DC 08 00 D4 08 00 D4 07 01 A3 FF 00 02 00 03 07 00 03 07 02 FC 07 01 DC 00 05 07 01 DC 08 00 D4 08 00 D4 07 01 A3 01 FF 00 1D 00 03 07 00 03 07 02 FC 07 01 DC 00 04 07 01 DC 08 00 D4 08 00 D4 07 01 A3 42 07 00 47 FF 00 00 00 03 07 00 03 07 02 FC 07 01 DC 00 04 07 01 DC 08 00 D4 08 00 D4 07 01 A3 45 07 00 47 FF 00 00 00 03 07 00 03 07 02 FC 07 01 DC 00 04 07 01 DC 08 00 D4 08 00 D4 07 01 A3 42 07 00 47 FF 00 00 00 03 07 00 03 07 02 FC 07 01 DC 00 04 07 01 DC 08 00 D4 08 00 D4 07 01 A3 45 07 00 47 FF 00 00 00 03 07 00 03 07 02 FC 07 01 DC 00 02 07 01 DC 07 00 68 40 07 01 DC 4E 07 03 04 FF 00 02 00 03 07 00 03 07 02 FC 07 01 DC 00 02 07 03 04 01 5E 07 03 04 FF 00 07 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 01 07 00 47 40 07 02 06 45 07 00 47 40 07 01 E0 4E 07 01 89 FF 00 02 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 02 07 01 89 01 5D 07 01 89 42 07 00 35 40 07 01 89 45 07 00 47 40 01 0E 42 01 1E 56 07 00 87 FF 00 02 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 02 07 00 87 01 5D 07 00 87 50 07 00 90 FF 00 02 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 02 07 00 90 01 5F 07 00 90 42 07 00 47 40 07 00 90 45 07 00 47 40 07 00 C1 46 07 00 23 40 07 00 C1 45 07 00 47 40 07 00 C1 05 05 42 01 1A FF 00 13 00 00 00 01 07 00 47 FF 00 00 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 03 07 00 CF 05 07 00 90 45 07 00 47 FF 00 00 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 03 07 00 CF 05 07 00 C1 FF 00 03 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 03 07 00 CF 05 07 00 C1 FF 00 05 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 03 07 00 CF 05 07 00 C1 FF 00 02 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 04 07 00 CF 05 07 00 C1 01 FF 00 1A 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 03 07 00 CF 05 07 00 C1 42 07 00 47 FF 00 00 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 03 07 00 CF 05 07 00 C1 45 07 00 47 FF 00 00 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 03 07 00 CF 05 07 00 C1 44 07 00 47 FF 00 00 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 03 07 00 CF 05 07 00 C1 45 07 00 47 FF 00 00 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 03 07 00 CF 05 07 00 C9 45 07 00 47 FF 00 00 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 04 07 00 CF 05 07 00 C9 03 45 07 00 47 FF 00 00 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 03 07 00 CF 05 07 00 C9 FF 00 10 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 06 07 00 CF 05 07 00 C9 03 03 03 FF 00 02 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 07 07 00 CF 05 07 00 C9 03 03 03 01 FF 00 1D 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 06 07 00 CF 05 07 00 C9 03 03 03 42 07 00 2B FF 00 00 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 06 07 00 CF 05 07 00 C9 03 03 03 45 07 00 47 FF 00 00 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 03 07 00 CF 05 07 00 C9 42 07 00 47 FF 00 00 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 03 07 00 CF 05 07 00 C9 45 07 00 47 40 07 01 DE 4B 07 01 DE FF 00 02 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 02 07 01 DE 01 5E 07 01 DE FF 00 02 00 00 00 01 07 00 47 FF 00 00 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 01 07 01 DE 47 07 00 47 40 01 4B 07 00 2B 40 07 02 FC 45 07 00 47 40 07 01 DC 43 07 01 DC 45 07 01 DC FF 00 02 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 02 07 01 DC 01 59 07 01 DC 49 07 00 2B FF 00 00 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 04 07 01 DC 08 03 A4 08 03 A4 07 01 A3 45 07 00 47 FF 00 00 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 04 07 01 DC 08 03 A4 08 03 A4 07 01 A3 42 07 00 27 FF 00 00 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 04 07 01 DC 08 03 A4 08 03 A4 07 01 A3 45 07 00 47 FF 00 00 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 02 07 01 DC 07 00 68 40 07 01 DC 46 07 00 47 FF 00 00 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 02 07 03 3A 07 03 04 45 07 00 47 FF 00 00 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 02 07 03 3A 03 FF 00 06 00 00 00 01 07 00 47 FF 00 00 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 02 07 03 3A 03 47 07 00 47 00 FA 00 02 FF 00 0A 00 00 00 01 07 00 47 FF 00 00 00 03 07 00 03 07 02 FC 07 01 DC 00 01 07 02 FC 45 07 00 47 00 02 5B 07 00 90 FF 00 02 00 03 07 00 03 07 02 FC 07 01 DC 00 02 07 00 90 01 5D 07 00 90 42 07 00 47 40 07 00 90 45 07 00 47 40 01 0E 42 01 1E 4C 07 02 FC FF 00 02 00 03 07 00 03 07 02 FC 07 01 DC 00 02 07 02 FC 01 5F 07 02 FC 42 07 00 47 40 07 02 FC 45 07 00 47 40 07 01 DC 4D 07 00 47 FF 00 00 00 03 07 00 03 07 02 FC 07 01 DC 00 04 07 01 DC 08 04 B3 08 04 B3 07 01 A3 45 07 00 47 FF 00 00 00 03 07 00 03 07 02 FC 07 01 DC 00 04 07 01 DC 08 04 B3 08 04 B3 07 01 A3 42 07 00 39 FF 00 00 00 03 07 00 03 07 02 FC 07 01 DC 00 04 07 01 DC 08 04 B3 08 04 B3 07 01 A3 45 07 00 47 FF 00 00 00 03 07 00 03 07 02 FC 07 01 DC 00 02 07 01 DC 07 00 68 40 07 01 DC 4E 07 03 48 FF 00 02 00 03 07 00 03 07 02 FC 07 01 DC 00 02 07 03 48 01 5C 07 03 48 42 07 00 47 40 07 03 48 45 07 00 47 40 01 4F 07 00 03 FF 00 02 00 03 07 00 03 07 02 FC 07 01 DC 00 02 07 00 03 01 5D 07 00 03 4E 07 00 87 FF 00 02 00 03 07 00 03 07 02 FC 07 01 DC 00 02 07 00 87 01 5D 07 00 87 47 07 00 2B 40 07 00 90 45 07 00 47 40 07 00 C1 4F 07 00 C1 FF 00 02 00 03 07 00 03 07 02 FC 07 01 DC 00 02 07 00 C1 01 5C 07 00 C1 42 07 00 47 40 07 00 C1 45 07 00 47 40 07 00 C1 05 43 07 00 35 40 07 02 FC 45 07 00 47 00 02 0B 42 01 1C 53 07 00 03 FF 00 02 00 03 07 00 03 07 02 FC 07 01 DC 00 02 07 00 03 01 5C 07 00 03 4A 07 00 47 40 07 00 90 45 07 00 47 40 01 0E 42 01 1E 43 07 00 33 40 07 02 FC 45 07 00 47 00 02 53 07 00 03 FF 00 02 00 03 07 00 03 07 02 FC 07 01 DC 00 02 07 00 03 01 5D 07 00 03 4A 07 00 47 40 07 00 90 45 07 00 47 40 01 0E 42 01 1E 43 07 00 47 40 07 02 FC 45 07 00 47 40 07 01 DC 4D 07 00 47 FF 00 00 00 03 07 00 03 07 02 FC 07 01 DC 00 04 07 01 DC 08 07 08 08 07 08 07 01 A3 45 07 00 47 FF 00 00 00 03 07 00 03 07 02 FC 07 01 DC 00 04 07 01 DC 08 07 08 08 07 08 07 01 A3 42 07 00 47 FF 00 00 00 03 07 00 03 07 02 FC 07 01 DC 00 04 07 01 DC 08 07 08 08 07 08 07 01 A3 45 07 00 47 FF 00 00 00 03 07 00 03 07 02 FC 07 01 DC 00 02 07 01 DC 07 00 68 40 07 01 DC 45 07 00 47 40 07 03 6F 45 07 00 47 40 07 03 7D 49 07 00 47 40 07 02 FC 45 07 00 47 FA 00 00 FC 00 00 07 01 DC 41 07 00 C1 FF 00 01 00 02 07 00 03 07 02 FC 00 01 07 02 FC FF 00 01 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 01 07 00 90 FF 00 01 00 03 07 00 03 07 02 FC 07 01 DC 00 01 07 00 87 41 07 03 04 01 FF 00 01 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 01 07 01 89 41 07 01 DE FF 00 01 00 03 07 00 03 07 02 FC 07 01 DC 00 01 07 00 03 41 07 00 03 01 FC 00 01 07 03 04 FF 00 01 00 03 07 00 03 07 02 FC 07 01 DC 00 01 07 00 03 41 07 02 FC FF 00 01 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 01 07 00 87 FA 00 01 41 07 00 90 FF 00 01 00 03 07 00 03 07 02 FC 07 01 DC 00 04 07 01 DC 08 00 D4 08 00 D4 07 01 A3 FF 00 01 00 04 07 00 03 07 02 FC 07 01 DC 07 03 04 00 06 07 00 CF 05 07 00 C9 03 03 03 FF 00 01 00 03 07 00 03 07 02 FC 07 01 DC 00 01 07 03 48 FF 00 01 00 02 07 00 03 07 02 FC 00 01 07 00 47 43 05 44 07 00 47 47 05 47 07 00 47
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     1914   1922   Any
        //  1914   1922   1914   1922   Any
        //  1930   1932   3      8      Ljava/lang/NullPointerException;
        //  75     82     82     83     Any
        //  76     82     75     76     Ljava/util/NoSuchElementException;
        //  76     82     82     83     Ljava/lang/NullPointerException;
        //  76     82     75     76     Any
        //  76     82     75     76     Any
        //  128    135    135    136    Any
        //  129    135    3      8      Ljava/util/ConcurrentModificationException;
        //  129    135    3      8      Any
        //  129    135    128    129    Ljava/lang/NullPointerException;
        //  128    135    128    129    Any
        //  143    150    150    151    Any
        //  144    150    143    144    Any
        //  144    150    150    151    Ljava/lang/NumberFormatException;
        //  143    150    143    144    Any
        //  143    150    150    151    Ljava/lang/ClassCastException;
        //  200    207    207    208    Any
        //  200    207    207    208    Ljava/lang/NullPointerException;
        //  201    207    200    201    Any
        //  201    207    200    201    Ljava/util/ConcurrentModificationException;
        //  200    207    200    201    Any
        //  267    274    274    275    Any
        //  268    274    274    275    Any
        //  268    274    3      8      Any
        //  268    274    267    268    Any
        //  267    274    3      8      Ljava/lang/AssertionError;
        //  278    285    285    286    Any
        //  279    285    285    286    Ljava/lang/RuntimeException;
        //  279    285    3      8      Any
        //  278    285    285    286    Any
        //  278    285    278    279    Any
        //  344    351    351    352    Any
        //  344    351    344    345    Any
        //  345    351    351    352    Ljava/lang/ClassCastException;
        //  344    351    351    352    Ljava/lang/NumberFormatException;
        //  345    351    351    352    Any
        //  403    410    410    411    Any
        //  403    410    3      8      Ljava/lang/ClassCastException;
        //  404    410    410    411    Ljava/lang/AssertionError;
        //  404    410    3      8      Any
        //  404    410    403    404    Ljava/lang/IllegalStateException;
        //  571    578    578    579    Any
        //  571    578    578    579    Any
        //  571    578    578    579    Ljava/lang/UnsupportedOperationException;
        //  572    578    571    572    Any
        //  571    578    578    579    Any
        //  586    593    593    594    Any
        //  587    593    593    594    Ljava/lang/NegativeArraySizeException;
        //  587    593    593    594    Ljava/lang/RuntimeException;
        //  587    593    3      8      Ljava/lang/NullPointerException;
        //  587    593    586    587    Ljava/lang/EnumConstantNotPresentException;
        //  657    663    663    664    Any
        //  657    663    663    664    Any
        //  657    663    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  657    663    663    664    Ljava/lang/UnsupportedOperationException;
        //  657    663    663    664    Any
        //  707    714    714    715    Any
        //  708    714    3      8      Ljava/lang/ClassCastException;
        //  708    714    714    715    Any
        //  708    714    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  707    714    707    708    Any
        //  720    727    727    728    Any
        //  721    727    720    721    Ljava/util/NoSuchElementException;
        //  721    727    3      8      Ljava/lang/NumberFormatException;
        //  720    727    720    721    Any
        //  721    727    727    728    Any
        //  734    741    741    742    Any
        //  734    741    741    742    Any
        //  734    741    3      8      Any
        //  734    741    734    735    Any
        //  735    741    3      8      Ljava/lang/ClassCastException;
        //  795    802    802    803    Any
        //  795    802    795    796    Ljava/lang/UnsupportedOperationException;
        //  796    802    3      8      Any
        //  795    802    795    796    Ljava/util/NoSuchElementException;
        //  796    802    795    796    Ljava/lang/IllegalArgumentException;
        //  806    813    813    814    Any
        //  807    813    806    807    Any
        //  807    813    806    807    Any
        //  807    813    806    807    Ljava/util/NoSuchElementException;
        //  807    813    3      8      Ljava/util/NoSuchElementException;
        //  864    872    872    873    Any
        //  864    872    872    873    Ljava/lang/NumberFormatException;
        //  864    872    3      8      Any
        //  864    872    872    873    Ljava/lang/IllegalStateException;
        //  864    872    872    873    Ljava/lang/IllegalStateException;
        //  885    892    892    893    Any
        //  885    892    892    893    Ljava/lang/ClassCastException;
        //  885    892    885    886    Ljava/lang/IndexOutOfBoundsException;
        //  885    892    885    886    Ljava/lang/RuntimeException;
        //  886    892    885    886    Ljava/lang/IllegalArgumentException;
        //  942    949    949    950    Any
        //  943    949    949    950    Ljava/lang/IndexOutOfBoundsException;
        //  942    949    949    950    Ljava/lang/AssertionError;
        //  942    949    942    943    Ljava/lang/RuntimeException;
        //  942    949    942    943    Ljava/util/NoSuchElementException;
        //  953    960    960    961    Any
        //  954    960    953    954    Ljava/lang/NumberFormatException;
        //  953    960    960    961    Ljava/lang/ArithmeticException;
        //  953    960    953    954    Ljava/lang/NumberFormatException;
        //  954    960    3      8      Ljava/lang/IllegalStateException;
        //  969    976    976    977    Any
        //  970    976    3      8      Ljava/lang/IllegalArgumentException;
        //  969    976    976    977    Ljava/lang/ClassCastException;
        //  970    976    969    970    Any
        //  970    976    3      8      Any
        //  985    993    993    994    Any
        //  985    993    993    994    Ljava/lang/EnumConstantNotPresentException;
        //  985    993    993    994    Ljava/util/NoSuchElementException;
        //  985    993    3      8      Ljava/lang/UnsupportedOperationException;
        //  985    993    3      8      Ljava/lang/ArithmeticException;
        //  1009   1015   1015   1016   Any
        //  1009   1015   1015   1016   Ljava/lang/IndexOutOfBoundsException;
        //  1009   1015   3      8      Ljava/util/NoSuchElementException;
        //  1009   1015   1015   1016   Any
        //  1009   1015   1015   1016   Any
        //  1083   1090   1090   1091   Any
        //  1083   1090   1083   1084   Any
        //  1084   1090   1090   1091   Ljava/lang/NumberFormatException;
        //  1083   1090   1083   1084   Ljava/lang/EnumConstantNotPresentException;
        //  1083   1090   3      8      Ljava/lang/ArithmeticException;
        //  1191   1198   1198   1199   Any
        //  1192   1198   3      8      Any
        //  1192   1198   1191   1192   Any
        //  1191   1198   1198   1199   Ljava/lang/EnumConstantNotPresentException;
        //  1192   1198   1191   1192   Any
        //  1213   1220   1220   1221   Any
        //  1213   1220   1213   1214   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1213   1220   1213   1214   Any
        //  1214   1220   1220   1221   Any
        //  1213   1220   3      8      Ljava/lang/IllegalStateException;
        //  1224   1231   1231   1232   Any
        //  1224   1231   1231   1232   Any
        //  1224   1231   1231   1232   Ljava/lang/EnumConstantNotPresentException;
        //  1225   1231   3      8      Ljava/lang/EnumConstantNotPresentException;
        //  1224   1231   1224   1225   Ljava/lang/IllegalArgumentException;
        //  1283   1290   1290   1291   Any
        //  1284   1290   1283   1284   Any
        //  1284   1290   1283   1284   Ljava/lang/RuntimeException;
        //  1283   1290   1283   1284   Any
        //  1283   1290   1290   1291   Any
        //  1396   1403   1403   1404   Any
        //  1397   1403   3      8      Any
        //  1397   1403   3      8      Any
        //  1397   1403   1403   1404   Any
        //  1397   1403   1396   1397   Ljava/lang/RuntimeException;
        //  1455   1462   1462   1463   Any
        //  1456   1462   3      8      Any
        //  1456   1462   1462   1463   Any
        //  1456   1462   1462   1463   Any
        //  1455   1462   1455   1456   Any
        //  1473   1480   1480   1481   Any
        //  1474   1480   1480   1481   Any
        //  1473   1480   3      8      Any
        //  1474   1480   3      8      Any
        //  1474   1480   1473   1474   Ljava/lang/IllegalStateException;
        //  1591   1598   1598   1599   Any
        //  1591   1598   1598   1599   Ljava/lang/StringIndexOutOfBoundsException;
        //  1592   1598   1598   1599   Any
        //  1591   1598   3      8      Ljava/lang/IllegalArgumentException;
        //  1592   1598   1591   1592   Any
        //  1652   1659   1659   1660   Any
        //  1653   1659   1652   1653   Ljava/lang/ClassCastException;
        //  1652   1659   3      8      Ljava/lang/IndexOutOfBoundsException;
        //  1652   1659   1659   1660   Any
        //  1653   1659   1659   1660   Ljava/lang/NumberFormatException;
        //  1727   1734   1734   1735   Any
        //  1727   1734   1727   1728   Any
        //  1728   1734   1734   1735   Any
        //  1727   1734   3      8      Any
        //  1728   1734   1734   1735   Ljava/lang/IllegalArgumentException;
        //  1788   1795   1795   1796   Any
        //  1789   1795   1788   1789   Any
        //  1789   1795   1795   1796   Ljava/lang/IllegalArgumentException;
        //  1789   1795   3      8      Ljava/lang/ClassCastException;
        //  1788   1795   1795   1796   Ljava/util/ConcurrentModificationException;
        //  1810   1817   1817   1818   Any
        //  1810   1817   1810   1811   Any
        //  1810   1817   3      8      Ljava/lang/ArithmeticException;
        //  1810   1817   3      8      Any
        //  1810   1817   1817   1818   Any
        //  1821   1828   1828   1829   Any
        //  1822   1828   1821   1822   Any
        //  1821   1828   1828   1829   Ljava/lang/NumberFormatException;
        //  1821   1828   3      8      Ljava/util/ConcurrentModificationException;
        //  1822   1828   3      8      Any
        //  1836   1843   1843   1844   Any
        //  1837   1843   1836   1837   Any
        //  1836   1843   1843   1844   Ljava/util/NoSuchElementException;
        //  1836   1843   3      8      Any
        //  1837   1843   1843   1844   Any
        //  1854   1861   1861   1862   Any
        //  1855   1861   1854   1855   Any
        //  1855   1861   1861   1862   Any
        //  1854   1861   1854   1855   Any
        //  1855   1861   3      8      Ljava/lang/EnumConstantNotPresentException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:667)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void c(final float n) {
        fez.aZ(this, 1933853657, n);
    }
    
    public float 9() {
        return fez.ew(this, 1790875549);
    }
    
    @NotNull
    public f0k 1() {
        return fez.6U(this, 2116858708);
    }
    
    public void 3() {
        fez.gB(this, 91578622);
    }
    
    @NotNull
    public f0m 5() {
        return fez.9k(this, 306313983);
    }
    
    @NotNull
    public f0m 0() {
        return fez.9b(this, 46304294);
    }
    
    @NotNull
    public f0p 2() {
        return fez.4U(this, 1065136489);
    }
}
