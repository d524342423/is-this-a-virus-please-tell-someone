// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import org.jetbrains.annotations.NotNull;

public class faz extends far
{
    public double c;
    public double 0;
    public int c;
    public int 0;
    public boolean c;
    
    public faz() {
        final int c = 4;
        while (true) {
            int n = 0;
            Label_0019: {
                if (fc.1 == 0) {
                    n = 361547220;
                    break Label_0019;
                }
                n = 1266495406;
            }
            switch (n ^ 0xBDBCECC4) {
                case -1746007262: {
                    continue;
                }
                default: {
                    this.c = c;
                    this.c = far.1();
                }
                case -1473238768: {
                    throw null;
                }
            }
            break;
        }
    }
    
    @Override
    public void c(@NotNull final f4p p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          3094
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            3086
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            3078
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: aload_1        
        //    27: goto            31
        //    30: athrow         
        //    31: invokevirtual   dev/nuker/pyro/f4p.c:()Ldev/nuker/pyro/f41;
        //    34: goto            38
        //    37: athrow         
        //    38: getstatic       dev/nuker/pyro/f41.c:Ldev/nuker/pyro/f41;
        //    41: if_acmpne       143
        //    44: getstatic       dev/nuker/pyro/fc.1:I
        //    47: ifne            55
        //    50: ldc             -384730461
        //    52: goto            57
        //    55: ldc             505909460
        //    57: ldc             -1850367538
        //    59: ixor           
        //    60: lookupswitch {
        //          109530856: 55
        //          2024069997: 2991
        //          default: 88
        //        }
        //    88: getstatic       dev/nuker/pyro/f64.c:Ldev/nuker/pyro/fdk;
        //    91: getfield        dev/nuker/pyro/fdk.c:Ldev/nuker/pyro/fw;
        //    94: goto            98
        //    97: athrow         
        //    98: invokevirtual   dev/nuker/pyro/fw.0:()Ljava/lang/Object;
        //   101: goto            105
        //   104: athrow         
        //   105: dup            
        //   106: pop            
        //   107: checkcast       Ljava/lang/Boolean;
        //   110: goto            114
        //   113: athrow         
        //   114: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   117: goto            121
        //   120: athrow         
        //   121: ifeq            128
        //   124: iconst_1       
        //   125: goto            140
        //   128: aload_1        
        //   129: goto            133
        //   132: athrow         
        //   133: invokevirtual   dev/nuker/pyro/f4p.c:()Z
        //   136: goto            140
        //   139: athrow         
        //   140: ifeq            144
        //   143: return         
        //   144: goto            148
        //   147: athrow         
        //   148: invokestatic    dev/nuker/pyro/fec.a:()Z
        //   151: goto            155
        //   154: athrow         
        //   155: ifeq            204
        //   158: getstatic       dev/nuker/pyro/far.c:Lnet/minecraft/client/Minecraft;
        //   161: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   164: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70143_R:F
        //   167: ldc             5.0
        //   169: fcmpl          
        //   170: ifle            178
        //   173: ldc             -872808547
        //   175: goto            180
        //   178: ldc             -872808548
        //   180: ldc             -1392569083
        //   182: ixor           
        //   183: tableswitch {
        //          -837954256: 204
        //          -837954255: 276
        //          default: 173
        //        }
        //   204: getstatic       dev/nuker/pyro/fc.c:I
        //   207: ifne            215
        //   210: ldc             -1617900258
        //   212: goto            217
        //   215: ldc             578157002
        //   217: ldc             -1500436668
        //   219: ixor           
        //   220: lookupswitch {
        //          956426842: 3027
        //          1814393691: 215
        //          default: 248
        //        }
        //   248: getstatic       dev/nuker/pyro/f0b.c:Ldev/nuker/pyro/f0b;
        //   251: ldc             "\u37f3\ub255\u84b7\uafb0\u6aa4\u530d\u7e41\u63bd"
        //   253: goto            257
        //   256: athrow         
        //   257: invokestatic    invokestatic   !!! ERROR
        //   260: goto            264
        //   263: athrow         
        //   264: goto            268
        //   267: athrow         
        //   268: invokevirtual   dev/nuker/pyro/f0b.1:(Ljava/lang/String;)V
        //   271: goto            275
        //   274: athrow         
        //   275: return         
        //   276: getstatic       dev/nuker/pyro/f64.c:Ldev/nuker/pyro/f9Y;
        //   279: getstatic       dev/nuker/pyro/fc.0:I
        //   282: ifgt            290
        //   285: ldc             -803001108
        //   287: goto            292
        //   290: ldc             968690371
        //   292: ldc             -1338594703
        //   294: ixor           
        //   295: lookupswitch {
        //          -1987338062: 320
        //          1612023453: 290
        //          default: 3029
        //        }
        //   320: getfield        dev/nuker/pyro/f9Y.c:Ldev/nuker/pyro/fw;
        //   323: goto            327
        //   326: athrow         
        //   327: invokevirtual   dev/nuker/pyro/fw.0:()Ljava/lang/Object;
        //   330: goto            334
        //   333: athrow         
        //   334: dup            
        //   335: pop            
        //   336: checkcast       Ljava/lang/Boolean;
        //   339: getstatic       dev/nuker/pyro/fc.c:I
        //   342: ifne            350
        //   345: ldc             511950150
        //   347: goto            352
        //   350: ldc             -423680309
        //   352: ldc             -499364482
        //   354: ixor           
        //   355: lookupswitch {
        //          -54529992: 350
        //          75721653: 380
        //          default: 3053
        //        }
        //   380: goto            384
        //   383: athrow         
        //   384: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   387: goto            391
        //   390: athrow         
        //   391: ifeq            529
        //   394: getstatic       dev/nuker/pyro/f64.c:Ldev/nuker/pyro/f9Y;
        //   397: getstatic       dev/nuker/pyro/f64.c:Ldev/nuker/pyro/f9Y;
        //   400: getfield        dev/nuker/pyro/f9Y.c:Ldev/nuker/pyro/f0m;
        //   403: getstatic       dev/nuker/pyro/fc.1:I
        //   406: ifne            414
        //   409: ldc             -219129307
        //   411: goto            416
        //   414: ldc             -329598374
        //   416: ldc             -2080197850
        //   418: ixor           
        //   419: lookupswitch {
        //          -1728052445: 414
        //          1995630851: 3059
        //          default: 444
        //        }
        //   444: goto            448
        //   447: athrow         
        //   448: invokevirtual   dev/nuker/pyro/f0m.c:()Ljava/lang/Object;
        //   451: goto            455
        //   454: athrow         
        //   455: checkcast       Ljava/lang/Number;
        //   458: getstatic       dev/nuker/pyro/fc.0:I
        //   461: ifgt            469
        //   464: ldc             2114879811
        //   466: goto            471
        //   469: ldc             -569467316
        //   471: ldc             -1238180094
        //   473: ixor           
        //   474: lookupswitch {
        //          -935567807: 2997
        //          1149615935: 469
        //          default: 500
        //        }
        //   500: goto            504
        //   503: athrow         
        //   504: invokevirtual   java/lang/Number.doubleValue:()D
        //   507: goto            511
        //   510: athrow         
        //   511: goto            515
        //   514: athrow         
        //   515: invokevirtual   dev/nuker/pyro/f9Y.c:(D)D
        //   518: goto            522
        //   521: athrow         
        //   522: fconst_0       
        //   523: f2d            
        //   524: dcmpl          
        //   525: ifle            529
        //   528: return         
        //   529: getstatic       dev/nuker/pyro/f64.c:Ldev/nuker/pyro/f9T;
        //   532: getstatic       dev/nuker/pyro/fc.1:I
        //   535: ifne            543
        //   538: ldc             1614828331
        //   540: goto            545
        //   543: ldc             -1343079260
        //   545: ldc             1913842541
        //   547: ixor           
        //   548: lookupswitch {
        //          -572467255: 576
        //          307411014: 543
        //          default: 3025
        //        }
        //   576: goto            580
        //   579: athrow         
        //   580: invokevirtual   dev/nuker/pyro/f9T.1:()Ldev/nuker/pyro/f0k;
        //   583: goto            587
        //   586: athrow         
        //   587: getstatic       dev/nuker/pyro/fc.0:I
        //   590: ifgt            598
        //   593: ldc             1222873580
        //   595: goto            600
        //   598: ldc             -708538670
        //   600: ldc             -507325068
        //   602: ixor           
        //   603: lookupswitch {
        //          -1457437544: 3035
        //          1271788668: 598
        //          default: 628
        //        }
        //   628: goto            632
        //   631: athrow         
        //   632: invokevirtual   dev/nuker/pyro/f0k.c:()Ljava/lang/Object;
        //   635: goto            639
        //   638: athrow         
        //   639: checkcast       Ljava/lang/Boolean;
        //   642: getstatic       dev/nuker/pyro/fc.0:I
        //   645: ifgt            653
        //   648: ldc             315305538
        //   650: goto            655
        //   653: ldc             -1359941855
        //   655: ldc             -1072176734
        //   657: ixor           
        //   658: lookupswitch {
        //          -757280800: 653
        //          1860636291: 684
        //          default: 3009
        //        }
        //   684: goto            688
        //   687: athrow         
        //   688: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   691: goto            695
        //   694: athrow         
        //   695: ifeq            771
        //   698: getstatic       dev/nuker/pyro/f0b.c:Ldev/nuker/pyro/f0b;
        //   701: ldc             "\u37f3\ub255\u84b7\uafb0\u6aa4\u530d\u7e41\u63bd"
        //   703: getstatic       dev/nuker/pyro/fc.c:I
        //   706: ifne            714
        //   709: ldc             -1744640707
        //   711: goto            716
        //   714: ldc             -1473558534
        //   716: ldc             1098928244
        //   718: ixor           
        //   719: lookupswitch {
        //          -1821133634: 714
        //          -645745335: 3039
        //          default: 744
        //        }
        //   744: goto            748
        //   747: athrow         
        //   748: invokestatic    invokestatic   !!! ERROR
        //   751: goto            755
        //   754: athrow         
        //   755: getstatic       dev/nuker/pyro/f07.0:Ldev/nuker/pyro/f07;
        //   758: ldc             1.088
        //   760: goto            764
        //   763: athrow         
        //   764: invokevirtual   dev/nuker/pyro/f0b.c:(Ljava/lang/String;Ldev/nuker/pyro/f07;F)V
        //   767: goto            771
        //   770: athrow         
        //   771: getstatic       dev/nuker/pyro/far.c:Lnet/minecraft/client/Minecraft;
        //   774: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   777: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70123_F:Z
        //   780: ifeq            1797
        //   783: getstatic       dev/nuker/pyro/far.c:Lnet/minecraft/client/Minecraft;
        //   786: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   789: getstatic       dev/nuker/pyro/fc.0:I
        //   792: ifgt            800
        //   795: ldc             -1711087281
        //   797: goto            802
        //   800: ldc             2059253217
        //   802: ldc             925788248
        //   804: ixor           
        //   805: lookupswitch {
        //          -1389590249: 3045
        //          895483667: 800
        //          default: 832
        //        }
        //   832: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70122_E:Z
        //   835: ifeq            957
        //   838: getstatic       dev/nuker/pyro/f64.c:Ldev/nuker/pyro/f9Y;
        //   841: dconst_1       
        //   842: goto            846
        //   845: athrow         
        //   846: invokevirtual   dev/nuker/pyro/f9Y.c:(D)D
        //   849: goto            853
        //   852: athrow         
        //   853: dstore_2       
        //   854: getstatic       dev/nuker/pyro/fc.1:I
        //   857: ifne            865
        //   860: ldc             -1897459717
        //   862: goto            867
        //   865: ldc             -791213735
        //   867: ldc             1874086056
        //   869: ixor           
        //   870: lookupswitch {
        //          -1084014095: 896
        //          -514635949: 865
        //          default: 2989
        //        }
        //   896: dload_2        
        //   897: dconst_1       
        //   898: dcmpg          
        //   899: ifne            957
        //   902: getstatic       dev/nuker/pyro/fc.1:I
        //   905: ifne            913
        //   908: ldc             2003097062
        //   910: goto            915
        //   913: ldc             1541850284
        //   915: ldc             1461265628
        //   917: ixor           
        //   918: lookupswitch {
        //          -2133631451: 913
        //          545124666: 3003
        //          default: 944
        //        }
        //   944: aload_0        
        //   945: dup            
        //   946: getfield        dev/nuker/pyro/faz.0:I
        //   949: dup            
        //   950: istore          5
        //   952: iconst_1       
        //   953: iadd           
        //   954: putfield        dev/nuker/pyro/faz.0:I
        //   957: getstatic       dev/nuker/pyro/fc.1:I
        //   960: ifne            968
        //   963: ldc             -703641992
        //   965: goto            970
        //   968: ldc             867934709
        //   970: ldc             175522829
        //   972: ixor           
        //   973: lookupswitch {
        //          -596049291: 968
        //          969795064: 1000
        //          default: 3049
        //        }
        //  1000: aload_0        
        //  1001: getfield        dev/nuker/pyro/faz.0:I
        //  1004: ifle            1012
        //  1007: ldc             236081506
        //  1009: goto            1014
        //  1012: ldc             236081505
        //  1014: ldc             1133725307
        //  1016: ixor           
        //  1017: tableswitch {
        //          -1694355918: 1040
        //          -1694355917: 1797
        //          default: 1007
        //        }
        //  1040: getstatic       dev/nuker/pyro/fc.1:I
        //  1043: ifne            1051
        //  1046: ldc             1208961458
        //  1048: goto            1053
        //  1051: ldc             342357013
        //  1053: ldc             -129904344
        //  1055: ixor           
        //  1056: lookupswitch {
        //          -1337026406: 1051
        //          -333044419: 1084
        //          default: 3047
        //        }
        //  1084: aload_0        
        //  1085: getstatic       dev/nuker/pyro/fc.1:I
        //  1088: ifne            1096
        //  1091: ldc             -1679029355
        //  1093: goto            1098
        //  1096: ldc             1013376671
        //  1098: ldc             -175354967
        //  1100: ixor           
        //  1101: lookupswitch {
        //          -907367114: 1128
        //          1851801660: 1096
        //          default: 3041
        //        }
        //  1128: getfield        dev/nuker/pyro/faz.0:I
        //  1131: tableswitch {
        //                2: 1156
        //                3: 1324
        //                4: 1589
        //          default: 1796
        //        }
        //  1156: aload_1        
        //  1157: getstatic       dev/nuker/pyro/fc.0:I
        //  1160: ifgt            1168
        //  1163: ldc             402845576
        //  1165: goto            1170
        //  1168: ldc             -2019649003
        //  1170: ldc             451690927
        //  1172: ixor           
        //  1173: lookupswitch {
        //          49196583: 3013
        //          1638038067: 1168
        //          default: 1200
        //        }
        //  1200: goto            1204
        //  1203: athrow         
        //  1204: invokevirtual   dev/nuker/pyro/f4p.0:()V
        //  1207: goto            1211
        //  1210: athrow         
        //  1211: aload_1        
        //  1212: ldc2_w          0.41999998688698
        //  1215: goto            1219
        //  1218: athrow         
        //  1219: invokevirtual   dev/nuker/pyro/f4p.1:(D)V
        //  1222: goto            1226
        //  1225: athrow         
        //  1226: aload_0        
        //  1227: dup            
        //  1228: getstatic       dev/nuker/pyro/fc.c:I
        //  1231: ifne            1239
        //  1234: ldc             408617111
        //  1236: goto            1241
        //  1239: ldc             1831241289
        //  1241: ldc             1024141319
        //  1243: ixor           
        //  1244: lookupswitch {
        //          626010256: 1239
        //          1345171022: 1272
        //          default: 3011
        //        }
        //  1272: getfield        dev/nuker/pyro/faz.0:I
        //  1275: dup            
        //  1276: istore_2       
        //  1277: iconst_1       
        //  1278: iadd           
        //  1279: getstatic       dev/nuker/pyro/fc.c:I
        //  1282: ifne            1290
        //  1285: ldc             -2034139644
        //  1287: goto            1292
        //  1290: ldc             1218677184
        //  1292: ldc             -506068417
        //  1294: ixor           
        //  1295: lookupswitch {
        //          -1233173260: 1290
        //          1729592379: 3015
        //          default: 1320
        //        }
        //  1320: putfield        dev/nuker/pyro/faz.0:I
        //  1323: return         
        //  1324: getstatic       dev/nuker/pyro/fc.0:I
        //  1327: ifgt            1336
        //  1330: ldc_w           -147627311
        //  1333: goto            1339
        //  1336: ldc_w           -95251348
        //  1339: ldc_w           -825635500
        //  1342: ixor           
        //  1343: lookupswitch {
        //          882596152: 1368
        //          972730245: 1336
        //          default: 3051
        //        }
        //  1368: aload_1        
        //  1369: getstatic       dev/nuker/pyro/fc.c:I
        //  1372: ifne            1381
        //  1375: ldc_w           761215620
        //  1378: goto            1384
        //  1381: ldc_w           1809591101
        //  1384: ldc_w           -1489206223
        //  1387: ixor           
        //  1388: lookupswitch {
        //          -1973174603: 1381
        //          -857690356: 1416
        //          default: 2993
        //        }
        //  1416: goto            1420
        //  1419: athrow         
        //  1420: invokevirtual   dev/nuker/pyro/f4p.0:()V
        //  1423: goto            1427
        //  1426: athrow         
        //  1427: getstatic       dev/nuker/pyro/fc.1:I
        //  1430: ifne            1439
        //  1433: ldc_w           1045841639
        //  1436: goto            1442
        //  1439: ldc_w           1689534559
        //  1442: ldc_w           1719605045
        //  1445: ixor           
        //  1446: lookupswitch {
        //          46880618: 1472
        //          1479102930: 1439
        //          default: 2985
        //        }
        //  1472: aload_1        
        //  1473: ldc2_w          0.33319999363422
        //  1476: getstatic       dev/nuker/pyro/fc.c:I
        //  1479: ifne            1488
        //  1482: ldc_w           1621725114
        //  1485: goto            1491
        //  1488: ldc_w           -1879033607
        //  1491: ldc_w           71724366
        //  1494: ixor           
        //  1495: lookupswitch {
        //          1415629151: 1488
        //          1693442804: 3033
        //          default: 1520
        //        }
        //  1520: goto            1524
        //  1523: athrow         
        //  1524: invokevirtual   dev/nuker/pyro/f4p.1:(D)V
        //  1527: goto            1531
        //  1530: athrow         
        //  1531: getstatic       dev/nuker/pyro/fc.c:I
        //  1534: ifne            1543
        //  1537: ldc_w           1270964931
        //  1540: goto            1546
        //  1543: ldc_w           331095803
        //  1546: ldc_w           435037467
        //  1549: ixor           
        //  1550: lookupswitch {
        //          173161440: 1576
        //          1378830296: 1543
        //          default: 2999
        //        }
        //  1576: aload_0        
        //  1577: dup            
        //  1578: getfield        dev/nuker/pyro/faz.0:I
        //  1581: dup            
        //  1582: istore_2       
        //  1583: iconst_1       
        //  1584: iadd           
        //  1585: putfield        dev/nuker/pyro/faz.0:I
        //  1588: return         
        //  1589: goto            1593
        //  1592: athrow         
        //  1593: invokestatic    dev/nuker/pyro/fec.5:()D
        //  1596: goto            1600
        //  1599: athrow         
        //  1600: d2f            
        //  1601: fstore_2       
        //  1602: aload_1        
        //  1603: ldc2_w          0.24813599859094704
        //  1606: goto            1610
        //  1609: athrow         
        //  1610: invokevirtual   dev/nuker/pyro/f4p.1:(D)V
        //  1613: goto            1617
        //  1616: athrow         
        //  1617: aload_1        
        //  1618: fload_2        
        //  1619: goto            1623
        //  1622: athrow         
        //  1623: invokestatic    net/minecraft/util/math/MathHelper.func_76126_a:(F)F
        //  1626: goto            1630
        //  1629: athrow         
        //  1630: fneg           
        //  1631: f2d            
        //  1632: ldc2_w          0.2
        //  1635: dmul           
        //  1636: goto            1640
        //  1639: athrow         
        //  1640: invokevirtual   dev/nuker/pyro/f4p.0:(D)V
        //  1643: goto            1647
        //  1646: athrow         
        //  1647: aload_1        
        //  1648: fload_2        
        //  1649: goto            1653
        //  1652: athrow         
        //  1653: invokestatic    net/minecraft/util/math/MathHelper.func_76134_b:(F)F
        //  1656: goto            1660
        //  1659: athrow         
        //  1660: f2d            
        //  1661: ldc2_w          0.2
        //  1664: dmul           
        //  1665: goto            1669
        //  1668: athrow         
        //  1669: invokevirtual   dev/nuker/pyro/f4p.c:(D)V
        //  1672: goto            1676
        //  1675: athrow         
        //  1676: aload_0        
        //  1677: iconst_0       
        //  1678: getstatic       dev/nuker/pyro/fc.c:I
        //  1681: ifne            1690
        //  1684: ldc_w           -461694216
        //  1687: goto            1693
        //  1690: ldc_w           99075118
        //  1693: ldc_w           1600941184
        //  1696: ixor           
        //  1697: lookupswitch {
        //          -1162088574: 1690
        //          -1156090248: 3019
        //          default: 1724
        //        }
        //  1724: putfield        dev/nuker/pyro/faz.0:I
        //  1727: getstatic       dev/nuker/pyro/far.c:Lnet/minecraft/client/Minecraft;
        //  1730: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1733: dconst_0       
        //  1734: getstatic       dev/nuker/pyro/fc.c:I
        //  1737: ifne            1746
        //  1740: ldc_w           -44093328
        //  1743: goto            1749
        //  1746: ldc_w           -1758923663
        //  1749: ldc_w           165898737
        //  1752: ixor           
        //  1753: lookupswitch {
        //          -188982911: 3005
        //          942135295: 1746
        //          default: 1780
        //        }
        //  1780: putfield        net/minecraft/client/entity/EntityPlayerSP.field_70181_x:D
        //  1783: aload_1        
        //  1784: goto            1788
        //  1787: athrow         
        //  1788: invokevirtual   dev/nuker/pyro/f4p.0:()V
        //  1791: goto            1795
        //  1794: athrow         
        //  1795: return         
        //  1796: return         
        //  1797: getstatic       dev/nuker/pyro/fc.c:I
        //  1800: ifne            1809
        //  1803: ldc_w           1687192361
        //  1806: goto            1812
        //  1809: ldc_w           -2111196051
        //  1812: ldc_w           -1409124664
        //  1815: ixor           
        //  1816: lookupswitch {
        //          -929892895: 3055
        //          1688869916: 1809
        //          default: 1844
        //        }
        //  1844: aload_0        
        //  1845: iconst_0       
        //  1846: putfield        dev/nuker/pyro/faz.0:I
        //  1849: aload_0        
        //  1850: getfield        dev/nuker/pyro/faz.c:I
        //  1853: iconst_1       
        //  1854: if_icmpne       2082
        //  1857: getstatic       dev/nuker/pyro/far.c:Lnet/minecraft/client/Minecraft;
        //  1860: getstatic       dev/nuker/pyro/fc.1:I
        //  1863: ifne            1872
        //  1866: ldc_w           -1415410909
        //  1869: goto            1875
        //  1872: ldc_w           -355703253
        //  1875: ldc_w           1981136171
        //  1878: ixor           
        //  1879: lookupswitch {
        //          -1539440717: 1872
        //          -575195640: 3063
        //          default: 1904
        //        }
        //  1904: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1907: getfield        net/minecraft/client/entity/EntityPlayerSP.field_191988_bg:F
        //  1910: fconst_0       
        //  1911: fcmpg          
        //  1912: ifne            1921
        //  1915: ldc_w           1273254147
        //  1918: goto            1924
        //  1921: ldc_w           1273254146
        //  1924: ldc_w           -1118848469
        //  1927: ixor           
        //  1928: tableswitch {
        //          -313010608: 1952
        //          -313010607: 2011
        //          default: 1915
        //        }
        //  1952: getstatic       dev/nuker/pyro/far.c:Lnet/minecraft/client/Minecraft;
        //  1955: getstatic       dev/nuker/pyro/fc.1:I
        //  1958: ifne            1967
        //  1961: ldc_w           2080123517
        //  1964: goto            1970
        //  1967: ldc_w           633800354
        //  1970: ldc_w           -1475570048
        //  1973: ixor           
        //  1974: lookupswitch {
        //          -1502690863: 1967
        //          -739197699: 3067
        //          default: 2000
        //        }
        //  2000: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  2003: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70702_br:F
        //  2006: fconst_0       
        //  2007: fcmpg          
        //  2008: ifeq            2082
        //  2011: getstatic       dev/nuker/pyro/fc.c:I
        //  2014: ifne            2023
        //  2017: ldc_w           -841468581
        //  2020: goto            2026
        //  2023: ldc_w           -1732956305
        //  2026: ldc_w           92734507
        //  2029: ixor           
        //  2030: lookupswitch {
        //          -933285520: 2987
        //          821777364: 2023
        //          default: 2056
        //        }
        //  2056: aload_0        
        //  2057: ldc2_w          1.35
        //  2060: goto            2064
        //  2063: athrow         
        //  2064: invokestatic    dev/nuker/pyro/far.1:()D
        //  2067: goto            2071
        //  2070: athrow         
        //  2071: dmul           
        //  2072: ldc2_w          0.01
        //  2075: dsub           
        //  2076: putfield        dev/nuker/pyro/faz.c:D
        //  2079: goto            2774
        //  2082: aload_0        
        //  2083: getstatic       dev/nuker/pyro/fc.1:I
        //  2086: ifne            2095
        //  2089: ldc_w           1429690792
        //  2092: goto            2098
        //  2095: ldc_w           1281469704
        //  2098: ldc_w           1415076375
        //  2101: ixor           
        //  2102: lookupswitch {
        //          24052671: 2095
        //          406451999: 2128
        //          default: 3023
        //        }
        //  2128: getfield        dev/nuker/pyro/faz.c:I
        //  2131: iconst_2       
        //  2132: if_icmpne       2422
        //  2135: getstatic       dev/nuker/pyro/fc.c:I
        //  2138: ifne            2147
        //  2141: ldc_w           752637465
        //  2144: goto            2150
        //  2147: ldc_w           1307654115
        //  2150: ldc_w           -53681425
        //  2153: ixor           
        //  2154: lookupswitch {
        //          -1321347828: 2180
        //          -804211466: 2147
        //          default: 3061
        //        }
        //  2180: getstatic       dev/nuker/pyro/far.c:Lnet/minecraft/client/Minecraft;
        //  2183: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  2186: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70124_G:Z
        //  2189: ifeq            2422
        //  2192: aload_1        
        //  2193: ldc2_w          0.4
        //  2196: dstore_2       
        //  2197: astore          9
        //  2199: iconst_0       
        //  2200: istore          4
        //  2202: iconst_0       
        //  2203: istore          5
        //  2205: dload_2        
        //  2206: dstore          6
        //  2208: iconst_0       
        //  2209: getstatic       dev/nuker/pyro/fc.c:I
        //  2212: ifne            2221
        //  2215: ldc_w           1242862416
        //  2218: goto            2224
        //  2221: ldc_w           127446171
        //  2224: ldc_w           1177169461
        //  2227: ixor           
        //  2228: lookupswitch {
        //          205438309: 3057
        //          1818745496: 2221
        //          default: 2256
        //        }
        //  2256: istore          8
        //  2258: getstatic       dev/nuker/pyro/far.c:Lnet/minecraft/client/Minecraft;
        //  2261: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  2264: getstatic       dev/nuker/pyro/fc.c:I
        //  2267: ifne            2276
        //  2270: ldc_w           -1393980934
        //  2273: goto            2279
        //  2276: ldc_w           1444256947
        //  2279: ldc_w           1734551073
        //  2282: ixor           
        //  2283: lookupswitch {
        //          -880103461: 3065
        //          -62107094: 2276
        //          default: 2308
        //        }
        //  2308: dload           6
        //  2310: putfield        net/minecraft/client/entity/EntityPlayerSP.field_70181_x:D
        //  2313: dload_2        
        //  2314: dstore          10
        //  2316: aload           9
        //  2318: dload           10
        //  2320: goto            2324
        //  2323: athrow         
        //  2324: invokevirtual   dev/nuker/pyro/f4p.1:(D)V
        //  2327: goto            2331
        //  2330: athrow         
        //  2331: aload_0        
        //  2332: aload_0        
        //  2333: getfield        dev/nuker/pyro/faz.c:Z
        //  2336: ifne            2343
        //  2339: iconst_1       
        //  2340: goto            2344
        //  2343: iconst_0       
        //  2344: putfield        dev/nuker/pyro/faz.c:Z
        //  2347: aload_0        
        //  2348: dup            
        //  2349: getfield        dev/nuker/pyro/faz.c:D
        //  2352: aload_0        
        //  2353: getstatic       dev/nuker/pyro/fc.0:I
        //  2356: ifgt            2365
        //  2359: ldc_w           751771745
        //  2362: goto            2368
        //  2365: ldc_w           -352355942
        //  2368: ldc_w           -309463740
        //  2371: ixor           
        //  2372: lookupswitch {
        //          -1052584667: 3017
        //          -371384050: 2365
        //          default: 2400
        //        }
        //  2400: getfield        dev/nuker/pyro/faz.c:Z
        //  2403: ifeq            2412
        //  2406: ldc2_w          1.6835
        //  2409: goto            2415
        //  2412: ldc2_w          1.395
        //  2415: dmul           
        //  2416: putfield        dev/nuker/pyro/faz.c:D
        //  2419: goto            2774
        //  2422: aload_0        
        //  2423: getfield        dev/nuker/pyro/faz.c:I
        //  2426: iconst_3       
        //  2427: if_icmpne       2464
        //  2430: ldc2_w          0.66
        //  2433: aload_0        
        //  2434: getfield        dev/nuker/pyro/faz.0:D
        //  2437: goto            2441
        //  2440: athrow         
        //  2441: invokestatic    dev/nuker/pyro/far.1:()D
        //  2444: goto            2448
        //  2447: athrow         
        //  2448: dsub           
        //  2449: dmul           
        //  2450: dstore_2       
        //  2451: aload_0        
        //  2452: aload_0        
        //  2453: getfield        dev/nuker/pyro/faz.0:D
        //  2456: dload_2        
        //  2457: dsub           
        //  2458: putfield        dev/nuker/pyro/faz.c:D
        //  2461: goto            2774
        //  2464: getstatic       dev/nuker/pyro/far.c:Lnet/minecraft/client/Minecraft;
        //  2467: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //  2470: getstatic       dev/nuker/pyro/far.c:Lnet/minecraft/client/Minecraft;
        //  2473: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  2476: checkcast       Lnet/minecraft/entity/Entity;
        //  2479: getstatic       dev/nuker/pyro/far.c:Lnet/minecraft/client/Minecraft;
        //  2482: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  2485: dup            
        //  2486: pop            
        //  2487: goto            2491
        //  2490: athrow         
        //  2491: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_174813_aQ:()Lnet/minecraft/util/math/AxisAlignedBB;
        //  2494: goto            2498
        //  2497: athrow         
        //  2498: dconst_0       
        //  2499: getstatic       dev/nuker/pyro/far.c:Lnet/minecraft/client/Minecraft;
        //  2502: getstatic       dev/nuker/pyro/fc.1:I
        //  2505: ifne            2514
        //  2508: ldc_w           962882902
        //  2511: goto            2517
        //  2514: ldc_w           -196597044
        //  2517: ldc_w           -747186760
        //  2520: ixor           
        //  2521: lookupswitch {
        //          -367871762: 2514
        //          658440052: 2548
        //          default: 3001
        //        }
        //  2548: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  2551: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70181_x:D
        //  2554: dconst_0       
        //  2555: goto            2559
        //  2558: athrow         
        //  2559: invokevirtual   net/minecraft/util/math/AxisAlignedBB.func_72317_d:(DDD)Lnet/minecraft/util/math/AxisAlignedBB;
        //  2562: goto            2566
        //  2565: athrow         
        //  2566: goto            2570
        //  2569: athrow         
        //  2570: invokevirtual   net/minecraft/client/multiplayer/WorldClient.func_184144_a:(Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/AxisAlignedBB;)Ljava/util/List;
        //  2573: goto            2577
        //  2576: athrow         
        //  2577: astore_2       
        //  2578: getstatic       dev/nuker/pyro/fc.0:I
        //  2581: ifgt            2590
        //  2584: ldc_w           -1845478002
        //  2587: goto            2593
        //  2590: ldc_w           1750551450
        //  2593: ldc_w           -1759308872
        //  2596: ixor           
        //  2597: lookupswitch {
        //          -9152478: 2624
        //          86191670: 2590
        //          default: 3021
        //        }
        //  2624: aload_2        
        //  2625: goto            2629
        //  2628: athrow         
        //  2629: invokeinterface java/util/List.size:()I
        //  2634: goto            2638
        //  2637: athrow         
        //  2638: ifgt            2698
        //  2641: getstatic       dev/nuker/pyro/far.c:Lnet/minecraft/client/Minecraft;
        //  2644: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  2647: getstatic       dev/nuker/pyro/fc.c:I
        //  2650: ifne            2659
        //  2653: ldc_w           1392429980
        //  2656: goto            2662
        //  2659: ldc_w           1878989975
        //  2662: ldc_w           1905213471
        //  2665: ixor           
        //  2666: lookupswitch {
        //          594643843: 2995
        //          1166025810: 2659
        //          default: 2692
        //        }
        //  2692: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70124_G:Z
        //  2695: ifeq            2757
        //  2698: aload_0        
        //  2699: getfield        dev/nuker/pyro/faz.c:I
        //  2702: ifle            2757
        //  2705: getstatic       dev/nuker/pyro/fc.0:I
        //  2708: ifgt            2717
        //  2711: ldc_w           351199318
        //  2714: goto            2720
        //  2717: ldc_w           -2072086285
        //  2720: ldc_w           693285598
        //  2723: ixor           
        //  2724: lookupswitch {
        //          1035752072: 3043
        //          1930608635: 2717
        //          default: 2752
        //        }
        //  2752: aload_0        
        //  2753: iconst_1       
        //  2754: putfield        dev/nuker/pyro/faz.c:I
        //  2757: aload_0        
        //  2758: aload_0        
        //  2759: getfield        dev/nuker/pyro/faz.0:D
        //  2762: aload_0        
        //  2763: getfield        dev/nuker/pyro/faz.0:D
        //  2766: ldc2_w          159.0
        //  2769: ddiv           
        //  2770: dsub           
        //  2771: putfield        dev/nuker/pyro/faz.c:D
        //  2774: aload_1        
        //  2775: goto            2779
        //  2778: athrow         
        //  2779: invokevirtual   dev/nuker/pyro/f4p.0:()V
        //  2782: goto            2786
        //  2785: athrow         
        //  2786: aload_0        
        //  2787: aload_0        
        //  2788: getstatic       dev/nuker/pyro/fc.c:I
        //  2791: ifne            2800
        //  2794: ldc_w           778061996
        //  2797: goto            2803
        //  2800: ldc_w           711324204
        //  2803: ldc_w           -838686398
        //  2806: ixor           
        //  2807: lookupswitch {
        //          -1855338705: 2800
        //          -530390546: 3031
        //          default: 2832
        //        }
        //  2832: getfield        dev/nuker/pyro/faz.c:D
        //  2835: goto            2839
        //  2838: athrow         
        //  2839: invokestatic    dev/nuker/pyro/far.1:()D
        //  2842: goto            2846
        //  2845: athrow         
        //  2846: goto            2850
        //  2849: athrow         
        //  2850: invokestatic    java/lang/Math.max:(DD)D
        //  2853: goto            2857
        //  2856: athrow         
        //  2857: putfield        dev/nuker/pyro/faz.c:D
        //  2860: aload_1        
        //  2861: aload_0        
        //  2862: getstatic       dev/nuker/pyro/fc.0:I
        //  2865: ifgt            2874
        //  2868: ldc_w           2044645451
        //  2871: goto            2877
        //  2874: ldc_w           1082967296
        //  2877: ldc_w           -166717218
        //  2880: ixor           
        //  2881: lookupswitch {
        //          -1882273643: 2874
        //          -1231233570: 2908
        //          default: 3007
        //        }
        //  2908: getfield        dev/nuker/pyro/faz.c:D
        //  2911: goto            2915
        //  2914: athrow         
        //  2915: invokestatic    dev/nuker/pyro/fec.c:(Ldev/nuker/pyro/f4p;D)V
        //  2918: goto            2922
        //  2921: athrow         
        //  2922: aload_0        
        //  2923: dup            
        //  2924: dup            
        //  2925: getfield        dev/nuker/pyro/faz.c:I
        //  2928: iconst_1       
        //  2929: iadd           
        //  2930: putfield        dev/nuker/pyro/faz.c:I
        //  2933: getstatic       dev/nuker/pyro/fc.c:I
        //  2936: ifne            2945
        //  2939: ldc_w           1676805268
        //  2942: goto            2948
        //  2945: ldc_w           424069218
        //  2948: ldc_w           -281157187
        //  2951: ixor           
        //  2952: lookupswitch {
        //          -1932532439: 3037
        //          958654208: 2945
        //          default: 2980
        //        }
        //  2980: getfield        dev/nuker/pyro/faz.c:I
        //  2983: pop            
        //  2984: return         
        //  2985: aconst_null    
        //  2986: athrow         
        //  2987: aconst_null    
        //  2988: athrow         
        //  2989: aconst_null    
        //  2990: athrow         
        //  2991: aconst_null    
        //  2992: athrow         
        //  2993: aconst_null    
        //  2994: athrow         
        //  2995: aconst_null    
        //  2996: athrow         
        //  2997: aconst_null    
        //  2998: athrow         
        //  2999: aconst_null    
        //  3000: athrow         
        //  3001: aconst_null    
        //  3002: athrow         
        //  3003: aconst_null    
        //  3004: athrow         
        //  3005: aconst_null    
        //  3006: athrow         
        //  3007: aconst_null    
        //  3008: athrow         
        //  3009: aconst_null    
        //  3010: athrow         
        //  3011: aconst_null    
        //  3012: athrow         
        //  3013: aconst_null    
        //  3014: athrow         
        //  3015: aconst_null    
        //  3016: athrow         
        //  3017: aconst_null    
        //  3018: athrow         
        //  3019: aconst_null    
        //  3020: athrow         
        //  3021: aconst_null    
        //  3022: athrow         
        //  3023: aconst_null    
        //  3024: athrow         
        //  3025: aconst_null    
        //  3026: athrow         
        //  3027: aconst_null    
        //  3028: athrow         
        //  3029: aconst_null    
        //  3030: athrow         
        //  3031: aconst_null    
        //  3032: athrow         
        //  3033: aconst_null    
        //  3034: athrow         
        //  3035: aconst_null    
        //  3036: athrow         
        //  3037: aconst_null    
        //  3038: athrow         
        //  3039: aconst_null    
        //  3040: athrow         
        //  3041: aconst_null    
        //  3042: athrow         
        //  3043: aconst_null    
        //  3044: athrow         
        //  3045: aconst_null    
        //  3046: athrow         
        //  3047: aconst_null    
        //  3048: athrow         
        //  3049: aconst_null    
        //  3050: athrow         
        //  3051: aconst_null    
        //  3052: athrow         
        //  3053: aconst_null    
        //  3054: athrow         
        //  3055: aconst_null    
        //  3056: athrow         
        //  3057: aconst_null    
        //  3058: athrow         
        //  3059: aconst_null    
        //  3060: athrow         
        //  3061: aconst_null    
        //  3062: athrow         
        //  3063: aconst_null    
        //  3064: athrow         
        //  3065: aconst_null    
        //  3066: athrow         
        //  3067: aconst_null    
        //  3068: athrow         
        //  3069: pop            
        //  3070: goto            24
        //  3073: pop            
        //  3074: aconst_null    
        //  3075: goto            3069
        //  3078: dup            
        //  3079: ifnull          3069
        //  3082: checkcast       Ljava/lang/Throwable;
        //  3085: athrow         
        //  3086: dup            
        //  3087: ifnull          3073
        //  3090: checkcast       Ljava/lang/Throwable;
        //  3093: athrow         
        //  3094: aconst_null    
        //  3095: athrow         
        //    StackMapTable: 01 73 43 07 00 42 04 FF 00 0B 00 00 00 01 07 00 42 FD 00 03 07 00 03 07 00 44 45 07 00 42 40 07 00 44 45 07 00 42 40 07 00 49 10 41 01 1E 48 07 00 42 40 07 00 5B 45 07 00 42 40 07 01 A2 47 07 00 23 40 07 00 60 45 07 00 42 40 01 06 FF 00 03 00 00 00 01 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 01 07 00 44 45 07 00 42 40 01 02 00 42 07 00 42 00 45 07 00 42 40 01 11 04 41 01 17 0A 41 01 1E 47 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 02 07 00 83 07 01 A4 45 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 02 07 00 83 07 01 A4 42 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 02 07 00 83 07 01 A4 45 07 00 42 00 00 4D 07 00 9A FF 00 01 00 02 07 00 03 07 00 44 00 02 07 00 9A 01 5B 07 00 9A 45 07 00 42 40 07 00 5B 45 07 00 42 40 07 01 A2 4F 07 00 60 FF 00 01 00 02 07 00 03 07 00 44 00 02 07 00 60 01 5B 07 00 60 42 07 00 42 40 07 00 60 45 07 00 42 40 01 FF 00 16 00 02 07 00 03 07 00 44 00 02 07 00 9A 07 00 A6 FF 00 01 00 02 07 00 03 07 00 44 00 03 07 00 9A 07 00 A6 01 FF 00 1B 00 02 07 00 03 07 00 44 00 02 07 00 9A 07 00 A6 42 07 00 29 FF 00 00 00 02 07 00 03 07 00 44 00 02 07 00 9A 07 00 A6 45 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 02 07 00 9A 07 01 A2 FF 00 0D 00 02 07 00 03 07 00 44 00 02 07 00 9A 07 00 AA FF 00 01 00 02 07 00 03 07 00 44 00 03 07 00 9A 07 00 AA 01 FF 00 1C 00 02 07 00 03 07 00 44 00 02 07 00 9A 07 00 AA 42 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 02 07 00 9A 07 00 AA 45 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 02 07 00 9A 03 42 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 02 07 00 9A 03 45 07 00 42 40 03 06 4D 07 00 BB FF 00 01 00 02 07 00 03 07 00 44 00 02 07 00 BB 01 5E 07 00 BB 42 07 00 42 40 07 00 BB 45 07 00 42 40 07 00 C3 4A 07 00 C3 FF 00 01 00 02 07 00 03 07 00 44 00 02 07 00 C3 01 5B 07 00 C3 42 07 00 42 40 07 00 C3 45 07 00 42 40 07 01 A2 4D 07 00 60 FF 00 01 00 02 07 00 03 07 00 44 00 02 07 00 60 01 5C 07 00 60 42 07 00 2D 40 07 00 60 45 07 00 42 40 01 FF 00 12 00 02 07 00 03 07 00 44 00 02 07 00 83 07 01 A4 FF 00 01 00 02 07 00 03 07 00 44 00 03 07 00 83 07 01 A4 01 FF 00 1B 00 02 07 00 03 07 00 44 00 02 07 00 83 07 01 A4 42 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 02 07 00 83 07 01 A4 45 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 02 07 00 83 07 01 A4 47 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 04 07 00 83 07 01 A4 07 00 CC 02 45 07 00 42 00 5C 07 00 76 FF 00 01 00 02 07 00 03 07 00 44 00 02 07 00 76 01 5D 07 00 76 4C 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 02 07 00 9A 03 45 07 00 42 40 03 FC 00 0B 03 41 01 1C 10 41 01 1C FA 00 0C 0A 41 01 1D 06 04 41 01 19 0A 41 01 1E 4B 07 00 03 FF 00 01 00 02 07 00 03 07 00 44 00 02 07 00 03 01 5D 07 00 03 1B 4B 07 00 44 FF 00 01 00 02 07 00 03 07 00 44 00 02 07 00 44 01 5D 07 00 44 42 07 00 3B 40 07 00 44 45 07 00 42 00 FF 00 06 00 00 00 01 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 02 07 00 44 03 45 07 00 42 00 FF 00 0C 00 02 07 00 03 07 00 44 00 02 07 00 03 07 00 03 FF 00 01 00 02 07 00 03 07 00 44 00 03 07 00 03 07 00 03 01 FF 00 1E 00 02 07 00 03 07 00 44 00 02 07 00 03 07 00 03 FF 00 11 00 03 07 00 03 07 00 44 01 00 02 07 00 03 01 FF 00 01 00 03 07 00 03 07 00 44 01 00 03 07 00 03 01 01 FF 00 1B 00 03 07 00 03 07 00 44 01 00 02 07 00 03 01 FA 00 03 0B 42 01 1C 4C 07 00 44 FF 00 02 00 02 07 00 03 07 00 44 00 02 07 00 44 01 5F 07 00 44 42 07 00 2F 40 07 00 44 45 07 00 42 00 0B 42 01 1D FF 00 0F 00 02 07 00 03 07 00 44 00 02 07 00 44 03 FF 00 02 00 02 07 00 03 07 00 44 00 03 07 00 44 03 01 FF 00 1C 00 02 07 00 03 07 00 44 00 02 07 00 44 03 42 07 00 3B FF 00 00 00 02 07 00 03 07 00 44 00 02 07 00 44 03 45 07 00 42 00 0B 42 01 1D 0C FF 00 02 00 00 00 01 07 00 42 FD 00 00 07 00 03 07 00 44 45 07 00 42 40 03 FF 00 08 00 03 07 00 03 07 00 44 02 00 01 07 00 42 FF 00 00 00 03 07 00 03 07 00 44 02 00 02 07 00 44 03 45 07 00 42 00 44 07 00 42 FF 00 00 00 03 07 00 03 07 00 44 02 00 02 07 00 44 02 45 07 00 42 FF 00 00 00 03 07 00 03 07 00 44 02 00 02 07 00 44 02 48 07 00 42 FF 00 00 00 03 07 00 03 07 00 44 02 00 02 07 00 44 03 45 07 00 42 00 44 07 00 3B FF 00 00 00 03 07 00 03 07 00 44 02 00 02 07 00 44 02 45 07 00 42 FF 00 00 00 03 07 00 03 07 00 44 02 00 02 07 00 44 02 47 07 00 35 FF 00 00 00 03 07 00 03 07 00 44 02 00 02 07 00 44 03 45 07 00 42 00 FF 00 0D 00 03 07 00 03 07 00 44 02 00 02 07 00 03 01 FF 00 02 00 03 07 00 03 07 00 44 02 00 03 07 00 03 01 01 FF 00 1E 00 03 07 00 03 07 00 44 02 00 02 07 00 03 01 FF 00 15 00 03 07 00 03 07 00 44 02 00 02 07 00 76 03 FF 00 02 00 03 07 00 03 07 00 44 02 00 03 07 00 76 03 01 FF 00 1E 00 03 07 00 03 07 00 44 02 00 02 07 00 76 03 46 07 00 42 40 07 00 44 45 07 00 42 00 FA 00 00 00 0B 42 01 1F 5B 07 00 70 FF 00 02 00 02 07 00 03 07 00 44 00 02 07 00 70 01 5C 07 00 70 0A 05 42 01 1B 4E 07 00 70 FF 00 02 00 02 07 00 03 07 00 44 00 02 07 00 70 01 5D 07 00 70 0A 0B 42 01 1D FF 00 06 00 00 00 01 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 02 07 00 03 03 45 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 03 07 00 03 03 03 0A 4C 07 00 03 FF 00 02 00 02 07 00 03 07 00 44 00 02 07 00 03 01 5D 07 00 03 12 42 01 1D FF 00 28 00 08 07 00 03 07 00 44 03 01 01 03 00 07 00 44 00 01 01 FF 00 02 00 08 07 00 03 07 00 44 03 01 01 03 00 07 00 44 00 02 01 01 5F 01 FF 00 13 00 08 07 00 03 07 00 44 03 01 01 03 01 07 00 44 00 01 07 00 76 FF 00 02 00 08 07 00 03 07 00 44 03 01 01 03 01 07 00 44 00 02 07 00 76 01 5C 07 00 76 FF 00 0E 00 00 00 01 07 00 42 FF 00 00 00 09 07 00 03 07 00 44 03 01 01 03 01 07 00 44 03 00 02 07 00 44 03 45 07 00 42 00 4B 07 00 03 FF 00 00 00 09 07 00 03 07 00 44 03 01 01 03 01 07 00 44 03 00 02 07 00 03 01 FF 00 14 00 09 07 00 03 07 00 44 03 01 01 03 01 07 00 44 03 00 03 07 00 03 03 07 00 03 FF 00 02 00 09 07 00 03 07 00 44 03 01 01 03 01 07 00 44 03 00 04 07 00 03 03 07 00 03 01 FF 00 1F 00 09 07 00 03 07 00 44 03 01 01 03 01 07 00 44 03 00 03 07 00 03 03 07 00 03 FF 00 0B 00 09 07 00 03 07 00 44 03 01 01 03 01 07 00 44 03 00 02 07 00 03 03 FF 00 02 00 09 07 00 03 07 00 44 03 01 01 03 01 07 00 44 03 00 03 07 00 03 03 03 FF 00 06 00 02 07 00 03 07 00 44 00 00 51 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 02 03 03 45 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 03 03 03 03 0F 59 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 03 07 01 79 07 01 6A 07 00 76 45 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 03 07 01 79 07 01 6A 07 01 73 FF 00 0F 00 02 07 00 03 07 00 44 00 05 07 01 79 07 01 6A 07 01 73 03 07 00 70 FF 00 02 00 02 07 00 03 07 00 44 00 06 07 01 79 07 01 6A 07 01 73 03 07 00 70 01 FF 00 1E 00 02 07 00 03 07 00 44 00 05 07 01 79 07 01 6A 07 01 73 03 07 00 70 49 07 00 37 FF 00 00 00 02 07 00 03 07 00 44 00 06 07 01 79 07 01 6A 07 01 73 03 03 03 45 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 03 07 01 79 07 01 6A 07 01 73 FF 00 02 00 00 00 01 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 03 07 01 79 07 01 6A 07 01 73 45 07 00 42 40 07 01 82 FC 00 0C 07 01 82 42 01 1E 43 07 00 3F 40 07 01 82 47 07 00 42 40 01 54 07 00 76 FF 00 02 00 03 07 00 03 07 00 44 07 01 82 00 02 07 00 76 01 5D 07 00 76 05 12 42 01 1F 04 FA 00 10 43 07 00 42 40 07 00 44 45 07 00 42 00 FF 00 0D 00 02 07 00 03 07 00 44 00 02 07 00 03 07 00 03 FF 00 02 00 02 07 00 03 07 00 44 00 03 07 00 03 07 00 03 01 FF 00 1C 00 02 07 00 03 07 00 44 00 02 07 00 03 07 00 03 45 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 02 07 00 03 03 45 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 03 07 00 03 03 03 42 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 03 07 00 03 03 03 45 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 02 07 00 03 03 FF 00 10 00 02 07 00 03 07 00 44 00 02 07 00 44 07 00 03 FF 00 02 00 02 07 00 03 07 00 44 00 03 07 00 44 07 00 03 01 FF 00 1E 00 02 07 00 03 07 00 44 00 02 07 00 44 07 00 03 45 07 00 42 FF 00 00 00 02 07 00 03 07 00 44 00 02 07 00 44 03 45 07 00 42 00 56 07 00 03 FF 00 02 00 02 07 00 03 07 00 44 00 02 07 00 03 01 5F 07 00 03 04 01 FC 00 01 03 FA 00 01 41 07 00 44 FF 00 01 00 03 07 00 03 07 00 44 07 01 82 00 01 07 00 76 FF 00 01 00 02 07 00 03 07 00 44 00 02 07 00 9A 07 00 AA 01 FF 00 01 00 02 07 00 03 07 00 44 00 05 07 01 79 07 01 6A 07 01 73 03 07 00 70 FC 00 01 03 FF 00 01 00 03 07 00 03 07 00 44 02 00 02 07 00 76 03 FF 00 01 00 02 07 00 03 07 00 44 00 02 07 00 44 07 00 03 41 07 00 60 FF 00 01 00 02 07 00 03 07 00 44 00 02 07 00 03 07 00 03 41 07 00 44 FF 00 01 00 03 07 00 03 07 00 44 01 00 02 07 00 03 01 FF 00 01 00 09 07 00 03 07 00 44 03 01 01 03 01 07 00 44 03 00 03 07 00 03 03 07 00 03 FF 00 01 00 03 07 00 03 07 00 44 02 00 02 07 00 03 01 FF 00 01 00 03 07 00 03 07 00 44 07 01 82 00 00 FF 00 01 00 02 07 00 03 07 00 44 00 01 07 00 03 41 07 00 BB 01 41 07 00 9A FF 00 01 00 02 07 00 03 07 00 44 00 02 07 00 03 07 00 03 FF 00 01 00 02 07 00 03 07 00 44 00 02 07 00 44 03 41 07 00 C3 41 07 00 03 FF 00 01 00 02 07 00 03 07 00 44 00 02 07 00 83 07 01 A4 41 07 00 03 FC 00 01 07 01 82 FF 00 01 00 02 07 00 03 07 00 44 00 01 07 00 76 01 01 01 41 07 00 60 01 FF 00 01 00 08 07 00 03 07 00 44 03 01 01 03 00 07 00 44 00 01 01 FF 00 01 00 02 07 00 03 07 00 44 00 02 07 00 9A 07 00 A6 01 41 07 00 70 FF 00 01 00 08 07 00 03 07 00 44 03 01 01 03 01 07 00 44 00 01 07 00 76 FF 00 01 00 02 07 00 03 07 00 44 00 01 07 00 70 41 07 00 3B 43 05 44 07 00 3B 47 05 47 07 00 42
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     3078   3086   Ljava/lang/IllegalArgumentException;
        //  3078   3086   3078   3086   Ljava/lang/StringIndexOutOfBoundsException;
        //  3094   3096   3      8      Ljava/lang/NegativeArraySizeException;
        //  30     37     37     38     Any
        //  31     37     3      8      Any
        //  30     37     3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  31     37     3      8      Ljava/lang/ArithmeticException;
        //  30     37     30     31     Any
        //  97     104    104    105    Any
        //  97     104    104    105    Ljava/lang/AssertionError;
        //  98     104    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  97     104    97     98     Any
        //  98     104    97     98     Any
        //  113    120    120    121    Any
        //  113    120    120    121    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  113    120    3      8      Any
        //  113    120    113    114    Ljava/lang/StringIndexOutOfBoundsException;
        //  114    120    120    121    Any
        //  133    139    139    140    Any
        //  133    139    3      8      Ljava/lang/NegativeArraySizeException;
        //  133    139    3      8      Any
        //  133    139    139    140    Any
        //  133    139    3      8      Ljava/lang/IllegalStateException;
        //  147    154    154    155    Any
        //  148    154    147    148    Any
        //  148    154    154    155    Any
        //  148    154    3      8      Any
        //  147    154    147    148    Any
        //  256    263    263    264    Any
        //  257    263    3      8      Any
        //  257    263    256    257    Any
        //  256    263    256    257    Any
        //  257    263    263    264    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  267    274    274    275    Any
        //  268    274    274    275    Any
        //  268    274    267    268    Any
        //  268    274    274    275    Any
        //  268    274    267    268    Ljava/lang/NumberFormatException;
        //  326    333    333    334    Any
        //  326    333    3      8      Any
        //  326    333    333    334    Any
        //  326    333    333    334    Any
        //  326    333    326    327    Any
        //  383    390    390    391    Any
        //  383    390    3      8      Any
        //  384    390    383    384    Any
        //  384    390    390    391    Ljava/lang/ArithmeticException;
        //  384    390    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  447    454    454    455    Any
        //  447    454    447    448    Ljava/lang/ArithmeticException;
        //  448    454    3      8      Any
        //  448    454    3      8      Any
        //  447    454    454    455    Ljava/lang/UnsupportedOperationException;
        //  503    510    510    511    Any
        //  503    510    503    504    Ljava/lang/AssertionError;
        //  504    510    503    504    Any
        //  503    510    503    504    Any
        //  504    510    510    511    Ljava/lang/NullPointerException;
        //  514    521    521    522    Any
        //  515    521    521    522    Ljava/lang/IllegalStateException;
        //  515    521    521    522    Ljava/lang/ClassCastException;
        //  514    521    514    515    Any
        //  515    521    514    515    Ljava/util/NoSuchElementException;
        //  579    586    586    587    Any
        //  580    586    3      8      Ljava/lang/ArithmeticException;
        //  579    586    586    587    Ljava/lang/UnsupportedOperationException;
        //  579    586    579    580    Any
        //  579    586    579    580    Ljava/lang/EnumConstantNotPresentException;
        //  631    638    638    639    Any
        //  631    638    638    639    Any
        //  631    638    631    632    Any
        //  631    638    3      8      Any
        //  632    638    631    632    Ljava/util/NoSuchElementException;
        //  687    694    694    695    Any
        //  687    694    687    688    Ljava/lang/EnumConstantNotPresentException;
        //  687    694    3      8      Any
        //  687    694    3      8      Ljava/lang/ArithmeticException;
        //  687    694    3      8      Ljava/lang/UnsupportedOperationException;
        //  747    754    754    755    Any
        //  748    754    3      8      Any
        //  748    754    754    755    Ljava/util/NoSuchElementException;
        //  748    754    3      8      Any
        //  748    754    747    748    Any
        //  763    770    770    771    Any
        //  764    770    770    771    Ljava/lang/RuntimeException;
        //  763    770    3      8      Ljava/lang/NegativeArraySizeException;
        //  763    770    763    764    Any
        //  763    770    3      8      Any
        //  845    852    852    853    Any
        //  846    852    3      8      Any
        //  846    852    845    846    Any
        //  846    852    845    846    Any
        //  846    852    3      8      Any
        //  1203   1210   1210   1211   Any
        //  1203   1210   1203   1204   Ljava/lang/EnumConstantNotPresentException;
        //  1204   1210   3      8      Any
        //  1203   1210   1203   1204   Ljava/lang/NumberFormatException;
        //  1203   1210   1203   1204   Ljava/lang/RuntimeException;
        //  1219   1225   1225   1226   Any
        //  1219   1225   3      8      Ljava/lang/IndexOutOfBoundsException;
        //  1219   1225   3      8      Any
        //  1219   1225   1225   1226   Ljava/lang/IndexOutOfBoundsException;
        //  1219   1225   1225   1226   Any
        //  1419   1426   1426   1427   Any
        //  1420   1426   1419   1420   Ljava/lang/IllegalStateException;
        //  1419   1426   3      8      Any
        //  1419   1426   3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  1420   1426   3      8      Ljava/lang/IllegalArgumentException;
        //  1523   1530   1530   1531   Any
        //  1523   1530   3      8      Any
        //  1524   1530   1523   1524   Ljava/lang/ArithmeticException;
        //  1524   1530   3      8      Any
        //  1523   1530   1523   1524   Ljava/lang/StringIndexOutOfBoundsException;
        //  1593   1599   1599   1600   Any
        //  1593   1599   3      8      Ljava/lang/ClassCastException;
        //  1593   1599   1599   1600   Ljava/lang/IndexOutOfBoundsException;
        //  1593   1599   1599   1600   Any
        //  1593   1599   3      8      Ljava/lang/ClassCastException;
        //  1609   1616   1616   1617   Any
        //  1610   1616   1616   1617   Ljava/lang/ArithmeticException;
        //  1609   1616   1616   1617   Any
        //  1609   1616   1609   1610   Any
        //  1610   1616   3      8      Any
        //  1622   1629   1629   1630   Any
        //  1623   1629   1622   1623   Any
        //  1622   1629   1629   1630   Any
        //  1623   1629   1629   1630   Ljava/lang/IndexOutOfBoundsException;
        //  1623   1629   1622   1623   Ljava/lang/RuntimeException;
        //  1639   1646   1646   1647   Any
        //  1640   1646   3      8      Any
        //  1640   1646   1639   1640   Any
        //  1639   1646   1646   1647   Any
        //  1640   1646   1639   1640   Ljava/lang/StringIndexOutOfBoundsException;
        //  1652   1659   1659   1660   Any
        //  1652   1659   3      8      Any
        //  1652   1659   1652   1653   Ljava/lang/RuntimeException;
        //  1653   1659   3      8      Any
        //  1653   1659   3      8      Any
        //  1668   1675   1675   1676   Any
        //  1668   1675   3      8      Any
        //  1668   1675   3      8      Any
        //  1669   1675   3      8      Ljava/lang/ClassCastException;
        //  1669   1675   1668   1669   Ljava/lang/NullPointerException;
        //  1787   1794   1794   1795   Any
        //  1787   1794   1794   1795   Ljava/lang/AssertionError;
        //  1788   1794   3      8      Any
        //  1787   1794   1787   1788   Any
        //  1788   1794   1787   1788   Any
        //  2064   2070   2070   2071   Any
        //  2064   2070   2070   2071   Ljava/lang/IllegalArgumentException;
        //  2064   2070   3      8      Any
        //  2064   2070   3      8      Ljava/lang/NullPointerException;
        //  2064   2070   3      8      Any
        //  2324   2330   2330   2331   Any
        //  2324   2330   3      8      Any
        //  2324   2330   2330   2331   Ljava/util/NoSuchElementException;
        //  2324   2330   2330   2331   Ljava/lang/AssertionError;
        //  2324   2330   3      8      Any
        //  2440   2447   2447   2448   Any
        //  2440   2447   2440   2441   Any
        //  2440   2447   2440   2441   Any
        //  2440   2447   3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  2440   2447   2440   2441   Ljava/lang/AssertionError;
        //  2490   2497   2497   2498   Any
        //  2490   2497   2497   2498   Ljava/lang/AssertionError;
        //  2490   2497   2490   2491   Any
        //  2490   2497   3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  2491   2497   2490   2491   Ljava/lang/ClassCastException;
        //  2558   2565   2565   2566   Any
        //  2559   2565   2565   2566   Any
        //  2558   2565   3      8      Any
        //  2558   2565   3      8      Any
        //  2558   2565   2558   2559   Ljava/lang/ClassCastException;
        //  2570   2576   2576   2577   Any
        //  2570   2576   2576   2577   Ljava/lang/ArithmeticException;
        //  2570   2576   2576   2577   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  2570   2576   3      8      Ljava/util/NoSuchElementException;
        //  2570   2576   3      8      Any
        //  2628   2637   2637   2638   Any
        //  2628   2637   2637   2638   Ljava/lang/AssertionError;
        //  2628   2637   2628   2629   Ljava/util/ConcurrentModificationException;
        //  2628   2637   2637   2638   Ljava/lang/EnumConstantNotPresentException;
        //  2629   2637   3      8      Any
        //  2778   2785   2785   2786   Any
        //  2778   2785   2778   2779   Any
        //  2779   2785   2785   2786   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  2778   2785   2778   2779   Ljava/lang/ClassCastException;
        //  2778   2785   2778   2779   Any
        //  2838   2845   2845   2846   Any
        //  2838   2845   2838   2839   Any
        //  2838   2845   2845   2846   Any
        //  2839   2845   2838   2839   Any
        //  2838   2845   3      8      Any
        //  2849   2856   2856   2857   Any
        //  2849   2856   2849   2850   Any
        //  2849   2856   3      8      Ljava/lang/NullPointerException;
        //  2850   2856   3      8      Any
        //  2850   2856   3      8      Any
        //  2914   2921   2921   2922   Any
        //  2914   2921   3      8      Any
        //  2914   2921   2921   2922   Any
        //  2915   2921   2914   2915   Any
        //  2915   2921   3      8      Ljava/lang/AssertionError;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:577)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public int 0() {
        return fez.fk(this, 905718373);
    }
    
    public void 0(final int n) {
        fez.5D(this, 1165443560, n);
    }
    
    @Override
    public void c(@NotNull final f4u p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          341
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            333
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            325
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: aload_1        
        //    27: goto            31
        //    30: athrow         
        //    31: invokevirtual   dev/nuker/pyro/f4u.c:()Ldev/nuker/pyro/f41;
        //    34: goto            38
        //    37: athrow         
        //    38: getstatic       dev/nuker/pyro/f41.c:Ldev/nuker/pyro/f41;
        //    41: if_acmpeq       45
        //    44: return         
        //    45: getstatic       dev/nuker/pyro/far.c:Lnet/minecraft/client/Minecraft;
        //    48: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //    51: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70165_t:D
        //    54: getstatic       dev/nuker/pyro/far.c:Lnet/minecraft/client/Minecraft;
        //    57: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //    60: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70169_q:D
        //    63: dsub           
        //    64: dstore_2       
        //    65: getstatic       dev/nuker/pyro/far.c:Lnet/minecraft/client/Minecraft;
        //    68: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //    71: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70161_v:D
        //    74: getstatic       dev/nuker/pyro/far.c:Lnet/minecraft/client/Minecraft;
        //    77: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //    80: getstatic       dev/nuker/pyro/fc.1:I
        //    83: ifne            92
        //    86: ldc_w           1964254430
        //    89: goto            95
        //    92: ldc_w           1991141204
        //    95: ldc_w           1805199739
        //    98: ixor           
        //    99: lookupswitch {
        //          490163759: 124
        //          512560549: 92
        //          default: 314
        //        }
        //   124: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70166_s:D
        //   127: dsub           
        //   128: dstore          4
        //   130: aload_0        
        //   131: dload_2        
        //   132: dload_2        
        //   133: dmul           
        //   134: getstatic       dev/nuker/pyro/fc.0:I
        //   137: ifgt            146
        //   140: ldc_w           1863865731
        //   143: goto            149
        //   146: ldc_w           789851533
        //   149: ldc_w           647651354
        //   152: ixor           
        //   153: lookupswitch {
        //          1107931463: 146
        //          1233270169: 310
        //          default: 180
        //        }
        //   180: dload           4
        //   182: dload           4
        //   184: dmul           
        //   185: dadd           
        //   186: dstore          6
        //   188: astore          9
        //   190: iconst_0       
        //   191: istore          8
        //   193: getstatic       dev/nuker/pyro/fc.c:I
        //   196: ifne            205
        //   199: ldc_w           -342975639
        //   202: goto            208
        //   205: ldc_w           -342435760
        //   208: ldc_w           1741724152
        //   211: ixor           
        //   212: lookupswitch {
        //          -1939996015: 312
        //          1750236729: 205
        //          default: 240
        //        }
        //   240: dload           6
        //   242: goto            246
        //   245: athrow         
        //   246: invokestatic    java/lang/Math.sqrt:(D)D
        //   249: goto            253
        //   252: athrow         
        //   253: dstore          10
        //   255: getstatic       dev/nuker/pyro/fc.c:I
        //   258: ifne            267
        //   261: ldc_w           1937917362
        //   264: goto            270
        //   267: ldc_w           -1116223484
        //   270: ldc_w           -1899309284
        //   273: ixor           
        //   274: lookupswitch {
        //          -45575506: 308
        //          713099319: 267
        //          default: 300
        //        }
        //   300: aload           9
        //   302: dload           10
        //   304: putfield        dev/nuker/pyro/faz.0:D
        //   307: return         
        //   308: aconst_null    
        //   309: athrow         
        //   310: aconst_null    
        //   311: athrow         
        //   312: aconst_null    
        //   313: athrow         
        //   314: aconst_null    
        //   315: athrow         
        //   316: pop            
        //   317: goto            24
        //   320: pop            
        //   321: aconst_null    
        //   322: goto            316
        //   325: dup            
        //   326: ifnull          316
        //   329: checkcast       Ljava/lang/Throwable;
        //   332: athrow         
        //   333: dup            
        //   334: ifnull          320
        //   337: checkcast       Ljava/lang/Throwable;
        //   340: athrow         
        //   341: aconst_null    
        //   342: athrow         
        //    StackMapTable: 00 22 43 07 00 42 04 FF 00 0B 00 00 00 01 07 00 42 FD 00 03 07 00 03 07 01 B4 45 07 00 42 40 07 01 B4 45 07 00 42 40 07 00 49 06 FF 00 2E 00 03 07 00 03 07 01 B4 03 00 02 03 07 00 76 FF 00 02 00 03 07 00 03 07 01 B4 03 00 03 03 07 00 76 01 FF 00 1C 00 03 07 00 03 07 01 B4 03 00 02 03 07 00 76 FF 00 15 00 04 07 00 03 07 01 B4 03 03 00 02 07 00 03 03 FF 00 02 00 04 07 00 03 07 01 B4 03 03 00 03 07 00 03 03 01 FF 00 1E 00 04 07 00 03 07 01 B4 03 03 00 02 07 00 03 03 FE 00 18 03 01 07 00 03 42 01 1F FF 00 04 00 00 00 01 07 00 42 FF 00 00 00 07 07 00 03 07 01 B4 03 03 03 01 07 00 03 00 01 03 45 07 00 42 40 03 FC 00 0D 03 42 01 1D 07 FF 00 01 00 04 07 00 03 07 01 B4 03 03 00 02 07 00 03 03 FE 00 01 03 01 07 00 03 FF 00 01 00 03 07 00 03 07 01 B4 03 00 02 03 07 00 76 FF 00 01 00 02 07 00 03 07 01 B4 00 01 07 00 42 43 05 44 07 00 42 47 05 47 07 00 42
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     325    333    Any
        //  325    333    325    333    Any
        //  341    343    3      8      Ljava/lang/RuntimeException;
        //  30     37     37     38     Any
        //  31     37     30     31     Any
        //  30     37     3      8      Ljava/lang/NullPointerException;
        //  30     37     3      8      Ljava/lang/EnumConstantNotPresentException;
        //  31     37     30     31     Any
        //  246    252    252    253    Any
        //  246    252    252    253    Any
        //  246    252    252    253    Any
        //  246    252    3      8      Any
        //  246    252    252    253    Ljava/lang/IndexOutOfBoundsException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 107 out of bounds for length 107
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public int c() {
        return fez.f9(this, 1198354125);
    }
    
    static {
        throw t;
    }
    
    @Override
    public void 0() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          270
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            262
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            254
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_0        
        //    25: goto            29
        //    28: athrow         
        //    29: invokestatic    dev/nuker/pyro/far.1:()D
        //    32: goto            36
        //    35: athrow         
        //    36: getstatic       dev/nuker/pyro/fc.0:I
        //    39: ifgt            48
        //    42: ldc_w           808261791
        //    45: goto            51
        //    48: ldc_w           -1450335877
        //    51: ldc_w           1096281178
        //    54: ixor           
        //    55: lookupswitch {
        //          -563467821: 48
        //          1903883461: 243
        //          default: 80
        //        }
        //    80: putfield        dev/nuker/pyro/faz.c:D
        //    83: aload_0        
        //    84: iconst_4       
        //    85: getstatic       dev/nuker/pyro/fc.c:I
        //    88: ifne            97
        //    91: ldc_w           1966152543
        //    94: goto            100
        //    97: ldc_w           69687088
        //   100: ldc_w           -926760208
        //   103: ixor           
        //   104: lookupswitch {
        //          -1108092497: 97
        //          -857369152: 132
        //          default: 237
        //        }
        //   132: putfield        dev/nuker/pyro/faz.c:I
        //   135: getstatic       dev/nuker/pyro/fc.c:I
        //   138: ifne            147
        //   141: ldc_w           666902758
        //   144: goto            150
        //   147: ldc_w           1705432009
        //   150: ldc_w           -1491403728
        //   153: ixor           
        //   154: lookupswitch {
        //          -2133140266: 147
        //          -1027854343: 180
        //          default: 239
        //        }
        //   180: aload_0        
        //   181: dconst_0       
        //   182: getstatic       dev/nuker/pyro/fc.c:I
        //   185: ifne            194
        //   188: ldc_w           1065006530
        //   191: goto            197
        //   194: ldc_w           1225372242
        //   197: ldc_w           -1618879363
        //   200: ixor           
        //   201: lookupswitch {
        //          -1594136129: 241
        //          -309156140: 194
        //          default: 228
        //        }
        //   228: putfield        dev/nuker/pyro/faz.0:D
        //   231: aload_0        
        //   232: iconst_0       
        //   233: putfield        dev/nuker/pyro/faz.0:I
        //   236: return         
        //   237: aconst_null    
        //   238: athrow         
        //   239: aconst_null    
        //   240: athrow         
        //   241: aconst_null    
        //   242: athrow         
        //   243: aconst_null    
        //   244: athrow         
        //   245: pop            
        //   246: goto            24
        //   249: pop            
        //   250: aconst_null    
        //   251: goto            245
        //   254: dup            
        //   255: ifnull          245
        //   258: checkcast       Ljava/lang/Throwable;
        //   261: athrow         
        //   262: dup            
        //   263: ifnull          249
        //   266: checkcast       Ljava/lang/Throwable;
        //   269: athrow         
        //   270: aconst_null    
        //   271: athrow         
        //    StackMapTable: 00 1D 43 07 00 42 04 FF 00 0B 00 00 00 01 07 00 42 FC 00 03 07 00 03 43 07 00 35 40 07 00 03 45 07 00 42 FF 00 00 00 01 07 00 03 00 02 07 00 03 03 FF 00 0B 00 01 07 00 03 00 02 07 00 03 03 FF 00 02 00 01 07 00 03 00 03 07 00 03 03 01 FF 00 1C 00 01 07 00 03 00 02 07 00 03 03 FF 00 10 00 01 07 00 03 00 02 07 00 03 01 FF 00 02 00 01 07 00 03 00 03 07 00 03 01 01 FF 00 1F 00 01 07 00 03 00 02 07 00 03 01 0E 42 01 1D FF 00 0D 00 01 07 00 03 00 02 07 00 03 03 FF 00 02 00 01 07 00 03 00 03 07 00 03 03 01 FF 00 1E 00 01 07 00 03 00 02 07 00 03 03 FF 00 08 00 01 07 00 03 00 02 07 00 03 01 01 FF 00 01 00 01 07 00 03 00 02 07 00 03 03 FF 00 01 00 01 07 00 03 00 02 07 00 03 03 41 07 00 42 43 05 44 07 00 42 47 05 47 07 00 42
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     254    262    Ljava/lang/ClassCastException;
        //  254    262    254    262    Any
        //  270    272    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  28     35     35     36     Any
        //  29     35     3      8      Any
        //  28     35     3      8      Ljava/lang/NumberFormatException;
        //  28     35     28     29     Ljava/lang/NullPointerException;
        //  29     35     3      8      Ljava/lang/NegativeArraySizeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 82 out of bounds for length 82
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void c() {
        fez.g1(this, 28050105);
    }
    
    public void c(final int n) {
        fez.5D(this, 1165443567, n);
    }
}
