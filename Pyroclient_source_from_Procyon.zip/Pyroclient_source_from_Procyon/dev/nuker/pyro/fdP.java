// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

public class fdP
{
    public static int c;
    public static int 0;
    public static int 1;
    public static int 2;
    public static int 3;
    public static int 4;
    public static int 5;
    public static fdP c;
    
    public fdP() {
        while (true) {
            int n = 0;
            Label_0014: {
                if (fc.0 <= 0) {
                    n = 607360514;
                    break Label_0014;
                }
                n = -34892731;
            }
            switch (n ^ 0x691828AE) {
                case 1294712492: {
                    continue;
                }
                case -1795965717: {}
                default: {
                    throw null;
                }
            }
            break;
        }
    }
    
    static {
        final int 5 = 63;
        while (true) {
            int n = 0;
            Label_0015: {
                if (fc.1 == 0) {
                    n = 662857528;
                    break Label_0015;
                }
                n = 1728531935;
            }
            switch (n ^ 0xC0FDE418) {
                case -411073760: {
                    continue;
                }
                case -1476744761: {
                    fdP.5 = 5;
                    final int 6 = 32;
                    while (true) {
                        int n2 = 0;
                        Label_0062: {
                            if (fc.1 == 0) {
                                n2 = 419273542;
                                break Label_0062;
                            }
                            n2 = 1286464714;
                        }
                        switch (n2 ^ 0x951B1BCA) {
                            case -1891480952: {
                                continue;
                            }
                            default: {
                                fdP.4 = 6;
                                fdP.3 = 16;
                                fdP.2 = 8;
                                fdP.1 = 4;
                                fdP.0 = 2;
                                final int c = 1;
                                while (true) {
                                    int n3 = 0;
                                    Label_0127: {
                                        if (fc.c == 0) {
                                            n3 = 1228471047;
                                            break Label_0127;
                                        }
                                        n3 = 2130589953;
                                    }
                                    switch (n3 ^ 0xF748B24F) {
                                        case -1099937464: {
                                            continue;
                                        }
                                        case -1984525490: {
                                            fdP.c = c;
                                            while (true) {
                                                int n4 = 0;
                                                Label_0176: {
                                                    if (fc.1 == 0) {
                                                        n4 = 803021314;
                                                        break Label_0176;
                                                    }
                                                    n4 = 252063393;
                                                }
                                                switch (n4 ^ 0xA3F285AC) {
                                                    case -1943033938: {
                                                        continue;
                                                    }
                                                    case -1393251571: {
                                                        final fdP fdP = new fdP();
                                                        while (true) {
                                                            int n5 = 0;
                                                            Label_0220: {
                                                                if (fc.c == 0) {
                                                                    n5 = -1517688815;
                                                                    break Label_0220;
                                                                }
                                                                n5 = -1427917975;
                                                            }
                                                            switch (n5 ^ 0x865692E) {
                                                                case -736714185: {
                                                                    continue;
                                                                }
                                                                default: {
                                                                    final fdP c2 = fdP;
                                                                    while (true) {
                                                                        int n6 = 0;
                                                                        Label_0263: {
                                                                            if (fc.c == 0) {
                                                                                n6 = 845196432;
                                                                                break Label_0263;
                                                                            }
                                                                            n6 = 2081934762;
                                                                        }
                                                                        switch (n6 ^ 0xD2F7386E) {
                                                                            case -526936834: {
                                                                                continue;
                                                                            }
                                                                            case -1360988732: {
                                                                                dev.nuker.pyro.fdP.c = c2;
                                                                                return;
                                                                            }
                                                                            default: {
                                                                                throw null;
                                                                            }
                                                                        }
                                                                        break;
                                                                    }
                                                                    break;
                                                                }
                                                                case -1377009345: {
                                                                    throw null;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        break;
                                                    }
                                                    default: {
                                                        throw null;
                                                    }
                                                }
                                                break;
                                            }
                                            break;
                                        }
                                        default: {
                                            throw null;
                                        }
                                    }
                                    break;
                                }
                                break;
                            }
                            case -1914273652: {
                                throw null;
                            }
                        }
                        break;
                    }
                    break;
                }
                default: {
                    throw null;
                }
            }
            break;
        }
    }
}
