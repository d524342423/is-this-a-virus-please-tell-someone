// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

public enum f7l
{
    public static f7l c;
    public static f7l 0;
    public static f7l 1;
    public static f7l[] c;
    
    public f7l(final String name, final int ordinal) {
        while (true) {
            Label_0013: {
                if (fc.0 <= 0) {
                    n = 539409118;
                    break Label_0013;
                }
                n = 1930439568;
            }
            switch (n ^ 0xBDA52380) {
                case -1196944064: {
                    continue;
                }
                default: {
                    super(name, ordinal);
                }
                case -1652319906: {
                    throw null;
                }
            }
            break;
        }
    }
    
    static {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: anewarray       Ldev/nuker/pyro/f7l;
        //     4: dup            
        //     5: dup            
        //     6: iconst_0       
        //     7: new             Ldev/nuker/pyro/f7l;
        //    10: dup            
        //    11: ldc             "\u3cb3\ub243\u8fd0"
        //    13: getstatic       dev/nuker/pyro/fc.0:I
        //    16: ifgt            24
        //    19: ldc             -2092444522
        //    21: goto            26
        //    24: ldc             -193408825
        //    26: ldc             -1926808575
        //    28: ixor           
        //    29: lookupswitch {
        //          241232023: 24
        //          2036329670: 56
        //          default: 248
        //        }
        //    56: invokestatic    invokestatic   !!! ERROR
        //    59: iconst_0       
        //    60: invokespecial   dev/nuker/pyro/f7l.<init>:(Ljava/lang/String;I)V
        //    63: dup            
        //    64: putstatic       dev/nuker/pyro/f7l.c:Ldev/nuker/pyro/f7l;
        //    67: aastore        
        //    68: dup            
        //    69: iconst_1       
        //    70: new             Ldev/nuker/pyro/f7l;
        //    73: dup            
        //    74: ldc             "\u3caf\ub240\u8fdb\ua176"
        //    76: invokestatic    invokestatic   !!! ERROR
        //    79: iconst_1       
        //    80: invokespecial   dev/nuker/pyro/f7l.<init>:(Ljava/lang/String;I)V
        //    83: dup            
        //    84: putstatic       dev/nuker/pyro/f7l.0:Ldev/nuker/pyro/f7l;
        //    87: aastore        
        //    88: dup            
        //    89: iconst_2       
        //    90: new             Ldev/nuker/pyro/f7l;
        //    93: dup            
        //    94: ldc             "\u3cba\ub250\u8fda\ua173"
        //    96: getstatic       dev/nuker/pyro/fc.0:I
        //    99: ifgt            107
        //   102: ldc             -812836054
        //   104: goto            109
        //   107: ldc             1295440177
        //   109: ldc             -1864021408
        //   111: ixor           
        //   112: lookupswitch {
        //          -573336751: 140
        //          1600672074: 107
        //          default: 244
        //        }
        //   140: invokestatic    invokestatic   !!! ERROR
        //   143: iconst_2       
        //   144: getstatic       dev/nuker/pyro/fc.0:I
        //   147: ifgt            155
        //   150: ldc             -362934604
        //   152: goto            157
        //   155: ldc             163944696
        //   157: ldc             368530561
        //   159: ixor           
        //   160: lookupswitch {
        //          -5678539: 155
        //          473091193: 188
        //          default: 250
        //        }
        //   188: invokespecial   dev/nuker/pyro/f7l.<init>:(Ljava/lang/String;I)V
        //   191: dup            
        //   192: getstatic       dev/nuker/pyro/fc.c:I
        //   195: ifne            203
        //   198: ldc             -849857419
        //   200: goto            205
        //   203: ldc             1588026684
        //   205: ldc             -1729098798
        //   207: ixor           
        //   208: lookupswitch {
        //          827844375: 203
        //          1437089703: 246
        //          default: 236
        //        }
        //   236: putstatic       dev/nuker/pyro/f7l.1:Ldev/nuker/pyro/f7l;
        //   239: aastore        
        //   240: putstatic       dev/nuker/pyro/f7l.c:[Ldev/nuker/pyro/f7l;
        //   243: return         
        //   244: aconst_null    
        //   245: athrow         
        //   246: aconst_null    
        //   247: athrow         
        //   248: aconst_null    
        //   249: athrow         
        //   250: aconst_null    
        //   251: athrow         
        //    StackMapTable: 00 10 FF 00 18 00 00 00 07 07 00 25 07 00 25 07 00 25 01 08 00 07 08 00 07 07 00 4F FF 00 01 00 00 00 08 07 00 25 07 00 25 07 00 25 01 08 00 07 08 00 07 07 00 4F 01 FF 00 1D 00 00 00 07 07 00 25 07 00 25 07 00 25 01 08 00 07 08 00 07 07 00 4F FF 00 32 00 00 00 07 07 00 25 07 00 25 07 00 25 01 08 00 5A 08 00 5A 07 00 4F FF 00 01 00 00 00 08 07 00 25 07 00 25 07 00 25 01 08 00 5A 08 00 5A 07 00 4F 01 FF 00 1E 00 00 00 07 07 00 25 07 00 25 07 00 25 01 08 00 5A 08 00 5A 07 00 4F FF 00 0E 00 00 00 08 07 00 25 07 00 25 07 00 25 01 08 00 5A 08 00 5A 07 00 4F 01 FF 00 01 00 00 00 09 07 00 25 07 00 25 07 00 25 01 08 00 5A 08 00 5A 07 00 4F 01 01 FF 00 1E 00 00 00 08 07 00 25 07 00 25 07 00 25 01 08 00 5A 08 00 5A 07 00 4F 01 FF 00 0E 00 00 00 06 07 00 25 07 00 25 07 00 25 01 07 00 03 07 00 03 FF 00 01 00 00 00 07 07 00 25 07 00 25 07 00 25 01 07 00 03 07 00 03 01 FF 00 1E 00 00 00 06 07 00 25 07 00 25 07 00 25 01 07 00 03 07 00 03 FF 00 07 00 00 00 07 07 00 25 07 00 25 07 00 25 01 08 00 5A 08 00 5A 07 00 4F FF 00 01 00 00 00 06 07 00 25 07 00 25 07 00 25 01 07 00 03 07 00 03 FF 00 01 00 00 00 07 07 00 25 07 00 25 07 00 25 01 08 00 07 08 00 07 07 00 4F FF 00 01 00 00 00 08 07 00 25 07 00 25 07 00 25 01 08 00 5A 08 00 5A 07 00 4F 01
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static f7l c(final String p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          156
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            148
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            140
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: ldc             Ldev/nuker/pyro/f7l;.class
        //    26: getstatic       dev/nuker/pyro/fc.0:I
        //    29: ifgt            37
        //    32: ldc             1613851906
        //    34: goto            39
        //    37: ldc             1395079471
        //    39: ldc             1420300443
        //    41: ixor           
        //    42: lookupswitch {
        //          126822836: 68
        //          882474393: 37
        //          default: 129
        //        }
        //    68: aload_0        
        //    69: getstatic       dev/nuker/pyro/fc.0:I
        //    72: ifgt            80
        //    75: ldc             -563913373
        //    77: goto            82
        //    80: ldc             -210351517
        //    82: ldc             -1444657383
        //    84: ixor           
        //    85: lookupswitch {
        //          1519521146: 112
        //          2005342842: 80
        //          default: 127
        //        }
        //   112: goto            116
        //   115: athrow         
        //   116: invokestatic    java/lang/Enum.valueOf:(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;
        //   119: goto            123
        //   122: athrow         
        //   123: checkcast       Ldev/nuker/pyro/f7l;
        //   126: areturn        
        //   127: aconst_null    
        //   128: athrow         
        //   129: aconst_null    
        //   130: athrow         
        //   131: pop            
        //   132: goto            24
        //   135: pop            
        //   136: aconst_null    
        //   137: goto            131
        //   140: dup            
        //   141: ifnull          131
        //   144: checkcast       Ljava/lang/Throwable;
        //   147: athrow         
        //   148: dup            
        //   149: ifnull          135
        //   152: checkcast       Ljava/lang/Throwable;
        //   155: athrow         
        //   156: aconst_null    
        //   157: athrow         
        //    StackMapTable: 00 15 43 07 00 22 04 FF 00 0B 00 00 00 01 07 00 22 FC 00 03 07 00 4F 4C 07 00 60 FF 00 01 00 01 07 00 4F 00 02 07 00 60 01 5C 07 00 60 FF 00 0B 00 01 07 00 4F 00 02 07 00 60 07 00 4F FF 00 01 00 01 07 00 4F 00 03 07 00 60 07 00 4F 01 FF 00 1D 00 01 07 00 4F 00 02 07 00 60 07 00 4F FF 00 02 00 00 00 01 07 00 22 FF 00 00 00 01 07 00 4F 00 02 07 00 60 07 00 4F 45 07 00 22 40 07 00 05 FF 00 03 00 01 07 00 4F 00 02 07 00 60 07 00 4F 41 07 00 60 41 07 00 22 43 05 44 07 00 22 47 05 47 07 00 22
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     140    148    Any
        //  140    148    140    148    Any
        //  156    158    3      8      Any
        //  116    122    122    123    Any
        //  116    122    122    123    Any
        //  116    122    3      8      Any
        //  116    122    3      8      Ljava/util/ConcurrentModificationException;
        //  116    122    3      8      Ljava/lang/AssertionError;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 46 out of bounds for length 46
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
