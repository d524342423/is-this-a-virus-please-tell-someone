// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import kotlin.jvm.JvmStatic;
import kotlin.jvm.JvmOverloads;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;
import net.minecraft.client.gui.FontRenderer;

public class f0J
{
    public static f0J c;
    
    public void c(final int n, final int n2, final int n3, final int n4, final int n5, final int n6) {
        fez.0a(this, 565278739, n, n2, n3, n4, n5, n6);
    }
    
    public void 0(@NotNull final FontRenderer fontRenderer, @Nullable final String s, final int n, final int n2, final int n3) {
        fez.1B(this, 1780940644, fontRenderer, s, n, n2, n3);
    }
    
    @JvmOverloads
    public void c(@NotNull final FontRenderer p0, @Nullable final String p1, final int p2, final int p3, final int p4, final int p5, @NotNull final f0G p6, final int p7, final int p8, final boolean p9) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          915
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            907
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            899
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: aload           7
        //    28: pop            
        //    29: iload_3        
        //    30: istore          11
        //    32: iload           4
        //    34: istore          12
        //    36: getstatic       dev/nuker/pyro/fc.c:I
        //    39: ifne            47
        //    42: ldc             -1891792706
        //    44: goto            49
        //    47: ldc             -1794844444
        //    49: ldc             2114885318
        //    51: ixor           
        //    52: lookupswitch {
        //          -1407002334: 47
        //          -248308104: 888
        //          default: 80
        //        }
        //    80: iload           5
        //    82: getstatic       dev/nuker/pyro/fc.c:I
        //    85: ifne            93
        //    88: ldc             -529966377
        //    90: goto            95
        //    93: ldc             -116071143
        //    95: ldc             955177937
        //    97: ixor           
        //    98: lookupswitch {
        //          -1040564536: 124
        //          -662208250: 93
        //          default: 876
        //        }
        //   124: istore          13
        //   126: iload           6
        //   128: istore          14
        //   130: aload_1        
        //   131: aload_2        
        //   132: goto            136
        //   135: athrow         
        //   136: invokevirtual   net/minecraft/client/gui/FontRenderer.func_78256_a:(Ljava/lang/String;)I
        //   139: goto            143
        //   142: athrow         
        //   143: istore          15
        //   145: aload_1        
        //   146: getfield        net/minecraft/client/gui/FontRenderer.field_78288_b:I
        //   149: getstatic       dev/nuker/pyro/fc.c:I
        //   152: ifne            160
        //   155: ldc             71755382
        //   157: goto            162
        //   160: ldc             850050302
        //   162: ldc             691573330
        //   164: ixor           
        //   165: lookupswitch {
        //          763261988: 860
        //          1285807559: 160
        //          default: 192
        //        }
        //   192: istore          16
        //   194: iload           11
        //   196: iload           8
        //   198: iadd           
        //   199: istore          11
        //   201: iload           12
        //   203: iload           8
        //   205: iadd           
        //   206: istore          12
        //   208: iload           13
        //   210: getstatic       dev/nuker/pyro/fc.c:I
        //   213: ifne            221
        //   216: ldc             564821274
        //   218: goto            223
        //   221: ldc             -1804222359
        //   223: ldc             -1142361191
        //   225: ixor           
        //   226: lookupswitch {
        //          -1706914173: 872
        //          1724430444: 221
        //          default: 252
        //        }
        //   252: iload           8
        //   254: isub           
        //   255: istore          13
        //   257: iload           14
        //   259: getstatic       dev/nuker/pyro/fc.1:I
        //   262: ifne            270
        //   265: ldc             1425220152
        //   267: goto            272
        //   270: ldc             13480778
        //   272: ldc             545257763
        //   274: ixor           
        //   275: lookupswitch {
        //          -302791706: 270
        //          1955388187: 884
        //          default: 300
        //        }
        //   300: iload           8
        //   302: isub           
        //   303: istore          14
        //   305: iload           12
        //   307: iload           14
        //   309: iconst_2       
        //   310: idiv           
        //   311: iload           16
        //   313: iconst_2       
        //   314: idiv           
        //   315: isub           
        //   316: iconst_1       
        //   317: isub           
        //   318: iadd           
        //   319: istore          12
        //   321: aload           7
        //   323: getstatic       dev/nuker/pyro/fc.0:I
        //   326: ifgt            334
        //   329: ldc             -817852643
        //   331: goto            336
        //   334: ldc             -1942175402
        //   336: ldc             -1036244437
        //   338: ixor           
        //   339: lookupswitch {
        //          226272566: 334
        //          1308683133: 364
        //          default: 882
        //        }
        //   364: getstatic       dev/nuker/pyro/f0I.c:[I
        //   367: swap           
        //   368: goto            372
        //   371: athrow         
        //   372: invokevirtual   dev/nuker/pyro/f0G.ordinal:()I
        //   375: goto            379
        //   378: athrow         
        //   379: iaload         
        //   380: tableswitch {
        //                2: 404
        //                3: 459
        //          default: 514
        //        }
        //   404: iload           11
        //   406: getstatic       dev/nuker/pyro/fc.1:I
        //   409: ifne            417
        //   412: ldc             -105896963
        //   414: goto            419
        //   417: ldc             -1548760319
        //   419: ldc             -301478653
        //   421: ixor           
        //   422: lookupswitch {
        //          397930238: 417
        //          1302857218: 448
        //          default: 862
        //        }
        //   448: iload           13
        //   450: iload           15
        //   452: isub           
        //   453: iadd           
        //   454: istore          11
        //   456: goto            514
        //   459: getstatic       dev/nuker/pyro/fc.1:I
        //   462: ifne            470
        //   465: ldc             1842204518
        //   467: goto            472
        //   470: ldc             -1579116768
        //   472: ldc             1622701099
        //   474: ixor           
        //   475: lookupswitch {
        //          -946949019: 470
        //          225819469: 886
        //          default: 500
        //        }
        //   500: iload           11
        //   502: iload           13
        //   504: iconst_2       
        //   505: idiv           
        //   506: iload           15
        //   508: iconst_2       
        //   509: idiv           
        //   510: isub           
        //   511: iadd           
        //   512: istore          11
        //   514: getstatic       dev/nuker/pyro/fc.0:I
        //   517: ifgt            525
        //   520: ldc             1053246638
        //   522: goto            527
        //   525: ldc             1043757001
        //   527: ldc             -1488906825
        //   529: ixor           
        //   530: lookupswitch {
        //          -1959913482: 525
        //          -1719250663: 874
        //          default: 556
        //        }
        //   556: iload           10
        //   558: ifeq            754
        //   561: aload_0        
        //   562: getstatic       dev/nuker/pyro/fc.0:I
        //   565: ifgt            573
        //   568: ldc             -1823033181
        //   570: goto            575
        //   573: ldc             2084940
        //   575: ldc             1273669981
        //   577: ixor           
        //   578: lookupswitch {
        //          -658763266: 866
        //          208156352: 573
        //          default: 604
        //        }
        //   604: aload_1        
        //   605: aload_2        
        //   606: getstatic       dev/nuker/pyro/fc.0:I
        //   609: ifgt            617
        //   612: ldc             1306188092
        //   614: goto            619
        //   617: ldc             -1185804111
        //   619: ldc             2070426514
        //   621: ixor           
        //   622: lookupswitch {
        //          917695150: 868
        //          2032773279: 617
        //          default: 648
        //        }
        //   648: iload           11
        //   650: getstatic       dev/nuker/pyro/fc.0:I
        //   653: ifgt            661
        //   656: ldc             -1766403100
        //   658: goto            663
        //   661: ldc             -2145144320
        //   663: ldc             -192334783
        //   665: ixor           
        //   666: lookupswitch {
        //          1648355237: 661
        //          1957332545: 692
        //          default: 878
        //        }
        //   692: iload           12
        //   694: iload           9
        //   696: getstatic       dev/nuker/pyro/fc.0:I
        //   699: ifgt            707
        //   702: ldc             -384546774
        //   704: goto            709
        //   707: ldc             -80468325
        //   709: ldc             -42506765
        //   711: ixor           
        //   712: lookupswitch {
        //          105071464: 740
        //          342044121: 707
        //          default: 880
        //        }
        //   740: goto            744
        //   743: athrow         
        //   744: invokevirtual   dev/nuker/pyro/f0J.c:(Lnet/minecraft/client/gui/FontRenderer;Ljava/lang/String;III)V
        //   747: goto            751
        //   750: athrow         
        //   751: goto            859
        //   754: aload_0        
        //   755: aload_1        
        //   756: aload_2        
        //   757: getstatic       dev/nuker/pyro/fc.c:I
        //   760: ifne            768
        //   763: ldc             -437032640
        //   765: goto            770
        //   768: ldc             2034340937
        //   770: ldc             1638197364
        //   772: ixor           
        //   773: lookupswitch {
        //          -2074640076: 864
        //          -1613640096: 768
        //          default: 800
        //        }
        //   800: iload           11
        //   802: iload           12
        //   804: iload           9
        //   806: getstatic       dev/nuker/pyro/fc.c:I
        //   809: ifne            817
        //   812: ldc             272606008
        //   814: goto            819
        //   817: ldc             -640773841
        //   819: ldc             2041961245
        //   821: ixor           
        //   822: lookupswitch {
        //          122280008: 817
        //          1770682405: 870
        //          default: 848
        //        }
        //   848: goto            852
        //   851: athrow         
        //   852: invokevirtual   dev/nuker/pyro/f0J.0:(Lnet/minecraft/client/gui/FontRenderer;Ljava/lang/String;III)V
        //   855: goto            859
        //   858: athrow         
        //   859: return         
        //   860: aconst_null    
        //   861: athrow         
        //   862: aconst_null    
        //   863: athrow         
        //   864: aconst_null    
        //   865: athrow         
        //   866: aconst_null    
        //   867: athrow         
        //   868: aconst_null    
        //   869: athrow         
        //   870: aconst_null    
        //   871: athrow         
        //   872: aconst_null    
        //   873: athrow         
        //   874: aconst_null    
        //   875: athrow         
        //   876: aconst_null    
        //   877: athrow         
        //   878: aconst_null    
        //   879: athrow         
        //   880: aconst_null    
        //   881: athrow         
        //   882: aconst_null    
        //   883: athrow         
        //   884: aconst_null    
        //   885: athrow         
        //   886: aconst_null    
        //   887: athrow         
        //   888: aconst_null    
        //   889: athrow         
        //   890: pop            
        //   891: goto            24
        //   894: pop            
        //   895: aconst_null    
        //   896: goto            890
        //   899: dup            
        //   900: ifnull          890
        //   903: checkcast       Ljava/lang/Throwable;
        //   906: athrow         
        //   907: dup            
        //   908: ifnull          894
        //   911: checkcast       Ljava/lang/Throwable;
        //   914: athrow         
        //   915: aconst_null    
        //   916: athrow         
        //    StackMapTable: 00 59 FF 00 03 00 0F 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 00 01 07 00 32 FF 00 04 00 0B 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 00 00 FF 00 0B 00 00 00 01 07 00 32 FF 00 03 00 0B 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 00 00 FD 00 16 01 01 41 01 1E 4C 01 FF 00 01 00 0D 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 00 02 01 01 5C 01 FF 00 0A 00 0F 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 00 01 07 00 24 FF 00 00 00 0F 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 00 02 07 00 3C 07 00 7D 45 07 00 32 40 01 FF 00 10 00 10 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 00 01 01 FF 00 01 00 10 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 00 02 01 01 5D 01 FF 00 1C 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 01 01 FF 00 01 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 02 01 01 5C 01 51 01 FF 00 01 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 02 01 01 5B 01 61 07 00 58 FF 00 01 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 02 07 00 58 01 5B 07 00 58 46 07 00 32 FF 00 00 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 02 07 00 7E 07 00 58 45 07 00 32 FF 00 00 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 02 07 00 7E 01 18 4C 01 FF 00 01 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 02 01 01 5C 01 0A 0A 41 01 1B 0D 0A 41 01 1C 50 07 00 03 FF 00 01 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 02 07 00 03 01 5C 07 00 03 FF 00 0C 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 03 07 00 03 07 00 3C 07 00 7D FF 00 01 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 04 07 00 03 07 00 3C 07 00 7D 01 FF 00 1C 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 03 07 00 03 07 00 3C 07 00 7D FF 00 0C 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 04 07 00 03 07 00 3C 07 00 7D 01 FF 00 01 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 05 07 00 03 07 00 3C 07 00 7D 01 01 FF 00 1C 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 04 07 00 03 07 00 3C 07 00 7D 01 FF 00 0E 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 06 07 00 03 07 00 3C 07 00 7D 01 01 01 FF 00 01 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 07 07 00 03 07 00 3C 07 00 7D 01 01 01 01 FF 00 1E 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 06 07 00 03 07 00 3C 07 00 7D 01 01 01 42 07 00 32 FF 00 00 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 06 07 00 03 07 00 3C 07 00 7D 01 01 01 45 07 00 32 00 02 FF 00 0D 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 03 07 00 03 07 00 3C 07 00 7D FF 00 01 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 04 07 00 03 07 00 3C 07 00 7D 01 FF 00 1D 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 03 07 00 03 07 00 3C 07 00 7D FF 00 10 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 06 07 00 03 07 00 3C 07 00 7D 01 01 01 FF 00 01 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 07 07 00 03 07 00 3C 07 00 7D 01 01 01 01 FF 00 1C 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 06 07 00 03 07 00 3C 07 00 7D 01 01 01 42 07 00 32 FF 00 00 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 06 07 00 03 07 00 3C 07 00 7D 01 01 01 45 07 00 32 00 FF 00 00 00 10 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 00 01 01 FF 00 01 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 01 01 FF 00 01 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 03 07 00 03 07 00 3C 07 00 7D 41 07 00 03 FF 00 01 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 03 07 00 03 07 00 3C 07 00 7D FF 00 01 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 06 07 00 03 07 00 3C 07 00 7D 01 01 01 41 01 01 FF 00 01 00 0D 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 00 01 01 FF 00 01 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 04 07 00 03 07 00 3C 07 00 7D 01 FF 00 01 00 11 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 01 01 00 06 07 00 03 07 00 3C 07 00 7D 01 01 01 41 07 00 58 41 01 01 FF 00 01 00 0D 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 00 00 FF 00 01 00 0B 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 00 01 07 00 32 43 05 44 07 00 32 47 05 FF 00 07 00 0F 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 01 01 01 00 01 07 00 32
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     899    907    Ljava/lang/AssertionError;
        //  899    907    899    907    Ljava/lang/RuntimeException;
        //  915    917    3      8      Any
        //  135    142    142    143    Any
        //  135    142    3      8      Any
        //  135    142    3      8      Any
        //  136    142    135    136    Ljava/util/NoSuchElementException;
        //  135    142    142    143    Any
        //  371    378    378    379    Any
        //  372    378    3      8      Any
        //  372    378    371    372    Ljava/lang/ClassCastException;
        //  371    378    3      8      Any
        //  372    378    371    372    Any
        //  743    750    750    751    Any
        //  744    750    3      8      Any
        //  743    750    743    744    Any
        //  744    750    743    744    Any
        //  744    750    750    751    Ljava/util/ConcurrentModificationException;
        //  851    858    858    859    Any
        //  852    858    851    852    Any
        //  852    858    3      8      Any
        //  851    858    858    859    Ljava/lang/NegativeArraySizeException;
        //  852    858    851    852    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visitVariable(StackMappingVisitor.java:470)
        //     at com.strobel.assembler.ir.Instruction.accept(Instruction.java:556)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:403)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static void c(final f0J p0, final FontRenderer p1, final String p2, final int p3, final int p4, final int p5, final int p6, final f0G p7, final int p8, final int p9, final boolean p10, final int p11, final Object p12) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          225
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            217
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            209
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: getstatic       dev/nuker/pyro/fc.1:I
        //    27: ifne            35
        //    30: ldc             905033554
        //    32: goto            37
        //    35: ldc             627849684
        //    37: ldc             -987165044
        //    39: ixor           
        //    40: lookupswitch {
        //          -532334760: 68
        //          -254232098: 35
        //          default: 196
        //        }
        //    68: iload           11
        //    70: sipush          512
        //    73: iand           
        //    74: ifeq            80
        //    77: iconst_0       
        //    78: istore          10
        //    80: aload_0        
        //    81: getstatic       dev/nuker/pyro/fc.c:I
        //    84: ifne            92
        //    87: ldc             676143252
        //    89: goto            94
        //    92: ldc             1434309884
        //    94: ldc             1073196512
        //    96: ixor           
        //    97: lookupswitch {
        //          398101876: 92
        //          1787459868: 124
        //          default: 198
        //        }
        //   124: aload_1        
        //   125: aload_2        
        //   126: iload_3        
        //   127: iload           4
        //   129: iload           5
        //   131: iload           6
        //   133: aload           7
        //   135: iload           8
        //   137: iload           9
        //   139: getstatic       dev/nuker/pyro/fc.0:I
        //   142: ifgt            150
        //   145: ldc             -675525950
        //   147: goto            152
        //   150: ldc             -443472142
        //   152: ldc             -1260180591
        //   154: ixor           
        //   155: lookupswitch {
        //          -1692975626: 150
        //          1667195219: 194
        //          default: 180
        //        }
        //   180: iload           10
        //   182: goto            186
        //   185: athrow         
        //   186: invokevirtual   dev/nuker/pyro/f0J.c:(Lnet/minecraft/client/gui/FontRenderer;Ljava/lang/String;IIIILdev/nuker/pyro/f0G;IIZ)V
        //   189: goto            193
        //   192: athrow         
        //   193: return         
        //   194: aconst_null    
        //   195: athrow         
        //   196: aconst_null    
        //   197: athrow         
        //   198: aconst_null    
        //   199: athrow         
        //   200: pop            
        //   201: goto            24
        //   204: pop            
        //   205: aconst_null    
        //   206: goto            200
        //   209: dup            
        //   210: ifnull          200
        //   213: checkcast       Ljava/lang/Throwable;
        //   216: athrow         
        //   217: dup            
        //   218: ifnull          204
        //   221: checkcast       Ljava/lang/Throwable;
        //   224: athrow         
        //   225: aconst_null    
        //   226: athrow         
        //    StackMapTable: 00 1A 43 07 00 32 04 FF 00 0B 00 00 00 01 07 00 32 FF 00 03 00 0D 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 07 00 05 00 00 0A 41 01 1E 0B 4B 07 00 03 FF 00 01 00 0D 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 07 00 05 00 02 07 00 03 01 5D 07 00 03 FF 00 19 00 0D 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 07 00 05 00 0A 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 FF 00 01 00 0D 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 07 00 05 00 0B 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 FF 00 1B 00 0D 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 07 00 05 00 0A 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 FF 00 04 00 00 00 01 07 00 32 FF 00 00 00 0D 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 07 00 05 00 0B 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 45 07 00 32 00 FF 00 00 00 0D 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 07 00 05 00 0A 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 41 07 00 03 41 07 00 22 43 05 44 07 00 22 47 05 47 07 00 32
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                      
        //  -----  -----  -----  -----  ------------------------------------------
        //  8      20     209    217    Ljava/util/NoSuchElementException;
        //  209    217    209    217    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  225    227    3      8      Ljava/lang/IllegalStateException;
        //  186    192    192    193    Any
        //  186    192    3      8      Any
        //  186    192    192    193    Any
        //  186    192    192    193    Ljava/lang/NegativeArraySizeException;
        //  186    192    3      8      Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 77 out of bounds for length 77
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public int c(@NotNull final FontRenderer p0, @Nullable final String p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          686
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            678
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            670
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: getstatic       dev/nuker/pyro/fc.0:I
        //    29: ifgt            37
        //    32: ldc             1487208164
        //    34: goto            39
        //    37: ldc             -2006479517
        //    39: ldc             1912329175
        //    41: ixor           
        //    42: lookupswitch {
        //          694103347: 643
        //          902681978: 37
        //          default: 68
        //        }
        //    68: aload_2        
        //    69: ifnonnull       76
        //    72: iconst_0       
        //    73: goto            642
        //    76: iconst_0       
        //    77: istore_3       
        //    78: iconst_0       
        //    79: istore          4
        //    81: iconst_0       
        //    82: istore          5
        //    84: iload           5
        //    86: getstatic       dev/nuker/pyro/fc.0:I
        //    89: ifgt            97
        //    92: ldc             1205629546
        //    94: goto            99
        //    97: ldc             545574122
        //    99: ldc             1042516295
        //   101: ixor           
        //   102: lookupswitch {
        //          -1387521916: 97
        //          2046819117: 651
        //          default: 128
        //        }
        //   128: aload_2        
        //   129: goto            133
        //   132: athrow         
        //   133: invokevirtual   java/lang/String.length:()I
        //   136: goto            140
        //   139: athrow         
        //   140: if_icmpge       641
        //   143: aload_2        
        //   144: iload           5
        //   146: goto            150
        //   149: athrow         
        //   150: invokevirtual   java/lang/String.charAt:(I)C
        //   153: goto            157
        //   156: athrow         
        //   157: istore          6
        //   159: aload_1        
        //   160: iload           6
        //   162: goto            166
        //   165: athrow         
        //   166: invokevirtual   net/minecraft/client/gui/FontRenderer.func_78263_a:(C)I
        //   169: goto            173
        //   172: athrow         
        //   173: getstatic       dev/nuker/pyro/fc.1:I
        //   176: ifne            184
        //   179: ldc             -727858763
        //   181: goto            186
        //   184: ldc             408173160
        //   186: ldc             214388912
        //   188: ixor           
        //   189: lookupswitch {
        //          -665153275: 184
        //          345205464: 216
        //          default: 645
        //        }
        //   216: istore          7
        //   218: iload           7
        //   220: ifge            542
        //   223: getstatic       dev/nuker/pyro/fc.c:I
        //   226: ifne            234
        //   229: ldc             -1894644080
        //   231: goto            236
        //   234: ldc             2020213154
        //   236: ldc             1698356880
        //   238: ixor           
        //   239: lookupswitch {
        //          -366422016: 234
        //          491839282: 264
        //          default: 657
        //        }
        //   264: iload           5
        //   266: aload_2        
        //   267: goto            271
        //   270: athrow         
        //   271: invokevirtual   java/lang/String.length:()I
        //   274: goto            278
        //   277: athrow         
        //   278: iconst_1       
        //   279: isub           
        //   280: if_icmpge       542
        //   283: iinc            5, 1
        //   286: getstatic       dev/nuker/pyro/fc.1:I
        //   289: ifne            297
        //   292: ldc             -1879977265
        //   294: goto            299
        //   297: ldc             1519819106
        //   299: ldc             -1304433929
        //   301: ixor           
        //   302: lookupswitch {
        //          -733765033: 297
        //          1036924984: 659
        //          default: 328
        //        }
        //   328: aload_2        
        //   329: getstatic       dev/nuker/pyro/fc.1:I
        //   332: ifne            340
        //   335: ldc             1599110521
        //   337: goto            342
        //   340: ldc             864357612
        //   342: ldc             -1991060080
        //   344: ixor           
        //   345: lookupswitch {
        //          -1639470703: 340
        //          -704468759: 649
        //          default: 372
        //        }
        //   372: iload           5
        //   374: goto            378
        //   377: athrow         
        //   378: invokevirtual   java/lang/String.charAt:(I)C
        //   381: goto            385
        //   384: athrow         
        //   385: istore          6
        //   387: iload           6
        //   389: bipush          108
        //   391: if_icmpeq       494
        //   394: getstatic       dev/nuker/pyro/fc.c:I
        //   397: ifne            405
        //   400: ldc             -134696322
        //   402: goto            407
        //   405: ldc             -1761625805
        //   407: ldc             1283306063
        //   409: ixor           
        //   410: lookupswitch {
        //          -1148911567: 405
        //          -629011588: 436
        //          default: 655
        //        }
        //   436: iload           6
        //   438: bipush          76
        //   440: if_icmpeq       494
        //   443: iload           6
        //   445: bipush          114
        //   447: if_icmpeq       488
        //   450: iload           6
        //   452: bipush          82
        //   454: if_icmpne       462
        //   457: ldc             444423336
        //   459: goto            464
        //   462: ldc             444423339
        //   464: ldc             1221130549
        //   466: ixor           
        //   467: tableswitch {
        //          -1519695046: 488
        //          -1519695045: 497
        //          default: 457
        //        }
        //   488: iconst_0       
        //   489: istore          4
        //   491: goto            497
        //   494: iconst_1       
        //   495: istore          4
        //   497: iconst_0       
        //   498: getstatic       dev/nuker/pyro/fc.0:I
        //   501: ifgt            509
        //   504: ldc             -588494773
        //   506: goto            511
        //   509: ldc             -728832460
        //   511: ldc             -1995569528
        //   513: ixor           
        //   514: lookupswitch {
        //          658070742: 509
        //          1440894659: 647
        //          default: 540
        //        }
        //   540: istore          7
        //   542: iload_3        
        //   543: iload           7
        //   545: iadd           
        //   546: istore_3       
        //   547: getstatic       dev/nuker/pyro/fc.0:I
        //   550: ifgt            558
        //   553: ldc             -1173607041
        //   555: goto            560
        //   558: ldc             -1628010644
        //   560: ldc             -1524178216
        //   562: ixor           
        //   563: lookupswitch {
        //          522899367: 653
        //          545400827: 558
        //          default: 588
        //        }
        //   588: iload           4
        //   590: ifeq            635
        //   593: iload           7
        //   595: ifle            603
        //   598: ldc             698256332
        //   600: goto            605
        //   603: ldc             698256335
        //   605: ldc             -511383839
        //   607: ixor           
        //   608: tableswitch {
        //          -1875584422: 632
        //          -1875584421: 635
        //          default: 598
        //        }
        //   632: iinc            3, 1
        //   635: iinc            5, 1
        //   638: goto            84
        //   641: iload_3        
        //   642: ireturn        
        //   643: aconst_null    
        //   644: athrow         
        //   645: aconst_null    
        //   646: athrow         
        //   647: aconst_null    
        //   648: athrow         
        //   649: aconst_null    
        //   650: athrow         
        //   651: aconst_null    
        //   652: athrow         
        //   653: aconst_null    
        //   654: athrow         
        //   655: aconst_null    
        //   656: athrow         
        //   657: aconst_null    
        //   658: athrow         
        //   659: aconst_null    
        //   660: athrow         
        //   661: pop            
        //   662: goto            24
        //   665: pop            
        //   666: aconst_null    
        //   667: goto            661
        //   670: dup            
        //   671: ifnull          661
        //   674: checkcast       Ljava/lang/Throwable;
        //   677: athrow         
        //   678: dup            
        //   679: ifnull          665
        //   682: checkcast       Ljava/lang/Throwable;
        //   685: athrow         
        //   686: aconst_null    
        //   687: athrow         
        //    StackMapTable: 00 51 FF 00 03 00 06 07 00 03 07 00 3C 07 00 7D 01 01 01 00 01 07 00 32 F8 00 04 FF 00 0B 00 00 00 01 07 00 32 FE 00 03 07 00 03 07 00 3C 07 00 7D 0C 41 01 1C 07 FE 00 07 01 01 01 4C 01 FF 00 01 00 06 07 00 03 07 00 3C 07 00 7D 01 01 01 00 02 01 01 5C 01 43 07 00 20 FF 00 00 00 06 07 00 03 07 00 3C 07 00 7D 01 01 01 00 02 01 07 00 7D 45 07 00 32 FF 00 00 00 06 07 00 03 07 00 3C 07 00 7D 01 01 01 00 02 01 01 48 07 00 95 FF 00 00 00 06 07 00 03 07 00 3C 07 00 7D 01 01 01 00 02 07 00 7D 01 45 07 00 32 40 01 FF 00 07 00 00 00 01 07 00 32 FF 00 00 00 07 07 00 03 07 00 3C 07 00 7D 01 01 01 01 00 02 07 00 3C 01 45 07 00 32 40 01 4A 01 FF 00 01 00 07 07 00 03 07 00 3C 07 00 7D 01 01 01 01 00 02 01 01 5D 01 FC 00 11 01 41 01 1B 45 07 00 22 FF 00 00 00 08 07 00 03 07 00 3C 07 00 7D 01 01 01 01 01 00 02 01 07 00 7D 45 07 00 32 FF 00 00 00 08 07 00 03 07 00 3C 07 00 7D 01 01 01 01 01 00 02 01 01 12 41 01 1C 4B 07 00 7D FF 00 01 00 08 07 00 03 07 00 3C 07 00 7D 01 01 01 01 01 00 02 07 00 7D 01 5D 07 00 7D FF 00 04 00 00 00 01 07 00 32 FF 00 00 00 08 07 00 03 07 00 3C 07 00 7D 01 01 01 01 01 00 02 07 00 7D 01 45 07 00 32 40 01 13 41 01 1C 14 04 41 01 17 05 02 4B 01 FF 00 01 00 08 07 00 03 07 00 3C 07 00 7D 01 01 01 01 01 00 02 01 01 5C 01 01 0F 41 01 1B 09 04 41 01 1A 02 F9 00 05 FF 00 00 00 03 07 00 03 07 00 3C 07 00 7D 00 01 01 00 FF 00 01 00 07 07 00 03 07 00 3C 07 00 7D 01 01 01 01 00 01 01 FF 00 01 00 08 07 00 03 07 00 3C 07 00 7D 01 01 01 01 01 00 01 01 41 07 00 7D FF 00 01 00 06 07 00 03 07 00 3C 07 00 7D 01 01 01 00 01 01 FD 00 01 01 01 01 01 01 FF 00 01 00 03 07 00 03 07 00 3C 07 00 7D 00 01 07 00 32 43 05 44 07 00 32 47 05 FF 00 07 00 06 07 00 03 07 00 3C 07 00 7D 01 01 01 00 01 07 00 32
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     670    678    Any
        //  670    678    670    678    Any
        //  686    688    3      8      Any
        //  132    139    139    140    Any
        //  133    139    139    140    Ljava/lang/NegativeArraySizeException;
        //  133    139    132    133    Ljava/lang/AssertionError;
        //  133    139    139    140    Ljava/util/NoSuchElementException;
        //  133    139    139    140    Ljava/lang/NullPointerException;
        //  149    156    156    157    Any
        //  150    156    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  149    156    156    157    Any
        //  149    156    149    150    Ljava/lang/UnsupportedOperationException;
        //  149    156    3      8      Ljava/lang/IllegalStateException;
        //  166    172    172    173    Any
        //  166    172    172    173    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  166    172    3      8      Ljava/lang/UnsupportedOperationException;
        //  166    172    3      8      Ljava/lang/ArithmeticException;
        //  166    172    3      8      Any
        //  270    277    277    278    Any
        //  270    277    277    278    Ljava/lang/AssertionError;
        //  271    277    270    271    Ljava/lang/RuntimeException;
        //  271    277    3      8      Ljava/lang/NullPointerException;
        //  270    277    277    278    Any
        //  378    384    384    385    Any
        //  378    384    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  378    384    3      8      Ljava/lang/NegativeArraySizeException;
        //  378    384    384    385    Any
        //  378    384    3      8      Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:599)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void c(@NotNull final FontRenderer fontRenderer, @Nullable final String s, final int n, final int n2, final int n3) {
        fez.1B(this, 1780940643, fontRenderer, s, n, n2, n3);
    }
    
    static {
        while (true) {
            int n = 0;
            Label_0017: {
                if (fc.0 <= 0) {
                    n = -1121009407;
                    break Label_0017;
                }
                n = -1448777345;
            }
            switch (n ^ 0x4EA14DF2) {
                case -1186535356: {
                    continue;
                }
                default: {
                    f0J.c = new f0J();
                }
                case -208696077: {
                    throw null;
                }
            }
            break;
        }
    }
    
    @JvmStatic
    public static void c(final int p0, final int p1, final int p2, final int p3, final int p4, final int p5, final int p6) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          747
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            739
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            731
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: getstatic       dev/nuker/pyro/fc.0:I
        //    27: ifgt            35
        //    30: ldc             1977869686
        //    32: goto            37
        //    35: ldc             -236198832
        //    37: ldc             -411146848
        //    39: ixor           
        //    40: lookupswitch {
        //          -1835171626: 718
        //          410251778: 35
        //          default: 68
        //        }
        //    68: iload_0        
        //    69: iload_1        
        //    70: getstatic       dev/nuker/pyro/fc.c:I
        //    73: ifne            81
        //    76: ldc             -1063061166
        //    78: goto            83
        //    81: ldc             -610967260
        //    83: ldc             -195717012
        //    85: ixor           
        //    86: lookupswitch {
        //          801175880: 112
        //          888627518: 81
        //          default: 716
        //        }
        //   112: iload_0        
        //   113: getstatic       dev/nuker/pyro/fc.c:I
        //   116: ifne            124
        //   119: ldc             -1857033172
        //   121: goto            126
        //   124: ldc             362074394
        //   126: ldc             1212333589
        //   128: ixor           
        //   129: lookupswitch {
        //          -653438407: 714
        //          1668217316: 124
        //          default: 156
        //        }
        //   156: iload_2        
        //   157: iadd           
        //   158: iload_1        
        //   159: iload_3        
        //   160: iadd           
        //   161: getstatic       dev/nuker/pyro/fc.1:I
        //   164: ifne            172
        //   167: ldc             29874927
        //   169: goto            174
        //   172: ldc             -608295431
        //   174: ldc             -397552191
        //   176: ixor           
        //   177: lookupswitch {
        //          -376828114: 172
        //          871624760: 204
        //          default: 720
        //        }
        //   204: iload           4
        //   206: goto            210
        //   209: athrow         
        //   210: invokestatic    net/minecraft/client/gui/Gui.func_73734_a:(IIIII)V
        //   213: goto            217
        //   216: athrow         
        //   217: iload_0        
        //   218: getstatic       dev/nuker/pyro/fc.0:I
        //   221: ifgt            229
        //   224: ldc             -37614774
        //   226: goto            231
        //   229: ldc             1524201911
        //   231: ldc             -1263018507
        //   233: ixor           
        //   234: lookupswitch {
        //          -294738878: 260
        //          1232459455: 229
        //          default: 698
        //        }
        //   260: iload_1        
        //   261: iload_0        
        //   262: iload           6
        //   264: iadd           
        //   265: getstatic       dev/nuker/pyro/fc.1:I
        //   268: ifne            276
        //   271: ldc             2020259451
        //   273: goto            278
        //   276: ldc             1512568860
        //   278: ldc             -30004103
        //   280: ixor           
        //   281: lookupswitch {
        //          -2040751614: 276
        //          -1542335387: 308
        //          default: 708
        //        }
        //   308: iload_1        
        //   309: iload_3        
        //   310: iadd           
        //   311: iload           5
        //   313: getstatic       dev/nuker/pyro/fc.1:I
        //   316: ifne            324
        //   319: ldc             419292892
        //   321: goto            326
        //   324: ldc             -1880864109
        //   326: ldc             692966003
        //   328: ixor           
        //   329: lookupswitch {
        //          -1498834720: 356
        //          833631407: 324
        //          default: 704
        //        }
        //   356: goto            360
        //   359: athrow         
        //   360: invokestatic    net/minecraft/client/gui/Gui.func_73734_a:(IIIII)V
        //   363: goto            367
        //   366: athrow         
        //   367: iload_0        
        //   368: iload_2        
        //   369: iadd           
        //   370: iload           6
        //   372: isub           
        //   373: iload_1        
        //   374: iload_0        
        //   375: iload_2        
        //   376: iadd           
        //   377: iload_1        
        //   378: iload_3        
        //   379: iadd           
        //   380: iload           5
        //   382: goto            386
        //   385: athrow         
        //   386: invokestatic    net/minecraft/client/gui/Gui.func_73734_a:(IIIII)V
        //   389: goto            393
        //   392: athrow         
        //   393: iload_0        
        //   394: getstatic       dev/nuker/pyro/fc.1:I
        //   397: ifne            405
        //   400: ldc             -1560083638
        //   402: goto            407
        //   405: ldc             1630456016
        //   407: ldc             518062787
        //   409: ixor           
        //   410: lookupswitch {
        //          -1109261943: 405
        //          2144324115: 436
        //          default: 696
        //        }
        //   436: iload_1        
        //   437: iload_0        
        //   438: iload_2        
        //   439: iadd           
        //   440: getstatic       dev/nuker/pyro/fc.1:I
        //   443: ifne            451
        //   446: ldc             -841040633
        //   448: goto            453
        //   451: ldc             1550818506
        //   453: ldc             1297247874
        //   455: ixor           
        //   456: lookupswitch {
        //          -2138254459: 712
        //          608517237: 451
        //          default: 484
        //        }
        //   484: iload_1        
        //   485: iload           6
        //   487: iadd           
        //   488: iload           5
        //   490: goto            494
        //   493: athrow         
        //   494: invokestatic    net/minecraft/client/gui/Gui.func_73734_a:(IIIII)V
        //   497: goto            501
        //   500: athrow         
        //   501: iload_0        
        //   502: iload_1        
        //   503: getstatic       dev/nuker/pyro/fc.1:I
        //   506: ifne            514
        //   509: ldc             -633310595
        //   511: goto            516
        //   514: ldc             135491569
        //   516: ldc             170922429
        //   518: ixor           
        //   519: lookupswitch {
        //          -797940800: 514
        //          35880524: 544
        //          default: 700
        //        }
        //   544: iload_3        
        //   545: iadd           
        //   546: iload           6
        //   548: isub           
        //   549: getstatic       dev/nuker/pyro/fc.0:I
        //   552: ifgt            560
        //   555: ldc             -866339435
        //   557: goto            562
        //   560: ldc             1076773847
        //   562: ldc             -82102990
        //   564: ixor           
        //   565: lookupswitch {
        //          566736280: 560
        //          927432871: 710
        //          default: 592
        //        }
        //   592: iload_0        
        //   593: getstatic       dev/nuker/pyro/fc.1:I
        //   596: ifne            604
        //   599: ldc             1866216284
        //   601: goto            606
        //   604: ldc             -2137244029
        //   606: ldc             415574457
        //   608: ixor           
        //   609: lookupswitch {
        //          -1738991814: 636
        //          2012814053: 604
        //          default: 702
        //        }
        //   636: iload_2        
        //   637: iadd           
        //   638: iload_1        
        //   639: getstatic       dev/nuker/pyro/fc.0:I
        //   642: ifgt            650
        //   645: ldc             1288118206
        //   647: goto            652
        //   650: ldc             -504403473
        //   652: ldc             -204384378
        //   654: ixor           
        //   655: lookupswitch {
        //          -1089058760: 706
        //          1358441233: 650
        //          default: 680
        //        }
        //   680: iload_3        
        //   681: iadd           
        //   682: iload           5
        //   684: goto            688
        //   687: athrow         
        //   688: invokestatic    net/minecraft/client/gui/Gui.func_73734_a:(IIIII)V
        //   691: goto            695
        //   694: athrow         
        //   695: return         
        //   696: aconst_null    
        //   697: athrow         
        //   698: aconst_null    
        //   699: athrow         
        //   700: aconst_null    
        //   701: athrow         
        //   702: aconst_null    
        //   703: athrow         
        //   704: aconst_null    
        //   705: athrow         
        //   706: aconst_null    
        //   707: athrow         
        //   708: aconst_null    
        //   709: athrow         
        //   710: aconst_null    
        //   711: athrow         
        //   712: aconst_null    
        //   713: athrow         
        //   714: aconst_null    
        //   715: athrow         
        //   716: aconst_null    
        //   717: athrow         
        //   718: aconst_null    
        //   719: athrow         
        //   720: aconst_null    
        //   721: athrow         
        //   722: pop            
        //   723: goto            24
        //   726: pop            
        //   727: aconst_null    
        //   728: goto            722
        //   731: dup            
        //   732: ifnull          722
        //   735: checkcast       Ljava/lang/Throwable;
        //   738: athrow         
        //   739: dup            
        //   740: ifnull          726
        //   743: checkcast       Ljava/lang/Throwable;
        //   746: athrow         
        //   747: aconst_null    
        //   748: athrow         
        //    StackMapTable: 00 51 43 07 00 32 04 FF 00 0B 00 00 00 01 07 00 32 FF 00 03 00 07 01 01 01 01 01 01 01 00 00 0A 41 01 1E FF 00 0C 00 07 01 01 01 01 01 01 01 00 02 01 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 03 01 01 01 FF 00 1C 00 07 01 01 01 01 01 01 01 00 02 01 01 FF 00 0B 00 07 01 01 01 01 01 01 01 00 03 01 01 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 04 01 01 01 01 FF 00 1D 00 07 01 01 01 01 01 01 01 00 03 01 01 01 FF 00 0F 00 07 01 01 01 01 01 01 01 00 04 01 01 01 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 05 01 01 01 01 01 FF 00 1D 00 07 01 01 01 01 01 01 01 00 04 01 01 01 01 44 07 00 97 FF 00 00 00 07 01 01 01 01 01 01 01 00 05 01 01 01 01 01 45 07 00 32 00 4B 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 02 01 01 5C 01 FF 00 0F 00 07 01 01 01 01 01 01 01 00 03 01 01 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 04 01 01 01 01 FF 00 1D 00 07 01 01 01 01 01 01 01 00 03 01 01 01 FF 00 0F 00 07 01 01 01 01 01 01 01 00 05 01 01 01 01 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 06 01 01 01 01 01 01 FF 00 1D 00 07 01 01 01 01 01 01 01 00 05 01 01 01 01 01 42 07 00 32 FF 00 00 00 07 01 01 01 01 01 01 01 00 05 01 01 01 01 01 45 07 00 32 00 FF 00 11 00 00 00 01 07 00 32 FF 00 00 00 07 01 01 01 01 01 01 01 00 05 01 01 01 01 01 45 07 00 32 00 4B 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 02 01 01 5C 01 FF 00 0E 00 07 01 01 01 01 01 01 01 00 03 01 01 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 04 01 01 01 01 FF 00 1E 00 07 01 01 01 01 01 01 01 00 03 01 01 01 48 07 00 97 FF 00 00 00 07 01 01 01 01 01 01 01 00 05 01 01 01 01 01 45 07 00 32 00 FF 00 0C 00 07 01 01 01 01 01 01 01 00 02 01 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 03 01 01 01 FF 00 1B 00 07 01 01 01 01 01 01 01 00 02 01 01 FF 00 0F 00 07 01 01 01 01 01 01 01 00 02 01 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 03 01 01 01 FF 00 1D 00 07 01 01 01 01 01 01 01 00 02 01 01 FF 00 0B 00 07 01 01 01 01 01 01 01 00 03 01 01 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 04 01 01 01 01 FF 00 1D 00 07 01 01 01 01 01 01 01 00 03 01 01 01 FF 00 0D 00 07 01 01 01 01 01 01 01 00 04 01 01 01 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 05 01 01 01 01 01 FF 00 1B 00 07 01 01 01 01 01 01 01 00 04 01 01 01 01 46 07 00 97 FF 00 00 00 07 01 01 01 01 01 01 01 00 05 01 01 01 01 01 45 07 00 32 00 40 01 41 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 02 01 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 03 01 01 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 05 01 01 01 01 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 04 01 01 01 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 03 01 01 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 02 01 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 03 01 01 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 03 01 01 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 02 01 01 01 FF 00 01 00 07 01 01 01 01 01 01 01 00 04 01 01 01 01 41 07 00 32 43 05 44 07 00 32 47 05 47 07 00 32
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     731    739    Any
        //  731    739    731    739    Ljava/lang/IndexOutOfBoundsException;
        //  747    749    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  209    216    216    217    Any
        //  210    216    216    217    Any
        //  210    216    216    217    Ljava/lang/EnumConstantNotPresentException;
        //  209    216    216    217    Any
        //  210    216    209    210    Ljava/lang/ArithmeticException;
        //  359    366    366    367    Any
        //  360    366    359    360    Any
        //  359    366    3      8      Ljava/lang/IllegalStateException;
        //  360    366    3      8      Any
        //  359    366    359    360    Ljava/lang/ArithmeticException;
        //  386    392    392    393    Any
        //  386    392    3      8      Ljava/util/ConcurrentModificationException;
        //  386    392    3      8      Ljava/lang/IllegalStateException;
        //  386    392    3      8      Any
        //  386    392    392    393    Any
        //  493    500    500    501    Any
        //  494    500    3      8      Ljava/lang/ClassCastException;
        //  494    500    493    494    Ljava/lang/ArithmeticException;
        //  493    500    500    501    Ljava/lang/IllegalStateException;
        //  494    500    500    501    Any
        //  687    694    694    695    Any
        //  688    694    687    688    Ljava/lang/ArithmeticException;
        //  687    694    3      8      Any
        //  688    694    694    695    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  688    694    694    695    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 224 out of bounds for length 224
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @JvmOverloads
    public void c(@NotNull final FontRenderer p0, @Nullable final String p1, final int p2, final int p3, final int p4, final int p5, @NotNull final f0G p6, final int p7, final int p8) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          228
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            220
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            212
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_0        
        //    25: getstatic       dev/nuker/pyro/fc.0:I
        //    28: ifgt            37
        //    31: ldc_w           -1677727495
        //    34: goto            40
        //    37: ldc_w           -239287312
        //    40: ldc_w           -2127944534
        //    43: ixor           
        //    44: lookupswitch {
        //          -1565884810: 37
        //          450219091: 197
        //          default: 72
        //        }
        //    72: aload_1        
        //    73: aload_2        
        //    74: iload_3        
        //    75: iload           4
        //    77: getstatic       dev/nuker/pyro/fc.1:I
        //    80: ifne            89
        //    83: ldc_w           -1359688876
        //    86: goto            92
        //    89: ldc_w           584920928
        //    92: ldc_w           -869320686
        //    95: ixor           
        //    96: lookupswitch {
        //          996359530: 89
        //          1658581830: 201
        //          default: 124
        //        }
        //   124: iload           5
        //   126: iload           6
        //   128: aload           7
        //   130: getstatic       dev/nuker/pyro/fc.1:I
        //   133: ifne            142
        //   136: ldc_w           675018262
        //   139: goto            145
        //   142: ldc_w           1939438113
        //   145: ldc_w           1689976569
        //   148: ixor           
        //   149: lookupswitch {
        //          388203736: 176
        //          1283524847: 142
        //          default: 199
        //        }
        //   176: iload           8
        //   178: iload           9
        //   180: iconst_0       
        //   181: sipush          512
        //   184: aconst_null    
        //   185: goto            189
        //   188: athrow         
        //   189: invokestatic    dev/nuker/pyro/f0J.c:(Ldev/nuker/pyro/f0J;Lnet/minecraft/client/gui/FontRenderer;Ljava/lang/String;IIIILdev/nuker/pyro/f0G;IIZILjava/lang/Object;)V
        //   192: goto            196
        //   195: athrow         
        //   196: return         
        //   197: aconst_null    
        //   198: athrow         
        //   199: aconst_null    
        //   200: athrow         
        //   201: aconst_null    
        //   202: athrow         
        //   203: pop            
        //   204: goto            24
        //   207: pop            
        //   208: aconst_null    
        //   209: goto            203
        //   212: dup            
        //   213: ifnull          203
        //   216: checkcast       Ljava/lang/Throwable;
        //   219: athrow         
        //   220: dup            
        //   221: ifnull          207
        //   224: checkcast       Ljava/lang/Throwable;
        //   227: athrow         
        //   228: aconst_null    
        //   229: athrow         
        //    StackMapTable: 00 19 43 07 00 32 04 FF 00 0B 00 00 00 01 07 00 32 FF 00 03 00 0A 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 00 00 4C 07 00 03 FF 00 02 00 0A 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 00 02 07 00 03 01 5F 07 00 03 FF 00 10 00 0A 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 00 05 07 00 03 07 00 3C 07 00 7D 01 01 FF 00 02 00 0A 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 00 06 07 00 03 07 00 3C 07 00 7D 01 01 01 FF 00 1F 00 0A 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 00 05 07 00 03 07 00 3C 07 00 7D 01 01 FF 00 11 00 0A 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 00 08 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 FF 00 02 00 0A 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 00 09 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 FF 00 1E 00 0A 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 00 08 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 4B 07 00 32 FF 00 00 00 0A 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 00 0D 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 01 01 05 45 07 00 32 00 40 07 00 03 FF 00 01 00 0A 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 00 08 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 FF 00 01 00 0A 07 00 03 07 00 3C 07 00 7D 01 01 01 01 07 00 58 01 01 00 05 07 00 03 07 00 3C 07 00 7D 01 01 41 07 00 32 43 05 44 07 00 32 47 05 47 07 00 32
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                
        //  -----  -----  -----  -----  ------------------------------------
        //  8      20     212    220    Any
        //  212    220    212    220    Ljava/lang/IllegalArgumentException;
        //  228    230    3      8      Ljava/lang/ClassCastException;
        //  188    195    195    196    Any
        //  188    195    188    189    Ljava/lang/NumberFormatException;
        //  188    195    188    189    Any
        //  189    195    3      8      Ljava/lang/ArithmeticException;
        //  188    195    3      8      Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:543)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
