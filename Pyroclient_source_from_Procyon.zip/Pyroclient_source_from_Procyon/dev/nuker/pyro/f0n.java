// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import kotlin.Unit;
import org.jetbrains.annotations.Nullable;
import com.google.gson.JsonElement;
import org.jetbrains.annotations.NotNull;

public class f0n extends f0u
{
    @NotNull
    @Override
    public f13 2() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          69
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            61
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            53
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: new             Ldev/nuker/pyro/f0N;
        //    27: dup            
        //    28: aload_0        
        //    29: goto            33
        //    32: athrow         
        //    33: invokespecial   dev/nuker/pyro/f0N.<init>:(Ldev/nuker/pyro/f0n;)V
        //    36: goto            40
        //    39: athrow         
        //    40: checkcast       Ldev/nuker/pyro/f13;
        //    43: areturn        
        //    44: pop            
        //    45: goto            24
        //    48: pop            
        //    49: aconst_null    
        //    50: goto            44
        //    53: dup            
        //    54: ifnull          44
        //    57: checkcast       Ljava/lang/Throwable;
        //    60: athrow         
        //    61: dup            
        //    62: ifnull          48
        //    65: checkcast       Ljava/lang/Throwable;
        //    68: athrow         
        //    69: aconst_null    
        //    70: athrow         
        //    StackMapTable: 00 0D 43 07 00 16 04 FF 00 0B 00 00 00 01 07 00 16 FC 00 03 07 00 03 47 07 00 0E FF 00 00 00 01 07 00 03 00 03 08 00 18 08 00 18 07 00 03 45 07 00 16 40 07 00 18 43 07 00 16 43 05 44 07 00 16 47 05 47 07 00 16
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     53     61     Any
        //  53     61     53     61     Ljava/lang/IllegalStateException;
        //  69     71     3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  32     39     39     40     Any
        //  32     39     3      8      Any
        //  33     39     3      8      Any
        //  33     39     39     40     Any
        //  32     39     32     33     Ljava/lang/ArrayIndexOutOfBoundsException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:543)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public void c(@NotNull final JsonElement jsonElement) {
        fez.6b(this, 51476491, jsonElement);
    }
    
    public f0n(@NotNull final String s, @NotNull final String s2, @Nullable final String s3) {
        while (true) {
            int n = 0;
            Label_0019: {
                if (fc.1 == 0) {
                    n = -2131125648;
                    break Label_0019;
                }
                n = 1254828332;
            }
            switch (n ^ 0xCE9C81C7) {
                case 1315249079: {
                    continue;
                }
                case -2074629909: {
                    super(s, s2, s3, Unit.INSTANCE);
                }
                default: {
                    throw null;
                }
            }
            break;
        }
    }
    
    @NotNull
    @Override
    public JsonElement 0() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getstatic       dev/nuker/pyro/fc.c:I
        //     4: ifeq            42
        //     7: pop            
        //     8: aconst_null    
        //     9: goto            34
        //    12: nop            
        //    13: nop            
        //    14: nop            
        //    15: athrow         
        //    16: getstatic       com/google/gson/JsonNull.INSTANCE:Lcom/google/gson/JsonNull;
        //    19: dup            
        //    20: pop            
        //    21: checkcast       Lcom/google/gson/JsonElement;
        //    24: areturn        
        //    25: pop            
        //    26: goto            16
        //    29: pop            
        //    30: aconst_null    
        //    31: goto            25
        //    34: dup            
        //    35: ifnull          25
        //    38: checkcast       Ljava/lang/Throwable;
        //    41: athrow         
        //    42: dup            
        //    43: ifnull          29
        //    46: checkcast       Ljava/lang/Throwable;
        //    49: athrow         
        //    StackMapTable: 00 06 FF 00 0C 00 00 00 01 07 00 16 FC 00 03 07 00 03 48 07 00 16 43 05 44 07 00 16 47 05
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type
        //  -----  -----  -----  -----  ----
        //  0      12     34     42     Any
        //  34     42     34     42     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:543)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        throw t;
    }
}
