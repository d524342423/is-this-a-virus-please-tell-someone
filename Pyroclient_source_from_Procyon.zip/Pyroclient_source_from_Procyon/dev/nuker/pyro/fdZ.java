// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import net.minecraft.client.Minecraft;

public class fdZ
{
    public static Minecraft c;
    
    public fdZ() {
        while (true) {
            int n = 0;
            Label_0013: {
                if (fc.1 == 0) {
                    n = 1760298667;
                    break Label_0013;
                }
                n = 940628029;
            }
            switch (n ^ 0xD75395A5) {
                case -1467990587: {
                    continue;
                }
                default: {
                    while (true) {
                        int n2 = 0;
                        Label_0058: {
                            if (fc.c == 0) {
                                n2 = -1373258309;
                                break Label_0058;
                            }
                            n2 = -1881141578;
                        }
                        switch (n2 ^ 0xC0DCCBFF) {
                            case 508324947: {
                                continue;
                            }
                            default: {
                                return;
                            }
                            case 1861842500: {
                                throw null;
                            }
                        }
                        break;
                    }
                    break;
                }
                case -1077964018: {
                    throw null;
                }
            }
            break;
        }
    }
    
    static {
        fdZ.c = Minecraft.func_71410_x();
    }
}
