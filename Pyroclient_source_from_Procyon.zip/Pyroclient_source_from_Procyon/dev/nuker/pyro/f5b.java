// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;

public class f5b extends GuiScreen
{
    public GuiScreen c;
    public f5d c;
    public String c;
    public f5g c;
    
    public void func_73863_a(final int p0, final int p1, final float p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          136
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            128
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            120
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_0        
        //    25: getfield        dev/nuker/pyro/f5b.c:Lnet/minecraft/client/gui/GuiScreen;
        //    28: sipush          -1337
        //    31: sipush          -1337
        //    34: fload_3        
        //    35: goto            39
        //    38: athrow         
        //    39: invokevirtual   net/minecraft/client/gui/GuiScreen.func_73863_a:(IIF)V
        //    42: goto            46
        //    45: athrow         
        //    46: aload_0        
        //    47: getstatic       dev/nuker/pyro/fc.1:I
        //    50: ifne            58
        //    53: ldc             -793262195
        //    55: goto            60
        //    58: ldc             -211533809
        //    60: ldc             1915705627
        //    62: ixor           
        //    63: lookupswitch {
        //          -1567056234: 109
        //          629903296: 58
        //          default: 88
        //        }
        //    88: getfield        dev/nuker/pyro/f5b.c:Ldev/nuker/pyro/f5g;
        //    91: iload_1        
        //    92: i2f            
        //    93: iload_2        
        //    94: i2f            
        //    95: fload_3        
        //    96: goto            100
        //    99: athrow         
        //   100: invokevirtual   dev/nuker/pyro/f5g.c:(FFF)Z
        //   103: goto            107
        //   106: athrow         
        //   107: pop            
        //   108: return         
        //   109: aconst_null    
        //   110: athrow         
        //   111: pop            
        //   112: goto            24
        //   115: pop            
        //   116: aconst_null    
        //   117: goto            111
        //   120: dup            
        //   121: ifnull          111
        //   124: checkcast       Ljava/lang/Throwable;
        //   127: athrow         
        //   128: dup            
        //   129: ifnull          115
        //   132: checkcast       Ljava/lang/Throwable;
        //   135: athrow         
        //   136: aconst_null    
        //   137: athrow         
        //    StackMapTable: 00 15 43 07 00 1D 04 FF 00 0B 00 00 00 01 07 00 1D FF 00 03 00 04 07 00 03 01 01 02 00 00 FF 00 0D 00 00 00 01 07 00 1D FF 00 00 00 04 07 00 03 01 01 02 00 04 07 00 05 01 01 02 45 07 00 1D 00 4B 07 00 03 FF 00 01 00 04 07 00 03 01 01 02 00 02 07 00 03 01 5B 07 00 03 4A 07 00 1D FF 00 00 00 04 07 00 03 01 01 02 00 04 07 00 2B 02 02 02 45 07 00 1D 40 01 41 07 00 03 41 07 00 1D 43 05 44 07 00 1D 47 05 47 07 00 1D
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     120    128    Any
        //  120    128    120    128    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  136    138    3      8      Ljava/lang/NumberFormatException;
        //  39     45     45     46     Any
        //  39     45     3      8      Any
        //  39     45     3      8      Ljava/util/ConcurrentModificationException;
        //  39     45     3      8      Any
        //  39     45     45     46     Any
        //  99     106    106    107    Any
        //  99     106    99     100    Any
        //  99     106    3      8      Any
        //  99     106    106    107    Ljava/lang/StringIndexOutOfBoundsException;
        //  99     106    106    107    Ljava/lang/RuntimeException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 51 out of bounds for length 51
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public f5b(final String c, final GuiScreen c2, final f5d c3) {
        while (true) {
            int n = 0;
            Label_0013: {
                if (fc.1 == 0) {
                    n = 380207999;
                    break Label_0013;
                }
                n = -60110278;
            }
            switch (n ^ 0x24F3C248) {
                case 844775735: {
                    continue;
                }
                case -661059470: {
                    while (true) {
                        int n2 = 0;
                        Label_0061: {
                            if (fc.c == 0) {
                                n2 = 1711533203;
                                break Label_0061;
                            }
                            n2 = 2072983897;
                        }
                        switch (n2 ^ 0x5950EB7E) {
                            case -2116901889: {
                                continue;
                            }
                            default: {
                                while (true) {
                                    int n3 = 0;
                                    Label_0107: {
                                        if (fc.0 <= 0) {
                                            n3 = -889754726;
                                            break Label_0107;
                                        }
                                        n3 = 2093114423;
                                    }
                                    switch (n3 ^ 0x9B5E5B02) {
                                        case 1370042520: {
                                            continue;
                                        }
                                        case -409190603: {
                                            this.c = c;
                                            this.c = c2;
                                            while (true) {
                                                int n4 = 0;
                                                Label_0158: {
                                                    if (fc.0 <= 0) {
                                                        n4 = 527609059;
                                                        break Label_0158;
                                                    }
                                                    n4 = 817196701;
                                                }
                                                switch (n4 ^ 0xD7E9CA71) {
                                                    case 739750125: {
                                                        continue;
                                                    }
                                                    default: {
                                                        this.c = c3;
                                                        final ScaledResolution scaledResolution = new ScaledResolution(Minecraft.func_71410_x());
                                                        while (true) {
                                                            int n5 = 0;
                                                            Label_0219: {
                                                                if (fc.0 <= 0) {
                                                                    n5 = 617411594;
                                                                    break Label_0219;
                                                                }
                                                                n5 = -367600573;
                                                            }
                                                            switch (n5 ^ 0x735AD216) {
                                                                case 159602280: {
                                                                    continue;
                                                                }
                                                                default: {
                                                                    final float n6 = (float)(scaledResolution.func_78326_a() / 2);
                                                                    while (true) {
                                                                        int n7 = 0;
                                                                        Label_0269: {
                                                                            if (fc.c == 0) {
                                                                                n7 = 552102663;
                                                                                break Label_0269;
                                                                            }
                                                                            n7 = 293588024;
                                                                        }
                                                                        switch (n7 ^ 0xDA69EACE) {
                                                                            case -92175927: {
                                                                                continue;
                                                                            }
                                                                            case -887740682: {
                                                                                final float n8 = (float)(scaledResolution.func_78328_b() / 2 + 40);
                                                                                while (true) {
                                                                                    int n9 = 0;
                                                                                    Label_0332: {
                                                                                        if (fc.0 <= 0) {
                                                                                            n9 = -1122421522;
                                                                                            break Label_0332;
                                                                                        }
                                                                                        n9 = 1868538828;
                                                                                    }
                                                                                    switch (n9 ^ 0xD6262D9D) {
                                                                                        case 1799297395: {
                                                                                            continue;
                                                                                        }
                                                                                        case -1183216047: {
                                                                                            final float n10 = n6;
                                                                                            while (true) {
                                                                                                int n11 = 0;
                                                                                                Label_0375: {
                                                                                                    if (fc.c == 0) {
                                                                                                        n11 = -1843475494;
                                                                                                        break Label_0375;
                                                                                                    }
                                                                                                    n11 = 832563433;
                                                                                                }
                                                                                                switch (n11 ^ 0xF10E72C6) {
                                                                                                    case 1662040348: {
                                                                                                        continue;
                                                                                                    }
                                                                                                    case -1064199633: {
                                                                                                        final f5g c4 = new f5g(c, n10, n8);
                                                                                                        while (true) {
                                                                                                            int n12 = 0;
                                                                                                            Label_0422: {
                                                                                                                if (fc.0 <= 0) {
                                                                                                                    n12 = -1992309450;
                                                                                                                    break Label_0422;
                                                                                                                }
                                                                                                                n12 = -1157532131;
                                                                                                            }
                                                                                                            switch (n12 ^ 0x30C1B4EA) {
                                                                                                                case 1524430781: {
                                                                                                                    continue;
                                                                                                                }
                                                                                                                default: {
                                                                                                                    this.c = c4;
                                                                                                                    final f5d c5 = this.c;
                                                                                                                    while (true) {
                                                                                                                        int n13 = 0;
                                                                                                                        Label_0472: {
                                                                                                                            if (fc.c == 0) {
                                                                                                                                n13 = -1949821167;
                                                                                                                                break Label_0472;
                                                                                                                            }
                                                                                                                            n13 = -1013694740;
                                                                                                                        }
                                                                                                                        switch (n13 ^ 0xD801358A) {
                                                                                                                            case 1405690523: {
                                                                                                                                continue;
                                                                                                                            }
                                                                                                                            case 462752614: {
                                                                                                                                final f0w c6 = c5.c().c();
                                                                                                                                while (true) {
                                                                                                                                    int n14 = 0;
                                                                                                                                    Label_0521: {
                                                                                                                                        if (fc.0 <= 0) {
                                                                                                                                            n14 = -1504834698;
                                                                                                                                            break Label_0521;
                                                                                                                                        }
                                                                                                                                        n14 = -299826699;
                                                                                                                                    }
                                                                                                                                    switch (n14 ^ 0x25F6AEEE) {
                                                                                                                                        case -2085050984: {
                                                                                                                                            continue;
                                                                                                                                        }
                                                                                                                                        case -875057381: {
                                                                                                                                            Label_0750: {
                                                                                                                                                if (c6 instanceof f0m) {
                                                                                                                                                    this.c.c().0(String.valueOf(((f0m)c6).c()));
                                                                                                                                                }
                                                                                                                                                else {
                                                                                                                                                    while (true) {
                                                                                                                                                        int n15 = 0;
                                                                                                                                                        Label_0601: {
                                                                                                                                                            if (fc.1 == 0) {
                                                                                                                                                                n15 = 1529412708;
                                                                                                                                                                break Label_0601;
                                                                                                                                                            }
                                                                                                                                                            n15 = -464980779;
                                                                                                                                                        }
                                                                                                                                                        switch (n15 ^ 0x116324D) {
                                                                                                                                                            case 1785395222: {
                                                                                                                                                                continue;
                                                                                                                                                            }
                                                                                                                                                            default: {
                                                                                                                                                                if (!(c6 instanceof f0p)) {
                                                                                                                                                                    break;
                                                                                                                                                                }
                                                                                                                                                                final f0p f0p = (f0p)c6;
                                                                                                                                                                while (true) {
                                                                                                                                                                    int n16 = 0;
                                                                                                                                                                    Label_0658: {
                                                                                                                                                                        if (fc.1 == 0) {
                                                                                                                                                                            n16 = 1962835216;
                                                                                                                                                                            break Label_0658;
                                                                                                                                                                        }
                                                                                                                                                                        n16 = 1507196840;
                                                                                                                                                                    }
                                                                                                                                                                    switch (n16 ^ 0xE517087F) {
                                                                                                                                                                        case -448424645: {
                                                                                                                                                                            continue;
                                                                                                                                                                        }
                                                                                                                                                                        default: {
                                                                                                                                                                            final f0p f0p2 = f0p;
                                                                                                                                                                            final f5f c7 = this.c.c();
                                                                                                                                                                            final Object c8 = f0p2.c();
                                                                                                                                                                            while (true) {
                                                                                                                                                                                int n17 = 0;
                                                                                                                                                                                Label_0715: {
                                                                                                                                                                                    if (fc.0 <= 0) {
                                                                                                                                                                                        n17 = 269278575;
                                                                                                                                                                                        break Label_0715;
                                                                                                                                                                                    }
                                                                                                                                                                                    n17 = -824759410;
                                                                                                                                                                                }
                                                                                                                                                                                switch (n17 ^ 0x637FB0F3) {
                                                                                                                                                                                    case 1936944540: {
                                                                                                                                                                                        continue;
                                                                                                                                                                                    }
                                                                                                                                                                                    case -1381459075: {
                                                                                                                                                                                        c7.0(String.valueOf(c8));
                                                                                                                                                                                        break Label_0750;
                                                                                                                                                                                    }
                                                                                                                                                                                    default: {
                                                                                                                                                                                        throw null;
                                                                                                                                                                                    }
                                                                                                                                                                                }
                                                                                                                                                                                break;
                                                                                                                                                                            }
                                                                                                                                                                            break;
                                                                                                                                                                        }
                                                                                                                                                                        case -1846971025: {
                                                                                                                                                                            throw null;
                                                                                                                                                                        }
                                                                                                                                                                    }
                                                                                                                                                                    break;
                                                                                                                                                                }
                                                                                                                                                                break;
                                                                                                                                                            }
                                                                                                                                                            case 1514065449: {
                                                                                                                                                                throw null;
                                                                                                                                                            }
                                                                                                                                                        }
                                                                                                                                                        break;
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                            }
                                                                                                                                            return;
                                                                                                                                        }
                                                                                                                                        default: {
                                                                                                                                            throw null;
                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                    break;
                                                                                                                                }
                                                                                                                                break;
                                                                                                                            }
                                                                                                                            default: {
                                                                                                                                throw null;
                                                                                                                            }
                                                                                                                        }
                                                                                                                        break;
                                                                                                                    }
                                                                                                                    break;
                                                                                                                }
                                                                                                                case -1174507044: {
                                                                                                                    throw null;
                                                                                                                }
                                                                                                            }
                                                                                                            break;
                                                                                                        }
                                                                                                        break;
                                                                                                    }
                                                                                                    default: {
                                                                                                        throw null;
                                                                                                    }
                                                                                                }
                                                                                                break;
                                                                                            }
                                                                                            break;
                                                                                        }
                                                                                        default: {
                                                                                            throw null;
                                                                                        }
                                                                                    }
                                                                                    break;
                                                                                }
                                                                                break;
                                                                            }
                                                                            default: {
                                                                                throw null;
                                                                            }
                                                                        }
                                                                        break;
                                                                    }
                                                                    break;
                                                                }
                                                                case 1469457948: {
                                                                    throw null;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        break;
                                                    }
                                                    case -929339758: {
                                                        throw null;
                                                    }
                                                }
                                                break;
                                            }
                                            break;
                                        }
                                        default: {
                                            throw null;
                                        }
                                    }
                                    break;
                                }
                                break;
                            }
                            case 1062406125: {
                                throw null;
                            }
                        }
                        break;
                    }
                    break;
                }
                default: {
                    throw null;
                }
            }
            break;
        }
    }
    
    public void func_146286_b(final int n, final int n2, final int n3) {
        fez.eS(this, 447637078, n, n2, n3);
    }
    
    static {
        throw t;
    }
    
    public void func_73864_a(final int n, final int n2, final int n3) {
        fez.eR(this, 687011304, n, n2, n3);
    }
    
    public void func_73869_a(final char c, final int n) {
        fez.4n(this, 2068641811, c, n);
    }
    
    public void c(final boolean b) {
        fez.3k(this, 1301484698, b);
    }
}
