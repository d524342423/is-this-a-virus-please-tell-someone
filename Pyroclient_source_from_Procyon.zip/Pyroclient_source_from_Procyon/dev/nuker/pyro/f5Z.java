// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import org.jetbrains.annotations.Nullable;
import net.minecraft.client.gui.ScaledResolution;
import dev.nuker.pyro.security.inject.LauncherEventHide;
import org.jetbrains.annotations.NotNull;

public class f5Z extends f5T
{
    @NotNull
    public String 1;
    public int c;
    
    public int c() {
        return fez.fG(this, 604891089);
    }
    
    @NotNull
    @Override
    public String 4() {
        return fez.3S(this, 337709455);
    }
    
    public void c(final int n) {
        fez.5n(this, 416321485, n);
    }
    
    @f0g
    @LauncherEventHide
    public void c(@NotNull final f43 p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          1046
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            1038
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            1030
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: getstatic       dev/nuker/pyro/fc.c:I
        //    29: ifne            37
        //    32: ldc             -1516704274
        //    34: goto            39
        //    37: ldc             -716549503
        //    39: ldc             -254428547
        //    41: ixor           
        //    42: lookupswitch {
        //          -452611911: 37
        //          1431132051: 1013
        //          default: 68
        //        }
        //    68: aload_1        
        //    69: goto            73
        //    72: athrow         
        //    73: invokevirtual   dev/nuker/pyro/f43.c:()Ldev/nuker/pyro/f41;
        //    76: goto            80
        //    79: athrow         
        //    80: getstatic       dev/nuker/pyro/fc.c:I
        //    83: ifne            91
        //    86: ldc             -1067500578
        //    88: goto            93
        //    91: ldc             -1529974229
        //    93: ldc             -1686975850
        //    95: ixor           
        //    96: lookupswitch {
        //          1529737544: 1015
        //          2045315718: 91
        //          default: 124
        //        }
        //   124: getstatic       dev/nuker/pyro/f41.c:Ldev/nuker/pyro/f41;
        //   127: if_acmpne       135
        //   130: ldc             -844880502
        //   132: goto            137
        //   135: ldc             -844880503
        //   137: ldc             -259673533
        //   139: ixor           
        //   140: tableswitch {
        //          2051223442: 164
        //          2051223443: 990
        //          default: 130
        //        }
        //   164: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //   167: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   170: ifnull          990
        //   173: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //   176: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   179: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71071_by:Lnet/minecraft/entity/player/InventoryPlayer;
        //   182: getstatic       dev/nuker/pyro/fc.c:I
        //   185: ifne            193
        //   188: ldc             -1119552451
        //   190: goto            195
        //   193: ldc             785519288
        //   195: ldc             -747149330
        //   197: ixor           
        //   198: lookupswitch {
        //          -39488170: 224
        //          1848875987: 193
        //          default: 1019
        //        }
        //   224: goto            228
        //   227: athrow         
        //   228: invokevirtual   net/minecraft/entity/player/InventoryPlayer.func_70448_g:()Lnet/minecraft/item/ItemStack;
        //   231: goto            235
        //   234: athrow         
        //   235: dup            
        //   236: pop            
        //   237: goto            241
        //   240: athrow         
        //   241: invokevirtual   net/minecraft/item/ItemStack.func_77984_f:()Z
        //   244: goto            248
        //   247: athrow         
        //   248: ifeq            973
        //   251: getstatic       dev/nuker/pyro/fc.c:I
        //   254: ifne            262
        //   257: ldc             42740221
        //   259: goto            264
        //   262: ldc             918606268
        //   264: ldc             -240708335
        //   266: ixor           
        //   267: lookupswitch {
        //          -215270164: 1001
        //          122876139: 262
        //          default: 292
        //        }
        //   292: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //   295: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   298: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71071_by:Lnet/minecraft/entity/player/InventoryPlayer;
        //   301: goto            305
        //   304: athrow         
        //   305: invokevirtual   net/minecraft/entity/player/InventoryPlayer.func_70448_g:()Lnet/minecraft/item/ItemStack;
        //   308: goto            312
        //   311: athrow         
        //   312: dup            
        //   313: pop            
        //   314: goto            318
        //   317: athrow         
        //   318: invokevirtual   net/minecraft/item/ItemStack.func_77958_k:()I
        //   321: goto            325
        //   324: athrow         
        //   325: getstatic       dev/nuker/pyro/fc.1:I
        //   328: ifne            336
        //   331: ldc             124236455
        //   333: goto            338
        //   336: ldc             -1687942343
        //   338: ldc             -796341254
        //   340: ixor           
        //   341: lookupswitch {
        //          -672171683: 991
        //          813847223: 336
        //          default: 368
        //        }
        //   368: istore_2       
        //   369: getstatic       dev/nuker/pyro/fc.c:I
        //   372: ifne            380
        //   375: ldc             -1935243011
        //   377: goto            382
        //   380: ldc             -1807490630
        //   382: ldc             -569693633
        //   384: ixor           
        //   385: lookupswitch {
        //          1246284677: 412
        //          1387111106: 380
        //          default: 993
        //        }
        //   412: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //   415: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   418: getstatic       dev/nuker/pyro/fc.c:I
        //   421: ifne            429
        //   424: ldc             -1710321962
        //   426: goto            431
        //   429: ldc             1884547230
        //   431: ldc             -1283024114
        //   433: ixor           
        //   434: lookupswitch {
        //          -1009421424: 460
        //          696784344: 429
        //          default: 1005
        //        }
        //   460: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71071_by:Lnet/minecraft/entity/player/InventoryPlayer;
        //   463: goto            467
        //   466: athrow         
        //   467: invokevirtual   net/minecraft/entity/player/InventoryPlayer.func_70448_g:()Lnet/minecraft/item/ItemStack;
        //   470: goto            474
        //   473: athrow         
        //   474: dup            
        //   475: pop            
        //   476: goto            480
        //   479: athrow         
        //   480: invokevirtual   net/minecraft/item/ItemStack.func_77952_i:()I
        //   483: goto            487
        //   486: athrow         
        //   487: istore_3       
        //   488: aload_0        
        //   489: getstatic       dev/nuker/pyro/fc.c:I
        //   492: ifne            500
        //   495: ldc             -534940501
        //   497: goto            502
        //   500: ldc             313572747
        //   502: ldc             -1827859410
        //   504: ixor           
        //   505: lookupswitch {
        //          243520202: 500
        //          1930453125: 1003
        //          default: 532
        //        }
        //   532: getstatic       kotlin/jvm/internal/StringCompanionObject.INSTANCE:Lkotlin/jvm/internal/StringCompanionObject;
        //   535: astore          4
        //   537: ldc             "\u3dab\ub212\u8e02\uafa0\u613e\u5988\u7e42\u6938\uc0de\ua5c3\u9bc1\u131d\uc110\u73d8\u96ef\u4dc4\ub202"
        //   539: goto            543
        //   542: athrow         
        //   543: invokestatic    invokestatic   !!! ERROR
        //   546: goto            550
        //   549: athrow         
        //   550: astore          5
        //   552: iconst_1       
        //   553: anewarray       Ljava/lang/Object;
        //   556: dup            
        //   557: iconst_0       
        //   558: iload_2        
        //   559: getstatic       dev/nuker/pyro/fc.c:I
        //   562: ifne            570
        //   565: ldc             -1978500695
        //   567: goto            572
        //   570: ldc             815060290
        //   572: ldc             -1229984408
        //   574: ixor           
        //   575: lookupswitch {
        //          -2042939350: 600
        //          1019057345: 570
        //          default: 1007
        //        }
        //   600: iload_3        
        //   601: isub           
        //   602: getstatic       dev/nuker/pyro/fc.1:I
        //   605: ifne            613
        //   608: ldc             187778487
        //   610: goto            615
        //   613: ldc             1505471286
        //   615: ldc             -1953155632
        //   617: ixor           
        //   618: lookupswitch {
        //          -2136706969: 613
        //          -768696602: 644
        //          default: 995
        //        }
        //   644: goto            648
        //   647: athrow         
        //   648: invokestatic    java/lang/Integer.valueOf:(I)Ljava/lang/Integer;
        //   651: goto            655
        //   654: athrow         
        //   655: aastore        
        //   656: astore          6
        //   658: astore          8
        //   660: iconst_0       
        //   661: getstatic       dev/nuker/pyro/fc.c:I
        //   664: ifne            672
        //   667: ldc             912600687
        //   669: goto            674
        //   672: ldc             -1598495880
        //   674: ldc             -70882452
        //   676: ixor           
        //   677: lookupswitch {
        //          -844937981: 672
        //          1535019028: 704
        //          default: 999
        //        }
        //   704: istore          7
        //   706: aload           5
        //   708: aload           6
        //   710: dup            
        //   711: arraylength    
        //   712: goto            716
        //   715: athrow         
        //   716: invokestatic    java/util/Arrays.copyOf:([Ljava/lang/Object;I)[Ljava/lang/Object;
        //   719: goto            723
        //   722: athrow         
        //   723: getstatic       dev/nuker/pyro/fc.c:I
        //   726: ifne            734
        //   729: ldc             -530849994
        //   731: goto            736
        //   734: ldc             -920313708
        //   736: ldc             -1231687428
        //   738: ixor           
        //   739: lookupswitch {
        //          -901075189: 734
        //          1456353226: 1009
        //          default: 764
        //        }
        //   764: goto            768
        //   767: athrow         
        //   768: invokestatic    java/lang/String.format:(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
        //   771: goto            775
        //   774: athrow         
        //   775: dup            
        //   776: pop            
        //   777: astore          9
        //   779: getstatic       dev/nuker/pyro/fc.1:I
        //   782: ifne            790
        //   785: ldc             -1028276389
        //   787: goto            792
        //   790: ldc             -1848409294
        //   792: ldc             -596825060
        //   794: ixor           
        //   795: lookupswitch {
        //          517509959: 790
        //          1304342318: 820
        //          default: 1011
        //        }
        //   820: aload           8
        //   822: aload           9
        //   824: getstatic       dev/nuker/pyro/fc.c:I
        //   827: ifne            835
        //   830: ldc             497584979
        //   832: goto            837
        //   835: ldc             -545991005
        //   837: ldc             -7270810
        //   839: ixor           
        //   840: lookupswitch {
        //          -499546827: 835
        //          551934149: 868
        //          default: 997
        //        }
        //   868: putfield        dev/nuker/pyro/f5Z.1:Ljava/lang/String;
        //   871: aload_0        
        //   872: new             Ldev/nuker/pyro/feo;
        //   875: dup            
        //   876: iload_2        
        //   877: iload_3        
        //   878: isub           
        //   879: i2f            
        //   880: iload_2        
        //   881: i2f            
        //   882: fdiv           
        //   883: ldc             120.0
        //   885: fmul           
        //   886: ldc             100.0
        //   888: ldc             50.0
        //   890: fconst_1       
        //   891: getstatic       dev/nuker/pyro/fc.1:I
        //   894: ifne            902
        //   897: ldc             2054306145
        //   899: goto            904
        //   902: ldc             2124414411
        //   904: ldc             883872536
        //   906: ixor           
        //   907: lookupswitch {
        //          1244737235: 932
        //          1323100793: 902
        //          default: 1017
        //        }
        //   932: goto            936
        //   935: athrow         
        //   936: invokespecial   dev/nuker/pyro/feo.<init>:(FFFF)V
        //   939: goto            943
        //   942: athrow         
        //   943: goto            947
        //   946: athrow         
        //   947: invokevirtual   dev/nuker/pyro/feo.4:()Ljava/awt/Color;
        //   950: goto            954
        //   953: athrow         
        //   954: dup            
        //   955: pop            
        //   956: goto            960
        //   959: athrow         
        //   960: invokevirtual   java/awt/Color.getRGB:()I
        //   963: goto            967
        //   966: athrow         
        //   967: putfield        dev/nuker/pyro/f5Z.c:I
        //   970: goto            990
        //   973: aload_0        
        //   974: ldc             "\u3dab\ub212\u8e02\uafa0\u613e\u5988\u7e42\u6938\uc0de\ua5c3\u9bc1\u131d\uc110\u73d8\u96ef\u4da8\ub21f\u4cbc"
        //   976: goto            980
        //   979: athrow         
        //   980: invokestatic    invokestatic   !!! ERROR
        //   983: goto            987
        //   986: athrow         
        //   987: putfield        dev/nuker/pyro/f5Z.1:Ljava/lang/String;
        //   990: return         
        //   991: aconst_null    
        //   992: athrow         
        //   993: aconst_null    
        //   994: athrow         
        //   995: aconst_null    
        //   996: athrow         
        //   997: aconst_null    
        //   998: athrow         
        //   999: aconst_null    
        //  1000: athrow         
        //  1001: aconst_null    
        //  1002: athrow         
        //  1003: aconst_null    
        //  1004: athrow         
        //  1005: aconst_null    
        //  1006: athrow         
        //  1007: aconst_null    
        //  1008: athrow         
        //  1009: aconst_null    
        //  1010: athrow         
        //  1011: aconst_null    
        //  1012: athrow         
        //  1013: aconst_null    
        //  1014: athrow         
        //  1015: aconst_null    
        //  1016: athrow         
        //  1017: aconst_null    
        //  1018: athrow         
        //  1019: aconst_null    
        //  1020: athrow         
        //  1021: pop            
        //  1022: goto            24
        //  1025: pop            
        //  1026: aconst_null    
        //  1027: goto            1021
        //  1030: dup            
        //  1031: ifnull          1021
        //  1034: checkcast       Ljava/lang/Throwable;
        //  1037: athrow         
        //  1038: dup            
        //  1039: ifnull          1025
        //  1042: checkcast       Ljava/lang/Throwable;
        //  1045: athrow         
        //  1046: aconst_null    
        //  1047: athrow         
        //    StackMapTable: 00 87 43 07 00 44 04 FF 00 0B 00 00 00 01 07 00 44 FD 00 03 07 00 03 07 00 4B 0C 41 01 1C 43 07 00 44 40 07 00 4B 45 07 00 44 40 07 00 53 4A 07 00 53 FF 00 01 00 02 07 00 03 07 00 4B 00 02 07 00 53 01 5E 07 00 53 05 04 41 01 1A 5C 07 00 6F FF 00 01 00 02 07 00 03 07 00 4B 00 02 07 00 6F 01 5C 07 00 6F 42 07 00 28 40 07 00 6F 45 07 00 44 40 07 00 75 44 07 00 36 40 07 00 75 45 07 00 44 40 01 0D 41 01 1B 4B 07 00 34 40 07 00 6F 45 07 00 44 40 07 00 75 44 07 00 38 40 07 00 75 45 07 00 44 40 01 4A 01 FF 00 01 00 02 07 00 03 07 00 4B 00 02 01 01 5D 01 FC 00 0B 01 41 01 1D 50 07 00 66 FF 00 01 00 03 07 00 03 07 00 4B 01 00 02 07 00 66 01 5C 07 00 66 FF 00 05 00 00 00 01 07 00 44 FF 00 00 00 03 07 00 03 07 00 4B 01 00 01 07 00 6F 45 07 00 44 40 07 00 75 44 07 00 44 40 07 00 75 45 07 00 44 40 01 FF 00 0C 00 04 07 00 03 07 00 4B 01 01 00 01 07 00 03 FF 00 01 00 04 07 00 03 07 00 4B 01 01 00 02 07 00 03 01 5D 07 00 03 FF 00 09 00 05 07 00 03 07 00 4B 01 01 07 00 90 00 01 07 00 3A FF 00 00 00 05 07 00 03 07 00 4B 01 01 07 00 90 00 02 07 00 03 07 00 B8 45 07 00 44 FF 00 00 00 05 07 00 03 07 00 4B 01 01 07 00 90 00 02 07 00 03 07 00 B8 FF 00 13 00 06 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 00 05 07 00 03 07 00 DD 07 00 DD 01 01 FF 00 01 00 06 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 00 06 07 00 03 07 00 DD 07 00 DD 01 01 01 FF 00 1B 00 06 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 00 05 07 00 03 07 00 DD 07 00 DD 01 01 FF 00 0C 00 06 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 00 05 07 00 03 07 00 DD 07 00 DD 01 01 FF 00 01 00 06 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 00 06 07 00 03 07 00 DD 07 00 DD 01 01 01 FF 00 1C 00 06 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 00 05 07 00 03 07 00 DD 07 00 DD 01 01 42 07 00 44 FF 00 00 00 06 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 00 05 07 00 03 07 00 DD 07 00 DD 01 01 45 07 00 44 FF 00 00 00 06 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 00 05 07 00 03 07 00 DD 07 00 DD 01 07 00 A6 FF 00 10 00 09 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 00 07 00 03 00 01 01 FF 00 01 00 09 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 00 07 00 03 00 02 01 01 5D 01 FF 00 0A 00 09 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 00 01 07 00 44 FF 00 00 00 09 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 00 03 07 00 B8 07 00 DD 01 45 07 00 44 FF 00 00 00 09 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 00 02 07 00 B8 07 00 DD FF 00 0A 00 09 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 00 02 07 00 B8 07 00 DD FF 00 01 00 09 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 00 03 07 00 B8 07 00 DD 01 FF 00 1B 00 09 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 00 02 07 00 B8 07 00 DD 42 07 00 44 FF 00 00 00 09 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 00 02 07 00 B8 07 00 DD 45 07 00 44 40 07 00 B8 FC 00 0E 07 00 B8 41 01 1B FF 00 0E 00 0A 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 07 00 B8 00 02 07 00 03 07 00 B8 FF 00 01 00 0A 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 07 00 B8 00 03 07 00 03 07 00 B8 01 FF 00 1E 00 0A 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 07 00 B8 00 02 07 00 03 07 00 B8 FF 00 21 00 0A 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 07 00 B8 00 07 07 00 03 08 03 68 08 03 68 02 02 02 02 FF 00 01 00 0A 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 07 00 B8 00 08 07 00 03 08 03 68 08 03 68 02 02 02 02 01 FF 00 1B 00 0A 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 07 00 B8 00 07 07 00 03 08 03 68 08 03 68 02 02 02 02 42 07 00 44 FF 00 00 00 0A 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 07 00 B8 00 07 07 00 03 08 03 68 08 03 68 02 02 02 02 45 07 00 44 FF 00 00 00 0A 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 07 00 B8 00 02 07 00 03 07 00 C6 42 07 00 36 FF 00 00 00 0A 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 07 00 B8 00 02 07 00 03 07 00 C6 45 07 00 44 FF 00 00 00 0A 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 07 00 B8 00 02 07 00 03 07 00 D5 44 07 00 44 FF 00 00 00 0A 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 07 00 B8 00 02 07 00 03 07 00 D5 45 07 00 44 FF 00 00 00 0A 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 07 00 B8 00 02 07 00 03 01 FF 00 05 00 02 07 00 03 07 00 4B 00 00 FF 00 05 00 00 00 01 07 00 44 FF 00 00 00 02 07 00 03 07 00 4B 00 02 07 00 03 07 00 B8 45 07 00 44 FF 00 00 00 02 07 00 03 07 00 4B 00 02 07 00 03 07 00 B8 02 40 01 FC 00 01 01 FF 00 01 00 06 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 00 05 07 00 03 07 00 DD 07 00 DD 01 01 FF 00 01 00 0A 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 07 00 B8 00 02 07 00 03 07 00 B8 FF 00 01 00 09 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 00 07 00 03 00 01 01 FF 00 01 00 02 07 00 03 07 00 4B 00 00 FF 00 01 00 04 07 00 03 07 00 4B 01 01 00 01 07 00 03 FF 00 01 00 03 07 00 03 07 00 4B 01 00 01 07 00 66 FF 00 01 00 06 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 00 05 07 00 03 07 00 DD 07 00 DD 01 01 FF 00 01 00 09 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 00 02 07 00 B8 07 00 DD FC 00 01 07 00 B8 FF 00 01 00 02 07 00 03 07 00 4B 00 00 41 07 00 53 FF 00 01 00 0A 07 00 03 07 00 4B 01 01 07 00 90 07 00 B8 07 00 DD 01 07 00 03 07 00 B8 00 07 07 00 03 08 03 68 08 03 68 02 02 02 02 FF 00 01 00 02 07 00 03 07 00 4B 00 01 07 00 6F 41 07 00 44 43 05 44 07 00 44 47 05 47 07 00 44
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     1030   1038   Ljava/lang/ArithmeticException;
        //  1030   1038   1030   1038   Any
        //  1046   1048   3      8      Ljava/lang/NegativeArraySizeException;
        //  72     79     79     80     Any
        //  73     79     3      8      Ljava/lang/AssertionError;
        //  73     79     72     73     Any
        //  72     79     3      8      Any
        //  72     79     72     73     Ljava/util/ConcurrentModificationException;
        //  227    234    234    235    Any
        //  228    234    3      8      Ljava/lang/IllegalStateException;
        //  227    234    234    235    Ljava/lang/IndexOutOfBoundsException;
        //  227    234    3      8      Any
        //  228    234    227    228    Ljava/lang/AssertionError;
        //  240    247    247    248    Any
        //  240    247    240    241    Ljava/lang/IllegalArgumentException;
        //  240    247    240    241    Ljava/lang/IllegalStateException;
        //  241    247    3      8      Ljava/lang/ClassCastException;
        //  241    247    247    248    Ljava/lang/ClassCastException;
        //  304    311    311    312    Any
        //  305    311    3      8      Any
        //  304    311    3      8      Ljava/lang/ClassCastException;
        //  305    311    304    305    Ljava/lang/NumberFormatException;
        //  304    311    3      8      Ljava/util/ConcurrentModificationException;
        //  317    324    324    325    Any
        //  318    324    3      8      Ljava/lang/RuntimeException;
        //  318    324    317    318    Ljava/lang/UnsupportedOperationException;
        //  318    324    324    325    Ljava/lang/EnumConstantNotPresentException;
        //  317    324    324    325    Any
        //  467    473    473    474    Any
        //  467    473    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  467    473    3      8      Any
        //  467    473    473    474    Any
        //  467    473    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  479    486    486    487    Any
        //  480    486    479    480    Any
        //  480    486    479    480    Any
        //  479    486    3      8      Any
        //  479    486    486    487    Ljava/lang/UnsupportedOperationException;
        //  542    549    549    550    Any
        //  543    549    542    543    Ljava/lang/EnumConstantNotPresentException;
        //  543    549    542    543    Ljava/lang/EnumConstantNotPresentException;
        //  542    549    549    550    Any
        //  542    549    549    550    Ljava/lang/ArithmeticException;
        //  647    654    654    655    Any
        //  647    654    647    648    Any
        //  648    654    3      8      Ljava/lang/AssertionError;
        //  647    654    654    655    Any
        //  647    654    3      8      Any
        //  715    722    722    723    Any
        //  716    722    715    716    Any
        //  715    722    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  715    722    715    716    Any
        //  715    722    3      8      Any
        //  767    774    774    775    Any
        //  768    774    774    775    Any
        //  767    774    3      8      Ljava/util/ConcurrentModificationException;
        //  767    774    767    768    Any
        //  767    774    767    768    Ljava/util/ConcurrentModificationException;
        //  935    942    942    943    Any
        //  935    942    935    936    Any
        //  936    942    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  935    942    935    936    Ljava/lang/NumberFormatException;
        //  935    942    942    943    Ljava/lang/AssertionError;
        //  946    953    953    954    Any
        //  946    953    3      8      Any
        //  946    953    946    947    Ljava/lang/RuntimeException;
        //  946    953    3      8      Ljava/lang/IllegalStateException;
        //  946    953    3      8      Ljava/lang/NumberFormatException;
        //  959    966    966    967    Any
        //  959    966    3      8      Ljava/lang/ClassCastException;
        //  960    966    959    960    Ljava/lang/IndexOutOfBoundsException;
        //  959    966    3      8      Any
        //  959    966    959    960    Any
        //  980    986    986    987    Any
        //  980    986    986    987    Any
        //  980    986    986    987    Ljava/lang/NullPointerException;
        //  980    986    3      8      Any
        //  980    986    986    987    Ljava/util/ConcurrentModificationException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:543)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    static {
        throw t;
    }
    
    public f5Z() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: ldc             "\u3d7c\ub24c\u8e28\uada3"
        //     3: invokestatic    invokestatic   !!! ERROR
        //     6: invokespecial   dev/nuker/pyro/f5T.<init>:(Ljava/lang/String;)V
        //     9: aload_0        
        //    10: ldc             ""
        //    12: putfield        dev/nuker/pyro/f5Z.1:Ljava/lang/String;
        //    15: aload_0        
        //    16: ldc             11184810
        //    18: putfield        dev/nuker/pyro/f5Z.c:I
        //    21: return         
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2695)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public int c(@Nullable final ScaledResolution scaledResolution, final float n, final float n2) {
        return fez.dh(this, 1917200864, scaledResolution, n, n2);
    }
}
