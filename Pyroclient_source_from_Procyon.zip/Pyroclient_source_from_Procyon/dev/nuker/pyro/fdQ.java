// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import org.jetbrains.annotations.NotNull;
import net.minecraft.util.EnumFacing;
import java.util.HashMap;

public class fdQ
{
    @NotNull
    public static HashMap<EnumFacing, Integer> c;
    public static fdQ c;
    
    static {
        final fdQ c = new fdQ();
        while (true) {
            int n = 0;
            Label_0022: {
                if (fc.c == 0) {
                    n = -1750969139;
                    break Label_0022;
                }
                n = -2090480094;
            }
            switch (n ^ 0xE29244EE) {
                case 1966084131: {
                    continue;
                }
                case 1643612876: {
                    fdQ.c = c;
                    while (true) {
                        int n2 = 0;
                        Label_0072: {
                            if (fc.1 == 0) {
                                n2 = -2077349935;
                                break Label_0072;
                            }
                            n2 = -1262345988;
                        }
                        switch (n2 ^ 0x29357741) {
                            case -1390718832: {
                                continue;
                            }
                            case -1644734531: {
                                fdQ.c = new HashMap<EnumFacing, Integer>();
                                fdQ.c.put(EnumFacing.DOWN, 1);
                                while (true) {
                                    int n3 = 0;
                                    Label_0138: {
                                        if (fc.0 <= 0) {
                                            n3 = -1962619160;
                                            break Label_0138;
                                        }
                                        n3 = 902250491;
                                    }
                                    switch (n3 ^ 0x1F18EA93) {
                                        case -1810094981: {
                                            continue;
                                        }
                                        case 719312232: {
                                            final HashMap<EnumFacing, Integer> hashMap = fdQ.c;
                                            final EnumFacing west = EnumFacing.WEST;
                                            final int i = 16;
                                            while (true) {
                                                int n4 = 0;
                                                Label_0192: {
                                                    if (fc.c == 0) {
                                                        n4 = 1273921010;
                                                        break Label_0192;
                                                    }
                                                    n4 = 2081511089;
                                                }
                                                switch (n4 ^ 0x867B6E93) {
                                                    case -845868191: {
                                                        continue;
                                                    }
                                                    case -93702110: {
                                                        hashMap.put(west, i);
                                                        fdQ.c.put(EnumFacing.NORTH, 4);
                                                        fdQ.c.put(EnumFacing.SOUTH, 8);
                                                        final HashMap<EnumFacing, Integer> hashMap2 = fdQ.c;
                                                        while (true) {
                                                            int n5 = 0;
                                                            Label_0287: {
                                                                if (fc.0 <= 0) {
                                                                    n5 = -2017676118;
                                                                    break Label_0287;
                                                                }
                                                                n5 = 1326466566;
                                                            }
                                                            switch (n5 ^ 0x3C26A33B) {
                                                                case -1147529327: {
                                                                    continue;
                                                                }
                                                                case 1932977469: {
                                                                    final EnumFacing east = EnumFacing.EAST;
                                                                    final Integer value = 32;
                                                                    while (true) {
                                                                        int n6 = 0;
                                                                        Label_0337: {
                                                                            if (fc.0 <= 0) {
                                                                                n6 = -966155286;
                                                                                break Label_0337;
                                                                            }
                                                                            n6 = 1744187824;
                                                                        }
                                                                        switch (n6 ^ 0x39D41380) {
                                                                            case -163537127: {
                                                                                continue;
                                                                            }
                                                                            default: {
                                                                                hashMap2.put(east, value);
                                                                                while (true) {
                                                                                    int n7 = 0;
                                                                                    Label_0387: {
                                                                                        if (fc.1 == 0) {
                                                                                            n7 = 1382490543;
                                                                                            break Label_0387;
                                                                                        }
                                                                                        n7 = -931760213;
                                                                                    }
                                                                                    switch (n7 ^ 0x9EA5C94A) {
                                                                                        case 1752414947: {
                                                                                            continue;
                                                                                        }
                                                                                        default: {
                                                                                            fdQ.c.put(EnumFacing.UP, 2);
                                                                                            return;
                                                                                        }
                                                                                        case -859641627: {
                                                                                            throw null;
                                                                                        }
                                                                                    }
                                                                                    break;
                                                                                }
                                                                                break;
                                                                            }
                                                                            case -4345750: {
                                                                                throw null;
                                                                            }
                                                                        }
                                                                        break;
                                                                    }
                                                                    break;
                                                                }
                                                                default: {
                                                                    throw null;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        break;
                                                    }
                                                    default: {
                                                        throw null;
                                                    }
                                                }
                                                break;
                                            }
                                            break;
                                        }
                                        default: {
                                            throw null;
                                        }
                                    }
                                    break;
                                }
                                break;
                            }
                            default: {
                                throw null;
                            }
                        }
                        break;
                    }
                    break;
                }
                default: {
                    throw null;
                }
            }
            break;
        }
    }
    
    @NotNull
    public HashMap c() {
        Object o = null;
        Block_0: {
            break Block_0;
        Label_0037:
            while (true) {
                do {
                    Label_0024: {
                        break Label_0024;
                        try {
                            o = null;
                            if (fc.1 != 0) {
                                null;
                                goto Label_0029;
                            }
                            continue Label_0037;
                            return fdQ.c;
                        }
                        catch (ClassCastException ex) {}
                    }
                    continue Label_0037;
                } while (o == null);
                break;
            }
        }
        throw (Throwable)o;
    }
}
