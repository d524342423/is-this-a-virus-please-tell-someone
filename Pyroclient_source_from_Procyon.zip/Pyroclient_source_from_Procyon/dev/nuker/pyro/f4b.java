// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import org.jetbrains.annotations.NotNull;

public class f4b extends f4g
{
    static {
        throw t;
    }
    
    public f4b(@NotNull final String s) {
        super(s);
    }
}
