// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import net.minecraft.client.entity.EntityPlayerSP;
import dev.nuker.pyro.security.inject.LauncherEventHide;
import org.jetbrains.annotations.NotNull;

public class fac extends fQ
{
    @NotNull
    public f0p c;
    @NotNull
    public f0k c;
    @NotNull
    public f0p 0;
    public int 1;
    public float c;
    
    public int 1() {
        return fez.f6(this, 51222880);
    }
    
    public float c(final float p0, final int p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          118
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            110
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            102
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: fload_1        
        //    25: ldc             360.0
        //    27: getstatic       dev/nuker/pyro/fc.c:I
        //    30: ifne            38
        //    33: ldc             1165779853
        //    35: goto            40
        //    38: ldc             -664879975
        //    40: ldc             198250115
        //    42: ixor           
        //    43: lookupswitch {
        //          -745557478: 68
        //          1319988494: 38
        //          default: 91
        //        }
        //    68: iload_2        
        //    69: i2f            
        //    70: fdiv           
        //    71: fdiv           
        //    72: goto            76
        //    75: athrow         
        //    76: invokestatic    kotlin/math/MathKt.roundToInt:(F)I
        //    79: goto            83
        //    82: athrow         
        //    83: i2f            
        //    84: ldc             360.0
        //    86: iload_2        
        //    87: i2f            
        //    88: fdiv           
        //    89: fmul           
        //    90: freturn        
        //    91: aconst_null    
        //    92: athrow         
        //    93: pop            
        //    94: goto            24
        //    97: pop            
        //    98: aconst_null    
        //    99: goto            93
        //   102: dup            
        //   103: ifnull          93
        //   106: checkcast       Ljava/lang/Throwable;
        //   109: athrow         
        //   110: dup            
        //   111: ifnull          97
        //   114: checkcast       Ljava/lang/Throwable;
        //   117: athrow         
        //   118: aconst_null    
        //   119: athrow         
        //    StackMapTable: 00 11 43 07 00 20 04 FF 00 0B 00 00 00 01 07 00 20 FE 00 03 07 00 03 02 01 FF 00 0D 00 03 07 00 03 02 01 00 02 02 02 FF 00 01 00 03 07 00 03 02 01 00 03 02 02 01 FF 00 1B 00 03 07 00 03 02 01 00 02 02 02 46 07 00 20 40 02 45 07 00 20 40 01 FF 00 07 00 03 07 00 03 02 01 00 02 02 02 41 07 00 20 43 05 44 07 00 20 47 05 47 07 00 20
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                      
        //  -----  -----  -----  -----  ------------------------------------------
        //  8      20     102    110    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  102    110    102    110    Any
        //  118    120    3      8      Ljava/lang/ArithmeticException;
        //  75     82     82     83     Any
        //  76     82     75     76     Any
        //  75     82     3      8      Any
        //  76     82     75     76     Any
        //  76     82     82     83     Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 53 out of bounds for length 53
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public float c() {
        return fez.et(this, 1443027741);
    }
    
    @NotNull
    public f0p 3() {
        return fez.4T(this, 1837827504);
    }
    
    public void 3(final int n) {
        fez.5B(this, 1820486875, n);
    }
    
    @f0g
    @LauncherEventHide
    public void c(@NotNull final f43 f43) {
        fez.bI(this, 666549436, f43);
    }
    
    public void c(final float n) {
        fez.aP(this, 492819066, n);
    }
    
    public fac() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: ldc             "\u3792\ub244\u84de\uad9b\u68b4\u5361\u7e43\u63d5"
        //     3: getstatic       dev/nuker/pyro/fc.1:I
        //     6: ifne            14
        //     9: ldc             -118511419
        //    11: goto            16
        //    14: ldc             -131432210
        //    16: ldc             416312437
        //    18: ixor           
        //    19: lookupswitch {
        //          -532691792: 634
        //          1637231578: 14
        //          default: 44
        //        }
        //    44: invokestatic    invokestatic   !!! ERROR
        //    47: ldc             "\u37b2\ub244\u84de\uad88\u68b7\u536d\u7e4b"
        //    49: invokestatic    invokestatic   !!! ERROR
        //    52: ldc             "\u37a7\ub24a\u84ca\uadaf\u68f8\u5377\u7e4f\u63cb\uc2d1\uac1e\u912b\u1305\ucba8\u714e\u9f7a\u4769\ub251\u464c\u014d\u089e\u183e\ufec7\u6008\u885a\u39db\u37e7\u7ff7\ua3b8\ud1a0\u7d97\u4eb1\u6bbc\u7ece\u9771\uc864\u49e1\ufdf8\u1a0f\u1842\u4505\u6cdb\uac0c\u87bf\uf927\ub313\uaefc\u4c2b\u35c8\u4a2a\uadc6\u7292\u917b"
        //    54: invokestatic    invokestatic   !!! ERROR
        //    57: invokespecial   dev/nuker/pyro/fQ.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //    60: getstatic       dev/nuker/pyro/fc.0:I
        //    63: ifgt            71
        //    66: ldc             2018109922
        //    68: goto            73
        //    71: ldc             -794018971
        //    73: ldc             -44490005
        //    75: ixor           
        //    76: lookupswitch {
        //          -2062497015: 638
        //          -1632755866: 71
        //          default: 104
        //        }
        //   104: aload_0        
        //   105: aload_0        
        //   106: new             Ldev/nuker/pyro/f0p;
        //   109: dup            
        //   110: ldc             "\u378f\ub24c\u84db\uada1\u68bb\u537a\u7e49\u63d1\uc2cd\uac4d"
        //   112: getstatic       dev/nuker/pyro/fc.c:I
        //   115: ifne            123
        //   118: ldc             529554556
        //   120: goto            125
        //   123: ldc             593920426
        //   125: ldc             -432970815
        //   127: ixor           
        //   128: lookupswitch {
        //          -984096149: 156
        //          -106872899: 123
        //          default: 644
        //        }
        //   156: invokestatic    invokestatic   !!! ERROR
        //   159: ldc             "\u37af\ub24c\u84db\uada1\u68bb\u537a\u7e49\u63d1\uc2cd\uac4d"
        //   161: getstatic       dev/nuker/pyro/fc.1:I
        //   164: ifne            172
        //   167: ldc             1587102696
        //   169: goto            174
        //   172: ldc             1581073216
        //   174: ldc             1072137577
        //   176: ixor           
        //   177: lookupswitch {
        //          1635698305: 172
        //          1641727529: 204
        //          default: 648
        //        }
        //   204: invokestatic    invokestatic   !!! ERROR
        //   207: ldc             "\u37a5\ub250\u84c4\uada6\u68bd\u537c\u7e00\u63d1\uc2c5\uac1e\u9121\u130a\ucbbe\u711e\u9f29\u4762\ub218\u4647\u0147\u0888\u186a\ufecd\u6006\u885a\u3988\u37af\u7fbb\ua380\ud1a0\u7d89\u4eb0\u6ba2\u7edb\u9771\uc873\u49e5\ufde9\u1a0f\u1849\u450c\u6c8c\uac50\u87bf\uf92f\ub340\uaeb4\u4c30\u35ca\u4a21\uadde\u729e\u916f\u3997\u6fc6\uf96a\u0435\u7a5f"
        //   209: invokestatic    invokestatic   !!! ERROR
        //   212: bipush          8
        //   214: iconst_2       
        //   215: bipush          16
        //   217: iconst_0       
        //   218: bipush          64
        //   220: aconst_null    
        //   221: invokespecial   dev/nuker/pyro/f0p.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILkotlin/jvm/internal/DefaultConstructorMarker;)V
        //   224: checkcast       Ldev/nuker/pyro/f0w;
        //   227: invokevirtual   dev/nuker/pyro/fac.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   230: checkcast       Ldev/nuker/pyro/f0p;
        //   233: putfield        dev/nuker/pyro/fac.c:Ldev/nuker/pyro/f0p;
        //   236: aload_0        
        //   237: aload_0        
        //   238: new             Ldev/nuker/pyro/f0k;
        //   241: dup            
        //   242: ldc             "\u3787\ub24a\u84ca\uadaf\u6887\u5363\u7e4f\u63cb\uc2d0\uac5b"
        //   244: invokestatic    invokestatic   !!! ERROR
        //   247: ldc             "\u37a7\ub24a\u84ca\uadaf\u68f8\u5343\u7e4f\u63cb\uc2d0\uac5b"
        //   249: getstatic       dev/nuker/pyro/fc.c:I
        //   252: ifne            260
        //   255: ldc             560172523
        //   257: goto            262
        //   260: ldc             1328307644
        //   262: ldc             649118620
        //   264: ixor           
        //   265: lookupswitch {
        //          -305812322: 260
        //          131288695: 630
        //          default: 292
        //        }
        //   292: invokestatic    invokestatic   !!! ERROR
        //   295: ldc             "\u37b2\ub24a\u84dc\uade4\u68bb\u536f\u7e4e\u6399\uc2d7\uac1e\u913f\u130b\ucba9\u710b\u9f29\u4772\ub219\u4650\u0102\u0886\u1871\ufed1\u601a\u8851\u39db\u37e0\u7fef\ua3e1\ud1e1\u7d88\u4ea9\u6be0\u7e81"
        //   297: invokestatic    invokestatic   !!! ERROR
        //   300: iconst_0       
        //   301: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   304: checkcast       Ldev/nuker/pyro/f0w;
        //   307: invokevirtual   dev/nuker/pyro/fac.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   310: checkcast       Ldev/nuker/pyro/f0k;
        //   313: getstatic       dev/nuker/pyro/fc.c:I
        //   316: ifne            324
        //   319: ldc             -909524303
        //   321: goto            326
        //   324: ldc             671333256
        //   326: ldc             356870270
        //   328: ixor           
        //   329: lookupswitch {
        //          -594761009: 646
        //          -344926227: 324
        //          default: 356
        //        }
        //   356: putfield        dev/nuker/pyro/fac.c:Ldev/nuker/pyro/f0k;
        //   359: aload_0        
        //   360: getstatic       dev/nuker/pyro/fc.0:I
        //   363: ifgt            371
        //   366: ldc             1926494208
        //   368: goto            373
        //   371: ldc             -16415170
        //   373: ldc             1298535333
        //   375: ixor           
        //   376: lookupswitch {
        //          -756501986: 371
        //          1068886949: 636
        //          default: 404
        //        }
        //   404: aload_0        
        //   405: new             Ldev/nuker/pyro/f0p;
        //   408: dup            
        //   409: ldc             "\u3798\ub24b\u84c8\uadb4\u6887\u537a\u7e49\u63dd\uc2c8\uac4d"
        //   411: invokestatic    invokestatic   !!! ERROR
        //   414: ldc             "\u37b8\ub24b\u84c8\uadb4\u68f8\u535a\u7e49\u63dd\uc2c8\uac4d"
        //   416: invokestatic    invokestatic   !!! ERROR
        //   419: ldc             "\u37af\ub240\u84c5\uada5\u68a1\u532e\u7e42\u63db\uc2d7\uac49\u9137\u1301\ucbb1\u714e\u9f64\u4769\ub204\u4646\u0147\u08cb\u1873\ufecb\u601f\u8851\u3996\u37e4\u7ff5\ua3b5\ud1a0\u7d85\u4eab\u6baa\u7e8f\u976b\uc86d\u49e8\ufdfc\u1a5f\u184f\u4504\u6ccb\uac42\u87eb\uf929\ub313\uaeed\u4c23\u35d8"
        //   421: getstatic       dev/nuker/pyro/fc.c:I
        //   424: ifne            432
        //   427: ldc             -1088522504
        //   429: goto            434
        //   432: ldc             -2094580667
        //   434: ldc             1990120532
        //   436: ixor           
        //   437: lookupswitch {
        //          -914316628: 432
        //          -172365807: 464
        //          default: 632
        //        }
        //   464: invokestatic    invokestatic   !!! ERROR
        //   467: bipush          10
        //   469: iconst_0       
        //   470: sipush          200
        //   473: iconst_0       
        //   474: bipush          64
        //   476: aconst_null    
        //   477: getstatic       dev/nuker/pyro/fc.c:I
        //   480: ifne            488
        //   483: ldc             1370837566
        //   485: goto            490
        //   488: ldc             99224868
        //   490: ldc             -573032735
        //   492: ixor           
        //   493: lookupswitch {
        //          -1938987809: 488
        //          -667796539: 520
        //          default: 640
        //        }
        //   520: invokespecial   dev/nuker/pyro/f0p.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIIIILkotlin/jvm/internal/DefaultConstructorMarker;)V
        //   523: checkcast       Ldev/nuker/pyro/f0w;
        //   526: getstatic       dev/nuker/pyro/fc.c:I
        //   529: ifne            537
        //   532: ldc             -1177905734
        //   534: goto            539
        //   537: ldc             -396502305
        //   539: ldc             -1563818250
        //   541: ixor           
        //   542: lookupswitch {
        //          453022540: 537
        //          1251466281: 568
        //          default: 650
        //        }
        //   568: invokevirtual   dev/nuker/pyro/fac.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   571: checkcast       Ldev/nuker/pyro/f0p;
        //   574: putfield        dev/nuker/pyro/fac.0:Ldev/nuker/pyro/f0p;
        //   577: aload_0        
        //   578: getstatic       dev/nuker/pyro/fc.0:I
        //   581: ifgt            589
        //   584: ldc             962880399
        //   586: goto            591
        //   589: ldc             -1949281646
        //   591: ldc             -596072507
        //   593: ixor           
        //   594: lookupswitch {
        //          -451099574: 589
        //          1470690647: 620
        //          default: 642
        //        }
        //   620: getstatic       kotlin/jvm/internal/FloatCompanionObject.INSTANCE:Lkotlin/jvm/internal/FloatCompanionObject;
        //   623: invokevirtual   kotlin/jvm/internal/FloatCompanionObject.getMIN_VALUE:()F
        //   626: putfield        dev/nuker/pyro/fac.c:F
        //   629: return         
        //   630: aconst_null    
        //   631: athrow         
        //   632: aconst_null    
        //   633: athrow         
        //   634: aconst_null    
        //   635: athrow         
        //   636: aconst_null    
        //   637: athrow         
        //   638: aconst_null    
        //   639: athrow         
        //   640: aconst_null    
        //   641: athrow         
        //   642: aconst_null    
        //   643: athrow         
        //   644: aconst_null    
        //   645: athrow         
        //   646: aconst_null    
        //   647: athrow         
        //   648: aconst_null    
        //   649: athrow         
        //   650: aconst_null    
        //   651: athrow         
        //    StackMapTable: 00 2C FF 00 0E 00 01 06 00 02 06 07 00 B4 FF 00 01 00 01 06 00 03 06 07 00 B4 01 FF 00 1B 00 01 06 00 02 06 07 00 B4 FF 00 1A 00 01 07 00 03 00 00 41 01 1E FF 00 12 00 01 07 00 03 00 05 07 00 03 07 00 03 08 00 6A 08 00 6A 07 00 B4 FF 00 01 00 01 07 00 03 00 06 07 00 03 07 00 03 08 00 6A 08 00 6A 07 00 B4 01 FF 00 1E 00 01 07 00 03 00 05 07 00 03 07 00 03 08 00 6A 08 00 6A 07 00 B4 FF 00 0F 00 01 07 00 03 00 06 07 00 03 07 00 03 08 00 6A 08 00 6A 07 00 B4 07 00 B4 FF 00 01 00 01 07 00 03 00 07 07 00 03 07 00 03 08 00 6A 08 00 6A 07 00 B4 07 00 B4 01 FF 00 1D 00 01 07 00 03 00 06 07 00 03 07 00 03 08 00 6A 08 00 6A 07 00 B4 07 00 B4 FF 00 37 00 01 07 00 03 00 06 07 00 03 07 00 03 08 00 EE 08 00 EE 07 00 B4 07 00 B4 FF 00 01 00 01 07 00 03 00 07 07 00 03 07 00 03 08 00 EE 08 00 EE 07 00 B4 07 00 B4 01 FF 00 1D 00 01 07 00 03 00 06 07 00 03 07 00 03 08 00 EE 08 00 EE 07 00 B4 07 00 B4 FF 00 1F 00 01 07 00 03 00 02 07 00 03 07 00 7F FF 00 01 00 01 07 00 03 00 03 07 00 03 07 00 7F 01 FF 00 1D 00 01 07 00 03 00 02 07 00 03 07 00 7F 4E 07 00 03 FF 00 01 00 01 07 00 03 00 02 07 00 03 01 5E 07 00 03 FF 00 1B 00 01 07 00 03 00 07 07 00 03 07 00 03 08 01 95 08 01 95 07 00 B4 07 00 B4 07 00 B4 FF 00 01 00 01 07 00 03 00 08 07 00 03 07 00 03 08 01 95 08 01 95 07 00 B4 07 00 B4 07 00 B4 01 FF 00 1D 00 01 07 00 03 00 07 07 00 03 07 00 03 08 01 95 08 01 95 07 00 B4 07 00 B4 07 00 B4 FF 00 17 00 01 07 00 03 00 0D 07 00 03 07 00 03 08 01 95 08 01 95 07 00 B4 07 00 B4 07 00 B4 01 01 01 01 01 05 FF 00 01 00 01 07 00 03 00 0E 07 00 03 07 00 03 08 01 95 08 01 95 07 00 B4 07 00 B4 07 00 B4 01 01 01 01 01 05 01 FF 00 1D 00 01 07 00 03 00 0D 07 00 03 07 00 03 08 01 95 08 01 95 07 00 B4 07 00 B4 07 00 B4 01 01 01 01 01 05 FF 00 10 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 78 FF 00 01 00 01 07 00 03 00 04 07 00 03 07 00 03 07 00 78 01 FF 00 1C 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 78 54 07 00 03 FF 00 01 00 01 07 00 03 00 02 07 00 03 01 5C 07 00 03 FF 00 09 00 01 07 00 03 00 06 07 00 03 07 00 03 08 00 EE 08 00 EE 07 00 B4 07 00 B4 FF 00 01 00 01 07 00 03 00 07 07 00 03 07 00 03 08 01 95 08 01 95 07 00 B4 07 00 B4 07 00 B4 FF 00 01 00 01 06 00 02 06 07 00 B4 FF 00 01 00 01 07 00 03 00 01 07 00 03 01 FF 00 01 00 01 07 00 03 00 0D 07 00 03 07 00 03 08 01 95 08 01 95 07 00 B4 07 00 B4 07 00 B4 01 01 01 01 01 05 41 07 00 03 FF 00 01 00 01 07 00 03 00 05 07 00 03 07 00 03 08 00 6A 08 00 6A 07 00 B4 FF 00 01 00 01 07 00 03 00 02 07 00 03 07 00 7F FF 00 01 00 01 07 00 03 00 06 07 00 03 07 00 03 08 00 6A 08 00 6A 07 00 B4 07 00 B4 FF 00 01 00 01 07 00 03 00 03 07 00 03 07 00 03 07 00 78
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2695)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @NotNull
    public f0k 0() {
        return fez.7Z(this, 1446141680);
    }
    
    @Override
    public void c(final boolean p0, @Nullable final EntityPlayerSP p1, @Nullable final World p2) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          297
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            289
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            281
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_0        
        //    25: iload_1        
        //    26: aload_2        
        //    27: aload_3        
        //    28: goto            32
        //    31: athrow         
        //    32: invokespecial   dev/nuker/pyro/fQ.c:(ZLnet/minecraft/client/entity/EntityPlayerSP;Lnet/minecraft/world/World;)V
        //    35: goto            39
        //    38: athrow         
        //    39: getstatic       dev/nuker/pyro/fc.1:I
        //    42: ifne            50
        //    45: ldc             -1893057203
        //    47: goto            52
        //    50: ldc             1514565276
        //    52: ldc             1193258144
        //    54: ixor           
        //    55: lookupswitch {
        //          -936013331: 50
        //          492421692: 80
        //          default: 268
        //        }
        //    80: aload_2        
        //    81: ifnonnull       89
        //    84: ldc             -2045752833
        //    86: goto            91
        //    89: ldc             -2045752834
        //    91: ldc             -1330397069
        //    93: ixor           
        //    94: tableswitch {
        //          1833374488: 116
        //          1833374489: 117
        //          default: 84
        //        }
        //   116: return         
        //   117: aload_0        
        //   118: iload_1        
        //   119: ifeq            202
        //   122: aload_0        
        //   123: getfield        dev/nuker/pyro/fac.c:Ldev/nuker/pyro/f0k;
        //   126: goto            130
        //   129: athrow         
        //   130: invokevirtual   dev/nuker/pyro/f0k.c:()Ljava/lang/Object;
        //   133: goto            137
        //   136: athrow         
        //   137: checkcast       Ljava/lang/Boolean;
        //   140: goto            144
        //   143: athrow         
        //   144: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   147: goto            151
        //   150: athrow         
        //   151: ifeq            202
        //   154: aload_0        
        //   155: aload_2        
        //   156: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70177_z:F
        //   159: aload_0        
        //   160: getfield        dev/nuker/pyro/fac.c:Ldev/nuker/pyro/f0p;
        //   163: goto            167
        //   166: athrow         
        //   167: invokevirtual   dev/nuker/pyro/f0p.c:()Ljava/lang/Object;
        //   170: goto            174
        //   173: athrow         
        //   174: checkcast       Ljava/lang/Number;
        //   177: goto            181
        //   180: athrow         
        //   181: invokevirtual   java/lang/Number.intValue:()I
        //   184: goto            188
        //   187: athrow         
        //   188: goto            192
        //   191: athrow         
        //   192: invokevirtual   dev/nuker/pyro/fac.c:(FI)F
        //   195: goto            199
        //   198: athrow         
        //   199: goto            216
        //   202: getstatic       kotlin/jvm/internal/FloatCompanionObject.INSTANCE:Lkotlin/jvm/internal/FloatCompanionObject;
        //   205: goto            209
        //   208: athrow         
        //   209: invokevirtual   kotlin/jvm/internal/FloatCompanionObject.getMIN_VALUE:()F
        //   212: goto            216
        //   215: athrow         
        //   216: putfield        dev/nuker/pyro/fac.c:F
        //   219: aload_0        
        //   220: iconst_0       
        //   221: getstatic       dev/nuker/pyro/fc.c:I
        //   224: ifne            232
        //   227: ldc             1262210190
        //   229: goto            234
        //   232: ldc             -399951597
        //   234: ldc             -845200309
        //   236: ixor           
        //   237: lookupswitch {
        //          -2036037435: 270
        //          -999588717: 232
        //          default: 264
        //        }
        //   264: putfield        dev/nuker/pyro/fac.1:I
        //   267: return         
        //   268: aconst_null    
        //   269: athrow         
        //   270: aconst_null    
        //   271: athrow         
        //   272: pop            
        //   273: goto            24
        //   276: pop            
        //   277: aconst_null    
        //   278: goto            272
        //   281: dup            
        //   282: ifnull          272
        //   285: checkcast       Ljava/lang/Throwable;
        //   288: athrow         
        //   289: dup            
        //   290: ifnull          276
        //   293: checkcast       Ljava/lang/Throwable;
        //   296: athrow         
        //   297: aconst_null    
        //   298: athrow         
        //    StackMapTable: 00 33 43 07 00 20 04 FF 00 0B 00 00 00 01 07 00 20 FF 00 03 00 04 07 00 03 01 07 00 E1 07 00 F2 00 00 46 07 00 C2 FF 00 00 00 04 07 00 03 01 07 00 E1 07 00 F2 00 04 07 00 03 01 07 00 E1 07 00 F2 45 07 00 20 00 0A 41 01 1B 03 04 41 01 18 00 4B 07 00 20 FF 00 00 00 04 07 00 03 01 07 00 E1 07 00 F2 00 02 07 00 03 07 00 7F 45 07 00 20 FF 00 00 00 04 07 00 03 01 07 00 E1 07 00 F2 00 02 07 00 03 07 00 F4 FF 00 05 00 00 00 01 07 00 20 FF 00 00 00 04 07 00 03 01 07 00 E1 07 00 F2 00 02 07 00 03 07 00 DB 45 07 00 20 FF 00 00 00 04 07 00 03 01 07 00 E1 07 00 F2 00 02 07 00 03 01 4E 07 00 20 FF 00 00 00 04 07 00 03 01 07 00 E1 07 00 F2 00 04 07 00 03 07 00 03 02 07 00 67 45 07 00 20 FF 00 00 00 04 07 00 03 01 07 00 E1 07 00 F2 00 04 07 00 03 07 00 03 02 07 00 F4 45 07 00 C0 FF 00 00 00 04 07 00 03 01 07 00 E1 07 00 F2 00 04 07 00 03 07 00 03 02 07 00 E7 45 07 00 20 FF 00 00 00 04 07 00 03 01 07 00 E1 07 00 F2 00 04 07 00 03 07 00 03 02 01 42 07 00 20 FF 00 00 00 04 07 00 03 01 07 00 E1 07 00 F2 00 04 07 00 03 07 00 03 02 01 45 07 00 20 FF 00 00 00 04 07 00 03 01 07 00 E1 07 00 F2 00 02 07 00 03 02 42 07 00 03 45 07 00 20 FF 00 00 00 04 07 00 03 01 07 00 E1 07 00 F2 00 02 07 00 03 07 00 A9 45 07 00 20 FF 00 00 00 04 07 00 03 01 07 00 E1 07 00 F2 00 02 07 00 03 02 FF 00 0F 00 04 07 00 03 01 07 00 E1 07 00 F2 00 02 07 00 03 01 FF 00 01 00 04 07 00 03 01 07 00 E1 07 00 F2 00 03 07 00 03 01 01 FF 00 1D 00 04 07 00 03 01 07 00 E1 07 00 F2 00 02 07 00 03 01 03 FF 00 01 00 04 07 00 03 01 07 00 E1 07 00 F2 00 02 07 00 03 01 41 07 00 F6 43 05 44 07 00 F6 47 05 47 07 00 20
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     281    289    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  281    289    281    289    Ljava/lang/ArithmeticException;
        //  297    299    3      8      Any
        //  31     38     38     39     Any
        //  31     38     38     39     Ljava/lang/AssertionError;
        //  32     38     3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  32     38     31     32     Ljava/lang/EnumConstantNotPresentException;
        //  32     38     38     39     Ljava/lang/NegativeArraySizeException;
        //  129    136    136    137    Any
        //  129    136    136    137    Any
        //  129    136    3      8      Any
        //  130    136    129    130    Any
        //  129    136    136    137    Ljava/lang/IllegalArgumentException;
        //  144    150    150    151    Any
        //  144    150    150    151    Any
        //  144    150    3      8      Ljava/lang/IllegalStateException;
        //  144    150    3      8      Any
        //  144    150    3      8      Any
        //  166    173    173    174    Any
        //  166    173    166    167    Ljava/lang/IllegalArgumentException;
        //  166    173    166    167    Any
        //  167    173    166    167    Ljava/lang/UnsupportedOperationException;
        //  166    173    173    174    Ljava/lang/IllegalArgumentException;
        //  180    187    187    188    Any
        //  180    187    3      8      Any
        //  181    187    180    181    Ljava/lang/StringIndexOutOfBoundsException;
        //  180    187    187    188    Any
        //  181    187    187    188    Ljava/lang/EnumConstantNotPresentException;
        //  191    198    198    199    Any
        //  192    198    3      8      Ljava/lang/AssertionError;
        //  191    198    3      8      Ljava/lang/NumberFormatException;
        //  191    198    191    192    Any
        //  191    198    3      8      Ljava/lang/IllegalArgumentException;
        //  208    215    215    216    Any
        //  208    215    215    216    Any
        //  209    215    3      8      Ljava/lang/NumberFormatException;
        //  209    215    215    216    Ljava/util/NoSuchElementException;
        //  209    215    208    209    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:595)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @NotNull
    public f0p 2() {
        return fez.4X(this, 1650951447);
    }
    
    static {
        throw t;
    }
}
