// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import dev.nuker.pyro.security.inject.LauncherEventHide;
import org.jetbrains.annotations.Nullable;
import net.minecraft.client.Minecraft;
import org.jetbrains.annotations.NotNull;

public class f6Q extends fQ
{
    @NotNull
    public f0q c;
    @NotNull
    public f0k c;
    
    @NotNull
    public f0q 0() {
        return fez.5T(this, 1890862632);
    }
    
    public static void c(final f6Q f6Q, final Minecraft c) {
        Object o = null;
        Block_0: {
            break Block_0;
        Label_0039:
            while (true) {
                do {
                    while (true) {
                        break Label_0026;
                        try {
                            o = null;
                            if (fc.1 == 0) {
                                continue Label_0039;
                            }
                            null;
                            f6Q.c = c;
                            return;
                        }
                        catch (NegativeArraySizeException ex) {
                            if (ex != null) {
                                throw ex;
                            }
                            continue;
                        }
                        break;
                    }
                    continue Label_0039;
                } while (o == null);
                break;
            }
        }
        throw (Throwable)o;
    }
    
    static {
        throw t;
    }
    
    public static Minecraft c(final f6Q p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: getstatic       dev/nuker/pyro/fc.0:I
        //     4: ifeq            38
        //     7: pop            
        //     8: aconst_null    
        //     9: goto            30
        //    12: nop            
        //    13: nop            
        //    14: nop            
        //    15: athrow         
        //    16: aload_0        
        //    17: getfield        dev/nuker/pyro/f6Q.c:Lnet/minecraft/client/Minecraft;
        //    20: areturn        
        //    21: pop            
        //    22: goto            16
        //    25: pop            
        //    26: aconst_null    
        //    27: goto            21
        //    30: dup            
        //    31: ifnull          21
        //    34: checkcast       Ljava/lang/Throwable;
        //    37: athrow         
        //    38: dup            
        //    39: ifnull          25
        //    42: checkcast       Ljava/lang/Throwable;
        //    45: athrow         
        //    StackMapTable: 00 06 FF 00 0C 00 00 00 01 07 00 1D FC 00 03 07 00 03 44 07 00 1D 43 05 44 07 00 1D 47 05
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                              
        //  -----  -----  -----  -----  ----------------------------------
        //  0      12     30     38     Any
        //  30     38     30     38     Ljava/util/NoSuchElementException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:543)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @f0g
    @LauncherEventHide
    public void c(@Nullable final f4t p0) {
        public class f6P implements Runnable
        {
            public f6Q c;
            public int c;
            
            @Override
            public void run() {
                // 
                // This method could not be decompiled.
                // 
                // Original Bytecode:
                // 
                //     3: dup            
                //     4: ifnull          784
                //     7: athrow         
                //     8: aconst_null    
                //     9: getstatic       dev/nuker/pyro/fc.c:I
                //    12: ifeq            776
                //    15: pop            
                //    16: aconst_null    
                //    17: goto            768
                //    20: nop            
                //    21: nop            
                //    22: nop            
                //    23: athrow         
                //    24: aload_0        
                //    25: getfield        dev/nuker/pyro/f6P.c:Ldev/nuker/pyro/f6Q;
                //    28: goto            32
                //    31: athrow         
                //    32: invokestatic    dev/nuker/pyro/f6Q.c:(Ldev/nuker/pyro/f6Q;)Lnet/minecraft/client/Minecraft;
                //    35: goto            39
                //    38: athrow         
                //    39: getfield        net/minecraft/client/Minecraft.field_71442_b:Lnet/minecraft/client/multiplayer/PlayerControllerMP;
                //    42: iconst_0       
                //    43: bipush          44
                //    45: iconst_0       
                //    46: getstatic       net/minecraft/inventory/ClickType.PICKUP:Lnet/minecraft/inventory/ClickType;
                //    49: aload_0        
                //    50: getstatic       dev/nuker/pyro/fc.c:I
                //    53: ifne            61
                //    56: ldc             1007248633
                //    58: goto            63
                //    61: ldc             1816899067
                //    63: ldc             1157813842
                //    65: ixor           
                //    66: lookupswitch {
                //          692681641: 92
                //          2030809771: 61
                //          default: 755
                //        }
                //    92: getfield        dev/nuker/pyro/f6P.c:Ldev/nuker/pyro/f6Q;
                //    95: getstatic       dev/nuker/pyro/fc.0:I
                //    98: ifgt            106
                //   101: ldc             -1938973327
                //   103: goto            108
                //   106: ldc             1692882816
                //   108: ldc             -105635156
                //   110: ixor           
                //   111: lookupswitch {
                //          -1618418050: 106
                //          1977204701: 739
                //          default: 136
                //        }
                //   136: goto            140
                //   139: athrow         
                //   140: invokestatic    dev/nuker/pyro/f6Q.c:(Ldev/nuker/pyro/f6Q;)Lnet/minecraft/client/Minecraft;
                //   143: goto            147
                //   146: athrow         
                //   147: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
                //   150: checkcast       Lnet/minecraft/entity/player/EntityPlayer;
                //   153: getstatic       dev/nuker/pyro/fc.0:I
                //   156: ifgt            164
                //   159: ldc             589793813
                //   161: goto            166
                //   164: ldc             -954110527
                //   166: ldc             -126694850
                //   168: ixor           
                //   169: lookupswitch {
                //          -1157033698: 164
                //          -615170005: 751
                //          default: 196
                //        }
                //   196: goto            200
                //   199: athrow         
                //   200: invokevirtual   net/minecraft/client/multiplayer/PlayerControllerMP.func_187098_a:(IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
                //   203: goto            207
                //   206: athrow         
                //   207: pop            
                //   208: aload_0        
                //   209: getstatic       dev/nuker/pyro/fc.c:I
                //   212: ifne            220
                //   215: ldc             173665456
                //   217: goto            222
                //   220: ldc             -133774809
                //   222: ldc             -875181996
                //   224: ixor           
                //   225: lookupswitch {
                //          -1047780124: 743
                //          782473841: 220
                //          default: 252
                //        }
                //   252: getfield        dev/nuker/pyro/f6P.c:Ldev/nuker/pyro/f6Q;
                //   255: goto            259
                //   258: athrow         
                //   259: invokestatic    dev/nuker/pyro/f6Q.c:(Ldev/nuker/pyro/f6Q;)Lnet/minecraft/client/Minecraft;
                //   262: goto            266
                //   265: athrow         
                //   266: getfield        net/minecraft/client/Minecraft.field_71442_b:Lnet/minecraft/client/multiplayer/PlayerControllerMP;
                //   269: iconst_0       
                //   270: getstatic       dev/nuker/pyro/fc.0:I
                //   273: ifgt            281
                //   276: ldc             358420484
                //   278: goto            283
                //   281: ldc             860570865
                //   283: ldc             -1214146357
                //   285: ixor           
                //   286: lookupswitch {
                //          -2064982982: 312
                //          -1560508209: 281
                //          default: 757
                //        }
                //   312: aload_0        
                //   313: getstatic       dev/nuker/pyro/fc.0:I
                //   316: ifgt            324
                //   319: ldc             1205809161
                //   321: goto            326
                //   324: ldc             -1908784826
                //   326: ldc             -1924934577
                //   328: ixor           
                //   329: lookupswitch {
                //          -895687610: 753
                //          673970749: 324
                //          default: 356
                //        }
                //   356: getfield        dev/nuker/pyro/f6P.c:I
                //   359: iconst_0       
                //   360: getstatic       net/minecraft/inventory/ClickType.PICKUP:Lnet/minecraft/inventory/ClickType;
                //   363: getstatic       dev/nuker/pyro/fc.1:I
                //   366: ifne            374
                //   369: ldc             1212926160
                //   371: goto            376
                //   374: ldc             -1624412080
                //   376: ldc             753047838
                //   378: ixor           
                //   379: lookupswitch {
                //          -1278219954: 404
                //          1688818126: 374
                //          default: 737
                //        }
                //   404: aload_0        
                //   405: getstatic       dev/nuker/pyro/fc.1:I
                //   408: ifne            416
                //   411: ldc             -1044354361
                //   413: goto            418
                //   416: ldc             -1416187222
                //   418: ldc             1445085464
                //   420: ixor           
                //   421: lookupswitch {
                //          -1746785313: 416
                //          -38472782: 448
                //          default: 745
                //        }
                //   448: getfield        dev/nuker/pyro/f6P.c:Ldev/nuker/pyro/f6Q;
                //   451: goto            455
                //   454: athrow         
                //   455: invokestatic    dev/nuker/pyro/f6Q.c:(Ldev/nuker/pyro/f6Q;)Lnet/minecraft/client/Minecraft;
                //   458: goto            462
                //   461: athrow         
                //   462: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
                //   465: checkcast       Lnet/minecraft/entity/player/EntityPlayer;
                //   468: goto            472
                //   471: athrow         
                //   472: invokevirtual   net/minecraft/client/multiplayer/PlayerControllerMP.func_187098_a:(IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
                //   475: goto            479
                //   478: athrow         
                //   479: pop            
                //   480: aload_0        
                //   481: getfield        dev/nuker/pyro/f6P.c:Ldev/nuker/pyro/f6Q;
                //   484: goto            488
                //   487: athrow         
                //   488: invokestatic    dev/nuker/pyro/f6Q.c:(Ldev/nuker/pyro/f6Q;)Lnet/minecraft/client/Minecraft;
                //   491: goto            495
                //   494: athrow         
                //   495: dup            
                //   496: pop            
                //   497: goto            501
                //   500: athrow         
                //   501: invokevirtual   net/minecraft/client/Minecraft.func_147114_u:()Lnet/minecraft/client/network/NetHandlerPlayClient;
                //   504: goto            508
                //   507: athrow         
                //   508: dup            
                //   509: ifnonnull       523
                //   512: goto            516
                //   515: athrow         
                //   516: invokestatic    kotlin/jvm/internal/Intrinsics.throwNpe:()V
                //   519: goto            523
                //   522: athrow         
                //   523: new             Lnet/minecraft/network/play/client/CPacketClickWindow;
                //   526: dup            
                //   527: iconst_0       
                //   528: iconst_0       
                //   529: iconst_0       
                //   530: getstatic       net/minecraft/inventory/ClickType.PICKUP:Lnet/minecraft/inventory/ClickType;
                //   533: new             Lnet/minecraft/item/ItemStack;
                //   536: dup            
                //   537: getstatic       dev/nuker/pyro/fc.1:I
                //   540: ifne            548
                //   543: ldc             -930250458
                //   545: goto            550
                //   548: ldc             1913802459
                //   550: ldc             777676492
                //   552: ixor           
                //   553: lookupswitch {
                //          -422058006: 747
                //          1540258208: 548
                //          default: 580
                //        }
                //   580: getstatic       net/minecraft/init/Items.field_190929_cY:Lnet/minecraft/item/Item;
                //   583: iconst_5       
                //   584: goto            588
                //   587: athrow         
                //   588: invokespecial   net/minecraft/item/ItemStack.<init>:(Lnet/minecraft/item/Item;I)V
                //   591: goto            595
                //   594: athrow         
                //   595: sipush          420
                //   598: getstatic       dev/nuker/pyro/fc.c:I
                //   601: ifne            609
                //   604: ldc             2068903980
                //   606: goto            611
                //   609: ldc             -1751663801
                //   611: ldc             1672470730
                //   613: ixor           
                //   614: lookupswitch {
                //          -197633139: 640
                //          419371238: 609
                //          default: 741
                //        }
                //   640: goto            644
                //   643: athrow         
                //   644: invokespecial   net/minecraft/network/play/client/CPacketClickWindow.<init>:(IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/item/ItemStack;S)V
                //   647: goto            651
                //   650: athrow         
                //   651: checkcast       Lnet/minecraft/network/Packet;
                //   654: goto            658
                //   657: athrow         
                //   658: invokevirtual   net/minecraft/client/network/NetHandlerPlayClient.func_147297_a:(Lnet/minecraft/network/Packet;)V
                //   661: goto            665
                //   664: athrow         
                //   665: aload_0        
                //   666: getstatic       dev/nuker/pyro/fc.c:I
                //   669: ifne            677
                //   672: ldc             -1337659352
                //   674: goto            679
                //   677: ldc             -451381129
                //   679: ldc             353712413
                //   681: ixor           
                //   682: lookupswitch {
                //          -1521366731: 677
                //          -267566742: 708
                //          default: 749
                //        }
                //   708: getfield        dev/nuker/pyro/f6P.c:Ldev/nuker/pyro/f6Q;
                //   711: goto            715
                //   714: athrow         
                //   715: invokestatic    dev/nuker/pyro/f6Q.c:(Ldev/nuker/pyro/f6Q;)Lnet/minecraft/client/Minecraft;
                //   718: goto            722
                //   721: athrow         
                //   722: getfield        net/minecraft/client/Minecraft.field_71442_b:Lnet/minecraft/client/multiplayer/PlayerControllerMP;
                //   725: goto            729
                //   728: athrow         
                //   729: invokevirtual   net/minecraft/client/multiplayer/PlayerControllerMP.func_78765_e:()V
                //   732: goto            736
                //   735: athrow         
                //   736: return         
                //   737: aconst_null    
                //   738: athrow         
                //   739: aconst_null    
                //   740: athrow         
                //   741: aconst_null    
                //   742: athrow         
                //   743: aconst_null    
                //   744: athrow         
                //   745: aconst_null    
                //   746: athrow         
                //   747: aconst_null    
                //   748: athrow         
                //   749: aconst_null    
                //   750: athrow         
                //   751: aconst_null    
                //   752: athrow         
                //   753: aconst_null    
                //   754: athrow         
                //   755: aconst_null    
                //   756: athrow         
                //   757: aconst_null    
                //   758: athrow         
                //   759: pop            
                //   760: goto            24
                //   763: pop            
                //   764: aconst_null    
                //   765: goto            759
                //   768: dup            
                //   769: ifnull          759
                //   772: checkcast       Ljava/lang/Throwable;
                //   775: athrow         
                //   776: dup            
                //   777: ifnull          763
                //   780: checkcast       Ljava/lang/Throwable;
                //   783: athrow         
                //   784: aconst_null    
                //   785: athrow         
                //    StackMapTable: 00 6D 43 07 00 30 04 FF 00 0B 00 00 00 01 07 00 30 FC 00 03 07 00 03 46 07 00 30 40 07 00 09 45 07 00 30 40 07 00 37 FF 00 15 00 01 07 00 03 00 06 07 00 55 01 01 01 07 00 3D 07 00 03 FF 00 01 00 01 07 00 03 00 07 07 00 55 01 01 01 07 00 3D 07 00 03 01 FF 00 1C 00 01 07 00 03 00 06 07 00 55 01 01 01 07 00 3D 07 00 03 FF 00 0D 00 01 07 00 03 00 06 07 00 55 01 01 01 07 00 3D 07 00 09 FF 00 01 00 01 07 00 03 00 07 07 00 55 01 01 01 07 00 3D 07 00 09 01 FF 00 1B 00 01 07 00 03 00 06 07 00 55 01 01 01 07 00 3D 07 00 09 42 07 00 30 FF 00 00 00 01 07 00 03 00 06 07 00 55 01 01 01 07 00 3D 07 00 09 45 07 00 30 FF 00 00 00 01 07 00 03 00 06 07 00 55 01 01 01 07 00 3D 07 00 37 FF 00 10 00 01 07 00 03 00 06 07 00 55 01 01 01 07 00 3D 07 00 50 FF 00 01 00 01 07 00 03 00 07 07 00 55 01 01 01 07 00 3D 07 00 50 01 FF 00 1D 00 01 07 00 03 00 06 07 00 55 01 01 01 07 00 3D 07 00 50 42 07 00 30 FF 00 00 00 01 07 00 03 00 06 07 00 55 01 01 01 07 00 3D 07 00 50 45 07 00 30 40 07 00 79 4C 07 00 03 FF 00 01 00 01 07 00 03 00 02 07 00 03 01 5D 07 00 03 45 07 00 30 40 07 00 09 45 07 00 30 40 07 00 37 FF 00 0E 00 01 07 00 03 00 02 07 00 55 01 FF 00 01 00 01 07 00 03 00 03 07 00 55 01 01 FF 00 1C 00 01 07 00 03 00 02 07 00 55 01 FF 00 0B 00 01 07 00 03 00 03 07 00 55 01 07 00 03 FF 00 01 00 01 07 00 03 00 04 07 00 55 01 07 00 03 01 FF 00 1D 00 01 07 00 03 00 03 07 00 55 01 07 00 03 FF 00 11 00 01 07 00 03 00 05 07 00 55 01 01 01 07 00 3D FF 00 01 00 01 07 00 03 00 06 07 00 55 01 01 01 07 00 3D 01 FF 00 1B 00 01 07 00 03 00 05 07 00 55 01 01 01 07 00 3D FF 00 0B 00 01 07 00 03 00 06 07 00 55 01 01 01 07 00 3D 07 00 03 FF 00 01 00 01 07 00 03 00 07 07 00 55 01 01 01 07 00 3D 07 00 03 01 FF 00 1D 00 01 07 00 03 00 06 07 00 55 01 01 01 07 00 3D 07 00 03 45 07 00 30 FF 00 00 00 01 07 00 03 00 06 07 00 55 01 01 01 07 00 3D 07 00 09 45 07 00 30 FF 00 00 00 01 07 00 03 00 06 07 00 55 01 01 01 07 00 3D 07 00 37 48 07 00 30 FF 00 00 00 01 07 00 03 00 06 07 00 55 01 01 01 07 00 3D 07 00 50 45 07 00 30 40 07 00 79 47 07 00 30 40 07 00 09 45 07 00 30 40 07 00 37 44 07 00 24 40 07 00 37 45 07 00 30 40 07 00 90 46 07 00 30 40 07 00 90 45 07 00 30 40 07 00 90 FF 00 18 00 01 07 00 03 00 09 07 00 90 08 02 0B 08 02 0B 01 01 01 07 00 3D 08 02 15 08 02 15 FF 00 01 00 01 07 00 03 00 0A 07 00 90 08 02 0B 08 02 0B 01 01 01 07 00 3D 08 02 15 08 02 15 01 FF 00 1D 00 01 07 00 03 00 09 07 00 90 08 02 0B 08 02 0B 01 01 01 07 00 3D 08 02 15 08 02 15 46 07 00 30 FF 00 00 00 01 07 00 03 00 0B 07 00 90 08 02 0B 08 02 0B 01 01 01 07 00 3D 08 02 15 08 02 15 07 00 9C 01 45 07 00 30 FF 00 00 00 01 07 00 03 00 08 07 00 90 08 02 0B 08 02 0B 01 01 01 07 00 3D 07 00 79 FF 00 0D 00 01 07 00 03 00 09 07 00 90 08 02 0B 08 02 0B 01 01 01 07 00 3D 07 00 79 01 FF 00 01 00 01 07 00 03 00 0A 07 00 90 08 02 0B 08 02 0B 01 01 01 07 00 3D 07 00 79 01 01 FF 00 1C 00 01 07 00 03 00 09 07 00 90 08 02 0B 08 02 0B 01 01 01 07 00 3D 07 00 79 01 42 07 00 30 FF 00 00 00 01 07 00 03 00 09 07 00 90 08 02 0B 08 02 0B 01 01 01 07 00 3D 07 00 79 01 45 07 00 30 FF 00 00 00 01 07 00 03 00 02 07 00 90 07 00 77 45 07 00 20 FF 00 00 00 01 07 00 03 00 02 07 00 90 07 00 8E 45 07 00 30 00 4B 07 00 03 FF 00 01 00 01 07 00 03 00 02 07 00 03 01 5C 07 00 03 FF 00 05 00 00 00 01 07 00 30 FF 00 00 00 01 07 00 03 00 01 07 00 09 45 07 00 30 40 07 00 37 FF 00 05 00 00 00 01 07 00 30 FF 00 00 00 01 07 00 03 00 01 07 00 55 45 07 00 30 00 FF 00 00 00 01 07 00 03 00 05 07 00 55 01 01 01 07 00 3D FF 00 01 00 01 07 00 03 00 06 07 00 55 01 01 01 07 00 3D 07 00 09 FF 00 01 00 01 07 00 03 00 09 07 00 90 08 02 0B 08 02 0B 01 01 01 07 00 3D 07 00 79 01 41 07 00 03 FF 00 01 00 01 07 00 03 00 06 07 00 55 01 01 01 07 00 3D 07 00 03 FF 00 01 00 01 07 00 03 00 09 07 00 90 08 02 0B 08 02 0B 01 01 01 07 00 3D 08 02 15 08 02 15 41 07 00 03 FF 00 01 00 01 07 00 03 00 06 07 00 55 01 01 01 07 00 3D 07 00 50 FF 00 01 00 01 07 00 03 00 03 07 00 55 01 07 00 03 FF 00 01 00 01 07 00 03 00 06 07 00 55 01 01 01 07 00 3D 07 00 03 FF 00 01 00 01 07 00 03 00 02 07 00 55 01 41 07 00 30 43 05 44 07 00 30 47 05 47 07 00 30
                //    Exceptions:
                //  Try           Handler
                //  Start  End    Start  End    Type                                       
                //  -----  -----  -----  -----  -------------------------------------------
                //  8      20     768    776    Any
                //  768    776    768    776    Ljava/lang/NegativeArraySizeException;
                //  784    786    3      8      Any
                //  31     38     38     39     Any
                //  31     38     38     39     Any
                //  31     38     31     32     Any
                //  32     38     31     32     Any
                //  32     38     3      8      Ljava/lang/StringIndexOutOfBoundsException;
                //  139    146    146    147    Any
                //  140    146    139    140    Any
                //  139    146    3      8      Any
                //  139    146    146    147    Ljava/lang/NullPointerException;
                //  139    146    3      8      Any
                //  199    206    206    207    Any
                //  200    206    199    200    Any
                //  200    206    206    207    Ljava/lang/IllegalArgumentException;
                //  199    206    206    207    Any
                //  200    206    206    207    Any
                //  258    265    265    266    Any
                //  259    265    3      8      Any
                //  259    265    258    259    Any
                //  258    265    265    266    Any
                //  258    265    3      8      Ljava/lang/IllegalStateException;
                //  454    461    461    462    Any
                //  454    461    454    455    Ljava/lang/ArrayIndexOutOfBoundsException;
                //  454    461    3      8      Ljava/lang/UnsupportedOperationException;
                //  454    461    454    455    Any
                //  455    461    3      8      Ljava/lang/RuntimeException;
                //  471    478    478    479    Any
                //  472    478    478    479    Ljava/util/ConcurrentModificationException;
                //  471    478    471    472    Any
                //  472    478    478    479    Ljava/lang/IndexOutOfBoundsException;
                //  472    478    3      8      Ljava/lang/IllegalArgumentException;
                //  487    494    494    495    Any
                //  488    494    3      8      Ljava/lang/StringIndexOutOfBoundsException;
                //  488    494    487    488    Ljava/lang/ClassCastException;
                //  488    494    487    488    Any
                //  488    494    494    495    Ljava/lang/AssertionError;
                //  500    507    507    508    Any
                //  501    507    507    508    Ljava/lang/IllegalStateException;
                //  501    507    500    501    Ljava/lang/IndexOutOfBoundsException;
                //  500    507    507    508    Any
                //  500    507    3      8      Any
                //  515    522    522    523    Any
                //  515    522    515    516    Any
                //  516    522    515    516    Any
                //  516    522    522    523    Ljava/lang/IllegalArgumentException;
                //  516    522    522    523    Any
                //  587    594    594    595    Any
                //  587    594    3      8      Ljava/lang/ClassCastException;
                //  587    594    3      8      Ljava/lang/IllegalStateException;
                //  587    594    594    595    Ljava/lang/IllegalArgumentException;
                //  588    594    587    588    Any
                //  643    650    650    651    Any
                //  643    650    650    651    Any
                //  644    650    650    651    Ljava/lang/ClassCastException;
                //  643    650    643    644    Any
                //  644    650    3      8      Any
                //  657    664    664    665    Any
                //  657    664    664    665    Ljava/lang/ArrayIndexOutOfBoundsException;
                //  658    664    657    658    Ljava/lang/ArrayIndexOutOfBoundsException;
                //  657    664    3      8      Ljava/util/ConcurrentModificationException;
                //  657    664    657    658    Ljava/util/ConcurrentModificationException;
                //  715    721    721    722    Any
                //  715    721    721    722    Any
                //  715    721    3      8      Ljava/lang/NullPointerException;
                //  715    721    3      8      Any
                //  715    721    3      8      Any
                //  729    735    735    736    Any
                //  729    735    3      8      Any
                //  729    735    735    736    Ljava/lang/ArithmeticException;
                //  729    735    735    736    Any
                //  729    735    735    736    Any
                // 
                // The error that occurred was:
                // 
                // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
                //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
                //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
                //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
                //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
                //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
                //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
                //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:595)
                //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
                //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
                //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
                //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:670)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
                //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
                //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
                //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
                //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
                //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
                //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
                // 
                throw new IllegalStateException("An error occurred while decompiling this method.");
            }
            
            static {
                throw t;
            }
            
            public f6P(final f6Q c, final int c2) {
                while (true) {
                    int n = 0;
                    Label_0015: {
                        if (fc.0 <= 0) {
                            n = 2012952548;
                            break Label_0015;
                        }
                        n = 940866423;
                    }
                    switch (n ^ 0xED384C05) {
                        case -219417879: {
                            continue;
                        }
                        default: {
                            this.c = c;
                            while (true) {
                                int n2 = 0;
                                Label_0060: {
                                    if (fc.c == 0) {
                                        n2 = -203078430;
                                        break Label_0060;
                                    }
                                    n2 = -355696629;
                                }
                                switch (n2 ^ 0x6A4C0AE) {
                                    case 1685007049: {
                                        continue;
                                    }
                                    default: {
                                        this.c = c2;
                                        return;
                                    }
                                    case -180255668: {
                                        throw null;
                                    }
                                }
                                break;
                            }
                            break;
                        }
                        case -1698464799: {
                            throw null;
                        }
                    }
                    break;
                }
            }
        }
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          2076
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            2068
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            2060
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_0        
        //    25: getfield        dev/nuker/pyro/f6Q.c:Ldev/nuker/pyro/f0q;
        //    28: goto            32
        //    31: athrow         
        //    32: invokevirtual   dev/nuker/pyro/f0q.c:()Z
        //    35: goto            39
        //    38: athrow         
        //    39: ifeq            1990
        //    42: iconst_0       
        //    43: istore_2       
        //    44: bipush          8
        //    46: istore_3       
        //    47: getstatic       dev/nuker/pyro/fc.1:I
        //    50: ifne            58
        //    53: ldc             1105552413
        //    55: goto            60
        //    58: ldc             -1812201771
        //    60: ldc             -130973506
        //    62: ixor           
        //    63: lookupswitch {
        //          -1649433361: 58
        //          -1177230173: 2009
        //          default: 88
        //        }
        //    88: iload_2        
        //    89: iload_3        
        //    90: if_icmpgt       1174
        //    93: getstatic       dev/nuker/pyro/fc.1:I
        //    96: ifne            104
        //    99: ldc             -353924385
        //   101: goto            106
        //   104: ldc             1304632639
        //   106: ldc             863480100
        //   108: ixor           
        //   109: lookupswitch {
        //          -644865029: 104
        //          2125771803: 136
        //          default: 2003
        //        }
        //   136: aload_0        
        //   137: getfield        dev/nuker/pyro/f6Q.c:Lnet/minecraft/client/Minecraft;
        //   140: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   143: getstatic       dev/nuker/pyro/fc.c:I
        //   146: ifne            154
        //   149: ldc             439511417
        //   151: goto            156
        //   154: ldc             -415262108
        //   156: ldc             -1403047274
        //   158: ixor           
        //   159: lookupswitch {
        //          -1234347025: 2027
        //          1867626003: 154
        //          default: 184
        //        }
        //   184: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71071_by:Lnet/minecraft/entity/player/InventoryPlayer;
        //   187: getstatic       dev/nuker/pyro/fc.0:I
        //   190: ifgt            198
        //   193: ldc             -225850107
        //   195: goto            200
        //   198: ldc             -1818553376
        //   200: ldc             -1122423785
        //   202: ixor           
        //   203: lookupswitch {
        //          780287991: 228
        //          1334894866: 198
        //          default: 2023
        //        }
        //   228: iload_2        
        //   229: goto            233
        //   232: athrow         
        //   233: invokevirtual   net/minecraft/entity/player/InventoryPlayer.func_70301_a:(I)Lnet/minecraft/item/ItemStack;
        //   236: goto            240
        //   239: athrow         
        //   240: astore          4
        //   242: getstatic       dev/nuker/pyro/fc.0:I
        //   245: ifgt            253
        //   248: ldc             -2120262348
        //   250: goto            255
        //   253: ldc             -220296207
        //   255: ldc             7882116
        //   257: ixor           
        //   258: lookupswitch {
        //          -2115561296: 2035
        //          984163262: 253
        //          default: 284
        //        }
        //   284: aload           4
        //   286: dup            
        //   287: pop            
        //   288: getstatic       dev/nuker/pyro/fc.c:I
        //   291: ifne            299
        //   294: ldc             813932720
        //   296: goto            301
        //   299: ldc             -1725906911
        //   301: ldc             -163127129
        //   303: ixor           
        //   304: lookupswitch {
        //          -960151529: 299
        //          1868963974: 332
        //          default: 2045
        //        }
        //   332: goto            336
        //   335: athrow         
        //   336: invokevirtual   net/minecraft/item/ItemStack.func_190926_b:()Z
        //   339: goto            343
        //   342: athrow         
        //   343: ifne            1168
        //   346: aload           4
        //   348: goto            352
        //   351: athrow         
        //   352: invokevirtual   net/minecraft/item/ItemStack.func_77973_b:()Lnet/minecraft/item/Item;
        //   355: goto            359
        //   358: athrow         
        //   359: getstatic       net/minecraft/init/Items.field_151079_bi:Lnet/minecraft/item/Item;
        //   362: getstatic       dev/nuker/pyro/fc.0:I
        //   365: ifgt            373
        //   368: ldc             -646993673
        //   370: goto            375
        //   373: ldc             -1980708567
        //   375: ldc             935413574
        //   377: ixor           
        //   378: lookupswitch {
        //          -290525263: 2047
        //          1677823793: 373
        //          default: 404
        //        }
        //   404: goto            408
        //   407: athrow         
        //   408: invokestatic    kotlin/jvm/internal/Intrinsics.areEqual:(Ljava/lang/Object;Ljava/lang/Object;)Z
        //   411: goto            415
        //   414: athrow         
        //   415: ifeq            1168
        //   418: aload_0        
        //   419: getfield        dev/nuker/pyro/f6Q.c:Lnet/minecraft/client/Minecraft;
        //   422: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   425: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71071_by:Lnet/minecraft/entity/player/InventoryPlayer;
        //   428: getstatic       dev/nuker/pyro/fc.c:I
        //   431: ifne            439
        //   434: ldc             280045890
        //   436: goto            441
        //   439: ldc             1694758616
        //   441: ldc             -1459253870
        //   443: ixor           
        //   444: lookupswitch {
        //          -1179343664: 2041
        //          1235096144: 439
        //          default: 472
        //        }
        //   472: getfield        net/minecraft/entity/player/InventoryPlayer.field_70461_c:I
        //   475: iload_2        
        //   476: if_icmpeq       484
        //   479: ldc             -1557932076
        //   481: goto            486
        //   484: ldc             -1557932075
        //   486: ldc             -139843582
        //   488: ixor           
        //   489: tableswitch {
        //          -1458307156: 512
        //          -1458307155: 721
        //          default: 479
        //        }
        //   512: aload_0        
        //   513: getstatic       dev/nuker/pyro/fc.1:I
        //   516: ifne            524
        //   519: ldc             1419522427
        //   521: goto            526
        //   524: ldc             725626690
        //   526: ldc             -948819746
        //   528: ixor           
        //   529: lookupswitch {
        //          -1813112411: 2007
        //          1960021501: 524
        //          default: 556
        //        }
        //   556: getfield        dev/nuker/pyro/f6Q.c:Lnet/minecraft/client/Minecraft;
        //   559: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   562: getstatic       dev/nuker/pyro/fc.c:I
        //   565: ifne            573
        //   568: ldc             1798604871
        //   570: goto            575
        //   573: ldc             824475279
        //   575: ldc             257354398
        //   577: ixor           
        //   578: lookupswitch {
        //          86518670: 573
        //          1684169433: 2037
        //          default: 604
        //        }
        //   604: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71174_a:Lnet/minecraft/client/network/NetHandlerPlayClient;
        //   607: new             Lnet/minecraft/network/play/client/CPacketHeldItemChange;
        //   610: dup            
        //   611: getstatic       dev/nuker/pyro/fc.c:I
        //   614: ifne            622
        //   617: ldc             1026996197
        //   619: goto            624
        //   622: ldc             1921035858
        //   624: ldc             2051894050
        //   626: ixor           
        //   627: lookupswitch {
        //          -977360633: 622
        //          1199299783: 2019
        //          default: 652
        //        }
        //   652: iload_2        
        //   653: getstatic       dev/nuker/pyro/fc.0:I
        //   656: ifgt            664
        //   659: ldc             -668043129
        //   661: goto            666
        //   664: ldc             1388341355
        //   666: ldc             -1280869759
        //   668: ixor           
        //   669: lookupswitch {
        //          -513338646: 696
        //          1804141062: 664
        //          default: 2017
        //        }
        //   696: goto            700
        //   699: athrow         
        //   700: invokespecial   net/minecraft/network/play/client/CPacketHeldItemChange.<init>:(I)V
        //   703: goto            707
        //   706: athrow         
        //   707: checkcast       Lnet/minecraft/network/Packet;
        //   710: goto            714
        //   713: athrow         
        //   714: invokevirtual   net/minecraft/client/network/NetHandlerPlayClient.func_147297_a:(Lnet/minecraft/network/Packet;)V
        //   717: goto            721
        //   720: athrow         
        //   721: aload_0        
        //   722: getfield        dev/nuker/pyro/f6Q.c:Lnet/minecraft/client/Minecraft;
        //   725: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   728: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71174_a:Lnet/minecraft/client/network/NetHandlerPlayClient;
        //   731: new             Lnet/minecraft/network/play/client/CPacketPlayerTryUseItem;
        //   734: dup            
        //   735: getstatic       net/minecraft/util/EnumHand.MAIN_HAND:Lnet/minecraft/util/EnumHand;
        //   738: getstatic       dev/nuker/pyro/fc.0:I
        //   741: ifgt            749
        //   744: ldc             -1733360225
        //   746: goto            751
        //   749: ldc             -1090465706
        //   751: ldc             1071264441
        //   753: ixor           
        //   754: lookupswitch {
        //          -1858352319: 749
        //          -1485490394: 1991
        //          default: 780
        //        }
        //   780: goto            784
        //   783: athrow         
        //   784: invokespecial   net/minecraft/network/play/client/CPacketPlayerTryUseItem.<init>:(Lnet/minecraft/util/EnumHand;)V
        //   787: goto            791
        //   790: athrow         
        //   791: checkcast       Lnet/minecraft/network/Packet;
        //   794: getstatic       dev/nuker/pyro/fc.1:I
        //   797: ifne            805
        //   800: ldc             -2064517262
        //   802: goto            807
        //   805: ldc             71662118
        //   807: ldc             -937841545
        //   809: ixor           
        //   810: lookupswitch {
        //          -866331055: 836
        //          1290296069: 805
        //          default: 2033
        //        }
        //   836: goto            840
        //   839: athrow         
        //   840: invokevirtual   net/minecraft/client/network/NetHandlerPlayClient.func_147297_a:(Lnet/minecraft/network/Packet;)V
        //   843: goto            847
        //   846: athrow         
        //   847: aload_0        
        //   848: getfield        dev/nuker/pyro/f6Q.c:Lnet/minecraft/client/Minecraft;
        //   851: getstatic       dev/nuker/pyro/fc.0:I
        //   854: ifgt            862
        //   857: ldc             -1046886463
        //   859: goto            864
        //   862: ldc             1471105359
        //   864: ldc             -262175435
        //   866: ixor           
        //   867: lookupswitch {
        //          -1477391238: 892
        //          835076852: 862
        //          default: 2005
        //        }
        //   892: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   895: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71071_by:Lnet/minecraft/entity/player/InventoryPlayer;
        //   898: getfield        net/minecraft/entity/player/InventoryPlayer.field_70461_c:I
        //   901: iload_2        
        //   902: if_icmpeq       1167
        //   905: aload_0        
        //   906: getstatic       dev/nuker/pyro/fc.1:I
        //   909: ifne            917
        //   912: ldc             -728156322
        //   914: goto            919
        //   917: ldc             491227072
        //   919: ldc             1108341535
        //   921: ixor           
        //   922: lookupswitch {
        //          -1768504255: 917
        //          1598584031: 948
        //          default: 1999
        //        }
        //   948: getfield        dev/nuker/pyro/f6Q.c:Lnet/minecraft/client/Minecraft;
        //   951: getstatic       dev/nuker/pyro/fc.c:I
        //   954: ifne            962
        //   957: ldc             722273517
        //   959: goto            964
        //   962: ldc             598633444
        //   964: ldc             -1588253758
        //   966: ixor           
        //   967: lookupswitch {
        //          -1973932241: 1995
        //          -1734924872: 962
        //          default: 992
        //        }
        //   992: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   995: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71174_a:Lnet/minecraft/client/network/NetHandlerPlayClient;
        //   998: new             Lnet/minecraft/network/play/client/CPacketHeldItemChange;
        //  1001: dup            
        //  1002: getstatic       dev/nuker/pyro/fc.c:I
        //  1005: ifne            1013
        //  1008: ldc             -1701496989
        //  1010: goto            1015
        //  1013: ldc             900184195
        //  1015: ldc             -158018148
        //  1017: ixor           
        //  1018: lookupswitch {
        //          391974906: 1013
        //          1812062975: 2029
        //          default: 1044
        //        }
        //  1044: aload_0        
        //  1045: getfield        dev/nuker/pyro/f6Q.c:Lnet/minecraft/client/Minecraft;
        //  1048: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1051: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71071_by:Lnet/minecraft/entity/player/InventoryPlayer;
        //  1054: getstatic       dev/nuker/pyro/fc.0:I
        //  1057: ifgt            1065
        //  1060: ldc             -1700586710
        //  1062: goto            1067
        //  1065: ldc             -437586988
        //  1067: ldc             -1538478519
        //  1069: ixor           
        //  1070: lookupswitch {
        //          -314796669: 1065
        //          1055896931: 2043
        //          default: 1096
        //        }
        //  1096: getfield        net/minecraft/entity/player/InventoryPlayer.field_70461_c:I
        //  1099: goto            1103
        //  1102: athrow         
        //  1103: invokespecial   net/minecraft/network/play/client/CPacketHeldItemChange.<init>:(I)V
        //  1106: goto            1110
        //  1109: athrow         
        //  1110: checkcast       Lnet/minecraft/network/Packet;
        //  1113: getstatic       dev/nuker/pyro/fc.0:I
        //  1116: ifgt            1124
        //  1119: ldc             -464194387
        //  1121: goto            1126
        //  1124: ldc             742922327
        //  1126: ldc             -1650400290
        //  1128: ixor           
        //  1129: lookupswitch {
        //          -329725856: 1124
        //          2046039923: 1993
        //          default: 1156
        //        }
        //  1156: goto            1160
        //  1159: athrow         
        //  1160: invokevirtual   net/minecraft/client/network/NetHandlerPlayClient.func_147297_a:(Lnet/minecraft/network/Packet;)V
        //  1163: goto            1167
        //  1166: athrow         
        //  1167: return         
        //  1168: iinc            2, 1
        //  1171: goto            47
        //  1174: aload_0        
        //  1175: getfield        dev/nuker/pyro/f6Q.c:Ldev/nuker/pyro/f0k;
        //  1178: goto            1182
        //  1181: athrow         
        //  1182: invokevirtual   dev/nuker/pyro/f0k.c:()Ljava/lang/Object;
        //  1185: goto            1189
        //  1188: athrow         
        //  1189: checkcast       Ljava/lang/Boolean;
        //  1192: goto            1196
        //  1195: athrow         
        //  1196: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //  1199: goto            1203
        //  1202: athrow         
        //  1203: ifeq            1211
        //  1206: ldc             -1441580223
        //  1208: goto            1213
        //  1211: ldc             -1441580224
        //  1213: ldc             1212018679
        //  1215: ixor           
        //  1216: tableswitch {
        //          -1000494740: 1240
        //          -1000494739: 1990
        //          default: 1206
        //        }
        //  1240: getstatic       dev/nuker/pyro/fc.1:I
        //  1243: ifne            1251
        //  1246: ldc             1856403733
        //  1248: goto            1253
        //  1251: ldc             1255921519
        //  1253: ldc             1325090407
        //  1255: ixor           
        //  1256: lookupswitch {
        //          326506883: 1251
        //          542982002: 2001
        //          default: 1284
        //        }
        //  1284: getstatic       dev/nuker/pyro/fdX.c:Ldev/nuker/pyro/fdX;
        //  1287: getstatic       net/minecraft/init/Items.field_151079_bi:Lnet/minecraft/item/Item;
        //  1290: dup            
        //  1291: pop            
        //  1292: goto            1296
        //  1295: athrow         
        //  1296: invokevirtual   dev/nuker/pyro/fdX.0:(Lnet/minecraft/item/Item;)I
        //  1299: goto            1303
        //  1302: athrow         
        //  1303: istore_2       
        //  1304: getstatic       dev/nuker/pyro/fc.c:I
        //  1307: ifne            1315
        //  1310: ldc             891134434
        //  1312: goto            1317
        //  1315: ldc             -1978348159
        //  1317: ldc             965187355
        //  1319: ixor           
        //  1320: lookupswitch {
        //          -1096475821: 1315
        //          211433209: 2049
        //          default: 1348
        //        }
        //  1348: iload_2        
        //  1349: iconst_m1      
        //  1350: if_icmpeq       1990
        //  1353: aload_0        
        //  1354: getfield        dev/nuker/pyro/f6Q.c:Lnet/minecraft/client/Minecraft;
        //  1357: getfield        net/minecraft/client/Minecraft.field_71442_b:Lnet/minecraft/client/multiplayer/PlayerControllerMP;
        //  1360: iconst_0       
        //  1361: getstatic       dev/nuker/pyro/fc.c:I
        //  1364: ifne            1372
        //  1367: ldc             -354382718
        //  1369: goto            1374
        //  1372: ldc             1525041242
        //  1374: ldc             562301667
        //  1376: ixor           
        //  1377: lookupswitch {
        //          -882604447: 1372
        //          2070037177: 1404
        //          default: 2013
        //        }
        //  1404: iload_2        
        //  1405: iconst_0       
        //  1406: getstatic       net/minecraft/inventory/ClickType.PICKUP:Lnet/minecraft/inventory/ClickType;
        //  1409: aload_0        
        //  1410: getfield        dev/nuker/pyro/f6Q.c:Lnet/minecraft/client/Minecraft;
        //  1413: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1416: checkcast       Lnet/minecraft/entity/player/EntityPlayer;
        //  1419: goto            1423
        //  1422: athrow         
        //  1423: invokevirtual   net/minecraft/client/multiplayer/PlayerControllerMP.func_187098_a:(IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
        //  1426: goto            1430
        //  1429: athrow         
        //  1430: pop            
        //  1431: aload_0        
        //  1432: getfield        dev/nuker/pyro/f6Q.c:Lnet/minecraft/client/Minecraft;
        //  1435: getfield        net/minecraft/client/Minecraft.field_71442_b:Lnet/minecraft/client/multiplayer/PlayerControllerMP;
        //  1438: iconst_0       
        //  1439: bipush          44
        //  1441: iconst_0       
        //  1442: getstatic       net/minecraft/inventory/ClickType.PICKUP:Lnet/minecraft/inventory/ClickType;
        //  1445: aload_0        
        //  1446: getstatic       dev/nuker/pyro/fc.1:I
        //  1449: ifne            1458
        //  1452: ldc_w           808753892
        //  1455: goto            1461
        //  1458: ldc_w           524576304
        //  1461: ldc_w           -656254767
        //  1464: ixor           
        //  1465: lookupswitch {
        //          -945406239: 1492
        //          -388578763: 1458
        //          default: 2011
        //        }
        //  1492: getfield        dev/nuker/pyro/f6Q.c:Lnet/minecraft/client/Minecraft;
        //  1495: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1498: checkcast       Lnet/minecraft/entity/player/EntityPlayer;
        //  1501: getstatic       dev/nuker/pyro/fc.0:I
        //  1504: ifgt            1513
        //  1507: ldc_w           1570120607
        //  1510: goto            1516
        //  1513: ldc_w           -1657641619
        //  1516: ldc_w           -1278463900
        //  1519: ixor           
        //  1520: lookupswitch {
        //          -296086533: 1513
        //          788419849: 1548
        //          default: 1997
        //        }
        //  1548: goto            1552
        //  1551: athrow         
        //  1552: invokevirtual   net/minecraft/client/multiplayer/PlayerControllerMP.func_187098_a:(IIILnet/minecraft/inventory/ClickType;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/item/ItemStack;
        //  1555: goto            1559
        //  1558: athrow         
        //  1559: pop            
        //  1560: getstatic       dev/nuker/pyro/fc.0:I
        //  1563: ifgt            1572
        //  1566: ldc_w           -1105693929
        //  1569: goto            1575
        //  1572: ldc_w           -818014565
        //  1575: ldc_w           -900022190
        //  1578: ixor           
        //  1579: lookupswitch {
        //          956733044: 1572
        //          1950528325: 2031
        //          default: 1604
        //        }
        //  1604: aload_0        
        //  1605: getfield        dev/nuker/pyro/f6Q.c:Lnet/minecraft/client/Minecraft;
        //  1608: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1611: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71071_by:Lnet/minecraft/entity/player/InventoryPlayer;
        //  1614: getfield        net/minecraft/entity/player/InventoryPlayer.field_70461_c:I
        //  1617: istore_3       
        //  1618: iload_3        
        //  1619: bipush          8
        //  1621: if_icmpeq       1630
        //  1624: ldc_w           827301723
        //  1627: goto            1633
        //  1630: ldc_w           827301700
        //  1633: ldc_w           14737236
        //  1636: ixor           
        //  1637: tableswitch {
        //          1667137566: 1660
        //          1667137567: 1675
        //          default: 1624
        //        }
        //  1660: aload_0        
        //  1661: getfield        dev/nuker/pyro/f6Q.c:Lnet/minecraft/client/Minecraft;
        //  1664: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1667: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71071_by:Lnet/minecraft/entity/player/InventoryPlayer;
        //  1670: bipush          8
        //  1672: putfield        net/minecraft/entity/player/InventoryPlayer.field_70461_c:I
        //  1675: aload_0        
        //  1676: getfield        dev/nuker/pyro/f6Q.c:Lnet/minecraft/client/Minecraft;
        //  1679: getstatic       dev/nuker/pyro/fc.1:I
        //  1682: ifne            1691
        //  1685: ldc_w           -124125283
        //  1688: goto            1694
        //  1691: ldc_w           -80991779
        //  1694: ldc_w           -2007936267
        //  1697: ixor           
        //  1698: lookupswitch {
        //          1598578315: 1691
        //          1892199784: 2021
        //          default: 1724
        //        }
        //  1724: getfield        net/minecraft/client/Minecraft.field_71442_b:Lnet/minecraft/client/multiplayer/PlayerControllerMP;
        //  1727: aload_0        
        //  1728: getfield        dev/nuker/pyro/f6Q.c:Lnet/minecraft/client/Minecraft;
        //  1731: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1734: checkcast       Lnet/minecraft/entity/player/EntityPlayer;
        //  1737: aload_0        
        //  1738: getfield        dev/nuker/pyro/f6Q.c:Lnet/minecraft/client/Minecraft;
        //  1741: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //  1744: checkcast       Lnet/minecraft/world/World;
        //  1747: getstatic       dev/nuker/pyro/fc.0:I
        //  1750: ifgt            1759
        //  1753: ldc_w           1708229332
        //  1756: goto            1762
        //  1759: ldc_w           1367437704
        //  1762: ldc_w           -325820966
        //  1765: ixor           
        //  1766: lookupswitch {
        //          -1991909618: 2015
        //          -1876377138: 1759
        //          default: 1792
        //        }
        //  1792: getstatic       net/minecraft/util/EnumHand.MAIN_HAND:Lnet/minecraft/util/EnumHand;
        //  1795: goto            1799
        //  1798: athrow         
        //  1799: invokevirtual   net/minecraft/client/multiplayer/PlayerControllerMP.func_187101_a:(Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/EnumHand;)Lnet/minecraft/util/EnumActionResult;
        //  1802: goto            1806
        //  1805: athrow         
        //  1806: pop            
        //  1807: iload_3        
        //  1808: bipush          8
        //  1810: if_icmpeq       1819
        //  1813: ldc_w           -1744491700
        //  1816: goto            1822
        //  1819: ldc_w           -1744491699
        //  1822: ldc_w           -769058944
        //  1825: ixor           
        //  1826: tableswitch {
        //          -1806141032: 1848
        //          -1806141031: 1954
        //          default: 1813
        //        }
        //  1848: aload_0        
        //  1849: getstatic       dev/nuker/pyro/fc.1:I
        //  1852: ifne            1861
        //  1855: ldc_w           691179565
        //  1858: goto            1864
        //  1861: ldc_w           2019011083
        //  1864: ldc_w           -1093383035
        //  1867: ixor           
        //  1868: lookupswitch {
        //          -1746477912: 1861
        //          -964434290: 1896
        //          default: 2039
        //        }
        //  1896: getfield        dev/nuker/pyro/f6Q.c:Lnet/minecraft/client/Minecraft;
        //  1899: getstatic       dev/nuker/pyro/fc.0:I
        //  1902: ifgt            1911
        //  1905: ldc_w           -1927621408
        //  1908: goto            1914
        //  1911: ldc_w           -1649807250
        //  1914: ldc_w           1579307867
        //  1917: ixor           
        //  1918: lookupswitch {
        //          -1014258891: 1944
        //          -751269957: 1911
        //          default: 2025
        //        }
        //  1944: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1947: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71071_by:Lnet/minecraft/entity/player/InventoryPlayer;
        //  1950: iload_3        
        //  1951: putfield        net/minecraft/entity/player/InventoryPlayer.field_70461_c:I
        //  1954: aload_0        
        //  1955: getfield        dev/nuker/pyro/f6Q.c:Lnet/minecraft/client/Minecraft;
        //  1958: new             Ldev/nuker/pyro/f6P;
        //  1961: dup            
        //  1962: aload_0        
        //  1963: iload_2        
        //  1964: goto            1968
        //  1967: athrow         
        //  1968: invokespecial   dev/nuker/pyro/f6P.<init>:(Ldev/nuker/pyro/f6Q;I)V
        //  1971: goto            1975
        //  1974: athrow         
        //  1975: checkcast       Ljava/lang/Runnable;
        //  1978: goto            1982
        //  1981: athrow         
        //  1982: invokevirtual   net/minecraft/client/Minecraft.func_152344_a:(Ljava/lang/Runnable;)Lcom/google/common/util/concurrent/ListenableFuture;
        //  1985: goto            1989
        //  1988: athrow         
        //  1989: pop            
        //  1990: return         
        //  1991: aconst_null    
        //  1992: athrow         
        //  1993: aconst_null    
        //  1994: athrow         
        //  1995: aconst_null    
        //  1996: athrow         
        //  1997: aconst_null    
        //  1998: athrow         
        //  1999: aconst_null    
        //  2000: athrow         
        //  2001: aconst_null    
        //  2002: athrow         
        //  2003: aconst_null    
        //  2004: athrow         
        //  2005: aconst_null    
        //  2006: athrow         
        //  2007: aconst_null    
        //  2008: athrow         
        //  2009: aconst_null    
        //  2010: athrow         
        //  2011: aconst_null    
        //  2012: athrow         
        //  2013: aconst_null    
        //  2014: athrow         
        //  2015: aconst_null    
        //  2016: athrow         
        //  2017: aconst_null    
        //  2018: athrow         
        //  2019: aconst_null    
        //  2020: athrow         
        //  2021: aconst_null    
        //  2022: athrow         
        //  2023: aconst_null    
        //  2024: athrow         
        //  2025: aconst_null    
        //  2026: athrow         
        //  2027: aconst_null    
        //  2028: athrow         
        //  2029: aconst_null    
        //  2030: athrow         
        //  2031: aconst_null    
        //  2032: athrow         
        //  2033: aconst_null    
        //  2034: athrow         
        //  2035: aconst_null    
        //  2036: athrow         
        //  2037: aconst_null    
        //  2038: athrow         
        //  2039: aconst_null    
        //  2040: athrow         
        //  2041: aconst_null    
        //  2042: athrow         
        //  2043: aconst_null    
        //  2044: athrow         
        //  2045: aconst_null    
        //  2046: athrow         
        //  2047: aconst_null    
        //  2048: athrow         
        //  2049: aconst_null    
        //  2050: athrow         
        //  2051: pop            
        //  2052: goto            24
        //  2055: pop            
        //  2056: aconst_null    
        //  2057: goto            2051
        //  2060: dup            
        //  2061: ifnull          2051
        //  2064: checkcast       Ljava/lang/Throwable;
        //  2067: athrow         
        //  2068: dup            
        //  2069: ifnull          2055
        //  2072: checkcast       Ljava/lang/Throwable;
        //  2075: athrow         
        //  2076: aconst_null    
        //  2077: athrow         
        //    StackMapTable: 00 E3 43 07 00 1D 04 FF 00 0B 00 00 00 01 07 00 1D FD 00 03 07 00 03 07 01 36 46 07 00 1D 40 07 00 49 45 07 00 1D 40 01 FD 00 07 01 01 0A 41 01 1B 0F 41 01 1D 51 07 00 5D FF 00 01 00 04 07 00 03 07 01 36 01 01 00 02 07 00 5D 01 5B 07 00 5D 4D 07 00 66 FF 00 01 00 04 07 00 03 07 01 36 01 01 00 02 07 00 66 01 5B 07 00 66 43 07 00 35 FF 00 00 00 04 07 00 03 07 01 36 01 01 00 02 07 00 66 01 45 07 00 1D 40 07 00 72 FC 00 0C 07 00 72 41 01 1C 4E 07 00 72 FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 00 72 01 5E 07 00 72 42 07 00 37 40 07 00 72 45 07 00 1D 40 01 47 07 00 1D 40 07 00 72 45 07 00 1D 40 07 01 38 FF 00 0D 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 01 38 07 01 38 FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 03 07 01 38 07 01 38 01 FF 00 1C 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 01 38 07 01 38 FF 00 02 00 00 00 01 07 00 1D FF 00 00 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 01 38 07 01 38 45 07 00 1D 40 01 57 07 00 66 FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 00 66 01 5E 07 00 66 06 04 41 01 19 4B 07 00 03 FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 00 03 01 5D 07 00 03 50 07 00 5D FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 00 5D 01 5C 07 00 5D FF 00 11 00 05 07 00 03 07 01 36 01 01 07 00 72 00 03 07 00 AB 08 02 5F 08 02 5F FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 04 07 00 AB 08 02 5F 08 02 5F 01 FF 00 1B 00 05 07 00 03 07 01 36 01 01 07 00 72 00 03 07 00 AB 08 02 5F 08 02 5F FF 00 0B 00 05 07 00 03 07 01 36 01 01 07 00 72 00 04 07 00 AB 08 02 5F 08 02 5F 01 FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 05 07 00 AB 08 02 5F 08 02 5F 01 01 FF 00 1D 00 05 07 00 03 07 01 36 01 01 07 00 72 00 04 07 00 AB 08 02 5F 08 02 5F 01 42 07 00 3B FF 00 00 00 05 07 00 03 07 01 36 01 01 07 00 72 00 04 07 00 AB 08 02 5F 08 02 5F 01 45 07 00 1D FF 00 00 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 00 AB 07 00 9D 45 07 00 1D FF 00 00 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 00 AB 07 00 A9 45 07 00 1D 00 FF 00 1B 00 05 07 00 03 07 01 36 01 01 07 00 72 00 04 07 00 AB 08 02 DB 08 02 DB 07 00 B3 FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 05 07 00 AB 08 02 DB 08 02 DB 07 00 B3 01 FF 00 1C 00 05 07 00 03 07 01 36 01 01 07 00 72 00 04 07 00 AB 08 02 DB 08 02 DB 07 00 B3 42 07 00 2F FF 00 00 00 05 07 00 03 07 01 36 01 01 07 00 72 00 04 07 00 AB 08 02 DB 08 02 DB 07 00 B3 45 07 00 1D FF 00 00 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 00 AB 07 00 B1 FF 00 0D 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 00 AB 07 00 A9 FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 03 07 00 AB 07 00 A9 01 FF 00 1C 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 00 AB 07 00 A9 42 07 00 3D FF 00 00 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 00 AB 07 00 A9 45 07 00 1D 00 4E 07 00 22 FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 00 22 01 5B 07 00 22 58 07 00 03 FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 00 03 01 5C 07 00 03 4D 07 00 22 FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 00 22 01 5B 07 00 22 FF 00 14 00 05 07 00 03 07 01 36 01 01 07 00 72 00 03 07 00 AB 08 03 E6 08 03 E6 FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 04 07 00 AB 08 03 E6 08 03 E6 01 FF 00 1C 00 05 07 00 03 07 01 36 01 01 07 00 72 00 03 07 00 AB 08 03 E6 08 03 E6 FF 00 14 00 05 07 00 03 07 01 36 01 01 07 00 72 00 04 07 00 AB 08 03 E6 08 03 E6 07 00 66 FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 05 07 00 AB 08 03 E6 08 03 E6 07 00 66 01 FF 00 1C 00 05 07 00 03 07 01 36 01 01 07 00 72 00 04 07 00 AB 08 03 E6 08 03 E6 07 00 66 45 07 00 43 FF 00 00 00 05 07 00 03 07 01 36 01 01 07 00 72 00 04 07 00 AB 08 03 E6 08 03 E6 01 45 07 00 1D FF 00 00 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 00 AB 07 00 9D FF 00 0D 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 00 AB 07 00 A9 FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 03 07 00 AB 07 00 A9 01 FF 00 1D 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 00 AB 07 00 A9 42 07 00 1D FF 00 00 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 00 AB 07 00 A9 45 07 00 1D 00 00 FA 00 05 46 07 00 1D 40 07 00 D6 45 07 00 1D 40 07 01 3A 45 07 00 1D 40 07 00 DB 45 07 00 1D 40 01 02 04 41 01 1A 0A 41 01 1E 4A 07 00 41 FF 00 00 00 04 07 00 03 07 01 36 01 01 00 02 07 00 E6 07 01 38 45 07 00 1D 40 01 0B 41 01 1E FF 00 17 00 04 07 00 03 07 01 36 01 01 00 02 07 01 00 01 FF 00 01 00 04 07 00 03 07 01 36 01 01 00 03 07 01 00 01 01 FF 00 1D 00 04 07 00 03 07 01 36 01 01 00 02 07 01 00 01 51 07 00 1D FF 00 00 00 04 07 00 03 07 01 36 01 01 00 06 07 01 00 01 01 01 07 00 F8 07 00 FE 45 07 00 1D 40 07 00 72 FF 00 1B 00 04 07 00 03 07 01 36 01 01 00 06 07 01 00 01 01 01 07 00 F8 07 00 03 FF 00 02 00 04 07 00 03 07 01 36 01 01 00 07 07 01 00 01 01 01 07 00 F8 07 00 03 01 FF 00 1E 00 04 07 00 03 07 01 36 01 01 00 06 07 01 00 01 01 01 07 00 F8 07 00 03 FF 00 14 00 04 07 00 03 07 01 36 01 01 00 06 07 01 00 01 01 01 07 00 F8 07 00 FE FF 00 02 00 04 07 00 03 07 01 36 01 01 00 07 07 01 00 01 01 01 07 00 F8 07 00 FE 01 FF 00 1F 00 04 07 00 03 07 01 36 01 01 00 06 07 01 00 01 01 01 07 00 F8 07 00 FE FF 00 02 00 00 00 01 07 00 1D FF 00 00 00 04 07 00 03 07 01 36 01 01 00 06 07 01 00 01 01 01 07 00 F8 07 00 FE 45 07 00 1D 40 07 00 72 0C 42 01 1C 13 05 42 01 1A 0E 4F 07 00 22 FF 00 02 00 04 07 00 03 07 01 36 01 01 00 02 07 00 22 01 5D 07 00 22 FF 00 22 00 04 07 00 03 07 01 36 01 01 00 03 07 01 00 07 00 FE 07 01 19 FF 00 02 00 04 07 00 03 07 01 36 01 01 00 04 07 01 00 07 00 FE 07 01 19 01 FF 00 1D 00 04 07 00 03 07 01 36 01 01 00 03 07 01 00 07 00 FE 07 01 19 45 07 00 1D FF 00 00 00 04 07 00 03 07 01 36 01 01 00 04 07 01 00 07 00 FE 07 01 19 07 00 B3 45 07 00 1D 40 07 01 3C 06 05 42 01 19 4C 07 00 03 FF 00 02 00 04 07 00 03 07 01 36 01 01 00 02 07 00 03 01 5F 07 00 03 4E 07 00 22 FF 00 02 00 04 07 00 03 07 01 36 01 01 00 02 07 00 22 01 5D 07 00 22 09 4C 07 00 1D FF 00 00 00 04 07 00 03 07 01 36 01 01 00 05 07 00 22 08 07 A6 08 07 A6 07 00 03 01 45 07 00 1D FF 00 00 00 04 07 00 03 07 01 36 01 01 00 02 07 00 22 07 01 2B 45 07 00 1D FF 00 00 00 04 07 00 03 07 01 36 01 01 00 02 07 00 22 07 01 30 45 07 00 1D 40 07 01 3E F9 00 00 FF 00 00 00 05 07 00 03 07 01 36 01 01 07 00 72 00 04 07 00 AB 08 02 DB 08 02 DB 07 00 B3 FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 00 AB 07 00 A9 41 07 00 22 FF 00 01 00 04 07 00 03 07 01 36 01 01 00 06 07 01 00 01 01 01 07 00 F8 07 00 FE FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 01 07 00 03 FA 00 01 01 FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 01 07 00 22 41 07 00 03 FA 00 01 FF 00 01 00 04 07 00 03 07 01 36 01 01 00 06 07 01 00 01 01 01 07 00 F8 07 00 03 FF 00 01 00 04 07 00 03 07 01 36 01 01 00 02 07 01 00 01 FF 00 01 00 04 07 00 03 07 01 36 01 01 00 03 07 01 00 07 00 FE 07 01 19 FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 04 07 00 AB 08 02 5F 08 02 5F 01 FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 03 07 00 AB 08 02 5F 08 02 5F FF 00 01 00 04 07 00 03 07 01 36 01 01 00 01 07 00 22 41 07 00 66 41 07 00 22 41 07 00 5D FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 03 07 00 AB 08 03 E6 08 03 E6 FA 00 01 FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 00 AB 07 00 A9 01 41 07 00 5D FF 00 01 00 04 07 00 03 07 01 36 01 01 00 01 07 00 03 FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 01 07 00 66 FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 04 07 00 AB 08 03 E6 08 03 E6 07 00 66 41 07 00 72 FF 00 01 00 05 07 00 03 07 01 36 01 01 07 00 72 00 02 07 01 38 07 01 38 FA 00 01 FF 00 01 00 02 07 00 03 07 01 36 00 01 07 00 1D 43 05 44 07 00 1D 47 05 47 07 00 1D
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     2060   2068   Any
        //  2060   2068   2060   2068   Any
        //  2076   2078   3      8      Ljava/lang/IndexOutOfBoundsException;
        //  31     38     38     39     Any
        //  32     38     38     39     Any
        //  32     38     31     32     Any
        //  32     38     3      8      Any
        //  31     38     3      8      Ljava/lang/EnumConstantNotPresentException;
        //  232    239    239    240    Any
        //  232    239    239    240    Any
        //  232    239    3      8      Ljava/util/ConcurrentModificationException;
        //  232    239    232    233    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  233    239    3      8      Any
        //  335    342    342    343    Any
        //  336    342    335    336    Ljava/lang/UnsupportedOperationException;
        //  336    342    3      8      Any
        //  335    342    3      8      Ljava/util/NoSuchElementException;
        //  335    342    342    343    Any
        //  351    358    358    359    Any
        //  351    358    358    359    Ljava/lang/NegativeArraySizeException;
        //  351    358    3      8      Any
        //  351    358    358    359    Any
        //  352    358    351    352    Any
        //  408    414    414    415    Any
        //  408    414    414    415    Any
        //  408    414    3      8      Any
        //  408    414    414    415    Any
        //  408    414    3      8      Ljava/lang/IllegalStateException;
        //  699    706    706    707    Any
        //  700    706    706    707    Any
        //  699    706    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  700    706    3      8      Ljava/lang/UnsupportedOperationException;
        //  699    706    699    700    Ljava/lang/RuntimeException;
        //  713    720    720    721    Any
        //  713    720    720    721    Ljava/lang/EnumConstantNotPresentException;
        //  714    720    3      8      Ljava/lang/NullPointerException;
        //  713    720    713    714    Any
        //  714    720    720    721    Ljava/lang/NegativeArraySizeException;
        //  783    790    790    791    Any
        //  783    790    790    791    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  783    790    3      8      Any
        //  784    790    783    784    Ljava/lang/IndexOutOfBoundsException;
        //  783    790    790    791    Ljava/lang/StringIndexOutOfBoundsException;
        //  839    846    846    847    Any
        //  839    846    839    840    Ljava/lang/NullPointerException;
        //  840    846    3      8      Ljava/lang/AssertionError;
        //  840    846    846    847    Ljava/lang/NegativeArraySizeException;
        //  839    846    846    847    Any
        //  1102   1109   1109   1110   Any
        //  1103   1109   1109   1110   Any
        //  1102   1109   1109   1110   Any
        //  1102   1109   3      8      Any
        //  1103   1109   1102   1103   Ljava/lang/IllegalArgumentException;
        //  1159   1166   1166   1167   Any
        //  1160   1166   1159   1160   Any
        //  1159   1166   1159   1160   Ljava/lang/IllegalStateException;
        //  1160   1166   3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1159   1166   3      8      Ljava/util/NoSuchElementException;
        //  1181   1188   1188   1189   Any
        //  1181   1188   3      8      Any
        //  1181   1188   3      8      Ljava/lang/ClassCastException;
        //  1181   1188   1181   1182   Any
        //  1181   1188   3      8      Ljava/lang/NullPointerException;
        //  1195   1202   1202   1203   Any
        //  1196   1202   3      8      Ljava/lang/IllegalArgumentException;
        //  1196   1202   3      8      Ljava/lang/ClassCastException;
        //  1195   1202   1195   1196   Ljava/lang/ClassCastException;
        //  1195   1202   1195   1196   Any
        //  1295   1302   1302   1303   Any
        //  1295   1302   1302   1303   Ljava/lang/EnumConstantNotPresentException;
        //  1295   1302   1295   1296   Ljava/lang/AssertionError;
        //  1295   1302   3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  1296   1302   1302   1303   Ljava/lang/RuntimeException;
        //  1422   1429   1429   1430   Any
        //  1423   1429   1422   1423   Any
        //  1422   1429   1429   1430   Ljava/lang/RuntimeException;
        //  1423   1429   1429   1430   Ljava/lang/StringIndexOutOfBoundsException;
        //  1422   1429   1429   1430   Ljava/lang/NegativeArraySizeException;
        //  1552   1558   1558   1559   Any
        //  1552   1558   3      8      Any
        //  1552   1558   1558   1559   Ljava/util/NoSuchElementException;
        //  1552   1558   3      8      Ljava/lang/RuntimeException;
        //  1552   1558   3      8      Any
        //  1798   1805   1805   1806   Any
        //  1799   1805   1805   1806   Ljava/lang/NullPointerException;
        //  1799   1805   3      8      Any
        //  1799   1805   3      8      Any
        //  1798   1805   1798   1799   Any
        //  1967   1974   1974   1975   Any
        //  1967   1974   1967   1968   Any
        //  1968   1974   1974   1975   Any
        //  1967   1974   1974   1975   Ljava/util/ConcurrentModificationException;
        //  1967   1974   3      8      Any
        //  1981   1988   1988   1989   Any
        //  1981   1988   1981   1982   Ljava/lang/NegativeArraySizeException;
        //  1982   1988   1981   1982   Any
        //  1981   1988   1988   1989   Ljava/lang/IllegalArgumentException;
        //  1981   1988   1988   1989   Ljava/util/ConcurrentModificationException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:577)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public f6Q() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: ldc_w           "\u3d49\ub240\u8e09\uad94\u6774\u59a6\u7e52\u690b"
        //     4: invokestatic    invokestatic   !!! ERROR
        //     7: ldc_w           "\u3d69\ub240\u8e09\uad94\u6774\u59a6\u7e52\u690b"
        //    10: getstatic       dev/nuker/pyro/fc.1:I
        //    13: ifne            22
        //    16: ldc_w           -850670814
        //    19: goto            25
        //    22: ldc_w           1960073224
        //    25: ldc_w           781722661
        //    28: ixor           
        //    29: lookupswitch {
        //          -472649977: 421
        //          993836082: 22
        //          default: 56
        //        }
        //    56: invokestatic    invokestatic   !!! ERROR
        //    59: ldc_w           "\u3d63\ub249\u8e1c\uadab\u6766\u59b4\u7e00\u691e\uc2cc\ua382\u9bbb\u1310\uc169\u714e\u90a1\u4dba\ub205\u4c83\u014f\u0743\u12a3\ufecd\u6ad3\u8855\u365e\u3d24\u7fe2\ua938\ud1f4\u7245\u447e\u6ba1\u7401\u9738\uc7ab\u4360\ufdfc\u1093\u1847\u4ad1\u6609\uac42\u8d20\uf934\ubc95\ua430\u4c62\u3f17\u4a2c\ua201\u784d\u916a\u334e\u6fda\uf6a2\u0eb9\u7a52\u0ab8\u9f70\ud3ed\ue78d\u4c7f\u485b\u16d1\u31c4\u5187\u7986\ue7f4\u5feb\u8bb0\ueb92\u1dd1\uf2f6\ub63d\uc03e\u1769\u2aee\u6653\u4408\u7c74\uca34\u1722\u2b19\u8fd2\ud029\u3848\u9bdb\u83fe\uc8c9\ucdf6\uafa6\ueb0c\ub82c\u1336\u40b2\uef42\u908c\u4a70\ua7c7\u3aad\uf37b"
        //    62: invokestatic    invokestatic   !!! ERROR
        //    65: getstatic       dev/nuker/pyro/fc.c:I
        //    68: ifne            77
        //    71: ldc_w           -240666695
        //    74: goto            80
        //    77: ldc_w           -1770141172
        //    80: ldc_w           -1785403111
        //    83: ixor           
        //    84: lookupswitch {
        //          65610517: 112
        //          1681088160: 77
        //          default: 431
        //        }
        //   112: invokespecial   dev/nuker/pyro/fQ.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //   115: aload_0        
        //   116: new             Ldev/nuker/pyro/f0q;
        //   119: dup            
        //   120: ldc_w           "\u3d52\ub240\u8e11\uadb6\u677d\u598c\u7e45\u691e"
        //   123: invokestatic    invokestatic   !!! ERROR
        //   126: ldc_w           "\u3d72\ub240\u8e11\uadb6\u677d\u598c\u7e45\u691e"
        //   129: invokestatic    invokestatic   !!! ERROR
        //   132: ldc_w           "\u3d76\ub24d\u8e15\uade4\u677a\u59a2\u7e59\u6947\uc2cc\ua385\u9bbb\u1309\uc169\u711b\u90b3\u4daa\ub251\u4c8e\u0157\u0756\u12a3\ufecb\u6ade\u8814\u3646\u3d27\u7fbb\ua96b\ud1e5\u7259"
        //   135: invokestatic    invokestatic   !!! ERROR
        //   138: iconst_m1      
        //   139: invokespecial   dev/nuker/pyro/f0q.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V
        //   142: getstatic       dev/nuker/pyro/fc.c:I
        //   145: ifne            154
        //   148: ldc_w           1880022180
        //   151: goto            157
        //   154: ldc_w           1321841425
        //   157: ldc_w           -593152051
        //   160: ixor           
        //   161: lookupswitch {
        //          -1398019223: 427
        //          446429165: 154
        //          default: 188
        //        }
        //   188: putfield        dev/nuker/pyro/f6Q.c:Ldev/nuker/pyro/f0q;
        //   191: getstatic       dev/nuker/pyro/fc.1:I
        //   194: ifne            203
        //   197: ldc_w           -1828906696
        //   200: goto            206
        //   203: ldc_w           521484679
        //   206: ldc_w           -576422148
        //   209: ixor           
        //   210: lookupswitch {
        //          -1028569221: 236
        //          1331259332: 203
        //          default: 429
        //        }
        //   236: aload_0        
        //   237: new             Ldev/nuker/pyro/f0k;
        //   240: dup            
        //   241: ldc_w           "\u3d4b\ub24b\u8e06\uada1\u677f\u59b3\u7e4f\u6915\uc2da"
        //   244: invokestatic    invokestatic   !!! ERROR
        //   247: ldc_w           "\u3d6b\ub24b\u8e06\uada1\u677f\u59b3\u7e4f\u6915\uc2da"
        //   250: getstatic       dev/nuker/pyro/fc.c:I
        //   253: ifne            262
        //   256: ldc_w           -1593572446
        //   259: goto            265
        //   262: ldc_w           54903745
        //   265: ldc_w           550345281
        //   268: ixor           
        //   269: lookupswitch {
        //          -2117494301: 423
        //          644843007: 262
        //          default: 296
        //        }
        //   296: invokestatic    invokestatic   !!! ERROR
        //   299: aconst_null    
        //   300: iconst_0       
        //   301: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   304: putfield        dev/nuker/pyro/f6Q.c:Ldev/nuker/pyro/f0k;
        //   307: getstatic       dev/nuker/pyro/fc.0:I
        //   310: ifgt            319
        //   313: ldc_w           115635386
        //   316: goto            322
        //   319: ldc_w           -1232932777
        //   322: ldc_w           -501737078
        //   325: ixor           
        //   326: lookupswitch {
        //          -453219024: 319
        //          1419438557: 352
        //          default: 433
        //        }
        //   352: aload_0        
        //   353: aload_0        
        //   354: getfield        dev/nuker/pyro/f6Q.c:Ldev/nuker/pyro/f0q;
        //   357: checkcast       Ldev/nuker/pyro/f0w;
        //   360: getstatic       dev/nuker/pyro/fc.1:I
        //   363: ifne            372
        //   366: ldc_w           -755437212
        //   369: goto            375
        //   372: ldc_w           -1421169370
        //   375: ldc_w           166718955
        //   378: ixor           
        //   379: lookupswitch {
        //          -619242353: 425
        //          1073960144: 372
        //          default: 404
        //        }
        //   404: invokevirtual   dev/nuker/pyro/f6Q.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   407: pop            
        //   408: aload_0        
        //   409: aload_0        
        //   410: getfield        dev/nuker/pyro/f6Q.c:Ldev/nuker/pyro/f0k;
        //   413: checkcast       Ldev/nuker/pyro/f0w;
        //   416: invokevirtual   dev/nuker/pyro/f6Q.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   419: pop            
        //   420: return         
        //   421: aconst_null    
        //   422: athrow         
        //   423: aconst_null    
        //   424: athrow         
        //   425: aconst_null    
        //   426: athrow         
        //   427: aconst_null    
        //   428: athrow         
        //   429: aconst_null    
        //   430: athrow         
        //   431: aconst_null    
        //   432: athrow         
        //   433: aconst_null    
        //   434: athrow         
        //    StackMapTable: 00 1C FF 00 16 00 01 06 00 03 06 07 01 79 07 01 79 FF 00 02 00 01 06 00 04 06 07 01 79 07 01 79 01 FF 00 1E 00 01 06 00 03 06 07 01 79 07 01 79 FF 00 14 00 01 06 00 04 06 07 01 79 07 01 79 07 01 79 FF 00 02 00 01 06 00 05 06 07 01 79 07 01 79 07 01 79 01 FF 00 1F 00 01 06 00 04 06 07 01 79 07 01 79 07 01 79 FF 00 29 00 01 07 00 03 00 02 07 00 03 07 00 49 FF 00 02 00 01 07 00 03 00 03 07 00 03 07 00 49 01 FF 00 1E 00 01 07 00 03 00 02 07 00 03 07 00 49 0E 42 01 1D FF 00 19 00 01 07 00 03 00 05 07 00 03 08 00 ED 08 00 ED 07 01 79 07 01 79 FF 00 02 00 01 07 00 03 00 06 07 00 03 08 00 ED 08 00 ED 07 01 79 07 01 79 01 FF 00 1E 00 01 07 00 03 00 05 07 00 03 08 00 ED 08 00 ED 07 01 79 07 01 79 16 42 01 1D FF 00 13 00 01 07 00 03 00 02 07 00 03 07 01 71 FF 00 02 00 01 07 00 03 00 03 07 00 03 07 01 71 01 FF 00 1C 00 01 07 00 03 00 02 07 00 03 07 01 71 FF 00 10 00 01 06 00 03 06 07 01 79 07 01 79 FF 00 01 00 01 07 00 03 00 05 07 00 03 08 00 ED 08 00 ED 07 01 79 07 01 79 FF 00 01 00 01 07 00 03 00 02 07 00 03 07 01 71 FF 00 01 00 01 07 00 03 00 02 07 00 03 07 00 49 01 FF 00 01 00 01 06 00 04 06 07 01 79 07 01 79 07 01 79 FF 00 01 00 01 07 00 03 00 00
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:770)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:881)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @NotNull
    public f0k c() {
        return fez.73(this, 935003720);
    }
}
