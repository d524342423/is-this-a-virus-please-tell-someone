// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import net.minecraft.client.gui.ScaledResolution;

public class f5T extends f5q
{
    @Override
    public float 5() {
        return fez.es(this, 646458567);
    }
    
    public int c(@Nullable final ScaledResolution scaledResolution, final float n, final float n2) {
        throw new UnsupportedOperationException("Please report this to the binscure obfuscator developers");
    }
    
    static {
        throw t;
    }
    
    @Nullable
    public String 4() {
        throw new UnsupportedOperationException("Please report this to the binscure obfuscator developers");
    }
    
    public f5T(@NotNull final String s) {
        while (true) {
            int n = 0;
            Label_0016: {
                if (fc.c == 0) {
                    n = -164720264;
                    break Label_0016;
                }
                n = 40817998;
            }
            switch (n ^ 0xF4BC66E7) {
                case -1746373295: {
                    continue;
                }
                default: {
                    super(s, null, 2, null);
                }
                case 43186079: {
                    throw null;
                }
            }
            break;
        }
    }
    
    @Override
    public void c(@Nullable final f5t f5t, final int n, @Nullable final ScaledResolution scaledResolution, final float n2, final float n3) {
        fez.00(this, 453158251, f5t, n, scaledResolution, n2, n3);
    }
    
    @Override
    public float 0() {
        return fez.es(this, 646458566);
    }
}
