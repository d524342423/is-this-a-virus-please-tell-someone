// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

public class f7h
{
    public static int[] c;
    public static int[] 0;
}
