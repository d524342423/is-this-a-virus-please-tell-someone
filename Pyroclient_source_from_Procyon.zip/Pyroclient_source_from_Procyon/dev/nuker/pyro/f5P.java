// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import net.minecraft.client.gui.ScaledResolution;
import org.jetbrains.annotations.Nullable;

public class f5P extends f5q
{
    @Override
    public void c(@Nullable final f5t p0, final int p1, @Nullable final ScaledResolution p2, final float p3, final float p4) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          2397
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            2389
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            2381
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: getstatic       dev/nuker/pyro/fdX.c:Ldev/nuker/pyro/fdX;
        //    27: getstatic       net/minecraft/init/Items.field_190929_cY:Lnet/minecraft/item/Item;
        //    30: dup            
        //    31: pop            
        //    32: goto            36
        //    35: athrow         
        //    36: invokevirtual   dev/nuker/pyro/fdX.c:(Lnet/minecraft/item/Item;)I
        //    39: goto            43
        //    42: athrow         
        //    43: getstatic       dev/nuker/pyro/fc.0:I
        //    46: ifgt            54
        //    49: ldc             1911400595
        //    51: goto            56
        //    54: ldc             829260539
        //    56: ldc             143358077
        //    58: ixor           
        //    59: lookupswitch {
        //          971438726: 84
        //          2036781294: 54
        //          default: 2312
        //        }
        //    84: istore          6
        //    86: getstatic       dev/nuker/pyro/fc.1:I
        //    89: ifne            97
        //    92: ldc             1189055690
        //    94: goto            99
        //    97: ldc             1658008471
        //    99: ldc             843953837
        //   101: ixor           
        //   102: lookupswitch {
        //          1352566074: 128
        //          1955740263: 97
        //          default: 2352
        //        }
        //   128: getstatic       dev/nuker/pyro/fdX.c:Ldev/nuker/pyro/fdX;
        //   131: getstatic       net/minecraft/init/Items.field_151062_by:Lnet/minecraft/item/Item;
        //   134: dup            
        //   135: pop            
        //   136: goto            140
        //   139: athrow         
        //   140: invokevirtual   dev/nuker/pyro/fdX.c:(Lnet/minecraft/item/Item;)I
        //   143: goto            147
        //   146: athrow         
        //   147: istore          7
        //   149: getstatic       dev/nuker/pyro/fdX.c:Ldev/nuker/pyro/fdX;
        //   152: getstatic       net/minecraft/init/Items.field_185158_cP:Lnet/minecraft/item/Item;
        //   155: dup            
        //   156: pop            
        //   157: getstatic       dev/nuker/pyro/fc.1:I
        //   160: ifne            168
        //   163: ldc             1825209858
        //   165: goto            170
        //   168: ldc             -1513715345
        //   170: ldc             1082543101
        //   172: ixor           
        //   173: lookupswitch {
        //          -448740718: 200
        //          743192063: 168
        //          default: 2336
        //        }
        //   200: goto            204
        //   203: athrow         
        //   204: invokevirtual   dev/nuker/pyro/fdX.c:(Lnet/minecraft/item/Item;)I
        //   207: goto            211
        //   210: athrow         
        //   211: getstatic       dev/nuker/pyro/fc.1:I
        //   214: ifne            222
        //   217: ldc             108848885
        //   219: goto            224
        //   222: ldc             1094765216
        //   224: ldc             2068096145
        //   226: ixor           
        //   227: lookupswitch {
        //          340818875: 222
        //          2100839012: 2350
        //          default: 252
        //        }
        //   252: istore          8
        //   254: getstatic       dev/nuker/pyro/fdX.c:Ldev/nuker/pyro/fdX;
        //   257: getstatic       dev/nuker/pyro/fc.1:I
        //   260: ifne            268
        //   263: ldc             1006894212
        //   265: goto            270
        //   268: ldc             -1497939612
        //   270: ldc             -2042544048
        //   272: ixor           
        //   273: lookupswitch {
        //          -1170031404: 2356
        //          -143550257: 268
        //          default: 300
        //        }
        //   300: getstatic       net/minecraft/init/Items.field_151153_ao:Lnet/minecraft/item/Item;
        //   303: dup            
        //   304: pop            
        //   305: goto            309
        //   308: athrow         
        //   309: invokevirtual   dev/nuker/pyro/fdX.c:(Lnet/minecraft/item/Item;)I
        //   312: goto            316
        //   315: athrow         
        //   316: getstatic       dev/nuker/pyro/fc.c:I
        //   319: ifne            327
        //   322: ldc             -950864013
        //   324: goto            329
        //   327: ldc             305122669
        //   329: ldc             943274473
        //   331: ixor           
        //   332: lookupswitch {
        //          -1121742090: 327
        //          -9711974: 2358
        //          default: 360
        //        }
        //   360: istore          9
        //   362: new             Ljava/util/ArrayList;
        //   365: dup            
        //   366: getstatic       dev/nuker/pyro/fc.c:I
        //   369: ifne            377
        //   372: ldc             1242782312
        //   374: goto            379
        //   377: ldc             586836300
        //   379: ldc             1523362867
        //   381: ixor           
        //   382: lookupswitch {
        //          283113051: 377
        //          2016855423: 408
        //          default: 2342
        //        }
        //   408: goto            412
        //   411: athrow         
        //   412: invokespecial   java/util/ArrayList.<init>:()V
        //   415: goto            419
        //   418: athrow         
        //   419: checkcast       Ljava/util/List;
        //   422: astore          10
        //   424: iload           6
        //   426: ifle            434
        //   429: ldc             -1463904243
        //   431: goto            436
        //   434: ldc             -1463904244
        //   436: ldc             -148551695
        //   438: ixor           
        //   439: tableswitch {
        //          -1086865416: 460
        //          -1086865415: 538
        //          default: 429
        //        }
        //   460: aload           10
        //   462: new             Lnet/minecraft/item/ItemStack;
        //   465: dup            
        //   466: getstatic       dev/nuker/pyro/fc.c:I
        //   469: ifne            477
        //   472: ldc             -2026439375
        //   474: goto            479
        //   477: ldc             -1664485239
        //   479: ldc             -1706407038
        //   481: ixor           
        //   482: lookupswitch {
        //          109294347: 508
        //          494712499: 477
        //          default: 2326
        //        }
        //   508: getstatic       net/minecraft/init/Items.field_190929_cY:Lnet/minecraft/item/Item;
        //   511: iload           6
        //   513: goto            517
        //   516: athrow         
        //   517: invokespecial   net/minecraft/item/ItemStack.<init>:(Lnet/minecraft/item/Item;I)V
        //   520: goto            524
        //   523: athrow         
        //   524: goto            528
        //   527: athrow         
        //   528: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //   533: goto            537
        //   536: athrow         
        //   537: pop            
        //   538: iload           7
        //   540: ifle            662
        //   543: getstatic       dev/nuker/pyro/fc.c:I
        //   546: ifne            554
        //   549: ldc             -1612517949
        //   551: goto            556
        //   554: ldc             1259775571
        //   556: ldc             1765846454
        //   558: ixor           
        //   559: lookupswitch {
        //          -1194672690: 554
        //          -157138827: 2338
        //          default: 584
        //        }
        //   584: aload           10
        //   586: new             Lnet/minecraft/item/ItemStack;
        //   589: dup            
        //   590: getstatic       dev/nuker/pyro/fc.c:I
        //   593: ifne            601
        //   596: ldc             -227809767
        //   598: goto            603
        //   601: ldc             2094926288
        //   603: ldc             -582857975
        //   605: ixor           
        //   606: lookupswitch {
        //          791260432: 2310
        //          1778521112: 601
        //          default: 632
        //        }
        //   632: getstatic       net/minecraft/init/Items.field_151062_by:Lnet/minecraft/item/Item;
        //   635: iload           7
        //   637: goto            641
        //   640: athrow         
        //   641: invokespecial   net/minecraft/item/ItemStack.<init>:(Lnet/minecraft/item/Item;I)V
        //   644: goto            648
        //   647: athrow         
        //   648: goto            652
        //   651: athrow         
        //   652: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //   657: goto            661
        //   660: athrow         
        //   661: pop            
        //   662: iload           8
        //   664: ifle            747
        //   667: aload           10
        //   669: new             Lnet/minecraft/item/ItemStack;
        //   672: dup            
        //   673: getstatic       net/minecraft/init/Items.field_185158_cP:Lnet/minecraft/item/Item;
        //   676: getstatic       dev/nuker/pyro/fc.c:I
        //   679: ifne            687
        //   682: ldc             -1515377139
        //   684: goto            689
        //   687: ldc             -1177939075
        //   689: ldc             712604051
        //   691: ixor           
        //   692: lookupswitch {
        //          -1881909346: 687
        //          -1816958226: 720
        //          default: 2334
        //        }
        //   720: iload           8
        //   722: goto            726
        //   725: athrow         
        //   726: invokespecial   net/minecraft/item/ItemStack.<init>:(Lnet/minecraft/item/Item;I)V
        //   729: goto            733
        //   732: athrow         
        //   733: goto            737
        //   736: athrow         
        //   737: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //   742: goto            746
        //   745: athrow         
        //   746: pop            
        //   747: iload           9
        //   749: ifle            874
        //   752: aload           10
        //   754: new             Lnet/minecraft/item/ItemStack;
        //   757: dup            
        //   758: getstatic       net/minecraft/init/Items.field_151153_ao:Lnet/minecraft/item/Item;
        //   761: iload           9
        //   763: iconst_1       
        //   764: getstatic       dev/nuker/pyro/fc.0:I
        //   767: ifgt            775
        //   770: ldc             -345874669
        //   772: goto            777
        //   775: ldc             -1501244756
        //   777: ldc             -598862942
        //   779: ixor           
        //   780: lookupswitch {
        //          -819499187: 775
        //          925650097: 2370
        //          default: 808
        //        }
        //   808: goto            812
        //   811: athrow         
        //   812: invokespecial   net/minecraft/item/ItemStack.<init>:(Lnet/minecraft/item/Item;II)V
        //   815: goto            819
        //   818: athrow         
        //   819: getstatic       dev/nuker/pyro/fc.c:I
        //   822: ifne            830
        //   825: ldc             1934662372
        //   827: goto            832
        //   830: ldc             2036227915
        //   832: ldc             -2101392185
        //   834: ixor           
        //   835: lookupswitch {
        //          -235940317: 830
        //          -69135476: 860
        //          default: 2304
        //        }
        //   860: goto            864
        //   863: athrow         
        //   864: invokeinterface java/util/List.add:(Ljava/lang/Object;)Z
        //   869: goto            873
        //   872: athrow         
        //   873: pop            
        //   874: iconst_0       
        //   875: istore          11
        //   877: aload           10
        //   879: checkcast       Ljava/util/Collection;
        //   882: goto            886
        //   885: athrow         
        //   886: invokeinterface java/util/Collection.size:()I
        //   891: goto            895
        //   894: athrow         
        //   895: getstatic       dev/nuker/pyro/fc.1:I
        //   898: ifne            906
        //   901: ldc             -1237897692
        //   903: goto            908
        //   906: ldc             688754280
        //   908: ldc             -1097816996
        //   910: ixor           
        //   911: lookupswitch {
        //          -1751307724: 936
        //          145197688: 906
        //          default: 2332
        //        }
        //   936: istore          12
        //   938: getstatic       dev/nuker/pyro/fc.0:I
        //   941: ifgt            949
        //   944: ldc             -1253532949
        //   946: goto            951
        //   949: ldc             -467312297
        //   951: ldc             -1275408854
        //   953: ixor           
        //   954: lookupswitch {
        //          112350401: 2344
        //          120379156: 949
        //          default: 980
        //        }
        //   980: iload           11
        //   982: getstatic       dev/nuker/pyro/fc.0:I
        //   985: ifgt            993
        //   988: ldc             1525724624
        //   990: goto            995
        //   993: ldc             -1696173512
        //   995: ldc             158139188
        //   997: ixor           
        //   998: lookupswitch {
        //          -1819578100: 1024
        //          1402844900: 993
        //          default: 2346
        //        }
        //  1024: iload           12
        //  1026: if_icmpge       1796
        //  1029: goto            1033
        //  1032: athrow         
        //  1033: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179094_E:()V
        //  1036: goto            1040
        //  1039: athrow         
        //  1040: iconst_1       
        //  1041: getstatic       dev/nuker/pyro/fc.c:I
        //  1044: ifne            1052
        //  1047: ldc             1414512755
        //  1049: goto            1054
        //  1052: ldc             -931450121
        //  1054: ldc             -1377816191
        //  1056: ixor           
        //  1057: lookupswitch {
        //          -105909774: 2330
        //          981260141: 1052
        //          default: 1084
        //        }
        //  1084: goto            1088
        //  1087: athrow         
        //  1088: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179132_a:(Z)V
        //  1091: goto            1095
        //  1094: athrow         
        //  1095: sipush          256
        //  1098: goto            1102
        //  1101: athrow         
        //  1102: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179086_m:(I)V
        //  1105: goto            1109
        //  1108: athrow         
        //  1109: goto            1113
        //  1112: athrow         
        //  1113: invokestatic    net/minecraft/client/renderer/RenderHelper.func_74519_b:()V
        //  1116: goto            1120
        //  1119: athrow         
        //  1120: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //  1123: dup            
        //  1124: pop            
        //  1125: getstatic       dev/nuker/pyro/fc.0:I
        //  1128: ifgt            1136
        //  1131: ldc             -991125528
        //  1133: goto            1138
        //  1136: ldc             2072935515
        //  1138: ldc             1444769589
        //  1140: ixor           
        //  1141: lookupswitch {
        //          -1829637923: 2306
        //          588514593: 1136
        //          default: 1168
        //        }
        //  1168: goto            1172
        //  1171: athrow         
        //  1172: invokevirtual   net/minecraft/client/Minecraft.func_175599_af:()Lnet/minecraft/client/renderer/RenderItem;
        //  1175: goto            1179
        //  1178: athrow         
        //  1179: ldc             -150.0
        //  1181: putfield        net/minecraft/client/renderer/RenderItem.field_77023_b:F
        //  1184: goto            1188
        //  1187: athrow         
        //  1188: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179118_c:()V
        //  1191: goto            1195
        //  1194: athrow         
        //  1195: goto            1199
        //  1198: athrow         
        //  1199: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179126_j:()V
        //  1202: goto            1206
        //  1205: athrow         
        //  1206: goto            1210
        //  1209: athrow         
        //  1210: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179129_p:()V
        //  1213: goto            1217
        //  1216: athrow         
        //  1217: iconst_0       
        //  1218: istore          13
        //  1220: iconst_0       
        //  1221: istore          14
        //  1223: aload           10
        //  1225: iload           11
        //  1227: goto            1231
        //  1230: athrow         
        //  1231: invokeinterface java/util/List.get:(I)Ljava/lang/Object;
        //  1236: goto            1240
        //  1239: athrow         
        //  1240: checkcast       Lnet/minecraft/item/ItemStack;
        //  1243: astore          15
        //  1245: getstatic       dev/nuker/pyro/fc.1:I
        //  1248: ifne            1256
        //  1251: ldc             -407901142
        //  1253: goto            1258
        //  1256: ldc             519976035
        //  1258: ldc             -1389906842
        //  1260: ixor           
        //  1261: lookupswitch {
        //          1180234471: 1256
        //          1250449484: 2314
        //          default: 1288
        //        }
        //  1288: iload           11
        //  1290: iconst_2       
        //  1291: irem           
        //  1292: bipush          20
        //  1294: imul           
        //  1295: getstatic       dev/nuker/pyro/fc.c:I
        //  1298: ifne            1306
        //  1301: ldc             -1472635815
        //  1303: goto            1308
        //  1306: ldc             -1496217549
        //  1308: ldc             -94562751
        //  1310: ixor           
        //  1311: lookupswitch {
        //          1382304280: 1306
        //          1552719474: 1336
        //          default: 2318
        //        }
        //  1336: istore          13
        //  1338: iload           11
        //  1340: iconst_2       
        //  1341: idiv           
        //  1342: bipush          20
        //  1344: imul           
        //  1345: getstatic       dev/nuker/pyro/fc.0:I
        //  1348: ifgt            1356
        //  1351: ldc             1201640455
        //  1353: goto            1358
        //  1356: ldc             2028868937
        //  1358: ldc             50807156
        //  1360: ixor           
        //  1361: lookupswitch {
        //          -459440001: 1356
        //          1150866803: 2364
        //          default: 1388
        //        }
        //  1388: istore          14
        //  1390: getstatic       dev/nuker/pyro/fc.1:I
        //  1393: ifne            1401
        //  1396: ldc             1407376481
        //  1398: goto            1403
        //  1401: ldc             1653947850
        //  1403: ldc             56809441
        //  1405: ixor           
        //  1406: lookupswitch {
        //          1350568832: 1401
        //          1643637291: 1432
        //          default: 2320
        //        }
        //  1432: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //  1435: dup            
        //  1436: pop            
        //  1437: goto            1441
        //  1440: athrow         
        //  1441: invokevirtual   net/minecraft/client/Minecraft.func_175599_af:()Lnet/minecraft/client/renderer/RenderItem;
        //  1444: goto            1448
        //  1447: athrow         
        //  1448: aload           15
        //  1450: iload           13
        //  1452: iconst_2       
        //  1453: iadd           
        //  1454: getstatic       dev/nuker/pyro/fc.1:I
        //  1457: ifne            1465
        //  1460: ldc             165066755
        //  1462: goto            1467
        //  1465: ldc             -1712440501
        //  1467: ldc             -60408832
        //  1469: ixor           
        //  1470: lookupswitch {
        //          -172981245: 1465
        //          1703413579: 1496
        //          default: 2360
        //        }
        //  1496: iload           14
        //  1498: iconst_2       
        //  1499: iadd           
        //  1500: goto            1504
        //  1503: athrow         
        //  1504: invokevirtual   net/minecraft/client/renderer/RenderItem.func_180450_b:(Lnet/minecraft/item/ItemStack;II)V
        //  1507: goto            1511
        //  1510: athrow         
        //  1511: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //  1514: dup            
        //  1515: pop            
        //  1516: getstatic       dev/nuker/pyro/fc.1:I
        //  1519: ifne            1527
        //  1522: ldc             -1576678772
        //  1524: goto            1529
        //  1527: ldc             -985159803
        //  1529: ldc             -401784500
        //  1531: ixor           
        //  1532: lookupswitch {
        //          1242074048: 2348
        //          2106767719: 1527
        //          default: 1560
        //        }
        //  1560: goto            1564
        //  1563: athrow         
        //  1564: invokevirtual   net/minecraft/client/Minecraft.func_175599_af:()Lnet/minecraft/client/renderer/RenderItem;
        //  1567: goto            1571
        //  1570: athrow         
        //  1571: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //  1574: getfield        net/minecraft/client/Minecraft.field_71466_p:Lnet/minecraft/client/gui/FontRenderer;
        //  1577: aload           15
        //  1579: iload           13
        //  1581: iconst_2       
        //  1582: iadd           
        //  1583: getstatic       dev/nuker/pyro/fc.0:I
        //  1586: ifgt            1594
        //  1589: ldc             -288593808
        //  1591: goto            1596
        //  1594: ldc             1051096150
        //  1596: ldc             1215304482
        //  1598: ixor           
        //  1599: lookupswitch {
        //          -1497597102: 1594
        //          1993762676: 1624
        //          default: 2366
        //        }
        //  1624: iload           14
        //  1626: iconst_2       
        //  1627: iadd           
        //  1628: goto            1632
        //  1631: athrow         
        //  1632: invokevirtual   net/minecraft/client/renderer/RenderItem.func_175030_a:(Lnet/minecraft/client/gui/FontRenderer;Lnet/minecraft/item/ItemStack;II)V
        //  1635: goto            1639
        //  1638: athrow         
        //  1639: getstatic       dev/nuker/pyro/fdZ.c:Lnet/minecraft/client/Minecraft;
        //  1642: dup            
        //  1643: pop            
        //  1644: goto            1648
        //  1647: athrow         
        //  1648: invokevirtual   net/minecraft/client/Minecraft.func_175599_af:()Lnet/minecraft/client/renderer/RenderItem;
        //  1651: goto            1655
        //  1654: athrow         
        //  1655: fconst_0       
        //  1656: getstatic       dev/nuker/pyro/fc.c:I
        //  1659: ifne            1667
        //  1662: ldc             468846763
        //  1664: goto            1669
        //  1667: ldc             762536383
        //  1669: ldc             1910880770
        //  1671: ixor           
        //  1672: lookupswitch {
        //          1038927357: 1667
        //          1779937961: 2340
        //          default: 1700
        //        }
        //  1700: putfield        net/minecraft/client/renderer/RenderItem.field_77023_b:F
        //  1703: goto            1707
        //  1706: athrow         
        //  1707: invokestatic    net/minecraft/client/renderer/RenderHelper.func_74518_a:()V
        //  1710: goto            1714
        //  1713: athrow         
        //  1714: goto            1718
        //  1717: athrow         
        //  1718: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179089_o:()V
        //  1721: goto            1725
        //  1724: athrow         
        //  1725: getstatic       dev/nuker/pyro/fc.0:I
        //  1728: ifgt            1736
        //  1731: ldc             1010087865
        //  1733: goto            1738
        //  1736: ldc             -575698069
        //  1738: ldc             -1931530642
        //  1740: ixor           
        //  1741: lookupswitch {
        //          -1326736937: 1736
        //          1366336773: 1768
        //          default: 2322
        //        }
        //  1768: goto            1772
        //  1771: athrow         
        //  1772: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179141_d:()V
        //  1775: goto            1779
        //  1778: athrow         
        //  1779: goto            1783
        //  1782: athrow         
        //  1783: invokestatic    net/minecraft/client/renderer/GlStateManager.func_179121_F:()V
        //  1786: goto            1790
        //  1789: athrow         
        //  1790: iinc            11, 1
        //  1793: goto            938
        //  1796: fconst_0       
        //  1797: fconst_0       
        //  1798: getstatic       dev/nuker/pyro/fc.c:I
        //  1801: ifne            1810
        //  1804: ldc_w           -1381109361
        //  1807: goto            1813
        //  1810: ldc_w           -580338949
        //  1813: ldc_w           -903138824
        //  1816: ixor           
        //  1817: lookupswitch {
        //          390302467: 1844
        //          1736884343: 1810
        //          default: 2354
        //        }
        //  1844: aload_0        
        //  1845: goto            1849
        //  1848: athrow         
        //  1849: invokevirtual   dev/nuker/pyro/f5P.5:()F
        //  1852: goto            1856
        //  1855: athrow         
        //  1856: aload_0        
        //  1857: goto            1861
        //  1860: athrow         
        //  1861: invokevirtual   dev/nuker/pyro/f5P.0:()F
        //  1864: goto            1868
        //  1867: athrow         
        //  1868: fconst_1       
        //  1869: getstatic       dev/nuker/pyro/f0H.c:Ldev/nuker/pyro/f0H;
        //  1872: goto            1876
        //  1875: athrow         
        //  1876: invokevirtual   dev/nuker/pyro/f0H.8:()I
        //  1879: goto            1883
        //  1882: athrow         
        //  1883: goto            1887
        //  1886: athrow         
        //  1887: invokestatic    dev/nuker/pyro/fe6.c:(FFFFFI)V
        //  1890: goto            1894
        //  1893: athrow         
        //  1894: aload_0        
        //  1895: getstatic       dev/nuker/pyro/fc.1:I
        //  1898: ifne            1907
        //  1901: ldc_w           450761697
        //  1904: goto            1910
        //  1907: ldc_w           588151123
        //  1910: ldc_w           1035092619
        //  1913: ixor           
        //  1914: lookupswitch {
        //          515652568: 1940
        //          661410154: 1907
        //          default: 2308
        //        }
        //  1940: goto            1944
        //  1943: athrow         
        //  1944: invokevirtual   dev/nuker/pyro/f5P.5:()F
        //  1947: goto            1951
        //  1950: athrow         
        //  1951: iconst_2       
        //  1952: i2f            
        //  1953: fdiv           
        //  1954: fconst_0       
        //  1955: aload_0        
        //  1956: goto            1960
        //  1959: athrow         
        //  1960: invokevirtual   dev/nuker/pyro/f5P.5:()F
        //  1963: goto            1967
        //  1966: athrow         
        //  1967: iconst_2       
        //  1968: i2f            
        //  1969: fdiv           
        //  1970: aload_0        
        //  1971: getstatic       dev/nuker/pyro/fc.c:I
        //  1974: ifne            1983
        //  1977: ldc_w           1560435647
        //  1980: goto            1986
        //  1983: ldc_w           -1297792672
        //  1986: ldc_w           -101427189
        //  1989: ixor           
        //  1990: lookupswitch {
        //          -1527381068: 1983
        //          1263606123: 2016
        //          default: 2316
        //        }
        //  2016: goto            2020
        //  2019: athrow         
        //  2020: invokevirtual   dev/nuker/pyro/f5P.0:()F
        //  2023: goto            2027
        //  2026: athrow         
        //  2027: fconst_1       
        //  2028: getstatic       dev/nuker/pyro/f0H.c:Ldev/nuker/pyro/f0H;
        //  2031: goto            2035
        //  2034: athrow         
        //  2035: invokevirtual   dev/nuker/pyro/f0H.8:()I
        //  2038: goto            2042
        //  2041: athrow         
        //  2042: getstatic       dev/nuker/pyro/fc.1:I
        //  2045: ifne            2054
        //  2048: ldc_w           2059797489
        //  2051: goto            2057
        //  2054: ldc_w           802746571
        //  2057: ldc_w           1565133903
        //  2060: ixor           
        //  2061: lookupswitch {
        //          663490494: 2054
        //          1922235524: 2088
        //          default: 2368
        //        }
        //  2088: goto            2092
        //  2091: athrow         
        //  2092: invokestatic    dev/nuker/pyro/fe6.0:(FFFFFI)V
        //  2095: goto            2099
        //  2098: athrow         
        //  2099: fconst_0       
        //  2100: aload_0        
        //  2101: goto            2105
        //  2104: athrow         
        //  2105: invokevirtual   dev/nuker/pyro/f5P.0:()F
        //  2108: goto            2112
        //  2111: athrow         
        //  2112: iconst_2       
        //  2113: i2f            
        //  2114: fdiv           
        //  2115: getstatic       dev/nuker/pyro/fc.1:I
        //  2118: ifne            2127
        //  2121: ldc_w           -1450655820
        //  2124: goto            2130
        //  2127: ldc_w           -1546536817
        //  2130: ldc_w           -232583909
        //  2133: ixor           
        //  2134: lookupswitch {
        //          1537979055: 2324
        //          1775873981: 2127
        //          default: 2160
        //        }
        //  2160: aload_0        
        //  2161: goto            2165
        //  2164: athrow         
        //  2165: invokevirtual   dev/nuker/pyro/f5P.5:()F
        //  2168: goto            2172
        //  2171: athrow         
        //  2172: aload_0        
        //  2173: goto            2177
        //  2176: athrow         
        //  2177: invokevirtual   dev/nuker/pyro/f5P.0:()F
        //  2180: goto            2184
        //  2183: athrow         
        //  2184: iconst_2       
        //  2185: i2f            
        //  2186: fdiv           
        //  2187: fconst_1       
        //  2188: getstatic       dev/nuker/pyro/f0H.c:Ldev/nuker/pyro/f0H;
        //  2191: getstatic       dev/nuker/pyro/fc.0:I
        //  2194: ifgt            2203
        //  2197: ldc_w           -953113215
        //  2200: goto            2206
        //  2203: ldc_w           240768538
        //  2206: ldc_w           2051615896
        //  2209: ixor           
        //  2210: lookupswitch {
        //          -1116108519: 2203
        //          1947269762: 2236
        //          default: 2328
        //        }
        //  2236: goto            2240
        //  2239: athrow         
        //  2240: invokevirtual   dev/nuker/pyro/f0H.8:()I
        //  2243: goto            2247
        //  2246: athrow         
        //  2247: getstatic       dev/nuker/pyro/fc.c:I
        //  2250: ifne            2259
        //  2253: ldc_w           1723544029
        //  2256: goto            2262
        //  2259: ldc_w           1414719828
        //  2262: ldc_w           823877342
        //  2265: ixor           
        //  2266: lookupswitch {
        //          1470131971: 2259
        //          1699329930: 2292
        //          default: 2362
        //        }
        //  2292: goto            2296
        //  2295: athrow         
        //  2296: invokestatic    dev/nuker/pyro/fe6.0:(FFFFFI)V
        //  2299: goto            2303
        //  2302: athrow         
        //  2303: return         
        //  2304: aconst_null    
        //  2305: athrow         
        //  2306: aconst_null    
        //  2307: athrow         
        //  2308: aconst_null    
        //  2309: athrow         
        //  2310: aconst_null    
        //  2311: athrow         
        //  2312: aconst_null    
        //  2313: athrow         
        //  2314: aconst_null    
        //  2315: athrow         
        //  2316: aconst_null    
        //  2317: athrow         
        //  2318: aconst_null    
        //  2319: athrow         
        //  2320: aconst_null    
        //  2321: athrow         
        //  2322: aconst_null    
        //  2323: athrow         
        //  2324: aconst_null    
        //  2325: athrow         
        //  2326: aconst_null    
        //  2327: athrow         
        //  2328: aconst_null    
        //  2329: athrow         
        //  2330: aconst_null    
        //  2331: athrow         
        //  2332: aconst_null    
        //  2333: athrow         
        //  2334: aconst_null    
        //  2335: athrow         
        //  2336: aconst_null    
        //  2337: athrow         
        //  2338: aconst_null    
        //  2339: athrow         
        //  2340: aconst_null    
        //  2341: athrow         
        //  2342: aconst_null    
        //  2343: athrow         
        //  2344: aconst_null    
        //  2345: athrow         
        //  2346: aconst_null    
        //  2347: athrow         
        //  2348: aconst_null    
        //  2349: athrow         
        //  2350: aconst_null    
        //  2351: athrow         
        //  2352: aconst_null    
        //  2353: athrow         
        //  2354: aconst_null    
        //  2355: athrow         
        //  2356: aconst_null    
        //  2357: athrow         
        //  2358: aconst_null    
        //  2359: athrow         
        //  2360: aconst_null    
        //  2361: athrow         
        //  2362: aconst_null    
        //  2363: athrow         
        //  2364: aconst_null    
        //  2365: athrow         
        //  2366: aconst_null    
        //  2367: athrow         
        //  2368: aconst_null    
        //  2369: athrow         
        //  2370: aconst_null    
        //  2371: athrow         
        //  2372: pop            
        //  2373: goto            24
        //  2376: pop            
        //  2377: aconst_null    
        //  2378: goto            2372
        //  2381: dup            
        //  2382: ifnull          2372
        //  2385: checkcast       Ljava/lang/Throwable;
        //  2388: athrow         
        //  2389: dup            
        //  2390: ifnull          2376
        //  2393: checkcast       Ljava/lang/Throwable;
        //  2396: athrow         
        //  2397: aconst_null    
        //  2398: athrow         
        //    StackMapTable: 01 53 43 07 00 2F 04 FF 00 0B 00 00 00 01 07 00 2F FF 00 03 00 06 07 00 03 07 01 2F 01 07 01 31 02 02 00 00 4A 07 00 16 FF 00 00 00 06 07 00 03 07 01 2F 01 07 01 31 02 02 00 02 07 00 31 07 01 33 45 07 00 2F 40 01 4A 01 FF 00 01 00 06 07 00 03 07 01 2F 01 07 01 31 02 02 00 02 01 01 5B 01 FC 00 0C 01 41 01 1C 4A 07 00 2F FF 00 00 00 07 07 00 03 07 01 2F 01 07 01 31 02 02 01 00 02 07 00 31 07 01 33 45 07 00 2F 40 01 FF 00 14 00 08 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 00 02 07 00 31 07 01 33 FF 00 01 00 08 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 00 03 07 00 31 07 01 33 01 FF 00 1D 00 08 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 00 02 07 00 31 07 01 33 42 07 00 2F FF 00 00 00 08 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 00 02 07 00 31 07 01 33 45 07 00 2F 40 01 4A 01 FF 00 01 00 08 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 00 02 01 01 5B 01 FF 00 0F 00 09 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 00 01 07 00 31 FF 00 01 00 09 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 00 02 07 00 31 01 5D 07 00 31 47 07 00 0A FF 00 00 00 09 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 00 02 07 00 31 07 01 33 45 07 00 2F 40 01 4A 01 FF 00 01 00 09 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 00 02 01 01 5E 01 FF 00 10 00 0A 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 00 02 08 01 6A 08 01 6A FF 00 01 00 0A 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 00 03 08 01 6A 08 01 6A 01 FF 00 1C 00 0A 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 00 02 08 01 6A 08 01 6A 42 07 00 1E FF 00 00 00 0A 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 00 02 08 01 6A 08 01 6A 45 07 00 2F 40 07 00 60 FC 00 09 07 00 69 04 41 01 17 FF 00 10 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 03 07 00 69 08 01 CE 08 01 CE FF 00 01 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 04 07 00 69 08 01 CE 08 01 CE 01 FF 00 1C 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 03 07 00 69 08 01 CE 08 01 CE 47 07 00 2F FF 00 00 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 05 07 00 69 08 01 CE 08 01 CE 07 01 33 01 45 07 00 2F FF 00 00 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 02 07 00 69 07 00 6E 42 07 00 2F FF 00 00 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 02 07 00 69 07 00 6E 47 07 00 2F 40 01 00 0F 41 01 1B FF 00 10 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 03 07 00 69 08 02 4A 08 02 4A FF 00 01 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 04 07 00 69 08 02 4A 08 02 4A 01 FF 00 1C 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 03 07 00 69 08 02 4A 08 02 4A 47 07 00 2F FF 00 00 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 05 07 00 69 08 02 4A 08 02 4A 07 01 33 01 45 07 00 2F FF 00 00 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 02 07 00 69 07 00 6E 42 07 00 2F FF 00 00 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 02 07 00 69 07 00 6E 47 07 00 2F 40 01 00 FF 00 18 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 04 07 00 69 08 02 9D 08 02 9D 07 01 33 FF 00 01 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 05 07 00 69 08 02 9D 08 02 9D 07 01 33 01 FF 00 1E 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 04 07 00 69 08 02 9D 08 02 9D 07 01 33 44 07 00 1E FF 00 00 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 05 07 00 69 08 02 9D 08 02 9D 07 01 33 01 45 07 00 2F FF 00 00 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 02 07 00 69 07 00 6E 42 07 00 2F FF 00 00 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 02 07 00 69 07 00 6E 47 07 00 2F 40 01 00 FF 00 1B 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 06 07 00 69 08 02 F2 08 02 F2 07 01 33 01 01 FF 00 01 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 07 07 00 69 08 02 F2 08 02 F2 07 01 33 01 01 01 FF 00 1E 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 06 07 00 69 08 02 F2 08 02 F2 07 01 33 01 01 42 07 00 2F FF 00 00 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 06 07 00 69 08 02 F2 08 02 F2 07 01 33 01 01 45 07 00 2F FF 00 00 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 02 07 00 69 07 00 6E FF 00 0A 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 02 07 00 69 07 00 6E FF 00 01 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 03 07 00 69 07 00 6E 01 FF 00 1B 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 02 07 00 69 07 00 6E 42 07 00 16 FF 00 00 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 02 07 00 69 07 00 6E 47 07 00 2F 40 01 00 FF 00 0A 00 00 00 01 07 00 2F FF 00 00 00 0C 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 00 01 07 00 8C 47 07 00 2F 40 01 4A 01 FF 00 01 00 0C 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 00 02 01 01 5B 01 FC 00 01 01 0A 41 01 1C 4C 01 FF 00 01 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 02 01 01 5C 01 47 07 00 0E 00 45 07 00 2F 00 4B 01 FF 00 01 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 02 01 01 5D 01 42 07 00 14 40 01 45 07 00 2F 00 45 07 00 2F 40 01 45 07 00 2F 00 42 07 00 2F 00 45 07 00 2F 00 4F 07 00 B8 FF 00 01 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 02 07 00 B8 01 5D 07 00 B8 FF 00 02 00 00 00 01 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 01 07 00 B8 45 07 00 2F 40 07 00 BF 47 07 00 14 00 45 07 00 2F 00 42 07 00 2F 00 45 07 00 2F 00 42 07 00 26 00 45 07 00 2F 00 FF 00 0C 00 00 00 01 07 00 2F FF 00 00 00 0F 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 00 02 07 00 69 01 47 07 00 2F 40 07 01 35 FC 00 0F 07 00 6E 41 01 1D 51 01 FF 00 01 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 02 01 01 5B 01 53 01 FF 00 01 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 02 01 01 5D 01 0C 41 01 1C 47 07 00 0A 40 07 00 B8 45 07 00 2F 40 07 00 BF FF 00 10 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 03 07 00 BF 07 00 6E 01 FF 00 01 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 04 07 00 BF 07 00 6E 01 01 FF 00 1C 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 03 07 00 BF 07 00 6E 01 46 07 00 12 FF 00 00 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 04 07 00 BF 07 00 6E 01 01 45 07 00 2F 00 4F 07 00 B8 FF 00 01 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 02 07 00 B8 01 5E 07 00 B8 42 07 00 2F 40 07 00 B8 45 07 00 2F 40 07 00 BF FF 00 16 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 04 07 00 BF 07 01 37 07 00 6E 01 FF 00 01 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 05 07 00 BF 07 01 37 07 00 6E 01 01 FF 00 1B 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 04 07 00 BF 07 01 37 07 00 6E 01 FF 00 06 00 00 00 01 07 00 2F FF 00 00 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 05 07 00 BF 07 01 37 07 00 6E 01 01 45 07 00 2F 00 47 07 00 2F 40 07 00 B8 45 07 00 2F 40 07 00 BF FF 00 0B 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 02 07 00 BF 02 FF 00 01 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 03 07 00 BF 02 01 FF 00 1E 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 02 07 00 BF 02 FF 00 05 00 00 00 01 07 00 2F FF 00 00 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 00 45 07 00 2F 00 42 07 00 16 00 45 07 00 2F 00 0A 41 01 1D 42 07 00 22 00 45 07 00 2F 00 42 07 00 26 00 45 07 00 2F 00 F8 00 05 FF 00 0D 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 02 02 02 FF 00 02 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 03 02 02 01 FF 00 1E 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 02 02 02 43 07 00 16 FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 03 02 02 07 00 03 45 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 03 02 02 02 43 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 04 02 02 02 07 00 03 45 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 04 02 02 02 02 46 07 00 10 FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 06 02 02 02 02 02 07 01 0E 45 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 06 02 02 02 02 02 01 FF 00 02 00 00 00 01 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 06 02 02 02 02 02 01 45 07 00 2F 00 4C 07 00 03 FF 00 02 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 02 07 00 03 01 5D 07 00 03 FF 00 02 00 00 00 01 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 01 07 00 03 45 07 00 2F 40 02 FF 00 07 00 00 00 01 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 03 02 02 07 00 03 45 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 03 02 02 02 FF 00 0F 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 04 02 02 02 07 00 03 FF 00 02 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 05 02 02 02 07 00 03 01 FF 00 1D 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 04 02 02 02 07 00 03 42 07 00 16 FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 04 02 02 02 07 00 03 45 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 04 02 02 02 02 FF 00 06 00 00 00 01 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 06 02 02 02 02 02 07 01 0E 45 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 06 02 02 02 02 02 01 FF 00 0B 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 06 02 02 02 02 02 01 FF 00 02 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 07 02 02 02 02 02 01 01 FF 00 1E 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 06 02 02 02 02 02 01 42 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 06 02 02 02 02 02 01 45 07 00 2F 00 FF 00 04 00 00 00 01 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 02 02 07 00 03 45 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 02 02 02 FF 00 0E 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 02 02 02 FF 00 02 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 03 02 02 01 FF 00 1D 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 02 02 02 43 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 03 02 02 07 00 03 45 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 03 02 02 02 43 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 04 02 02 02 07 00 03 45 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 04 02 02 02 02 FF 00 12 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 06 02 02 02 02 02 07 01 0E FF 00 02 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 07 02 02 02 02 02 07 01 0E 01 FF 00 1D 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 06 02 02 02 02 02 07 01 0E 42 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 06 02 02 02 02 02 07 01 0E 45 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 06 02 02 02 02 02 01 FF 00 0B 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 06 02 02 02 02 02 01 FF 00 02 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 07 02 02 02 02 02 01 01 FF 00 1D 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 06 02 02 02 02 02 01 FF 00 02 00 00 00 01 07 00 2F FF 00 00 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 06 02 02 02 02 02 01 45 07 00 2F 00 FF 00 00 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 02 07 00 69 07 00 6E FF 00 01 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 01 07 00 B8 41 07 00 03 FF 00 01 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 03 07 00 69 08 02 4A 08 02 4A FF 00 01 00 06 07 00 03 07 01 2F 01 07 01 31 02 02 00 01 01 FF 00 01 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 00 FF 00 01 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 04 02 02 02 07 00 03 FF 00 01 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 01 01 01 01 FF 00 01 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 02 02 02 FF 00 01 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 03 07 00 69 08 01 CE 08 01 CE FF 00 01 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 06 02 02 02 02 02 07 01 0E 41 01 FF 00 01 00 0C 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 00 01 01 FF 00 01 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 04 07 00 69 08 02 9D 08 02 9D 07 01 33 FF 00 01 00 08 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 00 02 07 00 31 07 01 33 FE 00 01 01 01 07 00 69 FF 00 01 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 02 07 00 BF 02 FF 00 01 00 0A 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 00 02 08 01 6A 08 01 6A FE 00 01 07 00 69 01 01 41 01 FF 00 01 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 01 07 00 B8 FF 00 01 00 08 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 00 01 01 FA 00 01 FF 00 01 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 02 02 02 FF 00 01 00 09 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 00 01 07 00 31 41 01 FF 00 01 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 03 07 00 BF 07 00 6E 01 FF 00 01 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 06 02 02 02 02 02 01 FF 00 01 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 01 01 FF 00 01 00 10 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 01 01 07 00 6E 00 04 07 00 BF 07 01 37 07 00 6E 01 FF 00 01 00 0D 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 01 01 00 06 02 02 02 02 02 01 FF 00 01 00 0B 07 00 03 07 01 2F 01 07 01 31 02 02 01 01 01 01 07 00 69 00 06 07 00 69 08 02 F2 08 02 F2 07 01 33 01 01 FF 00 01 00 06 07 00 03 07 01 2F 01 07 01 31 02 02 00 01 07 00 16 43 05 44 07 00 16 47 05 47 07 00 2F
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     2381   2389   Ljava/lang/NullPointerException;
        //  2381   2389   2381   2389   Ljava/lang/IllegalStateException;
        //  2397   2399   3      8      Any
        //  35     42     42     43     Any
        //  35     42     35     36     Ljava/lang/IndexOutOfBoundsException;
        //  36     42     3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  36     42     35     36     Ljava/lang/EnumConstantNotPresentException;
        //  36     42     42     43     Ljava/util/NoSuchElementException;
        //  139    146    146    147    Any
        //  139    146    139    140    Ljava/lang/RuntimeException;
        //  140    146    139    140    Any
        //  139    146    146    147    Any
        //  140    146    146    147    Any
        //  203    210    210    211    Any
        //  203    210    210    211    Any
        //  204    210    210    211    Ljava/lang/IllegalArgumentException;
        //  204    210    3      8      Ljava/lang/UnsupportedOperationException;
        //  204    210    203    204    Any
        //  308    315    315    316    Any
        //  308    315    3      8      Ljava/lang/UnsupportedOperationException;
        //  308    315    308    309    Ljava/lang/NullPointerException;
        //  309    315    315    316    Ljava/lang/ClassCastException;
        //  308    315    3      8      Any
        //  411    418    418    419    Any
        //  412    418    418    419    Ljava/util/NoSuchElementException;
        //  411    418    418    419    Any
        //  412    418    411    412    Ljava/lang/ArithmeticException;
        //  411    418    418    419    Any
        //  516    523    523    524    Any
        //  517    523    3      8      Ljava/lang/NumberFormatException;
        //  516    523    3      8      Ljava/lang/NegativeArraySizeException;
        //  517    523    516    517    Ljava/lang/EnumConstantNotPresentException;
        //  516    523    516    517    Any
        //  527    536    536    537    Any
        //  527    536    527    528    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  528    536    536    537    Ljava/util/NoSuchElementException;
        //  528    536    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  528    536    527    528    Any
        //  640    647    647    648    Any
        //  641    647    640    641    Any
        //  641    647    640    641    Any
        //  641    647    640    641    Any
        //  641    647    640    641    Any
        //  651    660    660    661    Any
        //  651    660    660    661    Any
        //  651    660    660    661    Any
        //  651    660    651    652    Ljava/util/NoSuchElementException;
        //  652    660    651    652    Any
        //  725    732    732    733    Any
        //  725    732    725    726    Ljava/lang/ArithmeticException;
        //  726    732    3      8      Any
        //  726    732    3      8      Any
        //  726    732    732    733    Any
        //  736    745    745    746    Any
        //  736    745    736    737    Any
        //  736    745    745    746    Any
        //  736    745    745    746    Ljava/lang/IndexOutOfBoundsException;
        //  737    745    736    737    Ljava/lang/NegativeArraySizeException;
        //  811    818    818    819    Any
        //  811    818    3      8      Any
        //  812    818    811    812    Any
        //  812    818    818    819    Ljava/lang/ClassCastException;
        //  811    818    818    819    Any
        //  863    872    872    873    Any
        //  863    872    863    864    Ljava/lang/EnumConstantNotPresentException;
        //  863    872    3      8      Any
        //  863    872    872    873    Ljava/lang/StringIndexOutOfBoundsException;
        //  863    872    863    864    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  886    894    894    895    Any
        //  886    894    894    895    Any
        //  886    894    894    895    Any
        //  886    894    894    895    Any
        //  886    894    894    895    Any
        //  1032   1039   1039   1040   Any
        //  1033   1039   1039   1040   Any
        //  1033   1039   1039   1040   Ljava/util/NoSuchElementException;
        //  1033   1039   1039   1040   Any
        //  1033   1039   1032   1033   Ljava/lang/IndexOutOfBoundsException;
        //  1087   1094   1094   1095   Any
        //  1087   1094   3      8      Ljava/lang/AssertionError;
        //  1087   1094   1087   1088   Ljava/util/NoSuchElementException;
        //  1087   1094   1094   1095   Ljava/lang/EnumConstantNotPresentException;
        //  1087   1094   1094   1095   Any
        //  1101   1108   1108   1109   Any
        //  1101   1108   1101   1102   Any
        //  1102   1108   3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  1101   1108   1108   1109   Ljava/lang/ArithmeticException;
        //  1101   1108   1108   1109   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1112   1119   1119   1120   Any
        //  1112   1119   3      8      Any
        //  1112   1119   1112   1113   Any
        //  1112   1119   1112   1113   Ljava/lang/NumberFormatException;
        //  1112   1119   3      8      Any
        //  1172   1178   1178   1179   Any
        //  1172   1178   3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  1172   1178   1178   1179   Ljava/lang/NegativeArraySizeException;
        //  1172   1178   1178   1179   Ljava/lang/EnumConstantNotPresentException;
        //  1172   1178   3      8      Ljava/lang/ArithmeticException;
        //  1187   1194   1194   1195   Any
        //  1188   1194   1194   1195   Ljava/util/ConcurrentModificationException;
        //  1187   1194   1187   1188   Ljava/util/NoSuchElementException;
        //  1187   1194   1194   1195   Ljava/lang/EnumConstantNotPresentException;
        //  1187   1194   1194   1195   Ljava/lang/NullPointerException;
        //  1198   1205   1205   1206   Any
        //  1199   1205   3      8      Ljava/lang/AssertionError;
        //  1198   1205   1198   1199   Any
        //  1198   1205   3      8      Any
        //  1199   1205   1198   1199   Ljava/lang/NumberFormatException;
        //  1209   1216   1216   1217   Any
        //  1209   1216   1209   1210   Ljava/lang/AssertionError;
        //  1209   1216   1216   1217   Ljava/util/ConcurrentModificationException;
        //  1210   1216   3      8      Any
        //  1210   1216   3      8      Ljava/lang/RuntimeException;
        //  1231   1239   1239   1240   Any
        //  1231   1239   1239   1240   Ljava/lang/NegativeArraySizeException;
        //  1231   1239   1239   1240   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1231   1239   1239   1240   Ljava/lang/IllegalArgumentException;
        //  1231   1239   1239   1240   Ljava/lang/IllegalArgumentException;
        //  1440   1447   1447   1448   Any
        //  1440   1447   3      8      Ljava/util/ConcurrentModificationException;
        //  1440   1447   1440   1441   Ljava/lang/NullPointerException;
        //  1441   1447   3      8      Ljava/lang/ArithmeticException;
        //  1441   1447   3      8      Ljava/util/ConcurrentModificationException;
        //  1503   1510   1510   1511   Any
        //  1504   1510   1510   1511   Ljava/util/NoSuchElementException;
        //  1503   1510   1510   1511   Ljava/lang/ClassCastException;
        //  1504   1510   1510   1511   Ljava/lang/NegativeArraySizeException;
        //  1504   1510   1503   1504   Ljava/lang/EnumConstantNotPresentException;
        //  1563   1570   1570   1571   Any
        //  1563   1570   1570   1571   Any
        //  1563   1570   1563   1564   Any
        //  1563   1570   1570   1571   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1563   1570   1570   1571   Ljava/lang/IndexOutOfBoundsException;
        //  1632   1638   1638   1639   Any
        //  1632   1638   1638   1639   Any
        //  1632   1638   1638   1639   Any
        //  1632   1638   1638   1639   Any
        //  1632   1638   1638   1639   Any
        //  1647   1654   1654   1655   Any
        //  1647   1654   3      8      Any
        //  1647   1654   1654   1655   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1648   1654   1647   1648   Any
        //  1648   1654   1654   1655   Any
        //  1707   1713   1713   1714   Any
        //  1707   1713   3      8      Any
        //  1707   1713   1713   1714   Ljava/lang/IndexOutOfBoundsException;
        //  1707   1713   1713   1714   Ljava/util/ConcurrentModificationException;
        //  1707   1713   1713   1714   Ljava/lang/ArithmeticException;
        //  1717   1724   1724   1725   Any
        //  1718   1724   1724   1725   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1718   1724   3      8      Any
        //  1717   1724   1717   1718   Ljava/lang/StringIndexOutOfBoundsException;
        //  1718   1724   1717   1718   Ljava/lang/ArithmeticException;
        //  1771   1778   1778   1779   Any
        //  1772   1778   1778   1779   Any
        //  1771   1778   3      8      Ljava/lang/AssertionError;
        //  1771   1778   1778   1779   Ljava/lang/AssertionError;
        //  1772   1778   1771   1772   Ljava/lang/NegativeArraySizeException;
        //  1782   1789   1789   1790   Any
        //  1783   1789   3      8      Any
        //  1782   1789   1782   1783   Ljava/lang/AssertionError;
        //  1782   1789   3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  1782   1789   3      8      Any
        //  1848   1855   1855   1856   Any
        //  1849   1855   1848   1849   Ljava/util/ConcurrentModificationException;
        //  1849   1855   1848   1849   Ljava/lang/IndexOutOfBoundsException;
        //  1848   1855   3      8      Any
        //  1848   1855   1848   1849   Ljava/lang/IllegalArgumentException;
        //  1860   1867   1867   1868   Any
        //  1860   1867   3      8      Any
        //  1861   1867   1860   1861   Any
        //  1860   1867   3      8      Ljava/util/NoSuchElementException;
        //  1861   1867   1860   1861   Any
        //  1875   1882   1882   1883   Any
        //  1875   1882   3      8      Any
        //  1876   1882   3      8      Ljava/lang/NegativeArraySizeException;
        //  1875   1882   3      8      Ljava/lang/UnsupportedOperationException;
        //  1875   1882   1875   1876   Ljava/lang/StringIndexOutOfBoundsException;
        //  1887   1893   1893   1894   Any
        //  1887   1893   3      8      Any
        //  1887   1893   3      8      Ljava/util/NoSuchElementException;
        //  1887   1893   1893   1894   Ljava/lang/AssertionError;
        //  1887   1893   3      8      Any
        //  1944   1950   1950   1951   Any
        //  1944   1950   1950   1951   Ljava/lang/ArithmeticException;
        //  1944   1950   3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1944   1950   1950   1951   Any
        //  1944   1950   3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  1960   1966   1966   1967   Any
        //  1960   1966   1966   1967   Any
        //  1960   1966   1966   1967   Ljava/lang/NullPointerException;
        //  1960   1966   1966   1967   Any
        //  1960   1966   3      8      Ljava/lang/NullPointerException;
        //  2019   2026   2026   2027   Any
        //  2019   2026   3      8      Any
        //  2020   2026   2019   2020   Ljava/lang/UnsupportedOperationException;
        //  2019   2026   2026   2027   Any
        //  2020   2026   2019   2020   Ljava/lang/IndexOutOfBoundsException;
        //  2035   2041   2041   2042   Any
        //  2035   2041   3      8      Ljava/lang/IndexOutOfBoundsException;
        //  2035   2041   2041   2042   Ljava/lang/NumberFormatException;
        //  2035   2041   2041   2042   Any
        //  2035   2041   3      8      Ljava/lang/AssertionError;
        //  2091   2098   2098   2099   Any
        //  2091   2098   2091   2092   Any
        //  2092   2098   2091   2092   Any
        //  2092   2098   3      8      Any
        //  2092   2098   2091   2092   Ljava/lang/NegativeArraySizeException;
        //  2105   2111   2111   2112   Any
        //  2105   2111   3      8      Ljava/lang/AssertionError;
        //  2105   2111   2111   2112   Ljava/lang/ClassCastException;
        //  2105   2111   2111   2112   Any
        //  2105   2111   3      8      Any
        //  2164   2171   2171   2172   Any
        //  2165   2171   2171   2172   Any
        //  2165   2171   2164   2165   Any
        //  2164   2171   3      8      Any
        //  2164   2171   3      8      Any
        //  2176   2183   2183   2184   Any
        //  2176   2183   3      8      Any
        //  2176   2183   2176   2177   Any
        //  2176   2183   3      8      Any
        //  2177   2183   2176   2177   Ljava/lang/IndexOutOfBoundsException;
        //  2239   2246   2246   2247   Any
        //  2240   2246   3      8      Ljava/lang/IllegalStateException;
        //  2240   2246   2239   2240   Any
        //  2239   2246   2246   2247   Any
        //  2240   2246   3      8      Ljava/lang/IllegalArgumentException;
        //  2296   2302   2302   2303   Any
        //  2296   2302   2302   2303   Ljava/util/ConcurrentModificationException;
        //  2296   2302   2302   2303   Ljava/lang/ArithmeticException;
        //  2296   2302   3      8      Ljava/lang/RuntimeException;
        //  2296   2302   3      8      Ljava/lang/NumberFormatException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visitVariable(StackMappingVisitor.java:470)
        //     at com.strobel.assembler.ir.Instruction.accept(Instruction.java:556)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:403)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public f5P() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: ldc_w           "\u3d72\ub24a\u8e24\uadad\u675e\u5989\u7e68\u6932\uc2c7"
        //     4: invokestatic    invokestatic   !!! ERROR
        //     7: aconst_null    
        //     8: iconst_2       
        //     9: aconst_null    
        //    10: invokespecial   dev/nuker/pyro/f5q.<init>:(Ljava/lang/String;Ljava/lang/String;ILkotlin/jvm/internal/DefaultConstructorMarker;)V
        //    13: return         
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2695)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public float 5() {
        return fez.eh(this, 1119652294);
    }
    
    @Override
    public float 0() {
        return fez.eF(this, 846884159);
    }
    
    static {
        throw t;
    }
    
    @Override
    public boolean 1() {
        return fez.h1(this, 1413084282);
    }
}
