// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.util.math.BlockPos;
import dev.nuker.pyro.security.inject.LauncherEventHide;

public class f9u extends fQ
{
    public f0o<f9t> c;
    public f0k c;
    public boolean c;
    public float c;
    
    static {
        throw t;
    }
    
    public boolean 1() {
        return fez.hJ(this, 1272632666);
    }
    
    @f0g
    @LauncherEventHide
    public void c(final f4t p0) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          2547
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            2539
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            2531
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_0        
        //    25: getfield        dev/nuker/pyro/f9u.c:Ldev/nuker/pyro/f0k;
        //    28: goto            32
        //    31: athrow         
        //    32: invokevirtual   dev/nuker/pyro/f0k.c:()Ljava/lang/Object;
        //    35: goto            39
        //    38: athrow         
        //    39: checkcast       Ljava/lang/Boolean;
        //    42: getstatic       dev/nuker/pyro/fc.0:I
        //    45: ifgt            53
        //    48: ldc             -1627946951
        //    50: goto            55
        //    53: ldc             880464089
        //    55: ldc             1345392797
        //    57: ixor           
        //    58: lookupswitch {
        //          -825847644: 2494
        //          383398908: 53
        //          default: 84
        //        }
        //    84: goto            88
        //    87: athrow         
        //    88: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //    91: goto            95
        //    94: athrow         
        //    95: ifeq            326
        //    98: aload_0        
        //    99: new             Ljava/lang/StringBuilder;
        //   102: dup            
        //   103: getstatic       dev/nuker/pyro/fc.0:I
        //   106: ifgt            114
        //   109: ldc             327751656
        //   111: goto            116
        //   114: ldc             1154157430
        //   116: ldc             -1778250844
        //   118: ixor           
        //   119: lookupswitch {
        //          -2054480820: 2466
        //          -1820066274: 114
        //          default: 144
        //        }
        //   144: goto            148
        //   147: athrow         
        //   148: invokespecial   java/lang/StringBuilder.<init>:()V
        //   151: goto            155
        //   154: athrow         
        //   155: getstatic       dev/nuker/pyro/fc.0:I
        //   158: ifgt            166
        //   161: ldc             -66433755
        //   163: goto            168
        //   166: ldc             1287808759
        //   168: ldc             -1928559712
        //   170: ixor           
        //   171: lookupswitch {
        //          -798584424: 166
        //          1896271493: 2476
        //          default: 196
        //        }
        //   196: aload_0        
        //   197: getfield        dev/nuker/pyro/f9u.c:Ldev/nuker/pyro/f0o;
        //   200: getstatic       dev/nuker/pyro/fc.c:I
        //   203: ifne            211
        //   206: ldc             -351693388
        //   208: goto            213
        //   211: ldc             -2009854960
        //   213: ldc             699199937
        //   215: ixor           
        //   216: lookupswitch {
        //          -1583809071: 244
        //          -1029348235: 211
        //          default: 2504
        //        }
        //   244: goto            248
        //   247: athrow         
        //   248: invokevirtual   dev/nuker/pyro/f0o.c:()Ljava/lang/Object;
        //   251: goto            255
        //   254: athrow         
        //   255: goto            259
        //   258: athrow         
        //   259: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   262: goto            266
        //   265: athrow         
        //   266: goto            270
        //   269: athrow         
        //   270: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   273: goto            277
        //   276: athrow         
        //   277: ldc             "\u3c85\ub276\u8f9b\uafa7\u61ca\u5823\u7e54"
        //   279: goto            283
        //   282: athrow         
        //   283: invokestatic    invokestatic   !!! ERROR
        //   286: goto            290
        //   289: athrow         
        //   290: goto            294
        //   293: athrow         
        //   294: invokevirtual   java/lang/StringBuilder.append:(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   297: goto            301
        //   300: athrow         
        //   301: goto            305
        //   304: athrow         
        //   305: invokevirtual   java/lang/StringBuilder.toString:()Ljava/lang/String;
        //   308: goto            312
        //   311: athrow         
        //   312: goto            316
        //   315: athrow         
        //   316: invokevirtual   dev/nuker/pyro/f9u.5:(Ljava/lang/String;)V
        //   319: goto            323
        //   322: athrow         
        //   323: goto            364
        //   326: aload_0        
        //   327: aload_0        
        //   328: getfield        dev/nuker/pyro/f9u.c:Ldev/nuker/pyro/f0o;
        //   331: goto            335
        //   334: athrow         
        //   335: invokevirtual   dev/nuker/pyro/f0o.c:()Ljava/lang/Object;
        //   338: goto            342
        //   341: athrow         
        //   342: goto            346
        //   345: athrow         
        //   346: invokestatic    java/lang/String.valueOf:(Ljava/lang/Object;)Ljava/lang/String;
        //   349: goto            353
        //   352: athrow         
        //   353: goto            357
        //   356: athrow         
        //   357: invokevirtual   dev/nuker/pyro/f9u.5:(Ljava/lang/String;)V
        //   360: goto            364
        //   363: athrow         
        //   364: getstatic       dev/nuker/pyro/f9s.c:[I
        //   367: getstatic       dev/nuker/pyro/fc.1:I
        //   370: ifne            378
        //   373: ldc             1249098980
        //   375: goto            380
        //   378: ldc             -157083113
        //   380: ldc             -478200558
        //   382: ixor           
        //   383: lookupswitch {
        //          -1458798090: 2492
        //          83963401: 378
        //          default: 408
        //        }
        //   408: aload_0        
        //   409: getstatic       dev/nuker/pyro/fc.c:I
        //   412: ifne            420
        //   415: ldc             1051367008
        //   417: goto            422
        //   420: ldc             -687819678
        //   422: ldc             -1022401942
        //   424: ixor           
        //   425: lookupswitch {
        //          -1839121474: 420
        //          -39455734: 2472
        //          default: 452
        //        }
        //   452: getfield        dev/nuker/pyro/f9u.c:Ldev/nuker/pyro/f0o;
        //   455: getstatic       dev/nuker/pyro/fc.0:I
        //   458: ifgt            466
        //   461: ldc             1765926497
        //   463: goto            468
        //   466: ldc             -345432020
        //   468: ldc             -1439864092
        //   470: ixor           
        //   471: lookupswitch {
        //          -1016296315: 466
        //          1094994632: 496
        //          default: 2460
        //        }
        //   496: goto            500
        //   499: athrow         
        //   500: invokevirtual   dev/nuker/pyro/f0o.c:()Ljava/lang/Object;
        //   503: goto            507
        //   506: athrow         
        //   507: checkcast       Ldev/nuker/pyro/f9t;
        //   510: goto            514
        //   513: athrow         
        //   514: invokevirtual   dev/nuker/pyro/f9t.ordinal:()I
        //   517: goto            521
        //   520: athrow         
        //   521: iaload         
        //   522: tableswitch {
        //                2: 548
        //                3: 548
        //                4: 877
        //          default: 2457
        //        }
        //   548: aload_0        
        //   549: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //   552: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   555: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71158_b:Lnet/minecraft/util/MovementInput;
        //   558: getfield        net/minecraft/util/MovementInput.field_78899_d:Z
        //   561: ifne            779
        //   564: aload_0        
        //   565: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //   568: getstatic       dev/nuker/pyro/fc.0:I
        //   571: ifgt            579
        //   574: ldc             -1390428456
        //   576: goto            581
        //   579: ldc             1889047612
        //   581: ldc             1562941186
        //   583: ixor           
        //   584: lookupswitch {
        //          -264820262: 579
        //          766509886: 612
        //          default: 2478
        //        }
        //   612: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   615: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71158_b:Lnet/minecraft/util/MovementInput;
        //   618: getstatic       dev/nuker/pyro/fc.0:I
        //   621: ifgt            629
        //   624: ldc             384345489
        //   626: goto            631
        //   629: ldc             -407499168
        //   631: ldc             2117578614
        //   633: ixor           
        //   634: lookupswitch {
        //          -1719557866: 660
        //          1759447783: 629
        //          default: 2468
        //        }
        //   660: getfield        net/minecraft/util/MovementInput.field_78901_c:Z
        //   663: ifne            779
        //   666: aload_0        
        //   667: goto            671
        //   670: athrow         
        //   671: invokevirtual   dev/nuker/pyro/f9u.c:()Z
        //   674: goto            678
        //   677: athrow         
        //   678: ifeq            779
        //   681: aload_0        
        //   682: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //   685: getstatic       dev/nuker/pyro/fc.1:I
        //   688: ifne            696
        //   691: ldc             1008490000
        //   693: goto            698
        //   696: ldc             1072621859
        //   698: ldc             -1132607281
        //   700: ixor           
        //   701: lookupswitch {
        //          -2141085985: 2506
        //          1481471674: 696
        //          default: 728
        //        }
        //   728: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   731: ldc2_w          0.10000000149011612
        //   734: getstatic       dev/nuker/pyro/fc.c:I
        //   737: ifne            745
        //   740: ldc             1775218012
        //   742: goto            747
        //   745: ldc             36500941
        //   747: ldc             -886030651
        //   749: ixor           
        //   750: lookupswitch {
        //          -1560308839: 745
        //          -920859896: 776
        //          default: 2474
        //        }
        //   776: putfield        net/minecraft/client/entity/EntityPlayerSP.field_70181_x:D
        //   779: aload_0        
        //   780: getfield        dev/nuker/pyro/f9u.c:Ldev/nuker/pyro/f0k;
        //   783: goto            787
        //   786: athrow         
        //   787: invokevirtual   dev/nuker/pyro/f0k.c:()Ljava/lang/Object;
        //   790: goto            794
        //   793: athrow         
        //   794: checkcast       Ljava/lang/Boolean;
        //   797: getstatic       dev/nuker/pyro/fc.c:I
        //   800: ifne            808
        //   803: ldc             -1134391865
        //   805: goto            810
        //   808: ldc             -1043384765
        //   810: ldc             -1677264804
        //   812: ixor           
        //   813: lookupswitch {
        //          543454619: 808
        //          1573506591: 840
        //          default: 2510
        //        }
        //   840: goto            844
        //   843: athrow         
        //   844: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   847: goto            851
        //   850: athrow         
        //   851: ifeq            2457
        //   854: aload_0        
        //   855: goto            859
        //   858: athrow         
        //   859: invokevirtual   dev/nuker/pyro/f9u.1:()Z
        //   862: goto            866
        //   865: athrow         
        //   866: ifne            2457
        //   869: aload_0        
        //   870: fconst_0       
        //   871: putfield        dev/nuker/pyro/f9u.c:F
        //   874: goto            2457
        //   877: aload_0        
        //   878: getstatic       dev/nuker/pyro/fc.c:I
        //   881: ifne            889
        //   884: ldc             -1024519539
        //   886: goto            891
        //   889: ldc             1343380905
        //   891: ldc             1491966449
        //   893: ixor           
        //   894: lookupswitch {
        //          -1711109252: 889
        //          150979672: 920
        //          default: 2498
        //        }
        //   920: goto            924
        //   923: athrow         
        //   924: invokevirtual   dev/nuker/pyro/f9u.c:()Z
        //   927: goto            931
        //   930: athrow         
        //   931: ifeq            1094
        //   934: getstatic       dev/nuker/pyro/fc.1:I
        //   937: ifne            945
        //   940: ldc             348533663
        //   942: goto            947
        //   945: ldc             1740252242
        //   947: ldc             -358486865
        //   949: ixor           
        //   950: lookupswitch {
        //          -1337858423: 945
        //          -26747088: 2502
        //          default: 976
        //        }
        //   976: aload_0        
        //   977: getstatic       dev/nuker/pyro/fc.c:I
        //   980: ifne            988
        //   983: ldc             190181752
        //   985: goto            990
        //   988: ldc             2015920409
        //   990: ldc             -314050236
        //   992: ixor           
        //   993: lookupswitch {
        //          -435025860: 2482
        //          1147643247: 988
        //          default: 1020
        //        }
        //  1020: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  1023: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1026: goto            1030
        //  1029: athrow         
        //  1030: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_70093_af:()Z
        //  1033: goto            1037
        //  1036: athrow         
        //  1037: ifne            1094
        //  1040: aload_0        
        //  1041: getstatic       dev/nuker/pyro/fc.1:I
        //  1044: ifne            1052
        //  1047: ldc             -538779229
        //  1049: goto            1054
        //  1052: ldc             1881858288
        //  1054: ldc             583490416
        //  1056: ixor           
        //  1057: lookupswitch {
        //          -47858989: 2500
        //          1465789972: 1052
        //          default: 1084
        //        }
        //  1084: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  1087: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1090: iconst_0       
        //  1091: putfield        net/minecraft/client/entity/EntityPlayerSP.field_70122_E:Z
        //  1094: new             Lnet/minecraft/util/math/BlockPos;
        //  1097: dup            
        //  1098: aload_0        
        //  1099: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  1102: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1105: getstatic       dev/nuker/pyro/fc.c:I
        //  1108: ifne            1116
        //  1111: ldc             1085912130
        //  1113: goto            1118
        //  1116: ldc             309967622
        //  1118: ldc             919104525
        //  1120: ixor           
        //  1121: lookupswitch {
        //          615634699: 1148
        //          1987172431: 1116
        //          default: 2518
        //        }
        //  1148: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70165_t:D
        //  1151: goto            1155
        //  1154: athrow         
        //  1155: invokestatic    java/lang/Math.floor:(D)D
        //  1158: goto            1162
        //  1161: athrow         
        //  1162: aload_0        
        //  1163: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  1166: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1169: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70163_u:D
        //  1172: goto            1176
        //  1175: athrow         
        //  1176: invokestatic    java/lang/Math.floor:(D)D
        //  1179: goto            1183
        //  1182: athrow         
        //  1183: aload_0        
        //  1184: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  1187: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1190: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70161_v:D
        //  1193: goto            1197
        //  1196: athrow         
        //  1197: invokestatic    java/lang/Math.floor:(D)D
        //  1200: goto            1204
        //  1203: athrow         
        //  1204: goto            1208
        //  1207: athrow         
        //  1208: invokespecial   net/minecraft/util/math/BlockPos.<init>:(DDD)V
        //  1211: goto            1215
        //  1214: athrow         
        //  1215: goto            1219
        //  1218: athrow         
        //  1219: invokestatic    dev/nuker/pyro/feg.5:(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/Block;
        //  1222: goto            1226
        //  1225: athrow         
        //  1226: astore_2       
        //  1227: aload_0        
        //  1228: getfield        dev/nuker/pyro/f9u.c:Z
        //  1231: ifeq            1838
        //  1234: aload_0        
        //  1235: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  1238: getstatic       dev/nuker/pyro/fc.1:I
        //  1241: ifne            1249
        //  1244: ldc             -72290292
        //  1246: goto            1251
        //  1249: ldc             1873272150
        //  1251: ldc             -1269718712
        //  1253: ixor           
        //  1254: lookupswitch {
        //          -604603362: 1280
        //          1340166468: 1249
        //          default: 2480
        //        }
        //  1280: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1283: getstatic       dev/nuker/pyro/fc.c:I
        //  1286: ifne            1294
        //  1289: ldc             1753040135
        //  1291: goto            1296
        //  1294: ldc             30054973
        //  1296: ldc             -363243956
        //  1298: ixor           
        //  1299: lookupswitch {
        //          -2111564981: 1294
        //          -342635407: 1324
        //          default: 2488
        //        }
        //  1324: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71075_bZ:Lnet/minecraft/entity/player/PlayerCapabilities;
        //  1327: getfield        net/minecraft/entity/player/PlayerCapabilities.field_75100_b:Z
        //  1330: ifne            1339
        //  1333: ldc_w           1426165157
        //  1336: goto            1342
        //  1339: ldc_w           1426165156
        //  1342: ldc_w           226473433
        //  1345: ixor           
        //  1346: tableswitch {
        //          -1325633288: 1368
        //          -1325633287: 1838
        //          default: 1333
        //        }
        //  1368: getstatic       dev/nuker/pyro/fc.0:I
        //  1371: ifgt            1380
        //  1374: ldc_w           -183398084
        //  1377: goto            1383
        //  1380: ldc_w           127816611
        //  1383: ldc_w           -687947315
        //  1386: ixor           
        //  1387: lookupswitch {
        //          -782200210: 1412
        //          602886385: 1380
        //          default: 2514
        //        }
        //  1412: aload_0        
        //  1413: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  1416: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1419: goto            1423
        //  1422: athrow         
        //  1423: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_70090_H:()Z
        //  1426: goto            1430
        //  1429: athrow         
        //  1430: ifne            1838
        //  1433: aload_0        
        //  1434: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  1437: getstatic       dev/nuker/pyro/fc.c:I
        //  1440: ifne            1449
        //  1443: ldc_w           -752538747
        //  1446: goto            1452
        //  1449: ldc_w           -619819678
        //  1452: ldc_w           -1072604338
        //  1455: ixor           
        //  1456: lookupswitch {
        //          322203851: 1449
        //          455022124: 1484
        //          default: 2470
        //        }
        //  1484: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1487: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70181_x:D
        //  1490: ldc2_w          -0.3
        //  1493: dcmpg          
        //  1494: iflt            1692
        //  1497: aload_0        
        //  1498: getstatic       dev/nuker/pyro/fc.0:I
        //  1501: ifgt            1510
        //  1504: ldc_w           1228691792
        //  1507: goto            1513
        //  1510: ldc_w           1605814234
        //  1513: ldc_w           -208353923
        //  1516: ixor           
        //  1517: lookupswitch {
        //          -1163355091: 2516
        //          1361055586: 1510
        //          default: 1544
        //        }
        //  1544: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  1547: getstatic       dev/nuker/pyro/fc.c:I
        //  1550: ifne            1559
        //  1553: ldc_w           -1539367351
        //  1556: goto            1562
        //  1559: ldc_w           642197146
        //  1562: ldc_w           -350272044
        //  1565: ixor           
        //  1566: lookupswitch {
        //          1172552886: 1559
        //          1327520669: 2484
        //          default: 1592
        //        }
        //  1592: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1595: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70122_E:Z
        //  1598: ifne            1607
        //  1601: ldc_w           1752626812
        //  1604: goto            1610
        //  1607: ldc_w           1752626787
        //  1610: ldc_w           -1749424685
        //  1613: ixor           
        //  1614: tableswitch {
        //          -6412450: 1636
        //          -6412449: 1692
        //          default: 1601
        //        }
        //  1636: aload_0        
        //  1637: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  1640: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1643: goto            1647
        //  1646: athrow         
        //  1647: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_70617_f_:()Z
        //  1650: goto            1654
        //  1653: athrow         
        //  1654: ifeq            1663
        //  1657: ldc_w           46984640
        //  1660: goto            1666
        //  1663: ldc_w           46984643
        //  1666: ldc_w           -1189950183
        //  1669: ixor           
        //  1670: tableswitch {
        //          2008826290: 1692
        //          2008826291: 1698
        //          default: 1657
        //        }
        //  1692: aload_0        
        //  1693: iconst_0       
        //  1694: putfield        dev/nuker/pyro/f9u.c:Z
        //  1697: return         
        //  1698: aload_0        
        //  1699: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  1702: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1705: getstatic       dev/nuker/pyro/fc.1:I
        //  1708: ifne            1717
        //  1711: ldc_w           -875275900
        //  1714: goto            1720
        //  1717: ldc_w           696730887
        //  1720: ldc_w           -1312475127
        //  1723: ixor           
        //  1724: lookupswitch {
        //          1936999866: 1717
        //          2047959437: 2512
        //          default: 1752
        //        }
        //  1752: aload_0        
        //  1753: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  1756: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1759: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70181_x:D
        //  1762: ldc2_w          0.9800000190734863
        //  1765: ddiv           
        //  1766: ldc2_w          0.08
        //  1769: dadd           
        //  1770: putfield        net/minecraft/client/entity/EntityPlayerSP.field_70181_x:D
        //  1773: aload_0        
        //  1774: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  1777: getstatic       dev/nuker/pyro/fc.0:I
        //  1780: ifgt            1789
        //  1783: ldc_w           -274640307
        //  1786: goto            1792
        //  1789: ldc_w           716904245
        //  1792: ldc_w           -1176445302
        //  1795: ixor           
        //  1796: lookupswitch {
        //          -1822701121: 1824
        //          1447136455: 1789
        //          default: 2458
        //        }
        //  1824: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1827: dup            
        //  1828: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70181_x:D
        //  1831: ldc2_w          0.03120000000005
        //  1834: dsub           
        //  1835: putfield        net/minecraft/client/entity/EntityPlayerSP.field_70181_x:D
        //  1838: aload_0        
        //  1839: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  1842: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1845: goto            1849
        //  1848: athrow         
        //  1849: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_70090_H:()Z
        //  1852: goto            1856
        //  1855: athrow         
        //  1856: ifne            1865
        //  1859: ldc_w           1589970775
        //  1862: goto            1868
        //  1865: ldc_w           1589970768
        //  1868: ldc_w           1018591172
        //  1871: ixor           
        //  1872: tableswitch {
        //          -991502042: 1896
        //          -991502041: 1996
        //          default: 1859
        //        }
        //  1896: aload_0        
        //  1897: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  1900: getstatic       dev/nuker/pyro/fc.1:I
        //  1903: ifne            1912
        //  1906: ldc_w           1391096089
        //  1909: goto            1915
        //  1912: ldc_w           208889839
        //  1915: ldc_w           -915533296
        //  1918: ixor           
        //  1919: lookupswitch {
        //          -1685822711: 1912
        //          -987924993: 1944
        //          default: 2464
        //        }
        //  1944: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1947: goto            1951
        //  1950: athrow         
        //  1951: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_180799_ab:()Z
        //  1954: goto            1958
        //  1957: athrow         
        //  1958: ifeq            1967
        //  1961: ldc_w           1128707702
        //  1964: goto            1970
        //  1967: ldc_w           1128707701
        //  1970: ldc_w           7582255
        //  1973: ixor           
        //  1974: tableswitch {
        //          -2039871310: 1996
        //          -2039871309: 2103
        //          default: 1961
        //        }
        //  1996: getstatic       dev/nuker/pyro/fc.0:I
        //  1999: ifgt            2008
        //  2002: ldc_w           1450845131
        //  2005: goto            2011
        //  2008: ldc_w           -1804022414
        //  2011: ldc_w           1292707008
        //  2014: ixor           
        //  2015: lookupswitch {
        //          -646583886: 2040
        //          460785419: 2008
        //          default: 2490
        //        }
        //  2040: aload_0        
        //  2041: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  2044: getstatic       dev/nuker/pyro/fc.0:I
        //  2047: ifgt            2056
        //  2050: ldc_w           781832189
        //  2053: goto            2059
        //  2056: ldc_w           1481818896
        //  2059: ldc_w           1611660644
        //  2062: ixor           
        //  2063: lookupswitch {
        //          -2112317631: 2056
        //          1318466201: 2462
        //          default: 2088
        //        }
        //  2088: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  2091: ldc2_w          0.10000000149011612
        //  2094: putfield        net/minecraft/client/entity/EntityPlayerSP.field_70181_x:D
        //  2097: aload_0        
        //  2098: iconst_0       
        //  2099: putfield        dev/nuker/pyro/f9u.c:Z
        //  2102: return         
        //  2103: getstatic       dev/nuker/pyro/fc.c:I
        //  2106: ifne            2115
        //  2109: ldc_w           767076408
        //  2112: goto            2118
        //  2115: ldc_w           -1174284775
        //  2118: ldc_w           1821222940
        //  2121: ixor           
        //  2122: lookupswitch {
        //          -675849171: 2115
        //          1093992484: 2520
        //          default: 2148
        //        }
        //  2148: aload_0        
        //  2149: getstatic       dev/nuker/pyro/fc.0:I
        //  2152: ifgt            2161
        //  2155: ldc_w           -819268117
        //  2158: goto            2164
        //  2161: ldc_w           -267392055
        //  2164: ldc_w           1282437459
        //  2167: ixor           
        //  2168: lookupswitch {
        //          -2091219784: 2161
        //          -1132488038: 2196
        //          default: 2496
        //        }
        //  2196: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  2199: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  2202: goto            2206
        //  2205: athrow         
        //  2206: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_180799_ab:()Z
        //  2209: goto            2213
        //  2212: athrow         
        //  2213: ifne            2457
        //  2216: aload_2        
        //  2217: instanceof      Lnet/minecraft/block/BlockLiquid;
        //  2220: ifeq            2229
        //  2223: ldc_w           302106298
        //  2226: goto            2232
        //  2229: ldc_w           302106301
        //  2232: ldc_w           409784393
        //  2235: ixor           
        //  2236: tableswitch {
        //          349842918: 2260
        //          349842919: 2457
        //          default: 2223
        //        }
        //  2260: aload_0        
        //  2261: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  2264: getstatic       dev/nuker/pyro/fc.1:I
        //  2267: ifne            2276
        //  2270: ldc_w           1211507399
        //  2273: goto            2279
        //  2276: ldc_w           -1301434349
        //  2279: ldc_w           1136663523
        //  2282: ixor           
        //  2283: lookupswitch {
        //          200685860: 2486
        //          2053733260: 2276
        //          default: 2308
        //        }
        //  2308: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  2311: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70181_x:D
        //  2314: ldc2_w          0.20000000298023224
        //  2317: dcmpg          
        //  2318: ifge            2457
        //  2321: aload_0        
        //  2322: getstatic       dev/nuker/pyro/fc.0:I
        //  2325: ifgt            2334
        //  2328: ldc_w           1271507369
        //  2331: goto            2337
        //  2334: ldc_w           -468340335
        //  2337: ldc_w           1019512489
        //  2340: ixor           
        //  2341: lookupswitch {
        //          -1724620498: 2334
        //          1997352704: 2508
        //          default: 2368
        //        }
        //  2368: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  2371: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  2374: aload_0        
        //  2375: getfield        dev/nuker/pyro/f9u.c:Ldev/nuker/pyro/f0k;
        //  2378: goto            2382
        //  2381: athrow         
        //  2382: invokevirtual   dev/nuker/pyro/f0k.c:()Ljava/lang/Object;
        //  2385: goto            2389
        //  2388: athrow         
        //  2389: checkcast       Ljava/lang/Boolean;
        //  2392: goto            2396
        //  2395: athrow         
        //  2396: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //  2399: goto            2403
        //  2402: athrow         
        //  2403: ifne            2412
        //  2406: ldc_w           903047367
        //  2409: goto            2415
        //  2412: ldc_w           903047366
        //  2415: ldc_w           2053311681
        //  2418: ixor           
        //  2419: tableswitch {
        //          -1621047284: 2440
        //          -1621047283: 2446
        //          default: 2406
        //        }
        //  2440: ldc2_w          0.5
        //  2443: goto            2449
        //  2446: ldc2_w          0.184
        //  2449: putfield        net/minecraft/client/entity/EntityPlayerSP.field_70181_x:D
        //  2452: aload_0        
        //  2453: iconst_1       
        //  2454: putfield        dev/nuker/pyro/f9u.c:Z
        //  2457: return         
        //  2458: aconst_null    
        //  2459: athrow         
        //  2460: aconst_null    
        //  2461: athrow         
        //  2462: aconst_null    
        //  2463: athrow         
        //  2464: aconst_null    
        //  2465: athrow         
        //  2466: aconst_null    
        //  2467: athrow         
        //  2468: aconst_null    
        //  2469: athrow         
        //  2470: aconst_null    
        //  2471: athrow         
        //  2472: aconst_null    
        //  2473: athrow         
        //  2474: aconst_null    
        //  2475: athrow         
        //  2476: aconst_null    
        //  2477: athrow         
        //  2478: aconst_null    
        //  2479: athrow         
        //  2480: aconst_null    
        //  2481: athrow         
        //  2482: aconst_null    
        //  2483: athrow         
        //  2484: aconst_null    
        //  2485: athrow         
        //  2486: aconst_null    
        //  2487: athrow         
        //  2488: aconst_null    
        //  2489: athrow         
        //  2490: aconst_null    
        //  2491: athrow         
        //  2492: aconst_null    
        //  2493: athrow         
        //  2494: aconst_null    
        //  2495: athrow         
        //  2496: aconst_null    
        //  2497: athrow         
        //  2498: aconst_null    
        //  2499: athrow         
        //  2500: aconst_null    
        //  2501: athrow         
        //  2502: aconst_null    
        //  2503: athrow         
        //  2504: aconst_null    
        //  2505: athrow         
        //  2506: aconst_null    
        //  2507: athrow         
        //  2508: aconst_null    
        //  2509: athrow         
        //  2510: aconst_null    
        //  2511: athrow         
        //  2512: aconst_null    
        //  2513: athrow         
        //  2514: aconst_null    
        //  2515: athrow         
        //  2516: aconst_null    
        //  2517: athrow         
        //  2518: aconst_null    
        //  2519: athrow         
        //  2520: aconst_null    
        //  2521: athrow         
        //  2522: pop            
        //  2523: goto            24
        //  2526: pop            
        //  2527: aconst_null    
        //  2528: goto            2522
        //  2531: dup            
        //  2532: ifnull          2522
        //  2535: checkcast       Ljava/lang/Throwable;
        //  2538: athrow         
        //  2539: dup            
        //  2540: ifnull          2526
        //  2543: checkcast       Ljava/lang/Throwable;
        //  2546: athrow         
        //  2547: aconst_null    
        //  2548: athrow         
        //    StackMapTable: 01 34 43 07 00 40 04 FF 00 0B 00 00 00 01 07 00 40 FD 00 03 07 00 03 07 01 5D 46 07 00 40 40 07 00 44 45 07 00 40 40 07 01 5F 4D 07 00 49 FF 00 01 00 02 07 00 03 07 01 5D 00 02 07 00 49 01 5C 07 00 49 42 07 00 40 40 07 00 49 45 07 00 40 40 01 FF 00 12 00 02 07 00 03 07 01 5D 00 03 07 00 03 08 00 63 08 00 63 FF 00 01 00 02 07 00 03 07 01 5D 00 04 07 00 03 08 00 63 08 00 63 01 FF 00 1B 00 02 07 00 03 07 01 5D 00 03 07 00 03 08 00 63 08 00 63 42 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 03 07 00 03 08 00 63 08 00 63 45 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 02 07 00 03 07 00 54 FF 00 0A 00 02 07 00 03 07 01 5D 00 02 07 00 03 07 00 54 FF 00 01 00 02 07 00 03 07 01 5D 00 03 07 00 03 07 00 54 01 FF 00 1B 00 02 07 00 03 07 01 5D 00 02 07 00 03 07 00 54 FF 00 0E 00 02 07 00 03 07 01 5D 00 03 07 00 03 07 00 54 07 00 65 FF 00 01 00 02 07 00 03 07 01 5D 00 04 07 00 03 07 00 54 07 00 65 01 FF 00 1E 00 02 07 00 03 07 01 5D 00 03 07 00 03 07 00 54 07 00 65 42 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 03 07 00 03 07 00 54 07 00 65 45 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 03 07 00 03 07 00 54 07 01 5F FF 00 02 00 00 00 01 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 03 07 00 03 07 00 54 07 01 5F 45 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 03 07 00 03 07 00 54 07 00 68 42 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 03 07 00 03 07 00 54 07 00 68 45 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 02 07 00 03 07 00 54 44 07 00 1D FF 00 00 00 02 07 00 03 07 01 5D 00 03 07 00 03 07 00 54 07 00 68 45 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 03 07 00 03 07 00 54 07 00 68 42 07 00 39 FF 00 00 00 02 07 00 03 07 01 5D 00 03 07 00 03 07 00 54 07 00 68 45 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 02 07 00 03 07 00 54 42 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 02 07 00 03 07 00 54 45 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 02 07 00 03 07 00 68 42 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 02 07 00 03 07 00 68 45 07 00 40 00 02 47 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 02 07 00 03 07 00 65 45 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 02 07 00 03 07 01 5F 42 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 02 07 00 03 07 01 5F 45 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 02 07 00 03 07 00 68 42 07 00 23 FF 00 00 00 02 07 00 03 07 01 5D 00 02 07 00 03 07 00 68 45 07 00 40 00 4D 07 01 60 FF 00 01 00 02 07 00 03 07 01 5D 00 02 07 01 60 01 5B 07 01 60 FF 00 0B 00 02 07 00 03 07 01 5D 00 02 07 01 60 07 00 03 FF 00 01 00 02 07 00 03 07 01 5D 00 03 07 01 60 07 00 03 01 FF 00 1D 00 02 07 00 03 07 01 5D 00 02 07 01 60 07 00 03 FF 00 0D 00 02 07 00 03 07 01 5D 00 02 07 01 60 07 00 65 FF 00 01 00 02 07 00 03 07 01 5D 00 03 07 01 60 07 00 65 01 FF 00 1B 00 02 07 00 03 07 01 5D 00 02 07 01 60 07 00 65 42 07 00 35 FF 00 00 00 02 07 00 03 07 01 5D 00 02 07 01 60 07 00 65 45 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 02 07 01 60 07 01 5F 45 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 02 07 01 60 07 00 91 45 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 02 07 01 60 01 1A 5E 07 00 9A FF 00 01 00 02 07 00 03 07 01 5D 00 02 07 00 9A 01 5E 07 00 9A 50 07 00 A6 FF 00 01 00 02 07 00 03 07 01 5D 00 02 07 00 A6 01 5C 07 00 A6 49 07 00 40 40 07 00 03 45 07 00 40 40 01 51 07 00 9A FF 00 01 00 02 07 00 03 07 01 5D 00 02 07 00 9A 01 5D 07 00 9A FF 00 10 00 02 07 00 03 07 01 5D 00 02 07 00 A0 03 FF 00 01 00 02 07 00 03 07 01 5D 00 03 07 00 A0 03 01 FF 00 1C 00 02 07 00 03 07 01 5D 00 02 07 00 A0 03 02 FF 00 06 00 00 00 01 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 01 07 00 44 45 07 00 40 40 07 01 5F 4D 07 00 49 FF 00 01 00 02 07 00 03 07 01 5D 00 02 07 00 49 01 5D 07 00 49 42 07 00 25 40 07 00 49 45 07 00 40 40 01 46 07 00 37 40 07 00 03 45 07 00 40 40 01 0A 4B 07 00 03 FF 00 01 00 02 07 00 03 07 01 5D 00 02 07 00 03 01 5C 07 00 03 42 07 00 1B 40 07 00 03 45 07 00 40 40 01 0D 41 01 1C 4B 07 00 03 FF 00 01 00 02 07 00 03 07 01 5D 00 02 07 00 03 01 5D 07 00 03 48 07 00 40 40 07 00 A0 45 07 00 40 40 01 4E 07 00 03 FF 00 01 00 02 07 00 03 07 01 5D 00 02 07 00 03 01 5D 07 00 03 09 FF 00 15 00 02 07 00 03 07 01 5D 00 03 08 04 46 08 04 46 07 00 A0 FF 00 01 00 02 07 00 03 07 01 5D 00 04 08 04 46 08 04 46 07 00 A0 01 FF 00 1D 00 02 07 00 03 07 01 5D 00 03 08 04 46 08 04 46 07 00 A0 45 07 00 33 FF 00 00 00 02 07 00 03 07 01 5D 00 03 08 04 46 08 04 46 03 45 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 03 08 04 46 08 04 46 03 4C 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 04 08 04 46 08 04 46 03 03 45 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 04 08 04 46 08 04 46 03 03 FF 00 0C 00 00 00 01 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 05 08 04 46 08 04 46 03 03 03 45 07 00 40 FF 00 00 00 02 07 00 03 07 01 5D 00 05 08 04 46 08 04 46 03 03 03 42 07 00 1B FF 00 00 00 02 07 00 03 07 01 5D 00 05 08 04 46 08 04 46 03 03 03 45 07 00 40 40 07 00 DB 42 07 00 40 40 07 00 DB 45 07 00 40 40 07 01 62 FF 00 16 00 03 07 00 03 07 01 5D 07 01 62 00 01 07 00 9A FF 00 01 00 03 07 00 03 07 01 5D 07 01 62 00 02 07 00 9A 01 5C 07 00 9A 4D 07 00 A0 FF 00 01 00 03 07 00 03 07 01 5D 07 01 62 00 02 07 00 A0 01 5B 07 00 A0 08 05 42 01 19 0B 42 01 1C 49 07 00 35 40 07 00 A0 45 07 00 40 40 01 52 07 00 9A FF 00 02 00 03 07 00 03 07 01 5D 07 01 62 00 02 07 00 9A 01 5F 07 00 9A 59 07 00 03 FF 00 02 00 03 07 00 03 07 01 5D 07 01 62 00 02 07 00 03 01 5E 07 00 03 4E 07 00 9A FF 00 02 00 03 07 00 03 07 01 5D 07 01 62 00 02 07 00 9A 01 5D 07 00 9A 08 05 42 01 19 49 07 00 40 40 07 00 A0 45 07 00 40 40 01 02 05 42 01 19 05 52 07 00 A0 FF 00 02 00 03 07 00 03 07 01 5D 07 01 62 00 02 07 00 A0 01 5F 07 00 A0 64 07 00 9A FF 00 02 00 03 07 00 03 07 01 5D 07 01 62 00 02 07 00 9A 01 5F 07 00 9A 0D 49 07 00 1B 40 07 00 A0 45 07 00 40 40 01 02 05 42 01 1B 4F 07 00 9A FF 00 02 00 03 07 00 03 07 01 5D 07 01 62 00 02 07 00 9A 01 5C 07 00 9A 45 07 00 2D 40 07 00 A0 45 07 00 40 40 01 02 05 42 01 19 0B 42 01 1C 4F 07 00 9A FF 00 02 00 03 07 00 03 07 01 5D 07 01 62 00 02 07 00 9A 01 5C 07 00 9A 0E 0B 42 01 1D 4C 07 00 03 FF 00 02 00 03 07 00 03 07 01 5D 07 01 62 00 02 07 00 03 01 5F 07 00 03 FF 00 08 00 00 00 01 07 00 40 FF 00 00 00 03 07 00 03 07 01 5D 07 01 62 00 01 07 00 A0 45 07 00 40 40 01 09 05 42 01 1B 4F 07 00 9A FF 00 02 00 03 07 00 03 07 01 5D 07 01 62 00 02 07 00 9A 01 5C 07 00 9A 59 07 00 03 FF 00 02 00 03 07 00 03 07 01 5D 07 01 62 00 02 07 00 03 01 5E 07 00 03 4C 07 00 40 FF 00 00 00 03 07 00 03 07 01 5D 07 01 62 00 02 07 00 A0 07 00 44 45 07 00 40 FF 00 00 00 03 07 00 03 07 01 5D 07 01 62 00 02 07 00 A0 07 01 5F FF 00 05 00 00 00 01 07 00 40 FF 00 00 00 03 07 00 03 07 01 5D 07 01 62 00 02 07 00 A0 07 00 49 45 07 00 40 FF 00 00 00 03 07 00 03 07 01 5D 07 01 62 00 02 07 00 A0 01 42 07 00 A0 45 07 00 A0 FF 00 02 00 03 07 00 03 07 01 5D 07 01 62 00 02 07 00 A0 01 58 07 00 A0 45 07 00 A0 FF 00 02 00 03 07 00 03 07 01 5D 07 01 62 00 02 07 00 A0 03 FA 00 07 FF 00 00 00 03 07 00 03 07 01 5D 07 01 62 00 01 07 00 9A FF 00 01 00 02 07 00 03 07 01 5D 00 02 07 01 60 07 00 65 FF 00 01 00 03 07 00 03 07 01 5D 07 01 62 00 01 07 00 9A 41 07 00 9A FF 00 01 00 02 07 00 03 07 01 5D 00 03 07 00 03 08 00 63 08 00 63 41 07 00 A6 FF 00 01 00 03 07 00 03 07 01 5D 07 01 62 00 01 07 00 9A FF 00 01 00 02 07 00 03 07 01 5D 00 02 07 01 60 07 00 03 FF 00 01 00 02 07 00 03 07 01 5D 00 02 07 00 A0 03 FF 00 01 00 02 07 00 03 07 01 5D 00 02 07 00 03 07 00 54 41 07 00 9A FF 00 01 00 03 07 00 03 07 01 5D 07 01 62 00 01 07 00 9A FF 00 01 00 02 07 00 03 07 01 5D 00 01 07 00 03 FF 00 01 00 03 07 00 03 07 01 5D 07 01 62 00 01 07 00 9A 41 07 00 9A 41 07 00 A0 01 FF 00 01 00 02 07 00 03 07 01 5D 00 01 07 01 60 41 07 00 49 FF 00 01 00 03 07 00 03 07 01 5D 07 01 62 00 01 07 00 03 FF 00 01 00 02 07 00 03 07 01 5D 00 01 07 00 03 41 07 00 03 01 FF 00 01 00 02 07 00 03 07 01 5D 00 03 07 00 03 07 00 54 07 00 65 41 07 00 9A FF 00 01 00 03 07 00 03 07 01 5D 07 01 62 00 01 07 00 03 FF 00 01 00 02 07 00 03 07 01 5D 00 01 07 00 49 FF 00 01 00 03 07 00 03 07 01 5D 07 01 62 00 01 07 00 A0 01 41 07 00 03 FF 00 01 00 02 07 00 03 07 01 5D 00 03 08 04 46 08 04 46 07 00 A0 FC 00 01 07 01 62 FF 00 01 00 02 07 00 03 07 01 5D 00 01 07 00 39 43 05 44 07 00 39 47 05 47 07 00 40
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     2531   2539   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  2531   2539   2531   2539   Ljava/lang/NumberFormatException;
        //  2547   2549   3      8      Any
        //  31     38     38     39     Any
        //  31     38     38     39     Ljava/util/NoSuchElementException;
        //  31     38     31     32     Any
        //  32     38     31     32     Ljava/util/NoSuchElementException;
        //  31     38     3      8      Any
        //  87     94     94     95     Any
        //  87     94     87     88     Any
        //  87     94     3      8      Ljava/util/ConcurrentModificationException;
        //  87     94     87     88     Any
        //  87     94     3      8      Ljava/lang/NegativeArraySizeException;
        //  147    154    154    155    Any
        //  148    154    147    148    Any
        //  148    154    147    148    Ljava/util/NoSuchElementException;
        //  148    154    3      8      Any
        //  147    154    147    148    Ljava/lang/IndexOutOfBoundsException;
        //  247    254    254    255    Any
        //  248    254    254    255    Any
        //  248    254    3      8      Ljava/lang/UnsupportedOperationException;
        //  248    254    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  247    254    247    248    Any
        //  259    265    265    266    Any
        //  259    265    3      8      Any
        //  259    265    265    266    Ljava/lang/NegativeArraySizeException;
        //  259    265    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  259    265    265    266    Any
        //  269    276    276    277    Any
        //  270    276    276    277    Any
        //  269    276    276    277    Any
        //  269    276    3      8      Any
        //  270    276    269    270    Any
        //  282    289    289    290    Any
        //  283    289    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  283    289    3      8      Any
        //  283    289    289    290    Any
        //  282    289    282    283    Ljava/lang/NumberFormatException;
        //  293    300    300    301    Any
        //  293    300    3      8      Any
        //  293    300    293    294    Ljava/lang/IllegalArgumentException;
        //  294    300    3      8      Any
        //  293    300    293    294    Ljava/lang/IndexOutOfBoundsException;
        //  304    311    311    312    Any
        //  304    311    304    305    Any
        //  305    311    304    305    Any
        //  305    311    311    312    Ljava/lang/ClassCastException;
        //  305    311    311    312    Ljava/lang/EnumConstantNotPresentException;
        //  315    322    322    323    Any
        //  316    322    315    316    Any
        //  315    322    322    323    Ljava/lang/NumberFormatException;
        //  315    322    3      8      Ljava/util/ConcurrentModificationException;
        //  316    322    3      8      Any
        //  334    341    341    342    Any
        //  334    341    334    335    Ljava/lang/AssertionError;
        //  334    341    3      8      Any
        //  334    341    334    335    Ljava/util/ConcurrentModificationException;
        //  335    341    341    342    Ljava/lang/NumberFormatException;
        //  345    352    352    353    Any
        //  345    352    345    346    Any
        //  345    352    345    346    Any
        //  346    352    352    353    Any
        //  345    352    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  356    363    363    364    Any
        //  356    363    363    364    Any
        //  356    363    363    364    Ljava/lang/IndexOutOfBoundsException;
        //  357    363    356    357    Ljava/lang/NegativeArraySizeException;
        //  357    363    363    364    Any
        //  499    506    506    507    Any
        //  500    506    3      8      Any
        //  500    506    506    507    Ljava/lang/ArithmeticException;
        //  500    506    506    507    Any
        //  500    506    499    500    Ljava/lang/NullPointerException;
        //  513    520    520    521    Any
        //  514    520    520    521    Ljava/lang/EnumConstantNotPresentException;
        //  514    520    513    514    Any
        //  513    520    3      8      Any
        //  514    520    513    514    Ljava/lang/IndexOutOfBoundsException;
        //  670    677    677    678    Any
        //  671    677    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  670    677    670    671    Any
        //  670    677    670    671    Any
        //  671    677    670    671    Any
        //  787    793    793    794    Any
        //  787    793    3      8      Any
        //  787    793    793    794    Any
        //  787    793    3      8      Any
        //  787    793    793    794    Any
        //  843    850    850    851    Any
        //  844    850    3      8      Ljava/lang/UnsupportedOperationException;
        //  844    850    843    844    Ljava/lang/IndexOutOfBoundsException;
        //  844    850    3      8      Any
        //  844    850    850    851    Ljava/lang/NegativeArraySizeException;
        //  858    865    865    866    Any
        //  859    865    3      8      Any
        //  859    865    3      8      Any
        //  858    865    3      8      Any
        //  858    865    858    859    Ljava/lang/IllegalStateException;
        //  923    930    930    931    Any
        //  923    930    930    931    Ljava/lang/RuntimeException;
        //  923    930    930    931    Ljava/lang/RuntimeException;
        //  924    930    923    924    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  923    930    3      8      Ljava/lang/IllegalStateException;
        //  1029   1036   1036   1037   Any
        //  1030   1036   1036   1037   Ljava/lang/NegativeArraySizeException;
        //  1030   1036   1029   1030   Any
        //  1029   1036   1036   1037   Any
        //  1030   1036   3      8      Ljava/lang/EnumConstantNotPresentException;
        //  1154   1161   1161   1162   Any
        //  1155   1161   1161   1162   Any
        //  1154   1161   3      8      Any
        //  1155   1161   3      8      Any
        //  1154   1161   1154   1155   Ljava/lang/ArithmeticException;
        //  1175   1182   1182   1183   Any
        //  1175   1182   3      8      Ljava/lang/IllegalArgumentException;
        //  1176   1182   1182   1183   Ljava/lang/UnsupportedOperationException;
        //  1175   1182   1175   1176   Any
        //  1175   1182   3      8      Any
        //  1197   1203   1203   1204   Any
        //  1197   1203   1203   1204   Any
        //  1197   1203   3      8      Any
        //  1197   1203   3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1197   1203   1203   1204   Ljava/lang/NegativeArraySizeException;
        //  1207   1214   1214   1215   Any
        //  1208   1214   1207   1208   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1208   1214   3      8      Ljava/lang/AssertionError;
        //  1208   1214   1214   1215   Any
        //  1207   1214   1214   1215   Any
        //  1218   1225   1225   1226   Any
        //  1219   1225   1218   1219   Any
        //  1219   1225   3      8      Any
        //  1218   1225   1225   1226   Any
        //  1218   1225   1225   1226   Any
        //  1422   1429   1429   1430   Any
        //  1423   1429   1429   1430   Ljava/util/ConcurrentModificationException;
        //  1422   1429   1429   1430   Ljava/lang/ClassCastException;
        //  1423   1429   1422   1423   Ljava/lang/NullPointerException;
        //  1423   1429   3      8      Ljava/util/NoSuchElementException;
        //  1646   1653   1653   1654   Any
        //  1647   1653   1646   1647   Any
        //  1647   1653   1653   1654   Any
        //  1647   1653   1653   1654   Any
        //  1646   1653   3      8      Ljava/lang/NegativeArraySizeException;
        //  1848   1855   1855   1856   Any
        //  1849   1855   1848   1849   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1848   1855   3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1848   1855   3      8      Ljava/lang/IllegalArgumentException;
        //  1849   1855   1855   1856   Any
        //  1950   1957   1957   1958   Any
        //  1950   1957   1950   1951   Ljava/lang/IllegalArgumentException;
        //  1951   1957   3      8      Any
        //  1950   1957   3      8      Any
        //  1951   1957   3      8      Ljava/lang/RuntimeException;
        //  2206   2212   2212   2213   Any
        //  2206   2212   2212   2213   Any
        //  2206   2212   2212   2213   Ljava/lang/IllegalArgumentException;
        //  2206   2212   2212   2213   Ljava/util/NoSuchElementException;
        //  2206   2212   3      8      Any
        //  2381   2388   2388   2389   Any
        //  2381   2388   2381   2382   Any
        //  2382   2388   2388   2389   Any
        //  2381   2388   2388   2389   Any
        //  2382   2388   3      8      Any
        //  2396   2402   2402   2403   Any
        //  2396   2402   2402   2403   Ljava/lang/NumberFormatException;
        //  2396   2402   3      8      Ljava/util/NoSuchElementException;
        //  2396   2402   2402   2403   Ljava/lang/NumberFormatException;
        //  2396   2402   2402   2403   Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:776)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void c(final BlockPos p0, final CallbackInfoReturnable p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          1868
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            1860
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            1852
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: getstatic       dev/nuker/pyro/fc.0:I
        //    27: ifgt            36
        //    30: ldc_w           -795884061
        //    33: goto            39
        //    36: ldc_w           1546043027
        //    39: ldc_w           462037296
        //    42: ixor           
        //    43: lookupswitch {
        //          -1488628187: 36
        //          -888806189: 1791
        //          default: 68
        //        }
        //    68: aload_0        
        //    69: getstatic       dev/nuker/pyro/fc.c:I
        //    72: ifne            81
        //    75: ldc_w           -48758283
        //    78: goto            84
        //    81: ldc_w           -802949682
        //    84: ldc_w           46014886
        //    87: ixor           
        //    88: lookupswitch {
        //          -761408408: 116
        //          -5889965: 81
        //          default: 1805
        //        }
        //   116: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //   119: getstatic       dev/nuker/pyro/fc.1:I
        //   122: ifne            131
        //   125: ldc_w           -1825201504
        //   128: goto            134
        //   131: ldc_w           783895833
        //   134: ldc_w           1403307178
        //   137: ixor           
        //   138: lookupswitch {
        //          -1064212982: 1811
        //          682691172: 131
        //          default: 164
        //        }
        //   164: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //   167: ifnull          306
        //   170: aload_0        
        //   171: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //   174: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   177: ifnull          306
        //   180: aload_0        
        //   181: getstatic       dev/nuker/pyro/fc.0:I
        //   184: ifgt            193
        //   187: ldc_w           -127956785
        //   190: goto            196
        //   193: ldc_w           -549563173
        //   196: ldc_w           -807537277
        //   199: ixor           
        //   200: lookupswitch {
        //          -260745175: 193
        //          931298636: 1837
        //          default: 228
        //        }
        //   228: getfield        dev/nuker/pyro/f9u.c:Ldev/nuker/pyro/fw;
        //   231: goto            235
        //   234: athrow         
        //   235: invokevirtual   dev/nuker/pyro/fw.0:()Ljava/lang/Object;
        //   238: goto            242
        //   241: athrow         
        //   242: checkcast       Ljava/lang/Boolean;
        //   245: getstatic       dev/nuker/pyro/fc.1:I
        //   248: ifne            257
        //   251: ldc_w           933984896
        //   254: goto            260
        //   257: ldc_w           1194831254
        //   260: ldc_w           -1299149683
        //   263: ixor           
        //   264: lookupswitch {
        //          -2059667955: 1827
        //          -1455201486: 257
        //          default: 292
        //        }
        //   292: goto            296
        //   295: athrow         
        //   296: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   299: goto            303
        //   302: athrow         
        //   303: ifne            307
        //   306: return         
        //   307: aload_0        
        //   308: getfield        dev/nuker/pyro/f9u.c:Ldev/nuker/pyro/f0o;
        //   311: goto            315
        //   314: athrow         
        //   315: invokevirtual   dev/nuker/pyro/f0o.c:()Ljava/lang/Object;
        //   318: goto            322
        //   321: athrow         
        //   322: getstatic       dev/nuker/pyro/fc.c:I
        //   325: ifne            334
        //   328: ldc_w           -393969138
        //   331: goto            337
        //   334: ldc_w           -688900086
        //   337: ldc_w           1566296331
        //   340: ixor           
        //   341: lookupswitch {
        //          -1243657467: 1795
        //          79266415: 334
        //          default: 368
        //        }
        //   368: getstatic       dev/nuker/pyro/f9t.0:Ldev/nuker/pyro/f9t;
        //   371: if_acmpne       375
        //   374: return         
        //   375: getstatic       dev/nuker/pyro/fc.1:I
        //   378: ifne            387
        //   381: ldc_w           -121850185
        //   384: goto            390
        //   387: ldc_w           216552430
        //   390: ldc_w           -1581390975
        //   393: ixor           
        //   394: lookupswitch {
        //          -1386893201: 420
        //          1493259574: 387
        //          default: 1819
        //        }
        //   420: aload_0        
        //   421: goto            425
        //   424: athrow         
        //   425: invokevirtual   dev/nuker/pyro/f9u.c:()Z
        //   428: goto            432
        //   431: athrow         
        //   432: ifeq            436
        //   435: return         
        //   436: aload_0        
        //   437: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //   440: getstatic       dev/nuker/pyro/fc.1:I
        //   443: ifne            452
        //   446: ldc_w           2094587099
        //   449: goto            455
        //   452: ldc_w           -103899432
        //   455: ldc_w           1200994876
        //   458: ixor           
        //   459: lookupswitch {
        //          -1101323036: 484
        //          994928359: 452
        //          default: 1833
        //        }
        //   484: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   487: getstatic       dev/nuker/pyro/fc.0:I
        //   490: ifgt            499
        //   493: ldc_w           204815382
        //   496: goto            502
        //   499: ldc_w           1304378110
        //   502: ldc_w           -1680546766
        //   505: ixor           
        //   506: lookupswitch {
        //          -1746806748: 499
        //          -697573684: 532
        //          default: 1793
        //        }
        //   532: goto            536
        //   535: athrow         
        //   536: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_184838_M:()Z
        //   539: goto            543
        //   542: athrow         
        //   543: ifne            1790
        //   546: aload_0        
        //   547: getstatic       dev/nuker/pyro/fc.0:I
        //   550: ifgt            559
        //   553: ldc_w           -121097868
        //   556: goto            562
        //   559: ldc_w           -599381963
        //   562: ldc_w           962487529
        //   565: ixor           
        //   566: lookupswitch {
        //          -1047112291: 1799
        //          1480410702: 559
        //          default: 592
        //        }
        //   592: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //   595: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   598: goto            602
        //   601: athrow         
        //   602: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_70093_af:()Z
        //   605: goto            609
        //   608: athrow         
        //   609: ifne            1790
        //   612: aload_2        
        //   613: goto            617
        //   616: athrow         
        //   617: invokevirtual   org/spongepowered/asm/mixin/injection/callback/CallbackInfoReturnable.cancel:()V
        //   620: goto            624
        //   623: athrow         
        //   624: aload_2        
        //   625: getstatic       dev/nuker/pyro/fc.1:I
        //   628: ifne            637
        //   631: ldc_w           961864210
        //   634: goto            640
        //   637: ldc_w           797351835
        //   640: ldc_w           159484605
        //   643: ixor           
        //   644: lookupswitch {
        //          637998374: 672
        //          819292335: 637
        //          default: 1841
        //        }
        //   672: getstatic       net/minecraft/block/Block.field_185505_j:Lnet/minecraft/util/math/AxisAlignedBB;
        //   675: goto            679
        //   678: athrow         
        //   679: invokevirtual   org/spongepowered/asm/mixin/injection/callback/CallbackInfoReturnable.setReturnValue:(Ljava/lang/Object;)V
        //   682: goto            686
        //   685: athrow         
        //   686: aload_0        
        //   687: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //   690: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   693: goto            697
        //   696: athrow         
        //   697: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_184187_bx:()Lnet/minecraft/entity/Entity;
        //   700: goto            704
        //   703: athrow         
        //   704: ifnull          790
        //   707: getstatic       dev/nuker/pyro/fc.0:I
        //   710: ifgt            719
        //   713: ldc_w           934723289
        //   716: goto            722
        //   719: ldc_w           1208232712
        //   722: ldc_w           -1351003625
        //   725: ixor           
        //   726: lookupswitch {
        //          -1731203890: 1809
        //          654153548: 719
        //          default: 752
        //        }
        //   752: aload_2        
        //   753: new             Lnet/minecraft/util/math/AxisAlignedBB;
        //   756: dup            
        //   757: dconst_0       
        //   758: dconst_0       
        //   759: dconst_0       
        //   760: dconst_1       
        //   761: ldc2_w          0.949999988079071
        //   764: dconst_1       
        //   765: goto            769
        //   768: athrow         
        //   769: invokespecial   net/minecraft/util/math/AxisAlignedBB.<init>:(DDDDDD)V
        //   772: goto            776
        //   775: athrow         
        //   776: goto            780
        //   779: athrow         
        //   780: invokevirtual   org/spongepowered/asm/mixin/injection/callback/CallbackInfoReturnable.setReturnValue:(Ljava/lang/Object;)V
        //   783: goto            787
        //   786: athrow         
        //   787: goto            1790
        //   790: aload_0        
        //   791: getfield        dev/nuker/pyro/f9u.c:Ldev/nuker/pyro/f0o;
        //   794: goto            798
        //   797: athrow         
        //   798: invokevirtual   dev/nuker/pyro/f0o.c:()Ljava/lang/Object;
        //   801: goto            805
        //   804: athrow         
        //   805: getstatic       dev/nuker/pyro/fc.0:I
        //   808: ifgt            817
        //   811: ldc_w           -379246674
        //   814: goto            820
        //   817: ldc_w           1587665341
        //   820: ldc_w           -328875411
        //   823: ixor           
        //   824: lookupswitch {
        //          -1507123592: 817
        //          83944899: 1831
        //          default: 852
        //        }
        //   852: getstatic       dev/nuker/pyro/f9t.0:Ldev/nuker/pyro/f9t;
        //   855: if_acmpne       1237
        //   858: getstatic       dev/nuker/pyro/fc.1:I
        //   861: ifne            870
        //   864: ldc_w           -1688157572
        //   867: goto            873
        //   870: ldc_w           710561644
        //   873: ldc_w           -2053424697
        //   876: ixor           
        //   877: lookupswitch {
        //          -1346275669: 904
        //          519830459: 870
        //          default: 1829
        //        }
        //   904: aload_0        
        //   905: goto            909
        //   908: athrow         
        //   909: invokevirtual   dev/nuker/pyro/f9u.1:()Z
        //   912: goto            916
        //   915: athrow         
        //   916: ifeq            1790
        //   919: aload_2        
        //   920: new             Lnet/minecraft/util/math/AxisAlignedBB;
        //   923: dup            
        //   924: aload_1        
        //   925: goto            929
        //   928: athrow         
        //   929: invokevirtual   net/minecraft/util/math/BlockPos.func_177958_n:()I
        //   932: goto            936
        //   935: athrow         
        //   936: i2d            
        //   937: aload_1        
        //   938: goto            942
        //   941: athrow         
        //   942: invokevirtual   net/minecraft/util/math/BlockPos.func_177956_o:()I
        //   945: goto            949
        //   948: athrow         
        //   949: i2d            
        //   950: getstatic       dev/nuker/pyro/fc.0:I
        //   953: ifgt            962
        //   956: ldc_w           1060001796
        //   959: goto            965
        //   962: ldc_w           891634922
        //   965: ldc_w           1889043379
        //   968: ixor           
        //   969: lookupswitch {
        //          1170065241: 996
        //          1337383863: 962
        //          default: 1813
        //        }
        //   996: aload_1        
        //   997: getstatic       dev/nuker/pyro/fc.c:I
        //  1000: ifne            1009
        //  1003: ldc_w           -685049406
        //  1006: goto            1012
        //  1009: ldc_w           2003215200
        //  1012: ldc_w           -715840534
        //  1015: ixor           
        //  1016: lookupswitch {
        //          -1573683062: 1044
        //          41933352: 1009
        //          default: 1835
        //        }
        //  1044: goto            1048
        //  1047: athrow         
        //  1048: invokevirtual   net/minecraft/util/math/BlockPos.func_177956_o:()I
        //  1051: goto            1055
        //  1054: athrow         
        //  1055: i2d            
        //  1056: aload_1        
        //  1057: goto            1061
        //  1060: athrow         
        //  1061: invokevirtual   net/minecraft/util/math/BlockPos.func_177958_n:()I
        //  1064: goto            1068
        //  1067: athrow         
        //  1068: i2d            
        //  1069: aload_1        
        //  1070: goto            1074
        //  1073: athrow         
        //  1074: invokevirtual   net/minecraft/util/math/BlockPos.func_177956_o:()I
        //  1077: goto            1081
        //  1080: athrow         
        //  1081: i2d            
        //  1082: aload_0        
        //  1083: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  1086: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1089: getstatic       dev/nuker/pyro/fc.1:I
        //  1092: ifne            1101
        //  1095: ldc_w           1273421933
        //  1098: goto            1104
        //  1101: ldc_w           2003249340
        //  1104: ldc_w           1519120985
        //  1107: ixor           
        //  1108: lookupswitch {
        //          292360756: 1101
        //          770497253: 1136
        //          default: 1825
        //        }
        //  1136: getfield        net/minecraft/client/entity/EntityPlayerSP.field_71158_b:Lnet/minecraft/util/MovementInput;
        //  1139: getfield        net/minecraft/util/MovementInput.field_78901_c:Z
        //  1142: ifeq            1151
        //  1145: ldc2_w          0.95
        //  1148: goto            1154
        //  1151: ldc2_w          0.99
        //  1154: dadd           
        //  1155: aload_1        
        //  1156: goto            1160
        //  1159: athrow         
        //  1160: invokevirtual   net/minecraft/util/math/BlockPos.func_177952_p:()I
        //  1163: goto            1167
        //  1166: athrow         
        //  1167: i2d            
        //  1168: getstatic       dev/nuker/pyro/fc.0:I
        //  1171: ifgt            1180
        //  1174: ldc_w           -1228925882
        //  1177: goto            1183
        //  1180: ldc_w           398218719
        //  1183: ldc_w           845532963
        //  1186: ixor           
        //  1187: lookupswitch {
        //          -2069505179: 1803
        //          37016277: 1180
        //          default: 1212
        //        }
        //  1212: goto            1216
        //  1215: athrow         
        //  1216: invokespecial   net/minecraft/util/math/AxisAlignedBB.<init>:(DDDDDD)V
        //  1219: goto            1223
        //  1222: athrow         
        //  1223: goto            1227
        //  1226: athrow         
        //  1227: invokevirtual   org/spongepowered/asm/mixin/injection/callback/CallbackInfoReturnable.setReturnValue:(Ljava/lang/Object;)V
        //  1230: goto            1234
        //  1233: athrow         
        //  1234: goto            1790
        //  1237: aload_0        
        //  1238: getstatic       dev/nuker/pyro/fc.0:I
        //  1241: ifgt            1250
        //  1244: ldc_w           1806031254
        //  1247: goto            1253
        //  1250: ldc_w           -325973806
        //  1253: ldc_w           1762441621
        //  1256: ixor           
        //  1257: lookupswitch {
        //          -2053197497: 1284
        //          44654595: 1250
        //          default: 1821
        //        }
        //  1284: getfield        dev/nuker/pyro/f9u.c:Ldev/nuker/pyro/f0o;
        //  1287: goto            1291
        //  1290: athrow         
        //  1291: invokevirtual   dev/nuker/pyro/f0o.c:()Ljava/lang/Object;
        //  1294: goto            1298
        //  1297: athrow         
        //  1298: getstatic       dev/nuker/pyro/f9t.1:Ldev/nuker/pyro/f9t;
        //  1301: if_acmpne       1790
        //  1304: getstatic       dev/nuker/pyro/fc.0:I
        //  1307: ifgt            1316
        //  1310: ldc_w           -1147828878
        //  1313: goto            1319
        //  1316: ldc_w           1241670748
        //  1319: ldc_w           1392865280
        //  1322: ixor           
        //  1323: lookupswitch {
        //          -393153166: 1316
        //          419894364: 1348
        //          default: 1817
        //        }
        //  1348: aload_0        
        //  1349: getstatic       dev/nuker/pyro/fc.0:I
        //  1352: ifgt            1361
        //  1355: ldc_w           608193362
        //  1358: goto            1364
        //  1361: ldc_w           1447452974
        //  1364: ldc_w           1252363231
        //  1367: ixor           
        //  1368: lookupswitch {
        //          484698865: 1396
        //          1860550797: 1361
        //          default: 1839
        //        }
        //  1396: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  1399: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //  1402: goto            1406
        //  1405: athrow         
        //  1406: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_70093_af:()Z
        //  1409: goto            1413
        //  1412: athrow         
        //  1413: ifne            1422
        //  1416: ldc_w           402974111
        //  1419: goto            1425
        //  1422: ldc_w           402974110
        //  1425: ldc_w           1288467801
        //  1428: ixor           
        //  1429: tableswitch {
        //          -1450106484: 1452
        //          -1450106483: 1790
        //          default: 1416
        //        }
        //  1452: aload_2        
        //  1453: new             Lnet/minecraft/util/math/AxisAlignedBB;
        //  1456: dup            
        //  1457: aload_1        
        //  1458: getstatic       dev/nuker/pyro/fc.c:I
        //  1461: ifne            1470
        //  1464: ldc_w           836686344
        //  1467: goto            1473
        //  1470: ldc_w           -1341621753
        //  1473: ldc_w           -670621414
        //  1476: ixor           
        //  1477: lookupswitch {
        //          -371592430: 1470
        //          1745836829: 1504
        //          default: 1801
        //        }
        //  1504: goto            1508
        //  1507: athrow         
        //  1508: invokevirtual   net/minecraft/util/math/BlockPos.func_177958_n:()I
        //  1511: goto            1515
        //  1514: athrow         
        //  1515: i2d            
        //  1516: aload_1        
        //  1517: goto            1521
        //  1520: athrow         
        //  1521: invokevirtual   net/minecraft/util/math/BlockPos.func_177956_o:()I
        //  1524: goto            1528
        //  1527: athrow         
        //  1528: i2d            
        //  1529: aload_1        
        //  1530: getstatic       dev/nuker/pyro/fc.0:I
        //  1533: ifgt            1542
        //  1536: ldc_w           112358569
        //  1539: goto            1545
        //  1542: ldc_w           -679573546
        //  1545: ldc_w           823318150
        //  1548: ixor           
        //  1549: lookupswitch {
        //          -429108912: 1576
        //          933274159: 1542
        //          default: 1797
        //        }
        //  1576: goto            1580
        //  1579: athrow         
        //  1580: invokevirtual   net/minecraft/util/math/BlockPos.func_177956_o:()I
        //  1583: goto            1587
        //  1586: athrow         
        //  1587: i2d            
        //  1588: aload_1        
        //  1589: goto            1593
        //  1592: athrow         
        //  1593: invokevirtual   net/minecraft/util/math/BlockPos.func_177958_n:()I
        //  1596: goto            1600
        //  1599: athrow         
        //  1600: i2d            
        //  1601: aload_1        
        //  1602: getstatic       dev/nuker/pyro/fc.0:I
        //  1605: ifgt            1614
        //  1608: ldc_w           -1828103950
        //  1611: goto            1617
        //  1614: ldc_w           812133152
        //  1617: ldc_w           -263800605
        //  1620: ixor           
        //  1621: lookupswitch {
        //          -2124129013: 1614
        //          1666179089: 1807
        //          default: 1648
        //        }
        //  1648: goto            1652
        //  1651: athrow         
        //  1652: invokevirtual   net/minecraft/util/math/BlockPos.func_177956_o:()I
        //  1655: goto            1659
        //  1658: athrow         
        //  1659: i2d            
        //  1660: ldc2_w          0.96
        //  1663: dadd           
        //  1664: aload_1        
        //  1665: getstatic       dev/nuker/pyro/fc.c:I
        //  1668: ifne            1677
        //  1671: ldc_w           751488958
        //  1674: goto            1680
        //  1677: ldc_w           920603218
        //  1680: ldc_w           -481323088
        //  1683: ixor           
        //  1684: lookupswitch {
        //          -813344754: 1677
        //          -711926302: 1712
        //          default: 1815
        //        }
        //  1712: goto            1716
        //  1715: athrow         
        //  1716: invokevirtual   net/minecraft/util/math/BlockPos.func_177952_p:()I
        //  1719: goto            1723
        //  1722: athrow         
        //  1723: i2d            
        //  1724: getstatic       dev/nuker/pyro/fc.1:I
        //  1727: ifne            1736
        //  1730: ldc_w           -36297363
        //  1733: goto            1739
        //  1736: ldc_w           51391183
        //  1739: ldc_w           -1977734840
        //  1742: ixor           
        //  1743: lookupswitch {
        //          -1995570297: 1768
        //          2009599013: 1736
        //          default: 1823
        //        }
        //  1768: goto            1772
        //  1771: athrow         
        //  1772: invokespecial   net/minecraft/util/math/AxisAlignedBB.<init>:(DDDDDD)V
        //  1775: goto            1779
        //  1778: athrow         
        //  1779: goto            1783
        //  1782: athrow         
        //  1783: invokevirtual   org/spongepowered/asm/mixin/injection/callback/CallbackInfoReturnable.setReturnValue:(Ljava/lang/Object;)V
        //  1786: goto            1790
        //  1789: athrow         
        //  1790: return         
        //  1791: aconst_null    
        //  1792: athrow         
        //  1793: aconst_null    
        //  1794: athrow         
        //  1795: aconst_null    
        //  1796: athrow         
        //  1797: aconst_null    
        //  1798: athrow         
        //  1799: aconst_null    
        //  1800: athrow         
        //  1801: aconst_null    
        //  1802: athrow         
        //  1803: aconst_null    
        //  1804: athrow         
        //  1805: aconst_null    
        //  1806: athrow         
        //  1807: aconst_null    
        //  1808: athrow         
        //  1809: aconst_null    
        //  1810: athrow         
        //  1811: aconst_null    
        //  1812: athrow         
        //  1813: aconst_null    
        //  1814: athrow         
        //  1815: aconst_null    
        //  1816: athrow         
        //  1817: aconst_null    
        //  1818: athrow         
        //  1819: aconst_null    
        //  1820: athrow         
        //  1821: aconst_null    
        //  1822: athrow         
        //  1823: aconst_null    
        //  1824: athrow         
        //  1825: aconst_null    
        //  1826: athrow         
        //  1827: aconst_null    
        //  1828: athrow         
        //  1829: aconst_null    
        //  1830: athrow         
        //  1831: aconst_null    
        //  1832: athrow         
        //  1833: aconst_null    
        //  1834: athrow         
        //  1835: aconst_null    
        //  1836: athrow         
        //  1837: aconst_null    
        //  1838: athrow         
        //  1839: aconst_null    
        //  1840: athrow         
        //  1841: aconst_null    
        //  1842: athrow         
        //  1843: pop            
        //  1844: goto            24
        //  1847: pop            
        //  1848: aconst_null    
        //  1849: goto            1843
        //  1852: dup            
        //  1853: ifnull          1843
        //  1856: checkcast       Ljava/lang/Throwable;
        //  1859: athrow         
        //  1860: dup            
        //  1861: ifnull          1847
        //  1864: checkcast       Ljava/lang/Throwable;
        //  1867: athrow         
        //  1868: aconst_null    
        //  1869: athrow         
        //    StackMapTable: 00 F9 43 07 00 40 04 FF 00 0B 00 00 00 01 07 00 40 FE 00 03 07 00 03 07 00 DB 07 01 94 0B 42 01 1C 4C 07 00 03 FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 02 07 00 03 01 5F 07 00 03 4E 07 00 9A FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 02 07 00 9A 01 5D 07 00 9A 5C 07 00 03 FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 02 07 00 03 01 5F 07 00 03 45 07 00 1F 40 07 01 78 45 07 00 40 40 07 01 5F 4E 07 00 49 FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 02 07 00 49 01 5F 07 00 49 42 07 00 40 40 07 00 49 45 07 00 40 40 01 02 00 46 07 00 40 40 07 00 65 45 07 00 40 40 07 01 5F 4B 07 01 5F FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 02 07 01 5F 01 5E 07 01 5F 06 0B 42 01 1D 43 07 00 40 40 07 00 03 45 07 00 40 40 01 03 4F 07 00 9A FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 02 07 00 9A 01 5C 07 00 9A 4E 07 00 A0 FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 02 07 00 A0 01 5D 07 00 A0 FF 00 02 00 00 00 01 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 01 07 00 A0 45 07 00 40 40 01 4F 07 00 03 FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 02 07 00 03 01 5D 07 00 03 48 07 00 40 40 07 00 A0 45 07 00 40 40 01 FF 00 06 00 00 00 01 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 01 07 01 94 45 07 00 40 00 4C 07 01 94 FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 02 07 01 94 01 5F 07 01 94 FF 00 05 00 00 00 01 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 02 07 01 94 07 01 AB 45 07 00 40 00 49 07 00 39 40 07 00 A0 45 07 00 40 40 07 01 F0 0E 42 01 1D 4F 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 09 07 01 94 08 02 F1 08 02 F1 03 03 03 03 03 03 45 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 02 07 01 94 07 01 AB 42 07 00 2D FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 02 07 01 94 07 01 AB 45 07 00 40 00 02 46 07 00 40 40 07 00 65 45 07 00 40 40 07 01 5F 4B 07 01 5F FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 02 07 01 5F 01 5F 07 01 5F 11 42 01 1E FF 00 03 00 00 00 01 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 01 07 00 03 45 07 00 40 40 01 4B 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 04 07 01 94 08 03 98 08 03 98 07 00 DB 45 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 04 07 01 94 08 03 98 08 03 98 01 44 07 00 35 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 05 07 01 94 08 03 98 08 03 98 03 07 00 DB 45 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 05 07 01 94 08 03 98 08 03 98 03 01 FF 00 0C 00 03 07 00 03 07 00 DB 07 01 94 00 05 07 01 94 08 03 98 08 03 98 03 03 FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 06 07 01 94 08 03 98 08 03 98 03 03 01 FF 00 1E 00 03 07 00 03 07 00 DB 07 01 94 00 05 07 01 94 08 03 98 08 03 98 03 03 FF 00 0C 00 03 07 00 03 07 00 DB 07 01 94 00 06 07 01 94 08 03 98 08 03 98 03 03 07 00 DB FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 07 07 01 94 08 03 98 08 03 98 03 03 07 00 DB 01 FF 00 1F 00 03 07 00 03 07 00 DB 07 01 94 00 06 07 01 94 08 03 98 08 03 98 03 03 07 00 DB FF 00 02 00 00 00 01 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 06 07 01 94 08 03 98 08 03 98 03 03 07 00 DB 45 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 06 07 01 94 08 03 98 08 03 98 03 03 01 44 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 07 07 01 94 08 03 98 08 03 98 03 03 03 07 00 DB 45 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 07 07 01 94 08 03 98 08 03 98 03 03 03 01 44 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 08 07 01 94 08 03 98 08 03 98 03 03 03 03 07 00 DB 45 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 08 07 01 94 08 03 98 08 03 98 03 03 03 03 01 FF 00 13 00 03 07 00 03 07 00 DB 07 01 94 00 09 07 01 94 08 03 98 08 03 98 03 03 03 03 03 07 00 A0 FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 0A 07 01 94 08 03 98 08 03 98 03 03 03 03 03 07 00 A0 01 FF 00 1F 00 03 07 00 03 07 00 DB 07 01 94 00 09 07 01 94 08 03 98 08 03 98 03 03 03 03 03 07 00 A0 FF 00 0E 00 03 07 00 03 07 00 DB 07 01 94 00 08 07 01 94 08 03 98 08 03 98 03 03 03 03 03 FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 09 07 01 94 08 03 98 08 03 98 03 03 03 03 03 03 44 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 09 07 01 94 08 03 98 08 03 98 03 03 03 03 03 07 00 DB 45 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 09 07 01 94 08 03 98 08 03 98 03 03 03 03 03 01 FF 00 0C 00 03 07 00 03 07 00 DB 07 01 94 00 09 07 01 94 08 03 98 08 03 98 03 03 03 03 03 03 FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 0A 07 01 94 08 03 98 08 03 98 03 03 03 03 03 03 01 FF 00 1C 00 03 07 00 03 07 00 DB 07 01 94 00 09 07 01 94 08 03 98 08 03 98 03 03 03 03 03 03 42 07 00 2B FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 09 07 01 94 08 03 98 08 03 98 03 03 03 03 03 03 45 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 02 07 01 94 07 01 AB 42 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 02 07 01 94 07 01 AB 45 07 00 40 00 02 4C 07 00 03 FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 02 07 00 03 01 5E 07 00 03 45 07 00 40 40 07 00 65 45 07 00 40 40 07 01 5F 11 42 01 1C 4C 07 00 03 FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 02 07 00 03 01 5F 07 00 03 FF 00 08 00 00 00 01 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 01 07 00 A0 45 07 00 40 40 01 02 05 42 01 1A FF 00 11 00 03 07 00 03 07 00 DB 07 01 94 00 04 07 01 94 08 05 AD 08 05 AD 07 00 DB FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 05 07 01 94 08 05 AD 08 05 AD 07 00 DB 01 FF 00 1E 00 03 07 00 03 07 00 DB 07 01 94 00 04 07 01 94 08 05 AD 08 05 AD 07 00 DB 42 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 04 07 01 94 08 05 AD 08 05 AD 07 00 DB 45 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 04 07 01 94 08 05 AD 08 05 AD 01 44 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 05 07 01 94 08 05 AD 08 05 AD 03 07 00 DB 45 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 05 07 01 94 08 05 AD 08 05 AD 03 01 FF 00 0D 00 03 07 00 03 07 00 DB 07 01 94 00 06 07 01 94 08 05 AD 08 05 AD 03 03 07 00 DB FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 07 07 01 94 08 05 AD 08 05 AD 03 03 07 00 DB 01 FF 00 1E 00 03 07 00 03 07 00 DB 07 01 94 00 06 07 01 94 08 05 AD 08 05 AD 03 03 07 00 DB 42 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 06 07 01 94 08 05 AD 08 05 AD 03 03 07 00 DB 45 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 06 07 01 94 08 05 AD 08 05 AD 03 03 01 44 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 07 07 01 94 08 05 AD 08 05 AD 03 03 03 07 00 DB 45 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 07 07 01 94 08 05 AD 08 05 AD 03 03 03 01 FF 00 0D 00 03 07 00 03 07 00 DB 07 01 94 00 08 07 01 94 08 05 AD 08 05 AD 03 03 03 03 07 00 DB FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 09 07 01 94 08 05 AD 08 05 AD 03 03 03 03 07 00 DB 01 FF 00 1E 00 03 07 00 03 07 00 DB 07 01 94 00 08 07 01 94 08 05 AD 08 05 AD 03 03 03 03 07 00 DB 42 07 00 1B FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 08 07 01 94 08 05 AD 08 05 AD 03 03 03 03 07 00 DB 45 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 08 07 01 94 08 05 AD 08 05 AD 03 03 03 03 01 FF 00 11 00 03 07 00 03 07 00 DB 07 01 94 00 09 07 01 94 08 05 AD 08 05 AD 03 03 03 03 03 07 00 DB FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 0A 07 01 94 08 05 AD 08 05 AD 03 03 03 03 03 07 00 DB 01 FF 00 1F 00 03 07 00 03 07 00 DB 07 01 94 00 09 07 01 94 08 05 AD 08 05 AD 03 03 03 03 03 07 00 DB 42 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 09 07 01 94 08 05 AD 08 05 AD 03 03 03 03 03 07 00 DB 45 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 09 07 01 94 08 05 AD 08 05 AD 03 03 03 03 03 01 FF 00 0C 00 03 07 00 03 07 00 DB 07 01 94 00 09 07 01 94 08 05 AD 08 05 AD 03 03 03 03 03 03 FF 00 02 00 03 07 00 03 07 00 DB 07 01 94 00 0A 07 01 94 08 05 AD 08 05 AD 03 03 03 03 03 03 01 FF 00 1C 00 03 07 00 03 07 00 DB 07 01 94 00 09 07 01 94 08 05 AD 08 05 AD 03 03 03 03 03 03 42 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 09 07 01 94 08 05 AD 08 05 AD 03 03 03 03 03 03 45 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 02 07 01 94 07 01 AB 42 07 00 40 FF 00 00 00 03 07 00 03 07 00 DB 07 01 94 00 02 07 01 94 07 01 AB 45 07 00 40 00 00 41 07 00 A0 41 07 01 5F FF 00 01 00 03 07 00 03 07 00 DB 07 01 94 00 06 07 01 94 08 05 AD 08 05 AD 03 03 07 00 DB 41 07 00 03 FF 00 01 00 03 07 00 03 07 00 DB 07 01 94 00 04 07 01 94 08 05 AD 08 05 AD 07 00 DB FF 00 01 00 03 07 00 03 07 00 DB 07 01 94 00 09 07 01 94 08 03 98 08 03 98 03 03 03 03 03 03 41 07 00 03 FF 00 01 00 03 07 00 03 07 00 DB 07 01 94 00 08 07 01 94 08 05 AD 08 05 AD 03 03 03 03 07 00 DB 01 41 07 00 9A FF 00 01 00 03 07 00 03 07 00 DB 07 01 94 00 05 07 01 94 08 03 98 08 03 98 03 03 FF 00 01 00 03 07 00 03 07 00 DB 07 01 94 00 09 07 01 94 08 05 AD 08 05 AD 03 03 03 03 03 07 00 DB 01 01 41 07 00 03 FF 00 01 00 03 07 00 03 07 00 DB 07 01 94 00 09 07 01 94 08 05 AD 08 05 AD 03 03 03 03 03 03 FF 00 01 00 03 07 00 03 07 00 DB 07 01 94 00 09 07 01 94 08 03 98 08 03 98 03 03 03 03 03 07 00 A0 41 07 00 49 01 41 07 01 5F 41 07 00 9A FF 00 01 00 03 07 00 03 07 00 DB 07 01 94 00 06 07 01 94 08 03 98 08 03 98 03 03 07 00 DB 41 07 00 03 41 07 00 03 41 07 01 94 41 07 00 40 43 05 44 07 00 40 47 05 47 07 00 40
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     1852   1860   Any
        //  1852   1860   1852   1860   Ljava/util/ConcurrentModificationException;
        //  1868   1870   3      8      Ljava/lang/IllegalArgumentException;
        //  234    241    241    242    Any
        //  235    241    234    235    Ljava/util/NoSuchElementException;
        //  235    241    241    242    Any
        //  235    241    241    242    Ljava/lang/NullPointerException;
        //  235    241    3      8      Ljava/lang/ArithmeticException;
        //  295    302    302    303    Any
        //  296    302    295    296    Ljava/lang/UnsupportedOperationException;
        //  295    302    295    296    Any
        //  296    302    295    296    Ljava/lang/NullPointerException;
        //  296    302    295    296    Ljava/util/NoSuchElementException;
        //  314    321    321    322    Any
        //  314    321    3      8      Any
        //  315    321    314    315    Any
        //  315    321    3      8      Any
        //  315    321    314    315    Any
        //  424    431    431    432    Any
        //  425    431    3      8      Ljava/lang/NumberFormatException;
        //  425    431    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  424    431    424    425    Any
        //  424    431    424    425    Ljava/lang/RuntimeException;
        //  536    542    542    543    Any
        //  536    542    542    543    Any
        //  536    542    542    543    Any
        //  536    542    542    543    Ljava/lang/EnumConstantNotPresentException;
        //  536    542    3      8      Any
        //  601    608    608    609    Any
        //  602    608    3      8      Ljava/lang/NumberFormatException;
        //  601    608    601    602    Any
        //  602    608    3      8      Ljava/lang/NumberFormatException;
        //  602    608    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  617    623    623    624    Any
        //  617    623    3      8      Any
        //  617    623    3      8      Any
        //  617    623    3      8      Ljava/util/ConcurrentModificationException;
        //  617    623    623    624    Ljava/lang/IllegalStateException;
        //  679    685    685    686    Any
        //  679    685    685    686    Ljava/lang/IndexOutOfBoundsException;
        //  679    685    3      8      Any
        //  679    685    3      8      Any
        //  679    685    685    686    Any
        //  696    703    703    704    Any
        //  696    703    696    697    Ljava/util/ConcurrentModificationException;
        //  697    703    703    704    Any
        //  696    703    3      8      Ljava/util/NoSuchElementException;
        //  696    703    696    697    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  768    775    775    776    Any
        //  769    775    3      8      Any
        //  769    775    3      8      Any
        //  769    775    768    769    Any
        //  768    775    775    776    Any
        //  779    786    786    787    Any
        //  779    786    779    780    Ljava/lang/IllegalArgumentException;
        //  780    786    3      8      Any
        //  780    786    779    780    Ljava/lang/NumberFormatException;
        //  779    786    786    787    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  797    804    804    805    Any
        //  798    804    804    805    Ljava/lang/IllegalArgumentException;
        //  797    804    797    798    Any
        //  797    804    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  798    804    797    798    Any
        //  909    915    915    916    Any
        //  909    915    3      8      Ljava/lang/NullPointerException;
        //  909    915    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  909    915    3      8      Any
        //  909    915    3      8      Any
        //  928    935    935    936    Any
        //  929    935    928    929    Any
        //  928    935    3      8      Any
        //  928    935    928    929    Ljava/lang/EnumConstantNotPresentException;
        //  928    935    3      8      Ljava/lang/RuntimeException;
        //  941    948    948    949    Any
        //  942    948    3      8      Ljava/lang/UnsupportedOperationException;
        //  941    948    3      8      Any
        //  942    948    948    949    Any
        //  941    948    941    942    Ljava/lang/NullPointerException;
        //  1048   1054   1054   1055   Any
        //  1048   1054   3      8      Any
        //  1048   1054   1054   1055   Any
        //  1048   1054   1054   1055   Ljava/lang/NegativeArraySizeException;
        //  1048   1054   1054   1055   Ljava/lang/AssertionError;
        //  1060   1067   1067   1068   Any
        //  1061   1067   1060   1061   Any
        //  1061   1067   1060   1061   Ljava/util/NoSuchElementException;
        //  1060   1067   3      8      Ljava/lang/UnsupportedOperationException;
        //  1061   1067   3      8      Any
        //  1073   1080   1080   1081   Any
        //  1074   1080   3      8      Ljava/lang/IllegalArgumentException;
        //  1073   1080   1073   1074   Any
        //  1074   1080   1080   1081   Any
        //  1074   1080   1080   1081   Any
        //  1159   1166   1166   1167   Any
        //  1159   1166   1159   1160   Any
        //  1159   1166   1166   1167   Any
        //  1159   1166   1159   1160   Ljava/lang/AssertionError;
        //  1160   1166   3      8      Any
        //  1215   1222   1222   1223   Any
        //  1215   1222   3      8      Ljava/lang/RuntimeException;
        //  1215   1222   1222   1223   Any
        //  1215   1222   1215   1216   Ljava/lang/StringIndexOutOfBoundsException;
        //  1215   1222   3      8      Any
        //  1226   1233   1233   1234   Any
        //  1227   1233   1226   1227   Ljava/util/ConcurrentModificationException;
        //  1226   1233   3      8      Ljava/lang/UnsupportedOperationException;
        //  1226   1233   1226   1227   Ljava/lang/NumberFormatException;
        //  1227   1233   1226   1227   Any
        //  1290   1297   1297   1298   Any
        //  1290   1297   1290   1291   Any
        //  1290   1297   3      8      Ljava/util/NoSuchElementException;
        //  1291   1297   1290   1291   Any
        //  1290   1297   1297   1298   Any
        //  1406   1412   1412   1413   Any
        //  1406   1412   3      8      Any
        //  1406   1412   1412   1413   Any
        //  1406   1412   3      8      Ljava/lang/AssertionError;
        //  1406   1412   3      8      Ljava/lang/NullPointerException;
        //  1507   1514   1514   1515   Any
        //  1508   1514   1507   1508   Any
        //  1507   1514   1514   1515   Any
        //  1507   1514   1514   1515   Any
        //  1508   1514   3      8      Ljava/lang/AssertionError;
        //  1520   1527   1527   1528   Any
        //  1521   1527   1527   1528   Any
        //  1520   1527   1520   1521   Any
        //  1521   1527   3      8      Any
        //  1521   1527   1527   1528   Ljava/util/NoSuchElementException;
        //  1579   1586   1586   1587   Any
        //  1580   1586   1579   1580   Ljava/lang/AssertionError;
        //  1579   1586   3      8      Ljava/lang/RuntimeException;
        //  1579   1586   1579   1580   Any
        //  1579   1586   3      8      Ljava/lang/IllegalArgumentException;
        //  1592   1599   1599   1600   Any
        //  1593   1599   1592   1593   Any
        //  1593   1599   1592   1593   Ljava/lang/IllegalArgumentException;
        //  1592   1599   3      8      Ljava/lang/UnsupportedOperationException;
        //  1592   1599   3      8      Any
        //  1651   1658   1658   1659   Any
        //  1651   1658   3      8      Ljava/lang/UnsupportedOperationException;
        //  1652   1658   1651   1652   Ljava/lang/ArrayIndexOutOfBoundsException;
        //  1652   1658   1658   1659   Any
        //  1651   1658   3      8      Any
        //  1715   1722   1722   1723   Any
        //  1715   1722   1715   1716   Any
        //  1715   1722   3      8      Ljava/lang/IllegalArgumentException;
        //  1715   1722   1722   1723   Ljava/lang/IllegalArgumentException;
        //  1716   1722   1722   1723   Ljava/util/ConcurrentModificationException;
        //  1771   1778   1778   1779   Any
        //  1772   1778   3      8      Ljava/lang/NumberFormatException;
        //  1771   1778   1771   1772   Any
        //  1772   1778   3      8      Any
        //  1772   1778   3      8      Ljava/util/ConcurrentModificationException;
        //  1782   1789   1789   1790   Any
        //  1782   1789   3      8      Ljava/lang/EnumConstantNotPresentException;
        //  1783   1789   3      8      Ljava/lang/RuntimeException;
        //  1782   1789   1782   1783   Any
        //  1783   1789   1789   1790   Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:595)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public boolean c() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          1055
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            1047
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            1039
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_0        
        //    25: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //    28: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //    31: ifnonnull       40
        //    34: ldc_w           460306442
        //    37: goto            43
        //    40: ldc_w           460306453
        //    43: ldc_w           1244848805
        //    46: ixor           
        //    47: tableswitch {
        //          -1564822178: 68
        //          -1564822177: 70
        //          default: 34
        //        }
        //    68: iconst_0       
        //    69: ireturn        
        //    70: iconst_0       
        //    71: getstatic       dev/nuker/pyro/fc.c:I
        //    74: ifne            83
        //    77: ldc_w           -69944872
        //    80: goto            86
        //    83: ldc_w           -221570044
        //    86: ldc_w           -1556747568
        //    89: ixor           
        //    90: lookupswitch {
        //          1491161864: 1024
        //          1613429988: 83
        //          default: 116
        //        }
        //   116: istore_1       
        //   117: aload_0        
        //   118: getstatic       dev/nuker/pyro/fc.c:I
        //   121: ifne            130
        //   124: ldc_w           -2125972032
        //   127: goto            133
        //   130: ldc_w           -643548298
        //   133: ldc_w           690327222
        //   136: ixor           
        //   137: lookupswitch {
        //          -1469205642: 1012
        //          946097607: 130
        //          default: 164
        //        }
        //   164: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //   167: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   170: goto            174
        //   173: athrow         
        //   174: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_174813_aQ:()Lnet/minecraft/util/math/AxisAlignedBB;
        //   177: goto            181
        //   180: athrow         
        //   181: getfield        net/minecraft/util/math/AxisAlignedBB.field_72338_b:D
        //   184: ldc2_w          0.02
        //   187: dadd           
        //   188: d2i            
        //   189: istore_2       
        //   190: aload_0        
        //   191: getstatic       dev/nuker/pyro/fc.1:I
        //   194: ifne            203
        //   197: ldc_w           -901182149
        //   200: goto            206
        //   203: ldc_w           1954614780
        //   206: ldc_w           568397977
        //   209: ixor           
        //   210: lookupswitch {
        //          -349878783: 203
        //          -341303902: 1006
        //          default: 236
        //        }
        //   236: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //   239: getstatic       dev/nuker/pyro/fc.0:I
        //   242: ifgt            251
        //   245: ldc_w           725437276
        //   248: goto            254
        //   251: ldc_w           1783578072
        //   254: ldc_w           378611441
        //   257: ixor           
        //   258: lookupswitch {
        //          -1546090486: 251
        //          1034710445: 1008
        //          default: 284
        //        }
        //   284: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   287: getstatic       dev/nuker/pyro/fc.0:I
        //   290: ifgt            299
        //   293: ldc_w           -404642020
        //   296: goto            302
        //   299: ldc_w           168091719
        //   302: ldc_w           1183993096
        //   305: ixor           
        //   306: lookupswitch {
        //          -1586238956: 1026
        //          515479124: 299
        //          default: 332
        //        }
        //   332: goto            336
        //   335: athrow         
        //   336: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_174813_aQ:()Lnet/minecraft/util/math/AxisAlignedBB;
        //   339: goto            343
        //   342: athrow         
        //   343: getfield        net/minecraft/util/math/AxisAlignedBB.field_72340_a:D
        //   346: goto            350
        //   349: athrow         
        //   350: invokestatic    net/minecraft/util/math/MathHelper.func_76128_c:(D)I
        //   353: goto            357
        //   356: athrow         
        //   357: istore_3       
        //   358: getstatic       dev/nuker/pyro/fc.0:I
        //   361: ifgt            370
        //   364: ldc_w           -897306866
        //   367: goto            373
        //   370: ldc_w           477652470
        //   373: ldc_w           601027926
        //   376: ixor           
        //   377: lookupswitch {
        //          -380183976: 370
        //          1068142752: 404
        //          default: 1016
        //        }
        //   404: iload_3        
        //   405: aload_0        
        //   406: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //   409: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   412: getstatic       dev/nuker/pyro/fc.0:I
        //   415: ifgt            424
        //   418: ldc_w           815118828
        //   421: goto            427
        //   424: ldc_w           -1664429828
        //   427: ldc_w           -1770641706
        //   430: ixor           
        //   431: lookupswitch {
        //          -1495032006: 424
        //          180155946: 456
        //          default: 1004
        //        }
        //   456: goto            460
        //   459: athrow         
        //   460: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_174813_aQ:()Lnet/minecraft/util/math/AxisAlignedBB;
        //   463: goto            467
        //   466: athrow         
        //   467: getfield        net/minecraft/util/math/AxisAlignedBB.field_72336_d:D
        //   470: goto            474
        //   473: athrow         
        //   474: invokestatic    net/minecraft/util/math/MathHelper.func_76128_c:(D)I
        //   477: goto            481
        //   480: athrow         
        //   481: iconst_1       
        //   482: iadd           
        //   483: if_icmpge       492
        //   486: ldc_w           -1737951071
        //   489: goto            495
        //   492: ldc_w           -1737951070
        //   495: ldc_w           -529549948
        //   498: ixor           
        //   499: tableswitch {
        //          -267478454: 520
        //          -267478453: 953
        //          default: 486
        //        }
        //   520: aload_0        
        //   521: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //   524: getstatic       dev/nuker/pyro/fc.0:I
        //   527: ifgt            536
        //   530: ldc_w           1384499517
        //   533: goto            539
        //   536: ldc_w           697912432
        //   539: ldc_w           -854866010
        //   542: ixor           
        //   543: lookupswitch {
        //          -1618080101: 536
        //          -460157994: 568
        //          default: 1028
        //        }
        //   568: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   571: goto            575
        //   574: athrow         
        //   575: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_174813_aQ:()Lnet/minecraft/util/math/AxisAlignedBB;
        //   578: goto            582
        //   581: athrow         
        //   582: getstatic       dev/nuker/pyro/fc.0:I
        //   585: ifgt            594
        //   588: ldc_w           1554694161
        //   591: goto            597
        //   594: ldc_w           -1915151833
        //   597: ldc_w           2053268249
        //   600: ixor           
        //   601: lookupswitch {
        //          -138708674: 628
        //          650683144: 594
        //          default: 1018
        //        }
        //   628: getfield        net/minecraft/util/math/AxisAlignedBB.field_72339_c:D
        //   631: getstatic       dev/nuker/pyro/fc.c:I
        //   634: ifne            643
        //   637: ldc_w           255828877
        //   640: goto            646
        //   643: ldc_w           1270304490
        //   646: ldc_w           816628898
        //   649: ixor           
        //   650: lookupswitch {
        //          1066624815: 643
        //          2065402440: 676
        //          default: 1020
        //        }
        //   676: goto            680
        //   679: athrow         
        //   680: invokestatic    net/minecraft/util/math/MathHelper.func_76128_c:(D)I
        //   683: goto            687
        //   686: athrow         
        //   687: getstatic       dev/nuker/pyro/fc.1:I
        //   690: ifne            699
        //   693: ldc_w           -6806203
        //   696: goto            702
        //   699: ldc_w           -139640285
        //   702: ldc_w           -1923764343
        //   705: ixor           
        //   706: lookupswitch {
        //          1926073036: 1014
        //          2080159068: 699
        //          default: 732
        //        }
        //   732: istore          4
        //   734: iload           4
        //   736: aload_0        
        //   737: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //   740: getstatic       dev/nuker/pyro/fc.1:I
        //   743: ifne            752
        //   746: ldc_w           -530655906
        //   749: goto            755
        //   752: ldc_w           -1247800143
        //   755: ldc_w           -2033812066
        //   758: ixor           
        //   759: lookupswitch {
        //          -631173351: 752
        //          1721280704: 1002
        //          default: 784
        //        }
        //   784: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   787: goto            791
        //   790: athrow         
        //   791: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_174813_aQ:()Lnet/minecraft/util/math/AxisAlignedBB;
        //   794: goto            798
        //   797: athrow         
        //   798: getfield        net/minecraft/util/math/AxisAlignedBB.field_72334_f:D
        //   801: goto            805
        //   804: athrow         
        //   805: invokestatic    net/minecraft/util/math/MathHelper.func_76128_c:(D)I
        //   808: goto            812
        //   811: athrow         
        //   812: iconst_1       
        //   813: iadd           
        //   814: if_icmpge       947
        //   817: aload_0        
        //   818: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //   821: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //   824: new             Lnet/minecraft/util/math/BlockPos;
        //   827: dup            
        //   828: iload_3        
        //   829: iload_2        
        //   830: iload           4
        //   832: goto            836
        //   835: athrow         
        //   836: invokespecial   net/minecraft/util/math/BlockPos.<init>:(III)V
        //   839: goto            843
        //   842: athrow         
        //   843: goto            847
        //   846: athrow         
        //   847: invokevirtual   net/minecraft/client/multiplayer/WorldClient.func_180495_p:(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
        //   850: goto            854
        //   853: athrow         
        //   854: goto            858
        //   857: athrow         
        //   858: invokeinterface net/minecraft/block/state/IBlockState.func_177230_c:()Lnet/minecraft/block/Block;
        //   863: goto            867
        //   866: athrow         
        //   867: astore          5
        //   869: getstatic       dev/nuker/pyro/fc.1:I
        //   872: ifne            881
        //   875: ldc_w           1100939080
        //   878: goto            884
        //   881: ldc_w           71225184
        //   884: ldc_w           1768781110
        //   887: ixor           
        //   888: lookupswitch {
        //          687049342: 881
        //          1834203734: 916
        //          default: 1010
        //        }
        //   916: aload           5
        //   918: ifnull          941
        //   921: aload           5
        //   923: instanceof      Lnet/minecraft/block/BlockAir;
        //   926: ifne            941
        //   929: aload           5
        //   931: instanceof      Lnet/minecraft/block/BlockLiquid;
        //   934: ifne            939
        //   937: iconst_0       
        //   938: ireturn        
        //   939: iconst_1       
        //   940: istore_1       
        //   941: iinc            4, 1
        //   944: goto            734
        //   947: iinc            3, 1
        //   950: goto            358
        //   953: getstatic       dev/nuker/pyro/fc.0:I
        //   956: ifgt            965
        //   959: ldc_w           -10231362
        //   962: goto            968
        //   965: ldc_w           399132032
        //   968: ldc_w           183245286
        //   971: ixor           
        //   972: lookupswitch {
        //          -1926356880: 965
        //          -175114152: 1022
        //          default: 1000
        //        }
        //  1000: iload_1        
        //  1001: ireturn        
        //  1002: aconst_null    
        //  1003: athrow         
        //  1004: aconst_null    
        //  1005: athrow         
        //  1006: aconst_null    
        //  1007: athrow         
        //  1008: aconst_null    
        //  1009: athrow         
        //  1010: aconst_null    
        //  1011: athrow         
        //  1012: aconst_null    
        //  1013: athrow         
        //  1014: aconst_null    
        //  1015: athrow         
        //  1016: aconst_null    
        //  1017: athrow         
        //  1018: aconst_null    
        //  1019: athrow         
        //  1020: aconst_null    
        //  1021: athrow         
        //  1022: aconst_null    
        //  1023: athrow         
        //  1024: aconst_null    
        //  1025: athrow         
        //  1026: aconst_null    
        //  1027: athrow         
        //  1028: aconst_null    
        //  1029: athrow         
        //  1030: pop            
        //  1031: goto            24
        //  1034: pop            
        //  1035: aconst_null    
        //  1036: goto            1030
        //  1039: dup            
        //  1040: ifnull          1030
        //  1043: checkcast       Ljava/lang/Throwable;
        //  1046: athrow         
        //  1047: dup            
        //  1048: ifnull          1034
        //  1051: checkcast       Ljava/lang/Throwable;
        //  1054: athrow         
        //  1055: aconst_null    
        //  1056: athrow         
        //    StackMapTable: 00 80 FF 00 03 00 02 07 00 03 01 00 01 07 00 40 FA 00 04 FF 00 0B 00 00 00 01 07 00 40 FC 00 03 07 00 03 09 05 42 01 18 01 4C 01 FF 00 02 00 01 07 00 03 00 02 01 01 5D 01 FF 00 0D 00 02 07 00 03 01 00 01 07 00 03 FF 00 02 00 02 07 00 03 01 00 02 07 00 03 01 5E 07 00 03 48 07 00 1D 40 07 00 A0 45 07 00 40 40 07 01 AB FF 00 15 00 03 07 00 03 01 01 00 01 07 00 03 FF 00 02 00 03 07 00 03 01 01 00 02 07 00 03 01 5D 07 00 03 4E 07 00 9A FF 00 02 00 03 07 00 03 01 01 00 02 07 00 9A 01 5D 07 00 9A 4E 07 00 A0 FF 00 02 00 03 07 00 03 01 01 00 02 07 00 A0 01 5D 07 00 A0 42 07 00 40 40 07 00 A0 45 07 00 40 40 07 01 AB 45 07 00 1B 40 03 45 07 00 40 40 01 FC 00 00 01 0B 42 01 1E FF 00 13 00 04 07 00 03 01 01 01 00 02 01 07 00 A0 FF 00 02 00 04 07 00 03 01 01 01 00 03 01 07 00 A0 01 FF 00 1C 00 04 07 00 03 01 01 01 00 02 01 07 00 A0 42 07 00 40 FF 00 00 00 04 07 00 03 01 01 01 00 02 01 07 00 A0 45 07 00 40 FF 00 00 00 04 07 00 03 01 01 01 00 02 01 07 01 AB 45 07 00 40 FF 00 00 00 04 07 00 03 01 01 01 00 02 01 03 45 07 00 40 FF 00 00 00 04 07 00 03 01 01 01 00 02 01 01 04 05 42 01 18 4F 07 00 9A FF 00 02 00 04 07 00 03 01 01 01 00 02 07 00 9A 01 5C 07 00 9A 45 07 00 40 40 07 00 A0 45 07 00 40 40 07 01 AB 4B 07 01 AB FF 00 02 00 04 07 00 03 01 01 01 00 02 07 01 AB 01 5E 07 01 AB 4E 03 FF 00 02 00 04 07 00 03 01 01 01 00 02 03 01 5D 03 42 07 00 40 40 03 45 07 00 40 40 01 4B 01 FF 00 02 00 04 07 00 03 01 01 01 00 02 01 01 5D 01 FC 00 01 01 FF 00 11 00 05 07 00 03 01 01 01 01 00 02 01 07 00 9A FF 00 02 00 05 07 00 03 01 01 01 01 00 03 01 07 00 9A 01 FF 00 1C 00 05 07 00 03 01 01 01 01 00 02 01 07 00 9A 45 07 00 40 FF 00 00 00 05 07 00 03 01 01 01 01 00 02 01 07 00 A0 45 07 00 40 FF 00 00 00 05 07 00 03 01 01 01 01 00 02 01 07 01 AB 45 07 00 40 FF 00 00 00 05 07 00 03 01 01 01 01 00 02 01 03 45 07 00 40 FF 00 00 00 05 07 00 03 01 01 01 01 00 02 01 01 56 07 00 33 FF 00 00 00 05 07 00 03 01 01 01 01 00 06 07 02 3A 08 03 38 08 03 38 01 01 01 45 07 00 40 FF 00 00 00 05 07 00 03 01 01 01 01 00 02 07 02 3A 07 00 DB FF 00 02 00 00 00 01 07 00 40 FF 00 00 00 05 07 00 03 01 01 01 01 00 02 07 02 3A 07 00 DB 45 07 00 40 40 07 02 40 FF 00 02 00 00 00 01 07 00 40 FF 00 00 00 05 07 00 03 01 01 01 01 00 01 07 02 40 47 07 00 40 40 07 01 62 FC 00 0D 07 01 62 42 01 1F 16 01 FA 00 05 FA 00 05 0B 42 01 1F FF 00 01 00 05 07 00 03 01 01 01 01 00 02 01 07 00 9A FF 00 01 00 04 07 00 03 01 01 01 00 02 01 07 00 A0 FF 00 01 00 03 07 00 03 01 01 00 01 07 00 03 41 07 00 9A FE 00 01 01 01 07 01 62 FF 00 01 00 02 07 00 03 01 00 01 07 00 03 FF 00 01 00 04 07 00 03 01 01 01 00 01 01 01 41 07 01 AB 41 03 01 FF 00 01 00 01 07 00 03 00 01 01 FF 00 01 00 03 07 00 03 01 01 00 01 07 00 A0 FF 00 01 00 04 07 00 03 01 01 01 00 01 07 00 9A FF 00 01 00 01 07 00 03 00 01 07 00 40 43 05 44 07 00 40 47 05 FF 00 07 00 02 07 00 03 01 00 01 07 00 40
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     1039   1047   Ljava/lang/AssertionError;
        //  1039   1047   1039   1047   Ljava/util/ConcurrentModificationException;
        //  1055   1057   3      8      Any
        //  173    180    180    181    Any
        //  173    180    173    174    Ljava/lang/NumberFormatException;
        //  173    180    180    181    Ljava/lang/IllegalArgumentException;
        //  173    180    180    181    Ljava/lang/AssertionError;
        //  174    180    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  335    342    342    343    Any
        //  336    342    342    343    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  335    342    335    336    Any
        //  335    342    342    343    Ljava/util/ConcurrentModificationException;
        //  336    342    335    336    Ljava/util/ConcurrentModificationException;
        //  349    356    356    357    Any
        //  349    356    3      8      Ljava/util/ConcurrentModificationException;
        //  350    356    3      8      Any
        //  349    356    349    350    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  349    356    356    357    Any
        //  459    466    466    467    Any
        //  459    466    459    460    Any
        //  460    466    459    460    Any
        //  460    466    459    460    Ljava/lang/IllegalStateException;
        //  459    466    459    460    Any
        //  473    480    480    481    Any
        //  473    480    480    481    Any
        //  473    480    473    474    Any
        //  473    480    3      8      Any
        //  474    480    480    481    Any
        //  574    581    581    582    Any
        //  574    581    574    575    Any
        //  574    581    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  575    581    581    582    Any
        //  574    581    574    575    Any
        //  679    686    686    687    Any
        //  679    686    686    687    Ljava/lang/NumberFormatException;
        //  680    686    3      8      Any
        //  680    686    679    680    Any
        //  679    686    679    680    Any
        //  790    797    797    798    Any
        //  791    797    797    798    Any
        //  790    797    790    791    Any
        //  791    797    797    798    Ljava/lang/NumberFormatException;
        //  791    797    3      8      Ljava/lang/IllegalStateException;
        //  804    811    811    812    Any
        //  805    811    811    812    Any
        //  805    811    811    812    Any
        //  804    811    811    812    Ljava/lang/NumberFormatException;
        //  804    811    804    805    Any
        //  835    842    842    843    Any
        //  835    842    3      8      Ljava/lang/IllegalStateException;
        //  835    842    3      8      Ljava/lang/EnumConstantNotPresentException;
        //  835    842    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  835    842    835    836    Ljava/lang/ArithmeticException;
        //  847    853    853    854    Any
        //  847    853    853    854    Ljava/lang/IndexOutOfBoundsException;
        //  847    853    3      8      Ljava/lang/NumberFormatException;
        //  847    853    853    854    Ljava/util/NoSuchElementException;
        //  847    853    3      8      Ljava/util/ConcurrentModificationException;
        //  858    866    866    867    Any
        //  858    866    866    867    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  858    866    3      8      Any
        //  858    866    3      8      Ljava/lang/ClassCastException;
        //  858    866    866    867    Ljava/lang/UnsupportedOperationException;
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 302 out of bounds for length 302
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @f0g
    @LauncherEventHide
    public void c(final f49 f49) {
        fez.3K(this, 1734420418, f49);
    }
    
    public f9u() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: ldc_w           "\u3ccf\ub240\u8f9c\uadb1\u67e1"
        //     4: invokestatic    invokestatic   !!! ERROR
        //     7: ldc_w           "\u3cef\ub240\u8f9c\uadb1\u67e1"
        //    10: invokestatic    invokestatic   !!! ERROR
        //    13: ldc_w           "\u3ce4\ub249\u8f83\uadab\u67e5\u5833\u7e00\u6881\uc2cc\ua301\u9a3c\u1310\uc0f6\u714e\u9034\u4c29\ub21d\u4d18\u0102\u07ce\u133e\ufe84\u6b58\u8855\u36c5\u3caa\u7fe9"
        //    16: invokestatic    invokestatic   !!! ERROR
        //    19: invokespecial   dev/nuker/pyro/fQ.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
        //    22: aload_0        
        //    23: new             Ldev/nuker/pyro/f0o;
        //    26: dup            
        //    27: ldc_w           "\u3cc8\ub24a\u8f8b\uada1"
        //    30: getstatic       dev/nuker/pyro/fc.1:I
        //    33: ifne            42
        //    36: ldc_w           -1248428617
        //    39: goto            45
        //    42: ldc_w           853494760
        //    45: ldc_w           -1013316399
        //    48: ixor           
        //    49: lookupswitch {
        //          -247115975: 76
        //          1980528998: 42
        //          default: 379
        //        }
        //    76: invokestatic    invokestatic   !!! ERROR
        //    79: ldc_w           "\u3ce8\ub24a\u8f8b\uada1"
        //    82: invokestatic    invokestatic   !!! ERROR
        //    85: aconst_null    
        //    86: getstatic       dev/nuker/pyro/f9t.c:Ldev/nuker/pyro/f9t;
        //    89: invokespecial   dev/nuker/pyro/f0o.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Enum;)V
        //    92: putfield        dev/nuker/pyro/f9u.c:Ldev/nuker/pyro/f0o;
        //    95: getstatic       dev/nuker/pyro/fc.0:I
        //    98: ifgt            107
        //   101: ldc_w           -601654006
        //   104: goto            110
        //   107: ldc_w           783142652
        //   110: ldc_w           -127667518
        //   113: ixor           
        //   114: lookupswitch {
        //          608210888: 381
        //          1275235326: 107
        //          default: 140
        //        }
        //   140: aload_0        
        //   141: new             Ldev/nuker/pyro/f0k;
        //   144: dup            
        //   145: ldc_w           "\u3ccb\ub246\u8f9f\uad97\u67e6\u5832\u7e49\u689b\uc2d7"
        //   148: getstatic       dev/nuker/pyro/fc.0:I
        //   151: ifgt            160
        //   154: ldc_w           -1630381362
        //   157: goto            163
        //   160: ldc_w           1189224160
        //   163: ldc_w           -2091715592
        //   166: ixor           
        //   167: lookupswitch {
        //          494971190: 377
        //          2138070720: 160
        //          default: 192
        //        }
        //   192: invokestatic    invokestatic   !!! ERROR
        //   195: ldc_w           "\u3ceb\ub266\u8fbf\uade4\u67c1\u5834\u7e52\u6891\uc2c0\ua300"
        //   198: invokestatic    invokestatic   !!! ERROR
        //   201: aconst_null    
        //   202: iconst_0       
        //   203: invokespecial   dev/nuker/pyro/f0k.<init>:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)V
        //   206: putfield        dev/nuker/pyro/f9u.c:Ldev/nuker/pyro/f0k;
        //   209: getstatic       dev/nuker/pyro/fc.0:I
        //   212: ifgt            221
        //   215: ldc_w           -1691152355
        //   218: goto            224
        //   221: ldc_w           142192270
        //   224: ldc_w           476706035
        //   227: ixor           
        //   228: lookupswitch {
        //          -2024086290: 373
        //          1723436907: 221
        //          default: 256
        //        }
        //   256: aload_0        
        //   257: iconst_0       
        //   258: putfield        dev/nuker/pyro/f9u.c:Z
        //   261: getstatic       dev/nuker/pyro/fc.c:I
        //   264: ifne            273
        //   267: ldc_w           1703255962
        //   270: goto            276
        //   273: ldc_w           -1160286883
        //   276: ldc_w           -1715812105
        //   279: ixor           
        //   280: lookupswitch {
        //          -1744210645: 273
        //          -62957715: 383
        //          default: 308
        //        }
        //   308: aload_0        
        //   309: aload_0        
        //   310: getstatic       dev/nuker/pyro/fc.1:I
        //   313: ifne            322
        //   316: ldc_w           208619356
        //   319: goto            325
        //   322: ldc_w           -1438290162
        //   325: ldc_w           -1056905971
        //   328: ixor           
        //   329: lookupswitch {
        //          -1845196333: 322
        //          -848321967: 375
        //          default: 356
        //        }
        //   356: getfield        dev/nuker/pyro/f9u.c:Ldev/nuker/pyro/f0o;
        //   359: invokevirtual   dev/nuker/pyro/f9u.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   362: pop            
        //   363: aload_0        
        //   364: aload_0        
        //   365: getfield        dev/nuker/pyro/f9u.c:Ldev/nuker/pyro/f0k;
        //   368: invokevirtual   dev/nuker/pyro/f9u.c:(Ldev/nuker/pyro/f0w;)Ldev/nuker/pyro/f0w;
        //   371: pop            
        //   372: return         
        //   373: aconst_null    
        //   374: athrow         
        //   375: aconst_null    
        //   376: athrow         
        //   377: aconst_null    
        //   378: athrow         
        //   379: aconst_null    
        //   380: athrow         
        //   381: aconst_null    
        //   382: athrow         
        //   383: aconst_null    
        //   384: athrow         
        //    StackMapTable: 00 18 FF 00 2A 00 01 07 00 03 00 04 07 00 03 08 00 17 08 00 17 07 00 68 FF 00 02 00 01 07 00 03 00 05 07 00 03 08 00 17 08 00 17 07 00 68 01 FF 00 1E 00 01 07 00 03 00 04 07 00 03 08 00 17 08 00 17 07 00 68 1E 42 01 1D FF 00 13 00 01 07 00 03 00 04 07 00 03 08 00 8D 08 00 8D 07 00 68 FF 00 02 00 01 07 00 03 00 05 07 00 03 08 00 8D 08 00 8D 07 00 68 01 FF 00 1C 00 01 07 00 03 00 04 07 00 03 08 00 8D 08 00 8D 07 00 68 1C 42 01 1F 10 42 01 1F FF 00 0D 00 01 07 00 03 00 02 07 00 03 07 00 03 FF 00 02 00 01 07 00 03 00 03 07 00 03 07 00 03 01 FF 00 1E 00 01 07 00 03 00 02 07 00 03 07 00 03 10 FF 00 01 00 01 07 00 03 00 02 07 00 03 07 00 03 FF 00 01 00 01 07 00 03 00 04 07 00 03 08 00 8D 08 00 8D 07 00 68 FF 00 01 00 01 07 00 03 00 04 07 00 03 08 00 17 08 00 17 07 00 68 01 01
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Invalid BootstrapMethods attribute entry: 21 additional arguments required for method a.a, but only 0 specified.
        //     at com.strobel.assembler.ir.Error.invalidBootstrapMethodEntry(Error.java:244)
        //     at com.strobel.assembler.ir.MetadataReader.readAttributeCore(MetadataReader.java:280)
        //     at com.strobel.assembler.metadata.ClassFileReader.readAttributeCore(ClassFileReader.java:261)
        //     at com.strobel.assembler.ir.MetadataReader.inflateAttributes(MetadataReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.visitAttributes(ClassFileReader.java:1134)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:439)
        //     at com.strobel.assembler.metadata.ClassFileReader.readClass(ClassFileReader.java:377)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveType(MetadataSystem.java:129)
        //     at com.strobel.decompiler.NoRetryMetadataSystem.resolveType(DecompilerDriver.java:476)
        //     at com.strobel.assembler.metadata.MetadataSystem.resolveCore(MetadataSystem.java:81)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:104)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:616)
        //     at com.strobel.assembler.metadata.MetadataResolver.resolve(MetadataResolver.java:128)
        //     at com.strobel.assembler.metadata.CoreMetadataFactory$UnresolvedType.resolve(CoreMetadataFactory.java:626)
        //     at com.strobel.assembler.metadata.MethodReference.resolve(MethodReference.java:177)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2438)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferCall(TypeAnalysis.java:2695)
        //     at com.strobel.decompiler.ast.TypeAnalysis.doInferTypeForExpression(TypeAnalysis.java:1029)
        //     at com.strobel.decompiler.ast.TypeAnalysis.inferTypeForExpression(TypeAnalysis.java:803)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:672)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:655)
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:365)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:109)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public boolean 0() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          1343
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.1:I
        //    12: ifeq            1335
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            1327
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: ldc_w           0.05
        //    27: fstore_1       
        //    28: aload_0        
        //    29: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //    32: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //    35: ifnonnull       44
        //    38: ldc_w           1624371826
        //    41: goto            47
        //    44: ldc_w           1624371825
        //    47: ldc_w           -2056620365
        //    50: ixor           
        //    51: tableswitch {
        //          -881391230: 72
        //          -881391229: 74
        //          default: 38
        //        }
        //    72: iconst_0       
        //    73: ireturn        
        //    74: aload_0        
        //    75: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //    78: getstatic       dev/nuker/pyro/fc.c:I
        //    81: ifne            90
        //    84: ldc_w           -1942336244
        //    87: goto            93
        //    90: ldc_w           1699144637
        //    93: ldc_w           1662493687
        //    96: ixor           
        //    97: lookupswitch {
        //          -282202373: 90
        //          105988170: 124
        //          default: 1306
        //        }
        //   124: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   127: getstatic       dev/nuker/pyro/fc.c:I
        //   130: ifne            139
        //   133: ldc_w           1235602601
        //   136: goto            142
        //   139: ldc_w           319394446
        //   142: ldc_w           1285227672
        //   145: ixor           
        //   146: lookupswitch {
        //          88000561: 139
        //          1603442198: 172
        //          default: 1308
        //        }
        //   172: getfield        net/minecraft/client/entity/EntityPlayerSP.field_70143_R:F
        //   175: ldc_w           3.0
        //   178: fcmpl          
        //   179: iflt            184
        //   182: iconst_0       
        //   183: ireturn        
        //   184: getstatic       dev/nuker/pyro/fc.0:I
        //   187: ifgt            196
        //   190: ldc_w           1562327969
        //   193: goto            199
        //   196: ldc_w           -373018846
        //   199: ldc_w           2121594183
        //   202: ixor           
        //   203: lookupswitch {
        //          -1750017435: 228
        //          594267878: 196
        //          default: 1282
        //        }
        //   228: aload_0        
        //   229: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //   232: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   235: ifnull          1278
        //   238: aload_0        
        //   239: getstatic       dev/nuker/pyro/fc.1:I
        //   242: ifne            251
        //   245: ldc_w           -1297563988
        //   248: goto            254
        //   251: ldc_w           22712320
        //   254: ldc_w           -505244885
        //   257: ixor           
        //   258: lookupswitch {
        //          400673711: 251
        //          1397370247: 1292
        //          default: 284
        //        }
        //   284: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //   287: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   290: goto            294
        //   293: athrow         
        //   294: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_184187_bx:()Lnet/minecraft/entity/Entity;
        //   297: goto            301
        //   300: athrow         
        //   301: ifnull          506
        //   304: aload_0        
        //   305: getstatic       dev/nuker/pyro/fc.c:I
        //   308: ifne            317
        //   311: ldc_w           1139692041
        //   314: goto            320
        //   317: ldc_w           -1376166160
        //   320: ldc_w           -1564475668
        //   323: ixor           
        //   324: lookupswitch {
        //          -514741019: 317
        //          256286748: 352
        //          default: 1280
        //        }
        //   352: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //   355: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   358: getstatic       dev/nuker/pyro/fc.0:I
        //   361: ifgt            370
        //   364: ldc_w           -1027311074
        //   367: goto            373
        //   370: ldc_w           -1480253164
        //   373: ldc_w           -1636686273
        //   376: ixor           
        //   377: lookupswitch {
        //          -2081197797: 370
        //          1555455009: 1296
        //          default: 404
        //        }
        //   404: goto            408
        //   407: athrow         
        //   408: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_184187_bx:()Lnet/minecraft/entity/Entity;
        //   411: goto            415
        //   414: athrow         
        //   415: goto            419
        //   418: athrow         
        //   419: invokevirtual   net/minecraft/entity/Entity.func_174813_aQ:()Lnet/minecraft/util/math/AxisAlignedBB;
        //   422: goto            426
        //   425: athrow         
        //   426: dconst_0       
        //   427: dconst_0       
        //   428: dconst_0       
        //   429: getstatic       dev/nuker/pyro/fc.0:I
        //   432: ifgt            441
        //   435: ldc_w           2110807000
        //   438: goto            444
        //   441: ldc_w           -1571268342
        //   444: ldc_w           588855616
        //   447: ixor           
        //   448: lookupswitch {
        //          -2126421942: 476
        //          1590256280: 441
        //          default: 1294
        //        }
        //   476: goto            480
        //   479: athrow         
        //   480: invokevirtual   net/minecraft/util/math/AxisAlignedBB.func_191195_a:(DDD)Lnet/minecraft/util/math/AxisAlignedBB;
        //   483: goto            487
        //   486: athrow         
        //   487: dconst_0       
        //   488: ldc2_w          -0.05000000074505806
        //   491: dconst_0       
        //   492: goto            496
        //   495: athrow         
        //   496: invokevirtual   net/minecraft/util/math/AxisAlignedBB.func_72317_d:(DDD)Lnet/minecraft/util/math/AxisAlignedBB;
        //   499: goto            503
        //   502: athrow         
        //   503: goto            554
        //   506: aload_0        
        //   507: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //   510: getfield        net/minecraft/client/Minecraft.field_71439_g:Lnet/minecraft/client/entity/EntityPlayerSP;
        //   513: goto            517
        //   516: athrow         
        //   517: invokevirtual   net/minecraft/client/entity/EntityPlayerSP.func_174813_aQ:()Lnet/minecraft/util/math/AxisAlignedBB;
        //   520: goto            524
        //   523: athrow         
        //   524: dconst_0       
        //   525: dconst_0       
        //   526: dconst_0       
        //   527: goto            531
        //   530: athrow         
        //   531: invokevirtual   net/minecraft/util/math/AxisAlignedBB.func_191195_a:(DDD)Lnet/minecraft/util/math/AxisAlignedBB;
        //   534: goto            538
        //   537: athrow         
        //   538: dconst_0       
        //   539: ldc2_w          -0.05000000074505806
        //   542: dconst_0       
        //   543: goto            547
        //   546: athrow         
        //   547: invokevirtual   net/minecraft/util/math/AxisAlignedBB.func_72317_d:(DDD)Lnet/minecraft/util/math/AxisAlignedBB;
        //   550: goto            554
        //   553: athrow         
        //   554: getstatic       dev/nuker/pyro/fc.c:I
        //   557: ifne            566
        //   560: ldc_w           -1042527133
        //   563: goto            569
        //   566: ldc_w           1369562122
        //   569: ldc_w           1507465139
        //   572: ixor           
        //   573: lookupswitch {
        //          -1744413744: 566
        //          142330809: 600
        //          default: 1302
        //        }
        //   600: astore_2       
        //   601: iconst_0       
        //   602: getstatic       dev/nuker/pyro/fc.1:I
        //   605: ifne            614
        //   608: ldc_w           841565729
        //   611: goto            617
        //   614: ldc_w           1869008528
        //   617: ldc_w           -205049146
        //   620: ixor           
        //   621: lookupswitch {
        //          -1667105706: 648
        //          -1041337113: 614
        //          default: 1284
        //        }
        //   648: istore_3       
        //   649: aload_2        
        //   650: getfield        net/minecraft/util/math/AxisAlignedBB.field_72338_b:D
        //   653: d2i            
        //   654: istore          4
        //   656: aload_2        
        //   657: getstatic       dev/nuker/pyro/fc.0:I
        //   660: ifgt            669
        //   663: ldc_w           1818258950
        //   666: goto            672
        //   669: ldc_w           830157323
        //   672: ldc_w           -1121139859
        //   675: ixor           
        //   676: lookupswitch {
        //          -783504021: 1310
        //          530790226: 669
        //          default: 704
        //        }
        //   704: getfield        net/minecraft/util/math/AxisAlignedBB.field_72340_a:D
        //   707: getstatic       dev/nuker/pyro/fc.c:I
        //   710: ifne            719
        //   713: ldc_w           1295593761
        //   716: goto            722
        //   719: ldc_w           1816114774
        //   722: ldc_w           1131354899
        //   725: ixor           
        //   726: lookupswitch {
        //          240527922: 719
        //          793816389: 752
        //          default: 1314
        //        }
        //   752: goto            756
        //   755: athrow         
        //   756: invokestatic    net/minecraft/util/math/MathHelper.func_76128_c:(D)I
        //   759: goto            763
        //   762: athrow         
        //   763: istore          5
        //   765: getstatic       dev/nuker/pyro/fc.1:I
        //   768: ifne            777
        //   771: ldc_w           -285809254
        //   774: goto            780
        //   777: ldc_w           -1888907035
        //   780: ldc_w           1603414111
        //   783: ixor           
        //   784: lookupswitch {
        //          -1318793787: 1304
        //          922431364: 777
        //          default: 812
        //        }
        //   812: iload           5
        //   814: aload_2        
        //   815: getfield        net/minecraft/util/math/AxisAlignedBB.field_72336_d:D
        //   818: dconst_1       
        //   819: dadd           
        //   820: getstatic       dev/nuker/pyro/fc.c:I
        //   823: ifne            832
        //   826: ldc_w           454369837
        //   829: goto            835
        //   832: ldc_w           1705335271
        //   835: ldc_w           1989039796
        //   838: ixor           
        //   839: lookupswitch {
        //          321589075: 864
        //          1838904473: 832
        //          default: 1288
        //        }
        //   864: goto            868
        //   867: athrow         
        //   868: invokestatic    net/minecraft/util/math/MathHelper.func_76128_c:(D)I
        //   871: goto            875
        //   874: athrow         
        //   875: if_icmpge       1229
        //   878: aload_2        
        //   879: getstatic       dev/nuker/pyro/fc.0:I
        //   882: ifgt            891
        //   885: ldc_w           -739131497
        //   888: goto            894
        //   891: ldc_w           -844362365
        //   894: ldc_w           101122891
        //   897: ixor           
        //   898: lookupswitch {
        //          -705250084: 1290
        //          1640308671: 891
        //          default: 924
        //        }
        //   924: getfield        net/minecraft/util/math/AxisAlignedBB.field_72339_c:D
        //   927: goto            931
        //   930: athrow         
        //   931: invokestatic    net/minecraft/util/math/MathHelper.func_76128_c:(D)I
        //   934: goto            938
        //   937: athrow         
        //   938: istore          6
        //   940: getstatic       dev/nuker/pyro/fc.1:I
        //   943: ifne            952
        //   946: ldc_w           380475839
        //   949: goto            955
        //   952: ldc_w           1577060024
        //   955: ldc_w           2040484074
        //   958: ixor           
        //   959: lookupswitch {
        //          1865599317: 1286
        //          1911542797: 952
        //          default: 984
        //        }
        //   984: iload           6
        //   986: aload_2        
        //   987: getfield        net/minecraft/util/math/AxisAlignedBB.field_72334_f:D
        //   990: dconst_1       
        //   991: dadd           
        //   992: goto            996
        //   995: athrow         
        //   996: invokestatic    net/minecraft/util/math/MathHelper.func_76128_c:(D)I
        //   999: goto            1003
        //  1002: athrow         
        //  1003: if_icmpge       1223
        //  1006: getstatic       dev/nuker/pyro/fc.0:I
        //  1009: ifgt            1018
        //  1012: ldc_w           952794190
        //  1015: goto            1021
        //  1018: ldc_w           102881494
        //  1021: ldc_w           2092680001
        //  1024: ixor           
        //  1025: lookupswitch {
        //          -2105183849: 1018
        //          1148305167: 1298
        //          default: 1052
        //        }
        //  1052: aload_0        
        //  1053: getfield        dev/nuker/pyro/f9u.c:Lnet/minecraft/client/Minecraft;
        //  1056: getfield        net/minecraft/client/Minecraft.field_71441_e:Lnet/minecraft/client/multiplayer/WorldClient;
        //  1059: new             Lnet/minecraft/util/math/BlockPos;
        //  1062: dup            
        //  1063: iload           5
        //  1065: iload           4
        //  1067: iload           6
        //  1069: goto            1073
        //  1072: athrow         
        //  1073: invokespecial   net/minecraft/util/math/BlockPos.<init>:(III)V
        //  1076: goto            1080
        //  1079: athrow         
        //  1080: goto            1084
        //  1083: athrow         
        //  1084: invokevirtual   net/minecraft/client/multiplayer/WorldClient.func_180495_p:(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
        //  1087: goto            1091
        //  1090: athrow         
        //  1091: getstatic       dev/nuker/pyro/fc.c:I
        //  1094: ifne            1103
        //  1097: ldc_w           1122104823
        //  1100: goto            1106
        //  1103: ldc_w           1444689037
        //  1106: ldc_w           806115915
        //  1109: ixor           
        //  1110: lookupswitch {
        //          1712352966: 1136
        //          1928179644: 1103
        //          default: 1300
        //        }
        //  1136: goto            1140
        //  1139: athrow         
        //  1140: invokeinterface net/minecraft/block/state/IBlockState.func_177230_c:()Lnet/minecraft/block/Block;
        //  1145: goto            1149
        //  1148: athrow         
        //  1149: astore          7
        //  1151: aload           7
        //  1153: getstatic       net/minecraft/init/Blocks.field_150350_a:Lnet/minecraft/block/Block;
        //  1156: if_acmpeq       1217
        //  1159: aload           7
        //  1161: instanceof      Lnet/minecraft/block/BlockLiquid;
        //  1164: ifne            1169
        //  1167: iconst_0       
        //  1168: ireturn        
        //  1169: iconst_1       
        //  1170: getstatic       dev/nuker/pyro/fc.0:I
        //  1173: ifgt            1182
        //  1176: ldc_w           -297325162
        //  1179: goto            1185
        //  1182: ldc_w           2141468552
        //  1185: ldc_w           1189502632
        //  1188: ixor           
        //  1189: lookupswitch {
        //          -1465814210: 1182
        //          960653600: 1216
        //          default: 1312
        //        }
        //  1216: istore_3       
        //  1217: iinc            6, 1
        //  1220: goto            940
        //  1223: iinc            5, 1
        //  1226: goto            765
        //  1229: getstatic       dev/nuker/pyro/fc.1:I
        //  1232: ifne            1241
        //  1235: ldc_w           893946070
        //  1238: goto            1244
        //  1241: ldc_w           -2118815128
        //  1244: ldc_w           -1567829196
        //  1247: ixor           
        //  1248: lookupswitch {
        //          -1748739102: 1241
        //          590979420: 1276
        //          default: 1316
        //        }
        //  1276: iload_3        
        //  1277: ireturn        
        //  1278: iconst_0       
        //  1279: ireturn        
        //  1280: aconst_null    
        //  1281: athrow         
        //  1282: aconst_null    
        //  1283: athrow         
        //  1284: aconst_null    
        //  1285: athrow         
        //  1286: aconst_null    
        //  1287: athrow         
        //  1288: aconst_null    
        //  1289: athrow         
        //  1290: aconst_null    
        //  1291: athrow         
        //  1292: aconst_null    
        //  1293: athrow         
        //  1294: aconst_null    
        //  1295: athrow         
        //  1296: aconst_null    
        //  1297: athrow         
        //  1298: aconst_null    
        //  1299: athrow         
        //  1300: aconst_null    
        //  1301: athrow         
        //  1302: aconst_null    
        //  1303: athrow         
        //  1304: aconst_null    
        //  1305: athrow         
        //  1306: aconst_null    
        //  1307: athrow         
        //  1308: aconst_null    
        //  1309: athrow         
        //  1310: aconst_null    
        //  1311: athrow         
        //  1312: aconst_null    
        //  1313: athrow         
        //  1314: aconst_null    
        //  1315: athrow         
        //  1316: aconst_null    
        //  1317: athrow         
        //  1318: pop            
        //  1319: goto            24
        //  1322: pop            
        //  1323: aconst_null    
        //  1324: goto            1318
        //  1327: dup            
        //  1328: ifnull          1318
        //  1331: checkcast       Ljava/lang/Throwable;
        //  1334: athrow         
        //  1335: dup            
        //  1336: ifnull          1322
        //  1339: checkcast       Ljava/lang/Throwable;
        //  1342: athrow         
        //  1343: aconst_null    
        //  1344: athrow         
        //    StackMapTable: 00 9F FF 00 03 00 02 07 00 03 02 00 01 07 00 40 FA 00 04 FF 00 0B 00 00 00 01 07 00 40 FC 00 03 07 00 03 FC 00 0D 02 05 42 01 18 01 4F 07 00 9A FF 00 02 00 02 07 00 03 02 00 02 07 00 9A 01 5E 07 00 9A 4E 07 00 A0 FF 00 02 00 02 07 00 03 02 00 02 07 00 A0 01 5D 07 00 A0 0B 0B 42 01 1C 56 07 00 03 FF 00 02 00 02 07 00 03 02 00 02 07 00 03 01 5D 07 00 03 FF 00 08 00 00 00 01 07 00 40 FF 00 00 00 02 07 00 03 02 00 01 07 00 A0 45 07 00 40 40 07 01 F0 4F 07 00 03 FF 00 02 00 02 07 00 03 02 00 02 07 00 03 01 5F 07 00 03 51 07 00 A0 FF 00 02 00 02 07 00 03 02 00 02 07 00 A0 01 5E 07 00 A0 42 07 00 40 40 07 00 A0 45 07 00 40 40 07 01 F0 42 07 00 40 40 07 01 F0 45 07 00 40 40 07 01 AB FF 00 0E 00 02 07 00 03 02 00 04 07 01 AB 03 03 03 FF 00 02 00 02 07 00 03 02 00 05 07 01 AB 03 03 03 01 FF 00 1F 00 02 07 00 03 02 00 04 07 01 AB 03 03 03 42 07 00 39 FF 00 00 00 02 07 00 03 02 00 04 07 01 AB 03 03 03 45 07 00 40 40 07 01 AB FF 00 07 00 00 00 01 07 00 40 FF 00 00 00 02 07 00 03 02 00 04 07 01 AB 03 03 03 45 07 00 40 40 07 01 AB 02 49 07 00 1B 40 07 00 A0 45 07 00 40 40 07 01 AB FF 00 05 00 00 00 01 07 00 40 FF 00 00 00 02 07 00 03 02 00 04 07 01 AB 03 03 03 45 07 00 40 40 07 01 AB 47 07 00 40 FF 00 00 00 02 07 00 03 02 00 04 07 01 AB 03 03 03 45 07 00 40 40 07 01 AB 4B 07 01 AB FF 00 02 00 02 07 00 03 02 00 02 07 01 AB 01 5E 07 01 AB FF 00 0D 00 03 07 00 03 02 07 01 AB 00 01 01 FF 00 02 00 03 07 00 03 02 07 01 AB 00 02 01 01 5E 01 FF 00 14 00 05 07 00 03 02 07 01 AB 01 01 00 01 07 01 AB FF 00 02 00 05 07 00 03 02 07 01 AB 01 01 00 02 07 01 AB 01 5F 07 01 AB 4E 03 FF 00 02 00 05 07 00 03 02 07 01 AB 01 01 00 02 03 01 5D 03 FF 00 02 00 00 00 01 07 00 40 FF 00 00 00 05 07 00 03 02 07 01 AB 01 01 00 01 03 45 07 00 40 40 01 FC 00 01 01 0B 42 01 1F FF 00 13 00 06 07 00 03 02 07 01 AB 01 01 01 00 02 01 03 FF 00 02 00 06 07 00 03 02 07 01 AB 01 01 01 00 03 01 03 01 FF 00 1C 00 06 07 00 03 02 07 01 AB 01 01 01 00 02 01 03 42 07 00 21 FF 00 00 00 06 07 00 03 02 07 01 AB 01 01 01 00 02 01 03 45 07 00 40 FF 00 00 00 06 07 00 03 02 07 01 AB 01 01 01 00 02 01 01 4F 07 01 AB FF 00 02 00 06 07 00 03 02 07 01 AB 01 01 01 00 02 07 01 AB 01 5D 07 01 AB 45 07 00 40 40 03 45 07 00 40 40 01 FC 00 01 01 0B 42 01 1C 4A 07 00 31 FF 00 00 00 07 07 00 03 02 07 01 AB 01 01 01 01 00 02 01 03 45 07 00 40 FF 00 00 00 07 07 00 03 02 07 01 AB 01 01 01 01 00 02 01 01 0E 42 01 1E 53 07 00 40 FF 00 00 00 07 07 00 03 02 07 01 AB 01 01 01 01 00 06 07 02 3A 08 04 23 08 04 23 01 01 01 45 07 00 40 FF 00 00 00 07 07 00 03 02 07 01 AB 01 01 01 01 00 02 07 02 3A 07 00 DB FF 00 02 00 00 00 01 07 00 40 FF 00 00 00 07 07 00 03 02 07 01 AB 01 01 01 01 00 02 07 02 3A 07 00 DB 45 07 00 40 40 07 02 40 4B 07 02 40 FF 00 02 00 07 07 00 03 02 07 01 AB 01 01 01 01 00 02 07 02 40 01 5D 07 02 40 42 07 00 40 40 07 02 40 47 07 00 40 40 07 01 62 FC 00 13 07 01 62 4C 01 FF 00 02 00 08 07 00 03 02 07 01 AB 01 01 01 01 07 01 62 00 02 01 01 5E 01 00 FA 00 05 FA 00 05 0B 42 01 1F FF 00 01 00 02 07 00 03 02 00 00 41 07 00 03 01 FF 00 01 00 03 07 00 03 02 07 01 AB 00 01 01 FF 00 01 00 07 07 00 03 02 07 01 AB 01 01 01 01 00 00 FF 00 01 00 06 07 00 03 02 07 01 AB 01 01 01 00 02 01 03 41 07 01 AB FF 00 01 00 02 07 00 03 02 00 01 07 00 03 FF 00 01 00 02 07 00 03 02 00 04 07 01 AB 03 03 03 41 07 00 A0 FF 00 01 00 07 07 00 03 02 07 01 AB 01 01 01 01 00 00 41 07 02 40 FF 00 01 00 02 07 00 03 02 00 01 07 01 AB FF 00 01 00 06 07 00 03 02 07 01 AB 01 01 01 00 00 FF 00 01 00 02 07 00 03 02 00 01 07 00 9A 41 07 00 A0 FF 00 01 00 05 07 00 03 02 07 01 AB 01 01 00 01 07 01 AB FF 00 01 00 08 07 00 03 02 07 01 AB 01 01 01 01 07 01 62 00 01 01 FF 00 01 00 05 07 00 03 02 07 01 AB 01 01 00 01 03 FC 00 01 01 FF 00 01 00 01 07 00 03 00 01 07 00 39 43 05 44 07 00 39 47 05 FF 00 07 00 02 07 00 03 02 00 01 07 00 40
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     1327   1335   Ljava/lang/IllegalStateException;
        //  1327   1335   1327   1335   Ljava/util/ConcurrentModificationException;
        //  1343   1345   3      8      Ljava/lang/IllegalArgumentException;
        //  294    300    300    301    Any
        //  294    300    300    301    Ljava/lang/StringIndexOutOfBoundsException;
        //  294    300    3      8      Any
        //  294    300    300    301    Ljava/lang/UnsupportedOperationException;
        //  294    300    3      8      Any
        //  407    414    414    415    Any
        //  408    414    407    408    Ljava/lang/ArithmeticException;
        //  408    414    3      8      Ljava/lang/IllegalArgumentException;
        //  407    414    407    408    Ljava/util/NoSuchElementException;
        //  407    414    407    408    Any
        //  418    425    425    426    Any
        //  418    425    425    426    Ljava/lang/UnsupportedOperationException;
        //  418    425    418    419    Any
        //  419    425    3      8      Any
        //  418    425    425    426    Any
        //  479    486    486    487    Any
        //  480    486    479    480    Ljava/util/ConcurrentModificationException;
        //  479    486    479    480    Ljava/lang/ArithmeticException;
        //  480    486    479    480    Ljava/lang/NullPointerException;
        //  480    486    3      8      Any
        //  496    502    502    503    Any
        //  496    502    502    503    Any
        //  496    502    3      8      Any
        //  496    502    502    503    Ljava/lang/EnumConstantNotPresentException;
        //  496    502    3      8      Any
        //  516    523    523    524    Any
        //  516    523    3      8      Any
        //  517    523    3      8      Ljava/lang/NullPointerException;
        //  517    523    516    517    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  517    523    523    524    Any
        //  531    537    537    538    Any
        //  531    537    3      8      Ljava/util/ConcurrentModificationException;
        //  531    537    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  531    537    537    538    Any
        //  531    537    537    538    Ljava/util/ConcurrentModificationException;
        //  546    553    553    554    Any
        //  547    553    553    554    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  547    553    553    554    Any
        //  547    553    3      8      Any
        //  547    553    546    547    Any
        //  756    762    762    763    Any
        //  756    762    762    763    Any
        //  756    762    762    763    Any
        //  756    762    3      8      Ljava/lang/UnsupportedOperationException;
        //  756    762    3      8      Ljava/lang/RuntimeException;
        //  867    874    874    875    Any
        //  867    874    874    875    Any
        //  868    874    874    875    Ljava/util/ConcurrentModificationException;
        //  867    874    874    875    Ljava/lang/IllegalArgumentException;
        //  867    874    867    868    Ljava/util/ConcurrentModificationException;
        //  930    937    937    938    Any
        //  930    937    3      8      Any
        //  930    937    937    938    Any
        //  930    937    930    931    Any
        //  930    937    930    931    Any
        //  995    1002   1002   1003   Any
        //  995    1002   1002   1003   Ljava/lang/UnsupportedOperationException;
        //  995    1002   1002   1003   Any
        //  996    1002   3      8      Any
        //  995    1002   995    996    Ljava/lang/AssertionError;
        //  1072   1079   1079   1080   Any
        //  1073   1079   1072   1073   Any
        //  1073   1079   3      8      Any
        //  1072   1079   1072   1073   Ljava/util/NoSuchElementException;
        //  1072   1079   1072   1073   Any
        //  1084   1090   1090   1091   Any
        //  1084   1090   1090   1091   Any
        //  1084   1090   1090   1091   Ljava/lang/EnumConstantNotPresentException;
        //  1084   1090   3      8      Ljava/lang/IndexOutOfBoundsException;
        //  1084   1090   1090   1091   Any
        //  1139   1148   1148   1149   Any
        //  1140   1148   1139   1140   Any
        //  1139   1148   1148   1149   Any
        //  1140   1148   1148   1149   Ljava/util/ConcurrentModificationException;
        //  1140   1148   1139   1140   Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:595)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}
