// 
// Decompiled by Procyon v0.5.36
// 

package dev.nuker.pyro;

import org.jetbrains.annotations.NotNull;

public class f0K extends f0Y
{
    @NotNull
    public String c;
    @NotNull
    public fw<Boolean> c;
    
    public void c(@NotNull final fw fw) {
        fez.2w(this, 581371043, fw);
    }
    
    @Override
    public void 0(@NotNull final f0F p0, final double p1, final double p2, @NotNull final f0H p3) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          1005
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.c:I
        //    12: ifeq            997
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            989
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: aload           6
        //    28: pop            
        //    29: aload_0        
        //    30: getstatic       dev/nuker/pyro/fc.1:I
        //    33: ifne            41
        //    36: ldc             -1234493197
        //    38: goto            43
        //    41: ldc             2044336659
        //    43: ldc             454335178
        //    45: ixor           
        //    46: lookupswitch {
        //          -1384138183: 958
        //          1485181894: 41
        //          default: 72
        //        }
        //    72: aload_1        
        //    73: getstatic       dev/nuker/pyro/fc.0:I
        //    76: ifgt            84
        //    79: ldc             485744782
        //    81: goto            86
        //    84: ldc             363987982
        //    86: ldc             1867984643
        //    88: ixor           
        //    89: lookupswitch {
        //          -252497162: 84
        //          1940180877: 964
        //          default: 116
        //        }
        //   116: dload_2        
        //   117: dload           4
        //   119: aload           6
        //   121: goto            125
        //   124: athrow         
        //   125: invokespecial   dev/nuker/pyro/f0Y.0:(Ldev/nuker/pyro/f0F;DDLdev/nuker/pyro/f0H;)V
        //   128: goto            132
        //   131: athrow         
        //   132: getstatic       dev/nuker/pyro/f0J.c:Ldev/nuker/pyro/f0J;
        //   135: aload_1        
        //   136: goto            140
        //   139: athrow         
        //   140: invokevirtual   dev/nuker/pyro/f0F.0:()Lnet/minecraft/client/gui/FontRenderer;
        //   143: goto            147
        //   146: athrow         
        //   147: aload_0        
        //   148: getfield        dev/nuker/pyro/f0K.c:Ljava/lang/String;
        //   151: iconst_0       
        //   152: iconst_0       
        //   153: aload_1        
        //   154: goto            158
        //   157: athrow         
        //   158: invokevirtual   dev/nuker/pyro/f0F.1:()I
        //   161: goto            165
        //   164: athrow         
        //   165: iconst_4       
        //   166: isub           
        //   167: aload_1        
        //   168: goto            172
        //   171: athrow         
        //   172: invokevirtual   dev/nuker/pyro/f0F.3:()I
        //   175: goto            179
        //   178: athrow         
        //   179: getstatic       dev/nuker/pyro/f0H.c:Ldev/nuker/pyro/f0G;
        //   182: getstatic       dev/nuker/pyro/f0H.c:I
        //   185: aload           6
        //   187: getstatic       dev/nuker/pyro/fc.c:I
        //   190: ifne            198
        //   193: ldc             -782892676
        //   195: goto            200
        //   198: ldc             -308322955
        //   200: ldc             -1407501003
        //   202: ixor           
        //   203: lookupswitch {
        //          424657395: 198
        //          2102213705: 968
        //          default: 228
        //        }
        //   228: goto            232
        //   231: athrow         
        //   232: invokevirtual   dev/nuker/pyro/f0H.b:()I
        //   235: goto            239
        //   238: athrow         
        //   239: iconst_0       
        //   240: sipush          512
        //   243: aconst_null    
        //   244: goto            248
        //   247: athrow         
        //   248: invokestatic    dev/nuker/pyro/f0J.c:(Ldev/nuker/pyro/f0J;Lnet/minecraft/client/gui/FontRenderer;Ljava/lang/String;IIIILdev/nuker/pyro/f0G;IIZILjava/lang/Object;)V
        //   251: goto            255
        //   254: athrow         
        //   255: aload_1        
        //   256: goto            260
        //   259: athrow         
        //   260: invokevirtual   dev/nuker/pyro/f0F.1:()I
        //   263: goto            267
        //   266: athrow         
        //   267: getstatic       dev/nuker/pyro/f0H.c:I
        //   270: isub           
        //   271: istore          7
        //   273: getstatic       dev/nuker/pyro/fc.c:I
        //   276: ifne            284
        //   279: ldc             -1063557844
        //   281: goto            286
        //   284: ldc             -58601028
        //   286: ldc             182594137
        //   288: ixor           
        //   289: lookupswitch {
        //          -898019467: 976
        //          1445393132: 284
        //          default: 316
        //        }
        //   316: aload_1        
        //   317: getstatic       dev/nuker/pyro/fc.0:I
        //   320: ifgt            328
        //   323: ldc             -723007065
        //   325: goto            330
        //   328: ldc             -578643498
        //   330: ldc             588387571
        //   332: ixor           
        //   333: lookupswitch {
        //          -134881964: 328
        //          -24081115: 360
        //          default: 970
        //        }
        //   360: goto            364
        //   363: athrow         
        //   364: invokevirtual   dev/nuker/pyro/f0F.3:()I
        //   367: goto            371
        //   370: athrow         
        //   371: getstatic       dev/nuker/pyro/fc.1:I
        //   374: ifne            382
        //   377: ldc             -2092681257
        //   379: goto            384
        //   382: ldc             -1220483336
        //   384: ldc             -160573783
        //   386: ixor           
        //   387: lookupswitch {
        //          -680326725: 382
        //          1965678974: 974
        //          default: 412
        //        }
        //   412: getstatic       dev/nuker/pyro/f0H.c:I
        //   415: iconst_2       
        //   416: imul           
        //   417: isub           
        //   418: iconst_2       
        //   419: imul           
        //   420: istore          8
        //   422: aload_1        
        //   423: goto            427
        //   426: athrow         
        //   427: invokevirtual   dev/nuker/pyro/f0F.3:()I
        //   430: goto            434
        //   433: athrow         
        //   434: getstatic       dev/nuker/pyro/f0H.c:I
        //   437: iconst_2       
        //   438: imul           
        //   439: isub           
        //   440: iconst_1       
        //   441: isub           
        //   442: istore          9
        //   444: iload           7
        //   446: iload           8
        //   448: isub           
        //   449: getstatic       dev/nuker/pyro/f0H.c:I
        //   452: aload_1        
        //   453: goto            457
        //   456: athrow         
        //   457: invokevirtual   dev/nuker/pyro/f0F.1:()I
        //   460: goto            464
        //   463: athrow         
        //   464: getstatic       dev/nuker/pyro/f0H.c:I
        //   467: isub           
        //   468: aload_1        
        //   469: goto            473
        //   472: athrow         
        //   473: invokevirtual   dev/nuker/pyro/f0F.3:()I
        //   476: goto            480
        //   479: athrow         
        //   480: getstatic       dev/nuker/pyro/f0H.c:I
        //   483: isub           
        //   484: getstatic       dev/nuker/pyro/fc.1:I
        //   487: ifne            495
        //   490: ldc             -223019515
        //   492: goto            497
        //   495: ldc             2050041417
        //   497: ldc             -1977850736
        //   499: ixor           
        //   500: lookupswitch {
        //          -265469223: 528
        //          2024315541: 495
        //          default: 960
        //        }
        //   528: aload_0        
        //   529: getfield        dev/nuker/pyro/f0K.c:Ldev/nuker/pyro/fw;
        //   532: goto            536
        //   535: athrow         
        //   536: invokevirtual   dev/nuker/pyro/fw.0:()Ljava/lang/Object;
        //   539: goto            543
        //   542: athrow         
        //   543: dup            
        //   544: pop            
        //   545: checkcast       Ljava/lang/Boolean;
        //   548: getstatic       dev/nuker/pyro/fc.0:I
        //   551: ifgt            559
        //   554: ldc             -1071974261
        //   556: goto            561
        //   559: ldc             1580916675
        //   561: ldc             -1891341419
        //   563: ixor           
        //   564: lookupswitch {
        //          -780225450: 592
        //          1331598110: 559
        //          default: 962
        //        }
        //   592: goto            596
        //   595: athrow         
        //   596: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   599: goto            603
        //   602: athrow         
        //   603: ifeq            611
        //   606: ldc             1194441729
        //   608: goto            613
        //   611: ldc             1194441728
        //   613: ldc             -94560535
        //   615: ixor           
        //   616: tableswitch {
        //          2061059536: 640
        //          2061059537: 656
        //          default: 606
        //        }
        //   640: aload           6
        //   642: goto            646
        //   645: athrow         
        //   646: invokevirtual   dev/nuker/pyro/f0H.5:()I
        //   649: goto            653
        //   652: athrow         
        //   653: goto            711
        //   656: aload           6
        //   658: getstatic       dev/nuker/pyro/fc.0:I
        //   661: ifgt            669
        //   664: ldc             -299749277
        //   666: goto            671
        //   669: ldc             195295717
        //   671: ldc             -1399429617
        //   673: ixor           
        //   674: lookupswitch {
        //          -1489657878: 700
        //          1119114860: 669
        //          default: 978
        //        }
        //   700: goto            704
        //   703: athrow         
        //   704: invokevirtual   dev/nuker/pyro/f0H.9:()I
        //   707: goto            711
        //   710: athrow         
        //   711: goto            715
        //   714: athrow         
        //   715: invokestatic    net/minecraft/client/gui/Gui.func_73734_a:(IIIII)V
        //   718: goto            722
        //   721: athrow         
        //   722: getstatic       dev/nuker/pyro/fc.c:I
        //   725: ifne            733
        //   728: ldc             -1021142334
        //   730: goto            735
        //   733: ldc             -31001421
        //   735: ldc             1962684711
        //   737: ixor           
        //   738: lookupswitch {
        //          -1210143771: 972
        //          1830401691: 733
        //          default: 764
        //        }
        //   764: aload_0        
        //   765: getstatic       dev/nuker/pyro/fc.c:I
        //   768: ifne            776
        //   771: ldc             -1977991166
        //   773: goto            778
        //   776: ldc             349434164
        //   778: ldc             1761894115
        //   780: ixor           
        //   781: lookupswitch {
        //          -484565279: 776
        //          2111287255: 808
        //          default: 966
        //        }
        //   808: getfield        dev/nuker/pyro/f0K.c:Ldev/nuker/pyro/fw;
        //   811: goto            815
        //   814: athrow         
        //   815: invokevirtual   dev/nuker/pyro/fw.0:()Ljava/lang/Object;
        //   818: goto            822
        //   821: athrow         
        //   822: dup            
        //   823: pop            
        //   824: checkcast       Ljava/lang/Boolean;
        //   827: getstatic       dev/nuker/pyro/fc.0:I
        //   830: ifgt            838
        //   833: ldc             -660661770
        //   835: goto            840
        //   838: ldc             33611277
        //   840: ldc             892759853
        //   842: ixor           
        //   843: lookupswitch {
        //          -1192706880: 838
        //          -307661093: 956
        //          default: 868
        //        }
        //   868: goto            872
        //   871: athrow         
        //   872: invokevirtual   java/lang/Boolean.booleanValue:()Z
        //   875: goto            879
        //   878: athrow         
        //   879: ifeq            892
        //   882: iload           7
        //   884: iconst_1       
        //   885: isub           
        //   886: iload           9
        //   888: isub           
        //   889: goto            899
        //   892: iload           7
        //   894: iload           8
        //   896: isub           
        //   897: iconst_1       
        //   898: iadd           
        //   899: istore          10
        //   901: iload           10
        //   903: getstatic       dev/nuker/pyro/f0H.c:I
        //   906: iconst_1       
        //   907: iadd           
        //   908: iload           10
        //   910: iload           9
        //   912: iadd           
        //   913: aload_1        
        //   914: goto            918
        //   917: athrow         
        //   918: invokevirtual   dev/nuker/pyro/f0F.3:()I
        //   921: goto            925
        //   924: athrow         
        //   925: getstatic       dev/nuker/pyro/f0H.c:I
        //   928: isub           
        //   929: iconst_1       
        //   930: isub           
        //   931: aload           6
        //   933: goto            937
        //   936: athrow         
        //   937: invokevirtual   dev/nuker/pyro/f0H.b:()I
        //   940: goto            944
        //   943: athrow         
        //   944: goto            948
        //   947: athrow         
        //   948: invokestatic    net/minecraft/client/gui/Gui.func_73734_a:(IIIII)V
        //   951: goto            955
        //   954: athrow         
        //   955: return         
        //   956: aconst_null    
        //   957: athrow         
        //   958: aconst_null    
        //   959: athrow         
        //   960: aconst_null    
        //   961: athrow         
        //   962: aconst_null    
        //   963: athrow         
        //   964: aconst_null    
        //   965: athrow         
        //   966: aconst_null    
        //   967: athrow         
        //   968: aconst_null    
        //   969: athrow         
        //   970: aconst_null    
        //   971: athrow         
        //   972: aconst_null    
        //   973: athrow         
        //   974: aconst_null    
        //   975: athrow         
        //   976: aconst_null    
        //   977: athrow         
        //   978: aconst_null    
        //   979: athrow         
        //   980: pop            
        //   981: goto            24
        //   984: pop            
        //   985: aconst_null    
        //   986: goto            980
        //   989: dup            
        //   990: ifnull          980
        //   993: checkcast       Ljava/lang/Throwable;
        //   996: athrow         
        //   997: dup            
        //   998: ifnull          984
        //  1001: checkcast       Ljava/lang/Throwable;
        //  1004: athrow         
        //  1005: aconst_null    
        //  1006: athrow         
        //    StackMapTable: 00 94 43 07 00 3B 04 FF 00 0B 00 00 00 01 07 00 3B FF 00 03 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 00 50 07 00 03 FF 00 01 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 02 07 00 03 01 5C 07 00 03 FF 00 0B 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 02 07 00 03 07 00 4F FF 00 01 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 03 07 00 03 07 00 4F 01 FF 00 1D 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 02 07 00 03 07 00 4F 47 07 00 1A FF 00 00 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 05 07 00 03 07 00 4F 03 03 07 00 5C 45 07 00 3B 00 46 07 00 2C FF 00 00 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 02 07 00 4A 07 00 4F 45 07 00 3B FF 00 00 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 02 07 00 4A 07 00 A2 49 07 00 3B FF 00 00 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 06 07 00 4A 07 00 A2 07 00 A4 01 01 07 00 4F 45 07 00 3B FF 00 00 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 06 07 00 4A 07 00 A2 07 00 A4 01 01 01 45 07 00 1C FF 00 00 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 07 07 00 4A 07 00 A2 07 00 A4 01 01 01 07 00 4F 45 07 00 3B FF 00 00 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 07 07 00 4A 07 00 A2 07 00 A4 01 01 01 01 FF 00 12 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 0A 07 00 4A 07 00 A2 07 00 A4 01 01 01 01 07 00 A6 01 07 00 5C FF 00 01 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 0B 07 00 4A 07 00 A2 07 00 A4 01 01 01 01 07 00 A6 01 07 00 5C 01 FF 00 1B 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 0A 07 00 4A 07 00 A2 07 00 A4 01 01 01 01 07 00 A6 01 07 00 5C 42 07 00 1C FF 00 00 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 0A 07 00 4A 07 00 A2 07 00 A4 01 01 01 01 07 00 A6 01 07 00 5C 45 07 00 3B FF 00 00 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 0A 07 00 4A 07 00 A2 07 00 A4 01 01 01 01 07 00 A6 01 01 47 07 00 3B FF 00 00 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 0D 07 00 4A 07 00 A2 07 00 A4 01 01 01 01 07 00 A6 01 01 01 01 05 45 07 00 3B 00 43 07 00 3B 40 07 00 4F 45 07 00 3B 40 01 FC 00 10 01 41 01 1D 4B 07 00 4F FF 00 01 00 06 07 00 03 07 00 4F 03 03 07 00 5C 01 00 02 07 00 4F 01 5D 07 00 4F 42 07 00 3B 40 07 00 4F 45 07 00 3B 40 01 4A 01 FF 00 01 00 06 07 00 03 07 00 4F 03 03 07 00 5C 01 00 02 01 01 5B 01 FF 00 0D 00 07 07 00 03 07 00 4F 03 03 07 00 5C 01 01 00 01 07 00 3B 40 07 00 4F 45 07 00 3B 40 01 FF 00 15 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 01 07 00 3B FF 00 00 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 03 01 01 07 00 4F 45 07 00 3B FF 00 00 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 03 01 01 01 47 07 00 3B FF 00 00 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 04 01 01 01 07 00 4F 45 07 00 3B FF 00 00 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 04 01 01 01 01 FF 00 0E 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 04 01 01 01 01 FF 00 01 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 05 01 01 01 01 01 FF 00 1E 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 04 01 01 01 01 46 07 00 18 FF 00 00 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 05 01 01 01 01 07 00 79 45 07 00 3B FF 00 00 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 05 01 01 01 01 07 00 A8 FF 00 0F 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 05 01 01 01 01 07 00 7E FF 00 01 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 06 01 01 01 01 07 00 7E 01 FF 00 1E 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 05 01 01 01 01 07 00 7E 42 07 00 3B FF 00 00 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 05 01 01 01 01 07 00 7E 45 07 00 3B FF 00 00 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 05 01 01 01 01 01 FF 00 02 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 04 01 01 01 01 FF 00 04 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 04 01 01 01 01 FF 00 01 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 05 01 01 01 01 01 FF 00 1A 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 04 01 01 01 01 44 07 00 3B FF 00 00 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 05 01 01 01 01 07 00 5C 45 07 00 3B FF 00 00 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 05 01 01 01 01 01 FF 00 02 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 04 01 01 01 01 FF 00 0C 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 05 01 01 01 01 07 00 5C FF 00 01 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 06 01 01 01 01 07 00 5C 01 FF 00 1C 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 05 01 01 01 01 07 00 5C 42 07 00 22 FF 00 00 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 05 01 01 01 01 07 00 5C 45 07 00 3B FF 00 00 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 05 01 01 01 01 01 42 07 00 3B FF 00 00 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 05 01 01 01 01 01 45 07 00 3B 00 0A 41 01 1C 4B 07 00 03 FF 00 01 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 02 07 00 03 01 5D 07 00 03 45 07 00 3B 40 07 00 79 45 07 00 3B 40 07 00 A8 4F 07 00 7E FF 00 01 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 02 07 00 7E 01 5B 07 00 7E 42 07 00 3B 40 07 00 7E 45 07 00 3B 40 01 0C 46 01 FF 00 11 00 09 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 01 00 01 07 00 2A FF 00 00 00 09 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 01 00 04 01 01 01 07 00 4F 45 07 00 3B FF 00 00 00 09 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 01 00 04 01 01 01 01 4A 07 00 3B FF 00 00 00 09 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 01 00 05 01 01 01 01 07 00 5C 45 07 00 3B FF 00 00 00 09 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 01 00 05 01 01 01 01 01 42 07 00 3B FF 00 00 00 09 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 01 00 05 01 01 01 01 01 45 07 00 3B 00 FF 00 00 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 01 07 00 7E FF 00 01 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 01 07 00 03 FF 00 01 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 04 01 01 01 01 FF 00 01 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 05 01 01 01 01 07 00 7E FF 00 01 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 02 07 00 03 07 00 4F FF 00 01 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 01 07 00 03 FF 00 01 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 0A 07 00 4A 07 00 A2 07 00 A4 01 01 01 01 07 00 A6 01 07 00 5C FF 00 01 00 06 07 00 03 07 00 4F 03 03 07 00 5C 01 00 01 07 00 4F FD 00 01 01 01 FF 00 01 00 06 07 00 03 07 00 4F 03 03 07 00 5C 01 00 01 01 01 FF 00 01 00 08 07 00 03 07 00 4F 03 03 07 00 5C 01 01 01 00 05 01 01 01 01 07 00 5C FF 00 01 00 05 07 00 03 07 00 4F 03 03 07 00 5C 00 01 07 00 3B 43 05 44 07 00 3B 47 05 47 07 00 3B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     989    997    Any
        //  989    997    989    997    Ljava/lang/ClassCastException;
        //  1005   1007   3      8      Ljava/lang/IllegalArgumentException;
        //  124    131    131    132    Any
        //  125    131    131    132    Any
        //  124    131    3      8      Ljava/lang/NumberFormatException;
        //  125    131    124    125    Ljava/lang/NumberFormatException;
        //  124    131    124    125    Ljava/lang/NumberFormatException;
        //  139    146    146    147    Any
        //  139    146    3      8      Any
        //  139    146    146    147    Any
        //  140    146    139    140    Ljava/lang/ArithmeticException;
        //  140    146    139    140    Ljava/lang/NumberFormatException;
        //  157    164    164    165    Any
        //  157    164    3      8      Ljava/lang/NullPointerException;
        //  158    164    157    158    Ljava/util/ConcurrentModificationException;
        //  157    164    157    158    Any
        //  157    164    157    158    Any
        //  171    178    178    179    Any
        //  171    178    178    179    Ljava/lang/EnumConstantNotPresentException;
        //  172    178    178    179    Ljava/lang/NumberFormatException;
        //  172    178    178    179    Any
        //  172    178    171    172    Ljava/lang/ArithmeticException;
        //  231    238    238    239    Any
        //  231    238    3      8      Ljava/util/ConcurrentModificationException;
        //  232    238    238    239    Any
        //  232    238    231    232    Ljava/lang/ArithmeticException;
        //  231    238    3      8      Ljava/lang/NegativeArraySizeException;
        //  247    254    254    255    Any
        //  247    254    247    248    Ljava/lang/StringIndexOutOfBoundsException;
        //  248    254    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  248    254    247    248    Any
        //  248    254    3      8      Any
        //  259    266    266    267    Any
        //  259    266    259    260    Any
        //  260    266    259    260    Any
        //  260    266    266    267    Ljava/lang/EnumConstantNotPresentException;
        //  260    266    3      8      Any
        //  363    370    370    371    Any
        //  364    370    3      8      Any
        //  364    370    3      8      Any
        //  364    370    3      8      Ljava/lang/StringIndexOutOfBoundsException;
        //  364    370    363    364    Any
        //  426    433    433    434    Any
        //  427    433    3      8      Ljava/lang/AssertionError;
        //  427    433    426    427    Ljava/lang/RuntimeException;
        //  427    433    426    427    Ljava/lang/AssertionError;
        //  427    433    433    434    Ljava/lang/IndexOutOfBoundsException;
        //  456    463    463    464    Any
        //  457    463    456    457    Any
        //  457    463    456    457    Any
        //  456    463    463    464    Ljava/lang/IndexOutOfBoundsException;
        //  456    463    463    464    Ljava/lang/NegativeArraySizeException;
        //  472    479    479    480    Any
        //  472    479    479    480    Ljava/util/ConcurrentModificationException;
        //  472    479    472    473    Any
        //  472    479    472    473    Any
        //  472    479    3      8      Ljava/lang/IllegalStateException;
        //  535    542    542    543    Any
        //  535    542    542    543    Any
        //  536    542    3      8      Ljava/lang/ArrayIndexOutOfBoundsException;
        //  535    542    3      8      Any
        //  536    542    535    536    Ljava/lang/IllegalArgumentException;
        //  595    602    602    603    Any
        //  596    602    595    596    Ljava/lang/IllegalArgumentException;
        //  596    602    595    596    Any
        //  595    602    3      8      Any
        //  596    602    595    596    Any
        //  645    652    652    653    Any
        //  646    652    645    646    Any
        //  645    652    652    653    Ljava/lang/IllegalStateException;
        //  645    652    652    653    Ljava/lang/NumberFormatException;
        //  646    652    645    646    Any
        //  703    710    710    711    Any
        //  703    710    710    711    Any
        //  704    710    710    711    Any
        //  704    710    703    704    Ljava/lang/EnumConstantNotPresentException;
        //  704    710    3      8      Ljava/util/ConcurrentModificationException;
        //  714    721    721    722    Any
        //  714    721    721    722    Any
        //  714    721    721    722    Ljava/util/NoSuchElementException;
        //  714    721    714    715    Ljava/lang/RuntimeException;
        //  715    721    714    715    Any
        //  814    821    821    822    Any
        //  814    821    814    815    Any
        //  814    821    814    815    Ljava/lang/ArrayIndexOutOfBoundsException;
        //  815    821    814    815    Ljava/lang/ClassCastException;
        //  815    821    821    822    Ljava/lang/IllegalArgumentException;
        //  871    878    878    879    Any
        //  872    878    871    872    Ljava/lang/AssertionError;
        //  872    878    871    872    Any
        //  871    878    871    872    Any
        //  872    878    3      8      Ljava/lang/NumberFormatException;
        //  917    924    924    925    Any
        //  917    924    924    925    Ljava/lang/UnsupportedOperationException;
        //  917    924    924    925    Any
        //  918    924    3      8      Ljava/lang/UnsupportedOperationException;
        //  918    924    917    918    Ljava/lang/AssertionError;
        //  936    943    943    944    Any
        //  936    943    943    944    Ljava/lang/NumberFormatException;
        //  937    943    3      8      Any
        //  937    943    943    944    Any
        //  936    943    936    937    Any
        //  947    954    954    955    Any
        //  948    954    954    955    Any
        //  948    954    3      8      Ljava/lang/IndexOutOfBoundsException;
        //  948    954    947    948    Any
        //  948    954    947    948    Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index -1 out of bounds for length 0
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.remove(ArrayList.java:535)
        //     at com.strobel.assembler.ir.StackMappingVisitor.pop(StackMappingVisitor.java:267)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.execute(StackMappingVisitor.java:600)
        //     at com.strobel.assembler.ir.StackMappingVisitor$InstructionAnalyzer.visit(StackMappingVisitor.java:398)
        //     at com.strobel.decompiler.ast.AstBuilder.performStackAnalysis(AstBuilder.java:2030)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:108)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public void c(@NotNull final String s) {
        fez.bN(this, 835029631, s);
    }
    
    @Override
    public void 0(@NotNull final f0F f0F, @NotNull final f0H f0H, @NotNull final f17 f17) {
        fez.0u(this, 170177106, f0F, f0H, f17);
    }
    
    @NotNull
    public fw c() {
        return fez.aE(this, 729622290);
    }
    
    @NotNull
    public String 0() {
        return fez.43(this, 730030069);
    }
    
    static {
        throw t;
    }
    
    @Override
    public int 0(@NotNull final f0F p0, @NotNull final f0H p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: dup            
        //     4: ifnull          75
        //     7: athrow         
        //     8: aconst_null    
        //     9: getstatic       dev/nuker/pyro/fc.0:I
        //    12: ifeq            67
        //    15: pop            
        //    16: aconst_null    
        //    17: goto            59
        //    20: nop            
        //    21: nop            
        //    22: nop            
        //    23: athrow         
        //    24: aload_1        
        //    25: pop            
        //    26: aload_2        
        //    27: pop            
        //    28: aload_1        
        //    29: goto            33
        //    32: athrow         
        //    33: invokevirtual   dev/nuker/pyro/f0F.0:()Lnet/minecraft/client/gui/FontRenderer;
        //    36: goto            40
        //    39: athrow         
        //    40: getfield        net/minecraft/client/gui/FontRenderer.field_78288_b:I
        //    43: getstatic       dev/nuker/pyro/f0H.c:I
        //    46: iconst_2       
        //    47: imul           
        //    48: iadd           
        //    49: ireturn        
        //    50: pop            
        //    51: goto            24
        //    54: pop            
        //    55: aconst_null    
        //    56: goto            50
        //    59: dup            
        //    60: ifnull          50
        //    63: checkcast       Ljava/lang/Throwable;
        //    66: athrow         
        //    67: dup            
        //    68: ifnull          54
        //    71: checkcast       Ljava/lang/Throwable;
        //    74: athrow         
        //    75: aconst_null    
        //    76: athrow         
        //    StackMapTable: 00 0D 43 07 00 3B 04 FF 00 0B 00 00 00 01 07 00 3B FE 00 03 07 00 03 07 00 4F 07 00 5C FF 00 07 00 00 00 01 07 00 3B FF 00 00 00 03 07 00 03 07 00 4F 07 00 5C 00 01 07 00 4F 45 07 00 3B 40 07 00 A2 49 07 00 3B 43 05 44 07 00 3B 47 05 47 07 00 3B
        //    Exceptions:
        //  Try           Handler
        //  Start  End    Start  End    Type                                       
        //  -----  -----  -----  -----  -------------------------------------------
        //  8      20     59     67     Ljava/lang/StringIndexOutOfBoundsException;
        //  59     67     59     67     Any
        //  75     77     3      8      Any
        //  33     39     39     40     Any
        //  33     39     39     40     Ljava/util/ConcurrentModificationException;
        //  33     39     3      8      Ljava/lang/EnumConstantNotPresentException;
        //  33     39     3      8      Any
        //  33     39     3      8      Any
        // 
        // The error that occurred was:
        // 
        // java.lang.IndexOutOfBoundsException: Index 40 out of bounds for length 40
        //     at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        //     at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        //     at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        //     at java.base/java.util.Objects.checkIndex(Objects.java:372)
        //     at java.base/java.util.ArrayList.get(ArrayList.java:458)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3321)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3569)
        //     at com.strobel.decompiler.ast.AstBuilder.convertToAst(AstBuilder.java:3435)
        //     at com.strobel.decompiler.ast.AstBuilder.build(AstBuilder.java:113)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:211)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public int c(@NotNull final f0F f0F, @NotNull final f0H f0H) {
        return fez.jf(this, 1287936473, f0F, f0H);
    }
    
    public f0K(@NotNull final f0k f0k) {
        while (true) {
            int n = 0;
            Label_0013: {
                if (fc.0 <= 0) {
                    n = 1151195551;
                    break Label_0013;
                }
                n = 780709255;
            }
            switch (n ^ 0xEADA72A8) {
                case -1371034825: {
                    continue;
                }
                case -1001201873: {
                    while (true) {
                        int n2 = 0;
                        Label_0059: {
                            if (fc.1 == 0) {
                                n2 = 877541184;
                                break Label_0059;
                            }
                            n2 = -1478767329;
                        }
                        switch (n2 ^ 0xF849292C) {
                            case -264796690: {
                                continue;
                            }
                            default: {
                                final f0k f0k2 = f0k;
                                while (true) {
                                    int n3 = 0;
                                    Label_0106: {
                                        if (fc.0 <= 0) {
                                            n3 = -213133443;
                                            break Label_0106;
                                        }
                                        n3 = -1376022740;
                                    }
                                    switch (n3 ^ 0xB2650C6A) {
                                        case 1193880603: {
                                            continue;
                                        }
                                        default: {
                                            super(f0k2);
                                            while (true) {
                                                int n4 = 0;
                                                Label_0152: {
                                                    if (fc.1 == 0) {
                                                        n4 = 2121772662;
                                                        break Label_0152;
                                                    }
                                                    n4 = 1662831562;
                                                }
                                                switch (n4 ^ 0xA24A0E35) {
                                                    case -599941053: {
                                                        continue;
                                                    }
                                                    case -1051277825: {
                                                        final String c = f0k.c();
                                                        while (true) {
                                                            int n5 = 0;
                                                            Label_0198: {
                                                                if (fc.0 <= 0) {
                                                                    n5 = 358952308;
                                                                    break Label_0198;
                                                                }
                                                                n5 = 1445942137;
                                                            }
                                                            switch (n5 ^ 0xB3112321) {
                                                                case -1502343595: {
                                                                    continue;
                                                                }
                                                                case -448892840: {
                                                                    this.c = c;
                                                                    this.c = (fw<Boolean>)f0k.5();
                                                                    return;
                                                                }
                                                                default: {
                                                                    throw null;
                                                                }
                                                            }
                                                            break;
                                                        }
                                                        break;
                                                    }
                                                    default: {
                                                        throw null;
                                                    }
                                                }
                                                break;
                                            }
                                            break;
                                        }
                                        case 1093589783: {
                                            throw null;
                                        }
                                    }
                                    break;
                                }
                                break;
                            }
                            case -871948692: {
                                throw null;
                            }
                        }
                        break;
                    }
                    break;
                }
                default: {
                    throw null;
                }
            }
            break;
        }
    }
}
